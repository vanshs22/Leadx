-- Ensure client portal login can bind + list
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS avatar_url text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS role text DEFAULT 'member';

-- Helpful unique on email per tenant when auth_user_id path fails
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tenant_members_tenant_email_key'
  ) THEN
    BEGIN
      ALTER TABLE public.tenant_members ADD CONSTRAINT tenant_members_tenant_email_key UNIQUE (tenant_id, email);
    EXCEPTION WHEN others THEN
      NULL; -- ignore if duplicates exist
    END;
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
