#!/usr/bin/env python3
"""
Standalone LinkedIn scraper + Instagram (instaloader) health test.
Does NOT run the full pipeline.

Usage (from repo root or lead-engine-v2):

  ./scripts/test_social.sh
  # or:
  cd lead-engine-v2 && source .venv/bin/activate
  PYTHONPATH=. python scripts/../scripts/test_linkedin_instagram.py

Exit codes: 0 = both usable, 1 = one failed, 2 = both failed / setup error
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

# Load .env from lead-engine-v2 or repo root
ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "lead-engine-v2"
if not ENGINE.is_dir():
    ENGINE = ROOT  # script may live under lead-engine-v2/scripts

for env_path in (ENGINE / ".env", ROOT / ".env", Path.cwd() / ".env"):
    if env_path.is_file():
        try:
            from dotenv import load_dotenv
            load_dotenv(env_path)
            print(f"Loaded env: {env_path}")
        except ImportError:
            # minimal dotenv
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if k and k not in os.environ:
                    os.environ[k] = v
            print(f"Loaded env (manual): {env_path}")
        break
else:
    print("WARN: no .env found — using process environment only")

# PYTHONPATH
sys.path.insert(0, str(ENGINE if (ENGINE / "backend").is_dir() else ROOT))


def section(title: str) -> None:
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


async def test_linkedin() -> bool:
    section("LINKEDIN SCRAPER")
    base = (os.getenv("LINKEDIN_SCRAPER_URL") or "").strip().rstrip("/")
    if not base:
        print("FAIL: LINKEDIN_SCRAPER_URL is empty")
        print("  Set e.g. LINKEDIN_SCRAPER_URL=http://127.0.0.1:8001")
        return False
    if base.startswith("https://"):
        print(f"WARN: URL is HTTPS ({base}) — scraper is usually HTTP only")
        print("  Prefer http://127.0.0.1:8001 to avoid SSL: WRONG_VERSION_NUMBER")

    print(f"URL: {base}")
    import httpx

    # 1) Health
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(f"{base}/health")
            print(f"GET /health → {r.status_code} {r.text[:200]!r}")
            if r.status_code >= 400:
                print("FAIL: scraper health not OK — is the process running?")
                return False
    except Exception as e:
        print(f"FAIL: cannot reach scraper: {e}")
        print("  Start linkedin-scraper, then: curl -s http://127.0.0.1:8001/health")
        return False

    cookie = (os.getenv("LINKEDIN_LI_AT_COOKIE") or "").strip()
    if not cookie:
        print("WARN: LINKEDIN_LI_AT_COOKIE empty — trying key pool / search may 401")
    else:
        print(f"LINKEDIN_LI_AT_COOKIE: set ({len(cookie)} chars)")

    # 2) Optional company-search smoke (needs cookie)
    if not cookie:
        print("SKIP company-search (no li_at cookie)")
        print("PASS: scraper is reachable (add li_at for full search test)")
        return True

    headers = {
        "X-Li-At": cookie,
        "Authorization": f"Bearer {cookie}",
        "Content-Type": "application/json",
    }
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            r = await client.post(
                f"{base}/company-search",
                headers=headers,
                json={"name": "med spa", "location": "Hoboken NJ"},
            )
            print(f"POST /company-search → {r.status_code}")
            body = (r.text or "")[:400]
            print(f"Body preview: {body!r}")
            if r.status_code in (401, 403):
                print("FAIL: cookie rejected — refresh li_at from browser")
                return False
            if r.status_code >= 400:
                print("FAIL: company-search error")
                return False
            print("PASS: LinkedIn scraper health + search OK")
            return True
    except Exception as e:
        print(f"FAIL: company-search exception: {e}")
        return False


async def test_instagram() -> bool:
    section("INSTAGRAM (instaloader)")
    user = (os.getenv("INSTAGRAM_USERNAME") or "").strip()
    password = (os.getenv("INSTAGRAM_PASSWORD") or "").strip()
    session = os.getenv("INSTAGRAM_SESSION_FILE") or "/tmp/leadx_instagram_session"
    print(f"INSTAGRAM_USERNAME: {user or '(empty)'}")
    print(f"INSTAGRAM_PASSWORD: {'set' if password else '(empty)'}")
    print(f"INSTAGRAM_SESSION_FILE: {session}")

    try:
        import instaloader  # noqa: F401
    except ImportError:
        print("FAIL: instaloader not installed — pip install instaloader")
        return False

    try:
        from backend.integrations.prod.social_discovery import get_logged_in_instaloader
    except Exception as e:
        print(f"FAIL: cannot import get_logged_in_instaloader: {e}")
        return False

    # Login / session
    try:
        L = get_logged_in_instaloader()
        print("Instaloader instance: OK")
    except Exception as e:
        print(f"FAIL: login/session: {e}")
        return False

    # Profile smoke (public)
    test_handle = (os.getenv("INSTAGRAM_TEST_HANDLE") or "instagram").strip().lstrip("@")
    try:
        import instaloader as il
        profile = il.Profile.from_username(L.context, test_handle)
        print(f"Profile @{profile.username}: followers={profile.followers} name={profile.full_name!r}")
        print("PASS: profile fetch OK")
    except Exception as e:
        print(f"FAIL: profile fetch @{test_handle}: {e}")
        return False

    # Hashtag smoke (needs login — this is the 403 path)
    tag = (os.getenv("INSTAGRAM_TEST_TAG") or "medspa").strip().lstrip("#")
    try:
        import instaloader as il
        it = il.Hashtag.from_name(L.context, tag).get_posts()
        n = 0
        sample = None
        for post in it:
            n += 1
            try:
                sample = post.owner_username
            except Exception:
                sample = None
            if n >= 2:
                break
        print(f"Hashtag #{tag}: got {n} post(s), sample owner={sample!r}")
        if n == 0:
            print("WARN: 0 posts — tag may be empty or still blocked")
            print("PASS with warn: login worked for profile; hashtag returned 0")
            return True
        print("PASS: hashtag discovery OK (login works)")
        return True
    except Exception as e:
        err = str(e)
        print(f"FAIL: hashtag #{tag}: {e}")
        if "login_required" in err or "403" in err:
            print("  → Instagram still wants login. Check username/password, complete checkpoint in browser, delete session file and retry.")
        if "429" in err:
            print("  → Rate limited. Wait and retry later.")
        return False


async def main() -> int:
    print("LeadX social-only test (LinkedIn + Instagram)")
    li_ok = await test_linkedin()
    ig_ok = await test_instagram()
    section("SUMMARY")
    print(f"LinkedIn:  {'PASS' if li_ok else 'FAIL'}")
    print(f"Instagram: {'PASS' if ig_ok else 'FAIL'}")
    if li_ok and ig_ok:
        print("Both usable.")
        return 0
    if li_ok or ig_ok:
        print("One channel failed — see sections above.")
        return 1
    print("Both failed.")
    return 2


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
