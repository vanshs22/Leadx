"""
Production Lead Pipeline Orchestrator
Discover → Enrich → Score → Store → Gate → Assign → Deliver
Tracks pipeline_runs + enrichment_failures for ops.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from backend.memory.supabase_client import get_supabase
from backend.integrations.prod.discovery import discover_leads
from backend.integrations.prod.enricher import enrich_batch
from backend.integrations.prod.quality import (
    score_lead, passes_quality_gate, assign_lead, quota_remaining,
)
from backend.integrations.prod.utils import setup_logging
from backend.services.delivery import deliver_batch

logger = logging.getLogger("lead_engine.pipeline")



def _fill_geo_fields(lead: dict) -> dict:
    """Fill state/city from address when Serper packs 'Hoboken NJ' into city only."""
    import re
    state = (lead.get("state") or "").strip()
    city = (lead.get("city") or "").strip()
    address = (lead.get("address") or "").strip()
    if not state:
        # ", NJ 07030" or "Hoboken, NJ"
        m = re.search(r",\s*([A-Z]{2})\s*\d{0,5}\s*$", address)
        if m:
            lead["state"] = m.group(1)
        elif re.search(r"\b([A-Z]{2})\b\s*$", city):
            m2 = re.search(r"^(.*?)\s+([A-Z]{2})$", city)
            if m2:
                lead["city"] = m2.group(1).strip()
                lead["state"] = m2.group(2)
    return lead

async def _upsert_global(lead: dict) -> Optional[str]:
    lead = _fill_geo_fields(lead)
    sb = get_supabase()
    fp = lead.get("fingerprint")
    phone = lead.get("phone_normalized")
    payload = {
        "fingerprint": fp,
        "phone_normalized": phone,
        "phone_e164": lead.get("phone_e164"),
        "name": lead.get("name") or lead.get("company_name") or "",
        "name_normalized": (lead.get("name") or "").lower().strip(),
        "address": lead.get("address"),
        "city": lead.get("city"),
        "state": lead.get("state"),
        "website": lead.get("website"),
        "website_domain": lead.get("website_domain"),
        "category": lead.get("category") or lead.get("industry"),
        "business_status": (lead.get("business_status") or "OPERATIONAL").upper(),
        "google_rating": lead.get("google_rating"),
        "review_count": lead.get("review_count") or 0,
        "google_place_id": lead.get("google_place_id"),
        "source": lead.get("source", "google_maps_serper"),
        "raw_data": lead.get("raw_data") or {},
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        if fp:
            ex = sb.table("leads_global").select("id").eq("fingerprint", fp).limit(1).execute().data
            if ex:
                sb.table("leads_global").update(payload).eq("id", ex[0]["id"]).execute()
                return ex[0]["id"]
        if phone:
            ex = sb.table("leads_global").select("id").eq("phone_normalized", phone).limit(1).execute().data
            if ex:
                sb.table("leads_global").update(payload).eq("id", ex[0]["id"]).execute()
                return ex[0]["id"]
        r = sb.table("leads_global").insert(payload).execute()
        return r.data[0]["id"] if r.data else None
    except Exception as e:
        logger.warning("upsert_global failed: %s", e)
        return None


async def _upsert_enrichment(lead_id: str, lead: dict) -> None:
    """Persist enrich + post_enrich fields (pitch, intent, owner, email)."""
    sb = get_supabase()
    try:
        payload = {
            "lead_id": lead_id,
            "email": lead.get("email"),
            "email_valid": lead.get("email_valid"),
            "emails": lead.get("emails") or [],
            "phone_from_web": lead.get("phone_from_web"),
            "has_booking": bool(lead.get("has_booking") or lead.get("booking_platform")),
            "booking_platform": lead.get("booking_platform"),
            "services": lead.get("services") or [],
            "social_links": lead.get("social_links") or {},
            "owner_name": lead.get("owner_name") or lead.get("decision_maker_name"),
            "pitch_line": lead.get("pitch_line"),
            "intent_score": int(lead.get("intent_score") or 0),
            "markdown_summary": (lead.get("markdown_summary") or "")[:4000] or None,
            "raw_extraction": lead.get("raw_extraction") or {},
            "enrichment_method": lead.get("enrichment_method"),
            "enrichment_ok": bool(lead.get("enrichment_ok")),
            "error": lead.get("enrichment_error"),
            "extracted_at": datetime.now(timezone.utc).isoformat(),
        }
        # optional columns — drop if schema older
        if lead.get("why_now") is not None:
            payload["raw_extraction"] = {
                **(payload.get("raw_extraction") or {}),
                "why_now": lead.get("why_now"),
            }
        try:
            sb.table("enrichment").upsert(payload, on_conflict="lead_id").execute()
        except Exception as e1:
            # retry without pitch/intent if columns missing
            for k in ("pitch_line", "intent_score"):
                payload.pop(k, None)
            try:
                sb.table("enrichment").upsert(payload, on_conflict="lead_id").execute()
            except Exception as e2:
                logger.warning("upsert_enrichment failed: %s / %s", e1, e2)
    except Exception as e:
        logger.warning("upsert_enrichment failed: %s", e)


async def _upsert_score(lead_id: str, score: int, tier: str, reasoning: str, lead: Optional[dict] = None) -> None:
    sb = get_supabase()
    lead = lead or {}
    try:
        row = {
            "lead_id": lead_id,
            "deterministic_score": score,
            "total_score": score,
            "tier": tier,
            "reasoning": reasoning,
            "scored_at": datetime.now(timezone.utc).isoformat(),
        }
        if lead.get("pitch_line"):
            row["pitch_line"] = lead.get("pitch_line")
        if lead.get("intent_score") is not None:
            row["intent_score"] = int(lead.get("intent_score") or 0)
        try:
            sb.table("scores").upsert(row, on_conflict="lead_id").execute()
        except Exception:
            row.pop("pitch_line", None)
            row.pop("intent_score", None)
            sb.table("scores").upsert(row, on_conflict="lead_id").execute()
    except Exception as e:
        logger.warning("upsert_score failed: %s", e)


async def _record_enrich_failure(lead_id: Optional[str], website: str, error: str) -> None:
    sb = get_supabase()
    try:
        sb.table("enrichment_failures").insert({
            "lead_id": lead_id,
            "website": website,
            "error": str(error)[:500],
            "attempts": 1,
            "last_attempt": datetime.now(timezone.utc).isoformat(),
            "resolved": False,
        }).execute()
    except Exception:
        pass


async def run_pipeline(
    tenant_id: str,
    icp_id: Optional[str] = None,
    industry: str = "medspa",
    locations: Optional[list[str]] = None,
    queries: Optional[list[str]] = None,
    limit_per_location: int = 50,
    skip_enrichment: bool = False,
    allow_tier_b: bool = False,
    max_enrich_concurrent: int = 3,
    deliver: bool = True,
    use_crawl4ai: bool = True,
    use_firecrawl: bool = True,
    include_linkedin: bool = True,
    include_instagram: bool = True,
    social_limit_per_source: int = 10,
    include_maps: bool = True,
    include_web: bool = True,
    include_yelp: bool = True,
    include_facebook: bool = True,
    target_new_leads: int = 0,
    max_cells_per_run: int = 25,
    run_id: Optional[str] = None,
) -> dict:
    """
    Full production pipeline for one tenant/ICP.
    Pass run_id to reuse the row created by the API (live progress UI).
    """
    setup_logging()
    sb = get_supabase()
    t0 = time.perf_counter()
    run_id = (run_id or "").strip() or str(uuid4())
    started = datetime.now(timezone.utc)

    # Upsert run record (API may have pre-created this id as queued)
    try:
        existing = (
            sb.table("pipeline_runs").select("id").eq("id", run_id).limit(1).execute().data or []
        )
        row = {
            "id": run_id,
            "tenant_id": tenant_id,
            "icp_id": icp_id,
            "status": "running",
            "started_at": started.isoformat(),
            "meta": {"stage": "starting", "message": "Pipeline started"},
        }
        if existing:
            sb.table("pipeline_runs").update({
                "status": "running",
                "started_at": started.isoformat(),
                "meta": row["meta"],
                "error_message": None,
            }).eq("id", run_id).execute()
        else:
            sb.table("pipeline_runs").insert(row).execute()
    except Exception:
        try:
            sb.table("pipeline_runs").upsert({
                "id": run_id,
                "tenant_id": tenant_id,
                "icp_id": icp_id,
                "status": "running",
                "started_at": started.isoformat(),
            }).execute()
        except Exception:
            pass

    vertical = industry
    offer_category = None
    geo = locations or []
    delivery_channel = "portal"
    delivery_config: dict = {}

    # Resolve ICP + tenant
    try:
        if icp_id:
            icp_rows = sb.table("icp_profiles").select("*").eq("id", icp_id).limit(1).execute().data or []
            if icp_rows:
                icp = icp_rows[0]
                vertical = icp.get("vertical") or industry
                offer_category = icp.get("offer_category") or icp.get("offer_label") or None
                geo = icp.get("geo") or locations or []
                if not queries:
                    queries = icp.get("keywords") or None
        t_rows = sb.table("tenants").select("*").eq("id", tenant_id).limit(1).execute().data or []
        if t_rows:
            t = t_rows[0]
            if t.get("status") != "active":
                return {"error": "tenant_not_active", "tenant_id": tenant_id}
            delivery_channel = t.get("delivery_channel") or "portal"
            try:
                from backend.integrations.prod.crypto_config import load_delivery_config
                delivery_config = load_delivery_config(t)
            except Exception:
                delivery_config = t.get("delivery_config") or {}
            if t.get("allow_tier_b") or t.get("plan") in ("growth", "premium", "enterprise"):
                allow_tier_b = True
    except Exception as e:
        logger.warning("tenant/icp resolve: %s", e)

    if not geo:
        geo = ["New Jersey"]

    # Quota pre-check
    remaining = await quota_remaining(tenant_id)
    if remaining <= 0:
        result = {
            "pipeline": "lead_engine_v2",
            "run_id": run_id,
            "error": "quota_exhausted",
            "tenant_id": tenant_id,
        }
        await _finish_run(run_id, "failed", result, "quota_exhausted")
        return result

    # ---------- Stage 1: Discover (continuous / high-volume when target set) ----------
    logger.info(
        "[%s] Discover %s in %s limit=%s target_new=%s",
        run_id[:8], vertical, geo, limit_per_location, target_new_leads,
    )
    try:
        src_flags = {
            "maps": include_maps,
            "linkedin": include_linkedin,
            "instagram": include_instagram,
            "web": include_web,
            "yelp": include_yelp,
            "facebook": include_facebook,
        }
        # Auto-raise target for statewide ICPs (e.g. "New Jersey med spa")
        if not target_new_leads:
            try:
                from backend.integrations.prod.geo_grids import recommend_target
                target_new_leads = recommend_target(geo, 0)
            except Exception:
                pass
        # Continuous mode: expand geo cells + skip tenant-seen → constant net-new supply
        if target_new_leads and target_new_leads > 0:
            from backend.integrations.prod.continuous_discovery import discover_continuous
            raw = await discover_continuous(
                industry=vertical,
                locations=geo,
                tenant_id=tenant_id,
                icp_id=icp_id,
                queries=queries,
                target_new_leads=target_new_leads,
                max_cells_per_run=max_cells_per_run,
                sources=src_flags,
                social_limit_per_source=social_limit_per_source,
            )
        else:
            raw = await discover_leads(
                industry=vertical,
                locations=geo,
                queries=queries,
                limit_per_location=limit_per_location,
                include_linkedin=include_linkedin,
                include_instagram=include_instagram,
                social_limit_per_source=social_limit_per_source,
                include_maps=include_maps,
                include_web=include_web,
                include_yelp=include_yelp,
                include_facebook=include_facebook,
            )
            # Still skip tenant-seen on normal runs
            if tenant_id and raw:
                try:
                    from backend.integrations.prod.continuous_discovery import load_tenant_seen, mark_tenant_seen
                    seen = await load_tenant_seen(tenant_id)
                    before = len(raw)
                    raw = [l for l in raw if l.get("fingerprint") not in seen]
                    await mark_tenant_seen(tenant_id, raw)
                    logger.info("[%s] tenant-seen filter %s → %s", run_id[:8], before, len(raw))
                except Exception as e:
                    logger.debug("tenant-seen filter: %s", e)
    except Exception as e:
        logger.exception("discovery failed")
        await _finish_run(run_id, "failed", {}, str(e))
        return {"error": "discovery_failed", "detail": str(e), "run_id": run_id}

    # Hard cap: never process more than target_new_leads when set
    if target_new_leads and target_new_leads > 0 and raw:
        if len(raw) > target_new_leads:
            logger.info(
                "[%s] trimming discovery %s → %s (target_new_leads)",
                run_id[:8], len(raw), target_new_leads,
            )
            raw = raw[: int(target_new_leads)]

    logger.info("[%s] Discovered %s", run_id[:8], len(raw))
    await _progress_run(
        run_id,
        "running",
        discovered=len(raw),
        meta={"stage": "discovered", "message": f"Found {len(raw)} businesses"},
    )

    # ---------- Stage 1b: Suppression / opt-out BEFORE enrichment (save crawl cost) ----------
    suppressed_n = opt_out_n = 0
    if raw and tenant_id:
        try:
            from backend.integrations.prod.suppression import filter_blocked_leads
            before = len(raw)
            raw, suppressed_n, opt_out_n = await filter_blocked_leads(tenant_id, raw)
            logger.info(
                "[%s] Pre-enrich filter: %s kept, %s suppressed, %s opt-out (from %s)",
                run_id[:8], len(raw), suppressed_n, opt_out_n, before,
            )
            try:
                from backend.integrations.prod.ops_metrics import bump
                if suppressed_n:
                    await bump("suppression_hits", suppressed_n, tenant_id)
                if opt_out_n:
                    await bump("opt_out_hits", opt_out_n, tenant_id)
            except Exception:
                pass
        except Exception as e:
            logger.warning("pre-enrich suppression filter failed: %s", e)

    # ---------- Stage 2: Enrich ----------
    if not skip_enrichment and raw:
        logger.info("[%s] Enriching concurrency=%s", run_id[:8], max_enrich_concurrent)
        raw = await enrich_batch(
            raw,
            max_concurrent=max_enrich_concurrent,
            use_crawl4ai=use_crawl4ai,
            use_firecrawl=use_firecrawl,
        )
        for lead in raw:
            if not lead.get("enrichment_ok") and lead.get("website"):
                await _record_enrich_failure(
                    lead.get("id"), lead.get("website"), lead.get("enrichment_error") or "unknown"
                )

    enriched_n = sum(1 for l in raw if l.get("enrichment_ok"))
    await _progress_run(
        run_id,
        "running",
        discovered=len(raw),
        enriched=enriched_n,
        meta={"stage": "enriched", "message": f"Enriched {enriched_n}/{len(raw)}"},
    )
    try:
        from backend.integrations.prod.ops_metrics import bump
        await bump("leads_discovered", len(raw), tenant_id)
        await bump("leads_enriched_ok", enriched_n, tenant_id)
        fail_n = len(raw) - enriched_n
        if fail_n > 0:
            await bump("leads_enriched_fail", fail_n, tenant_id)
        await bump("pipeline_runs", 1, tenant_id)
    except Exception:
        pass

    # ---------- Stages 2b–6 (always finish run row even on error) ----------
    try:
        # ---------- Stage 2b: Verify + signals + priors + score v3 ----------
        if raw:
            from backend.integrations.prod.pipeline_hooks import post_enrich_prepare
            prepared = []
            for lead in raw:
                if lead.get("_blocked"):
                    prepared.append(lead)
                    continue
                try:
                    lead = await post_enrich_prepare(
                        lead,
                        tenant_id=tenant_id,
                        industry=vertical,
                        html=lead.get("_html") or "",
                        reviews_text=lead.get("_reviews") or None,
                        do_linkedin=False,  # post-gate social_enrich handles LinkedIn
                    )
                except Exception as e:
                    logger.warning("post_enrich_prepare: %s", e)
                    s, t, r = score_lead(lead, vertical)
                    lead["score"], lead["tier"], lead["score_reason"] = s, t, r
                prepared.append(lead)
            raw = prepared

        # ---------- Stage 3–6: Store, gate, social, assign ----------
        stored = gated = assigned = 0
        social_budget = int(__import__('os').environ.get('SOCIAL_ENRICH_MAX_PER_RUN', '25'))
        to_deliver: list[dict] = []
        assignment_ids: list[str] = []
        top: list[dict] = []
        candidates: list[dict] = []

        for lead in raw:
            # Never store/assign suppressed or opted-out leads
            if lead.get("_blocked"):
                continue

            score = int(lead.get("score") or 0)
            tier = lead.get("tier") or "C"
            reasoning = lead.get("score_reason") or ""
            if not lead.get("score") and not lead.get("_blocked"):
                score, tier, reasoning = score_lead(lead, vertical)
                lead["score"], lead["tier"], lead["score_reason"] = score, tier, reasoning

            lead_id = await _upsert_global(lead)
            if not lead_id:
                continue
            lead["id"] = lead_id
            stored += 1

            # Always persist enrichment so pitch/intent/owner/email are not dropped
            await _upsert_enrichment(lead_id, lead)
            await _upsert_score(lead_id, score, tier, reasoning, lead)

            # Operator run board card
            stage0 = "enriched" if lead.get("enrichment_ok") else "discovered"
            await _board_upsert(run_id, lead_id, tenant_id, stage0, lead, position=stored)

            ok, reason = passes_quality_gate(lead, allow_tier_b=allow_tier_b)
            if not ok:
                continue
            gated += 1
            await _board_upsert(run_id, lead_id, tenant_id, "gated", lead, position=gated)
            if gated == 1 or gated % 5 == 0:
                await _progress_run(
                    run_id, "running",
                    discovered=len(raw), enriched=enriched_n, stored=stored,
                    gated_ok=gated, assigned=assigned,
                    meta={"stage": "gating", "message": f"Gated {gated}, stored {stored}"},
                )

            # Post-gate social enrich — capped + hard timeout so run cannot hang
            if social_budget > 0 and (lead.get("tier") or "").upper() in ("A", "B"):
                try:
                    from backend.integrations.prod.social_enrich import social_enrich_lead
                    import asyncio as _aio
                    await _aio.wait_for(social_enrich_lead(lead), timeout=20)
                    social_budget -= 1
                    if lead.get("owner_name") and "owner" not in (lead.get("score_reason") or ""):
                        from backend.integrations.prod.scoring import score_lead_v3
                        s2, t2, r2, _ = score_lead_v3(lead, industry=vertical)
                        lead["score"], lead["tier"], lead["score_reason"] = s2, t2, r2
                        score, tier, reasoning = s2, t2, r2
                        await _upsert_score(lead_id, score, tier, reasoning, lead)
                except Exception as e:
                    logger.warning("social enrich skipped: %s", e)

            candidates.append(lead)

        # ---------- Stage 6b: Rank — high quality, contactable, non-redundant ----------
        if candidates:
            try:
                from backend.integrations.prod.delivery_ranker import rank_for_delivery, diversity_cap
                ranked = rank_for_delivery(
                    candidates,
                    allow_tier_b=allow_tier_b,
                    require_contact="phone_or_email",
                    min_composite=55,
                    max_deliver=remaining if deliver else len(candidates),
                    prefer_multi_source=True,
                )
                ranked = diversity_cap(ranked, max_per_domain=1, max_per_name_prefix=2)
                logger.info(
                    "[%s] ranker: %s gated → %s ranked (contactable + diverse)",
                    run_id[:8], len(candidates), len(ranked),
                )
            except Exception as e:
                logger.warning("ranker failed, using gated order: %s", e)
                ranked = candidates[:remaining] if deliver else candidates
        else:
            ranked = []

        # When deliver=False, still expose ranked top for dry-run inspection
        if not deliver:
            for lead in ranked[:25]:
                top.append({
                    "name": lead.get("name"),
                    "score": lead.get("score"),
                    "tier": lead.get("tier"),
                    "composite": lead.get("composite_quality"),
                    "sources": lead.get("sources_hit"),
                    "phone": lead.get("phone_e164") or lead.get("phone"),
                    "email": lead.get("email"),
                    "pitch": lead.get("pitch_line"),
                    "reason": lead.get("score_reason"),
                })
        for lead in ranked:
            if not deliver:
                break
            if len(to_deliver) >= remaining:
                break
            lead_id = lead.get("id")
            tier = lead.get("tier") or "B"
            score = lead.get("score") or 0
            reasoning = lead.get("score_reason") or ""
            result = await assign_lead(
                lead_id=lead_id,
                tenant_id=tenant_id,
                icp_id=icp_id,
                vertical=vertical,
                geo=geo,
                delivery_channel=delivery_channel,
                tier=tier,
                offer_category=offer_category,
            )
            if result.get("assigned"):
                assigned += 1
                await _board_upsert(run_id, lead_id, tenant_id, "assigned", lead, position=assigned)
                if assigned == 1 or assigned % 5 == 0:
                    await _progress_run(
                        run_id, "running",
                        discovered=len(raw), enriched=enriched_n, stored=stored,
                        gated_ok=gated, assigned=assigned,
                        meta={"stage": "assigning", "message": f"Assigned {assigned}/{gated}"},
                    )
                to_deliver.append(lead)
                # First-touch is MANUAL only (CRM toggle / API) — never auto on every assign
                try:
                    from backend.integrations.prod.ops_metrics import bump
                    await bump("leads_assigned", 1, tenant_id)
                    await bump("leads_gated", 1, tenant_id)
                except Exception:
                    pass
                try:
                    arows = (
                        sb.table("lead_assignments")
                        .select("id")
                        .eq("lead_id", lead_id)
                        .eq("tenant_id", tenant_id)
                        .limit(1)
                        .execute()
                        .data or []
                    )
                    if arows:
                        assignment_ids.append(arows[0]["id"])
                except Exception:
                    pass
                if len(top) < 25:
                    top.append({
                        "name": lead.get("name"),
                        "score": score,
                        "tier": tier,
                        "composite": lead.get("composite_quality"),
                        "sources": lead.get("sources_hit"),
                        "phone": lead.get("phone_e164") or lead.get("phone"),
                        "email": lead.get("email"),
                        "website": lead.get("website"),
                        "booking_platform": lead.get("booking_platform"),
                        "pitch": lead.get("pitch_line"),
                        "reason": reasoning,
                    })

            # ---------- Stage 7: Deliver ----------
        delivered_n = 0
        delivery_result = None
        ch = (delivery_channel or "portal").strip().lower()
        if deliver and to_deliver:
            delivery_result = await deliver_batch(
                to_deliver, delivery_channel, delivery_config, assignment_ids
            )
            if delivery_result and delivery_result.get("ok"):
                delivered_n = int(delivery_result.get("count") or len(to_deliver) or 0)
            # Assigned leads live in CRM for portal/webhook/telegram — always count delivered
            if assigned:
                delivered_n = max(delivered_n, assigned)
                if not delivery_result or not delivery_result.get("ok"):
                    delivery_result = {
                        "ok": True,
                        "channel": ch or "portal",
                        "count": delivered_n,
                        "note": "crm_assigned; external_push_optional",
                    }
                    try:
                        from backend.services.delivery import mark_delivery_status
                        if assignment_ids:
                            await mark_delivery_status(assignment_ids, "sent", None)
                    except Exception as me:
                        logger.warning("mark_delivery_status: %s", me)
        elif assigned:
            delivered_n = assigned
            delivery_result = {"ok": True, "channel": "portal", "count": delivered_n, "note": "assigned_to_crm"}
            try:
                from backend.services.delivery import mark_delivery_status
                if assignment_ids:
                    await mark_delivery_status(assignment_ids, "sent", None)
            except Exception:
                pass

        elapsed = round((datetime.now(timezone.utc) - started).total_seconds(), 1)
        summary = {
            "pipeline": "lead_engine_v2",
            "run_id": run_id,
            "tenant_id": tenant_id,
            "icp_id": icp_id,
            "industry": vertical,
            "locations": geo,
            "discovered": len(raw),
            "stored_global": stored,
            "enriched": enriched_n,
            "passed_quality_gate": gated,
            "assigned_to_tenant": assigned,
            "delivered": delivered_n,
            "delivery": delivery_result,
            "elapsed_seconds": elapsed,
            "top_leads": top,
            "quota_remaining_after": await quota_remaining(tenant_id),
        }

        # completed = pipeline finished cleanly. assigned < gated is normal
        # (exclusivity / quota / tier filter) — not a partial failure.
        status = "completed"
        if stored == 0 and len(raw) == 0:
            status = "failed"
        elif deliver and assigned == 0 and gated > 0:
            status = "partial"  # gated leads but none could be assigned

        # Soft Stripe meter after successful assigns
        if assigned > 0:
            try:
                from backend.integrations.prod.billing_stripe import report_usage_for_period
                await report_usage_for_period(tenant_id)
            except Exception as be:
                logger.warning("stripe usage report skipped: %s", be)

        await _progress_run(
            run_id,
            "running",
            discovered=summary.get("discovered", 0),
            enriched=summary.get("enriched", 0),
            gated_ok=summary.get("passed_quality_gate", 0),
            assigned=summary.get("assigned_to_tenant", 0),
            delivered=summary.get("delivered", 0),
            meta={"stage": "finishing", "message": "Writing final results"},
        )
        await _finish_run(run_id, status, summary)
        logger.info("[%s] done status=%s assigned=%s delivered=%s in %ss",
                    run_id[:8], status, assigned, delivered_n, elapsed)
        summary["duration_ms"] = int((time.perf_counter() - t0) * 1000)
        summary["duration_sec"] = round(summary["duration_ms"] / 1000, 1)
    except Exception as e:
        logger.exception("[%s] pipeline aborted after enrich: %s", run_id[:8], e)
        try:
            await _finish_run(
                run_id,
                "failed",
                {
                    "discovered": len(raw) if isinstance(raw, list) else 0,
                    "enriched": sum(1 for x in (raw or []) if isinstance(x, dict) and x.get("enrichment_ok")),
                    "passed_quality_gate": 0,
                    "assigned_to_tenant": 0,
                    "delivered": 0,
                },
                str(e)[:500],
            )
        except Exception as fe:
            logger.exception("finish after abort failed: %s", fe)
        return {"error": str(e), "run_id": run_id, "status": "failed"}
    return summary




async def _board_upsert(
    run_id: str,
    lead_id: str,
    tenant_id: Optional[str],
    stage: str,
    lead: dict,
    position: int = 0,
) -> None:
    """Write/update a card on the operator run board (pipeline_run_leads)."""
    if not run_id or not lead_id:
        return
    sb = get_supabase()
    row = {
        "run_id": run_id,
        "lead_id": lead_id,
        "tenant_id": tenant_id,
        "stage": stage,
        "tier": (lead.get("tier") or None),
        "included": True,
        "score": int(lead.get("score") or 0) if lead.get("score") is not None else None,
        "source": lead.get("source") or (lead.get("sources") or [None])[0] if isinstance(lead.get("sources"), list) else lead.get("source"),
        "name": lead.get("name") or lead.get("company_name"),
        "phone": lead.get("phone_e164") or lead.get("phone") or lead.get("phone_normalized"),
        "website": lead.get("website"),
        "city": lead.get("city"),
        "position": position,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    # clean source if list weirdness
    if isinstance(row.get("source"), list):
        row["source"] = row["source"][0] if row["source"] else None
    try:
        sb.table("pipeline_run_leads").upsert(row, on_conflict="run_id,lead_id").execute()
    except Exception as e:
        logger.debug("board upsert failed: %s", e)


async def _progress_run(run_id: str, status: str = "running", **counts) -> None:
    """Live counters for admin UI polling (discovered / enriched / gated / assigned / delivered)."""
    if not run_id:
        return
    sb = get_supabase()
    payload = {"status": status}
    for k in ("discovered", "enriched", "gated_ok", "assigned", "delivered", "stored"):
        if k in counts and counts[k] is not None:
            payload[k] = int(counts[k])
    if "meta" in counts and isinstance(counts["meta"], dict):
        payload["meta"] = counts["meta"]
    msg = (
        f"PROGRESS {run_id[:8]} status={status} "
        f"discovered={payload.get('discovered')} enriched={payload.get('enriched')} "
        f"gated={payload.get('gated_ok')} assigned={payload.get('assigned')} "
        f"delivered={payload.get('delivered')} meta={(payload.get('meta') or {}).get('message')}"
    )
    logger.info(msg)
    print(msg, flush=True)
    try:
        sb.table("pipeline_runs").update(payload).eq("id", run_id).execute()
    except Exception as e:
        logger.warning("progress update failed: %s", e)


async def _finish_run(run_id: str, status: str, summary: dict, error: str = "") -> None:
    """Always try to close the run row so UI does not stick on 'running'."""
    if not run_id:
        return
    sb = get_supabase()
    payload = {
        "status": status,
        "discovered": int(summary.get("discovered", 0) or 0),
        "stored": int(summary.get("stored_global", summary.get("stored", 0)) or 0),
        "enriched": int(summary.get("enriched", 0) or 0),
        "gated_ok": int(summary.get("passed_quality_gate", summary.get("gated_ok", 0)) or 0),
        "assigned": int(summary.get("assigned_to_tenant", summary.get("assigned", 0)) or 0),
        "delivered": int(summary.get("delivered", 0) or 0),
        "error_message": (error or None),
        "meta": {k: summary.get(k) for k in ("industry", "locations", "top_leads", "stage", "message") if summary.get(k) is not None},
        "finished_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        sb.table("pipeline_runs").update(payload).eq("id", run_id).execute()
        logger.info("FINISH run_id=%s status=%s gated=%s assigned=%s", run_id[:8], status, payload["gated_ok"], payload["assigned"])
        print(f"FINISH run_id={run_id} status={status}", flush=True)
    except Exception as e:
        logger.exception("CRITICAL finish_run failed for %s: %s", run_id, e)
        try:
            sb.table("pipeline_runs").update({
                "status": status if status in ("completed", "partial", "failed") else "failed",
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "error_message": (error or str(e))[:500],
            }).eq("id", run_id).execute()
        except Exception as e2:
            logger.exception("finish_run fallback also failed: %s", e2)


async def run_all_active_icps(
    limit_per_location: int = 40,
    skip_enrichment: bool = False,
    max_enrich_concurrent: int = 3,
) -> list[dict]:
    """Cron entry: every active ICP for every active tenant."""
    sb = get_supabase()
    icps = (
        sb.table("icp_profiles")
        .select("id, tenant_id, vertical, geo, keywords, tenants!inner(status)")
        .eq("active", True)
        .execute()
        .data or []
    )
    # Filter active tenants
    active = []
    for icp in icps:
        t = icp.get("tenants") or {}
        if isinstance(t, dict) and t.get("status") == "active":
            active.append(icp)
        elif not t:
            # join may not expand — check separately
            active.append(icp)

    results = []
    for icp in active:
        try:
            r = await run_pipeline(
                tenant_id=icp["tenant_id"],
                icp_id=icp["id"],
                industry=icp.get("vertical") or "medspa",
                locations=icp.get("geo") or [],
                queries=icp.get("keywords") or None,
                limit_per_location=limit_per_location,
                skip_enrichment=skip_enrichment,
                max_enrich_concurrent=max_enrich_concurrent,
            )
            results.append(r)
        except Exception as e:
            logger.exception("ICP %s failed", icp.get("id"))
            results.append({"icp_id": icp.get("id"), "error": str(e)})
        await asyncio.sleep(1.5)

    # Auto-refresh vertical priors so new tenants inherit improved weights
    try:
        from backend.integrations.prod.priors import refresh_vertical_priors
        verticals = {((icp.get("vertical") or "medspa").lower()) for icp in active}
        for v in verticals:
            await refresh_vertical_priors(v)
            logger.info("Refreshed vertical priors for %s", v)
    except Exception as e:
        logger.warning("prior refresh on cron failed: %s", e)

    return results
