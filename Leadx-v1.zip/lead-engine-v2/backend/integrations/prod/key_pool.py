"""
Production API Key Pool — rotation, cooldown, error tracking, env fallback.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone, timedelta
from typing import Callable, Awaitable, TypeVar

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.key_pool")
T = TypeVar("T")

ENV_FALLBACK = {
    "serper": "SERPER_API_KEY",
    "firecrawl": "FIRECRAWL_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GOOGLE_API_KEY",
    "groq": "GROQ_API_KEY",
    "openai": "OPENAI_API_KEY",
    "resend": "RESEND_API_KEY",
    "linkedin_scraper": "LINKEDIN_LI_AT",
}

QUOTA_MARKERS = (
    "402", "429", "quota", "rate limit", "rate_limit",
    "insufficient", "credit", "exceeded", "too many requests",
)


class KeyPoolExhausted(Exception):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def get_active_key(provider: str) -> tuple[str, str | None]:
    """Return (key_value, key_id). Reactivates cooled keys. Env fallback."""
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "active",
            "updated_at": _now().isoformat(),
        }).eq("provider", provider).eq("status", "cooling").lte(
            "cooldown_until", _now().isoformat()
        ).execute()

        r = (
            sb.table("api_key_pool")
            .select("id, key_value")
            .eq("provider", provider)
            .eq("status", "active")
            .order("last_used_at", desc=False, nullsfirst=True)
            .limit(1)
            .execute()
        )
        if r.data:
            row = r.data[0]
            sb.table("api_key_pool").update({
                "last_used_at": _now().isoformat(),
            }).eq("id", row["id"]).execute()
            return row["key_value"], row["id"]
    except Exception as e:
        logger.warning("key_pool query failed for %s: %s", provider, e)

    env_name = ENV_FALLBACK.get(provider, "")
    env_key = os.getenv(env_name, "") if env_name else ""
    if env_key:
        return env_key, None
    raise KeyPoolExhausted(f"No active keys for provider={provider}")


async def mark_quota_error(provider: str, key_value: str, error: str, cooldown_minutes: int = 30) -> None:
    sb = get_supabase()
    try:
        rows = (
            sb.table("api_key_pool")
            .select("id, error_count")
            .eq("provider", provider)
            .eq("key_value", key_value)
            .limit(1)
            .execute()
            .data or []
        )
        payload = {
            "status": "cooling",
            "cooldown_until": (_now() + timedelta(minutes=cooldown_minutes)).isoformat(),
            "last_error": str(error)[:500],
            "updated_at": _now().isoformat(),
        }
        if rows:
            payload["error_count"] = (rows[0].get("error_count") or 0) + 1
            # After many errors, mark exhausted permanently
            if payload["error_count"] >= 10:
                payload["status"] = "exhausted"
            sb.table("api_key_pool").update(payload).eq("id", rows[0]["id"]).execute()
        else:
            sb.table("api_key_pool").update(payload).eq("provider", provider).eq("key_value", key_value).execute()
    except Exception as e:
        logger.warning("mark_quota_error failed: %s", e)


async def mark_exhausted(provider: str, key_value: str, error: str = "") -> None:
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "exhausted",
            "last_error": str(error)[:500],
            "updated_at": _now().isoformat(),
        }).eq("provider", provider).eq("key_value", key_value).execute()
    except Exception as e:
        logger.warning("mark_exhausted failed: %s", e)


async def mark_provider_exhausted(provider: str, error: str = "") -> None:
    """Mark all active keys for a provider exhausted (e.g. LinkedIn cookie expiry)."""
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "exhausted",
            "last_error": str(error)[:500],
            "updated_at": _now().isoformat(),
        }).eq("provider", provider).eq("status", "active").execute()
    except Exception as e:
        logger.warning("mark_provider_exhausted failed: %s", e)


async def increment_usage(provider: str, key_value: str, amount: int = 1) -> None:
    sb = get_supabase()
    try:
        rows = (
            sb.table("api_key_pool")
            .select("id, credits_used, credits_limit")
            .eq("provider", provider)
            .eq("key_value", key_value)
            .limit(1)
            .execute()
            .data or []
        )
        if not rows:
            return
        row = rows[0]
        used = (row.get("credits_used") or 0) + amount
        updates: dict = {"credits_used": used, "last_used_at": _now().isoformat()}
        limit = row.get("credits_limit")
        if limit and used >= limit:
            updates["status"] = "exhausted"
            logger.info("Key %s/%s hit credits_limit=%s", provider, key_value[:8], limit)
        sb.table("api_key_pool").update(updates).eq("id", row["id"]).execute()
    except Exception as e:
        logger.warning("increment_usage failed: %s", e)


def _is_quota_error(exc: Exception) -> bool:
    s = str(exc).lower()
    return any(m in s for m in QUOTA_MARKERS)


async def with_key_rotation(
    provider: str,
    call_fn: Callable[[str], Awaitable[T]],
    max_retries: int = 6,
    cooldown_minutes: int = 30,
) -> T:
    tried: set[str] = set()
    last_err: Exception | None = None

    for attempt in range(max_retries):
        try:
            key, _ = await get_active_key(provider)
        except KeyPoolExhausted as e:
            last_err = e
            break

        if key in tried:
            break
        tried.add(key)

        try:
            result = await call_fn(key)
            await increment_usage(provider, key)
            return result
        except Exception as e:
            last_err = e
            if _is_quota_error(e):
                logger.warning("Quota on %s key=%s… attempt=%s: %s", provider, key[:8], attempt + 1, e)
                await mark_quota_error(provider, key, str(e), cooldown_minutes)
                continue
            raise

    raise KeyPoolExhausted(f"All keys exhausted for {provider} after {len(tried)} tries: {last_err}")


async def with_linkedin_cookie(call_fn: Callable[[str], Awaitable[T]]) -> T:
    """
    LinkedIn is a single-account cookie, not a rotatable pool of trial
    keys like Serper/Firecrawl — set once as an env var and forget it,
    rather than re-pasting it into the admin panel after every deploy.

    Checks LINKEDIN_LI_AT_COOKIE first; only falls back to the
    api_key_pool (provider=linkedin_scraper) rotation if the env var
    isn't set, so the admin-panel path still works for anyone who
    prefers it or wants to rotate between multiple LinkedIn accounts.
    """
    env_cookie = (os.getenv("LINKEDIN_LI_AT_COOKIE") or os.getenv("LINKEDIN_LI_AT") or "").strip() or None
    if env_cookie:
        try:
            return await call_fn(env_cookie)
        except PermissionError:
            logger.warning(
                "LinkedIn cookie from LINKEDIN_LI_AT_COOKIE env var was rejected (401/403) — "
                "it's likely expired. Update the env var and redeploy; this path does not "
                "fall back to the database pool once the env var is set."
            )
            raise
    return await with_key_rotation("linkedin_scraper", call_fn)


async def add_key(
    provider: str,
    key_value: str,
    label: str | None = None,
    credits_limit: int | None = None,
    notes: str | None = None,
) -> dict:
    """Insert or reactivate a key in api_key_pool. Safe for LinkedIn li_at cookies."""
    sb = get_supabase()
    provider = (provider or "").strip().lower()
    key_value = (key_value or "").strip()
    if not provider or not key_value:
        return {"ok": False, "error": "provider and key_value required"}

    row = {
        "provider": provider,
        "key_value": key_value,
        "label": label or provider,
        "status": "active",
        "credits_used": 0,
        "credits_limit": credits_limit,
        "last_error": None,
        "cooldown_until": None,
        "updated_at": _now().isoformat(),
    }
    if notes:
        row["notes"] = notes

    try:
        existing = (
            sb.table("api_key_pool")
            .select("id")
            .eq("provider", provider)
            .eq("key_value", key_value)
            .limit(1)
            .execute()
            .data
            or []
        )
        if existing:
            sb.table("api_key_pool").update({
                "status": "active",
                "label": row["label"],
                "credits_limit": credits_limit,
                "last_error": None,
                "cooldown_until": None,
                "updated_at": row["updated_at"],
            }).eq("id", existing[0]["id"]).execute()
            return {
                "ok": True,
                "id": existing[0]["id"],
                "provider": provider,
                "status": "active",
                "updated": True,
                "message": "Key reactivated",
            }

        ins = sb.table("api_key_pool").insert(row).execute()
        new_id = (ins.data or [{}])[0].get("id")
        return {
            "ok": True,
            "id": new_id,
            "provider": provider,
            "status": "active",
            "created": True,
            "message": "Key added",
        }
    except Exception as e:
        logger.exception("add_key failed")
        # Env fallback note for linkedin
        if provider == "linkedin_scraper":
            return {
                "ok": False,
                "error": str(e),
                "hint": "Ensure api_key_pool table exists. Or set LINKEDIN_LI_AT=your_li_at_cookie in lead-engine-v2/.env",
            }
        return {"ok": False, "error": str(e)}


async def pool_health() -> dict:
    sb = get_supabase()
    out: dict = {"providers": {}, "ok": True}
    try:
        rows = (
            sb.table("api_key_pool")
            .select("provider, status")
            .limit(500)
            .execute()
            .data
            or []
        )
        for r in rows:
            p = r.get("provider") or "?"
            st = r.get("status") or "?"
            bucket = out["providers"].setdefault(p, {"active": 0, "cooling": 0, "exhausted": 0, "other": 0})
            if st in bucket:
                bucket[st] += 1
            else:
                bucket["other"] += 1
    except Exception as e:
        out["ok"] = False
        out["error"] = str(e)
    # Env fallbacks present?
    out["env_fallback"] = {
        k: bool(os.getenv(v)) for k, v in ENV_FALLBACK.items()
    }
    # LinkedIn: runtime accepts LINKEDIN_LI_AT_COOKIE (preferred) or LINKEDIN_LI_AT
    li_cookie = bool(
        (os.getenv("LINKEDIN_LI_AT_COOKIE") or "").strip()
        or (os.getenv("LINKEDIN_LI_AT") or "").strip()
    )
    out["env_fallback"]["linkedin_scraper"] = li_cookie
    out["env_fallback"]["linkedin_scraper_url"] = bool((os.getenv("LINKEDIN_SCRAPER_URL") or "").strip())
    return out
