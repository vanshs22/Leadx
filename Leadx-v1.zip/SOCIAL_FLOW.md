# Enrichment flow (updated)

## Order
1. **Discover** — multi-source (Maps, Web, Yelp, FB, LinkedIn, Instagram)
2. **Enrich (single stage)**
   - Website: Scrapling → Crawl4AI → Firecrawl
   - **Social (all leads, capped):**
     - LinkedIn: **scraper first** → Serper if scraper fails
     - Instagram: **instaloader first** (handle from site/discovery)
   - Social can fill: owner, linkedin_url, instagram, website
3. **Score + gate** — social URL counts as contactable
4. **Assign / deliver**

## Env
```bash
SERPER_API_KEY=...
LINKEDIN_SCRAPER_URL=http://127.0.0.1:8001
LINKEDIN_LI_AT_COOKIE=...
INSTAGRAM_USERNAME=...
INSTAGRAM_PASSWORD=...
SOCIAL_ENRICH_MAX_PER_RUN=40
```
