UPDATE public.lead_assignments
SET delivery_status = 'sent'
WHERE lower(coalesce(delivery_status, '')) = 'failed';

UPDATE public.tenants
SET delivery_channel = 'portal'
WHERE coalesce(delivery_channel, '') IN ('', 'telegram')
  AND (delivery_config IS NULL OR delivery_config::text IN ('{}', 'null', ''));

UPDATE public.pipeline_runs
SET delivered = GREATEST(COALESCE(delivered, 0), COALESCE(assigned, 0))
WHERE COALESCE(delivered, 0) = 0
  AND COALESCE(assigned, 0) > 0
  AND status IN ('completed', 'partial');
