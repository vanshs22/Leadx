# Instagram (instaloader) + LinkedIn scraper

## Instagram — fix 403 login_required

Hashtag discovery **requires** a logged-in Instagram session.

In `lead-engine-v2/.env`:

```bash
INSTAGRAM_USERNAME=your_ig_username
INSTAGRAM_PASSWORD=your_ig_password
INSTAGRAM_SESSION_FILE=/tmp/leadx_instagram_session
```

1. Restart API after setting env.
2. First run logs in and saves session file.
3. Later runs reuse the session (fewer challenges).

If Instagram shows checkpoint/2FA, log in once in a browser on the same account, complete challenge, then retry.

**Security:** do not commit passwords; rotate if exposed.

## LinkedIn scraper — fix SSL WRONG_VERSION_NUMBER

Scraper speaks **HTTP only**:

```bash
LINKEDIN_SCRAPER_URL=http://127.0.0.1:8001
# never https://127.0.0.1:8001
```

Start the scraper (from project root):

```bash
# if docker compose profile exists:
docker compose --profile social up -d linkedin-scraper
# or manual uvicorn in services/linkedin-scraper
```

Cookie:

```bash
LINKEDIN_LI_AT_COOKIE=your_li_at_value
```

Also add to Admin → API keys as provider `linkedin_scraper`.

Health:

```bash
curl -s http://127.0.0.1:8001/health
```

## Verify

Logs should show:

```text
instagram logged in as …
instagram session loaded for …
instaloader discovery […] → N   # N > 0 when tags exist
```

Not:

```text
403 login_required
SSL: WRONG_VERSION_NUMBER
```
