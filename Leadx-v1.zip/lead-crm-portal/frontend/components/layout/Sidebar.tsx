"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { getTenantName, clearTenant } from "@/lib/tenant";
import { signOut } from "@/lib/auth";

const NAV = [
  { href: "/dashboard", label: "Home", hint: "Overview & next steps" },
  // Search disabled for clients — admin delivers leads; re-enable later if needed
  // { href: "/search", label: "Search", hint: "Find leads → email" },
  { href: "/leads", label: "Leads", hint: "Call, email, export" },
  { href: "/sequences", label: "Sequences", hint: "Follow-up automation" },
  { href: "/replies", label: "Replies", hint: "Inbound, categorized" },
  { href: "/pipeline", label: "Pipeline", hint: "Stages & deals" },
  { href: "/activities", label: "Activity", hint: "Calls & notes" },
  { href: "/reports", label: "Reports", hint: "Wins & quality" },
  { href: "/team", label: "Team", hint: "Members & roles" },
  { href: "/docs", label: "Docs", hint: "Contracts & invoices" },
  { href: "/settings/email", label: "Email", hint: "Domain & bulk send" },
  { href: "/settings", label: "Settings", hint: "Account & weights" },
];

export function Sidebar() {
  const path = usePathname();
  const router = useRouter();

  async function handleSignOut() {
    try {
      clearTenant();
      await signOut();
    } catch {
      /* still leave */
    }
    router.replace("/login");
    // hard navigation clears any stuck client state
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
  }

  return (
    <aside className="flex h-full min-h-0 w-60 shrink-0 flex-col overflow-hidden border-r border-[rgb(var(--sidebar-border))] bg-[rgb(var(--sidebar))]">
      <div className="shrink-0 border-b border-line px-4 py-5">
        <div className="text-sm font-semibold tracking-tight text-ink">Lead CRM</div>
        <div className="mt-0.5 text-xs text-ink-faint">
          {typeof window !== "undefined" ? getTenantName() || "Workspace" : "Workspace"}
        </div>
      </div>

      <nav className="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto overscroll-contain p-3">
        {NAV.map((item) => {
          const active = path === item.href || path?.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={active ? "sidebar-link-active" : "sidebar-link"}
            >
              <div>
                <div>{item.label}</div>
                {item.hint ? (
                  <div className="text-[11px] font-normal text-ink-faint">{item.hint}</div>
                ) : null}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto space-y-3 shrink-0 border-t border-line p-3">
        <ThemeToggle className="w-full" />
        <div className="rounded-xl border border-line bg-surface-3/60 p-3 text-[11px] leading-relaxed text-ink-muted">
          New batches land here automatically. Filter <strong className="text-ink">Tier A</strong> first.
        </div>
        <button
          type="button"
          onClick={handleSignOut}
          className="w-full rounded-lg border border-line bg-surface px-3 py-2 text-left text-sm font-medium text-ink hover:bg-surface-2 hover:border-red-500/40 hover:text-red-600 dark:hover:text-red-400"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
