#!/usr/bin/env bash
# Run LinkedIn + Instagram checks only (no full pipeline).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -f lead-engine-v2/.venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source lead-engine-v2/.venv/bin/activate
elif [[ -f .venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

export PYTHONPATH="${ROOT}/lead-engine-v2:${PYTHONPATH:-}"
if [[ -d lead-engine-v2/backend ]]; then
  export PYTHONPATH="${ROOT}/lead-engine-v2:${PYTHONPATH}"
fi

echo "Running scripts/test_linkedin_instagram.py ..."
python3 scripts/test_linkedin_instagram.py
