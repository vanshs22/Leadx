#!/usr/bin/env bash
# Run LinkedIn + Instagram checks only (no full pipeline).
set -euo pipefail

# Script lives at repo root OR in scripts/ — resolve repo root correctly
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "$SCRIPT_DIR/scripts/test_linkedin_instagram.py" ]]; then
  ROOT="$SCRIPT_DIR"
elif [[ -f "$SCRIPT_DIR/test_linkedin_instagram.py" ]]; then
  ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
else
  echo "ERROR: cannot find test_linkedin_instagram.py near $SCRIPT_DIR"
  exit 2
fi
cd "$ROOT"
echo "Repo root: $ROOT"

if [[ -f lead-engine-v2/.venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source lead-engine-v2/.venv/bin/activate
elif [[ -f .venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

export PYTHONPATH="${ROOT}/lead-engine-v2:${PYTHONPATH:-}"

PY="$ROOT/scripts/test_linkedin_instagram.py"
if [[ ! -f "$PY" ]]; then
  PY="$ROOT/lead-engine-v2/scripts/test_linkedin_instagram.py"
fi
if [[ ! -f "$PY" ]]; then
  echo "ERROR: missing $PY"
  exit 2
fi

echo "Running $PY ..."
python3 "$PY"
