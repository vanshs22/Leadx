#!/usr/bin/env bash
# LeadX LinkedIn + Instagram connection test
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
# if script lives in scripts/, go up
if [[ "$(basename "$ROOT")" == "scripts" ]]; then
  ROOT="$(cd "$ROOT/.." && pwd)"
fi
cd "$ROOT"
echo "Repo root: $ROOT"

PY="$ROOT/scripts/test_linkedin_instagram.py"
if [[ ! -f "$PY" ]]; then
  PY="$ROOT/lead-engine-v2/scripts/test_linkedin_instagram.py"
fi
if [[ ! -f "$PY" ]]; then
  echo "ERROR: test_linkedin_instagram.py not found under $ROOT"
  exit 1
fi

export PYTHONPATH="${ROOT}/lead-engine-v2:${PYTHONPATH:-}"

if [[ -f "${ROOT}/lead-engine-v2/.venv/bin/activate" ]]; then
  # shellcheck disable=SC1091
  source "${ROOT}/lead-engine-v2/.venv/bin/activate"
fi

echo "Running $PY $*"
exec python3 "$PY" "$@"
