# LinkedIn + Instagram connection debug

## Run test
```bash
cd /workspaces/Leadx
chmod +x test_social.sh
./test_social.sh
./test_social.sh --clear-ig-session    # after Instagram checkpoint
./test_social.sh --skip-instagram      # LinkedIn only
./test_social.sh --skip-linkedin       # Instagram only
```

## LinkedIn
```bash
# .env
LINKEDIN_SCRAPER_URL=http://127.0.0.1:8001
LINKEDIN_LI_AT_COOKIE=<full li_at 100+ chars>

docker compose --profile social up -d linkedin-scraper
curl -s http://127.0.0.1:8001/health
docker logs lead-engine-v2-linkedin-scraper-1 2>&1 | tail -50
docker update --memory=1g lead-engine-v2-linkedin-scraper-1
docker restart lead-engine-v2-linkedin-scraper-1
```

## Instagram
```bash
INSTAGRAM_USERNAME=...
INSTAGRAM_PASSWORD=...
INSTAGRAM_SESSION_FILE=/tmp/leadx_instagram_session

# After "This was me" on phone:
rm -f /tmp/leadx_instagram_session*
./test_social.sh --clear-ig-session
# If 429: wait 30–60 min, do not spam
```

Pipeline still works with Serper LinkedIn if the scraper Chrome fails.
