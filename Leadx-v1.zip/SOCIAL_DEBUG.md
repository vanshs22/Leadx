# LinkedIn + Instagram — fix from your latest logs

## LinkedIn (Chrome crash)

Logs mean:
- `Connection refused` → scraper container was not running
- `invalid session id / not connected to DevTools` → Chrome died (`single_process: true` on old image)
- docker memory error → set memory and memory-swap together

### Rebuild (required)

```bash
cd /workspaces/Leadx
unzip -o leadx-saas-latest.zip   # keep .env

cd lead-engine-v2
docker compose --profile social up -d --build --force-recreate linkedin-scraper

curl -s http://127.0.0.1:8001/health
# want: "single_process": false

cd /workspaces/Leadx
./test_social.sh --skip-instagram
```

If still 500:

```bash
docker logs lead-engine-v2-linkedin-scraper-1 2>&1 | tail -60
docker update --memory=1g --memory-swap=1g lead-engine-v2-linkedin-scraper-1
docker restart lead-engine-v2-linkedin-scraper-1
```

Without deep scraper, pipeline still uses **Serper LinkedIn**.

## Instagram (checkpoint + 429)

**Stop running the test** until rate limit clears (30–60+ minutes).

1. Phone: Instagram → approve any "this was me"
2. Optional: open `https://www.instagram.com` + the `/auth_platform/?apc=...` path from the error while logged in
3. Wait, then once:

```bash
rm -f /tmp/leadx_instagram_session*
./test_social.sh --clear-ig-session --skip-linkedin
```

If Codespace IP keeps getting checkpoint, use Serper for IG discovery and skip Instaloader until you login from a normal network.
