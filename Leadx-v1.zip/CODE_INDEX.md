# LeadX code index (find issues fast)

## Pipeline / discovery
| What | File | Key symbols |
|------|------|-------------|
| Multi-source discovery (Maps+web+LI+IG…) | `lead-engine-v2/backend/integrations/prod/multi_source_discovery.py` | `_serper_search`, `_serper_maps`, `source_web`, `source_yelp`, `discover_multi_source` |
| Maps-only discovery | `.../prod/discovery.py` | `_serper_maps_page`, `search_maps_paginated` |
| Full pipeline | `.../prod/pipeline.py` | `run_pipeline`, `_upsert_enrichment`, `_finish_run` |
| Continuous / statewide | `.../prod/continuous_discovery.py` | geo cells, `target_new_leads` |

## Enrich / social
| What | File | Key symbols |
|------|------|-------------|
| Website enrich cascade | `.../prod/enricher.py` | Scrapling → Crawl4AI → Firecrawl |
| Why-now / signals | `.../prod/signals.py` | `why_now_labels`, booking platforms |
| LinkedIn + IG enrich | `.../prod/social_enrich.py` | post-gate social |
| LinkedIn/IG discovery | `.../prod/social_discovery.py` | Serper site: + instaloader |
| Scoring | `.../prod/scoring.py` / `quality.py` | `score_lead_v3`, gate |

## Delivery / CRM
| What | File | Key symbols |
|------|------|-------------|
| Assign + deliver | `.../prod/delivery.py` | `assign_lead`, portal/telegram |
| Operator API | `.../api/prod/leads_api.py` | `/pipeline/run`, `/admin/*` |
| Client CRM API | `.../crm/crm_api.py` (or backend/crm) | `/crm/{tenant}/…` |
| Board cards | pipeline + `pipeline_run_leads` table | `_board_upsert` |

## Email / SES / docs
| What | File | Key symbols |
|------|------|-------------|
| Outreach send | `.../prod/email_outreach.py` | `send_to_lead`, `send_for_tenant` |
| SES send | `.../prod/ses_domain.py` | `send_via_ses` |
| Inbound replies | `.../prod/inbound_email.py` | SES SNS webhook |
| Sequences | `.../prod/sequences.py` | enroll, process_due |
| Doc templates | `.../prod/doc_templates.py` | `render_doc`, `list_templates` |
| Template SQL upgrade | `FIX_professional_doc_templates.sql` | UPDATE body_html |

## Auth / keys
| What | File | Key symbols |
|------|------|-------------|
| Supabase client | `lead-engine-v2/backend/memory/supabase_client.py` | `get_supabase` |
| API key pool | `.../prod/key_pool.py` | `with_key_rotation`, `add_key` |
| Service key auth | middleware / leads_api | `LEAD_ENGINE_SERVICE_KEY` |

## Frontend
| What | Path |
|------|------|
| Client docs/templates UI | `lead-crm-portal/frontend/app/(portal)/docs/page.tsx` |
| Admin pipeline | `.../app/(admin)/admin/pipeline/page.tsx` |
| Admin client leads | `.../app/(admin)/admin/leads/[tenantId]/page.tsx` |
| API client | `lead-crm-portal/frontend/lib/api.ts`, `admin.ts` |

## Serper 400 checklist
1. Empty `q` → skip (fixed in `_serper_search` / `_serper_maps`)
2. `"ll": null` on maps → **400** (removed; do not send null ll)
3. Invalid `num` → clamp 1–10 search, 1–20 maps
4. Bad/expired key → 401/403 (not 400); check Admin → API keys + `SERPER_API_KEY`
