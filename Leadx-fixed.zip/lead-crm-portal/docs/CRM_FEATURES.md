# Client CRM Portal — Full Feature Map

Each client (agency or business) gets a **private dashboard** showing only *their* leads, pipeline, and activity.  
This is the product surface you sell on top of the Lead Engine.

---

## What the client sees (journey)

```
Login → Dashboard (KPIs)
      → Leads table (search / filter / export)
      → Pipeline board (Kanban by stage)
      → Lead detail (enrichment + timeline + tasks)
      → Reports (conversion, quality mix)
      → Settings (delivery, team, stages)
```

**Lead lifecycle states they manage:**

| Stage | Meaning |
|-------|---------|
| **New** | Just delivered, not touched |
| **Contacted** | Called / emailed / SMS sent |
| **Qualified** | Confirmed fit / interest |
| **Proposal** | Offer sent |
| **Negotiation** | Discussing terms |
| **Won** | Closed customer |
| **Lost** | Dead / rejected |

Every stage change is logged on the activity timeline.

---

## Feature list — Beginner → Advanced

### Beginner (day-one usable)

| Feature | Where | Why it matters |
|---------|--------|----------------|
| KPI dashboard | `/dashboard` | Total leads, Tier A count, win rate, quota used |
| Lead list | `/leads` | Search by company, filter by tier/stage |
| Contact fields | Lead detail | Phone, email, website, address one click away |
| Tier + score badges | Everywhere | Instantly see best leads |
| Pipeline stages | `/pipeline` | Visual board of where every lead sits |
| Move stage | Lead detail | Click to mark Contacted → Qualified → Won |
| Add note | Lead detail | Log what happened on a call |
| Log call | Lead detail | One-click “I called them” |
| Export CSV | Leads page | Download for Excel / their own tools |
| Monthly quota meter | Dashboard | Know how many leads left this month |

### Intermediate (daily power use)

| Feature | Where | Why |
|---------|--------|-----|
| Activity timeline | Lead detail | Full history: notes, calls, stage changes |
| Tasks & due dates | Lead detail + Dashboard | Follow-ups don’t fall through cracks |
| Priority (low→urgent) | Lead update | Focus the day |
| Tags | Lead fields | Segment e.g. “no website”, “high reviews” |
| Enrichment panel | Lead detail | Booking platform, services, owner name, score reason |
| Bulk select | Leads table | Multi-select for bulk stage moves |
| Funnel chart | Dashboard | See drop-off New → Won |
| Tasks due widget | Dashboard | Today’s work queue |
| Filters (stage, tier, assignee) | Leads | Slice the book of business |
| Reports summary | `/reports` | Email coverage %, avg score, stage mix |

### Advanced (agency / multi-user)

| Feature | Schema / API | Why |
|---------|--------------|-----|
| Team members & roles | `tenant_members` | Owner / admin / member / viewer |
| Assign lead to teammate | `assigned_to` | SDR ownership |
| Custom pipeline stages | `pipeline_stages` | Match their sales process |
| Saved segments | `lead_segments` | Reusable filters (“Tier A + no booking”) |
| Custom fields | `custom_fields` jsonb | Extra data per vertical |
| Value estimate | `value_estimate` | Pipeline $ forecasting |
| Next action date | `next_action_at` | Calendar-style follow-up |
| Audit log | `crm_audit_log` | Who changed what |
| Delivery channel config | tenant `delivery_config` | Telegram / webhook / email |
| Webhook into GHL/HubSpot | Delivery service | Sync to their existing CRM |
| Usage / billing view | `usage_log` | Transparent consumption |
| Quality gate transparency | Score reasoning | Why this lead is Tier A |
| Exclusivity awareness | Assignment rules | They know territory is locked |

---

## Pages in the portal

| Route | Purpose |
|-------|---------|
| `/dashboard` | KPIs, funnel, quota, tasks due, recent activity |
| `/leads` | Searchable table + filters + CSV export |
| `/leads/[id]` | Full lead card, enrichment, timeline, tasks, stage moves |
| `/pipeline` | Kanban by stage |
| `/activities` | Cross-lead task list (extend from tasks API) |
| `/reports` | Conversion & quality analytics |
| `/settings` | Stages seed, delivery channel, team invites |
| `/team` | Members & roles (uses `tenant_members`) |

---

## Data the client never sees (your edge)

- Other tenants’ leads  
- Global pool before quality gate  
- Raw Serper / scraper internals  
- Key pool / your costs  

They only see **assigned, gated, enriched** leads that passed exclusivity.

---

## How this ties to what you sell

1. **Lead Engine** produces and assigns leads (backend job).  
2. **CRM Portal** is how the client **works** those leads day to day.  
3. You charge for **volume + exclusivity + access to this portal**.

Pitch line:

> “We don’t just send you a CSV. You get a private CRM where every lead is scored, enriched, and tracked from first touch to closed deal.”

---

## Tech stack (portal)

| Layer | Choice |
|-------|--------|
| Framework | **Next.js 14** (App Router) |
| UI | React + Tailwind (dark CRM aesthetic) |
| API | FastAPI `/crm/{tenant_id}/...` |
| Auth (prod) | Supabase Auth — map `auth.users` → `tenant_members` |
| Data | Same Supabase DB as Lead Engine |

---

## Install order

1. Run `sql/003_crm_portal_schema.sql`  
2. Mount `backend/crm_api.py` router on FastAPI  
3. Copy `frontend/` into Next.js app (or new app under `/portal`)  
4. Set `NEXT_PUBLIC_API_URL` + `NEXT_PUBLIC_TENANT_ID` (or resolve tenant from session)  
5. Call `POST /crm/{tenant_id}/setup` once to seed stages  
6. Client logs in → only their `lead_assignments` appear  

---

## Roadmap after MVP (optional)

- Drag-and-drop Kanban (react-beautiful-dnd / dnd-kit)  
- Email open/click tracking if you send via Resend  
- Built-in dialer / click-to-call  
- AI “suggested next action” on each lead  
- White-label domain per agency client  
- Mobile-responsive PWA  

The files in this package already cover **beginner → advanced CRM** for selling and operating quality leads end-to-end.
