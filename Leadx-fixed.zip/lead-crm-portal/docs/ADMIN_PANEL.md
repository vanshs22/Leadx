# Operator Admin Panel

URL: `/admin/login` → enter `LEAD_ENGINE_SERVICE_KEY` → `/admin`

## Features
- **Overview** — global counts, API health, 7-day ops
- **Clients** — create/list tenants, plan, quota, pause/activate, Stripe link, invites
- **ICPs** — vertical + geo per client, exclusivity, toggle active
- **Pipeline** — run for one client or all ICPs
- **Run history** — discovered / enriched / gated / assigned / delivered
- **API keys** — add Serper/Firecrawl/Resend/LinkedIn, health status
- **Usage & billing** — period usage, report all to Stripe
- **Suppression** — CSV upload per client + global opt-out
- **Ops health** — metrics, priors refresh, key pool

## Env (frontend)
```
NEXT_PUBLIC_API_URL=http://localhost:8000
# optional default key (prefer typing at login)
NEXT_PUBLIC_SERVICE_KEY=
```

## Security
Admin uses the same service key as n8n/cron. Do not expose the admin UI publicly without VPN or IP allowlist.
