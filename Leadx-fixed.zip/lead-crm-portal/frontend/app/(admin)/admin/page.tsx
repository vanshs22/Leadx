"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { admin } from "@/lib/admin";

export default function AdminOverviewPage() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    admin
      .tenants()
      .then((d: any) => setTenants(d.tenants || d || []))
      .catch((e) => setErr(e.message));
  }, []);

  const actions = [
    { href: "/admin/pipeline", title: "Run pipeline", desc: "Discover → enrich → deliver for a client ICP" },
    { href: "/admin/intelligence", title: "Intelligence", desc: "Sample packs, QA accuracy, territories, bad leads" },
    { href: "/admin/tenants", title: "Clients", desc: "Quotas, branding, delivery channels" },
    { href: "/admin/icps", title: "ICPs", desc: "Vertical + geo + offer category targets" },
    { href: "/admin/keys", title: "API keys", desc: "Serper / crawl pools & cooldowns" },
    { href: "/admin/ops", title: "Ops health", desc: "Enrichment success, suppression, failures" },
  ];

  return (
    <div className="page">
      <header>
        <h1 className="page-title">Operator console</h1>
        <p className="page-sub">Run the service, protect quality, keep clients supplied</p>
      </header>
      {err && <p className="text-sm text-red-600 dark:text-red-300">{err}</p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {actions.map((a) => (
          <Link key={a.href} href={a.href} className="card-pad transition hover:shadow-lift hover:border-amber-300 dark:hover:border-amber-500/40">
            <div className="text-base font-semibold text-ink">{a.title}</div>
            <p className="mt-2 text-sm text-ink-muted">{a.desc}</p>
          </Link>
        ))}
      </div>
      <div className="card-pad">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-ink">Clients</h2>
          <Link href="/admin/tenants" className="text-xs font-medium text-amber-700 hover:underline dark:text-amber-300">Manage all</Link>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {tenants.slice(0, 12).map((t) => (
            <li key={t.id} className="flex items-center justify-between py-2.5 text-sm">
              <Link href={`/admin/tenants/${t.id}`} className="font-medium text-ink hover:text-amber-700 dark:hover:text-amber-300">{t.name || t.id}</Link>
              <span className="text-xs text-ink-faint">{t.status || "active"}</span>
            </li>
          ))}
          {!tenants.length && <li className="py-2 text-sm text-ink-faint">No tenants yet — create one under Clients</li>}
        </ul>
      </div>
    </div>
  );
}
