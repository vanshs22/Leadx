"use client";

import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";

export default function AdminRunsPage() {
  const [runs, setRuns] = useState<any[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    admin
      .runs()
      .then((d) => setRuns(d.runs || []))
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="p-8 text-red-400">{error}</div>;

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Pipeline runs</h1>
        <p className="text-sm text-slate-400">Recent discover → deliver jobs</p>
      </header>

      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full min-w-[800px] text-left text-sm">
          <thead className="border-b border-slate-800 bg-slate-900/80 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-3 py-3">Started</th>
              <th className="px-3 py-3">Status</th>
              <th className="px-3 py-3">Found</th>
              <th className="px-3 py-3">Enriched</th>
              <th className="px-3 py-3">Gated</th>
              <th className="px-3 py-3">Assigned</th>
              <th className="px-3 py-3">Delivered</th>
              <th className="px-3 py-3">Error</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {runs.map((r) => (
              <tr key={r.id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2 text-xs text-slate-400">
                  {r.started_at ? new Date(r.started_at).toLocaleString() : "—"}
                </td>
                <td className="px-3 py-2">
                  <span
                    className={`rounded px-1.5 py-0.5 text-xs ${
                      r.status === "completed"
                        ? "bg-emerald-900/40 text-emerald-300"
                        : r.status === "failed"
                          ? "bg-red-900/40 text-red-300"
                          : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {r.status}
                  </span>
                </td>
                <td className="px-3 py-2 tabular-nums text-slate-300">{r.discovered ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-slate-300">{r.enriched ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-slate-300">{r.gated_ok ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-slate-300">{r.assigned ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-slate-300">{r.delivered ?? "—"}</td>
                <td className="max-w-[200px] truncate px-3 py-2 text-xs text-red-400">
                  {r.error_message || ""}
                </td>
              </tr>
            ))}
            {runs.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                  No runs yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
