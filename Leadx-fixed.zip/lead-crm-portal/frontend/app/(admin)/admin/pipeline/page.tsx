"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { admin } from "@/lib/admin";

function PipelineForm() {
  const params = useSearchParams();
  const [tenants, setTenants] = useState<any[]>([]);
  const [icps, setIcps] = useState<any[]>([]);
  const [form, setForm] = useState({
    tenant_id: params.get("tenant") || "",
    icp_id: "",
    industry: "medspa",
    locations: "Hoboken NJ, Jersey City NJ",
    limit_per_location: 30,
    deliver: true,
    allow_tier_b: false,
    skip_enrichment: false,
  });
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    admin.tenants("active").then((d) => setTenants(d.tenants || []));
  }, []);

  useEffect(() => {
    if (!form.tenant_id) return;
    admin.icps(form.tenant_id).then((d) => setIcps(d.icps || []));
  }, [form.tenant_id]);

  async function run() {
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const locations = form.locations
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
      const r = await admin.runPipeline({
        tenant_id: form.tenant_id,
        icp_id: form.icp_id || undefined,
        industry: form.industry,
        locations,
        limit_per_location: Number(form.limit_per_location),
        deliver: form.deliver,
        allow_tier_b: form.allow_tier_b,
        skip_enrichment: form.skip_enrichment,
      });
      setResult(r);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function runAll() {
    setBusy(true);
    setError("");
    try {
      const r = await admin.runAllIcps({
        limit_per_location: Number(form.limit_per_location),
      });
      setResult(r);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Run pipeline</h1>
        <p className="mt-1 text-sm text-slate-400">
          Discover → enrich → gate → deliver for one client
        </p>
      </header>

      <div className="max-w-xl space-y-3 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <label className="block text-xs text-slate-500">
          Client
          <select
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.tenant_id}
            onChange={(e) => setForm({ ...form, tenant_id: e.target.value, icp_id: "" })}
          >
            <option value="">Select client…</option>
            {tenants.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-xs text-slate-500">
          ICP (optional)
          <select
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.icp_id}
            onChange={(e) => setForm({ ...form, icp_id: e.target.value })}
          >
            <option value="">Manual industry / locations</option>
            {icps.map((i) => (
              <option key={i.id} value={i.id}>
                {i.vertical} — {(i.geo || []).join(", ")}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-xs text-slate-500">
          Industry
          <input
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.industry}
            onChange={(e) => setForm({ ...form, industry: e.target.value })}
          />
        </label>

        <label className="block text-xs text-slate-500">
          Locations (comma-separated)
          <input
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.locations}
            onChange={(e) => setForm({ ...form, locations: e.target.value })}
          />
        </label>

        <label className="block text-xs text-slate-500">
          Limit per location
          <input
            type="number"
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.limit_per_location}
            onChange={(e) =>
              setForm({ ...form, limit_per_location: Number(e.target.value) })
            }
          />
        </label>

        <div className="flex flex-wrap gap-4 text-sm text-slate-400">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.deliver}
              onChange={(e) => setForm({ ...form, deliver: e.target.checked })}
            />
            Deliver
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.allow_tier_b}
              onChange={(e) => setForm({ ...form, allow_tier_b: e.target.checked })}
            />
            Allow Tier B
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.skip_enrichment}
              onChange={(e) => setForm({ ...form, skip_enrichment: e.target.checked })}
            />
            Skip enrichment
          </label>
        </div>

        <div className="flex gap-2 pt-2">
          <button
            onClick={run}
            disabled={busy || !form.tenant_id}
            className="rounded-lg bg-amber-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {busy ? "Running…" : "Run for client"}
          </button>
          <button
            onClick={runAll}
            disabled={busy}
            className="rounded-lg border border-slate-700 px-4 py-2 text-sm text-slate-300 disabled:opacity-50"
          >
            Run all active ICPs
          </button>
        </div>
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}
      {result && (
        <pre className="max-h-96 overflow-auto rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-xs text-slate-300">
          {JSON.stringify(result, null, 2)}
        </pre>
      )}
    </div>
  );
}

export default function AdminPipelinePage() {
  return (
    <Suspense fallback={<div className="p-8 text-slate-500">Loading…</div>}>
      <PipelineForm />
    </Suspense>
  );
}
