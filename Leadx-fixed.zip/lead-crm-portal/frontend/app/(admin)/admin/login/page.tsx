"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { setAdminKey, admin, clearAdminKey } from "@/lib/admin";
import { getApiBase } from "@/lib/config";

const REMEMBER_KEY = "lead_admin_remember_key";

export default function AdminLoginPage() {
  const [key, setKey] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [openMode, setOpenMode] = useState<boolean | null>(null);
  const router = useRouter();

  useEffect(() => {
    try {
      const saved = localStorage.getItem(REMEMBER_KEY);
      if (saved) {
        setKey(saved);
        setRemember(true);
      }
    } catch {
      /* ignore */
    }
    fetch(`${getApiBase()}/health`)
      .then((r) => r.json())
      .then((d) => {
        const hasKey = d?.checks?.service_key === true;
        setOpenMode(!hasKey);
      })
      .catch(() => setOpenMode(null));
  }, []);

  async function enter(withKey: string | null) {
    setBusy(true);
    setError("");
    try {
      if (withKey) {
        const k = withKey.trim();
        setAdminKey(k);
        try {
          if (remember) localStorage.setItem(REMEMBER_KEY, k);
          else localStorage.removeItem(REMEMBER_KEY);
        } catch {
          /* ignore */
        }
      } else {
        setAdminKey("dev-open-mode");
      }
      await admin.globalStats();
      router.push("/admin");
    } catch (err: any) {
      clearAdminKey();
      setError(err.message || "Invalid password");
      setBusy(false);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    await enter(key);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-surface p-6">
      <form
        onSubmit={submit}
        className="w-full max-w-sm space-y-5 rounded-2xl border border-line bg-panel p-8 shadow-lg"
      >
        <div className="text-center">
          <div className="text-[11px] font-semibold uppercase tracking-widest text-amber-600 dark:text-amber-400">
            Operator
          </div>
          <h1 className="mt-1 text-xl font-semibold text-ink">Admin sign in</h1>
          <p className="mt-1.5 text-sm text-ink-muted">One step — then you are in the console.</p>
        </div>

        {openMode && (
          <button
            type="button"
            disabled={busy}
            onClick={() => enter(null)}
            className="btn-primary w-full py-3"
          >
            {busy ? "Entering…" : "Continue (local / open mode)"}
          </button>
        )}

        {openMode && (
          <div className="flex items-center gap-3 text-xs text-ink-faint">
            <div className="h-px flex-1 bg-line" />
            or use password
            <div className="h-px flex-1 bg-line" />
          </div>
        )}

        <div className="space-y-3">
          <label className="block text-xs font-medium text-ink-faint">
            Admin password
            <div className="relative mt-1">
              <input
                type={show ? "text" : "password"}
                value={key}
                onChange={(e) => setKey(e.target.value)}
                placeholder="Your operator password"
                className="input w-full pr-16"
                autoFocus={!openMode}
                autoComplete="current-password"
              />
              <button
                type="button"
                className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-ink-faint hover:text-ink"
                onClick={() => setShow((s) => !s)}
              >
                {show ? "Hide" : "Show"}
              </button>
            </div>
          </label>

          <label className="flex items-center gap-2 text-sm text-ink-muted">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
            Remember on this device
          </label>
        </div>

        {error && (
          <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy || key.trim().length < 4}
          className="btn-primary w-full py-2.5 disabled:opacity-50"
        >
          {busy ? "Checking…" : "Sign in"}
        </button>

        <p className="text-center text-[11px] text-ink-faint">
          Same value as LEAD_ENGINE_SERVICE_KEY on the server.
        </p>
      </form>
    </div>
  );
}
