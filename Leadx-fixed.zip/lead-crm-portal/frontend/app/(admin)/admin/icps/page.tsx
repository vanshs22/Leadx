"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { admin } from "@/lib/admin";

function IcpsInner() {
  const params = useSearchParams();
  const preTenant = params.get("tenant") || "";
  const [tenants, setTenants] = useState<any[]>([]);
  const [icps, setIcps] = useState<any[]>([]);
  const [form, setForm] = useState({
    tenant_id: preTenant,
    name: "default",
    vertical: "medspa",
    geo: "Hoboken NJ",
    keywords: "med spa, medical spa",
    exclusivity: "exclusive",
  });
  const [msg, setMsg] = useState("");

  function load() {
    admin.icps(preTenant || undefined).then((d) => setIcps(d.icps || []));
  }

  useEffect(() => {
    admin.tenants().then((d) => setTenants(d.tenants || []));
    load();
  }, [preTenant]);

  async function create() {
    try {
      await admin.createIcp({
        tenant_id: form.tenant_id,
        name: form.name,
        vertical: form.vertical,
        geo: form.geo.split(",").map((s) => s.trim()).filter(Boolean),
        keywords: form.keywords.split(",").map((s) => s.trim()).filter(Boolean),
        exclusivity: form.exclusivity,
      });
      setMsg("ICP created");
      load();
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  async function toggle(id: string, active: boolean) {
    await admin.updateIcp(id, { active: !active });
    load();
  }

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">ICPs</h1>
        <p className="text-sm text-slate-400">Vertical + geo targets per client</p>
      </header>

      <div className="grid gap-3 rounded-xl border border-slate-800 bg-slate-900/60 p-5 sm:grid-cols-2">
        <select
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
          value={form.tenant_id}
          onChange={(e) => setForm({ ...form, tenant_id: e.target.value })}
        >
          <option value="">Client…</option>
          {tenants.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
        <input
          placeholder="Vertical (medspa)"
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
          value={form.vertical}
          onChange={(e) => setForm({ ...form, vertical: e.target.value })}
        />
        <input
          placeholder="Geo cities (comma-separated)"
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
          value={form.geo}
          onChange={(e) => setForm({ ...form, geo: e.target.value })}
        />
        <input
          placeholder="Keywords"
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
          value={form.keywords}
          onChange={(e) => setForm({ ...form, keywords: e.target.value })}
        />
        <select
          className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
          value={form.exclusivity}
          onChange={(e) => setForm({ ...form, exclusivity: e.target.value })}
        >
          <option value="exclusive">Exclusive</option>
          <option value="shared">Shared</option>
        </select>
        <button
          onClick={create}
          disabled={!form.tenant_id || !form.vertical}
          className="rounded-lg bg-amber-600 px-4 py-2 text-sm text-white disabled:opacity-50"
        >
          Create ICP
        </button>
      </div>

      {msg && <p className="text-sm text-amber-300">{msg}</p>}

      <div className="overflow-hidden rounded-xl border border-slate-800">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-800 bg-slate-900/80 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3">Vertical</th>
              <th className="px-4 py-3">Geo</th>
              <th className="px-4 py-3">Exclusivity</th>
              <th className="px-4 py-3">Active</th>
              <th className="px-4 py-3">Tenant</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {icps.map((i) => (
              <tr key={i.id}>
                <td className="px-4 py-3 text-white">{i.vertical}</td>
                <td className="px-4 py-3 text-slate-400">{(i.geo || []).join(", ")}</td>
                <td className="px-4 py-3 text-slate-500">{i.exclusivity}</td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggle(i.id, i.active)}
                    className={`rounded px-2 py-0.5 text-xs ${
                      i.active ? "bg-emerald-900/50 text-emerald-300" : "bg-slate-800 text-slate-500"
                    }`}
                  >
                    {i.active ? "on" : "off"}
                  </button>
                </td>
                <td className="px-4 py-3 font-mono text-xs text-slate-600">{i.tenant_id?.slice(0, 8)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function AdminIcpsPage() {
  return (
    <Suspense fallback={<div className="p-8 text-slate-500">Loading…</div>}>
      <IcpsInner />
    </Suspense>
  );
}
