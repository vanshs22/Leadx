"use client";

import { useEffect, useState } from "react";
import { admin, getAdminKey } from "@/lib/admin";
import { getApiBase } from "@/lib/config";

export default function AdminSearchPage() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [tenantId, setTenantId] = useState("");
  const [vertical, setVertical] = useState("medspa");
  const [geo, setGeo] = useState("Hoboken");
  const [keywords, setKeywords] = useState("med spa");
  const [offer, setOffer] = useState("lead_gen_service");
  const [limit, setLimit] = useState(15);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [leads, setLeads] = useState<any[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [emailOpen, setEmailOpen] = useState(false);
  const [subj, setSubj] = useState("Proposal for {{company}}");
  const [body, setBody] = useState(
    "<p>Hi {{owner}}, idea for {{company}} in {{city}}.</p><p>{{pitch}}</p>"
  );

  useEffect(() => {
    admin
      .tenants()
      .then((d) => setTenants(d.tenants || []))
      .catch((e) => setMsg(e.message));
  }, []);

  async function findLeads() {
    if (!tenantId) return setMsg("Select client");
    setLoading(true);
    setMsg("");
    try {
      // Operator pipeline (service-key auth) — not tenant JWT CRM routes
      const data: any = await admin.runPipeline({
        tenant_id: tenantId,
        industry: vertical.trim(),
        locations: geo.split(",").map((s) => s.trim()).filter(Boolean),
        queries: keywords.split(",").map((s) => s.trim()).filter(Boolean),
        limit_per_location: limit,
        allow_tier_b: true,
      });
      const list = data.leads || data.assigned || data.results || [];
      setLeads(Array.isArray(list) ? list : []);
      setMsg(
        `Run ${data.status || "done"} · assigned ${data.assigned ?? list.length ?? 0}`
      );
      setSelected(new Set());
    } catch (e: any) {
      setMsg(e.message);
      setLeads([]);
    } finally {
      setLoading(false);
    }
  }

  async function sendSelected() {
    if (!tenantId || !selected.size) return setMsg("Select leads first");
    setLoading(true);
    try {
      // Authenticated operator bulk email endpoint
      const base = getApiBase();
      const key = getAdminKey();
      const res = await fetch(`${base}/leads/v2/email/bulk`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(key && key !== "dev-open-mode" ? { Authorization: `Bearer ${key}` } : {}),
        },
        body: JSON.stringify({
          tenant_id: tenantId,
          subject: subj,
          body_html: body,
          assignment_ids: Array.from(selected),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.detail || data.message || res.statusText);
      setMsg(`Sent ${data.sent || 0}, failed ${data.failed || 0}`);
      setEmailOpen(false);
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setLoading(false);
    }
  }

  function toggle(id: string) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }

  return (
    <div className="page">
      <h1 className="page-title">Search & outreach</h1>
      <p className="page-sub">Pick client → run pipeline → email proposal</p>
      {msg && (
        <div className="rounded-xl border border-line bg-surface-2 px-4 py-2 text-sm">{msg}</div>
      )}
      <div className="card-pad space-y-3">
        <select className="input" value={tenantId} onChange={(e) => setTenantId(e.target.value)}>
          <option value="">Client…</option>
          {tenants.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
        <div className="grid gap-3 sm:grid-cols-2">
          <input className="input" value={vertical} onChange={(e) => setVertical(e.target.value)} placeholder="Vertical" />
          <input className="input" value={geo} onChange={(e) => setGeo(e.target.value)} placeholder="Geo" />
          <input className="input" value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder="Keywords" />
          <input className="input" value={offer} onChange={(e) => setOffer(e.target.value)} placeholder="Offer category" />
          <input
            className="input"
            type="number"
            min={5}
            max={50}
            value={limit}
            onChange={(e) => setLimit(Number(e.target.value) || 15)}
          />
        </div>
        <button disabled={loading || !tenantId} className="btn-primary" onClick={findLeads}>
          {loading ? "Running…" : "Find leads"}
        </button>
      </div>

      {leads.length > 0 && (
        <div className="card-pad flex flex-wrap gap-2">
          <button
            type="button"
            className="btn-secondary"
            onClick={() =>
              setSelected(
                new Set(
                  leads
                    .map((l) => l.assignment_id || l.id)
                    .filter(Boolean)
                )
              )
            }
          >
            Select all
          </button>
          <button
            type="button"
            className="btn-primary"
            disabled={!selected.size}
            onClick={() => setEmailOpen(true)}
          >
            Email selected ({selected.size})
          </button>
        </div>
      )}

      <div className="space-y-2">
        {leads.map((l, i) => {
          const id = l.assignment_id || l.id || String(i);
          return (
            <div key={id} className="card-pad flex gap-3">
              <input
                type="checkbox"
                className="mt-1"
                checked={selected.has(id)}
                onChange={() => toggle(id)}
              />
              <div>
                <div className="font-semibold">{l.name || l.company_name || id}</div>
                <div className="text-sm text-ink-muted">
                  {l.email || "No email"} · {l.phone || l.phone_e164 || ""} · {l.city || ""}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {emailOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="card-pad w-full max-w-lg space-y-3">
            <h2 className="text-lg font-semibold">Send proposal ({selected.size})</h2>
            <input className="input" value={subj} onChange={(e) => setSubj(e.target.value)} />
            <textarea
              className="input min-h-[140px] font-mono text-xs"
              value={body}
              onChange={(e) => setBody(e.target.value)}
            />
            <button disabled={loading} className="btn-primary w-full" onClick={sendSelected}>
              {loading ? "Sending…" : "Send"}
            </button>
            <button className="btn-ghost w-full" onClick={() => setEmailOpen(false)}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
