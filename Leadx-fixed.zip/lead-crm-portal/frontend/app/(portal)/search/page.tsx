"use client";

import { useEffect, useMemo, useState } from "react";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function SearchPage() {
  const [vertical, setVertical] = useState("medspa");
  const [geo, setGeo] = useState("Hoboken, New Jersey");
  const [keywords, setKeywords] = useState("med spa, botox, aesthetics");
  const [offer, setOffer] = useState("lead_gen_service");
  const [limit, setLimit] = useState(15);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [runInfo, setRunInfo] = useState<any>(null);
  const [leads, setLeads] = useState<any[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [onlyEmail, setOnlyEmail] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const [subj, setSubj] = useState("Proposal for {{company}} — exclusive local leads");
  const [body, setBody] = useState(
    "<p>Hi {{owner}},</p><p>We help <b>{{company}}</b> in {{city}} get exclusive verified local leads.</p><p>{{pitch}}</p><p>Sample pack this week?</p>"
  );
  const [sending, setSending] = useState(false);
  const [quota, setQuota] = useState<{ used: number; limit: number; remaining: number; unlimited?: boolean } | null>(null);

  const visible = useMemo(() => (onlyEmail ? leads.filter((l) => l.email) : leads), [leads, onlyEmail]);

  useEffect(() => {
    const tid = getTenantId();
    if (!tid) return;
    crm.searchQuota(tid).then(setQuota).catch(() => {});
  }, []);

  function toggle(id: string) {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }

  async function findLeads() {
    setLoading(true);
    setMsg("");
    setSelected(new Set());
    try {
      const r = await crm.searchRun(getTenantId(), {
        vertical: vertical.trim(),
        geo: geo.split(",").map((s) => s.trim()).filter(Boolean),
        keywords: keywords.split(",").map((s) => s.trim()).filter(Boolean),
        offer_category: offer.trim() || "lead_gen_service",
        limit_per_location: limit,
        allow_tier_b: true,
      });
      setLeads(r.leads || []);
      setRunInfo(r.run);
      const sec = r.duration_sec ?? (r.duration_ms ? (r.duration_ms / 1000).toFixed(1) : "?");
      const tierStr = r.tiers ? Object.entries(r.tiers).map(([k, v]) => `${k}:${v}`).join(" ") : "";
      setMsg(
        `Found ${r.count || 0} leads in ${sec}s · email ${r.with_email || 0} · phone ${r.with_phone || 0}` +
          (tierStr ? ` · tiers ${tierStr}` : "")
      );
      setRunInfo({ ...(r.run || {}), duration_sec: sec, tiers: r.tiers, sources: r.sources });
      // Refresh quota after a successful search-run
      const tid = getTenantId();
      if (tid) crm.searchQuota(tid).then(setQuota).catch(() => {});
    } catch (e: any) {
      setMsg(e.message || "Search failed");
      setLeads([]);
    } finally {
      setLoading(false);
    }
  }

  async function sendProposal() {
    if (!selected.size) return setMsg("Select leads first");
    setSending(true);
    try {
      const r: any = await crm.sendEmailBulk(getTenantId(), {
        subject: subj,
        body_html: body,
        assignment_ids: Array.from(selected),
      });
      setMsg(`Emails: ${r.sent || 0} sent · ${r.failed || 0} failed · ${r.skipped_no_email || 0} skipped`);
      setEmailOpen(false);
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="page">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="page-title">Search & outreach</h1>
          <p className="page-sub">ICP → Find leads → select → send proposal (same engine, simple UI)</p>
        </div>
        {quota && (
          <div className="rounded-xl border border-line bg-surface-2 px-4 py-2.5 text-sm">
            {quota.unlimited ? (
              <span className="text-ink-muted">Searches: unlimited</span>
            ) : (
              <>
                <span className="font-medium text-ink">{quota.remaining}</span>
                <span className="text-ink-faint"> / {quota.limit} searches left this month</span>
                {quota.remaining <= 5 && quota.remaining > 0 && (
                  <span className="ml-2 text-amber-600 dark:text-amber-400">· running low</span>
                )}
                {quota.remaining === 0 && (
                  <span className="ml-2 text-red-600 dark:text-red-400">· limit reached</span>
                )}
              </>
            )}
          </div>
        )}
      </header>

      <div className="card-pad space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-xs font-medium text-ink-faint">
            Who to find (vertical)
            <input className="input mt-1" value={vertical} onChange={(e) => setVertical(e.target.value)} />
          </label>
          <label className="block text-xs font-medium text-ink-faint">
            Where (geo, comma-separated)
            <input className="input mt-1" value={geo} onChange={(e) => setGeo(e.target.value)} />
          </label>
          <label className="block text-xs font-medium text-ink-faint sm:col-span-2">
            Keywords
            <input className="input mt-1" value={keywords} onChange={(e) => setKeywords(e.target.value)} />
          </label>
          <label className="block text-xs font-medium text-ink-faint">
            Your offer category
            <input className="input mt-1" value={offer} onChange={(e) => setOffer(e.target.value)} />
          </label>
          <label className="block text-xs font-medium text-ink-faint">
            Max per location
            <input className="input mt-1" type="number" min={5} max={100} value={limit} onChange={(e) => setLimit(Number(e.target.value) || 15)} />
          </label>
        </div>
        <button
          disabled={loading || (quota != null && !quota.unlimited && quota.remaining <= 0)}
          onClick={findLeads}
          className="btn-primary px-6"
        >
          {loading
            ? "Searching… (can take 30–120s)"
            : quota != null && !quota.unlimited && quota.remaining <= 0
              ? "Search limit reached"
              : "Find leads"}
        </button>
      </div>

      {msg && <div className="rounded-xl border border-line bg-surface-2 px-4 py-2.5 text-sm text-ink-muted">{msg}</div>}

      {leads.length > 0 && (
        <div className="card-pad flex flex-wrap gap-2">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={onlyEmail} onChange={(e) => setOnlyEmail(e.target.checked)} />
            Only with email
          </label>
          <button type="button" className="btn-secondary" onClick={() => setSelected(new Set(visible.map((l) => l.assignment_id)))}>
            Select all shown
          </button>
          <button type="button" className="btn-secondary" onClick={() => setSelected(new Set(leads.filter((l) => l.email).map((l) => l.assignment_id)))}>
            Select with email
          </button>
          <button type="button" className="btn-primary" disabled={!selected.size} onClick={() => setEmailOpen(true)}>
            Email proposal ({selected.size})
          </button>
        </div>
      )}

      <div className="space-y-2">
        {visible.map((l) => (
          <div key={l.assignment_id} className="card-pad flex gap-3">
            <input type="checkbox" className="mt-1" checked={selected.has(l.assignment_id)} onChange={() => toggle(l.assignment_id)} />
            <div className="min-w-0 flex-1">
              <div className="font-semibold text-ink">{l.name} {l.tier && `· Tier ${l.tier}`}</div>
              <div className="text-sm text-ink-muted">{l.email || "No email"} · {l.phone} · {l.city}</div>
              {(l.talking_points || l.pitch_line) && (
                <p className="mt-1 text-sm text-ink-muted"><span className="font-medium text-ink">Say this:</span> {l.talking_points || l.pitch_line}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {emailOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="card-pad w-full max-w-lg space-y-3 shadow-lift">
            <h2 className="text-lg font-semibold">Send proposal ({selected.size})</h2>
            <p className="text-xs text-ink-faint">Tags: {"{{company}}"} {"{{owner}}"} {"{{city}}"} {"{{pitch}}"}</p>
            <input className="input" value={subj} onChange={(e) => setSubj(e.target.value)} />
            <textarea className="input min-h-[160px] font-mono text-xs" value={body} onChange={(e) => setBody(e.target.value)} />
            <button disabled={sending} className="btn-primary w-full" onClick={sendProposal}>
              {sending ? "Sending…" : "Send via Resend / SMTP"}
            </button>
            <button className="btn-ghost w-full" onClick={() => setEmailOpen(false)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
