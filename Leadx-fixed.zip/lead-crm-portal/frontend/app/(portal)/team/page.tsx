"use client";

import { useEffect, useState } from "react";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function TeamPage() {
  const [members, setMembers] = useState<any[]>([]);
  const [invites, setInvites] = useState<any[]>([]);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("member");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  function load() {
    crm
      .teamMembers(getTenantId())
      .then((r) => {
        setMembers(r.members || []);
        setInvites(r.invites || []);
      })
      .catch((e) => setMsg(e.message));
  }

  useEffect(() => {
    load();
  }, []);

  async function invite() {
    if (!email.trim()) return;
    setBusy(true);
    try {
      const r: any = await crm.teamInvite(getTenantId(), { email, role, send_email: true });
      if (r?.error) setMsg(String(r.error));
      else {
        setMsg(`Invite sent to ${email}`);
        setEmail("");
        load();
      }
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="page">
      <header>
        <h1 className="page-title">Team</h1>
        <p className="page-sub">Invite teammates to this workspace</p>
      </header>

      {msg && (
        <div className="rounded-xl border border-line bg-surface-2 px-4 py-2.5 text-sm text-ink-muted">{msg}</div>
      )}

      <div className="card-pad space-y-3">
        <h2 className="text-sm font-semibold text-ink">Invite teammate</h2>
        <div className="flex flex-wrap gap-2">
          <input
            className="input flex-1 min-w-[200px]"
            type="email"
            placeholder="email@company.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <select className="input max-w-[140px]" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="member">Member</option>
            <option value="admin">Admin</option>
            <option value="viewer">Viewer</option>
          </select>
          <button disabled={busy} onClick={invite} className="btn-primary">
            Send invite
          </button>
        </div>
        <p className="text-xs text-ink-faint">Invite link expires in 7 days. No operator service key is used in the browser.</p>
      </div>

      <div className="card-pad">
        <h2 className="text-sm font-semibold text-ink">Members</h2>
        <ul className="mt-3 divide-y divide-line">
          {members.map((m) => (
            <li key={m.id} className="flex justify-between py-2.5 text-sm">
              <span className="text-ink">{m.email || m.full_name || m.id}</span>
              <span className="text-xs text-ink-faint">{m.role} · {m.status}</span>
            </li>
          ))}
          {!members.length && <li className="py-2 text-sm text-ink-faint">No members yet</li>}
        </ul>
      </div>

      <div className="card-pad">
        <h2 className="text-sm font-semibold text-ink">Pending invites</h2>
        <ul className="mt-3 divide-y divide-line">
          {invites.map((i) => (
            <li key={i.id || i.token} className="flex justify-between py-2.5 text-sm">
              <span className="text-ink">{i.email}</span>
              <span className="text-xs text-ink-faint">{i.role} · expires {String(i.expires_at || "").slice(0, 10)}</span>
            </li>
          ))}
          {!invites.length && <li className="py-2 text-sm text-ink-faint">No pending invites</li>}
        </ul>
      </div>
    </div>
  );
}
