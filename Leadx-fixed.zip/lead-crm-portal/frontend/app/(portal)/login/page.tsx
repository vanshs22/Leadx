"use client";

import { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { signInWithPassword, signUpWithPassword, signInWithMagicLink } from "@/lib/auth";

const EMAIL_KEY = "lead_crm_last_email";

function LoginForm() {
  const [mode, setMode] = useState<"signin" | "signup" | "magic">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/dashboard";

  useEffect(() => {
    try {
      const saved = localStorage.getItem(EMAIL_KEY);
      if (saved) setEmail(saved);
    } catch {
      /* ignore */
    }
  }, []);

  function rememberEmail(v: string) {
    try {
      localStorage.setItem(EMAIL_KEY, v.trim());
    } catch {
      /* ignore */
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setInfo("");
    const em = email.trim();
    try {
      if (mode === "magic") {
        await signInWithMagicLink(em);
        rememberEmail(em);
        setInfo("Check your email for a sign-in link.");
        setBusy(false);
        return;
      }
      if (mode === "signup") {
        if (password.length < 6) throw new Error("Password must be at least 6 characters");
        await signUpWithPassword(em, password);
        rememberEmail(em);
        setInfo("Account created — you’re signed in.");
        router.push(next);
        return;
      }
      await signInWithPassword(em, password);
      rememberEmail(em);
      router.push(next);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-surface p-6">
      <form
        onSubmit={submit}
        className="w-full max-w-sm space-y-5 rounded-2xl border border-line bg-panel p-8 shadow-lg"
      >
        <div className="text-center">
          <h1 className="text-xl font-semibold text-ink">
            {mode === "signup" ? "Create account" : mode === "magic" ? "Email me a link" : "Sign in"}
          </h1>
          <p className="mt-1.5 text-sm text-ink-muted">
            {mode === "signup"
              ? "Use the email your agency invited."
              : mode === "magic"
                ? "No password — we’ll send a one-tap link."
                : "Welcome back."}
          </p>
        </div>

        {/* Mode tabs */}
        <div className="flex rounded-xl border border-line bg-surface-2 p-1 text-sm">
          {(
            [
              ["signin", "Sign in"],
              ["signup", "Sign up"],
              ["magic", "Magic link"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                setMode(id);
                setError("");
                setInfo("");
              }}
              className={`flex-1 rounded-lg py-1.5 font-medium transition ${
                mode === id
                  ? "bg-panel text-ink shadow-sm"
                  : "text-ink-faint hover:text-ink-muted"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          <label className="block text-xs font-medium text-ink-faint">
            Email
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              className="input mt-1 w-full"
              autoFocus
              required
              autoComplete="email"
            />
          </label>

          {mode !== "magic" && (
            <label className="block text-xs font-medium text-ink-faint">
              Password
              <div className="relative mt-1">
                <input
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={mode === "signup" ? "At least 6 characters" : "Your password"}
                  className="input w-full pr-16"
                  required
                  minLength={mode === "signup" ? 6 : undefined}
                  autoComplete={mode === "signup" ? "new-password" : "current-password"}
                />
                <button
                  type="button"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-ink-faint hover:text-ink"
                  onClick={() => setShowPw((s) => !s)}
                >
                  {showPw ? "Hide" : "Show"}
                </button>
              </div>
            </label>
          )}
        </div>

        {error && (
          <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
            {error}
          </p>
        )}
        {info && (
          <p className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
            {info}
          </p>
        )}

        <button type="submit" disabled={busy || !email.trim()} className="btn-primary w-full py-2.5 disabled:opacity-50">
          {busy
            ? "Please wait…"
            : mode === "signup"
              ? "Create account"
              : mode === "magic"
                ? "Send magic link"
                : "Sign in"}
        </button>

        {mode === "signin" && (
          <p className="text-center text-xs text-ink-faint">
            No password?{" "}
            <button type="button" className="text-brand-600 hover:underline" onClick={() => setMode("magic")}>
              Use a magic link
            </button>
          </p>
        )}
      </form>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center text-sm text-ink-muted">
          Loading…
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
