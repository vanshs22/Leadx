"use client";

import { useEffect, useState } from "react";
import { crm, DashboardResponse } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function ActivitiesPage() {
  const [data, setData] = useState<DashboardResponse | null>(null);

  useEffect(() => {
    crm.dashboard(getTenantId()).then(setData).catch(() => {});
  }, []);

  const tasks = data?.tasks_due || [];
  const activity = data?.recent_activity || [];

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Tasks & Activity</h1>
        <p className="mt-1 text-sm text-slate-400">Follow-ups and recent workspace activity</p>
      </header>

      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <h2 className="text-sm font-semibold text-white">Open tasks</h2>
        <ul className="mt-3 space-y-2">
          {tasks.length === 0 && <li className="text-sm text-slate-500">No open tasks</li>}
          {tasks.map((t) => (
            <li
              key={t.id}
              className="flex items-center justify-between rounded-lg bg-slate-950/50 px-3 py-2 text-sm"
            >
              <span className="text-slate-300">{t.title}</span>
              <span className="text-xs text-slate-500">
                {t.due_at ? new Date(t.due_at).toLocaleDateString() : "—"} · {t.priority}
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <h2 className="text-sm font-semibold text-white">Recent activity</h2>
        <ul className="mt-3 divide-y divide-slate-800">
          {activity.length === 0 && <li className="py-2 text-sm text-slate-500">No activity yet</li>}
          {activity.map((a) => (
            <li key={a.id} className="flex justify-between py-2 text-sm">
              <span>
                <span className="rounded bg-slate-800 px-1.5 py-0.5 text-xs text-slate-400">
                  {a.activity_type}
                </span>
                <span className="ml-2 text-slate-300">{a.title || "—"}</span>
              </span>
              <span className="text-xs text-slate-600">
                {new Date(a.created_at).toLocaleString()}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
