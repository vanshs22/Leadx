"use client";

import { useEffect, useState } from "react";
import { crm, ReportsSummary } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function ReportsPage() {
  const [data, setData] = useState<ReportsSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    crm.reports(getTenantId()).then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="p-8 text-red-400">{error}</div>;
  if (!data) return <div className="p-8 text-slate-500">Loading reports…</div>;

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Reports</h1>
        <p className="mt-1 text-sm text-slate-400">Quality mix and conversion snapshot</p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Total leads", value: data.total },
          { label: "With email", value: `${data.with_email} (${data.with_email_pct}%)` },
          { label: "With booking", value: data.with_booking },
          { label: "Avg score", value: data.avg_score },
        ].map((c) => (
          <div key={c.label} className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
            <div className="text-xs uppercase tracking-wide text-slate-500">{c.label}</div>
            <div className="mt-2 text-2xl font-semibold text-white">{c.value}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <h2 className="text-sm font-semibold text-white">By tier</h2>
          <ul className="mt-4 space-y-2 text-sm">
            {Object.entries(data.by_tier || {}).map(([k, v]) => (
              <li key={k} className="flex justify-between text-slate-300">
                <span>Tier {k}</span>
                <span className="tabular-nums">{v}</span>
              </li>
            ))}
          </ul>
        </section>
        <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
          <h2 className="text-sm font-semibold text-white">By stage</h2>
          <ul className="mt-4 space-y-2 text-sm">
            {Object.entries(data.by_stage || {}).map(([k, v]) => (
              <li key={k} className="flex justify-between text-slate-300">
                <span className="capitalize">{k}</span>
                <span className="tabular-nums">{v}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
