/** @type {import('next').NextConfig} */
const API_UPSTREAM = process.env.API_UPSTREAM || process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000";

const nextConfig = {
  reactStrictMode: true,
  async rewrites() {
    // Browser calls same-origin /backend/* → Next proxies to FastAPI inside the machine
    // Fixes Codespaces / "Failed to fetch" when localhost:8000 is wrong in the browser
    return [
      {
        source: "/backend/:path*",
        destination: `${API_UPSTREAM.replace(/\/$/, "")}/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
