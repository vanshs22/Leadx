"use client";

/**
 * Requires a real Supabase session, then resolves workspace via /crm/me.
 */
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { getSupabase } from "@/lib/supabaseClient";
import { crm } from "@/lib/api";
import { setTenant, getTenantId, clearTenant } from "@/lib/tenant";
import { signOut } from "@/lib/auth";

export function SessionGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function resolve() {
      const { data } = await getSupabase().auth.getSession();
      if (!data.session) {
        router.replace(`/login?next=${encodeURIComponent(pathname || "/")}`);
        return;
      }
      if (getTenantId()) {
        if (!cancelled) setReady(true);
        return;
      }
      try {
        const me = await crm.me();
        setTenant(me.tenant_id, (me as any).tenant_name);
        if (!cancelled) setReady(true);
      } catch (e: any) {
        if (!cancelled) {
          setError(
            e.message ||
              "You're signed in, but no workspace is linked to this account yet. Ask your agency admin for an invite."
          );
        }
      }
    }

    resolve();
    return () => {
      cancelled = true;
    };
  }, [pathname, router]);

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-canvas p-6 text-center">
        <p className="max-w-md text-sm text-ink-muted">{error}</p>
        <div className="flex gap-2">
          <button
            type="button"
            className="btn-secondary"
            onClick={() => {
              clearTenant();
              setError("");
              setReady(false);
              window.location.reload();
            }}
          >
            Retry
          </button>
          <button
            type="button"
            className="btn-ghost"
            onClick={async () => {
              clearTenant();
              await signOut();
              router.replace("/login");
            }}
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas text-sm text-ink-muted">
        Loading workspace…
      </div>
    );
  }

  return <>{children}</>;
}
