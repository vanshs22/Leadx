/**
 * CRM Portal API client — tenant-scoped.
 *
 * Every call attaches the logged-in user's Supabase access token. The
 * backend (require_tenant) re-verifies that token and re-checks tenant
 * membership on every request — the tenantId in the URL is only a hint,
 * never trusted on its own.
 */
import { getApiBase } from "./config";
import { getAccessToken } from "./auth";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const base = getApiBase();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;
  const token = await getAccessToken();
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch (e: any) {
    throw new Error(
      `Cannot reach API at ${base} (${e?.message || "network error"}). ` +
        `Is the backend running on port 8000?`
    );
  }
  if (res.status === 401) {
    if (typeof window !== "undefined") window.location.href = "/login";
    throw new Error("Please log in again");
  }
  if (!res.ok) {
    const err = await res.text();
    let detail = err || res.statusText;
    try {
      const j = JSON.parse(err);
      detail = j.detail || j.message || detail;
      if (Array.isArray(detail)) detail = detail.map((d: any) => d.msg || d).join(", ");
    } catch {
      /* keep text */
    }
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

async function downloadAuthed(path: string, filename: string): Promise<void> {
  const base = getApiBase();
  const token = await getAccessToken();
  const res = await fetch(`${base}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Export failed (HTTP ${res.status})`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export const crm = {
  dashboard: (tenantId: string) => api(`/crm/${tenantId}/dashboard`),

  leads: (tenantId: string, params: Record<string, string | number | undefined> = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== "") q.set(k, String(v));
    });
    return api<{ total: number; leads: any[] }>(`/crm/${tenantId}/leads?${q}`);
  },

  lead: (tenantId: string, assignmentId: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}`),

  updateLead: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/leads/${assignmentId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  searchRun: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/search-run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  branding: (tenantId: string) => api(`/crm/${tenantId}/branding`),

  sendEmailBulk: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/email/bulk`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  /** Single-lead email — backend: POST /crm/{tenant}/leads/{assignment}/email */
  sendEmail: (
    tenantId: string,
    assignmentId: string,
    body: { subject: string; body_html: string; body_text?: string; reply_to?: string }
  ) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/email`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  pipeline: (tenantId: string) => api(`/crm/${tenantId}/pipeline`),

  changeStage: (tenantId: string, assignmentId: string, stageId: string, note?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/stage`, {
      method: "POST",
      body: JSON.stringify({ stage_id: stageId, note }),
    }),

  stages: (tenantId: string) => api<any[]>(`/crm/${tenantId}/stages`),

  addActivity: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/activities`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  createTask: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/tasks`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  reportBadLead: (tenantId: string, assignmentId: string, reason: string, detail?: string) =>
    api<{
      ok: boolean;
      report?: any;
      credit?: {
        applied: boolean;
        already_credited?: boolean;
        credit_type?: string;
        message?: string;
      };
    }>(`/crm/${tenantId}/leads/${assignmentId}/bad-lead`, {
      method: "POST",
      body: JSON.stringify({ reason, detail: detail || "" }),
    }),

  firstTouch: (tenantId: string, assignmentId: string, channel?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/first-touch`, {
      method: "POST",
      body: JSON.stringify({ channel }),
    }),

  icpWeights: (tenantId: string, icpId: string, weights: Record<string, number>) =>
    api(`/crm/${tenantId}/icp/weights`, {
      method: "PATCH",
      body: JSON.stringify({ icp_id: icpId, weights }),
    }),

  docsTemplates: (tenantId: string) => api<any[]>(`/crm/${tenantId}/docs/templates`),

  docsSend: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/docs/send`, { method: "POST", body: JSON.stringify(body) }),

  teamMembers: (tenantId: string) => api<{ members: any[]; invites: any[] }>(`/crm/${tenantId}/team/members`),

  teamInvite: (
    tenantId: string,
    emailOrBody: string | { email: string; role?: string; send_email?: boolean },
    role?: string
  ) => {
    const body =
      typeof emailOrBody === "string"
        ? { email: emailOrBody, role: role || "member" }
        : { email: emailOrBody.email, role: emailOrBody.role || "member", send_email: emailOrBody.send_email };
    return api(`/crm/${tenantId}/team/invite`, {
      method: "POST",
      body: JSON.stringify(body),
    });
  },

  reportsSummary: (tenantId: string) => api(`/crm/${tenantId}/reports/summary`),
  reports: (tenantId: string) => api(`/crm/${tenantId}/reports/summary`),

  // Returns JSON rows — the leads page builds the CSV client-side itself.
  exportCsv: (tenantId: string, params: Record<string, string | undefined> = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v && q.set(k, v));
    return api<{ rows: any[]; filename?: string }>(`/crm/${tenantId}/export/csv?${q}`);
  },

  // Raw CSV response — the endpoint now requires a Bearer token, which
  // window.open() can't send, so fetch as a blob and trigger the download
  // in-memory instead of returning a bare URL to open.
  exportInstantlyUrl: (tenantId: string) =>
    downloadAuthed(`/crm/${tenantId}/export/instantly`, "leads-instantly.csv"),

  setup: (tenantId: string, body: Record<string, unknown> = {}) =>
    api(`/crm/${tenantId}/setup`, { method: "POST", body: JSON.stringify(body || {}) }),

  updateBranding: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/branding`, { method: "PATCH", body: JSON.stringify(body) }),

  me: () => api<{ tenant_id: string; role: string; email?: string }>(`/crm/me`),

  /** Free sample pack of high-quality leads (sales / onboarding demo). */
  samplePack: (
    tenantId: string,
    body: { vertical: string; geo?: string; limit?: number; min_score?: number }
  ) =>
    api<{ pack_id?: string; count: number; leads: any[]; vertical: string; geo: string }>(
      `/crm/${tenantId}/sample-pack`,
      { method: "POST", body: JSON.stringify(body) }
    ),

  /** Territory exclusivity availability (vertical+geo+offer). */
  territory: (tenantId: string, params?: { vertical?: string; geo?: string }) => {
    const q = new URLSearchParams();
    if (params?.vertical) q.set("vertical", params.vertical);
    if (params?.geo) q.set("geo", params.geo);
    const qs = q.toString();
    return api<{ locked: any[]; total_active_icps: number; note?: string }>(
      `/crm/${tenantId}/territory${qs ? `?${qs}` : ""}`
    );
  },

  /** Remaining on-demand search-runs this billing period. */
  searchQuota: (tenantId: string) =>
    api<{
      ok: boolean;
      used: number;
      limit: number;
      remaining: number;
      unlimited?: boolean;
      period_start?: string;
    }>(`/crm/${tenantId}/search-quota`),
};

// Not tenant-scoped — accepting an invite is what creates tenant
// membership in the first place, so it only needs a logged-in user.
export const acceptInvite = (token: string, fullName?: string) =>
  api(`/crm/team/accept`, {
    method: "POST",
    body: JSON.stringify({ token, full_name: fullName }),
  });

export type DashboardResponse = any;
export type LeadCard = any;
export type LeadDetail = any;
