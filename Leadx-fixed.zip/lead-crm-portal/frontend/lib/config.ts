/**
 * API base URL for browser calls.
 * Default: same-origin `/backend` (Next.js rewrite → FastAPI).
 * Override only if API is on another host: NEXT_PUBLIC_API_URL=https://...
 */
export function getApiBase(): string {
  if (typeof window !== "undefined") {
    const fromEnv = process.env.NEXT_PUBLIC_API_URL;
    // If explicitly set and not localhost-on-remote, use it
    if (fromEnv && fromEnv.trim()) {
      const v = fromEnv.trim().replace(/\/$/, "");
      // Codespaces/browser: never use localhost for API — use proxy
      if (typeof window !== "undefined") {
        const host = window.location.hostname;
        const isRemote =
          host.includes("github.dev") ||
          host.includes("webcontainer") ||
          host.includes("codesandbox") ||
          (host !== "localhost" && host !== "127.0.0.1");
        if (isRemote && (v.includes("localhost") || v.includes("127.0.0.1"))) {
          return "/backend";
        }
      }
      return v;
    }
    return "/backend";
  }
  // SSR
  return process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, "") || "http://127.0.0.1:8000";
}
