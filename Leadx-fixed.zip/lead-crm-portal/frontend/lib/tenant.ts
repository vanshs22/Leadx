/**
 * Active workspace (tenant) — stored in localStorage, not NEXT_PUBLIC_*.
 */
const KEY = "lead_crm_tenant_id";
const NAME_KEY = "lead_crm_tenant_name";

export function getTenantId(): string {
  if (typeof window === "undefined") return "";
  return localStorage.getItem(KEY) || "";
}

export function getTenantName(): string {
  if (typeof window === "undefined") return "";
  return localStorage.getItem(NAME_KEY) || "";
}

export function setTenant(id: string, name?: string) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, id);
  if (name) localStorage.setItem(NAME_KEY, name);
}

export function clearTenant() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(KEY);
  localStorage.removeItem(NAME_KEY);
}

/** Hook-friendly: read tenant; empty means user must pick workspace */
export function useTenantId(): string {
  if (typeof window === "undefined") return "";
  return getTenantId();
}
