/**
 * White-label branding — load via CRM API (tenant-scoped).
 * NEVER uses operator service key in the browser — uses the logged-in
 * tenant user's Supabase access token instead.
 */
import { useEffect, useState } from "react";
import { getAccessToken } from "./auth";

export type Branding = {
  id: string;
  name: string;
  brand_name?: string;
  brand_logo_url?: string;
  brand_primary_color?: string;
  brand_accent_color?: string;
  brand_favicon_url?: string;
  custom_domain?: string;
  support_email?: string;
};

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export async function fetchBranding(tenantId: string): Promise<Branding | null> {
  try {
    const token = await getAccessToken();
    if (!token) return null;
    const res = await fetch(`${BASE}/crm/${tenantId}/branding`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export function applyBranding(b: Branding) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (b.brand_primary_color) {
    root.style.setProperty("--brand-primary", b.brand_primary_color);
    root.style.setProperty("--brand", b.brand_primary_color);
  }
  if (b.brand_accent_color) {
    root.style.setProperty("--brand-accent", b.brand_accent_color);
  }
  if (b.brand_favicon_url) {
    let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.href = b.brand_favicon_url;
  }
  if (b.brand_name || b.name) {
    document.title = `${b.brand_name || b.name} — Leads`;
  }
}

export function useBranding(tenantId: string) {
  const [brand, setBrand] = useState<Branding | null>(null);
  useEffect(() => {
    if (!tenantId || tenantId === "YOUR_TENANT_UUID") return;
    fetchBranding(tenantId).then((b) => {
      if (b) {
        setBrand(b);
        applyBranding(b);
      }
    });
  }, [tenantId]);
  return brand;
}
