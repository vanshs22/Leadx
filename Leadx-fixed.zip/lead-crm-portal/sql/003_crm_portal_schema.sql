-- =============================================================================
-- Client CRM Portal — extends Lead Engine v2
-- Pipeline stages, activities, notes, tasks, tags, team, audit
-- =============================================================================

-- Pipeline stages (per tenant, customizable)
CREATE TABLE IF NOT EXISTS pipeline_stages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,                 -- New, Contacted, Qualified, Proposal, Won, Lost
  slug        text NOT NULL,                 -- new, contacted, qualified, proposal, won, lost
  position    int  NOT NULL DEFAULT 0,
  color       text NOT NULL DEFAULT '#6366f1',
  is_won      boolean NOT NULL DEFAULT false,
  is_lost     boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_stages_tenant ON pipeline_stages (tenant_id, position);

-- Default stages helper (call after tenant create)
CREATE OR REPLACE FUNCTION seed_default_stages(p_tenant_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO pipeline_stages (tenant_id, name, slug, position, color, is_won, is_lost) VALUES
    (p_tenant_id, 'New',        'new',        0, '#94a3b8', false, false),
    (p_tenant_id, 'Contacted',  'contacted',  1, '#3b82f6', false, false),
    (p_tenant_id, 'Qualified',  'qualified',  2, '#8b5cf6', false, false),
    (p_tenant_id, 'Proposal',   'proposal',   3, '#f59e0b', false, false),
    (p_tenant_id, 'Negotiation','negotiation',4, '#f97316', false, false),
    (p_tenant_id, 'Won',        'won',        5, '#22c55e', true,  false),
    (p_tenant_id, 'Lost',       'lost',       6, '#ef4444', false, true)
  ON CONFLICT (tenant_id, slug) DO NOTHING;
END;
$$;

-- Extend lead_assignments with CRM fields
ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id       uuid REFERENCES pipeline_stages(id),
  ADD COLUMN IF NOT EXISTS assigned_to    uuid,          -- team member user id
  ADD COLUMN IF NOT EXISTS priority       text DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','urgent')),
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(12,2),
  ADD COLUMN IF NOT EXISTS source_campaign text,
  ADD COLUMN IF NOT EXISTS custom_fields  jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags           text[] DEFAULT '{}';

CREATE INDEX IF NOT EXISTS idx_assignments_stage ON lead_assignments (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_assignments_assignee ON lead_assignments (tenant_id, assigned_to);
CREATE INDEX IF NOT EXISTS idx_assignments_next_action ON lead_assignments (tenant_id, next_action_at)
  WHERE next_action_at IS NOT NULL;

-- Activities (calls, emails, notes, status changes, system events)
CREATE TABLE IF NOT EXISTS lead_activities (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  actor_id      uuid,                          -- team member who did it (null = system)
  activity_type text NOT NULL CHECK (activity_type IN (
    'note','call','email','sms','meeting','stage_change','status_change',
    'task_created','task_completed','enrichment','system','other'
  )),
  title         text,
  body          text,
  meta          jsonb DEFAULT '{}',            -- duration, outcome, from_stage, to_stage, etc.
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_activities_assignment ON lead_activities (assignment_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activities_tenant ON lead_activities (tenant_id, created_at DESC);

-- Tasks / follow-ups
CREATE TABLE IF NOT EXISTS lead_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assigned_to   uuid,
  created_by    uuid,
  title         text NOT NULL,
  description   text,
  due_at        timestamptz,
  completed_at  timestamptz,
  status        text NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','done','cancelled')),
  priority      text NOT NULL DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','urgent')),
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tasks_open ON lead_tasks (tenant_id, status, due_at)
  WHERE status = 'open';

-- Tags dictionary (per tenant)
CREATE TABLE IF NOT EXISTS lead_tags (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id  uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name       text NOT NULL,
  color      text DEFAULT '#64748b',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name)
);

-- Team members (portal users for a tenant)
CREATE TABLE IF NOT EXISTS tenant_members (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  full_name   text,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  auth_user_id uuid,                           -- Supabase auth.users id
  avatar_url  text,
  last_login_at timestamptz,
  status      text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','invited','disabled')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_members_tenant ON tenant_members (tenant_id, status);

-- Saved filters / segments
CREATE TABLE IF NOT EXISTS lead_segments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
  filters     jsonb NOT NULL DEFAULT '{}',    -- { tier: ['A'], stage: ['qualified'], tags: [...] }
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Audit log
CREATE TABLE IF NOT EXISTS crm_audit_log (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  actor_id    uuid,
  action      text NOT NULL,                  -- lead.stage_change, lead.export, settings.update
  entity_type text,
  entity_id   uuid,
  before      jsonb,
  after       jsonb,
  ip          text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_tenant ON crm_audit_log (tenant_id, created_at DESC);

-- Client portal sessions helper view: assignment + lead + enrichment + score + stage
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  la.id AS assignment_id,
  la.tenant_id,
  la.lead_id,
  la.status AS assignment_status,
  la.delivery_status,
  la.delivered_at,
  la.priority,
  la.next_action_at,
  la.last_contacted_at,
  la.value_estimate,
  la.tags,
  la.custom_fields,
  la.assigned_to,
  la.stage_id,
  ps.name AS stage_name,
  ps.slug AS stage_slug,
  ps.color AS stage_color,
  ps.position AS stage_position,
  lg.name AS company_name,
  lg.phone_normalized,
  lg.phone_e164,
  lg.website,
  lg.address,
  lg.city,
  lg.state,
  lg.business_status,
  lg.google_rating,
  lg.review_count,
  lg.category,
  e.email,
  e.email_valid,
  e.has_booking,
  e.booking_platform,
  e.services,
  e.social_links,
  e.owner_name,
  e.enrichment_ok,
  s.total_score,
  s.tier,
  s.reasoning AS score_reasoning
FROM lead_assignments la
JOIN leads_global lg ON lg.id = la.lead_id
LEFT JOIN enrichment e ON e.lead_id = lg.id
LEFT JOIN scores s ON s.lead_id = lg.id
LEFT JOIN pipeline_stages ps ON ps.id = la.stage_id;
