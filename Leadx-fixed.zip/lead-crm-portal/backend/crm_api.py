"""
Client CRM Portal API — multi-tenant lead CRM for agencies & businesses.
All endpoints require tenant context (from auth middleware in production).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

router = APIRouter(prefix="/crm", tags=["crm-portal"])


# ─── Request models ─────────────────────────────────────────────────────────

class StageChangeRequest(BaseModel):
    stage_id: str
    note: Optional[str] = None


class ActivityCreate(BaseModel):
    activity_type: str = "note"
    title: Optional[str] = None
    body: Optional[str] = None
    meta: dict = Field(default_factory=dict)


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    due_at: Optional[str] = None
    priority: str = "medium"
    assigned_to: Optional[str] = None


class LeadUpdate(BaseModel):
    priority: Optional[str] = None
    assigned_to: Optional[str] = None
    next_action_at: Optional[str] = None
    value_estimate: Optional[float] = None
    tags: Optional[list[str]] = None
    custom_fields: Optional[dict] = None
    status: Optional[str] = None


class BulkStageRequest(BaseModel):
    assignment_ids: list[str]
    stage_id: str


class SegmentCreate(BaseModel):
    name: str
    filters: dict = Field(default_factory=dict)


# ─── Helpers ────────────────────────────────────────────────────────────────

def _sb():
    from backend.memory.supabase_client import get_supabase
    return get_supabase()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def _log_activity(
    tenant_id: str,
    assignment_id: str,
    lead_id: str,
    activity_type: str,
    title: str = None,
    body: str = None,
    meta: dict = None,
    actor_id: str = None,
):
    try:
        _sb().table("lead_activities").insert({
            "tenant_id": tenant_id,
            "assignment_id": assignment_id,
            "lead_id": lead_id,
            "actor_id": actor_id,
            "activity_type": activity_type,
            "title": title,
            "body": body,
            "meta": meta or {},
        }).execute()
    except Exception:
        pass


# ─── Dashboard ──────────────────────────────────────────────────────────────

@router.get("/{tenant_id}/dashboard")
async def dashboard(tenant_id: UUID):
    """KPIs + funnel + recent activity for the home screen."""
    sb = _sb()
    tid = str(tenant_id)

    # Counts by stage
    stages = (
        sb.table("pipeline_stages")
        .select("id, name, slug, color, position, is_won, is_lost")
        .eq("tenant_id", tid)
        .order("position")
        .execute()
        .data or []
    )

    cards = (
        sb.table("crm_lead_cards")
        .select("assignment_id, stage_slug, tier, total_score, assignment_status")
        .eq("tenant_id", tid)
        .execute()
        .data or []
    )

    by_stage: dict[str, int] = {}
    by_tier: dict[str, int] = {"A": 0, "B": 0, "C": 0}
    total = len(cards)
    for c in cards:
        slug = c.get("stage_slug") or "new"
        by_stage[slug] = by_stage.get(slug, 0) + 1
        t = c.get("tier") or "C"
        by_tier[t] = by_tier.get(t, 0) + 1

    # Open tasks due soon
    tasks = (
        sb.table("lead_tasks")
        .select("id, title, due_at, priority, assignment_id")
        .eq("tenant_id", tid)
        .eq("status", "open")
        .order("due_at")
        .limit(10)
        .execute()
        .data or []
    )

    # Recent activities
    activities = (
        sb.table("lead_activities")
        .select("id, activity_type, title, body, created_at, lead_id")
        .eq("tenant_id", tid)
        .order("created_at", desc=True)
        .limit(15)
        .execute()
        .data or []
    )

    # Usage / quota
    period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
    usage = (
        sb.table("usage_log")
        .select("*")
        .eq("tenant_id", tid)
        .eq("period", period)
        .limit(1)
        .execute()
        .data
    )
    tenant = (
        sb.table("tenants")
        .select("name, plan, leads_per_month_limit, delivery_channel")
        .eq("id", tid)
        .limit(1)
        .execute()
        .data
    )

    won = by_stage.get("won", 0)
    lost = by_stage.get("lost", 0)
    closed = won + lost
    win_rate = round(100 * won / closed, 1) if closed else 0

    return {
        "tenant": tenant[0] if tenant else None,
        "kpis": {
            "total_leads": total,
            "tier_a": by_tier.get("A", 0),
            "tier_b": by_tier.get("B", 0),
            "new": by_stage.get("new", 0),
            "in_pipeline": total - won - lost,
            "won": won,
            "lost": lost,
            "win_rate_pct": win_rate,
        },
        "funnel": [
            {
                "stage": s["name"],
                "slug": s["slug"],
                "color": s["color"],
                "count": by_stage.get(s["slug"], 0),
            }
            for s in stages
        ],
        "usage": usage[0] if usage else None,
        "quota_limit": (tenant[0].get("leads_per_month_limit") if tenant else None),
        "tasks_due": tasks,
        "recent_activity": activities,
    }


# ─── Leads list & detail ────────────────────────────────────────────────────

@router.get("/{tenant_id}/leads")
async def list_leads(
    tenant_id: UUID,
    stage: Optional[str] = None,
    tier: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    tag: Optional[str] = None,
    assigned_to: Optional[str] = None,
    priority: Optional[str] = None,
    sort: str = "delivered_at",
    order: str = "desc",
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    """Paginated, filterable lead list for the CRM table view."""
    sb = _sb()
    tid = str(tenant_id)

    q = sb.table("crm_lead_cards").select("*", count="exact").eq("tenant_id", tid)

    if stage:
        q = q.eq("stage_slug", stage)
    if tier:
        q = q.eq("tier", tier.upper())
    if status:
        q = q.eq("assignment_status", status)
    if assigned_to:
        q = q.eq("assigned_to", assigned_to)
    if priority:
        q = q.eq("priority", priority)
    if tag:
        q = q.contains("tags", [tag])
    if search:
        # Simple ilike on company name — for production add full-text
        q = q.ilike("company_name", f"%{search}%")

    desc = order.lower() != "asc"
    q = q.order(sort if sort in (
        "delivered_at", "total_score", "company_name", "next_action_at", "priority"
    ) else "delivered_at", desc=desc)

    q = q.range(offset, offset + limit - 1)
    r = q.execute()
    return {
        "total": r.count if hasattr(r, "count") else len(r.data or []),
        "limit": limit,
        "offset": offset,
        "leads": r.data or [],
    }


@router.get("/{tenant_id}/leads/{assignment_id}")
async def lead_detail(tenant_id: UUID, assignment_id: UUID):
    """Full lead card + timeline + tasks."""
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)

    cards = (
        sb.table("crm_lead_cards")
        .select("*")
        .eq("tenant_id", tid)
        .eq("assignment_id", aid)
        .limit(1)
        .execute()
        .data or []
    )
    if not cards:
        raise HTTPException(404, "Lead not found")

    activities = (
        sb.table("lead_activities")
        .select("*")
        .eq("assignment_id", aid)
        .order("created_at", desc=True)
        .limit(100)
        .execute()
        .data or []
    )
    tasks = (
        sb.table("lead_tasks")
        .select("*")
        .eq("assignment_id", aid)
        .order("created_at", desc=True)
        .execute()
        .data or []
    )
    return {
        "lead": cards[0],
        "activities": activities,
        "tasks": tasks,
    }


@router.patch("/{tenant_id}/leads/{assignment_id}")
async def update_lead(tenant_id: UUID, assignment_id: UUID, body: LeadUpdate):
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    payload = {k: v for k, v in body.model_dump().items() if v is not None}
    if not payload:
        raise HTTPException(400, "No fields to update")

    # Fetch lead_id for activity
    row = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        raise HTTPException(404, "Lead not found")

    sb.table("lead_assignments").update(payload).eq("id", aid).eq("tenant_id", tid).execute()
    await _log_activity(
        tid, aid, row[0]["lead_id"], "system",
        title="Lead updated", meta=payload,
    )
    return {"ok": True, "updated": list(payload.keys())}


@router.post("/{tenant_id}/leads/{assignment_id}/stage")
async def change_stage(tenant_id: UUID, assignment_id: UUID, body: StageChangeRequest):
    """Move lead to a pipeline stage + log activity."""
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)

    current = (
        sb.table("lead_assignments")
        .select("lead_id, stage_id, status")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not current:
        raise HTTPException(404, "Lead not found")

    stage = (
        sb.table("pipeline_stages")
        .select("*")
        .eq("id", body.stage_id)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not stage:
        raise HTTPException(400, "Invalid stage")

    stage = stage[0]
    new_status = "won" if stage.get("is_won") else ("rejected" if stage.get("is_lost") else "new")
    # Keep contacted/etc. semantics loose — status mirrors stage outcome
    if stage["slug"] in ("contacted", "qualified", "proposal", "negotiation"):
        new_status = "contacted"

    sb.table("lead_assignments").update({
        "stage_id": body.stage_id,
        "status": new_status,
        "last_contacted_at": _now() if stage["slug"] != "new" else None,
    }).eq("id", aid).execute()

    await _log_activity(
        tid, aid, current[0]["lead_id"], "stage_change",
        title=f"Moved to {stage['name']}",
        body=body.note,
        meta={"from_stage_id": current[0].get("stage_id"), "to_stage_id": body.stage_id, "to_slug": stage["slug"]},
    )
    return {"ok": True, "stage": stage}


@router.post("/{tenant_id}/leads/bulk-stage")
async def bulk_stage(tenant_id: UUID, body: BulkStageRequest):
    results = []
    for aid in body.assignment_ids:
        try:
            r = await change_stage(tenant_id, UUID(aid), StageChangeRequest(stage_id=body.stage_id))
            results.append({"id": aid, "ok": True})
        except Exception as e:
            results.append({"id": aid, "ok": False, "error": str(e)})
    return {"results": results}


# ─── Activities & tasks ─────────────────────────────────────────────────────

@router.post("/{tenant_id}/leads/{assignment_id}/activities")
async def add_activity(tenant_id: UUID, assignment_id: UUID, body: ActivityCreate):
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    row = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        raise HTTPException(404, "Lead not found")

    r = sb.table("lead_activities").insert({
        "tenant_id": tid,
        "assignment_id": aid,
        "lead_id": row[0]["lead_id"],
        "activity_type": body.activity_type,
        "title": body.title,
        "body": body.body,
        "meta": body.meta,
    }).execute()

    # Touch last_contacted for call/email/sms
    if body.activity_type in ("call", "email", "sms", "meeting"):
        sb.table("lead_assignments").update({
            "last_contacted_at": _now(),
        }).eq("id", aid).execute()

    return r.data[0] if r.data else {"ok": True}


@router.post("/{tenant_id}/leads/{assignment_id}/tasks")
async def create_task(tenant_id: UUID, assignment_id: UUID, body: TaskCreate):
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    row = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        raise HTTPException(404, "Lead not found")

    r = sb.table("lead_tasks").insert({
        "tenant_id": tid,
        "assignment_id": aid,
        "lead_id": row[0]["lead_id"],
        "title": body.title,
        "description": body.description,
        "due_at": body.due_at,
        "priority": body.priority,
        "assigned_to": body.assigned_to,
        "status": "open",
    }).execute()

    await _log_activity(
        tid, aid, row[0]["lead_id"], "task_created",
        title=body.title, meta={"due_at": body.due_at},
    )
    return r.data[0] if r.data else {"ok": True}


@router.post("/{tenant_id}/tasks/{task_id}/complete")
async def complete_task(tenant_id: UUID, task_id: UUID):
    sb = _sb()
    sb.table("lead_tasks").update({
        "status": "done",
        "completed_at": _now(),
    }).eq("id", str(task_id)).eq("tenant_id", str(tenant_id)).execute()
    return {"ok": True}


# ─── Pipeline (Kanban) ──────────────────────────────────────────────────────

@router.get("/{tenant_id}/pipeline")
async def pipeline_board(tenant_id: UUID):
    """All stages with leads nested — for Kanban UI."""
    sb = _sb()
    tid = str(tenant_id)
    stages = (
        sb.table("pipeline_stages")
        .select("*")
        .eq("tenant_id", tid)
        .order("position")
        .execute()
        .data or []
    )
    cards = (
        sb.table("crm_lead_cards")
        .select("*")
        .eq("tenant_id", tid)
        .order("total_score", desc=True)
        .execute()
        .data or []
    )
    by_stage: dict[str, list] = {s["id"]: [] for s in stages}
    unstaged = []
    for c in cards:
        sid = c.get("stage_id")
        if sid and sid in by_stage:
            by_stage[sid].append(c)
        else:
            unstaged.append(c)

    return {
        "stages": [
            {**s, "leads": by_stage.get(s["id"], [])}
            for s in stages
        ],
        "unstaged": unstaged,
    }


@router.get("/{tenant_id}/stages")
async def list_stages(tenant_id: UUID):
    sb = _sb()
    return (
        sb.table("pipeline_stages")
        .select("*")
        .eq("tenant_id", str(tenant_id))
        .order("position")
        .execute()
        .data or []
    )


@router.post("/{tenant_id}/stages/seed")
async def seed_stages(tenant_id: UUID):
    sb = _sb()
    try:
        sb.rpc("seed_default_stages", {"p_tenant_id": str(tenant_id)}).execute()
    except Exception:
        # Fallback insert if RPC missing
        defaults = [
            ("New", "new", 0, "#94a3b8", False, False),
            ("Contacted", "contacted", 1, "#3b82f6", False, False),
            ("Qualified", "qualified", 2, "#8b5cf6", False, False),
            ("Proposal", "proposal", 3, "#f59e0b", False, False),
            ("Negotiation", "negotiation", 4, "#f97316", False, False),
            ("Won", "won", 5, "#22c55e", True, False),
            ("Lost", "lost", 6, "#ef4444", False, True),
        ]
        for name, slug, pos, color, won, lost in defaults:
            try:
                sb.table("pipeline_stages").upsert({
                    "tenant_id": str(tenant_id),
                    "name": name, "slug": slug, "position": pos,
                    "color": color, "is_won": won, "is_lost": lost,
                }, on_conflict="tenant_id,slug").execute()
            except Exception:
                pass
    return await list_stages(tenant_id)


# ─── Reports ────────────────────────────────────────────────────────────────

@router.get("/{tenant_id}/reports/summary")
async def reports_summary(tenant_id: UUID):
    """Conversion, tier mix, delivery stats for Reports page."""
    sb = _sb()
    tid = str(tenant_id)
    cards = (
        sb.table("crm_lead_cards")
        .select("tier, stage_slug, total_score, delivered_at, has_booking, email")
        .eq("tenant_id", tid)
        .execute()
        .data or []
    )
    total = len(cards)
    with_email = sum(1 for c in cards if c.get("email"))
    with_booking = sum(1 for c in cards if c.get("has_booking"))
    by_tier = {"A": 0, "B": 0, "C": 0}
    by_stage: dict = {}
    for c in cards:
        by_tier[c.get("tier") or "C"] = by_tier.get(c.get("tier") or "C", 0) + 1
        s = c.get("stage_slug") or "unknown"
        by_stage[s] = by_stage.get(s, 0) + 1

    return {
        "total": total,
        "with_email": with_email,
        "with_email_pct": round(100 * with_email / total, 1) if total else 0,
        "with_booking": with_booking,
        "by_tier": by_tier,
        "by_stage": by_stage,
        "avg_score": round(sum(c.get("total_score") or 0 for c in cards) / total, 1) if total else 0,
    }


# ─── Export ─────────────────────────────────────────────────────────────────

@router.get("/{tenant_id}/export/csv")
async def export_csv(
    tenant_id: UUID,
    stage: Optional[str] = None,
    tier: Optional[str] = None,
):
    """Return lead rows as JSON (frontend turns into CSV download)."""
    data = await list_leads(
        tenant_id, stage=stage, tier=tier, limit=500, offset=0
    )
    rows = []
    for l in data.get("leads") or []:
        rows.append({
            "company": l.get("company_name"),
            "phone": l.get("phone_e164") or l.get("phone_normalized"),
            "email": l.get("email"),
            "website": l.get("website"),
            "city": l.get("city"),
            "tier": l.get("tier"),
            "score": l.get("total_score"),
            "stage": l.get("stage_name"),
            "booking": l.get("booking_platform"),
            "priority": l.get("priority"),
            "delivered_at": l.get("delivered_at"),
        })
    return {"filename": f"leads-{tenant_id}-{datetime.now(timezone.utc).date()}.csv", "rows": rows}


# ─── Onboarding helper ──────────────────────────────────────────────────────

@router.post("/{tenant_id}/setup")
async def setup_tenant_crm(tenant_id: UUID):
    """Seed default pipeline stages for a new tenant portal."""
    stages = await seed_stages(tenant_id)
    return {"ok": True, "stages": stages}
