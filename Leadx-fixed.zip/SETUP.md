# Run Automiqo Lead Service (few steps, no tenant env)

## One-time

1. **Supabase SQL Editor** → paste and run  
   `lead-engine-v2/SUPABASE_FULL_MIGRATION.sql`

2. **API env**
   ```bash
   cp lead-engine-v2/.env.example lead-engine-v2/.env
   ```
   Set: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `LEAD_ENGINE_SERVICE_KEY`  
   Optional: `SERPER_API_KEY`, `RESEND_API_KEY`, `RESEND_FROM`

## Start (pick one)

### A — Single script
```bash
./start.sh
```

### B — Docker both services
```bash
docker compose up --build
```

### C — Two terminals
```bash
# Terminal 1
cd lead-engine-v2 && docker compose up -d api

# Terminal 2
cd lead-crm-portal/frontend
echo 'NEXT_PUBLIC_API_URL=http://localhost:8000' > .env.local
npm install && npm run dev
```

## Use in the browser

1. Open **http://localhost:3000**
2. **Choose workspace** screen:
   - Enter service key → Unlock  
   - **Create & open** a workspace (or pick existing)
3. Go to **Search** → type ICP → **Find leads** → select → email proposal

No `NEXT_PUBLIC_TENANT_ID` required. Workspace is saved in the browser.

| URL | Purpose |
|-----|---------|
| http://localhost:3000 | CRM (after workspace pick) |
| http://localhost:3000/search | Find + email |
| http://localhost:3000/admin/login | Operator admin |
| http://localhost:8000/docs | API docs |

## Switch workspace
Sidebar → **Switch workspace**


## Live test (after API is running)

```bash
# from package root
./live_test.sh

# or
cd lead-engine-v2 && ./scripts/live_test.sh

# custom URLs
API_URL=http://127.0.0.1:8000 FRONTEND_URL=http://127.0.0.1:3000 ./scripts/live_test.sh
```

Reports pass/fail and **what to fix** (DB, keys, pipeline, CRM routes, frontend).


## LinkedIn scraper + Instagram instaloader

**Discovery (finding leads)**
- Maps / search: Serper
- LinkedIn: Serper `site:linkedin.com` **+** optional `drissbri` service (`/company-search`, `/company-data`) when `LINKEDIN_SCRAPER_URL` + `li_at` cookie in `api_key_pool` (provider=`linkedin_scraper`)
- Instagram: Serper `site:instagram.com` **+** instaloader hashtag scrape (no login)

**Enrichment (after quality gate, Tier A/B)**
- Website: Scrapling → Crawl4AI → Firecrawl → ScrapeGraphAI
- LinkedIn deep: same microservice `/company-data`, `/profile-data`
- Instagram: instaloader public profile (followers, bio, last post)

**2GB VPS:** skip LinkedIn Selenium container; Serper + instaloader still discover social leads.


## Simple testing (no service key)

Set in `lead-engine-v2/.env`:
```bash
ENVIRONMENT=development
LEAD_ENGINE_DEV_AUTH_BYPASS=1
```
UI workspace picker needs **no** unlock key — just Create & open.
For real production later: `ENVIRONMENT=production` + strong `LEAD_ENGINE_SERVICE_KEY`.
