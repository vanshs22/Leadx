#!/usr/bin/env bash
exec "$(cd "$(dirname "$0")" && pwd)/lead-engine-v2/scripts/live_test.sh" "$@"
