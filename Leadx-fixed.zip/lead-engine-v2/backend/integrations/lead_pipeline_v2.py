"""
Lead Engine v2 — Full Pipeline Orchestrator
Discover → Enrich → Score → Store → Quality Gate → Exclusivity → Assign → Deliver

Designed for thousands of leads: concurrent enrichment, global dedup, multi-tenant.
"""
from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from backend.integrations.lead_discovery_v2 import discover_leads_v2
from backend.integrations.lead_enricher_v2 import enrich_batch_v2
from backend.integrations.lead_quality_gate import (
    score_deterministic,
    passes_quality_gate,
    assign_lead_if_available,
    bump_usage,
)
from backend.memory.supabase_client import get_supabase


async def upsert_global_lead(lead: dict) -> Optional[str]:
    """Insert or update leads_global, return lead_id."""
    sb = get_supabase()
    fp = lead.get("fingerprint")
    phone = lead.get("phone_normalized")
    payload = {
        "fingerprint": fp,
        "phone_normalized": phone,
        "name": lead.get("name") or lead.get("company_name") or "",
        "address": lead.get("address"),
        "website": lead.get("website"),
        "category": lead.get("category") or lead.get("industry"),
        "business_status": (lead.get("business_status") or "OPERATIONAL").upper(),
        "google_rating": lead.get("google_rating"),
        "review_count": lead.get("review_count") or 0,
        "source": lead.get("source", "google_maps_serper"),
        "raw_data": lead.get("raw_data") or {},
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        # Prefer fingerprint match
        if fp:
            existing = (
                sb.table("leads_global")
                .select("id")
                .eq("fingerprint", fp)
                .limit(1)
                .execute()
                .data
            )
            if existing:
                sb.table("leads_global").update(payload).eq("id", existing[0]["id"]).execute()
                return existing[0]["id"]
        if phone:
            existing = (
                sb.table("leads_global")
                .select("id")
                .eq("phone_normalized", phone)
                .limit(1)
                .execute()
                .data
            )
            if existing:
                sb.table("leads_global").update(payload).eq("id", existing[0]["id"]).execute()
                return existing[0]["id"]

        r = sb.table("leads_global").insert(payload).execute()
        return r.data[0]["id"] if r.data else None
    except Exception:
        return None


async def upsert_enrichment(lead_id: str, lead: dict) -> None:
    sb = get_supabase()
    try:
        sb.table("enrichment").upsert({
            "lead_id": lead_id,
            "email": lead.get("email"),
            "emails": lead.get("emails") or [],
            "phone_from_web": lead.get("phone_from_web"),
            "has_booking": lead.get("has_booking") or lead.get("has_online_booking") or False,
            "booking_platform": lead.get("booking_platform"),
            "services": lead.get("services") or [],
            "social_links": lead.get("social_links") or {},
            "markdown_summary": (lead.get("markdown_summary") or "")[:4000] or None,
            "raw_extraction": lead.get("raw_extraction") or {},
            "enrichment_method": lead.get("enrichment_method"),
            "extracted_at": datetime.now(timezone.utc).isoformat(),
        }, on_conflict="lead_id").execute()
    except Exception:
        pass


async def upsert_score(lead_id: str, score: int, tier: str, reasoning: str) -> None:
    sb = get_supabase()
    try:
        sb.table("scores").upsert({
            "lead_id": lead_id,
            "deterministic_score": score,
            "total_score": score,
            "tier": tier,
            "reasoning": reasoning,
            "scored_at": datetime.now(timezone.utc).isoformat(),
        }, on_conflict="lead_id").execute()
    except Exception:
        pass


async def run_pipeline_v2(
    tenant_id: str,
    icp_id: Optional[str] = None,
    industry: str = "medspa",
    locations: list[str] | None = None,
    queries: list[str] | None = None,
    limit_per_location: int = 50,
    skip_enrichment: bool = False,
    allow_tier_b: bool = False,
    max_enrich_concurrent: int = 6,
    deliver: bool = True,
) -> dict:
    """
    Full multi-tenant lead pipeline.

    1. Discover (Serper key-pooled + Scrapling fallback)
    2. Enrich (Scrapling → Crawl4AI → Firecrawl → ScrapeGraphAI)
    3. Score (deterministic)
    4. Upsert global pool + enrichment + scores
    5. Quality gate
    6. Exclusivity check + assign
    7. Usage log
    """
    started = datetime.now(timezone.utc)
    sb = get_supabase()

    # Resolve ICP if provided
    vertical = industry
    geo = locations or []
    delivery_channel = "telegram"
    if icp_id:
        try:
            icp = (
                sb.table("icp_profiles")
                .select("*")
                .eq("id", icp_id)
                .limit(1)
                .execute()
                .data
            )
            if icp:
                icp = icp[0]
                vertical = icp.get("vertical") or industry
                geo = icp.get("geo") or locations or []
                queries = queries or (icp.get("keywords") or None)
        except Exception:
            pass

    if not geo:
        geo = ["New Jersey"]

    # Resolve tenant delivery channel
    try:
        t = sb.table("tenants").select("delivery_channel, plan").eq("id", tenant_id).limit(1).execute().data
        if t:
            delivery_channel = t[0].get("delivery_channel") or "telegram"
            if t[0].get("plan") in ("growth", "premium"):
                allow_tier_b = True
    except Exception:
        pass

    # ---------- Stage 1: Discover ----------
    print(f"[v2] Discover {vertical} in {geo} (limit={limit_per_location})")
    raw = await discover_leads_v2(
        industry=vertical,
        locations=geo,
        queries=queries,
        limit_per_location=limit_per_location,
    )
    print(f"[v2] Discovered {len(raw)} unique leads")

    # ---------- Stage 2: Enrich ----------
    if not skip_enrichment and raw:
        print(f"[v2] Enriching (concurrency={max_enrich_concurrent})...")
        raw = await enrich_batch_v2(raw, max_concurrent=max_enrich_concurrent)
        enriched_n = sum(1 for l in raw if l.get("enriched"))
        print(f"[v2] Enriched {enriched_n}/{len(raw)}")

    # ---------- Stage 3+4: Score + Store ----------
    stored = 0
    gated_ok = 0
    assigned = 0
    top = []

    for lead in raw:
        score, tier, reasoning = score_deterministic(lead, vertical)
        lead["score"] = score
        lead["tier"] = tier
        lead["score_reason"] = reasoning

        lead_id = await upsert_global_lead(lead)
        if not lead_id:
            continue
        lead["id"] = lead_id
        stored += 1

        if lead.get("enriched"):
            await upsert_enrichment(lead_id, lead)
        await upsert_score(lead_id, score, tier, reasoning)

        # ---------- Stage 5: Quality Gate ----------
        ok, reason = passes_quality_gate(lead, allow_tier_b=allow_tier_b)
        if not ok:
            continue
        gated_ok += 1

        # ---------- Stage 6: Exclusivity + Assign ----------
        if deliver:
            result = await assign_lead_if_available(
                lead_id=lead_id,
                tenant_id=tenant_id,
                icp_id=icp_id,
                vertical=vertical,
                geo=geo,
                delivery_channel=delivery_channel,
            )
            if result.get("assigned"):
                assigned += 1
                await bump_usage(tenant_id, tier)
                if len(top) < 20:
                    top.append({
                        "name": lead.get("name"),
                        "score": score,
                        "tier": tier,
                        "phone": lead.get("phone"),
                        "email": lead.get("email"),
                        "website": lead.get("website"),
                        "reason": reasoning,
                    })

    elapsed = round((datetime.now(timezone.utc) - started).total_seconds(), 1)

    return {
        "pipeline": "lead_engine_v2",
        "tenant_id": tenant_id,
        "icp_id": icp_id,
        "industry": vertical,
        "locations": geo,
        "discovered": len(raw),
        "stored_global": stored,
        "passed_quality_gate": gated_ok,
        "assigned_to_tenant": assigned,
        "elapsed_seconds": elapsed,
        "top_leads": top,
    }


async def run_for_all_active_icps(
    limit_per_location: int = 30,
    skip_enrichment: bool = False,
) -> list[dict]:
    """Cron entrypoint: loop every active ICP and run the pipeline."""
    sb = get_supabase()
    icps = (
        sb.table("icp_profiles")
        .select("id, tenant_id, vertical, geo, keywords")
        .eq("active", True)
        .execute()
        .data or []
    )
    results = []
    for icp in icps:
        try:
            r = await run_pipeline_v2(
                tenant_id=icp["tenant_id"],
                icp_id=icp["id"],
                industry=icp.get("vertical") or "medspa",
                locations=icp.get("geo") or [],
                queries=icp.get("keywords") or None,
                limit_per_location=limit_per_location,
                skip_enrichment=skip_enrichment,
            )
            results.append(r)
        except Exception as e:
            results.append({"icp_id": icp["id"], "error": str(e)})
        await asyncio.sleep(1)
    return results
