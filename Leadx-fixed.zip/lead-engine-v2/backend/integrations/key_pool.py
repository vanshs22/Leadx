"""
API Key Pool — automatic rotation for Serper, Firecrawl, Gemini, Groq, Anthropic.
Queries Supabase for the least-recently-used active key and marks exhausted on 402/429.
"""
from __future__ import annotations
import os
from datetime import datetime, timezone
from typing import Optional

from backend.memory.supabase_client import get_supabase


class KeyPoolExhausted(Exception):
    """Raised when no active keys remain for a provider."""


async def get_active_key(provider: str) -> str:
    """
    Return the least-recently-used active key for `provider`.
    Falls back to env var (SERPER_API_KEY, FIRECRAWL_API_KEY, etc.) if pool is empty.
    """
    sb = get_supabase()
    try:
        r = (
            sb.table("api_key_pool")
            .select("id, key_value")
            .eq("provider", provider)
            .eq("status", "active")
            .order("last_used_at", desc=False, nullsfirst=True)
            .limit(1)
            .execute()
        )
        if r.data:
            row = r.data[0]
            sb.table("api_key_pool").update({
                "last_used_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", row["id"]).execute()
            return row["key_value"]
    except Exception:
        pass  # table may not exist yet

    # Env fallback
    env_map = {
        "serper": "SERPER_API_KEY",
        "firecrawl": "FIRECRAWL_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "gemini": "GOOGLE_API_KEY",
        "groq": "GROQ_API_KEY",
        "openai": "OPENAI_API_KEY",
    }
    env_key = os.getenv(env_map.get(provider, ""), "")
    if env_key:
        return env_key
    raise KeyPoolExhausted(f"No active keys for provider={provider}")


async def mark_exhausted(provider: str, key_value: str) -> None:
    """Flip a key to exhausted after 402/429/quota error."""
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "exhausted",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }).eq("provider", provider).eq("key_value", key_value).execute()
    except Exception:
        pass


async def increment_usage(provider: str, key_value: str, amount: int = 1) -> None:
    sb = get_supabase()
    try:
        # Simple increment; for production use RPC
        r = (
            sb.table("api_key_pool")
            .select("id, credits_used")
            .eq("provider", provider)
            .eq("key_value", key_value)
            .limit(1)
            .execute()
        )
        if r.data:
            row = r.data[0]
            sb.table("api_key_pool").update({
                "credits_used": (row.get("credits_used") or 0) + amount,
                "last_used_at": datetime.now(timezone.utc).isoformat(),
            }).eq("id", row["id"]).execute()
    except Exception:
        pass


async def with_key_rotation(provider: str, call_fn, max_retries: int = 5):
    """
    Execute `call_fn(api_key)` with automatic rotation on quota errors.
    call_fn must be an async function that accepts a single string (the key).
    Raises KeyPoolExhausted if all keys fail.
    """
    tried = set()
    last_err = None
    for _ in range(max_retries):
        try:
            key = await get_active_key(provider)
            if key in tried:
                # Only one key left and it failed already
                break
            tried.add(key)
            try:
                result = await call_fn(key)
                await increment_usage(provider, key)
                return result
            except Exception as e:
                err_str = str(e).lower()
                if any(x in err_str for x in ("402", "429", "quota", "rate limit", "insufficient", "credit")):
                    await mark_exhausted(provider, key)
                    last_err = e
                    continue
                raise
        except KeyPoolExhausted as e:
            last_err = e
            break
    raise KeyPoolExhausted(f"All keys exhausted for {provider}: {last_err}")
