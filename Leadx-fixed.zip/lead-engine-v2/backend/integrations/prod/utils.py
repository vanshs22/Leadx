"""
Shared production helpers: phone, domain, fingerprint, email validation, logging.
"""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Optional

logger = logging.getLogger("lead_engine")

EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
PHONE_EXTRACT_RE = re.compile(r"(\+?1?\s?[\.\-]?\(?\d{3}\)?[\s.\-]?\d{3}[\s.\-]?\d{4})")
EMAIL_EXTRACT_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")

DISPOSABLE_DOMAINS = {
    "mailinator.com", "guerrillamail.com", "tempmail.com", "throwaway.email",
    "yopmail.com", "sharklasers.com", "10minutemail.com", "trashmail.com",
}

FALSE_EMAIL_MARKERS = {
    "example.com", "yourdomain", "sentry", "wixpress", "cloudflare",
    "schema.org", "email.com", "domain.com", "test.com", "localhost",
    "noreply", "no-reply", "donotreply",
}


def normalize_phone(phone: Optional[str]) -> Optional[str]:
    if not phone:
        return None
    digits = re.sub(r"[^0-9]", "", phone)
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) == 10:
        return digits
    if len(digits) > 10:
        return digits[-10:]  # take last 10 as best effort for US-centric
    return None


def to_e164(phone: Optional[str], default_country: str = "1") -> Optional[str]:
    n = normalize_phone(phone)
    if not n:
        return None
    return f"+{default_country}{n}"


def extract_domain(url: Optional[str]) -> Optional[str]:
    if not url:
        return None
    u = re.sub(r"^https?://(www\.)?", "", url.strip(), flags=re.I)
    u = u.split("/")[0].split("?")[0].lower()
    return u or None


def fingerprint(name: str, phone: Optional[str], website: Optional[str]) -> str:
    raw = f"{(name or '').lower().strip()}|{normalize_phone(phone) or ''}|{extract_domain(website) or ''}"
    return hashlib.md5(raw.encode()).hexdigest()


def is_valid_email(email: Optional[str]) -> bool:
    if not email or not EMAIL_RE.match(email):
        return False
    el = email.lower()
    domain = el.split("@")[-1]
    if domain in DISPOSABLE_DOMAINS:
        return False
    if any(m in el for m in FALSE_EMAIL_MARKERS):
        return False
    return True


def extract_emails(html: str) -> list[str]:
    found = EMAIL_EXTRACT_RE.findall(html or "")
    out, seen = [], set()
    for e in found:
        el = e.lower()
        if el in seen or not is_valid_email(e):
            continue
        seen.add(el)
        out.append(e)
    return out


def extract_phones(html: str) -> list[str]:
    found = PHONE_EXTRACT_RE.findall(html or "")
    out, seen = [], set()
    for p in found:
        n = normalize_phone(p)
        if n and n not in seen:
            seen.add(n)
            out.append(p.strip())
    return out[:3]


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )
