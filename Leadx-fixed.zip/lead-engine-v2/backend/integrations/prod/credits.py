"""
Auto-credit usage when a delivered lead's phone/email is later found dead.
Trust/SLA feature — refund quota, log credit reason.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.credits")


def _sb():
    return get_supabase()


def _period_start() -> str:
    return datetime.now(timezone.utc).replace(day=1).date().isoformat()


async def credit_dead_contact(
    tenant_id: str,
    assignment_id: str,
    credit_type: str,  # dead_phone | dead_email | bounce | closed_business
    detail: Optional[dict] = None,
) -> dict:
    """
    1. Insert lead_credits row
    2. Decrement usage_log for current period
    3. Optionally mark assignment status
    """
    if credit_type not in ("dead_phone", "dead_email", "bounce", "closed_business", "duplicate", "manual"):
        return {"ok": False, "error": "invalid_credit_type"}

    sb = _sb()
    period = _period_start()

    row = (
        sb.table("lead_assignments")
        .select("id, lead_id, status")
        .eq("id", assignment_id)
        .eq("tenant_id", tenant_id)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        return {"ok": False, "error": "assignment_not_found"}

    # Idempotent: don't double-credit same assignment + type
    existing = (
        sb.table("lead_credits")
        .select("id")
        .eq("assignment_id", assignment_id)
        .eq("credit_type", credit_type)
        .limit(1)
        .execute()
        .data or []
    )
    if existing:
        return {"ok": True, "already_credited": True}

    sb.table("lead_credits").insert({
        "tenant_id": tenant_id,
        "assignment_id": assignment_id,
        "lead_id": row[0].get("lead_id"),
        "credit_type": credit_type,
        "amount": 1,
        "period": period,
        "detail": detail or {},
    }).execute()

    try:
        sb.rpc("credit_tenant_usage", {
            "p_tenant_id": tenant_id,
            "p_period": period,
            "p_amount": 1,
        }).execute()
    except Exception:
        # Fallback manual update
        usage = (
            sb.table("usage_log")
            .select("id, leads_delivered")
            .eq("tenant_id", tenant_id)
            .eq("period", period)
            .limit(1)
            .execute()
            .data
        )
        if usage:
            new_val = max(0, int(usage[0].get("leads_delivered") or 0) - 1)
            sb.table("usage_log").update({"leads_delivered": new_val}).eq("id", usage[0]["id"]).execute()

    return {"ok": True, "credited": 1, "period": period, "credit_type": credit_type}


async def verify_and_credit_if_dead(
    tenant_id: str,
    assignment_id: str,
    phone: Optional[str] = None,
    email: Optional[str] = None,
) -> dict:
    """
    Re-run Twilio lookup / MX check; credit if dead.
    """
    from backend.integrations.prod.verify import verify_phone_twilio, verify_email_full

    results = {}
    if phone:
        pv = await verify_phone_twilio(phone)
        results["phone"] = pv
        if pv.get("valid") is False:
            return await credit_dead_contact(
                tenant_id, assignment_id, "dead_phone", detail=pv
            )
    if email:
        ev = await verify_email_full(email)
        results["email"] = ev
        if ev.get("valid") is False and ev.get("syntax_ok"):
            # syntax ok but no MX → credit
            return await credit_dead_contact(
                tenant_id, assignment_id, "dead_email", detail=ev
            )
    return {"ok": True, "credited": 0, "checks": results}
