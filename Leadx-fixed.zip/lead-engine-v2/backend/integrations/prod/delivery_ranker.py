"""
Rank & filter leads for delivery — high quality, contactable, non-redundant.

After enrich + score, only the best candidates should reach the client.
"""
from __future__ import annotations

from typing import Any, Optional


def contactability(lead: dict) -> tuple[int, list[str]]:
    """0-100: can the client actually reach this business?"""
    score = 0
    reasons = []
    if lead.get("phone_normalized") or lead.get("phone_e164") or lead.get("phone"):
        score += 40
        reasons.append("phone")
    if lead.get("email") and lead.get("email_valid") is not False:
        score += 35
        reasons.append("email")
    elif lead.get("email"):
        score += 15
        reasons.append("email_unverified")
    if lead.get("website"):
        score += 10
        reasons.append("website")
    if lead.get("linkedin_url") or (lead.get("social_links") or {}).get("linkedin"):
        score += 8
        reasons.append("linkedin")
    if lead.get("owner_name") or lead.get("decision_maker_name"):
        score += 7
        reasons.append("named_dm")
    return min(100, score), reasons


def composite_quality(lead: dict) -> int:
    """
    Single rank score for delivery order.
    Combines deterministic score, intent, discovery, contactability, multi-source.
    """
    base = int(lead.get("score") or lead.get("total_score") or 0)
    intent = int(lead.get("intent_score") or 0)
    disc = int(lead.get("discovery_quality") or 50)
    contact, _ = contactability(lead)
    multi = min(20, 8 * max(0, len(lead.get("sources_hit") or []) - 1))

    # Weighted blend
    return int(
        0.40 * base
        + 0.20 * intent
        + 0.15 * disc
        + 0.20 * contact
        + 0.05 * (multi * 5)  # multi already 0-20
    )


def is_contactable(lead: dict, require: str = "phone_or_email") -> bool:
    has_phone = bool(lead.get("phone_normalized") or lead.get("phone_e164") or lead.get("phone"))
    has_email = bool(lead.get("email") and lead.get("email_valid") is not False)
    if require == "phone":
        return has_phone
    if require == "email":
        return has_email
    if require == "phone_and_email":
        return has_phone and has_email
    # phone_or_email (default)
    return has_phone or has_email


def is_deliverable(
    lead: dict,
    *,
    allow_tier_b: bool = False,
    require_contact: str = "phone_or_email",
    min_composite: int = 55,
    min_score: int = 50,
) -> tuple[bool, str]:
    if (lead.get("business_status") or "").upper() == "CLOSED":
        return False, "closed"
    tier = (lead.get("tier") or "C").upper()
    allowed = {"A", "B"} if allow_tier_b else {"A"}
    if tier not in allowed:
        # Allow high composite even if tier B when allow_tier_b
        if not (allow_tier_b and tier == "B"):
            if tier == "C" and composite_quality(lead) < 70:
                return False, f"tier={tier}"
    if not is_contactable(lead, require_contact):
        return False, "not_contactable"
    if int(lead.get("score") or 0) < min_score and composite_quality(lead) < min_composite:
        return False, "low_score"
    if composite_quality(lead) < min_composite - 10:
        return False, "low_composite"
    return True, "ok"


def rank_for_delivery(
    leads: list[dict],
    *,
    allow_tier_b: bool = False,
    require_contact: str = "phone_or_email",
    min_composite: int = 55,
    max_deliver: Optional[int] = None,
    prefer_multi_source: bool = True,
) -> list[dict]:
    """
    Filter to contactable high-quality leads, sort best-first, optional cap.
    Non-redundant input assumed (entity resolution already run).
    """
    ranked = []
    for lead in leads:
        ok, reason = is_deliverable(
            lead,
            allow_tier_b=allow_tier_b,
            require_contact=require_contact,
            min_composite=min_composite,
        )
        lead["delivery_ok"] = ok
        lead["delivery_reason"] = reason
        lead["composite_quality"] = composite_quality(lead)
        lead["contactability"], lead["contact_channels"] = contactability(lead)
        if ok:
            ranked.append(lead)

    def sort_key(x: dict):
        multi = len(x.get("sources_hit") or []) if prefer_multi_source else 0
        return (
            multi,
            x.get("composite_quality") or 0,
            x.get("intent_score") or 0,
            x.get("score") or 0,
        )

    ranked.sort(key=sort_key, reverse=True)
    if max_deliver is not None and max_deliver > 0:
        ranked = ranked[:max_deliver]
    return ranked


def diversity_cap(
    leads: list[dict],
    *,
    max_per_domain: int = 1,
    max_per_name_prefix: int = 2,
) -> list[dict]:
    """
    Avoid delivering 5 branches of the same chain in one batch.
    """
    dom_count: dict[str, int] = {}
    name_count: dict[str, int] = {}
    out = []
    for lead in leads:
        dom = _domain_key_safe(lead)
        prefix = (lead.get("name") or "")[:12].lower()
        if dom:
            if dom_count.get(dom, 0) >= max_per_domain:
                continue
        if prefix and name_count.get(prefix, 0) >= max_per_name_prefix:
            continue
        out.append(lead)
        if dom:
            dom_count[dom] = dom_count.get(dom, 0) + 1
        if prefix:
            name_count[prefix] = name_count.get(prefix, 0) + 1
    return out


def _domain_key_safe(lead: dict) -> Optional[str]:
    try:
        from backend.integrations.prod.entity_resolution import _domain_key
        return _domain_key(lead)
    except Exception:
        return None
