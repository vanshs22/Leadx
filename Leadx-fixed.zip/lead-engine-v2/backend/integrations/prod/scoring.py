"""
Production scoring with:
- MX-validated email only gets full points
- Optional tenant win/loss weight multipliers
- Freshness decay
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from backend.integrations.prod.verify import score_freshness_multiplier

INDUSTRY_KEYWORDS = {
    "medspa": ["botox", "filler", "laser", "facial", "aesthetics", "microneedling", "hydrafacial"],
    "salon": ["hair", "color", "cut", "blowout", "keratin", "nails", "balayage"],
    "gym": ["training", "yoga", "pilates", "crossfit", "fitness"],
    "dental": ["dental", "teeth", "whitening", "implant", "orthodont"],
    "wellness": ["massage", "chiropractic", "acupuncture", "wellness", "therapy"],
}


def score_lead_v3(
    lead: dict,
    industry: str = "medspa",
    weights: Optional[dict] = None,
    scored_at: Optional[datetime] = None,
) -> tuple[int, str, str, dict]:
    """
    Returns (score, tier, reasoning, parts).
    parts used for feedback / debugging.
    """
    weights = weights or {}
    parts: dict[str, int] = {}
    reasons: list[str] = []

    status = (lead.get("business_status") or "OPERATIONAL").upper()
    if status == "CLOSED":
        return 0, "C", "CLOSED — rejected", {"closed": 0}
    if status == "TEMPORARILY_CLOSED":
        parts["temp_closed"] = -15
        reasons.append("-15 temporarily closed")

    # Website
    if lead.get("website") or lead.get("has_website"):
        parts["website"] = 12
        reasons.append("+12 website")
    else:
        reasons.append("0 no website")

    # Phone — bonus if Twilio verified
    if lead.get("phone_normalized") or lead.get("phone"):
        pts = 12
        if lead.get("phone_verified") is True:
            pts = 16
            reasons.append("+16 phone (verified)")
        elif lead.get("phone_verified") is False:
            pts = 4
            reasons.append("+4 phone (failed verify)")
        else:
            reasons.append("+12 phone")
        parts["phone"] = pts
    else:
        reasons.append("0 no phone")

    # Email — FULL points only if MX-valid
    if lead.get("email") and lead.get("email_valid") is True:
        parts["email"] = 22
        reasons.append("+22 email (MX ok)")
    elif lead.get("email") and lead.get("email_mx_ok") is False:
        parts["email"] = 4
        reasons.append("+4 email (no MX)")
    elif lead.get("email"):
        parts["email"] = 10
        reasons.append("+10 email (unverified MX)")
    else:
        reasons.append("0 no email")

    # Booking
    if lead.get("has_booking") or lead.get("has_online_booking"):
        parts["booking"] = 14
        reasons.append(f"+14 booking ({lead.get('booking_platform') or 'yes'})")
    else:
        parts["booking"] = 4
        reasons.append("+4 no booking (opportunity)")

    # Reviews
    rating = float(lead.get("google_rating") or 0)
    reviews = int(lead.get("review_count") or 0)
    if rating >= 4.5 and reviews >= 50:
        parts["reviews"] = 14
        reasons.append(f"+14 strong reviews ({rating}★/{reviews})")
    elif rating >= 4.0 and reviews >= 15:
        parts["reviews"] = 9
        reasons.append(f"+9 good reviews ({rating}★/{reviews})")
    elif reviews > 0:
        parts["reviews"] = 4
        reasons.append(f"+4 some reviews ({reviews})")

    if rating >= 4.5:
        parts["rating"] = parts.get("rating", 0)  # tracked for weights

    # Services fit
    services = [str(s).lower() for s in (lead.get("services") or [])]
    kws = INDUSTRY_KEYWORDS.get(industry.lower().replace(" ", ""), [])
    blob = " ".join(services)
    if any(k in blob for k in kws):
        parts["services"] = 10
        reasons.append("+10 service fit")

    if lead.get("owner_name"):
        parts["owner"] = 6
        reasons.append("+6 owner name")

    if lead.get("social_links"):
        parts["social"] = 4
        reasons.append("+4 social")

    # Apply tenant win/loss multipliers to key signals
    w_email = weights.get("email", 1.0)
    w_booking = weights.get("booking", 1.0)
    w_reviews = weights.get("reviews", 1.0)
    w_owner = weights.get("owner", 1.0)

    adjusted = 0
    for k, v in parts.items():
        if k == "email":
            v = int(round(v * w_email))
        elif k == "booking":
            v = int(round(v * w_booking))
        elif k == "reviews":
            v = int(round(v * w_reviews))
        elif k == "owner":
            v = int(round(v * w_owner))
        adjusted += v

    # Freshness decay
    mult = score_freshness_multiplier(scored_at if scored_at is not None else lead.get("_scored_at"))
    if mult < 1.0:
        reasons.append(f"×{mult:.2f} freshness")
    score = int(round(min(100, max(0, adjusted)) * mult))

    if score >= 72:
        tier = "A"
    elif score >= 48:
        tier = "B"
    else:
        tier = "C"

    return score, tier, "; ".join(reasons), parts
