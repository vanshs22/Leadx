"""
Production Lead Discovery — Serper Maps (paginated, key-pooled) + organic supplement.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Optional

import httpx

from backend.integrations.prod.key_pool import with_key_rotation, KeyPoolExhausted
from backend.integrations.prod.utils import (
    normalize_phone, to_e164, extract_domain, fingerprint,
)

logger = logging.getLogger("lead_engine.discovery")

SERPER_MAPS = "https://google.serper.dev/maps"
SERPER_SEARCH = "https://google.serper.dev/search"

DEFAULT_QUERIES = {
    "medspa": ["med spa", "medical spa", "aesthetics clinic", "botox clinic"],
    "salon": ["hair salon", "beauty salon", "nail salon", "barber shop"],
    "gym": ["gym", "fitness center", "personal training", "crossfit"],
    "dental": ["dentist", "dental clinic", "cosmetic dentist"],
    "wellness": ["wellness center", "chiropractic", "massage therapy"],
}


def normalize_maps_result(raw: dict, industry: str, location: str) -> dict:
    phone = raw.get("phoneNumber") or raw.get("phone") or ""
    website = (raw.get("website") or "").strip()
    if website and not website.startswith("http"):
        website = "https://" + website
    name = (raw.get("title") or raw.get("name") or "").strip()
    status = (raw.get("businessStatus") or "OPERATIONAL").upper()
    if status not in ("OPERATIONAL", "CLOSED", "TEMPORARILY_CLOSED"):
        status = "UNKNOWN"

    return {
        "name": name,
        "company_name": name,
        "phone": phone,
        "phone_normalized": normalize_phone(phone),
        "phone_e164": to_e164(phone),
        "address": raw.get("address") or "",
        "city": location.split(",")[0].strip() if location else None,
        "state": None,
        "website": website or None,
        "website_domain": extract_domain(website),
        "category": raw.get("category") or industry,
        "business_status": status,
        "google_rating": raw.get("rating"),
        "review_count": int(raw.get("ratingCount") or raw.get("reviews") or 0),
        "google_place_id": raw.get("placeId"),
        "source": "google_maps_serper",
        "industry": industry,
        "location": location,
        "fingerprint": fingerprint(name, phone, website),
        "has_website": bool(website),
        "raw_data": {
            k: raw.get(k) for k in ("title", "address", "phoneNumber", "website", "rating", "ratingCount", "placeId", "category", "businessStatus")
            if raw.get(k) is not None
        },
    }


async def _serper_maps_page(api_key: str, query: str, location: str, page: int, num: int) -> list[dict]:
    async with httpx.AsyncClient(timeout=45.0) as client:
        resp = await client.post(
            SERPER_MAPS,
            headers={"X-API-KEY": api_key, "Content-Type": "application/json"},
            json={"q": f"{query} {location}".strip(), "num": num, "page": page},
        )
        if resp.status_code in (402, 429):
            raise Exception(f"Serper quota/rate: {resp.status_code} {resp.text[:200]}")
        resp.raise_for_status()
        return resp.json().get("places") or []


async def search_maps_paginated(
    query: str,
    location: str,
    total: int = 100,
    industry: str = "medspa",
    per_page: int = 20,
    page_delay: float = 0.7,
) -> list[dict]:
    all_raw: list[dict] = []
    page = 1
    while len(all_raw) < total:
        try:
            batch = await with_key_rotation(
                "serper",
                lambda key, p=page: _serper_maps_page(key, query, location, p, per_page),
            )
        except KeyPoolExhausted:
            logger.error("Serper key pool exhausted during maps search")
            break
        if not batch:
            break
        all_raw.extend(batch)
        page += 1
        if len(all_raw) < total:
            await asyncio.sleep(page_delay)
    return [normalize_maps_result(r, industry, location) for r in all_raw[:total]]


async def discover_leads(
    industry: str,
    locations: list[str],
    queries: Optional[list[str]] = None,
    limit_per_location: int = 50,
    include_linkedin: bool = True,
    include_instagram: bool = True,
    social_limit_per_source: int = 15,
    social_min_quality: int = 50,
    sources: Optional[dict] = None,
    # Maps is NOT primary — multi-source by default
    include_maps: bool = True,
    include_web: bool = True,
    include_yelp: bool = True,
    include_facebook: bool = True,
) -> list[dict]:
    """
    Multi-source discovery. Maps / LinkedIn / Instagram / Web / Yelp / Facebook
    are peer channels — merge + boost multi-hit businesses.
    """
    enabled = {
        "maps": include_maps,
        "linkedin": include_linkedin,
        "instagram": include_instagram,
        "web": include_web,
        "yelp": include_yelp,
        "facebook": include_facebook,
    }
    if sources:
        enabled.update(sources)

    # Budget: scale maps with limit_per_location; social uses social_limit_per_source
    budget = {
        "maps": limit_per_location if include_maps else 0,
        "linkedin": social_limit_per_source if include_linkedin else 0,
        "instagram": social_limit_per_source if include_instagram else 0,
        "web": max(15, social_limit_per_source) if include_web else 0,
        "yelp": max(10, social_limit_per_source // 2) if include_yelp else 0,
        "facebook": max(10, social_limit_per_source // 2) if include_facebook else 0,
    }

    try:
        from backend.integrations.prod.multi_source_discovery import discover_multi_source
        leads = await discover_multi_source(
            industry=industry,
            locations=locations,
            queries=queries,
            sources=enabled,
            budget=budget,
            min_quality=social_min_quality,
        )
        return leads
    except Exception as e:
        logger.exception("multi-source discovery failed, falling back to maps-only: %s", e)
        # Safe fallback: maps only
        qlist = queries or DEFAULT_QUERIES.get(industry.lower().replace(" ", ""), [industry])
        seen: set[str] = set()
        leads: list[dict] = []
        for location in locations:
            for q in qlist:
                try:
                    batch = await search_maps_paginated(
                        query=q, location=location, total=limit_per_location, industry=industry,
                    )
                except Exception:
                    batch = []
                for lead in batch:
                    fp = lead.get("fingerprint")
                    if not fp or fp in seen:
                        continue
                    if lead.get("business_status") == "CLOSED":
                        continue
                    lead["sources_hit"] = ["maps"]
                    seen.add(fp)
                    leads.append(lead)
                await asyncio.sleep(0.2)
        return leads
