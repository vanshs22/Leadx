"""
Quality Gate + Exclusivity Engine + Scoring for Lead Engine v2.
"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
from typing import Optional
from uuid import UUID

from backend.memory.supabase_client import get_supabase


# ---------------------------------------------------------------------------
# Deterministic scoring (fast, no LLM cost)
# ---------------------------------------------------------------------------
def score_deterministic(lead: dict, industry: str = "medspa") -> tuple[int, str, str]:
    """
    Returns (score 0-100, tier A/B/C, reasoning string).
    Tuned for local-service verticals.
    """
    score = 0
    reasons = []

    # Website presence
    if lead.get("website") or lead.get("has_website"):
        score += 15
        reasons.append("+15 has website")
    else:
        reasons.append("0 no website")

    # Phone
    if lead.get("phone") or lead.get("phone_normalized"):
        score += 15
        reasons.append("+15 has phone")
    else:
        reasons.append("0 no phone")

    # Email (enriched)
    if lead.get("email"):
        score += 20
        reasons.append("+20 has email")
    else:
        reasons.append("0 no email")

    # Booking system = high intent / tech-forward
    if lead.get("has_booking") or lead.get("has_online_booking"):
        score += 15
        reasons.append(f"+15 booking ({lead.get('booking_platform') or 'yes'})")
    else:
        score += 5  # no booking can also be opportunity
        reasons.append("+5 no booking (opportunity)")

    # Reviews / social proof
    rating = float(lead.get("google_rating") or 0)
    reviews = int(lead.get("review_count") or 0)
    if rating >= 4.5 and reviews >= 50:
        score += 15
        reasons.append(f"+15 strong reviews ({rating}★/{reviews})")
    elif rating >= 4.0 and reviews >= 20:
        score += 10
        reasons.append(f"+10 good reviews ({rating}★/{reviews})")
    elif reviews > 0:
        score += 5
        reasons.append(f"+5 some reviews ({reviews})")

    # Business still open
    status = (lead.get("business_status") or "OPERATIONAL").upper()
    if status == "CLOSED":
        score = 0
        reasons = ["CLOSED — killed"]
    elif status == "TEMPORARILY_CLOSED":
        score = max(0, score - 20)
        reasons.append("-20 temporarily closed")

    # Services match industry keywords (simple)
    services = [s.lower() for s in (lead.get("services") or [])]
    industry_kw = {
        "medspa": ["botox", "filler", "laser", "facial", "aesthetics", "microneedling"],
        "salon": ["hair", "color", "cut", "blowout", "keratin", "nails"],
        "gym": ["training", "yoga", "pilates", "crossfit", "fitness"],
        "dental": ["dental", "teeth", "whitening", "implant", "orthodont"],
    }
    kws = industry_kw.get(industry.lower().replace(" ", ""), [])
    if any(k in " ".join(services) for k in kws):
        score += 10
        reasons.append("+10 service fit")

    score = min(100, max(0, score))
    if score >= 70:
        tier = "A"
    elif score >= 45:
        tier = "B"
    else:
        tier = "C"

    return score, tier, "; ".join(reasons)


# ---------------------------------------------------------------------------
# Quality Gate
# ---------------------------------------------------------------------------
def passes_quality_gate(
    lead: dict,
    allow_tier_b: bool = False,
    min_enrichment_fields: int = 2,
) -> tuple[bool, str]:
    """
    A lead is deliverable only if:
    - tier A (or B if plan allows)
    - business_status != CLOSED
    - phone_normalized + website present
    - ≥ min_enrichment_fields populated
    """
    tier = lead.get("tier") or "C"
    allowed = {"A"} if not allow_tier_b else {"A", "B"}
    if tier not in allowed:
        return False, f"tier={tier} not allowed"

    status = (lead.get("business_status") or "OPERATIONAL").upper()
    if status == "CLOSED":
        return False, "business closed"

    if not lead.get("phone_normalized") and not lead.get("phone"):
        return False, "missing phone"
    if not lead.get("website"):
        return False, "missing website"

    fields = 0
    if lead.get("email"):
        fields += 1
    if lead.get("has_booking") or lead.get("has_online_booking"):
        fields += 1
    if lead.get("services"):
        fields += 1
    if lead.get("social_links"):
        fields += 1
    if fields < min_enrichment_fields:
        return False, f"only {fields} enrichment fields (need {min_enrichment_fields})"

    return True, "ok"


# ---------------------------------------------------------------------------
# Exclusivity check
# ---------------------------------------------------------------------------
async def is_exclusive_conflict(
    lead_id: str,
    tenant_id: str,
    vertical: str,
    geo_list: list[str],
) -> bool:
    """
    True if another tenant with exclusivity='exclusive' and overlapping
    vertical + geo already holds this lead.
    """
    sb = get_supabase()
    try:
        # Find all assignments for this lead that are exclusive
        r = (
            sb.table("lead_assignments")
            .select("tenant_id, icp_id, tenants!inner(id), icp_profiles!inner(vertical, geo, exclusivity)")
            .eq("lead_id", lead_id)
            .neq("tenant_id", tenant_id)
            .execute()
        )
        # Simplified: if any other exclusive assignment exists for same vertical, conflict
        # Full geo intersection is done in application logic below
        for row in (r.data or []):
            # Because of join limitations we do a second query if needed
            pass
    except Exception:
        pass

    # Practical implementation: query assignments + join manually
    try:
        assigns = (
            sb.table("lead_assignments")
            .select("tenant_id, icp_id")
            .eq("lead_id", lead_id)
            .neq("tenant_id", tenant_id)
            .execute()
            .data or []
        )
        for a in assigns:
            if not a.get("icp_id"):
                continue
            icp = (
                sb.table("icp_profiles")
                .select("vertical, geo, exclusivity")
                .eq("id", a["icp_id"])
                .limit(1)
                .execute()
                .data
            )
            if not icp:
                continue
            icp = icp[0]
            if icp.get("exclusivity") != "exclusive":
                continue
            if icp.get("vertical", "").lower() != vertical.lower():
                continue
            other_geo = set(icp.get("geo") or [])
            my_geo = set(geo_list or [])
            if other_geo & my_geo or not other_geo or not my_geo:
                return True  # overlapping territory
    except Exception:
        return False  # fail open on DB errors during development
    return False


async def assign_lead_if_available(
    lead_id: str,
    tenant_id: str,
    icp_id: Optional[str],
    vertical: str,
    geo: list[str],
    delivery_channel: str = "telegram",
) -> dict:
    """
    Run exclusivity check + 90-day recency check, then insert assignment.
    Returns {"assigned": bool, "reason": str}.
    """
    sb = get_supabase()

    # Recency: already delivered to this tenant in last 90 days?
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        recent = (
            sb.table("lead_assignments")
            .select("id")
            .eq("lead_id", lead_id)
            .eq("tenant_id", tenant_id)
            .gte("delivered_at", cutoff)
            .limit(1)
            .execute()
            .data
        )
        if recent:
            return {"assigned": False, "reason": "already_delivered_90d"}
    except Exception:
        pass

    if await is_exclusive_conflict(lead_id, tenant_id, vertical, geo):
        return {"assigned": False, "reason": "exclusivity_conflict"}

    try:
        sb.table("lead_assignments").upsert({
            "lead_id": lead_id,
            "tenant_id": tenant_id,
            "icp_id": icp_id,
            "delivered_at": datetime.now(timezone.utc).isoformat(),
            "status": "new",
            "delivery_channel": delivery_channel,
        }, on_conflict="lead_id,tenant_id").execute()
        return {"assigned": True, "reason": "ok"}
    except Exception as e:
        return {"assigned": False, "reason": str(e)}


async def bump_usage(tenant_id: str, tier: str) -> None:
    """Increment usage_log for the current month."""
    sb = get_supabase()
    period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
    try:
        existing = (
            sb.table("usage_log")
            .select("id, leads_delivered, tier_a_count, tier_b_count, tier_c_count")
            .eq("tenant_id", tenant_id)
            .eq("period", period)
            .limit(1)
            .execute()
            .data
        )
        if existing:
            row = existing[0]
            updates = {
                "leads_delivered": (row.get("leads_delivered") or 0) + 1,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            key = f"tier_{tier.lower()}_count"
            if key in ("tier_a_count", "tier_b_count", "tier_c_count"):
                updates[key] = (row.get(key) or 0) + 1
            sb.table("usage_log").update(updates).eq("id", row["id"]).execute()
        else:
            sb.table("usage_log").insert({
                "tenant_id": tenant_id,
                "period": period,
                "leads_delivered": 1,
                "tier_a_count": 1 if tier == "A" else 0,
                "tier_b_count": 1 if tier == "B" else 0,
                "tier_c_count": 1 if tier == "C" else 0,
            }).execute()
    except Exception:
        pass
