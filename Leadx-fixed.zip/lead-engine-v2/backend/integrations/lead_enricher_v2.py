"""
Lead Enricher v2
Primary: Scrapling (anti-bot, adaptive)
Parallel: Crawl4AI (clean markdown for LLM)
Last resort: Firecrawl (key-pooled)
Structured extraction: ScrapeGraphAI (falls through free LLM tiers)
"""
from __future__ import annotations
import asyncio
import re
from typing import Optional

from backend.integrations.key_pool import with_key_rotation, KeyPoolExhausted

BOOKING_PLATFORMS = [
    ("mindbody", "Mindbody"), ("vagaro", "Vagaro"), ("fresha", "Fresha"),
    ("booksy", "Booksy"), ("acuityscheduling", "Acuity"), ("calendly", "Calendly"),
    ("cal.com", "Cal.com"), ("square", "Square Appointments"), ("zenoti", "Zenoti"),
    ("boulevard", "Boulevard"), ("booker", "Booker"), ("glofox", "Glofox"),
    ("schedulicity", "Schedulicity"), ("setmore", "Setmore"), ("simplybook", "SimplyBook"),
]

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(\+?1?\s?[\.\-]?\(?\d{3}\)?[\s.\-]?\d{3}[\s.\-]?\d{4})")
INSTAGRAM_RE = re.compile(r"instagram\.com/([a-zA-Z0-9._]+)")


def _detect_booking(html: str) -> tuple[bool, Optional[str]]:
    lower = html.lower()
    for kw, name in BOOKING_PLATFORMS:
        if kw in lower:
            return True, name
    return False, None


def _extract_emails(html: str) -> list[str]:
    found = EMAIL_RE.findall(html)
    skip = {"example.com", "yourdomain", "sentry", "wixpress", "cloudflare", "schema"}
    clean = []
    seen = set()
    for e in found:
        el = e.lower()
        if any(s in el for s in skip) or el in seen:
            continue
        seen.add(el)
        clean.append(e)
    return clean


def _extract_phones(html: str) -> list[str]:
    found = PHONE_RE.findall(html)
    seen, out = set(), []
    for p in found:
        digits = re.sub(r"[^\d]", "", p)
        if len(digits) >= 10 and digits not in seen:
            seen.add(digits)
            out.append(p.strip())
    return out[:3]


# ---------------------------------------------------------------------------
# Layer 1 — Scrapling (primary website fetch)
# ---------------------------------------------------------------------------
async def fetch_with_scrapling(url: str, timeout: int = 20) -> dict:
    result = {"html": "", "text": "", "method": "scrapling", "ok": False}
    try:
        from scrapling import AsyncFetcher
        fetcher = AsyncFetcher(auto_match=False)
        page = await fetcher.get(url, timeout=timeout)
        html = str(page.html) if hasattr(page, "html") else ""
        text = page.get_all_text(separator=" ") if hasattr(page, "get_all_text") else html
        result.update(html=html, text=text, ok=bool(html))
    except ImportError:
        # Fallback to plain httpx
        try:
            import httpx
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                r = await client.get(url, headers={"User-Agent": "Mozilla/5.0 (compatible; LeadBot/2.0)"})
                result.update(html=r.text, text=r.text, ok=True, method="httpx")
        except Exception as e:
            result["error"] = str(e)
    except Exception as e:
        result["error"] = str(e)
    return result


# ---------------------------------------------------------------------------
# Layer 2 — Crawl4AI (markdown normalization, parallel)
# ---------------------------------------------------------------------------
async def fetch_with_crawl4ai(url: str) -> dict:
    result = {"markdown": "", "method": "crawl4ai", "ok": False}
    try:
        from crawl4ai import AsyncWebCrawler
        async with AsyncWebCrawler(verbose=False) as crawler:
            res = await crawler.arun(url=url)
            md = getattr(res, "markdown", None) or getattr(res, "cleaned_html", "") or ""
            result.update(markdown=str(md), ok=bool(md))
    except Exception as e:
        result["error"] = str(e)
    return result


# ---------------------------------------------------------------------------
# Layer 3 — Firecrawl (last resort, key-pooled)
# ---------------------------------------------------------------------------
async def fetch_with_firecrawl(url: str) -> dict:
    result = {"html": "", "markdown": "", "method": "firecrawl", "ok": False}

    async def _call(api_key: str):
        import httpx
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                "https://api.firecrawl.dev/v1/scrape",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"url": url, "formats": ["markdown", "html"]},
            )
            if resp.status_code in (402, 429):
                raise Exception(f"Firecrawl quota: {resp.status_code}")
            resp.raise_for_status()
            data = resp.json().get("data", {})
            return data.get("html", ""), data.get("markdown", "")

    try:
        html, md = await with_key_rotation("firecrawl", _call)
        result.update(html=html or "", markdown=md or "", ok=True)
    except (KeyPoolExhausted, Exception) as e:
        result["error"] = str(e)
    return result


# ---------------------------------------------------------------------------
# Structured extraction via ScrapeGraphAI (optional, free LLM tiers)
# ---------------------------------------------------------------------------
async def extract_structured(markdown_or_html: str, website: str) -> dict:
    """
    Use ScrapeGraphAI if available; otherwise regex heuristics.
    Falls through Gemini / Groq free tiers via key pool when configured.
    """
    extracted = {
        "email": None,
        "emails": [],
        "phone_from_web": None,
        "has_booking": False,
        "booking_platform": None,
        "services": [],
        "social_links": {},
        "owner_name": None,
    }

    # Always run cheap regex first
    extracted["emails"] = _extract_emails(markdown_or_html)
    extracted["email"] = extracted["emails"][0] if extracted["emails"] else None
    phones = _extract_phones(markdown_or_html)
    if phones:
        extracted["phone_from_web"] = phones[0]
    extracted["has_booking"], extracted["booking_platform"] = _detect_booking(markdown_or_html)

    ig = INSTAGRAM_RE.search(markdown_or_html)
    if ig and ig.group(1) not in ("p", "reel", "stories", "explore"):
        extracted["social_links"]["instagram"] = ig.group(1)

    # Optional ScrapeGraphAI upgrade
    try:
        from scrapegraphai.graphs import SmartScraperGraph
        # Prefer free tiers; user must have keys in pool or env
        graph_config = {
            "llm": {
                "model": "gemini-1.5-flash",  # free tier friendly
                "temperature": 0,
            },
            "verbose": False,
        }
        prompt = (
            "Extract from this local business page: primary email, phone, "
            "list of services offered, whether online booking exists and which platform, "
            "owner or manager name if mentioned. Return JSON."
        )
        # ScrapeGraphAI expects a source; we feed markdown
        # This is best-effort; failures are silent
        graph = SmartScraperGraph(prompt=prompt, source=markdown_or_html[:15000], config=graph_config)
        out = graph.run()
        if isinstance(out, dict):
            if out.get("email") and not extracted["email"]:
                extracted["email"] = out["email"]
            if out.get("services"):
                extracted["services"] = out["services"] if isinstance(out["services"], list) else [out["services"]]
            if out.get("owner_name"):
                extracted["owner_name"] = out["owner_name"]
    except Exception:
        pass

    return extracted


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
async def enrich_one_v2(website: str, also_crawl4ai: bool = True) -> dict:
    """
    Full enrichment cascade for a single website.
    Returns a dict ready to upsert into `enrichment` table.
    """
    if not website or not website.startswith("http"):
        return {"enriched": False, "error": "invalid_url"}

    out = {
        "website": website,
        "email": None,
        "emails": [],
        "phone_from_web": None,
        "has_booking": False,
        "booking_platform": None,
        "services": [],
        "social_links": {},
        "markdown_summary": None,
        "raw_extraction": {},
        "enrichment_method": None,
        "enriched": False,
    }

    # 1. Scrapling primary
    scrap = await fetch_with_scrapling(website)
    html = scrap.get("html", "")
    text = scrap.get("text", "")

    # 2. Parallel Crawl4AI for clean markdown
    md = ""
    if also_crawl4ai:
        c4 = await fetch_with_crawl4ai(website)
        md = c4.get("markdown", "")
        if md:
            out["markdown_summary"] = md[:4000]

    content = md or html or text
    method = scrap.get("method", "scrapling")

    # 3. If both failed, try Firecrawl
    if not content:
        fc = await fetch_with_firecrawl(website)
        content = fc.get("markdown") or fc.get("html") or ""
        method = "firecrawl"
        if fc.get("markdown"):
            out["markdown_summary"] = fc["markdown"][:4000]

    if not content:
        out["error"] = scrap.get("error") or "all_fetchers_failed"
        return out

    # 4. Structured extraction
    extracted = await extract_structured(content, website)
    out.update(extracted)
    out["enrichment_method"] = method
    out["enriched"] = bool(
        out["email"] or out["has_booking"] or out["services"] or out["phone_from_web"]
    )
    out["raw_extraction"] = extracted
    return out


async def enrich_batch_v2(
    leads: list[dict],
    max_concurrent: int = 6,
    also_crawl4ai: bool = True,
) -> list[dict]:
    """Enrich a list of leads (must have 'website' key)."""
    sem = asyncio.Semaphore(max_concurrent)

    async def _one(lead: dict) -> dict:
        url = lead.get("website")
        if not url:
            return lead
        async with sem:
            info = await enrich_one_v2(url, also_crawl4ai=also_crawl4ai)
            if info.get("enriched"):
                lead["email"] = info.get("email") or lead.get("email")
                lead["emails"] = info.get("emails", [])
                if info.get("phone_from_web") and not lead.get("phone"):
                    lead["phone"] = info["phone_from_web"]
                    lead["phone_normalized"] = re.sub(r"[^\d]", "", info["phone_from_web"])
                lead["has_booking"] = info.get("has_booking", False)
                lead["booking_platform"] = info.get("booking_platform")
                lead["services"] = info.get("services", [])
                lead["social_links"] = info.get("social_links", {})
                lead["markdown_summary"] = info.get("markdown_summary")
                lead["enrichment_method"] = info.get("enrichment_method")
                lead["enriched"] = True
            else:
                lead["enrichment_failed"] = True
                lead["enrichment_error"] = info.get("error")
            return lead

    return list(await asyncio.gather(*[_one(l) for l in leads]))
