"""
Lead Discovery v2 — Serper.dev (primary, key-pooled) + Scrapling fallback.
Supports pagination for high volume (thousands of leads).
"""
from __future__ import annotations
import asyncio
import hashlib
import re
from typing import Optional

import httpx

from backend.integrations.key_pool import with_key_rotation, KeyPoolExhausted

SERPER_MAPS = "https://google.serper.dev/maps"
SERPER_SEARCH = "https://google.serper.dev/search"


def _normalize_phone(phone: str) -> Optional[str]:
    if not phone:
        return None
    digits = re.sub(r"[^0-9]", "", phone)
    return digits if len(digits) >= 10 else None


def _fingerprint(name: str, phone: str, website: str) -> str:
    norm_web = re.sub(r"^https?://(www\.)?", "", (website or "").lower()).rstrip("/")
    raw = f"{(name or '').lower().strip()}|{_normalize_phone(phone) or ''}|{norm_web}"
    return hashlib.md5(raw.encode()).hexdigest()


def normalize_maps_result(raw: dict, industry: str, location: str) -> dict:
    phone = raw.get("phoneNumber") or raw.get("phone") or ""
    website = raw.get("website") or ""
    name = raw.get("title") or raw.get("name") or ""
    return {
        "name": name,
        "company_name": name,
        "phone": phone,
        "phone_normalized": _normalize_phone(phone),
        "address": raw.get("address") or "",
        "website": website,
        "category": raw.get("category") or industry,
        "business_status": (raw.get("businessStatus") or "OPERATIONAL").upper(),
        "google_rating": raw.get("rating"),
        "review_count": raw.get("ratingCount") or raw.get("reviews") or 0,
        "google_place_id": raw.get("placeId"),
        "source": "google_maps_serper",
        "industry": industry,
        "location": location,
        "fingerprint": _fingerprint(name, phone, website),
        "has_website": bool(website),
        "raw_data": raw,
    }


async def _serper_maps_page(api_key: str, query: str, location: str, page: int = 1, num: int = 20) -> list[dict]:
    async with httpx.AsyncClient(timeout=45) as client:
        resp = await client.post(
            SERPER_MAPS,
            headers={"X-API-KEY": api_key, "Content-Type": "application/json"},
            json={"q": f"{query} {location}", "num": num, "page": page},
        )
        if resp.status_code in (402, 429):
            raise Exception(f"Serper quota/rate: {resp.status_code}")
        resp.raise_for_status()
        return resp.json().get("places", [])


async def search_maps_paginated(
    query: str,
    location: str,
    total: int = 100,
    industry: str = "medspa",
) -> list[dict]:
    """Paginate Serper Maps up to `total` results with key rotation."""
    all_raw = []
    page = 1
    per_page = 20
    while len(all_raw) < total:
        try:
            batch = await with_key_rotation(
                "serper",
                lambda key: _serper_maps_page(key, query, location, page, per_page),
            )
        except KeyPoolExhausted:
            break
        if not batch:
            break
        all_raw.extend(batch)
        page += 1
        if len(all_raw) < total:
            await asyncio.sleep(0.8)
    return [normalize_maps_result(r, industry, location) for r in all_raw[:total]]


async def scrapling_maps_fallback(query: str, location: str, limit: int = 20) -> list[dict]:
    """
    Last-resort discovery when every Serper key is exhausted.
    Uses Scrapling to scrape Google Maps search page (best-effort, may be blocked).
    """
    try:
        from scrapling import AsyncFetcher
        fetcher = AsyncFetcher(auto_match=False)
        url = f"https://www.google.com/maps/search/{query.replace(' ', '+')}+{location.replace(' ', '+')}"
        page = await fetcher.get(url, timeout=30)
        # Very light extraction — real production would use a dedicated Maps parser
        text = page.get_all_text(separator="\n") if hasattr(page, "get_all_text") else str(page.html)
        # This is intentionally minimal; prefer Serper. Returns empty on failure.
        return []
    except Exception:
        return []


async def discover_leads_v2(
    industry: str,
    locations: list[str],
    queries: list[str] | None = None,
    limit_per_location: int = 50,
) -> list[dict]:
    """
    High-volume discovery across multiple locations & query variants.
    Deduplicates by fingerprint.
    """
    if not queries:
        queries = [industry]

    seen = set()
    all_leads = []

    for location in locations:
        for q in queries:
            try:
                batch = await search_maps_paginated(
                    query=q,
                    location=location,
                    total=limit_per_location,
                    industry=industry,
                )
            except Exception:
                batch = await scrapling_maps_fallback(q, location, limit_per_location)

            for lead in batch:
                fp = lead.get("fingerprint")
                if fp and fp not in seen:
                    seen.add(fp)
                    all_leads.append(lead)
            await asyncio.sleep(0.3)

    return all_leads
