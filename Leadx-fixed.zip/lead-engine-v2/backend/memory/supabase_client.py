"""
Supabase client for Lead Engine (service role).
Standalone — does not depend on Automiqo OS host.
"""
from __future__ import annotations

import os
import logging
from functools import lru_cache
from typing import Any

logger = logging.getLogger("lead_engine.supabase")

_client: Any = None


@lru_cache(maxsize=1)
def get_supabase():
    """
    Returns a supabase-py client using the service role key.
    Required env: SUPABASE_URL, SUPABASE_SERVICE_KEY (or SUPABASE_SERVICE_ROLE_KEY).
    """
    global _client
    if _client is not None:
        return _client

    url = os.getenv("SUPABASE_URL", "").rstrip("/")
    key = (
        os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_KEY")
        or ""
    )
    if not url or not key:
        raise RuntimeError(
            "SUPABASE_URL and SUPABASE_SERVICE_KEY (or SUPABASE_SERVICE_ROLE_KEY) must be set"
        )

    try:
        from supabase import create_client
    except ImportError as e:
        raise RuntimeError("pip install supabase") from e

    _client = create_client(url, key)
    logger.info("Supabase client initialized host=%s", url.split("//")[-1][:40])
    return _client


def reset_supabase_client() -> None:
    """For tests."""
    global _client
    _client = None
    get_supabase.cache_clear()
