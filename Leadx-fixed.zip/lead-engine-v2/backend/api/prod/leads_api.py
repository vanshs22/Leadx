"""
Production Leads API v2 — protected by service key (n8n/cron/ops).
Tenant JWT auth lives on CRM routes; this router is operator-facing.
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from backend.middleware.service_auth import require_service_key
from backend.middleware.rate_limit import rate_limit_pipeline, rate_limit_keys, client_ip

router = APIRouter(
    prefix="/leads/v2",
    tags=["leads-v2"],
    dependencies=[Depends(require_service_key)],
)


class PipelineRequest(BaseModel):
    tenant_id: str
    icp_id: Optional[str] = None
    industry: str = "medspa"
    locations: list[str] = Field(default_factory=list)
    queries: list[str] = Field(default_factory=list)
    limit_per_location: int = Field(default=50, ge=1, le=200)
    skip_enrichment: bool = False
    allow_tier_b: bool = False
    max_enrich_concurrent: int = Field(default=6, ge=1, le=20)
    deliver: bool = True
    use_crawl4ai: bool = True
    use_firecrawl: bool = True
    include_linkedin: bool = True
    include_instagram: bool = False
    include_maps: bool = True
    include_web: bool = True
    include_yelp: bool = True
    include_facebook: bool = True
    social_limit_per_source: int = Field(default=15, ge=0, le=50)
    target_new_leads: int = Field(default=0, ge=0, le=50000, description='Net-new leads target; use 5000–15000 for statewide ICPs')
    max_cells_per_run: int = Field(default=40, ge=1, le=150)


class CronRequest(BaseModel):
    limit_per_location: int = Field(default=40, ge=1, le=200)
    skip_enrichment: bool = False
    max_enrich_concurrent: int = Field(default=6, ge=1, le=20)


class AddKeyRequest(BaseModel):
    provider: str
    key_value: str
    label: Optional[str] = None
    credits_limit: Optional[int] = None
    notes: Optional[str] = None


class CreateTenantRequest(BaseModel):
    name: str
    plan: str = "starter"
    leads_per_month_limit: int = 100
    allow_tier_b: bool = False
    delivery_channel: str = "telegram"
    delivery_config: dict = Field(default_factory=dict)


class CreateICPRequest(BaseModel):
    tenant_id: str
    name: str = "default"
    vertical: str
    geo: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    exclusivity: str = "exclusive"


class SuppressionUpload(BaseModel):
    tenant_id: str
    rows: list[dict] = Field(default_factory=list)


class OptOutRequest(BaseModel):
    company_name: str = ""
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None
    reason: str = "requested"
    requested_by: str = "admin"


class CreditRequest(BaseModel):
    tenant_id: str
    assignment_id: str
    credit_type: str = "manual"
    detail: dict = Field(default_factory=dict)


class VerifyCreditRequest(BaseModel):
    tenant_id: str
    assignment_id: str
    phone: Optional[str] = None
    email: Optional[str] = None


@router.post("/pipeline/run")
async def run_pipeline(req: PipelineRequest, request: Request):
    """Full pipeline: discover → enrich → score → gate → assign → deliver."""
    rate_limit_pipeline(req.tenant_id)
    from backend.integrations.prod.pipeline import run_pipeline as _run
    try:
        return await _run(
            tenant_id=req.tenant_id,
            icp_id=req.icp_id,
            industry=req.industry,
            locations=req.locations or None,
            queries=req.queries or None,
            limit_per_location=req.limit_per_location,
            skip_enrichment=req.skip_enrichment,
            allow_tier_b=req.allow_tier_b,
            max_enrich_concurrent=req.max_enrich_concurrent,
            deliver=req.deliver,
            use_crawl4ai=req.use_crawl4ai,
            use_firecrawl=req.use_firecrawl,
            include_linkedin=req.include_linkedin,
            include_instagram=req.include_instagram,
            social_limit_per_source=req.social_limit_per_source,
            include_maps=req.include_maps,
            include_web=req.include_web,
            include_yelp=req.include_yelp,
            include_facebook=req.include_facebook,
            target_new_leads=req.target_new_leads,
            max_cells_per_run=req.max_cells_per_run,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/pipeline/run-all-icps")
async def run_all(req: CronRequest, request: Request):
    rate_limit_pipeline(client_ip(request))
    from backend.integrations.prod.pipeline import run_all_active_icps
    return await run_all_active_icps(
        limit_per_location=req.limit_per_location,
        skip_enrichment=req.skip_enrichment,
        max_enrich_concurrent=req.max_enrich_concurrent,
    )


@router.get("/{tenant_id}/stats")
async def tenant_stats(tenant_id: UUID):
    from backend.memory.supabase_client import get_supabase
    from datetime import datetime, timezone
    sb = get_supabase()
    period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
    usage = (
        sb.table("usage_log").select("*")
        .eq("tenant_id", str(tenant_id)).eq("period", period).limit(1).execute().data
    )
    assigns = (
        sb.table("lead_assignments").select("status, delivery_status")
        .eq("tenant_id", str(tenant_id)).execute().data or []
    )
    by_status: dict = {}
    by_delivery: dict = {}
    for a in assigns:
        by_status[a["status"]] = by_status.get(a["status"], 0) + 1
        by_delivery[a.get("delivery_status") or "?"] = by_delivery.get(a.get("delivery_status") or "?", 0) + 1
    credits = (
        sb.table("lead_credits").select("credit_type, amount")
        .eq("tenant_id", str(tenant_id)).eq("period", period).execute().data or []
    )
    return {
        "usage_this_month": usage[0] if usage else None,
        "assignments_by_status": by_status,
        "delivery_by_status": by_delivery,
        "total_assigned": len(assigns),
        "credits_this_month": credits,
    }


@router.post("/keys/add")
async def add_key(req: AddKeyRequest, request: Request):
    rate_limit_keys(client_ip(request))
    from backend.integrations.prod.key_pool import add_key as _add
    return await _add(
        provider=req.provider,
        key_value=req.key_value,
        label=req.label,
        credits_limit=req.credits_limit,
        notes=req.notes,
    )


@router.get("/keys/health")
async def keys_health():
    from backend.integrations.prod.key_pool import pool_health
    return await pool_health()


@router.post("/tenants")
async def create_tenant(req: CreateTenantRequest):
    from backend.memory.supabase_client import get_supabase
    from backend.integrations.prod.crypto_config import store_delivery_config

    sb = get_supabase()
    r = sb.table("tenants").insert({
        "name": req.name,
        "plan": req.plan,
        "leads_per_month_limit": req.leads_per_month_limit,
        "allow_tier_b": req.allow_tier_b,
        "delivery_channel": req.delivery_channel,
        "delivery_config": {},  # never store secrets plaintext
    }).execute()
    tenant = (r.data or [None])[0]
    if not tenant:
        raise HTTPException(500, "Failed to create tenant")
    if req.delivery_config:
        try:
            store_delivery_config(tenant["id"], req.delivery_config)
        except Exception as e:
            # Key missing in dev — store plaintext only if encrypt fails AND not production
            import os
            if os.getenv("ENVIRONMENT", "").lower() not in ("production", "prod"):
                sb.table("tenants").update({"delivery_config": req.delivery_config}).eq("id", tenant["id"]).execute()
            else:
                raise HTTPException(500, f"Encrypt delivery_config failed: {e}")
    return tenant


@router.post("/icps")
async def create_icp(req: CreateICPRequest):
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    r = sb.table("icp_profiles").insert({
        "tenant_id": req.tenant_id,
        "name": req.name,
        "vertical": req.vertical,
        "geo": req.geo,
        "keywords": req.keywords,
        "exclusivity": req.exclusivity,
    }).execute()
    return (r.data or [None])[0]


@router.post("/suppression/upload")
async def suppression_upload(req: SuppressionUpload):
    """Upload CRM export rows so pipeline never resells existing customers."""
    from backend.integrations.prod.suppression import upload_suppression_rows
    if not req.rows:
        raise HTTPException(400, "rows required")
    if len(req.rows) > 5000:
        raise HTTPException(400, "max 5000 rows per upload")
    return await upload_suppression_rows(req.tenant_id, req.rows)


@router.post("/opt-out")
async def global_opt_out(req: OptOutRequest):
    """One removal — never surface this business to any tenant."""
    from backend.integrations.prod.suppression import add_global_opt_out
    return await add_global_opt_out(
        name=req.company_name,
        phone=req.phone,
        email=req.email,
        website=req.website,
        reason=req.reason,
        requested_by=req.requested_by,
    )


@router.post("/credits")
async def manual_credit(req: CreditRequest):
    from backend.integrations.prod.credits import credit_dead_contact
    return await credit_dead_contact(
        req.tenant_id, req.assignment_id, req.credit_type, req.detail
    )


@router.post("/credits/verify")
async def verify_and_credit(req: VerifyCreditRequest):
    """Re-check phone/email; auto-credit if dead."""
    from backend.integrations.prod.credits import verify_and_credit_if_dead
    return await verify_and_credit_if_dead(
        req.tenant_id, req.assignment_id, phone=req.phone, email=req.email
    )


@router.post("/priors/refresh/{vertical}")
async def refresh_priors(vertical: str):
    from backend.integrations.prod.priors import refresh_vertical_priors
    return await refresh_vertical_priors(vertical)


# ─── Team invites / branding / ops / LinkedIn ────────────────────────────────

class InviteRequest(BaseModel):
    tenant_id: str
    email: str
    role: str = "member"
    invited_by: Optional[str] = None
    send_email: bool = True


class AcceptInviteRequest(BaseModel):
    token: str
    auth_user_id: str
    full_name: Optional[str] = None


class BrandingUpdate(BaseModel):
    tenant_id: str
    brand_name: Optional[str] = None
    brand_logo_url: Optional[str] = None
    brand_primary_color: Optional[str] = None
    brand_accent_color: Optional[str] = None
    brand_favicon_url: Optional[str] = None
    custom_domain: Optional[str] = None
    support_email: Optional[str] = None


@router.post("/team/invite")
async def team_invite(req: InviteRequest):
    from backend.integrations.prod.team_invites import create_invite
    try:
        return await create_invite(
            req.tenant_id, req.email, req.role, req.invited_by, req.send_email
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/team/accept")
async def team_accept(req: AcceptInviteRequest):
    from backend.integrations.prod.team_invites import accept_invite
    return await accept_invite(req.token, req.auth_user_id, req.full_name)


@router.get("/team/{tenant_id}/members")
async def team_members(tenant_id: str):
    from backend.integrations.prod.team_invites import list_members, list_invites
    return {
        "members": await list_members(tenant_id),
        "invites": await list_invites(tenant_id),
    }


@router.patch("/tenants/branding")
async def update_branding(req: BrandingUpdate):
    from backend.memory.supabase_client import get_supabase
    payload = {k: v for k, v in req.model_dump().items() if k != "tenant_id" and v is not None}
    if not payload:
        raise HTTPException(400, "no branding fields")
    get_supabase().table("tenants").update(payload).eq("id", req.tenant_id).execute()
    return {"ok": True, "updated": list(payload.keys())}


@router.get("/tenants/{tenant_id}/branding")
async def get_branding(tenant_id: str):
    from backend.memory.supabase_client import get_supabase
    rows = (
        get_supabase().table("tenants")
        .select("id, name, brand_name, brand_logo_url, brand_primary_color, brand_accent_color, brand_favicon_url, custom_domain, support_email")
        .eq("id", tenant_id).limit(1).execute().data or []
    )
    if not rows:
        raise HTTPException(404, "tenant not found")
    return rows[0]


@router.get("/ops/dashboard")
async def ops_dashboard(days: int = 14):
    from backend.integrations.prod.ops_metrics import ops_dashboard as _ops
    return await _ops(days=min(days, 90))


class StripeLinkRequest(BaseModel):
    tenant_id: str
    stripe_customer_id: str
    stripe_subscription_item_id: Optional[str] = None
    stripe_price_id: Optional[str] = None


@router.post("/billing/link")
async def billing_link(req: StripeLinkRequest):
    """Attach Stripe customer / subscription item to tenant."""
    from backend.memory.supabase_client import get_supabase
    payload = {
        "stripe_customer_id": req.stripe_customer_id,
        "stripe_subscription_item_id": req.stripe_subscription_item_id,
        "stripe_price_id": req.stripe_price_id,
    }
    payload = {k: v for k, v in payload.items() if v is not None}
    get_supabase().table("tenants").update(payload).eq("id", req.tenant_id).execute()
    return {"ok": True, **payload}


@router.post("/billing/report/{tenant_id}")
async def billing_report(tenant_id: str, period: Optional[str] = None):
    """Push net usage_log leads_delivered to Stripe for one tenant."""
    from backend.integrations.prod.billing_stripe import report_usage_for_period
    return await report_usage_for_period(tenant_id, period)


@router.post("/billing/report-all")
async def billing_report_all(period: Optional[str] = None):
    """Cron: report all tenants with Stripe IDs."""
    from backend.integrations.prod.billing_stripe import report_all_tenants
    return {"results": await report_all_tenants(period)}


# ─── Admin list / update endpoints (operator panel) ──────────────────────────

@router.get("/admin/tenants")
async def list_tenants(status: Optional[str] = None, limit: int = 100):
    from backend.memory.supabase_client import get_supabase
    q = (
        get_supabase()
        .table("tenants")
        .select(
            "id, name, plan, status, leads_per_month_limit, allow_tier_b, "
            "delivery_channel, stripe_customer_id, brand_name, created_at, updated_at"
        )
        .order("created_at", desc=True)
        .limit(min(limit, 500))
    )
    if status:
        q = q.eq("status", status)
    return {"tenants": q.execute().data or []}


@router.get("/admin/tenants/{tenant_id}")
async def get_tenant(tenant_id: str):
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    rows = (
        sb.table("tenants")
        .select("*")
        .eq("id", tenant_id)
        .limit(1)
        .execute()
        .data
        or []
    )
    if not rows:
        raise HTTPException(404, "tenant not found")
    t = rows[0]
    # Never return encrypted secrets
    t.pop("delivery_config_enc", None)
    if t.get("delivery_config"):
        t["delivery_config"] = {"_redacted": True}
    icps = (
        sb.table("icp_profiles")
        .select("id, name, vertical, geo, keywords, exclusivity, active, created_at")
        .eq("tenant_id", tenant_id)
        .execute()
        .data
        or []
    )
    usage = (
        sb.table("usage_log")
        .select("*")
        .eq("tenant_id", tenant_id)
        .order("period", desc=True)
        .limit(6)
        .execute()
        .data
        or []
    )
    return {"tenant": t, "icps": icps, "usage": usage}


class UpdateTenantRequest(BaseModel):
    name: Optional[str] = None
    plan: Optional[str] = None
    status: Optional[str] = None
    leads_per_month_limit: Optional[int] = None
    allow_tier_b: Optional[bool] = None
    delivery_channel: Optional[str] = None
    delivery_config: Optional[dict] = None


@router.patch("/admin/tenants/{tenant_id}")
async def update_tenant(tenant_id: str, req: UpdateTenantRequest):
    from backend.memory.supabase_client import get_supabase
    from backend.integrations.prod.crypto_config import store_delivery_config
    payload = {k: v for k, v in req.model_dump().items() if v is not None and k != "delivery_config"}
    sb = get_supabase()
    if payload:
        sb.table("tenants").update(payload).eq("id", tenant_id).execute()
    if req.delivery_config is not None:
        try:
            store_delivery_config(tenant_id, req.delivery_config)
        except Exception as e:
            import os
            if os.getenv("ENVIRONMENT", "").lower() not in ("production", "prod"):
                sb.table("tenants").update({"delivery_config": req.delivery_config}).eq("id", tenant_id).execute()
            else:
                raise HTTPException(500, f"encrypt failed: {e}")
    return await get_tenant(tenant_id)


@router.get("/admin/icps")
async def list_icps(tenant_id: Optional[str] = None, active: Optional[bool] = None):
    from backend.memory.supabase_client import get_supabase
    q = (
        get_supabase()
        .table("icp_profiles")
        .select("id, tenant_id, name, vertical, geo, keywords, exclusivity, active, created_at")
        .order("created_at", desc=True)
        .limit(500)
    )
    if tenant_id:
        q = q.eq("tenant_id", tenant_id)
    if active is not None:
        q = q.eq("active", active)
    return {"icps": q.execute().data or []}


class UpdateICPRequest(BaseModel):
    name: Optional[str] = None
    vertical: Optional[str] = None
    geo: Optional[list[str]] = None
    keywords: Optional[list[str]] = None
    exclusivity: Optional[str] = None
    active: Optional[bool] = None


@router.patch("/admin/icps/{icp_id}")
async def update_icp(icp_id: str, req: UpdateICPRequest):
    from backend.memory.supabase_client import get_supabase
    payload = {k: v for k, v in req.model_dump().items() if v is not None}
    if not payload:
        raise HTTPException(400, "no fields")
    get_supabase().table("icp_profiles").update(payload).eq("id", icp_id).execute()
    rows = get_supabase().table("icp_profiles").select("*").eq("id", icp_id).limit(1).execute().data or []
    return rows[0] if rows else {"ok": True}


@router.get("/admin/runs")
async def list_pipeline_runs(tenant_id: Optional[str] = None, limit: int = 50):
    from backend.memory.supabase_client import get_supabase
    q = (
        get_supabase()
        .table("pipeline_runs")
        .select(
            "id, tenant_id, icp_id, status, discovered, enriched, gated_ok, assigned, delivered, "
            "error_message, started_at, finished_at, meta"
        )
        .order("started_at", desc=True)
        .limit(min(limit, 200))
    )
    if tenant_id:
        q = q.eq("tenant_id", tenant_id)
    return {"runs": q.execute().data or []}


@router.get("/admin/leads")
async def admin_list_leads(tenant_id: Optional[str] = None, limit: int = 100, offset: int = 0):
    """Operator view: leads assigned to a client (or summary by client if no tenant_id)."""
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    limit = max(1, min(int(limit or 100), 500))
    offset = max(0, int(offset or 0))

    if not tenant_id:
        # Summary: each tenant + assignment count
        tenants = (
            sb.table("tenants")
            .select("id, name, plan, status, brand_name, created_at")
            .order("created_at", desc=True)
            .limit(200)
            .execute()
            .data
            or []
        )
        out = []
        for t in tenants:
            tid = t["id"]
            try:
                r = (
                    sb.table("lead_assignments")
                    .select("id", count="exact")
                    .eq("tenant_id", tid)
                    .limit(1)
                    .execute()
                )
                count = r.count if r.count is not None else len(r.data or [])
            except Exception:
                count = 0
            out.append({**t, "leads_count": count})
        return {"clients": out}

    # Detail for one tenant
    assigns = (
        sb.table("lead_assignments")
        .select(
            "id, lead_id, tenant_id, icp_id, status, delivery_status, tier, "
            "delivery_channel, created_at, delivered_at, vertical"
        )
        .eq("tenant_id", tenant_id)
        .order("created_at", desc=True)
        .range(offset, offset + limit - 1)
        .execute()
        .data
        or []
    )
    lead_ids = [a["lead_id"] for a in assigns if a.get("lead_id")]
    leads_by_id: dict = {}
    if lead_ids:
        # batch in chunks of 50
        for i in range(0, len(lead_ids), 50):
            chunk = lead_ids[i : i + 50]
            try:
                rows = (
                    sb.table("leads_global")
                    .select(
                        "id, name, phone_normalized, phone_e164, address, city, state, "
                        "website, category, business_status, google_rating, review_count, "
                        "source, created_at, updated_at"
                    )
                    .in_("id", chunk)
                    .execute()
                    .data
                    or []
                )
                for row in rows:
                    leads_by_id[row["id"]] = row
            except Exception:
                pass

    leads = []
    for a in assigns:
        g = leads_by_id.get(a.get("lead_id") or "", {}) or {}
        leads.append({
            "assignment_id": a.get("id"),
            "lead_id": a.get("lead_id"),
            "status": a.get("status"),
            "delivery_status": a.get("delivery_status"),
            "tier": a.get("tier"),
            "delivery_channel": a.get("delivery_channel"),
            "vertical": a.get("vertical"),
            "assigned_at": a.get("created_at"),
            "delivered_at": a.get("delivered_at"),
            "name": g.get("name"),
            "phone": g.get("phone_e164") or g.get("phone_normalized"),
            "address": g.get("address"),
            "city": g.get("city"),
            "state": g.get("state"),
            "website": g.get("website"),
            "category": g.get("category"),
            "rating": g.get("google_rating"),
            "reviews": g.get("review_count"),
            "source": g.get("source"),
        })
    return {"tenant_id": tenant_id, "leads": leads, "count": len(leads)}


@router.get("/admin/usage")
async def list_usage(period: Optional[str] = None):
    from backend.memory.supabase_client import get_supabase
    from datetime import datetime, timezone
    period = period or datetime.now(timezone.utc).replace(day=1).date().isoformat()
    rows = (
        get_supabase()
        .table("usage_log")
        .select("tenant_id, period, leads_delivered, leads_credited, stripe_reported_qty, stripe_reported_at")
        .eq("period", period)
        .execute()
        .data
        or []
    )
    return {"period": period, "usage": rows}


@router.get("/admin/global-stats")
async def global_stats():
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    def count(table: str, **filters) -> int:
        try:
            q = sb.table(table).select("id", count="exact")
            for k, v in filters.items():
                q = q.eq(k, v)
            r = q.limit(1).execute()
            return r.count if r.count is not None else len(r.data or [])
        except Exception:
            return 0
    return {
        "tenants_active": count("tenants", status="active"),
        "tenants_total": count("tenants"),
        "icps_active": count("icp_profiles", active=True),
        "leads_global": count("leads_global"),
        "assignments": count("lead_assignments"),
        "opt_outs": count("global_opt_out"),
    }


@router.get("/admin/keys")
async def list_keys():
    from backend.memory.supabase_client import get_supabase
    rows = (
        get_supabase()
        .table("api_key_pool")
        .select(
            "id, provider, label, status, credits_used, credits_limit, "
            "last_error, last_used_at, cooldown_until, created_at"
        )
        .order("provider")
        .execute()
        .data
        or []
    )
    # Never return key_value
    return {"keys": rows}


# ─── Beat ZoomInfo/Apollo layer: sample packs, QA, territories, sequences ────

class SamplePackRequest(BaseModel):
    vertical: str
    geo: str = ""
    limit: int = Field(default=20, ge=5, le=50)
    tenant_id: Optional[str] = None
    min_score: int = 60


@router.post("/admin/sample-pack")
async def admin_sample_pack(req: SamplePackRequest):
    from backend.integrations.prod.sample_pack import build_sample_pack
    return await build_sample_pack(
        vertical=req.vertical,
        geo=req.geo,
        limit=req.limit,
        tenant_id=req.tenant_id,
        min_score=req.min_score,
    )


class QASubmit(BaseModel):
    lead_id: Optional[str] = None
    assignment_id: Optional[str] = None
    tenant_id: Optional[str] = None
    phone_ok: Optional[bool] = None
    email_ok: Optional[bool] = None
    business_open: Optional[bool] = None
    notes: str = ""
    reviewed_by: str = "ops"


@router.post("/admin/qa")
async def admin_qa_submit(req: QASubmit):
    from backend.integrations.prod.qa import submit_qa
    return await submit_qa(**req.model_dump())


@router.get("/admin/qa/stats")
async def admin_qa_stats(tenant_id: Optional[str] = None, days: int = 30):
    from backend.integrations.prod.qa import accuracy_stats
    return await accuracy_stats(tenant_id, days)


@router.get("/admin/bad-leads")
async def list_bad_leads(status: str = "open"):
    from backend.memory.supabase_client import get_supabase
    rows = (
        get_supabase()
        .table("bad_lead_reports")
        .select("*")
        .eq("status", status)
        .order("created_at", desc=True)
        .limit(100)
        .execute()
        .data
        or []
    )
    return {"reports": rows}


class ResolveBadLead(BaseModel):
    report_id: str
    credit: bool = True
    tenant_id: Optional[str] = None
    assignment_id: Optional[str] = None


@router.post("/admin/bad-leads/resolve")
async def resolve_bad(req: ResolveBadLead):
    from backend.integrations.prod.qa import resolve_bad_lead
    return await resolve_bad_lead(
        req.report_id,
        credit=req.credit,
        tenant_id=req.tenant_id,
        assignment_id=req.assignment_id,
    )


class TerritoryRequest(BaseModel):
    tenant_id: str
    vertical: str
    geo_key: str
    exclusive_until: Optional[str] = None
    notes: str = ""


@router.post("/admin/territories")
async def create_territory(req: TerritoryRequest):
    from backend.memory.supabase_client import get_supabase
    try:
        r = get_supabase().table("territories").upsert({
            "tenant_id": req.tenant_id,
            "vertical": req.vertical.lower().strip(),
            "geo_key": req.geo_key.lower().strip(),
            "exclusive_until": req.exclusive_until,
            "status": "active",
            "notes": req.notes,
        }, on_conflict="vertical,geo_key").execute()
        return (r.data or [None])[0]
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/admin/territories")
async def list_territories():
    from backend.memory.supabase_client import get_supabase
    rows = (
        get_supabase()
        .table("territories")
        .select("*")
        .eq("status", "active")
        .order("vertical")
        .execute()
        .data
        or []
    )
    return {"territories": rows}


@router.get("/admin/export/instantly/{tenant_id}")
async def export_instantly(tenant_id: str, limit: int = 200):
    """CSV for Instantly/Smartlead sequences — Apollo sequence alternative."""
    from backend.memory.supabase_client import get_supabase
    from backend.integrations.prod.sequence_export import leads_to_instantly_csv
    from fastapi.responses import PlainTextResponse
    sb = get_supabase()
    assigns = (
        sb.table("lead_assignments")
        .select("lead_id, id")
        .eq("tenant_id", tenant_id)
        .order("assigned_at", desc=True)
        .limit(min(limit, 500))
        .execute()
        .data
        or []
    )
    leads = []
    for a in assigns:
        lid = a.get("lead_id")
        if not lid:
            continue
        g = sb.table("leads_global").select("*").eq("id", lid).limit(1).execute().data or []
        e = sb.table("enrichment").select("*").eq("lead_id", lid).limit(1).execute().data or []
        s = sb.table("scores").select("*").eq("lead_id", lid).limit(1).execute().data or []
        if not g:
            continue
        row = {**g[0]}
        if e:
            row.update({k: e[0].get(k) for k in ("email", "booking_platform", "pitch_line", "intent_score", "owner_name")})
        if s:
            row["score"] = s[0].get("total_score")
            row["tier"] = s[0].get("tier")
            row["pitch_line"] = row.get("pitch_line") or s[0].get("pitch_line")
        leads.append(row)
    csv_text = leads_to_instantly_csv(leads)
    return PlainTextResponse(csv_text, media_type="text/csv")


# ─── Differentiators: docs, territory, recycle, weights ─────────────────────

class DocSendRequest(BaseModel):
    tenant_id: str
    template_id: str
    variables: dict = Field(default_factory=dict)
    channel: str = "email"
    to_email: Optional[str] = None
    to_phone: Optional[str] = None


class WeightsUpdate(BaseModel):
    tenant_id: str
    icp_id: str
    weights: dict  # e.g. {"email": 1.2, "booking": 0.8, "reviews": 1.5}


@router.get("/docs/templates")
async def docs_templates(tenant_id: Optional[str] = None, category: Optional[str] = None):
    from backend.integrations.prod.doc_templates import list_templates
    return {"templates": await list_templates(tenant_id, category)}


@router.post("/docs/send")
async def docs_send(req: DocSendRequest):
    from backend.integrations.prod.doc_templates import generate_and_send
    try:
        return await generate_and_send(
            req.tenant_id, req.template_id, req.variables,
            channel=req.channel, to_email=req.to_email, to_phone=req.to_phone,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/territories")
async def territories(vertical: Optional[str] = None, geo: Optional[str] = None):
    from backend.integrations.prod.territory import territory_availability
    return await territory_availability(vertical, geo)


@router.post("/recycle/lost")
async def recycle_lost(older_than_days: int = 90, limit: int = 500):
    from backend.integrations.prod.recycle import recycle_lost_assignments
    return await recycle_lost_assignments(older_than_days, limit)


@router.patch("/icp/weights")
async def update_icp_weights(req: WeightsUpdate):
    """Client or operator updates scoring weight overrides on an ICP."""
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    rows = sb.table("icp_profiles").select("id, tenant_id, weights, client_weight_overrides").eq("id", req.icp_id).limit(1).execute().data or []
    if not rows:
        raise HTTPException(404, "icp not found")
    if rows[0]["tenant_id"] != req.tenant_id:
        raise HTTPException(403, "icp tenant mismatch")
    # merge into weights + client_weight_overrides
    base = rows[0].get("weights") or {}
    base.update(req.weights or {})
    sb.table("icp_profiles").update({
        "weights": base,
        "client_weight_overrides": req.weights,
    }).eq("id", req.icp_id).execute()
    return {"ok": True, "weights": base}


class OpEmailBulk(BaseModel):
    tenant_id: str
    subject: str
    body_html: str
    body_text: Optional[str] = None
    assignment_ids: Optional[list[str]] = None
    tier: Optional[str] = None
    limit: int = 100


@router.post("/email/bulk")
async def op_email_bulk(req: OpEmailBulk):
    from backend.integrations.prod.email_outreach import send_bulk, send_bulk_filtered
    if req.assignment_ids:
        return await send_bulk(req.tenant_id, req.assignment_ids, req.subject, req.body_html, req.body_text or "")
    return await send_bulk_filtered(req.tenant_id, req.subject, req.body_html, req.body_text or "", tier=req.tier, limit=req.limit)


# ─── Admin territory availability + tenant health ───────────────────────────

@router.get("/admin/territory")
async def admin_territory(vertical: Optional[str] = None, geo: Optional[str] = None):
    """Which vertical+geo+offer combos are locked by exclusive ICPs."""
    from backend.integrations.prod.territory import territory_availability
    return await territory_availability(vertical, geo)


@router.get("/admin/tenant-health")
async def admin_tenant_health():
    """
    One-screen churn-risk view: usage + last activity + pipeline success per tenant.
    Surfaces tenants who haven't touched the product in 2+ weeks.
    """
    from backend.memory.supabase_client import get_supabase
    from datetime import datetime, timezone, timedelta

    sb = get_supabase()
    now = datetime.now(timezone.utc)
    two_weeks_ago = (now - timedelta(days=14)).isoformat()
    thirty_days_ago = (now - timedelta(days=30)).isoformat()

    tenants = (
        sb.table("tenants")
        .select("id, name, plan, created_at, status")
        .order("created_at", desc=True)
        .limit(200)
        .execute()
        .data
        or []
    )

    results = []
    for t in tenants:
        tid = t["id"]
        # Last assignment activity
        last_assign = (
            sb.table("lead_assignments")
            .select("assigned_at")
            .eq("tenant_id", tid)
            .order("assigned_at", desc=True)
            .limit(1)
            .execute()
            .data
            or []
        )
        last_activity = last_assign[0]["assigned_at"] if last_assign else None

        # Deliveries last 30d
        recent = (
            sb.table("lead_assignments")
            .select("id", count="exact")
            .eq("tenant_id", tid)
            .gte("assigned_at", thirty_days_ago)
            .execute()
        )
        deliveries_30d = recent.count if recent.count is not None else len(recent.data or [])

        # Bad lead reports open
        bad = (
            sb.table("bad_lead_reports")
            .select("id", count="exact")
            .eq("tenant_id", tid)
            .eq("status", "open")
            .execute()
        )
        open_bad = bad.count if bad.count is not None else len(bad.data or [])

        # Pipeline runs last 30d
        runs_30d = 0
        try:
            runs = (
                sb.table("pipeline_runs")
                .select("id", count="exact")
                .eq("tenant_id", tid)
                .gte("started_at", thirty_days_ago)
                .execute()
            )
            runs_30d = runs.count if runs.count is not None else len(runs.data or [])
        except Exception:
            runs_30d = 0

        risk = "ok"
        if not last_activity:
            risk = "never_active"
        elif last_activity < two_weeks_ago:
            risk = "churn_risk"
        elif deliveries_30d == 0 and runs_30d == 0:
            risk = "stale"
        elif open_bad >= 3:
            risk = "quality_issues"

        results.append({
            "tenant_id": tid,
            "name": t.get("name"),
            "plan": t.get("plan"),
            "status": t.get("status"),
            "created_at": t.get("created_at"),
            "last_activity": last_activity,
            "deliveries_30d": deliveries_30d,
            "runs_30d": runs_30d,
            "open_bad_reports": open_bad,
            "risk": risk,
        })

    # Sort riskiest first
    order = {"churn_risk": 0, "never_active": 1, "stale": 2, "quality_issues": 3, "ok": 4}
    results.sort(key=lambda x: order.get(x["risk"], 9))

    return {
        "tenants": results,
        "summary": {
            "total": len(results),
            "churn_risk": sum(1 for r in results if r["risk"] == "churn_risk"),
            "never_active": sum(1 for r in results if r["risk"] == "never_active"),
            "stale": sum(1 for r in results if r["risk"] == "stale"),
            "quality_issues": sum(1 for r in results if r["risk"] == "quality_issues"),
            "ok": sum(1 for r in results if r["risk"] == "ok"),
        },
    }


@router.post("/admin/alerts/run")
async def admin_run_alerts():
    """Manually trigger proactive alert checks (also intended for cron/n8n)."""
    from backend.integrations.prod.alerts import run_alert_checks
    return await run_alert_checks()


@router.get("/admin/feature-flags")
async def admin_feature_flags(tenant_id: Optional[str] = None):
    """Inspect effective feature flags (global + optional tenant)."""
    from backend.integrations.prod import feature_flags as ff
    flags = {}
    for key in ff._DEFAULTS:
        flags[key] = ff.is_enabled(key, tenant_id=tenant_id)
    return {
        "flags": flags,
        "staging_tenant_id": ff.staging_tenant_id(),
        "tenant_id": tenant_id,
    }
