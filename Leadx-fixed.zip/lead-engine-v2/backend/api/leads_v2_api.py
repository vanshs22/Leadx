"""Leads API v2 — Multi-tenant Lead Engine endpoints."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/leads/v2", tags=["leads-v2"])


class PipelineV2Request(BaseModel):
    tenant_id: str
    icp_id: Optional[str] = None
    industry: str = "medspa"
    locations: list[str] = Field(default_factory=list)
    queries: list[str] = Field(default_factory=list)
    limit_per_location: int = 50
    skip_enrichment: bool = False
    allow_tier_b: bool = False
    max_enrich_concurrent: int = 6
    deliver: bool = True


class CronAllRequest(BaseModel):
    limit_per_location: int = 30
    skip_enrichment: bool = False


@router.post("/pipeline/run")
async def run_pipeline(req: PipelineV2Request):
    """
    Run the full Lead Engine v2 pipeline for one tenant/ICP.
    Discover (Serper+Scrapling) → Enrich (Scrapling/Crawl4AI/Firecrawl) →
    Score → Quality Gate → Exclusivity → Assign → Usage log.
    """
    from backend.integrations.lead_pipeline_v2 import run_pipeline_v2
    return await run_pipeline_v2(
        tenant_id=req.tenant_id,
        icp_id=req.icp_id,
        industry=req.industry,
        locations=req.locations or None,
        queries=req.queries or None,
        limit_per_location=req.limit_per_location,
        skip_enrichment=req.skip_enrichment,
        allow_tier_b=req.allow_tier_b,
        max_enrich_concurrent=req.max_enrich_concurrent,
        deliver=req.deliver,
    )


@router.post("/pipeline/run-all-icps")
async def run_all_icps(req: CronAllRequest):
    """Cron entry: process every active ICP profile."""
    from backend.integrations.lead_pipeline_v2 import run_for_all_active_icps
    return await run_for_all_active_icps(
        limit_per_location=req.limit_per_location,
        skip_enrichment=req.skip_enrichment,
    )


@router.get("/{tenant_id}/stats")
async def tenant_stats(tenant_id: UUID):
    """Usage + assignment stats for a tenant."""
    from backend.memory.supabase_client import get_supabase
    from datetime import datetime, timezone
    sb = get_supabase()
    period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
    usage = (
        sb.table("usage_log")
        .select("*")
        .eq("tenant_id", str(tenant_id))
        .eq("period", period)
        .limit(1)
        .execute()
        .data
    )
    assigns = (
        sb.table("lead_assignments")
        .select("status")
        .eq("tenant_id", str(tenant_id))
        .execute()
        .data or []
    )
    by_status = {}
    for a in assigns:
        by_status[a["status"]] = by_status.get(a["status"], 0) + 1
    return {
        "usage_this_month": usage[0] if usage else None,
        "assignments_by_status": by_status,
        "total_assigned": len(assigns),
    }


@router.post("/keys/add")
async def add_api_key(provider: str, key_value: str, notes: str = ""):
    """Add a key to the rotation pool."""
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    r = sb.table("api_key_pool").insert({
        "provider": provider,
        "key_value": key_value,
        "status": "active",
        "notes": notes,
    }).execute()
    return {"ok": True, "id": r.data[0]["id"] if r.data else None}
