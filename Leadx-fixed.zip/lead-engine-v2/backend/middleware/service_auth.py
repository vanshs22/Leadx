"""
Service-key auth for operator endpoints.

Simple testing mode (default for non-production):
  No key required when ENVIRONMENT is not production/staging,
  or LEAD_ENGINE_DEV_AUTH_BYPASS=1.

Production:
  Set ENVIRONMENT=production and LEAD_ENGINE_SERVICE_KEY (16+ chars).
  Clients must send Authorization: Bearer <key> or X-Service-Key.
"""
from __future__ import annotations

import hmac
import os
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

_bearer = HTTPBearer(auto_error=False)

SERVICE_KEY = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")


def _open_mode() -> bool:
    """Allow unauthenticated operator calls for local / Codespace testing."""
    if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
        return True
    env = os.getenv("ENVIRONMENT", "development").lower()
    if env in ("production", "prod", "staging"):
        return False
    return True  # development / local / empty → simple open testing


def _configured() -> bool:
    return bool(SERVICE_KEY and len(SERVICE_KEY) >= 16)


async def require_service_key(
    request: Request,
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> None:
    if _open_mode():
        return

    if not _configured():
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "Set LEAD_ENGINE_SERVICE_KEY (min 16 chars) for production",
        )

    provided = None
    if creds and creds.credentials:
        provided = creds.credentials
    if not provided:
        provided = request.headers.get("X-Service-Key")

    if not provided or not hmac.compare_digest(provided, SERVICE_KEY):
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Invalid or missing service key",
            headers={"WWW-Authenticate": "Bearer"},
        )
