# Next-tier features (what beats a typical agency)

## Ops / security
| Item | Location |
|------|----------|
| Service-key auth on all `/leads/v2/*` | `middleware/service_auth.py` + `api/prod/leads_api.py` |
| Encrypt `delivery_config` at rest | `integrations/prod/crypto_config.py` + `tenants.delivery_config_enc` |
| GitHub Actions unit tests | `.github/workflows/tests.yml` |

**Env:** `LEAD_ENGINE_SERVICE_KEY` (≥16 chars), `DELIVERY_CONFIG_KEY` (32-byte key).

## Lead quality differentiators
| Feature | Module |
|---------|--------|
| Why-now signals (review velocity, redesign hints) | `signals.py` |
| Review sentiment → pitch hooks | `signals.mine_review_sentiment` |
| Specific tech (Vagaro / Mindbody / Intercom / …) | `signals.detect_tech_stack` |
| Client suppression lists | `suppression.py` + `POST /suppression/upload` |
| Global opt-out registry | `suppression.add_global_opt_out` + `POST /opt-out` |

## Feedback cold-start
| Feature | Module |
|---------|--------|
| Cross-tenant vertical priors | `priors.py` + `vertical_priors` table |
| New tenants inherit vertical bias until 5+ own outcomes | `weights_for_tenant` |

## Trust / SLA
| Feature | Module |
|---------|--------|
| Auto-credit dead phone/email | `credits.py` + `POST /credits/verify` |
| Idempotent credits + usage_log decrement | `lead_credits` + `credit_tenant_usage()` |

## Migrations
```
002 → 003 → 004 → 005 → 006_next_tier.sql
```

## Pipeline hook order
`post_enrich_prepare`: block lists → verify → signals → priors/weights → score v3
