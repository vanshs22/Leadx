# Auth Overhaul — What Changed

## 1. Retired the duplicate unauthenticated CRM router
`crm_api_secured.py` is gone. `crm_api.py` is now the single CRM router,
with `Depends(require_tenant)` applied at the router level — every
`/crm/{tenant_id}/...` call re-verifies the JWT and re-checks tenant
membership; the path `tenant_id` is only a hint. `/team/accept` lives on a
separate `crm_public_router` (lighter `require_auth_only` — accepting an
invite happens before someone has tenant membership) and now takes the
user id from the verified token instead of a client-supplied field in the
request body.

## 2. Built real tenant login (this was the actual root cause)
There was no client-portal auth at all — `WorkspacePicker` called the
admin tenant-list endpoint from the public portal and let any visitor
open or paste in any tenant's UUID ("No service key required" was in the
UI copy). Replaced with:
- `lib/supabaseClient.ts`, `lib/auth.ts` — Supabase Auth (anon key, safe
  to expose client-side, unlike the service key)
- `app/(portal)/login/page.tsx`, `app/(portal)/accept-invite/page.tsx`
- `SessionGate.tsx` replaces `WorkspacePicker.tsx` — resolves the tenant
  from a new `GET /crm/me` endpoint (JWT → verified membership), never
  from browser-supplied input
- `lib/api.ts` / `lib/branding.ts` now attach the real session token on
  every call instead of sending nothing

## 3. Admin panel: fixed auth that was pure theater
`setAdminKey` / `clearAdminKey` were no-ops and `hasAdminKey()` always
returned `true`. Rewrote `lib/admin.ts` with real `sessionStorage` +
`Authorization` header, added a route guard to the admin layout, and
added the 27 missing functions pages were already calling but that
didn't exist (`globalStats`, `keysHealth`, `territories`, `qaStats`,
etc. — full list matches every `/leads/v2/admin/*` and related route).

## 4. first_touch.py: suppression + idempotency
Both `maybe_first_touch` and `send_first_touch_manual` now check the
suppression/global-opt-out list and whether the assignment was already
contacted before dialing or texting — both fail closed (an error in the
check blocks the contact, never allows it).

## Not in this pass
Proactive ops alerts, the territory admin page, the sample-pack prospect
page, and the "why this lead" scoring panel — deferred in favor of doing
the auth fix completely rather than partially. `scores.reasoning` is
already exposed via `crm_lead_cards` (`score_reasoning`) if you want to
build the panel next; no backend change needed for that one.

## Before deploying
Add to environment: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
(frontend — see `.env.example`). Existing tenant users need real Supabase
Auth accounts bound via `tenant_members.auth_user_id` — for tenants
created before this change, send them an invite (`POST /leads/v2/team/invite`)
rather than assuming they can log in immediately.
