# Continuous high-volume lead supply

## Problem
Running the same city + query returns the same Maps page 1 results every time.

## Solution
1. **Geo cells** — expand "Hoboken" → zips, neighborhoods, adjacent cities; scan least-used cells first
2. **Query expansion** — 10–15 long-tail variants per vertical (botox, hydrafacial, …)
3. **tenant_seen_leads** — never rediscover fingerprints already delivered to that client
4. **Coverage tracking** — mark cells exhausted when they yield 0 new
5. **target_new_leads** — aim for 500 / 2000 / 10000 net-new per run

## API
```json
{
  "tenant_id": "...",
  "icp_id": "...",
  "industry": "medspa",
  "locations": ["Hoboken NJ", "Jersey City NJ"],
  "target_new_leads": 2000,
  "max_cells_per_run": 40,
  "include_maps": true,
  "include_linkedin": true,
  "include_instagram": true,
  "include_web": true
}
```

## Scale tips
| Target / run | max_cells | Serper load |
|--------------|-----------|-------------|
| 200–500 | 15–25 | Low–medium |
| 1,000–3,000 | 30–50 | Medium–high |
| 5,000–10,000 | 50–100 | High — batch over multiple days |

Run daily/weekly cron: each run picks **different cells** → steady pipeline without duplicates.

## SQL
Apply `011_continuous_discovery.sql`
