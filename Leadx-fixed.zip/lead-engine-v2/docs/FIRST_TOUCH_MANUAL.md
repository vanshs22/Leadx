# First touch = manual toggle, not always-on

## Behavior
- Pipeline **does not** auto-SMS/call when a lead is assigned.
- In CRM lead detail: **Enable send** toggle → choose SMS or Voice → **Send once**.
- Toggle turns off after send attempt (one-shot).
- If already `first_touch_status = sent`, API returns `skipped: already_sent`.

## Optional auto (advanced)
`tenants.auto_first_touch = true` still exists for rare always-on setups, but the pipeline no longer calls it. Prefer the CRM button.

## Endpoint
`POST /crm/{tenant_id}/leads/{assignment_id}/first-touch`
Body: `{ "channel": "sms" | "voice" }`
