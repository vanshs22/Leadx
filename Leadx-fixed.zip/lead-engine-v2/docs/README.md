# Automiqo Lead Engine v2 — Multi-Tenant, Sellable Lead Gen

Fully functional lead generation system that scrapes **thousands of leads**, enriches them with free/self-hosted tools, applies quality gates + territory exclusivity, and delivers only the best leads to each tenant.

Built by combining the existing Automiqo OS lead pipeline with the v2 multi-tenant sellable architecture.

---

## What it does

```
Cron / Webhook
    ↓
Loop active ICP profiles (per tenant)
    ↓
Serper.dev Google Maps (key-pooled, auto-rotates on quota)
    → fallback: Scrapling (self-hosted) if all keys exhausted
    ↓
Global fingerprint + phone dedup
    ↓
Scrapling website fetch (primary, anti-bot)
    + Crawl4AI markdown (parallel, free compute)
    → Firecrawl last-resort (key-pooled)
    → ScrapeGraphAI structured extraction (Gemini/Groq free tiers)
    ↓
Deterministic scoring → Tier A/B/C
    ↓
Upsert: leads_global + enrichment + scores
    ↓
Quality Gate (tier, open business, phone+website, ≥2 enrichment fields)
    ↓
Exclusivity check (no two exclusive tenants in same vertical+geo get same lead)
    ↓
Assign + usage_log (billing source of truth)
    ↓
Delivery (Telegram MVP / webhook / portal)
```

---

## Tool stack (free / self-hosted first)

| Layer              | Tool              | Notes                                      |
|--------------------|-------------------|--------------------------------------------|
| Maps discovery     | **Serper.dev**    | Primary. Auto-rotating key pool            |
| Discovery fallback | Scrapling         | Self-hosted, no key                        |
| Website fetch      | **Scrapling**     | Primary — anti-bot + adaptive              |
| Markdown           | **Crawl4AI**      | Self-hosted, free compute                  |
| Hard JS sites      | Firecrawl         | Last resort, key-pooled                    |
| Structured extract | ScrapeGraphAI     | OSS → Gemini / Groq free tiers             |
| Scoring            | Deterministic     | Zero cost; LLM optional later              |
| Storage            | Supabase          | Multi-tenant schema + pg_trgm              |
| Orchestration      | n8n               | Self-hosted                                |

---

## Files in this package

```
lead-engine-v2/
├── sql/
│   └── 001_lead_engine_v2_schema.sql     # Full multi-tenant schema
├── backend/
│   ├── integrations/
│   │   ├── key_pool.py                   # Auto-rotating API key pool
│   │   ├── lead_discovery_v2.py          # Serper + Scrapling discovery
│   │   ├── lead_enricher_v2.py           # Scrapling → Crawl4AI → Firecrawl → ScrapeGraphAI
│   │   ├── lead_quality_gate.py          # Score + quality gate + exclusivity
│   │   └── lead_pipeline_v2.py           # Full orchestrator
│   └── api/
│       └── leads_v2_api.py               # FastAPI routes
├── n8n/
│   └── lead_engine_v2_pipeline.json      # Cron + webhook workflow
└── docs/
    └── README.md                         # This file
```

---

## Quick start

### 1. Schema
```bash
# In Supabase SQL Editor
\i sql/001_lead_engine_v2_schema.sql
```

### 2. Drop the Python modules into your backend
```bash
cp backend/integrations/*.py  <repo>/backend/integrations/
cp backend/api/leads_v2_api.py <repo>/backend/api/
# Register the router in your FastAPI app:
# from backend.api.leads_v2_api import router as leads_v2_router
# app.include_router(leads_v2_router)
```

### 3. Install free/self-hosted deps
```bash
pip install scrapling crawl4ai scrapegraphai httpx
# Optional: playwright for Crawl4AI / Scrapling browser mode
playwright install
```

### 4. Seed API keys into the pool
```sql
INSERT INTO api_key_pool (provider, key_value, status) VALUES
  ('serper',    'your-serper-key-1', 'active'),
  ('serper',    'your-serper-key-2', 'active'),  -- rotation
  ('firecrawl', 'your-firecrawl-key', 'active'),
  ('gemini',    'your-gemini-key',   'active'),
  ('groq',      'your-groq-key',     'active');
```
Or use the endpoint: `POST /leads/v2/keys/add?provider=serper&key_value=...`

### 5. Create a tenant + ICP
```sql
INSERT INTO tenants (name, plan, leads_per_month_limit, delivery_channel)
VALUES ('Acme Medspa Agency', 'growth', 500, 'telegram')
RETURNING id;

INSERT INTO icp_profiles (tenant_id, vertical, geo, keywords, exclusivity)
VALUES (
  '<tenant-uuid>',
  'medspa',
  '["Hoboken NJ", "Jersey City NJ", "Newark NJ"]',
  '["med spa", "aesthetics", "botox clinic"]',
  'exclusive'
);
```

### 6. Import n8n workflow
- Import `n8n/lead_engine_v2_pipeline.json`
- Ensure env vars `BACKEND_URL`, `SUPABASE_URL`, `SUPABASE_SERVICE_KEY` are set in n8n
- Activate

### 7. Run
**Manual (single tenant):**
```bash
curl -X POST http://localhost:8000/leads/v2/pipeline/run \
  -H "Content-Type: application/json" \
  -d '{
    "tenant_id": "<uuid>",
    "icp_id": "<uuid>",
    "limit_per_location": 50,
    "max_enrich_concurrent": 8
  }'
```

**All active ICPs (cron does this daily):**
```bash
curl -X POST http://localhost:8000/leads/v2/pipeline/run-all-icps \
  -H "Content-Type: application/json" \
  -d '{"limit_per_location": 40}'
```

**Via n8n webhook:**
```bash
curl -X POST http://n8n:5678/webhook/lead_engine_v2 \
  -H "Content-Type: application/json" \
  -d '{"tenant_id":"<uuid>","limit_per_location":100}'
```

---

## Scaling to thousands of leads

- `limit_per_location` × number of locations × query variants = total volume
- Serper Maps returns ~20 per page; the client paginates automatically
- Enrichment concurrency is controlled by `max_enrich_concurrent` (default 6)
- Global fingerprint + phone_normalized prevents cross-run duplicates
- Key pool keeps Serper / Firecrawl alive as individual keys hit quota

Example for ~2 000 leads:
```json
{
  "locations": ["Newark NJ", "Jersey City NJ", "Paterson NJ", "Elizabeth NJ", "Edison NJ"],
  "queries": ["med spa", "medical spa", "aesthetics clinic"],
  "limit_per_location": 80
}
```
→ 5 × 3 × ~80 ≈ 1 200 unique after dedup.

---

## Quality Gate rules (nothing reaches a client without clearing them)

1. `tier = 'A'` (or `'B'` if plan is growth/premium)
2. `business_status != 'CLOSED'`
3. `phone_normalized` and `website` present
4. ≥ 2 enrichment fields populated (email / booking / services / social)
5. Passes exclusivity check (no other exclusive tenant in same vertical+geo already holds the lead)
6. Not delivered to *this* tenant in the last 90 days

---

## Pricing packaging (from the spec)

- **Pay-per-lead** — charge per delivered A-tier lead
- **Monthly subscription** — N leads/mo, tier-A guaranteed
- **Territory exclusivity add-on** — premium for `exclusivity = 'exclusive'`

`usage_log` is the billing source of truth.

---

## Next upgrades (Week 3–4 of the build order)

1. Telegram digest delivery node (n8n Telegram node after assignment)
2. LLM scoring pass (Claude Haiku / Gemini) on top of deterministic score
3. Client portal (simple React + Supabase auth) reading from `lead_assignments`
4. Webhook delivery to client GHL / HubSpot / custom CRM
