# High-quality, non-redundant delivery pipeline

```
Sources (Maps · LinkedIn · IG · Web · Yelp · Facebook)
        ↓ parallel
Entity resolution (phone · domain · name+city · social IDs)
        ↓
Suppress / opt-out
        ↓
Enrich (website resolve → crawl → verify)
        ↓
Intent + pitch + score
        ↓
Quality gate (contactable: phone OR email + presence)
        ↓
Social enrich (optional)
        ↓
Ranker (composite quality) + diversity cap (1 per domain)
        ↓
Assign exclusive → Deliver only top ranked
```

## Non-redundancy
- Fingerprint, phone last-10, website domain, LinkedIn slug, IG handle
- Name+city clustering
- Multi-source merge keeps richest fields

## Quality rank (composite)
- 40% score · 20% intent · 15% discovery · 20% contactability · multi-source boost
- Client only receives contactable, ranked, de-duplicated leads
