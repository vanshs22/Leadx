# Multi-source discovery (Maps is not primary)

## Sources (peers)

| Source | What it finds |
|--------|----------------|
| **maps** | Google Maps businesses (phone, address, rating) |
| **linkedin** | Company pages + owners/founders/managers |
| **instagram** | Business profiles with booking/clinic signals |
| **web** | Official websites via organic search |
| **yelp** | Yelp business pages |
| **facebook** | Facebook business pages |

## Merge logic
- Dedup by fingerprint + normalized name
- Business found on **2+ sources** → quality boost (+12 per extra source)
- `sources_hit` array on every lead

## API
```json
{
  "include_maps": true,
  "include_linkedin": true,
  "include_instagram": true,
  "include_web": true,
  "include_yelp": true,
  "include_facebook": true,
  "social_limit_per_source": 20,
  "limit_per_location": 40
}
```

Disable Maps entirely if you want social/web only:
`"include_maps": false`
