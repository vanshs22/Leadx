# How we outwork ZoomInfo & Apollo (local B2B)

We do **not** try to mirror 300M corporate contacts. We win where they are weak:

| ZoomInfo / Apollo | Automiqo Lead Service |
|-------------------|------------------------|
| Stale LinkedIn-heavy SMB coverage | Live Google Maps discovery |
| Shared database, everyone buys same rows | **Exclusive** vertical + geo territories |
| Generic firmographics | **Intent score** from booking gap, reviews, social staleness |
| No talk track | **Pitch line** on every lead |
| Brand trust via marketing | **QA accuracy %** published from real checks |
| Sequences built-in | **Instantly/Smartlead CSV** export |
| Expensive seats | Managed service priced per delivered exclusive lead |

## New modules
- `pitch.py` / `intent.py` — talk track + local intent 0–100
- `sample_pack.py` — sales demos
- `qa.py` — accuracy + bad-lead credits
- `sequence_export.py` — Instantly CSV
- SQL `010_beat_zoominfo_layer.sql`
- Admin UI `/admin/intelligence`

## Client
- `POST /crm/{tenant}/leads/{id}/bad-lead`
- `GET /crm/{tenant}/export/instantly`
