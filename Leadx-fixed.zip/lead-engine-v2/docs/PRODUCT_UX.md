# Product UX (client + admin)

## Client (easy + powerful)
- Home: "Start here" checklist + KPIs
- Leads: call/copy, pitch line, tier/intent chips, Instantly export
- Lead detail: talk track, stage buttons, notes, tasks, report bad lead
- Pipeline / reports / team for power users

## Admin
- Overview action grid
- Pipeline runs, ICPs, keys, intelligence (QA/samples/territories), ops

## Design
- Dark glass cards, clear primary actions (Call / Email)
- Quality chips always visible so users trust data
