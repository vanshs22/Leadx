# Post-gate social enrichment (LinkedIn + Instagram)

## Pipeline placement
```
discover → suppress → enrich_batch → score/gate
  → social_enrich (Tier A/B only, max 25/run)
  → assign → deliver
```
Rejected leads never touch LinkedIn session.

## Modules
- `backend/integrations/prod/social_enrich.py`
- `services/linkedin-scraper/` — Dockerfile + FastAPI+Selenium stub (swap in drissbri logic)
- SQL: `009_social_enrich.sql`

## LinkedIn
- HTTP service at `LINKEDIN_SCRAPER_URL` (default `http://linkedin-scraper:8001`)
- Cookie `li_at` via `api_key_pool` provider=`linkedin_scraper`
- On 401: `mark_exhausted` + Telegram ops alert
- Cap: `SOCIAL_ENRICH_MAX_PER_RUN` (default 25)

```bash
# Add cookie
POST /leads/v2/keys/add  {"provider":"linkedin_scraper","key_value":"<li_at cookie>"}

# Run service
cd services/linkedin-scraper && docker build -t linkedin-scraper . && docker run -p 8001:8001 linkedin-scraper
```

## Instagram
- `instaloader` in-process (no login for public bio/followers/last post)
- Stale (90+ days) → why_now: "marketing opportunity"

## Scoring
- `decision_maker_name` backfills `owner_name` → existing +6 owner points on re-score
