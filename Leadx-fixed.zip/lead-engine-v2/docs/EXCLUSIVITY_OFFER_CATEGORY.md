# Competitive exclusivity (offer category)

## Rule
Lock a lead **only against the same type of seller**, not against every ICP that targets the same businesses.

| Field | Meaning | Example |
|-------|---------|---------|
| `vertical` | Who the **lead** is (target industry) | `salon`, `medspa` |
| `offer_category` | What **you sell** to them (competitive set) | `hair_dryers`, `hair_cream`, `seo_agency` |
| `geo` | Territory overlap | `New Jersey` |

## Share vs lock

| Client A | Client B | Same salon lead? |
|----------|----------|------------------|
| offer=`hair_dryers`, vertical=`salon`, NJ | offer=`hair_cream`, vertical=`salon`, NJ | **Shared** (not competitors) |
| offer=`seo_agency`, vertical=`salon`, NJ | offer=`seo_agency`, vertical=`salon`, NJ | **Locked** (competitors) |
| offer=`website_design`, vertical=`medspa`, NJ | offer=`seo_agency`, vertical=`medspa`, NJ | **Shared** |

## Operator setup
When creating an ICP, set:

```json
{
  "name": "NJ salons – hair dryer seller",
  "vertical": "salon",
  "geo": ["New Jersey"],
  "offer_category": "hair_dryers",
  "offer_label": "Hair dryer product line",
  "exclusivity": "exclusive"
}
```

If `offer_category` is omitted, system falls back to `vertical` (legacy strict lock).

## Client pitch language
“Exclusive among sellers of the **same product category** in your territory — not locked away from non-competing brands that also sell into the same salons.”
