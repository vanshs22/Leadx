# LinkedIn · Team invites · White-label · Ops dashboard

## Active LinkedIn lookup
- Module: `integrations/prod/linkedin_lookup.py`
- Serper queries: `site:linkedin.com/company "{name}"` + people search for owner/founder/manager
- Wired in `pipeline_hooks.post_enrich_prepare` (`do_linkedin=True`)
- Fields: `linkedin_url`, `decision_makers[]`, optional `owner_name` fill
- Score: +4 when decision-maker found

## Team invites
- SQL: `tenant_invites` in `007_team_branding_ops.sql`
- `POST /leads/v2/team/invite` — token + optional Resend email
- `POST /leads/v2/team/accept` — binds `auth_user_id` to `tenant_members`
- `GET /leads/v2/team/{tenant_id}/members`

Env: `RESEND_API_KEY`, `PORTAL_BASE_URL`, `INVITE_TTL_DAYS`

## White-label branding
- Columns on `tenants`: brand_name, logo, colors, favicon, custom_domain, support_email
- `PATCH /leads/v2/tenants/branding`
- Frontend: `frontend/lib/branding.ts` — CSS vars `--brand-primary` / `--brand-accent`

## Ops observability
- Table: `ops_metrics_daily` + `bump_ops_metric()`
- `GET /leads/v2/ops/dashboard?days=14`
- Returns: key pool health, enrich success %, suppression hits, recent failures, **alerts**

## Migration
```
007_team_branding_ops.sql
```
