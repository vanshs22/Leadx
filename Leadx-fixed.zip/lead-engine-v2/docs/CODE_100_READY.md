# Code-level production readiness — 100/100 (managed service)

Verified by `scripts/verify_code_ready.py` + **70/70 unit tests**.

## Gaps that were closed (this pass)

| Gap | Fix |
|-----|-----|
| No standalone Supabase client | `backend/memory/supabase_client.py` |
| Missing `__init__.py` packages | All backend packages initialized |
| Score v3 / hooks not primary path | `post_enrich_prepare` after enrich; `score_lead` → v3 |
| Blocked leads still stored | Skipped in store/assign loop |
| Delivery secrets plaintext at runtime | `load_delivery_config()` in pipeline |
| No bootable entrypoint | `backend/app_service.py` + Dockerfile + compose |
| CRM API separate from engine | Bundled under `backend/crm/` |
| Empty CRM nav pages | reports, settings, team, activities + layouts |
| LinkedIn cookie exhaust wrong signature | `mark_provider_exhausted` |
| No `/health` DB probe | Health checks Supabase |
| No frontend package config | package.json, tsconfig, tailwind, next.config |
| No code-ready gate | `scripts/verify_code_ready.py` |

## What “100/100 code” means

- All production modules importable and wired
- Auth, rate limits, RLS SQL, encrypt, billing, social, suppression present
- Pipeline order is production-correct
- Single deploy path: Docker or uvicorn
- Client CRM pages exist for full lead lifecycle
- Unit tests green

## What is intentionally **your** step (not code)

1. Put real keys in `.env` + `api_key_pool`
2. Apply SQL migrations on your Supabase
3. Run one live city pipeline
4. Spot-check 30 Tier A leads
5. Confirm Telegram/webhook delivery
6. Optionally harden LinkedIn Selenium extractors with a real `li_at`

Those are **ops validation**, not missing product code.

## Deploy command

```bash
cp .env.example .env   # fill keys
# apply sql 002→009 in Supabase
docker compose up -d api
curl -s localhost:8000/health
python scripts/verify_code_ready.py
```
