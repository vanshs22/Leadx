# Statewide ICP: e.g. New Jersey med spa → 10,000+ leads

## Request
```json
{
  "tenant_id": "…",
  "icp_id": "…",
  "industry": "medspa",
  "locations": ["New Jersey"],
  "target_new_leads": 10000,
  "max_cells_per_run": 80,
  "include_maps": true,
  "include_linkedin": true,
  "include_instagram": true,
  "include_web": true,
  "include_yelp": true,
  "include_facebook": true
}
```

## What happens
1. **"New Jersey"** expands to 70+ cities/counties (Hoboken, Newark, Cherry Hill, Bergen County, …)
2. Queries expand (med spa, botox, hydrafacial, laser, …)
3. Each cell scanned with all sources → merge → entity resolve
4. **tenant_seen** skips already delivered
5. Enrich → intent/pitch → gate → rank → deliver **high quality only**

## Realistic plan for 10k
| Day | target_new_leads | cells | Notes |
|-----|------------------|-------|-------|
| 1 | 2500 | 40 | North + Central NJ |
| 2 | 2500 | 40 | least-scanned cells |
| 3 | 2500 | 40 | South + counties |
| 4 | 2500 | 40 | long-tail queries |

Or one large run `target_new_leads: 10000` with `max_cells_per_run: 80` if Serper quota allows.

## Quality still enforced
Discovery volume ≠ delivery volume. Ranker only assigns contactable, high composite leads.
