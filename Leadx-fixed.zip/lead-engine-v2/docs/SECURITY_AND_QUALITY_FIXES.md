# Critical fixes + enrichment quality upgrades

## 1. Authentication (was: open tenant_id in URL)

**Files**
- `backend/middleware/auth.py` — JWT verify (Supabase) + `tenant_members` membership check
- `lead-crm-portal/backend/crm_api_secured.py` — routes use `Depends(require_tenant)`; tenant from token

**Behavior**
- Client must send `Authorization: Bearer <supabase_jwt>`
- Optional `X-Tenant-Id` if user is in multiple workspaces
- Path `tenant_id` is only accepted if it matches verified membership
- Dev bypass: `LEAD_ENGINE_DEV_AUTH_BYPASS=true` + `X-Tenant-Id` (never in prod)

**Wire-up**
```python
from backend.middleware.auth import require_tenant
# Use crm_api_secured.router instead of open crm_api
app.include_router(secured_router)
```

---

## 2. Row-Level Security (Supabase)

**File:** `sql/004_rls_and_auth.sql`

- `is_tenant_member(tenant_id)` / `current_tenant_ids()` from `auth.uid()`
- RLS on assignments, stages, activities, tasks, usage, etc.
- `leads_global` SELECT only if assigned to caller's tenant
- `api_key_pool` — no client policies (service role only)

---

## 3. Rate limiting

**File:** `backend/middleware/rate_limit.py`

| Action | Default |
|--------|---------|
| Pipeline run | 20 / hour / tenant |
| Key add | 10 / hour |
| General API | 120 / minute / user |

Uses Redis if `REDIS_URL` set; else in-memory window.

---

## 4. Tests (were empty)

**File:** `tests/test_fingerprint_exclusivity.py`

Covers:
- Fingerprint stability (www, phone formatting)
- Geo exclusivity overlap rules
- Quality gate (closed, tier, enrichment depth)

```bash
pytest tests/test_fingerprint_exclusivity.py -v
```

---

## 5. Enrichment quality

| Upgrade | File | Effect |
|---------|------|--------|
| **Email MX check** | `prod/verify.py` | Full +22 only if domain has MX/A |
| **Phone Twilio Lookup** | `prod/verify.py` | Optional; boosts score if live line |
| **Scoring v3** | `prod/scoring.py` | MX-aware points + tenant weights + freshness decay |
| **Win/loss feedback** | `prod/feedback.py` + `sql/005_outcomes_feedback.sql` | Outcomes → per-tenant weight multipliers |
| **Lookalike queries** | `feedback.lookalike_queries` | Won services/categories added to next discovery |
| **Pipeline hook** | `prod/pipeline_hooks.py` | Call after enrich, before store |

**CRM integration:** secured `change_stage` records won/lost into `lead_outcomes` automatically.

---

## Migration order

```
002_lead_engine_v2_production.sql
003_crm_portal_schema.sql
004_rls_and_auth.sql
005_outcomes_feedback.sql
```

## Env vars

```
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_JWT_SECRET=          # or JWT_SECRET
SUPABASE_SERVICE_KEY=         # backend only
REDIS_URL=                    # optional rate limit
TWILIO_ACCOUNT_SID=           # optional phone verify
TWILIO_AUTH_TOKEN=
LEAD_ENGINE_DEV_AUTH_BYPASS=false
RATE_LIMIT_PIPELINE_PER_HOUR=20
```

## Dependency

```
pip install dnspython python-jose httpx
# optional: redis
```
