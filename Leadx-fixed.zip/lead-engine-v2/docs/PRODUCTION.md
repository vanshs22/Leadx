# Lead Engine v2 — Production Guide

Sellable, multi-tenant lead generation + enrichment system for agencies and local-service businesses.

## What you get

1. **Discover** thousands of businesses via Serper Google Maps (auto key rotation)
2. **Enrich** with email, phone, booking platform, services, social, owner name  
   (Scrapling → Crawl4AI → Firecrawl → ScrapeGraphAI)
3. **Score** 0–100 + tier A/B/C (deterministic, free)
4. **Quality gate** — only deliverable leads pass
5. **Exclusivity** — no two exclusive tenants in same vertical+geo get the same lead
6. **Quota + usage_log** — billing source of truth
7. **Deliver** — Telegram digest, webhook (GHL/CRM), email (Resend), or CSV
8. **Ops** — pipeline_runs history, enrichment_failures dead-letter, key health

---

## Install

### 1. Schema
```bash
# Supabase SQL Editor
# Run: sql/002_lead_engine_v2_production.sql
```

### 2. Code
Copy into your Automiqo OS (or FastAPI) backend:

```
backend/integrations/prod/
  key_pool.py
  utils.py
  discovery.py
  enricher.py
  quality.py
  pipeline.py
backend/services/delivery.py
backend/api/prod/leads_api.py
```

Register the router:

```python
from backend.api.prod.leads_api import router as leads_v2_router
app.include_router(leads_v2_router)
```

### 3. Dependencies
```bash
pip install scrapling crawl4ai scrapegraphai httpx
playwright install   # if using browser modes
```

### 4. Keys
```sql
INSERT INTO api_key_pool (provider, key_value, label, status) VALUES
  ('serper',    'key1', 'serper-1', 'active'),
  ('serper',    'key2', 'serper-2', 'active'),
  ('firecrawl', 'fc1',  'fc-1',     'active'),
  ('gemini',    'gm1',  'gemini',   'active'),
  ('resend',    're1',  'resend',   'active');
```

Or: `POST /leads/v2/keys/add`

Env fallbacks still work: `SERPER_API_KEY`, `FIRECRAWL_API_KEY`, `GOOGLE_API_KEY`, `RESEND_API_KEY`.

### 5. Tenant + ICP
```bash
curl -X POST $BACKEND/leads/v2/tenants -H 'Content-Type: application/json' -d '{
  "name": "Acme Agency",
  "plan": "growth",
  "leads_per_month_limit": 500,
  "allow_tier_b": true,
  "delivery_channel": "telegram",
  "delivery_config": { "bot_token": "123:ABC", "chat_id": "-100123" }
}'

curl -X POST $BACKEND/leads/v2/icp -H 'Content-Type: application/json' -d '{
  "tenant_id": "<uuid>",
  "vertical": "medspa",
  "geo": ["Hoboken NJ", "Jersey City NJ", "Newark NJ"],
  "keywords": ["med spa", "aesthetics", "botox clinic"],
  "exclusivity": "exclusive"
}'
```

### 6. n8n
Import `n8n/lead_engine_v2_production.json`.  
Set env: `BACKEND_URL`, activate.

---

## Run

**Single tenant (manual / agent):**
```bash
curl -X POST $BACKEND/leads/v2/pipeline/run \
  -H 'Content-Type: application/json' \
  -d '{
    "tenant_id": "<uuid>",
    "icp_id": "<uuid>",
    "limit_per_location": 80,
    "max_enrich_concurrent": 8
  }'
```

**All ICPs (cron does this daily):**
```bash
curl -X POST $BACKEND/leads/v2/pipeline/run-all-icps \
  -d '{"limit_per_location": 40}'
```

**Client list:**
```bash
curl $BACKEND/leads/v2/<tenant_id>/leads?status=new&limit=50
```

**Key health:**
```bash
curl $BACKEND/leads/v2/keys/health
```

---

## Quality gate (what clients actually receive)

A lead is delivered only if **all** pass:

| Rule | Detail |
|------|--------|
| Tier | A always; B only if plan allows |
| Open | `business_status != CLOSED` |
| Contact | phone + website present |
| Enrichment | ≥ 2 of: valid email, booking, services, social, owner name |
| Exclusivity | no other exclusive tenant holds it in same vertical + overlapping geo |
| Recency | not delivered to *this* tenant in last 90 days |
| Quota | under monthly `leads_per_month_limit` |

---

## Delivery channels

| Channel | Config keys |
|---------|-------------|
| `telegram` | `bot_token`, `chat_id` |
| `webhook` | `url` (optional `headers`) — posts JSON array of leads |
| `email` | `to` — Resend sends summary + CSV-like body |
| `csv` | returned in API response (`delivery.csv`) |

---

## Scaling to thousands

- `limit_per_location` × locations × query variants  
  Example: 5 cities × 3 queries × 80 ≈ **~1,200 unique** after fingerprint dedup
- Enrichment concurrency: 6–10 is safe; raise carefully
- Key pool keeps Serper/Firecrawl alive as individual keys cool down or exhaust
- Closed businesses filtered at discovery; quality gate filters the rest

---

## Ops checklist before first paying client

- [ ] Run schema `002_...production.sql`
- [ ] Seed ≥2 Serper keys in pool
- [ ] Create 1 test tenant + ICP
- [ ] Run pipeline for 1 city, inspect `pipeline_runs` + `enrichment_failures`
- [ ] Confirm Telegram/webhook delivery works
- [ ] Check `/leads/v2/keys/health` after a run
- [ ] Measure enrichment_ok rate (target >60% on sites with websites)
- [ ] Review 20 sample Tier-A leads manually for quality
- [ ] Set real monthly limits + exclusivity flags
- [ ] Add basic privacy note / data-source disclosure for clients

---

## Legal / compliance note

You are scraping public business listing data and public websites.  
Before selling at scale:

- Respect robots.txt / ToS of data sources where required
- Do not claim “guaranteed emails” — enrichment is best-effort
- Provide an opt-out path for businesses that contact you
- For SMS/email outreach by *your clients*, they need their own TCPA/CAN-SPAM compliance

This system delivers **data**, not a guarantee that outreach is lawful in every jurisdiction.

---

## File map

```
lead-engine-v2/
├── sql/002_lead_engine_v2_production.sql
├── backend/
│   ├── integrations/prod/
│   │   ├── key_pool.py      # rotation + cooldown
│   │   ├── utils.py         # phone/email/fingerprint
│   │   ├── discovery.py     # Serper Maps
│   │   ├── enricher.py      # Scrapling→Crawl4AI→Firecrawl→ScrapeGraphAI
│   │   ├── quality.py       # score + gate + exclusivity + quota
│   │   └── pipeline.py      # full orchestrator
│   ├── services/delivery.py # Telegram / webhook / email / CSV
│   └── api/prod/leads_api.py
├── n8n/lead_engine_v2_production.json
└── docs/PRODUCTION.md
```
