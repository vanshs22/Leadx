-- Win/loss feedback storage for adaptive scoring + lookalikes

CREATE TABLE IF NOT EXISTS lead_outcomes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  outcome       text NOT NULL CHECK (outcome IN ('won', 'lost')),
  reason        text,
  features      jsonb NOT NULL DEFAULT '{}',
  recorded_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (assignment_id)
);

CREATE INDEX IF NOT EXISTS idx_outcomes_tenant ON lead_outcomes (tenant_id, outcome);
CREATE INDEX IF NOT EXISTS idx_outcomes_features ON lead_outcomes USING gin (features);

ALTER TABLE lead_outcomes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS outcomes_select ON lead_outcomes;
CREATE POLICY outcomes_select ON lead_outcomes FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS outcomes_insert ON lead_outcomes;
CREATE POLICY outcomes_insert ON lead_outcomes FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));

-- Optional: store last verification timestamps on enrichment
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_mx_ok boolean,
  ADD COLUMN IF NOT EXISTS phone_verified boolean,
  ADD COLUMN IF NOT EXISTS phone_line_type text,
  ADD COLUMN IF NOT EXISTS verified_at timestamptz;

-- Freshness: track when score was last computed
ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS stale boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS refresh_after timestamptz;
