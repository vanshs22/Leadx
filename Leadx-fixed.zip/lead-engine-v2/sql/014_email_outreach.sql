CREATE TABLE IF NOT EXISTS email_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  to_email      text NOT NULL,
  subject       text,
  status        text NOT NULL DEFAULT 'queued',
  provider      text,
  provider_id   text,
  error         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_sends_tenant ON email_sends (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_sends_assignment ON email_sends (assignment_id);
