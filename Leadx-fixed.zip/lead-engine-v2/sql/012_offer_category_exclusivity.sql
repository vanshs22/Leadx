-- Competitive exclusivity: lock only against same offer_category (seller type),
-- not against every ICP that targets the same vertical/geo.
--
-- Example: hair-dryer seller + hair-cream seller both target NJ salons → BOTH OK.
--          two SEO agencies targeting NJ salons → CONFLICT if exclusive.

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_category text;

-- Human label for UI
ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_label text;

COMMENT ON COLUMN icp_profiles.offer_category IS
  'Competitive lock key. Same category + overlapping geo + exclusive = conflict. Different categories share the lead.';

COMMENT ON COLUMN icp_profiles.vertical IS
  'Target industry of the LEAD (salon, medspa). NOT the exclusivity lock.';

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS offer_category text;

CREATE INDEX IF NOT EXISTS idx_icp_offer_category
  ON icp_profiles (lower(offer_category)) WHERE active = true;

CREATE INDEX IF NOT EXISTS idx_assignments_offer_cat
  ON lead_assignments (lead_id, lower(offer_category))
  WHERE status NOT IN ('rejected', 'expired');

-- Backfill: if offer_category null, use vertical as conservative default
-- (operator should set real categories for multi-ICP same-vertical sharing)
UPDATE icp_profiles
SET offer_category = lower(regexp_replace(vertical, '\s+', '_', 'g'))
WHERE offer_category IS NULL OR offer_category = '';

UPDATE lead_assignments la
SET offer_category = icp.offer_category
FROM icp_profiles icp
WHERE la.icp_id = icp.id
  AND (la.offer_category IS NULL OR la.offer_category = '');

-- New exclusivity function: compete on offer_category, not vertical alone
CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[],
  p_offer_category text DEFAULT NULL
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
  v_offer text;
BEGIN
  -- Prefer explicit offer category; fall back to vertical (legacy)
  v_offer := lower(nullif(trim(p_offer_category), ''));
  IF v_offer IS NULL THEN
    v_offer := lower(nullif(trim(p_vertical), ''));
  END IF;

  IF v_offer IS NULL THEN
    RETURN false; -- cannot lock without a category
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    LEFT JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected', 'expired')
      AND COALESCE(icp.exclusivity, 'exclusive') = 'exclusive'
      -- SAME competitive set only
      AND lower(COALESCE(nullif(la.offer_category, ''), nullif(icp.offer_category, ''), icp.vertical, la.vertical, ''))
          = v_offer
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR p_geo IS NULL
        OR cardinality(p_geo) = 0
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;

  RETURN conflict_exists;
END;
$$;
