-- =============================================================================
-- Automiqo Lead Engine v2 — PRODUCTION Multi-Tenant Schema
-- Idempotent. Run in Supabase SQL Editor after 001 if present.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- 1. API Key Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_key_pool (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider       text NOT NULL CHECK (provider IN (
                   'serper','firecrawl','anthropic','gemini','groq','openai','resend'
                 )),
  key_value      text NOT NULL,
  label          text,
  status         text NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active','exhausted','disabled','cooling')),
  credits_used   int  NOT NULL DEFAULT 0,
  credits_limit  int,
  error_count    int  NOT NULL DEFAULT 0,
  last_error     text,
  last_used_at   timestamptz,
  cooldown_until timestamptz,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, key_value)
);

CREATE INDEX IF NOT EXISTS idx_api_key_pool_live
  ON api_key_pool (provider, status, last_used_at NULLS FIRST)
  WHERE status IN ('active','cooling');

-- ---------------------------------------------------------------------------
-- 2. Tenants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenants (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  text NOT NULL,
  slug                  text UNIQUE,
  plan                  text NOT NULL DEFAULT 'starter'
                          CHECK (plan IN ('starter','growth','premium','enterprise')),
  leads_per_month_limit int  NOT NULL DEFAULT 100,
  allow_tier_b          boolean NOT NULL DEFAULT false,
  delivery_channel      text NOT NULL DEFAULT 'telegram'
                          CHECK (delivery_channel IN ('telegram','webhook','email','portal','csv')),
  delivery_config       jsonb NOT NULL DEFAULT '{}',
  status                text NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','paused','churned')),
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants (status) WHERE status = 'active';

-- ---------------------------------------------------------------------------
-- 3. ICP Profiles
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS icp_profiles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL DEFAULT 'default',
  vertical      text NOT NULL,
  geo           jsonb NOT NULL DEFAULT '[]',
  keywords      jsonb NOT NULL DEFAULT '[]',
  weights       jsonb NOT NULL DEFAULT '{}',
  exclusivity   text NOT NULL DEFAULT 'exclusive'
                  CHECK (exclusivity IN ('exclusive','shared')),
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_icp_tenant_active ON icp_profiles (tenant_id) WHERE active = true;
CREATE INDEX IF NOT EXISTS idx_icp_vertical ON icp_profiles (vertical);

-- ---------------------------------------------------------------------------
-- 4. Global Leads Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads_global (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint       text NOT NULL UNIQUE,
  phone_normalized  text,
  phone_e164        text,
  name              text NOT NULL,
  name_normalized   text,
  address           text,
  city              text,
  state             text,
  website           text,
  website_domain    text,
  category          text,
  business_status   text NOT NULL DEFAULT 'OPERATIONAL'
                      CHECK (business_status IN ('OPERATIONAL','CLOSED','TEMPORARILY_CLOSED','UNKNOWN')),
  google_rating     numeric(2,1),
  review_count      int NOT NULL DEFAULT 0,
  google_place_id   text,
  source            text NOT NULL DEFAULT 'google_maps_serper',
  source_url        text,
  raw_data          jsonb NOT NULL DEFAULT '{}',
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_global_phone
  ON leads_global (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_domain
  ON leads_global (website_domain) WHERE website_domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_name_trgm
  ON leads_global USING gin (name_normalized gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_leads_global_status ON leads_global (business_status);

-- ---------------------------------------------------------------------------
-- 5. Enrichment
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrichment (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id           uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  email             text,
  email_valid       boolean,
  emails            text[] NOT NULL DEFAULT '{}',
  phone_from_web    text,
  has_booking       boolean NOT NULL DEFAULT false,
  booking_platform  text,
  services          text[] NOT NULL DEFAULT '{}',
  social_links      jsonb NOT NULL DEFAULT '{}',
  tech_stack        text[] NOT NULL DEFAULT '{}',
  owner_name        text,
  markdown_summary  text,
  raw_extraction    jsonb NOT NULL DEFAULT '{}',
  enrichment_method text,
  enrichment_ok     boolean NOT NULL DEFAULT false,
  error             text,
  extracted_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_enrichment_email ON enrichment (email) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_enrichment_ok ON enrichment (enrichment_ok) WHERE enrichment_ok = true;

-- ---------------------------------------------------------------------------
-- 6. Scores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scores (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id             uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  deterministic_score int  NOT NULL DEFAULT 0,
  llm_score           int,
  total_score         int  NOT NULL DEFAULT 0,
  tier                text NOT NULL DEFAULT 'C' CHECK (tier IN ('A','B','C')),
  reasoning           text,
  scored_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_scores_tier_score ON scores (tier, total_score DESC);

-- ---------------------------------------------------------------------------
-- 7. Lead Assignments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_assignments (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id          uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id           uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  vertical         text NOT NULL,
  geo_tags         text[] NOT NULL DEFAULT '{}',
  delivered_at     timestamptz,
  delivery_channel text,
  delivery_status  text NOT NULL DEFAULT 'pending'
                     CHECK (delivery_status IN ('pending','sent','failed','skipped')),
  delivery_error   text,
  status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','contacted','won','rejected','expired')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id, tenant_id)
);

CREATE INDEX IF NOT EXISTS idx_assignments_tenant_status ON lead_assignments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_exclusivity
  ON lead_assignments (vertical, lead_id) WHERE status NOT IN ('rejected','expired');
CREATE INDEX IF NOT EXISTS idx_assignments_delivered ON lead_assignments (tenant_id, delivered_at DESC);

-- ---------------------------------------------------------------------------
-- 8. Usage Log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  period          date NOT NULL,
  leads_delivered int  NOT NULL DEFAULT 0,
  tier_a_count    int  NOT NULL DEFAULT 0,
  tier_b_count    int  NOT NULL DEFAULT 0,
  tier_c_count    int  NOT NULL DEFAULT 0,
  leads_rejected  int  NOT NULL DEFAULT 0,
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, period)
);

-- ---------------------------------------------------------------------------
-- 9. Pipeline runs + dead-letter
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid REFERENCES tenants(id) ON DELETE SET NULL,
  icp_id          uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  status          text NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running','completed','failed','partial')),
  discovered      int NOT NULL DEFAULT 0,
  stored          int NOT NULL DEFAULT 0,
  enriched        int NOT NULL DEFAULT 0,
  gated_ok        int NOT NULL DEFAULT 0,
  assigned        int NOT NULL DEFAULT 0,
  delivered       int NOT NULL DEFAULT 0,
  error_message   text,
  meta            jsonb NOT NULL DEFAULT '{}',
  started_at      timestamptz NOT NULL DEFAULT now(),
  finished_at     timestamptz
);

CREATE TABLE IF NOT EXISTS enrichment_failures (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id      uuid REFERENCES leads_global(id) ON DELETE CASCADE,
  website      text,
  error        text,
  attempts     int NOT NULL DEFAULT 1,
  last_attempt timestamptz NOT NULL DEFAULT now(),
  resolved     boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_enrich_fail_unresolved
  ON enrichment_failures (resolved, last_attempt) WHERE resolved = false;

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION normalize_phone(p text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    CASE
      WHEN length(d) = 11 AND left(d,1) = '1' THEN substring(d from 2)
      WHEN length(d) = 10 THEN d
      ELSE d
    END,
    ''
  )
  FROM (SELECT regexp_replace(COALESCE(p, ''), '[^0-9]', '', 'g') AS d) s
  WHERE length(d) >= 10;
$$;

CREATE OR REPLACE FUNCTION extract_domain(url text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    lower(regexp_replace(
      regexp_replace(COALESCE(url,''), '^https?://(www\.)?', '', 'i'),
      '/.*$', ''
    )),
    ''
  );
$$;

CREATE OR REPLACE FUNCTION lead_fingerprint(p_name text, p_phone text, p_website text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT md5(
    lower(trim(COALESCE(p_name, ''))) || '|' ||
    COALESCE(normalize_phone(p_phone), '') || '|' ||
    COALESCE(extract_domain(p_website), '')
  );
$$;

CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[]
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected','expired')
      AND icp.exclusivity = 'exclusive'
      AND lower(icp.vertical) = lower(p_vertical)
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;
  RETURN conflict_exists;
END;
$$;

CREATE OR REPLACE FUNCTION bump_usage(p_tenant_id uuid, p_tier text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
BEGIN
  INSERT INTO usage_log (tenant_id, period, leads_delivered, tier_a_count, tier_b_count, tier_c_count)
  VALUES (
    p_tenant_id, p, 1,
    CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END
  )
  ON CONFLICT (tenant_id, period) DO UPDATE SET
    leads_delivered = usage_log.leads_delivered + 1,
    tier_a_count = usage_log.tier_a_count + CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    tier_b_count = usage_log.tier_b_count + CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    tier_c_count = usage_log.tier_c_count + CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END,
    updated_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE
  lim int;
  used int;
  p date := date_trunc('month', now())::date;
BEGIN
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id;
  IF lim IS NULL THEN RETURN 0; END IF;
  SELECT COALESCE(leads_delivered, 0) INTO used
  FROM usage_log WHERE tenant_id = p_tenant_id AND period = p;
  RETURN GREATEST(lim - COALESCE(used, 0), 0);
END;
$$;

CREATE OR REPLACE VIEW deliverable_leads AS
SELECT
  lg.id AS lead_id, lg.name, lg.phone_normalized, lg.phone_e164, lg.website,
  lg.address, lg.city, lg.state, lg.business_status, lg.google_rating, lg.review_count,
  e.email, e.email_valid, e.has_booking, e.booking_platform, e.services,
  e.social_links, e.owner_name, s.total_score, s.tier, s.reasoning
FROM leads_global lg
JOIN enrichment e ON e.lead_id = lg.id AND e.enrichment_ok = true
JOIN scores s ON s.lead_id = lg.id
WHERE lg.business_status IS DISTINCT FROM 'CLOSED'
  AND s.tier IN ('A', 'B')
  AND lg.phone_normalized IS NOT NULL
  AND lg.website IS NOT NULL
  AND (
    (e.email IS NOT NULL AND e.email_valid IS NOT FALSE)::int +
    (e.has_booking)::int +
    (COALESCE(array_length(e.services, 1), 0) > 0)::int +
    (e.social_links IS NOT NULL AND e.social_links != '{}'::jsonb)::int +
    (e.owner_name IS NOT NULL)::int
  ) >= 2;
