-- Team invites, white-label branding, ops metrics

-- Invite tokens for tenant_members
CREATE TABLE IF NOT EXISTS tenant_invites (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  token       text NOT NULL UNIQUE,
  invited_by  uuid,
  expires_at  timestamptz NOT NULL,
  accepted_at timestamptz,
  status      text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','accepted','expired','revoked')),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invites_token ON tenant_invites (token) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_invites_tenant ON tenant_invites (tenant_id, status);

ALTER TABLE tenant_invites ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS invites_admin ON tenant_invites;
CREATE POLICY invites_admin ON tenant_invites FOR ALL
  USING (public.is_tenant_admin(tenant_id));
DROP POLICY IF EXISTS invites_select_member ON tenant_invites;
CREATE POLICY invites_select_member ON tenant_invites FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- White-label branding on tenants
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS brand_name text,
  ADD COLUMN IF NOT EXISTS brand_logo_url text,
  ADD COLUMN IF NOT EXISTS brand_primary_color text DEFAULT '#6366f1',
  ADD COLUMN IF NOT EXISTS brand_accent_color text DEFAULT '#22c55e',
  ADD COLUMN IF NOT EXISTS brand_favicon_url text,
  ADD COLUMN IF NOT EXISTS custom_domain text,
  ADD COLUMN IF NOT EXISTS support_email text;

-- LinkedIn enrichment fields
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS linkedin_url text,
  ADD COLUMN IF NOT EXISTS linkedin_company_id text,
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS linkedin_fetched_at timestamptz;

-- Ops metrics daily rollup (pipeline health over time)
CREATE TABLE IF NOT EXISTS ops_metrics_daily (
  day               date NOT NULL,
  tenant_id         uuid,                          -- null = global/system
  pipeline_runs     int NOT NULL DEFAULT 0,
  leads_discovered  int NOT NULL DEFAULT 0,
  leads_enriched_ok int NOT NULL DEFAULT 0,
  leads_enriched_fail int NOT NULL DEFAULT 0,
  leads_gated       int NOT NULL DEFAULT 0,
  leads_assigned    int NOT NULL DEFAULT 0,
  suppression_hits  int NOT NULL DEFAULT 0,
  opt_out_hits      int NOT NULL DEFAULT 0,
  credits_issued    int NOT NULL DEFAULT 0,
  serper_calls      int NOT NULL DEFAULT 0,
  firecrawl_calls   int NOT NULL DEFAULT 0,
  avg_enrich_ms     int,
  error_samples     jsonb DEFAULT '[]',
  PRIMARY KEY (day, tenant_id)
);

-- Allow null tenant for global: use sentinel
-- Postgres UNIQUE treats NULLs as distinct — use coalesce in app or:
CREATE UNIQUE INDEX IF NOT EXISTS idx_ops_metrics_global
  ON ops_metrics_daily (day) WHERE tenant_id IS NULL;

CREATE OR REPLACE FUNCTION bump_ops_metric(
  p_day date,
  p_tenant_id uuid,
  p_field text,
  p_delta int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO ops_metrics_daily (day, tenant_id)
  VALUES (p_day, p_tenant_id)
  ON CONFLICT (day, tenant_id) DO NOTHING;

  EXECUTE format(
    'UPDATE ops_metrics_daily SET %I = COALESCE(%I, 0) + $1 WHERE day = $2 AND tenant_id IS NOT DISTINCT FROM $3',
    p_field, p_field
  ) USING p_delta, p_day, p_tenant_id;
EXCEPTION WHEN OTHERS THEN
  -- soft fail — never break pipeline for metrics
  NULL;
END;
$$;
