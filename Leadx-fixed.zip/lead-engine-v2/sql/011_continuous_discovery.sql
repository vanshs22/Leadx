-- Continuous supply: track what each ICP has already covered so runs explore NEW space.

CREATE TABLE IF NOT EXISTS discovery_coverage (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  icp_id          uuid,
  vertical        text NOT NULL,
  source          text NOT NULL,          -- maps | linkedin | instagram | web | yelp | facebook
  location_key    text NOT NULL,          -- normalized geo cell
  query_key       text NOT NULL DEFAULT '',
  page_reached    int NOT NULL DEFAULT 0,
  leads_found     int NOT NULL DEFAULT 0,
  last_run_at     timestamptz NOT NULL DEFAULT now(),
  exhausted       boolean NOT NULL DEFAULT false,  -- true when source returns 0 new
  meta            jsonb DEFAULT '{}',
  UNIQUE (icp_id, source, location_key, query_key)
);

CREATE INDEX IF NOT EXISTS idx_coverage_icp ON discovery_coverage (icp_id, exhausted, last_run_at);
CREATE INDEX IF NOT EXISTS idx_coverage_vertical ON discovery_coverage (vertical, location_key);

-- Fingerprints already delivered to a tenant (fast skip at discovery)
CREATE TABLE IF NOT EXISTS tenant_seen_leads (
  tenant_id       uuid NOT NULL,
  fingerprint     text NOT NULL,
  lead_id         uuid,
  first_seen_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_tenant_seen_fp ON tenant_seen_leads (fingerprint);

-- ICP geo expansion cells (zip / neighborhood / adjacent city)
CREATE TABLE IF NOT EXISTS icp_geo_cells (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  icp_id          uuid NOT NULL,
  cell_key        text NOT NULL,           -- "hoboken-nj" | "07030" | "jersey-city-nj"
  cell_label      text NOT NULL,          -- human label for Serper queries
  priority        int NOT NULL DEFAULT 100,
  times_scanned   int NOT NULL DEFAULT 0,
  last_scanned_at timestamptz,
  active          boolean NOT NULL DEFAULT true,
  UNIQUE (icp_id, cell_key)
);

CREATE INDEX IF NOT EXISTS idx_geo_cells_scan ON icp_geo_cells (icp_id, active, times_scanned, last_scanned_at);
