-- Differentiators: talking points, outreach, docs, recycle, freshness, territories

ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS first_touch_meta jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS recycled_from_assignment_id uuid,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz;

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS auto_first_touch boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS first_touch_channel text DEFAULT 'sms',
  ADD COLUMN IF NOT EXISTS first_touch_script text,
  ADD COLUMN IF NOT EXISTS vapi_assistant_id text,
  ADD COLUMN IF NOT EXISTS twilio_from_number text,
  ADD COLUMN IF NOT EXISTS whatsapp_from text,
  ADD COLUMN IF NOT EXISTS onboarding_defaults jsonb DEFAULT '{}';

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS client_weight_overrides jsonb DEFAULT '{}';

-- Document templates library
CREATE TABLE IF NOT EXISTS doc_templates (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE CASCADE, -- null = global
  category      text NOT NULL,  -- contract, nda, invoice, proposal, onboarding
  name          text NOT NULL,
  description   text,
  body_html     text NOT NULL,
  body_text     text,
  variables     jsonb NOT NULL DEFAULT '[]', -- ["client_name","amount",...]
  channel_hint  text DEFAULT 'email', -- email, whatsapp, both
  active        boolean DEFAULT true,
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doc_templates_cat ON doc_templates (category) WHERE active;

-- Generated docs / sends log
CREATE TABLE IF NOT EXISTS doc_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  template_id   uuid REFERENCES doc_templates(id) ON DELETE SET NULL,
  category      text,
  to_email      text,
  to_phone      text,
  channel       text NOT NULL, -- email, whatsapp
  subject       text,
  body_html     text,
  body_text     text,
  variables     jsonb DEFAULT '{}',
  status        text DEFAULT 'queued',
  provider_id   text,
  error         text,
  created_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doc_sends_tenant ON doc_sends (tenant_id, created_at DESC);

-- Outreach log
CREATE TABLE IF NOT EXISTS first_touch_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  channel       text NOT NULL,
  status        text NOT NULL,
  provider      text,
  provider_id   text,
  payload       jsonb DEFAULT '{}',
  error         text,
  created_at    timestamptz DEFAULT now()
);

-- Freshness schedule config (global defaults)
CREATE TABLE IF NOT EXISTS freshness_policy (
  tier          text PRIMARY KEY,
  reverify_days int NOT NULL
);

INSERT INTO freshness_policy (tier, reverify_days) VALUES
  ('A', 7), ('B', 21), ('C', 60)
ON CONFLICT (tier) DO NOTHING;

-- Seed a starter global template pack (short, editable)
INSERT INTO doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint)
SELECT NULL, x.category, x.name, x.description, x.body_html, x.body_text, x.variables::jsonb, x.channel_hint
FROM (VALUES
  ('contract', 'Service Agreement (simple)', '1-page services agreement',
   '<h2>Service Agreement</h2><p>This agreement is between <b>{{provider_name}}</b> and <b>{{client_name}}</b>.</p><p>Scope: {{scope}}</p><p>Fee: {{amount}} {{currency}}</p><p>Term: {{term}}</p><p>Signed: ________________</p>',
   'Service Agreement between {{provider_name}} and {{client_name}}. Scope: {{scope}}. Fee: {{amount}} {{currency}}. Term: {{term}}.',
   '["provider_name","client_name","scope","amount","currency","term"]', 'email'),
  ('nda', 'Mutual NDA', 'Short mutual confidentiality',
   '<h2>Mutual NDA</h2><p>{{party_a}} and {{party_b}} agree to keep confidential information private for {{term}}.</p>',
   'Mutual NDA between {{party_a}} and {{party_b}} for {{term}}.',
   '["party_a","party_b","term"]', 'email'),
  ('invoice', 'Standard Invoice', 'Simple invoice',
   '<h2>Invoice {{invoice_number}}</h2><p>Bill to: {{client_name}}</p><p>Amount due: <b>{{amount}} {{currency}}</b></p><p>Due: {{due_date}}</p><p>{{line_items}}</p>',
   'Invoice {{invoice_number}} to {{client_name}} for {{amount}} {{currency}}, due {{due_date}}.',
   '["invoice_number","client_name","amount","currency","due_date","line_items"]', 'both'),
  ('proposal', 'Lead Package Proposal', 'Proposal for exclusive leads',
   '<h2>Proposal</h2><p>Hi {{client_name}},</p><p>We will deliver {{lead_count}} Tier A {{vertical}} leads in {{geo}}.</p><p>Investment: {{amount}}/mo. Exclusivity: {{offer_category}} in {{geo}}.</p>',
   'Proposal for {{client_name}}: {{lead_count}} Tier A {{vertical}} leads in {{geo}} at {{amount}}/mo.',
   '["client_name","lead_count","vertical","geo","amount","offer_category"]', 'email'),
  ('onboarding', 'Client Onboarding Checklist', 'Kickoff email',
   '<h2>Welcome, {{client_name}}</h2><ol><li>Confirm ICP: {{vertical}} in {{geo}}</li><li>CRM login</li><li>Sample pack review</li><li>First pipeline run</li></ol>',
   'Welcome {{client_name}}. Confirm ICP {{vertical}} / {{geo}}, CRM login, sample pack, first run.',
   '["client_name","vertical","geo"]', 'both')
) AS x(category, name, description, body_html, body_text, variables, channel_hint)
WHERE NOT EXISTS (SELECT 1 FROM doc_templates WHERE name = x.name AND tenant_id IS NULL);
