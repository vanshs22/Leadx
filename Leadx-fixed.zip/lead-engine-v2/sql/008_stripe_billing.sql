-- Stripe billing fields + usage_log report tracking

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS stripe_customer_id text,
  ADD COLUMN IF NOT EXISTS stripe_subscription_item_id text,
  ADD COLUMN IF NOT EXISTS stripe_price_id text;

CREATE INDEX IF NOT EXISTS idx_tenants_stripe
  ON tenants (stripe_customer_id) WHERE stripe_customer_id IS NOT NULL;

ALTER TABLE usage_log
  ADD COLUMN IF NOT EXISTS stripe_reported_at timestamptz,
  ADD COLUMN IF NOT EXISTS stripe_reported_qty int;
