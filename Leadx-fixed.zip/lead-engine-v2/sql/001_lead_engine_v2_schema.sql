-- =============================================================================
-- Automiqo Lead Engine v2 — Multi-Tenant Schema
-- Run in Supabase SQL Editor (idempotent). Requires pg_trgm extension.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ---------------------------------------------------------------------------
-- 1. API Key Pool (auto-rotation)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_key_pool (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider      text NOT NULL,          -- serper | firecrawl | anthropic | gemini | groq | openai
  key_value     text NOT NULL,
  status        text NOT NULL DEFAULT 'active',  -- active | exhausted | disabled
  credits_used  int  NOT NULL DEFAULT 0,
  last_used_at  timestamptz,
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_api_key_pool_provider_status
  ON api_key_pool (provider, status, last_used_at NULLS FIRST);

-- ---------------------------------------------------------------------------
-- 2. Tenants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenants (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  text NOT NULL,
  plan                  text NOT NULL DEFAULT 'starter',  -- starter | growth | premium
  leads_per_month_limit int  NOT NULL DEFAULT 100,
  delivery_channel      text NOT NULL DEFAULT 'telegram', -- telegram | webhook | portal
  delivery_config       jsonb DEFAULT '{}',               -- bot token, chat_id, webhook_url, etc.
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- 3. ICP Profiles (Ideal Customer Profile per tenant)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS icp_profiles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL DEFAULT 'default',
  vertical      text NOT NULL,                 -- medspa | salon | gym | dental | ...
  geo           jsonb NOT NULL DEFAULT '[]',   -- ["Hoboken NJ", "Jersey City NJ"]
  keywords      jsonb NOT NULL DEFAULT '[]',   -- extra search terms
  weights       jsonb NOT NULL DEFAULT '{}',   -- scoring weight overrides
  exclusivity   text NOT NULL DEFAULT 'exclusive', -- exclusive | shared
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_icp_tenant ON icp_profiles (tenant_id) WHERE active;

-- ---------------------------------------------------------------------------
-- 4. Global Leads Pool (shared across tenants)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads_global (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint       text UNIQUE,                 -- hash of normalized name+phone+website
  phone_normalized  text UNIQUE,                 -- digits only
  name              text NOT NULL,
  address           text,
  website           text,
  category          text,
  business_status   text DEFAULT 'OPERATIONAL',  -- OPERATIONAL | CLOSED | TEMPORARILY_CLOSED
  google_rating     numeric(2,1),
  review_count      int DEFAULT 0,
  source            text DEFAULT 'google_maps_serper',
  raw_data          jsonb DEFAULT '{}',
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_leads_global_name_trgm
  ON leads_global USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_leads_global_website
  ON leads_global (website) WHERE website IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_status
  ON leads_global (business_status);

-- ---------------------------------------------------------------------------
-- 5. Enrichment (1:1 with leads_global)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrichment (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  email           text,
  emails          text[],
  phone_from_web  text,
  has_booking     boolean DEFAULT false,
  booking_platform text,
  services        text[],
  social_links    jsonb DEFAULT '{}',
  tech_stack      text[],
  markdown_summary text,               -- from Crawl4AI
  raw_extraction  jsonb DEFAULT '{}',  -- from ScrapeGraphAI
  enrichment_method text,              -- scrapling | crawl4ai | firecrawl | hybrid
  extracted_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_enrichment_email ON enrichment (email) WHERE email IS NOT NULL;

-- ---------------------------------------------------------------------------
-- 6. Scores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scores (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id             uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  deterministic_score int  NOT NULL DEFAULT 0,
  llm_score           int,
  total_score         int  NOT NULL DEFAULT 0,
  tier                text NOT NULL DEFAULT 'C',  -- A | B | C
  reasoning           text,
  scored_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_scores_tier ON scores (tier, total_score DESC);

-- ---------------------------------------------------------------------------
-- 7. Lead Assignments (exclusivity + delivery tracking)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_assignments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id        uuid REFERENCES icp_profiles(id),
  delivered_at  timestamptz,
  status        text NOT NULL DEFAULT 'new',  -- new | contacted | won | rejected | expired
  delivery_channel text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id, tenant_id)
);

CREATE INDEX IF NOT EXISTS idx_assignments_tenant_status
  ON lead_assignments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_lead
  ON lead_assignments (lead_id);

-- ---------------------------------------------------------------------------
-- 8. Usage Log (billing source of truth)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  period          date NOT NULL,               -- first of month
  leads_delivered int  NOT NULL DEFAULT 0,
  tier_a_count    int  NOT NULL DEFAULT 0,
  tier_b_count    int  NOT NULL DEFAULT 0,
  tier_c_count    int  NOT NULL DEFAULT 0,
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, period)
);

-- ---------------------------------------------------------------------------
-- Helper: normalize phone to digits only
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION normalize_phone(p text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(regexp_replace(COALESCE(p, ''), '[^0-9]', '', 'g'), '');
$$;

-- ---------------------------------------------------------------------------
-- Helper: generate fingerprint
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION lead_fingerprint(p_name text, p_phone text, p_website text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT md5(
    lower(trim(COALESCE(p_name, ''))) || '|' ||
    COALESCE(normalize_phone(p_phone), '') || '|' ||
    lower(regexp_replace(COALESCE(p_website, ''), '^https?://(www\.)?', '', 'i'))
  );
$$;

-- ---------------------------------------------------------------------------
-- Quality Gate view (for quick filtering)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW deliverable_leads AS
SELECT
  lg.id AS lead_id,
  lg.name,
  lg.phone_normalized,
  lg.website,
  lg.address,
  lg.business_status,
  lg.google_rating,
  lg.review_count,
  e.email,
  e.has_booking,
  e.booking_platform,
  e.services,
  e.social_links,
  s.total_score,
  s.tier,
  s.reasoning
FROM leads_global lg
JOIN enrichment e ON e.lead_id = lg.id
JOIN scores s ON s.lead_id = lg.id
WHERE lg.business_status IS DISTINCT FROM 'CLOSED'
  AND s.tier IN ('A', 'B')
  AND lg.phone_normalized IS NOT NULL
  AND lg.website IS NOT NULL
  AND (
    (e.email IS NOT NULL)::int +
    (e.has_booking)::int +
    (COALESCE(array_length(e.services, 1), 0) > 0)::int +
    (e.social_links IS NOT NULL AND e.social_links != '{}'::jsonb)::int
  ) >= 2;

COMMENT ON TABLE api_key_pool IS 'Rotating API keys for Serper, Firecrawl, LLM providers';
COMMENT ON TABLE leads_global IS 'Shared lead pool — one scrape, many tenants with exclusivity locks';
COMMENT ON TABLE lead_assignments IS 'Exclusivity enforcement + delivery tracking';
COMMENT ON VIEW deliverable_leads IS 'Quality-gated leads ready for assignment';
