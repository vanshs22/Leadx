-- =============================================================================
-- Next-tier: suppression, global opt-out, signals, sentiment, auto-credits
-- =============================================================================

-- Client suppression lists (tenant CRM exports — never resell these)
CREATE TABLE IF NOT EXISTS suppression_list (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  fingerprint text,                          -- same fingerprint as leads_global
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  source      text DEFAULT 'upload',         -- upload | manual | crm_sync
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_supp_tenant_fp ON suppression_list (tenant_id, fingerprint);
CREATE INDEX IF NOT EXISTS idx_supp_tenant_phone ON suppression_list (tenant_id, phone_normalized)
  WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_email ON suppression_list (tenant_id, email)
  WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_domain ON suppression_list (tenant_id, domain)
  WHERE domain IS NOT NULL;

-- Global opt-out registry (one removal = never for ANY tenant)
CREATE TABLE IF NOT EXISTS global_opt_out (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint text,
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  reason      text,
  requested_by text,                         -- email or 'admin'
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_phone
  ON global_opt_out (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_email
  ON global_opt_out (email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_domain
  ON global_opt_out (domain) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_optout_fp ON global_opt_out (fingerprint)
  WHERE fingerprint IS NOT NULL;

-- Why-now / trigger signals per lead
CREATE TABLE IF NOT EXISTS lead_signals (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id     uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  signal_type text NOT NULL CHECK (signal_type IN (
    'review_velocity_up', 'review_velocity_down',
    'site_redesign', 'new_hire', 'tech_change',
    'complaint_cluster', 'other'
  )),
  strength    numeric(4,2) DEFAULT 1.0,      -- 0–1 relative strength
  detail      jsonb DEFAULT '{}',
  detected_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_signals_lead ON lead_signals (lead_id, signal_type);

-- Review sentiment summary (one row per lead, refreshed)
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS review_sentiment jsonb,   -- {pos, neg, themes: [...], pitch_hooks: [...]}
  ADD COLUMN IF NOT EXISTS tech_stack jsonb,         -- {booking, crm, chat, analytics, ...}
  ADD COLUMN IF NOT EXISTS why_now text[],           -- short human labels
  ADD COLUMN IF NOT EXISTS last_signal_at timestamptz;

-- Auto-credit / refund log
CREATE TABLE IF NOT EXISTS lead_credits (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  lead_id       uuid,
  credit_type   text NOT NULL CHECK (credit_type IN (
    'dead_phone', 'dead_email', 'bounce', 'closed_business', 'duplicate', 'manual'
  )),
  amount        int NOT NULL DEFAULT 1,              -- leads credited back
  period        date NOT NULL,                       -- usage_log period
  detail        jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credits_tenant ON lead_credits (tenant_id, period);

-- Cross-tenant vertical priors (aggregated win rates per feature)
CREATE TABLE IF NOT EXISTS vertical_priors (
  vertical    text NOT NULL,
  feature     text NOT NULL,                         -- email, booking, reviews, owner, rating_high
  win_rate    numeric(6,4) NOT NULL DEFAULT 0.5,
  lose_rate   numeric(6,4) NOT NULL DEFAULT 0.5,
  sample_size int NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (vertical, feature)
);

-- Encrypted delivery config column (app encrypts JSON → store here)
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS delivery_config_enc text;  -- base64 AES ciphertext

-- RLS for new tables
ALTER TABLE suppression_list ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_credits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS supp_tenant ON suppression_list;
CREATE POLICY supp_tenant ON suppression_list FOR ALL
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS signals_via_assignment ON lead_signals;
CREATE POLICY signals_via_assignment ON lead_signals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = lead_signals.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS credits_tenant ON lead_credits;
CREATE POLICY credits_tenant ON lead_credits FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- global_opt_out + vertical_priors: service role only (no client policies)

-- Helper: is suppressed for tenant?
CREATE OR REPLACE FUNCTION is_suppressed(
  p_tenant_id uuid,
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM suppression_list s
    WHERE s.tenant_id = p_tenant_id
      AND (
        (p_fingerprint IS NOT NULL AND s.fingerprint = p_fingerprint)
        OR (p_phone IS NOT NULL AND s.phone_normalized = p_phone)
        OR (p_email IS NOT NULL AND lower(s.email) = lower(p_email))
        OR (p_domain IS NOT NULL AND s.domain = p_domain)
      )
  );
$$;

-- Helper: globally opted out?
CREATE OR REPLACE FUNCTION is_opted_out(
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM global_opt_out g
    WHERE
      (p_fingerprint IS NOT NULL AND g.fingerprint = p_fingerprint)
      OR (p_phone IS NOT NULL AND g.phone_normalized = p_phone)
      OR (p_email IS NOT NULL AND lower(g.email) = lower(p_email))
      OR (p_domain IS NOT NULL AND g.domain = p_domain)
  );
$$;

-- Auto-credit: decrement usage_log.leads_delivered for period
CREATE OR REPLACE FUNCTION credit_tenant_usage(
  p_tenant_id uuid,
  p_period date,
  p_amount int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE usage_log
  SET leads_delivered = GREATEST(0, leads_delivered - p_amount)
  WHERE tenant_id = p_tenant_id AND period = p_period;
END;
$$;
