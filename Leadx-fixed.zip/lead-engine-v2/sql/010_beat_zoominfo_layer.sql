-- Layer that closes gaps vs ZoomInfo/Apollo for LOCAL B2B:
-- contacts (people), intent score, pitch lines, QA feedback, sample packs, sequences.

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]';

ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS pitch_line text;

-- Named decision-makers / people (Apollo-style contacts, local-first)
CREATE TABLE IF NOT EXISTS lead_contacts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  full_name       text,
  title           text,
  email           text,
  phone           text,
  linkedin_url    text,
  is_decision_maker boolean DEFAULT false,
  source          text, -- linkedin | website | serper | manual
  confidence      int DEFAULT 50,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_contacts_lead ON lead_contacts (lead_id);

-- Operator QA (accuracy proof vs ZoomInfo brand trust)
CREATE TABLE IF NOT EXISTS lead_qa (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id   uuid,
  tenant_id       uuid,
  phone_ok        boolean,
  email_ok        boolean,
  business_open   boolean,
  notes           text,
  reviewed_by     text DEFAULT 'ops',
  reviewed_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_qa_tenant ON lead_qa (tenant_id, reviewed_at DESC);

-- Sample packs for sales (beat Apollo free credits narrative)
CREATE TABLE IF NOT EXISTS sample_packs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  vertical        text,
  geo             text,
  lead_ids        uuid[] DEFAULT '{}',
  meta            jsonb DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- Territory exclusivity board (ZoomInfo has territories; we make them real)
CREATE TABLE IF NOT EXISTS territories (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  vertical        text NOT NULL,
  geo_key         text NOT NULL, -- normalized city/region key
  exclusive_until date,
  status          text NOT NULL DEFAULT 'active', -- active | expired | released
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (vertical, geo_key)  -- one exclusive owner per vertical+geo
);

-- Client "report bad lead" requests
CREATE TABLE IF NOT EXISTS bad_lead_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL,
  assignment_id   uuid NOT NULL,
  lead_id         uuid,
  reason          text NOT NULL, -- wrong_number | email_bounce | closed | duplicate | other
  detail          text,
  status          text NOT NULL DEFAULT 'open', -- open | credited | rejected
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);

ALTER TABLE lead_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_qa ENABLE ROW LEVEL SECURITY;
ALTER TABLE bad_lead_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE territories ENABLE ROW LEVEL SECURITY;
