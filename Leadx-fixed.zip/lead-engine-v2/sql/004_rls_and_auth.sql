-- =============================================================================
-- Row-Level Security + auth helpers for multi-tenant isolation
-- Run AFTER 002 (lead engine) and 003 (CRM portal) schemas.
-- =============================================================================

-- Map auth.uid() → tenant_id via tenant_members
CREATE OR REPLACE FUNCTION public.current_tenant_ids()
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT tenant_id
  FROM tenant_members
  WHERE auth_user_id = auth.uid()
    AND status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_member(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_admin(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
      AND role IN ('owner', 'admin')
  );
$$;

-- Service role bypasses RLS; anon/authenticated are restricted.
-- Enable RLS on all tenant-scoped tables.

ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE icp_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrichment ENABLE ROW LEVEL SECURITY;
ALTER TABLE scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_segments ENABLE ROW LEVEL SECURITY;
ALTER TABLE crm_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrichment_failures ENABLE ROW LEVEL SECURITY;

-- leads_global is SHARED pool — members can SELECT only leads assigned to them
ALTER TABLE leads_global ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if re-running
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT policyname, tablename FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN (
        'tenants','icp_profiles','lead_assignments','leads_global',
        'enrichment','scores','usage_log','pipeline_runs','pipeline_stages',
        'lead_activities','lead_tasks','lead_tags','tenant_members',
        'lead_segments','crm_audit_log','enrichment_failures'
      )
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- TENANTS: members see only their tenants
CREATE POLICY tenants_select ON tenants FOR SELECT
  USING (id IN (SELECT public.current_tenant_ids()));
CREATE POLICY tenants_update ON tenants FOR UPDATE
  USING (public.is_tenant_admin(id));

-- ICP
CREATE POLICY icp_select ON icp_profiles FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY icp_write ON icp_profiles FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- ASSIGNMENTS (core isolation)
CREATE POLICY assignments_select ON lead_assignments FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_insert ON lead_assignments FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_update ON lead_assignments FOR UPDATE
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_delete ON lead_assignments FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- leads_global: only if assigned to one of user's tenants
CREATE POLICY leads_global_select ON leads_global FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = leads_global.id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
-- Writes only via service role (backend pipeline)

-- enrichment / scores: via assigned leads
CREATE POLICY enrichment_select ON enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
CREATE POLICY scores_select ON scores FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = scores.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- usage_log
CREATE POLICY usage_select ON usage_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- pipeline_runs
CREATE POLICY runs_select ON pipeline_runs FOR SELECT
  USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id));

-- CRM tables
CREATE POLICY stages_all ON pipeline_stages FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY activities_all ON lead_activities FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tasks_all ON lead_tasks FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tags_all ON lead_tags FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY segments_all ON lead_segments FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY audit_select ON crm_audit_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_select ON tenant_members FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_admin ON tenant_members FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- api_key_pool: NEVER exposed to clients (service role only)
ALTER TABLE api_key_pool ENABLE ROW LEVEL SECURITY;
-- no policies for authenticated → only service_role can access

COMMENT ON FUNCTION public.current_tenant_ids IS 'Tenants the JWT user belongs to';
COMMENT ON FUNCTION public.is_tenant_member IS 'True if auth.uid() is active member of tenant';
