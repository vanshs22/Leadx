-- Social enrichment (LinkedIn via microservice + Instagram via instaloader)
-- Runs only on quality-gated leads before assign.

CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,              -- serper | drissbri | site_html
  source_instagram        text,              -- instaloader
  enriched_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS social_enrichment_failures (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id    uuid,
  source     text NOT NULL,                  -- linkedin | instagram
  error      text,
  failed_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_social_fail_at ON social_enrichment_failures (failed_at DESC);

ALTER TABLE social_enrichment ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_enrichment_failures ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS social_enrich_select ON social_enrichment;
CREATE POLICY social_enrich_select ON social_enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS social_fail_select ON social_enrichment_failures;
CREATE POLICY social_fail_select ON social_enrichment_failures FOR SELECT
  USING (
    lead_id IS NULL OR EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment_failures.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- Mirror key fields onto enrichment for CRM views
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS instagram_handle text,
  ADD COLUMN IF NOT EXISTS instagram_followers int,
  ADD COLUMN IF NOT EXISTS instagram_last_post_at timestamptz,
  ADD COLUMN IF NOT EXISTS instagram_stale boolean;
