from backend.integrations.prod.pitch import build_pitch_line
from backend.integrations.prod.intent import compute_intent

def test_pitch_no_booking():
    line = build_pitch_line({"name": "Glow", "website": "https://x.com", "booking_platform": None})
    assert "booking" in line.lower() or "scheduling" in line.lower()

def test_pitch_stale_ig():
    line = build_pitch_line({"name": "Glow", "instagram_stale": True})
    assert "instagram" in line.lower() or "content" in line.lower()

def test_intent_boost_no_booking():
    s, reasons = compute_intent({"website": "https://x.com", "business_status": "OPERATIONAL"})
    assert s >= 50
    assert any("booking" in r.lower() for r in reasons)

def test_intent_closed_zero():
    s, _ = compute_intent({"business_status": "CLOSED"})
    assert s == 0

def test_intent_decision_maker():
    s1, _ = compute_intent({"website": "https://x.com"})
    s2, _ = compute_intent({"website": "https://x.com", "owner_name": "Jane"})
    assert s2 > s1
