"""LinkedIn URL extraction, DM title filter, invite token shape, ops alert rules."""
from __future__ import annotations

import re
import secrets


LINKEDIN_COMPANY_RE = re.compile(
    r"https?://(?:www\.)?linkedin\.com/company/([a-zA-Z0-9\-_%]+)/?",
    re.I,
)
DM_TITLE_HINTS = re.compile(
    r"\b(owner|founder|co-?founder|ceo|president|director|manager|"
    r"practice\s+manager|spa\s+director)\b",
    re.I,
)


def extract_company_url(results, company_name):
    name_l = (company_name or "").lower()
    tokens = [t for t in re.split(r"\W+", name_l) if len(t) > 2]
    best, best_score = None, 0
    for item in results:
        link = item.get("link") or ""
        m = LINKEDIN_COMPANY_RE.search(link)
        if not m:
            continue
        title = (item.get("title") or "").lower()
        snippet = (item.get("snippet") or "").lower()
        score = sum(1 for t in tokens if t in title or t in snippet)
        if score > best_score:
            best_score = score
            best = link.split("?")[0].rstrip("/")
    return best


def extract_people(results):
    people = []
    for item in results:
        link = item.get("link") or ""
        if "/in/" not in link:
            continue
        title = item.get("title") or ""
        if not DM_TITLE_HINTS.search(title + " " + (item.get("snippet") or "")):
            continue
        people.append({
            "name": title.split("-")[0].split("|")[0].strip(),
            "linkedin_url": link.split("?")[0],
        })
    return people


def test_extract_company_prefers_name_match():
    results = [
        {"link": "https://linkedin.com/company/other-spa", "title": "Other Spa"},
        {"link": "https://www.linkedin.com/company/glow-med-spa/?trk=1", "title": "Glow Med Spa | LinkedIn", "snippet": "Glow medspa hoboken"},
    ]
    url = extract_company_url(results, "Glow Med Spa")
    assert url == "https://www.linkedin.com/company/glow-med-spa"
    assert "glow-med-spa" in url


def test_extract_company_ignores_non_company():
    results = [{"link": "https://linkedin.com/in/someone", "title": "Someone"}]
    assert extract_company_url(results, "Glow") is None


def test_dm_filter_keeps_owner():
    results = [
        {"link": "https://linkedin.com/in/jane", "title": "Jane Doe - Owner - Glow Med Spa | LinkedIn"},
        {"link": "https://linkedin.com/in/bob", "title": "Bob Smith - Intern | LinkedIn", "snippet": "student"},
    ]
    people = extract_people(results)
    assert len(people) == 1
    assert "Jane" in people[0]["name"]


def test_dm_filter_practice_manager():
    results = [
        {"link": "https://linkedin.com/in/amy", "title": "Amy - Practice Manager at Dental Co"},
    ]
    assert len(extract_people(results)) == 1


def test_invite_token_entropy():
    t1 = secrets.token_urlsafe(32)
    t2 = secrets.token_urlsafe(32)
    assert t1 != t2
    assert len(t1) >= 32


def test_ops_alert_low_enrich_rate():
    def alerts(ok, fail, keys_available=1):
        out = []
        total = ok + fail
        rate = 100 * ok / total if total else None
        if rate is not None and rate < 50 and total >= 20:
            out.append("low_enrich")
        if keys_available == 0:
            out.append("keys_exhausted")
        return out

    assert "low_enrich" in alerts(5, 20)
    assert "low_enrich" not in alerts(5, 5)  # total < 20
    assert "keys_exhausted" in alerts(100, 0, keys_available=0)


def test_branding_css_vars():
    # pure logic: primary color format
    color = "#6366f1"
    assert re.match(r"^#[0-9a-fA-F]{6}$", color)
