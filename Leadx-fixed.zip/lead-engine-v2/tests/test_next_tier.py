"""Next-tier: tech detection, signals, suppression matching, credits idempotency logic, priors mult."""
from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ─── Tech detection (inline mirror of signals.TECH patterns) ─────────────────

TECH_PATTERNS = {
    "booking": {
        "vagaro": [r"vagaro\.com", r"cdn\.vagaro"],
        "mindbody": [r"mindbodyonline\.com", r"healcode"],
        "calendly": [r"calendly\.com"],
        "fresha": [r"fresha\.com"],
    },
    "chat": {
        "intercom": [r"intercom\.io"],
        "tidio": [r"tidio\.co"],
    },
}


def detect_tech(html: str) -> dict:
    blob = (html or "").lower()
    found = {}
    for cat, platforms in TECH_PATTERNS.items():
        for name, pats in platforms.items():
            if any(re.search(p, blob) for p in pats):
                found[cat] = name
                break
    return {
        "booking_platform": found.get("booking"),
        "has_booking": "booking" in found,
        "chat": found.get("chat"),
        "stack": found,
    }


def test_detects_vagaro():
    html = '<script src="https://cdn.vagaro.com/widget.js"></script>'
    t = detect_tech(html)
    assert t["booking_platform"] == "vagaro"
    assert t["has_booking"] is True


def test_detects_mindbody():
    html = 'book online at mindbodyonline.com/widgets'
    assert detect_tech(html)["booking_platform"] == "mindbody"


def test_detects_no_booking():
    assert detect_tech("<html>hello</html>")["has_booking"] is False


def test_detects_intercom():
    assert detect_tech('widget.intercom.io/widget/abc')["chat"] == "intercom"


# ─── Review velocity ─────────────────────────────────────────────────────────

def review_velocity(current, previous=None):
    if previous is None:
        if current >= 80:
            return {"signal_type": "review_velocity_up", "strength": 0.3}
        return None
    delta = current - previous
    if previous <= 0:
        return None
    pct = delta / previous
    if pct >= 0.15 and delta >= 5:
        return {"signal_type": "review_velocity_up", "strength": min(1.0, pct)}
    if pct <= -0.1 and abs(delta) >= 3:
        return {"signal_type": "review_velocity_down", "strength": min(1.0, abs(pct))}
    return None


def test_velocity_spike():
    s = review_velocity(100, 70)
    assert s and s["signal_type"] == "review_velocity_up"


def test_velocity_drop():
    s = review_velocity(50, 80)
    assert s and s["signal_type"] == "review_velocity_down"


def test_velocity_stable_none():
    assert review_velocity(55, 50) is None


# ─── Sentiment keywords ──────────────────────────────────────────────────────

def mine_keywords(texts):
    blob = " ".join(texts).lower()
    neg = []
    if re.search(r"hard to book|couldn.?t book", blob):
        neg.append("hard to book")
    if re.search(r"no one answers|never answer", blob):
        neg.append("no one answers")
    hooks = []
    if "hard to book" in neg:
        hooks.append("scheduling angle")
    if "no one answers" in neg:
        hooks.append("call-tracking angle")
    return {"themes": neg, "pitch_hooks": hooks, "neg": len(neg)}


def test_sentiment_hard_to_book():
    r = mine_keywords(["Great results but hard to book an appointment"])
    assert "hard to book" in r["themes"]
    assert r["pitch_hooks"]


def test_sentiment_phone():
    r = mine_keywords(["They never answer the phone"])
    assert "no one answers" in r["themes"]


# ─── Suppression match logic ─────────────────────────────────────────────────

def matches_suppression(lead, rules):
    """rules: list of {phone, email, domain, fingerprint}"""
    for r in rules:
        if r.get("phone") and lead.get("phone") == r["phone"]:
            return True
        if r.get("email") and (lead.get("email") or "").lower() == r["email"].lower():
            return True
        if r.get("domain") and lead.get("domain") == r["domain"]:
            return True
        if r.get("fingerprint") and lead.get("fingerprint") == r["fingerprint"]:
            return True
    return False


def test_suppression_by_phone():
    assert matches_suppression(
        {"phone": "2015550100", "email": "a@b.com"},
        [{"phone": "2015550100"}],
    )


def test_suppression_by_email_case_insensitive():
    assert matches_suppression(
        {"email": "Owner@Glow.COM"},
        [{"email": "owner@glow.com"}],
    )


def test_not_suppressed():
    assert not matches_suppression(
        {"phone": "2015550199"},
        [{"phone": "2015550100"}],
    )


# ─── Credit idempotency ──────────────────────────────────────────────────────

def credit_once(store, assignment_id, credit_type):
    key = (assignment_id, credit_type)
    if key in store:
        return {"already_credited": True, "credited": 0}
    store.add(key)
    return {"already_credited": False, "credited": 1}


def test_credit_idempotent():
    store = set()
    r1 = credit_once(store, "a1", "dead_phone")
    r2 = credit_once(store, "a1", "dead_phone")
    r3 = credit_once(store, "a1", "dead_email")
    assert r1["credited"] == 1
    assert r2["already_credited"] is True
    assert r3["credited"] == 1


# ─── Prior multiplier ────────────────────────────────────────────────────────

def prior_mult(win_rate, lose_rate):
    if win_rate + lose_rate < 0.05:
        return 1.0
    ratio = (win_rate + 0.05) / (lose_rate + 0.05)
    return max(0.5, min(1.5, ratio))


def test_prior_boost():
    assert prior_mult(0.8, 0.2) > 1.0


def test_prior_dampen():
    assert prior_mult(0.2, 0.8) < 1.0


def test_prior_clamp():
    assert prior_mult(1.0, 0.0) <= 1.5
    assert prior_mult(0.0, 1.0) >= 0.5


# ─── Redesign hints ──────────────────────────────────────────────────────────

def redesign_hints(html, year=2026):
    signals = []
    if re.search(rf"©\s*{year}|copyright\s+{year}", html, re.I):
        signals.append("copyright_current_year")
    if re.search(r"new\s+(look|website|design)|we.?ve\s+redesigned", html, re.I):
        signals.append("redesign_copy")
    return signals or None


def test_redesign_copy():
    assert redesign_hints("Welcome to our new website!") is not None


def test_no_redesign():
    assert redesign_hints("Established 1999. Same as always.") is None
