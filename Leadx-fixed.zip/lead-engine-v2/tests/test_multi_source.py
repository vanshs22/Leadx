from backend.integrations.prod.multi_source_discovery import merge_leads

def test_merge_boosts_multi_source():
    a = [{
        "name": "Glow Spa",
        "fingerprint": "fp1",
        "source": "maps",
        "sources_hit": ["maps"],
        "discovery_quality": 60,
        "phone": "2015550100",
    }]
    b = [{
        "name": "Glow Spa",
        "fingerprint": "fp2",  # different fp but same name → collapse
        "source": "instagram",
        "sources_hit": ["instagram"],
        "discovery_quality": 55,
        "instagram_handle": "glow",
    }]
    # same fingerprint merge
    c = [{
        "name": "Other",
        "fingerprint": "fp1",
        "source": "linkedin",
        "sources_hit": ["linkedin"],
        "discovery_quality": 70,
        "linkedin_url": "https://linkedin.com/company/x",
    }]
    merged = merge_leads([a, c], min_quality=50)
    assert len(merged) == 1
    assert "maps" in merged[0]["sources_hit"] and "linkedin" in merged[0]["sources_hit"]
    assert merged[0]["discovery_quality"] >= 70

def test_low_quality_dropped():
    batch = [{"name": "x", "fingerprint": "z", "discovery_quality": 20, "source": "web", "sources_hit": ["web"]}]
    assert merge_leads([batch], min_quality=50) == []
