from backend.integrations.prod.entity_resolution import resolve_entities, entity_keys
from backend.integrations.prod.delivery_ranker import (
    composite_quality, is_contactable, rank_for_delivery, diversity_cap,
)

def test_entity_merge_by_phone():
    leads = [
        {"name": "Glow Spa", "fingerprint": "a", "phone_normalized": "2015550100", "source": "maps", "sources_hit": ["maps"], "discovery_quality": 60},
        {"name": "Glow Medical Spa", "fingerprint": "b", "phone_normalized": "2015550100", "source": "web", "sources_hit": ["web"], "discovery_quality": 55, "website": "https://glow.com"},
    ]
    m = resolve_entities(leads)
    assert len(m) == 1
    assert m[0].get("website")
    assert "maps" in m[0]["sources_hit"] and "web" in m[0]["sources_hit"]

def test_entity_merge_by_domain():
    leads = [
        {"name": "A", "fingerprint": "1", "website": "https://www.acme.com", "website_domain": "acme.com", "sources_hit": ["web"], "discovery_quality": 50},
        {"name": "Acme LLC", "fingerprint": "2", "website": "https://acme.com/about", "website_domain": "acme.com", "sources_hit": ["maps"], "discovery_quality": 70, "phone": "555"},
    ]
    m = resolve_entities(leads)
    assert len(m) == 1

def test_contactable_phone_or_email():
    assert is_contactable({"phone": "2015550100"})
    assert is_contactable({"email": "a@b.com", "email_valid": True})
    assert not is_contactable({"website": "https://x.com"})

def test_rank_prefers_multi_source():
    leads = [
        {"name": "Weak", "tier": "A", "score": 80, "phone": "1", "sources_hit": ["maps"], "intent_score": 40, "discovery_quality": 50},
        {"name": "Strong", "tier": "A", "score": 75, "phone": "2", "email": "x@y.com", "email_valid": True, "sources_hit": ["maps", "linkedin", "instagram"], "intent_score": 80, "discovery_quality": 90},
    ]
    ranked = rank_for_delivery(leads, allow_tier_b=False)
    assert ranked[0]["name"] == "Strong"

def test_diversity_cap_domain():
    leads = [
        {"name": "A1", "website_domain": "chain.com"},
        {"name": "A2", "website_domain": "chain.com"},
        {"name": "B", "website_domain": "other.com"},
    ]
    out = diversity_cap(leads, max_per_domain=1)
    assert len(out) == 2
