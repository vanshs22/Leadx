"""
Unit tests for product differentiators: dedup fingerprint + exclusivity geo overlap.
Run: pytest tests/test_fingerprint_exclusivity.py -v
"""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

# Allow importing utils without full app
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def normalize_phone(phone: str | None) -> str | None:
    if not phone:
        return None
    digits = re.sub(r"[^0-9]", "", phone)
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) == 10:
        return digits
    if len(digits) > 10:
        return digits[-10:]
    return None


def extract_domain(url: str | None) -> str | None:
    if not url:
        return None
    u = re.sub(r"^https?://(www\.)?", "", url.strip(), flags=re.I)
    u = u.split("/")[0].split("?")[0].lower()
    return u or None


def fingerprint(name: str, phone: str | None, website: str | None) -> str:
    raw = f"{(name or '').lower().strip()}|{normalize_phone(phone) or ''}|{extract_domain(website) or ''}"
    return hashlib.md5(raw.encode()).hexdigest()


def geo_overlap(a: list[str], b: list[str]) -> bool:
    """Exclusivity conflict if geo sets intersect OR either is empty (global)."""
    sa, sb = set(a or []), set(b or [])
    if not sa or not sb:
        return True
    return bool(sa & sb)


# ─── Fingerprint tests ──────────────────────────────────────────────────────

def test_same_business_same_fingerprint():
    a = fingerprint("Glow Med Spa", "(201) 555-0100", "https://www.glowmedspa.com/about")
    b = fingerprint("glow med spa", "2015550100", "http://glowmedspa.com")
    assert a == b


def test_different_phone_different_fingerprint():
    a = fingerprint("Glow Med Spa", "2015550100", "https://glowmedspa.com")
    b = fingerprint("Glow Med Spa", "2015550199", "https://glowmedspa.com")
    assert a != b


def test_www_stripped():
    a = fingerprint("X", None, "https://www.example.com")
    b = fingerprint("X", None, "https://example.com")
    assert a == b


def test_normalize_phone_us():
    assert normalize_phone("+1 (201) 555-0100") == "2015550100"
    assert normalize_phone("2015550100") == "2015550100"
    assert normalize_phone("12015550100") == "2015550100"
    assert normalize_phone("123") is None


# ─── Exclusivity geo tests ──────────────────────────────────────────────────

def test_exclusivity_overlapping_cities():
    assert geo_overlap(["Hoboken NJ", "Jersey City NJ"], ["Hoboken NJ"]) is True


def test_exclusivity_no_overlap():
    assert geo_overlap(["Hoboken NJ"], ["Austin TX"]) is False


def test_exclusivity_empty_means_global():
    assert geo_overlap([], ["Hoboken NJ"]) is True
    assert geo_overlap(["Hoboken NJ"], []) is True


def test_exclusivity_same_vertical_logic():
    # Simulated: conflict only if same vertical AND geo overlap
    def conflict(v1, g1, v2, g2, exclusive=True):
        if not exclusive:
            return False
        if v1.lower() != v2.lower():
            return False
        return geo_overlap(g1, g2)

    assert conflict("medspa", ["Hoboken NJ"], "medspa", ["Hoboken NJ"]) is True
    assert conflict("medspa", ["Hoboken NJ"], "dental", ["Hoboken NJ"]) is False
    assert conflict("medspa", ["Hoboken NJ"], "medspa", ["Dallas TX"]) is False


# ─── Quality gate rules ─────────────────────────────────────────────────────

def passes_gate(lead: dict, allow_tier_b: bool = False) -> bool:
    tier = lead.get("tier") or "C"
    if tier not in ({"A", "B"} if allow_tier_b else {"A"}):
        return False
    if (lead.get("business_status") or "").upper() == "CLOSED":
        return False
    if not (lead.get("phone_normalized") or lead.get("phone")):
        return False
    if not lead.get("website"):
        return False
    fields = 0
    if lead.get("email") and lead.get("email_valid") is not False:
        fields += 1
    if lead.get("has_booking"):
        fields += 1
    if lead.get("services"):
        fields += 1
    if lead.get("social_links"):
        fields += 1
    if lead.get("owner_name"):
        fields += 1
    return fields >= 2


def test_gate_rejects_closed():
    assert not passes_gate({
        "tier": "A", "business_status": "CLOSED",
        "phone": "2015550100", "website": "https://x.com",
        "email": "a@b.com", "email_valid": True, "has_booking": True,
    })


def test_gate_requires_tier_a_by_default():
    assert not passes_gate({
        "tier": "B", "phone": "2015550100", "website": "https://x.com",
        "email": "a@b.com", "email_valid": True, "has_booking": True,
    })
    assert passes_gate({
        "tier": "B", "phone": "2015550100", "website": "https://x.com",
        "email": "a@b.com", "email_valid": True, "has_booking": True,
    }, allow_tier_b=True)


def test_gate_requires_enrichment_depth():
    assert not passes_gate({
        "tier": "A", "phone": "2015550100", "website": "https://x.com",
        # only one enrichment field
        "email": "a@b.com", "email_valid": True,
    })
    assert passes_gate({
        "tier": "A", "phone": "2015550100", "website": "https://x.com",
        "email": "a@b.com", "email_valid": True, "has_booking": True,
    })
