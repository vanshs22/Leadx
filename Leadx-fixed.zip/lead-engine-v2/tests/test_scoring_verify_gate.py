"""Scoring v3, email verification helpers, quality gate, rate-limit window."""
from __future__ import annotations

import re
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


# ─── Inline scoring (mirrors prod/scoring.py logic without imports) ──────────

INDUSTRY_KEYWORDS = {
    "medspa": ["botox", "filler", "laser", "facial", "aesthetics"],
}


def score_lead_v3(lead, industry="medspa", weights=None, scored_at=None):
    weights = weights or {}
    parts = {}
    reasons = []
    status = (lead.get("business_status") or "OPERATIONAL").upper()
    if status == "CLOSED":
        return 0, "C", "CLOSED — rejected", {"closed": 0}

    if lead.get("website"):
        parts["website"] = 12
    if lead.get("phone_normalized") or lead.get("phone"):
        pts = 12
        if lead.get("phone_verified") is True:
            pts = 16
        elif lead.get("phone_verified") is False:
            pts = 4
        parts["phone"] = pts
    if lead.get("email") and lead.get("email_valid") is True:
        parts["email"] = 22
    elif lead.get("email") and lead.get("email_mx_ok") is False:
        parts["email"] = 4
    elif lead.get("email"):
        parts["email"] = 10
    if lead.get("has_booking"):
        parts["booking"] = 14
    else:
        parts["booking"] = 4
    rating = float(lead.get("google_rating") or 0)
    reviews = int(lead.get("review_count") or 0)
    if rating >= 4.5 and reviews >= 50:
        parts["reviews"] = 14
    elif rating >= 4.0 and reviews >= 15:
        parts["reviews"] = 9
    elif reviews > 0:
        parts["reviews"] = 4
    services = [str(s).lower() for s in (lead.get("services") or [])]
    blob = " ".join(services)
    kws = INDUSTRY_KEYWORDS.get(industry, [])
    if any(k in blob for k in kws):
        parts["services"] = 10
    if lead.get("owner_name"):
        parts["owner"] = 6
    if lead.get("social_links"):
        parts["social"] = 4

    w_email = weights.get("email", 1.0)
    w_booking = weights.get("booking", 1.0)
    adjusted = 0
    for k, v in parts.items():
        if k == "email":
            v = int(round(v * w_email))
        elif k == "booking":
            v = int(round(v * w_booking))
        adjusted += v

    # freshness
    mult = 1.0
    if scored_at:
        if scored_at.tzinfo is None:
            scored_at = scored_at.replace(tzinfo=timezone.utc)
        age_days = (datetime.now(timezone.utc) - scored_at).total_seconds() / 86400
        if age_days > 14:
            mult = max(0.25, 0.5 ** (age_days / 90))
    score = int(round(min(100, max(0, adjusted)) * mult))
    tier = "A" if score >= 72 else ("B" if score >= 48 else "C")
    return score, tier, "; ".join(reasons), parts


def is_valid_email_syntax(email: str) -> bool:
    if not email or "@" not in email:
        return False
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email)) and " " not in email


DISPOSABLE = {"mailinator.com", "tempmail.com", "guerrillamail.com", "throwaway.email"}


def is_disposable(email: str) -> bool:
    domain = email.split("@")[-1].lower()
    return domain in DISPOSABLE


def passes_gate(lead, allow_tier_b=False):
    tier = lead.get("tier") or "C"
    if tier not in ({"A", "B"} if allow_tier_b else {"A"}):
        return False
    if (lead.get("business_status") or "").upper() == "CLOSED":
        return False
    if not (lead.get("phone_normalized") or lead.get("phone")):
        return False
    if not lead.get("website"):
        return False
    fields = 0
    if lead.get("email") and lead.get("email_valid") is not False:
        fields += 1
    if lead.get("has_booking"):
        fields += 1
    if lead.get("services"):
        fields += 1
    if lead.get("social_links"):
        fields += 1
    if lead.get("owner_name"):
        fields += 1
    return fields >= 2


def geo_overlap(a, b):
    sa, sb = set(a or []), set(b or [])
    if not sa or not sb:
        return True
    return bool(sa & sb)


# ─── Tests ───────────────────────────────────────────────────────────────────

def test_closed_business_score_zero():
    s, tier, _, _ = score_lead_v3({"business_status": "CLOSED", "website": "x.com", "phone": "1"})
    assert s == 0 and tier == "C"


def test_strong_lead_is_tier_a():
    lead = {
        "website": "https://glow.com",
        "phone": "2015550100",
        "email": "hello@glow.com",
        "email_valid": True,
        "has_booking": True,
        "google_rating": 4.8,
        "review_count": 120,
        "services": ["Botox", "Laser"],
        "owner_name": "Dr. Smith",
        "social_links": {"ig": "x"},
        "business_status": "OPERATIONAL",
    }
    s, tier, _, parts = score_lead_v3(lead)
    assert tier == "A", (s, tier, parts)
    assert s >= 72
    assert parts.get("email") == 22


def test_email_without_mx_gets_reduced_points():
    lead = {
        "website": "https://x.com",
        "phone": "2015550100",
        "email": "a@b.com",
        "email_mx_ok": False,
        "email_valid": False,
    }
    _, _, _, parts = score_lead_v3(lead)
    assert parts.get("email") == 4


def test_verified_phone_bonus():
    lead = {"website": "https://x.com", "phone": "2015550100", "phone_verified": True}
    _, _, _, parts = score_lead_v3(lead)
    assert parts.get("phone") == 16


def test_failed_phone_verify_penalty():
    lead = {"website": "https://x.com", "phone": "2015550100", "phone_verified": False}
    _, _, _, parts = score_lead_v3(lead)
    assert parts.get("phone") == 4


def test_tenant_weight_boosts_email():
    lead = {
        "website": "https://x.com",
        "phone": "2015550100",
        "email": "a@b.com",
        "email_valid": True,
        "has_booking": True,
        "google_rating": 4.5,
        "review_count": 60,
        "services": ["botox"],
    }
    s1, _, _, _ = score_lead_v3(lead, weights={"email": 1.0})
    s2, _, _, _ = score_lead_v3(lead, weights={"email": 1.5})
    assert s2 > s1


def test_freshness_decay_old_score():
    lead = {
        "website": "https://x.com",
        "phone": "2015550100",
        "email": "a@b.com",
        "email_valid": True,
        "has_booking": True,
        "google_rating": 4.8,
        "review_count": 100,
        "services": ["botox"],
        "owner_name": "A",
    }
    old = datetime.now(timezone.utc) - timedelta(days=180)
    s_fresh, _, _, _ = score_lead_v3(lead)
    s_old, _, _, _ = score_lead_v3(lead, scored_at=old)
    assert s_old < s_fresh
    assert s_old >= int(s_fresh * 0.25)  # floor


def test_email_syntax():
    assert is_valid_email_syntax("hello@glow.com")
    assert not is_valid_email_syntax("not-an-email")
    assert not is_valid_email_syntax("a@b")
    assert not is_valid_email_syntax("")


def test_disposable_domains():
    assert is_disposable("x@mailinator.com")
    assert not is_disposable("x@gmail.com")


def test_gate_accepts_strong_a():
    assert passes_gate({
        "tier": "A",
        "phone": "2015550100",
        "website": "https://x.com",
        "email": "a@b.com",
        "email_valid": True,
        "has_booking": True,
    })


def test_gate_rejects_missing_phone():
    assert not passes_gate({
        "tier": "A",
        "website": "https://x.com",
        "email": "a@b.com",
        "email_valid": True,
        "has_booking": True,
    })


def test_gate_rejects_thin_enrichment():
    assert not passes_gate({
        "tier": "A",
        "phone": "2015550100",
        "website": "https://x.com",
        "email": "a@b.com",
        "email_valid": True,
        # only 1 enrichment field
    })


def test_geo_overlap_cases():
    assert geo_overlap(["Hoboken NJ"], ["Hoboken NJ", "JC"])
    assert not geo_overlap(["Austin TX"], ["Hoboken NJ"])
    assert geo_overlap([], ["Anywhere"])  # empty = global lock


def test_rate_limit_memory_window():
    from collections import defaultdict
    from threading import Lock
    import time

    class Window:
        def __init__(self):
            self._hits = defaultdict(list)
            self._lock = Lock()

        def hit(self, key, limit, window_seconds):
            now = time.time()
            cutoff = now - window_seconds
            with self._lock:
                bucket = [t for t in self._hits[key] if t > cutoff]
                if len(bucket) >= limit:
                    self._hits[key] = bucket
                    return False
                bucket.append(now)
                self._hits[key] = bucket
                return True

    w = Window()
    assert w.hit("t1", 3, 60)
    assert w.hit("t1", 3, 60)
    assert w.hit("t1", 3, 60)
    assert not w.hit("t1", 3, 60)  # 4th blocked
    assert w.hit("t2", 3, 60)  # other key OK


def test_fingerprint_collision_resistance():
    import hashlib

    def fp(name, phone, web):
        digits = re.sub(r"[^0-9]", "", phone or "")
        if len(digits) == 11 and digits.startswith("1"):
            digits = digits[1:]
        if len(digits) > 10:
            digits = digits[-10:]
        domain = ""
        if web:
            domain = re.sub(r"^https?://(www\.)?", "", web, flags=re.I).split("/")[0].lower()
        raw = f"{(name or '').lower().strip()}|{digits}|{domain}"
        return hashlib.md5(raw.encode()).hexdigest()

    a = fp("Glow Med Spa", "(201) 555-0100", "https://www.glow.com/x")
    b = fp("glow med spa", "2015550100", "http://glow.com")
    c = fp("Other Spa", "2015550100", "http://glow.com")
    assert a == b
    assert a != c
