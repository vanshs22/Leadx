"""Bulk suppression matching + pre-enrich filter logic (in-memory)."""
from __future__ import annotations


def filter_local(leads, opt_phones, opt_emails, sup_phones, sup_emails):
    kept, opt_hits, sup_hits = [], 0, 0
    for lead in leads:
        phone = lead.get("phone")
        email = (lead.get("email") or "").lower() or None
        if (phone and phone in opt_phones) or (email and email in opt_emails):
            opt_hits += 1
            continue
        if (phone and phone in sup_phones) or (email and email in sup_emails):
            sup_hits += 1
            continue
        kept.append(lead)
    return kept, opt_hits, sup_hits


def test_bulk_filters_opt_out_before_suppress():
    leads = [
        {"name": "A", "phone": "111", "email": "a@x.com"},
        {"name": "B", "phone": "222", "email": "b@x.com"},
        {"name": "C", "phone": "333", "email": "c@x.com"},
    ]
    kept, opt_hits, sup_hits = filter_local(
        leads,
        opt_phones={"111"},
        opt_emails=set(),
        sup_phones={"222"},
        sup_emails=set(),
    )
    assert len(kept) == 1 and kept[0]["name"] == "C"
    assert opt_hits == 1 and sup_hits == 1


def test_bulk_keeps_clean_leads():
    leads = [{"phone": "999", "email": "z@z.com"}]
    kept, o, s = filter_local(leads, set(), set(), set(), set())
    assert len(kept) == 1 and o == 0 and s == 0


def test_or_clause_shape():
    # Documents the PostgREST or_ shape we use
    ids = {"fingerprint": "abc", "phone_normalized": "2015550100", "email": None, "domain": "glow.com"}
    clauses = [f"{k}.eq.{v}" for k, v in ids.items() if v]
    assert "phone_normalized.eq.2015550100" in clauses
    assert "domain.eq.glow.com" in clauses
    assert len(clauses) == 3  # no None email


def test_pre_enrich_saves_crawl():
    """Semantic: blocked leads never enter enrich list."""
    discovered = [{"name": "X", "phone": "111", "website": "https://x.com"}]
    blocked_phones = {"111"}
    to_enrich = [l for l in discovered if l.get("phone") not in blocked_phones]
    assert to_enrich == []
