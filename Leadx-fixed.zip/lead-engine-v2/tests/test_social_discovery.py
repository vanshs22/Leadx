from backend.integrations.prod.social_discovery import (
    _normalize_linkedin_company,
    _normalize_linkedin_person,
    _normalize_instagram,
)

def test_linkedin_company_ok():
    item = {
        "link": "https://www.linkedin.com/company/glow-medspa",
        "title": "Glow MedSpa | LinkedIn",
        "snippet": "Medical spa in Hoboken offering botox",
    }
    lead = _normalize_linkedin_company(item, "medspa", "Hoboken, NJ")
    assert lead is not None
    assert lead["source"] == "linkedin_serper"
    assert "linkedin" in lead["linkedin_url"]

def test_linkedin_person_requires_dm_title():
    item = {
        "link": "https://www.linkedin.com/in/janedoe",
        "title": "Jane Doe - Software Engineer - Acme | LinkedIn",
        "snippet": "Engineer in Hoboken",
    }
    assert _normalize_linkedin_person(item, "medspa", "Hoboken") is None

def test_linkedin_person_owner():
    item = {
        "link": "https://www.linkedin.com/in/jane-owner",
        "title": "Jane Doe - Owner - Glow Med Spa | LinkedIn",
        "snippet": "Owner of med spa in Hoboken",
    }
    lead = _normalize_linkedin_person(item, "medspa", "Hoboken")
    assert lead is not None
    assert lead["owner_name"]
    assert lead["source"] == "linkedin_people_serper"

def test_instagram_quality_floor():
    weak = {
        "link": "https://instagram.com/randomfan",
        "title": "randomfan",
        "snippet": "photos",
    }
    assert _normalize_instagram(weak, "medspa", "Hoboken") is None

def test_instagram_business_signal():
    item = {
        "link": "https://www.instagram.com/glow.hoboken/",
        "title": "Glow Hoboken Med Spa",
        "snippet": "Book appointment medspa clinic Hoboken",
    }
    lead = _normalize_instagram(item, "medspa", "Hoboken")
    assert lead is not None
    assert lead["instagram_handle"] == "glow.hoboken"
