"""Social enrich helpers: IG handle extract, stale flag, tier gate, cap."""
from __future__ import annotations

import re
from datetime import datetime, timezone, timedelta

IG_HANDLE_RE = re.compile(r"(?:instagram\.com/|@)([A-Za-z0-9._]{2,30})", re.I)


def extract_ig(lead):
    social = lead.get("social_links") or {}
    if isinstance(social, dict) and social.get("instagram"):
        m = IG_HANDLE_RE.search(str(social["instagram"]))
        return m.group(1) if m else str(social["instagram"]).lstrip("@")
    return None


def is_stale(last_post_at, days=90):
    if not last_post_at:
        return True
    age = datetime.now(timezone.utc) - last_post_at
    return age > timedelta(days=days)


def gate_candidates(leads, max_per_run=25):
    return [l for l in leads if (l.get("tier") or "").upper() in ("A", "B")][:max_per_run]


def test_extract_ig_from_social_links():
    assert extract_ig({"social_links": {"instagram": "https://instagram.com/glowmedspa"}}) == "glowmedspa"


def test_extract_ig_at_handle():
    assert extract_ig({"social_links": {"instagram": "@glow.spa"}}) == "glow.spa"


def test_stale_no_posts():
    assert is_stale(None) is True


def test_stale_old_post():
    old = datetime.now(timezone.utc) - timedelta(days=120)
    assert is_stale(old) is True


def test_fresh_post():
    recent = datetime.now(timezone.utc) - timedelta(days=10)
    assert is_stale(recent) is False


def test_only_tier_ab():
    leads = [
        {"tier": "A", "name": "1"},
        {"tier": "C", "name": "2"},
        {"tier": "B", "name": "3"},
    ]
    c = gate_candidates(leads)
    assert len(c) == 2
    assert all(x["tier"] in ("A", "B") for x in c)


def test_hard_cap():
    leads = [{"tier": "A", "name": str(i)} for i in range(50)]
    assert len(gate_candidates(leads, max_per_run=25)) == 25


def test_decision_maker_backfill_owner():
    lead = {"owner_name": None}
    dm_name = "Jane Doe"
    if dm_name and not lead.get("owner_name"):
        lead["owner_name"] = dm_name
    assert lead["owner_name"] == "Jane Doe"
