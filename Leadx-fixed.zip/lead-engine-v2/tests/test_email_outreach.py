from backend.integrations.prod.email_outreach import render_merge


def test_render_merge_company():
    out = render_merge(
        "Hi {{owner}} at {{company}} in {{city}}",
        {"name": "Glow Spa", "owner_name": "Sam", "city": "Hoboken"},
    )
    assert "Glow Spa" in out
    assert "Sam" in out
    assert "Hoboken" in out


def test_render_merge_pitch():
    out = render_merge("Note: {{pitch}}", {"pitch_line": "No online booking"})
    assert "No online booking" in out
