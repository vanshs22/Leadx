from backend.integrations.prod.geo_grids import (
    expand_state_grid, is_state_level_icp, detect_state, recommend_cells_for_target,
)

def test_nj_state_detect():
    assert detect_state("New Jersey") == "new jersey"
    assert detect_state("NJ") == "new jersey"

def test_nj_grid_size():
    cells = expand_state_grid(["New Jersey"])
    assert len(cells) >= 50  # full NJ grid

def test_state_level_icp():
    assert is_state_level_icp(["New Jersey"])
    assert is_state_level_icp(["NJ"])
    assert not is_state_level_icp(["Hoboken NJ"])

def test_recommend_cells_10k():
    assert recommend_cells_for_target(10000, 90) >= 50
