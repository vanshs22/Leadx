
"""Competitive exclusivity: lock by offer_category, not target vertical alone."""
from backend.integrations.prod.quality import _norm_offer


def test_norm_offer():
    assert _norm_offer("Hair Dryers") == "hair_dryers"
    assert _norm_offer(None, "salon") == "salon"
    assert _norm_offer("  SEO Agency ") == "seo_agency"


def test_different_offers_same_vertical_do_not_conflict_logic():
    """Document the rule used by check_exclusivity_conflict."""
    a = _norm_offer("hair_dryers", "salon")
    b = _norm_offer("hair_cream", "salon")
    assert a != b  # different sellers → share same salon lead


def test_same_offer_conflicts_logic():
    a = _norm_offer("seo_agency", "salon")
    b = _norm_offer("SEO Agency", "salon")
    assert a == b  # same competitive set → exclusive lock


def test_missing_offer_falls_back_to_vertical():
    assert _norm_offer(None, "Med Spa") == "med_spa"
