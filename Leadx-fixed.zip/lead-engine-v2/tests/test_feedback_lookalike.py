"""Feedback multipliers + lookalike aggregation (pure logic)."""
from __future__ import annotations

from collections import Counter


def mult(win_rate, lose_rate):
    if win_rate + lose_rate < 0.05:
        return 1.0
    ratio = (win_rate + 0.05) / (lose_rate + 0.05)
    return max(0.5, min(1.5, ratio))


def rate(key_fn, bucket):
    if not bucket:
        return 0.0
    return sum(1 for r in bucket if key_fn(r)) / len(bucket)


def derive_weights(outcomes):
    won = [r for r in outcomes if r["outcome"] == "won"]
    lost = [r for r in outcomes if r["outcome"] == "lost"]
    return {
        "email": mult(
            rate(lambda f: f.get("has_email"), won),
            rate(lambda f: f.get("has_email"), lost),
        ),
        "booking": mult(
            rate(lambda f: f.get("has_booking"), won),
            rate(lambda f: f.get("has_booking"), lost),
        ),
    }


def lookalike_from_wins(wins, limit=5):
    services = Counter()
    categories = Counter()
    for f in wins:
        for s in f.get("services") or []:
            if isinstance(s, str) and len(s) > 2:
                services[s.lower()] += 1
        cat = f.get("category")
        if cat:
            categories[str(cat).lower()] += 1
    queries = [t for t, _ in services.most_common(limit)]
    for t, _ in categories.most_common(2):
        if t not in queries:
            queries.append(t)
    return queries[:limit]


def test_weight_boosts_when_email_predicts_wins():
    outcomes = [
        {"outcome": "won", "has_email": True},
        {"outcome": "won", "has_email": True},
        {"outcome": "won", "has_email": True},
        {"outcome": "won", "has_email": True},
        {"outcome": "lost", "has_email": False},
        {"outcome": "lost", "has_email": False},
        {"outcome": "lost", "has_email": True},
    ]
    # reshape to features dict style
    rows = [{"outcome": o["outcome"], **{k: v for k, v in o.items() if k != "outcome"}} for o in outcomes]
    # adapt derive to use feature dicts
    won = [r for r in rows if r["outcome"] == "won"]
    lost = [r for r in rows if r["outcome"] == "lost"]
    w = mult(
        rate(lambda f: f.get("has_email"), won),
        rate(lambda f: f.get("has_email"), lost),
    )
    assert w > 1.0  # email correlated with wins


def test_weight_dampens_when_email_predicts_loss():
    won = [{"has_email": False} for _ in range(5)]
    lost = [{"has_email": True} for _ in range(5)]
    w = mult(
        rate(lambda f: f.get("has_email"), won),
        rate(lambda f: f.get("has_email"), lost),
    )
    assert w < 1.0


def test_weight_clamped():
    assert mult(1.0, 0.0) <= 1.5
    assert mult(0.0, 1.0) >= 0.5


def test_lookalike_prefers_frequent_services():
    wins = [
        {"services": ["Botox", "Laser"], "category": "Med spa"},
        {"services": ["Botox", "Filler"], "category": "Med spa"},
        {"services": ["Botox"], "category": "Aesthetics"},
        {"services": ["Massage"], "category": "Wellness"},
    ]
    q = lookalike_from_wins(wins, limit=3)
    assert "botox" in q
    assert q[0] == "botox"


def test_lookalike_empty_wins():
    assert lookalike_from_wins([]) == []


def test_exclusivity_conflict_matrix():
    def conflict(v1, g1, exclusive1, v2, g2, exclusive2):
        # Only exclusive locks block others in same vertical + geo
        if not (exclusive1 or exclusive2):
            return False
        # If either holds exclusive on overlapping geo+vertical
        if v1.lower() != v2.lower():
            return False
        sa, sb = set(g1 or []), set(g2 or [])
        if not sa or not sb:
            return True
        return bool(sa & sb)

    assert conflict("medspa", ["NJ"], True, "medspa", ["NJ"], False) is True
    assert conflict("medspa", ["NJ"], True, "dental", ["NJ"], True) is False
    assert conflict("medspa", ["NJ"], True, "medspa", ["TX"], True) is False
    assert conflict("medspa", ["NJ"], False, "medspa", ["NJ"], False) is False


def test_apply_weights_to_score_parts():
    def apply(parts, weights):
        mapping = {"email": "email", "booking": "booking", "reviews": "reviews"}
        total = 0
        for k, pts in parts.items():
            w = weights.get(mapping.get(k, k), 1.0)
            total += int(round(pts * w))
        return min(100, max(0, total))

    base = {"email": 22, "booking": 14, "website": 12}
    assert apply(base, {}) == 48
    assert apply(base, {"email": 1.5}) == int(round(22 * 1.5)) + 14 + 12
