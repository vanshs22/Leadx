-- =============================================================================
-- LeadX FULL SCHEMA — single run (CRM tables + all columns before indexes/RLS)
-- =============================================================================
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;


-- ##### 002 production core #####

-- =============================================================================
-- Automiqo Lead Engine v2 — PRODUCTION Multi-Tenant Schema
-- Idempotent. Run in Supabase SQL Editor after 001 if present.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- 1. API Key Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_key_pool (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider       text NOT NULL CHECK (provider IN (
                   'serper','firecrawl','anthropic','gemini','groq','openai','resend'
                 )),
  key_value      text NOT NULL,
  label          text,
  status         text NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active','exhausted','disabled','cooling')),
  credits_used   int  NOT NULL DEFAULT 0,
  credits_limit  int,
  error_count    int  NOT NULL DEFAULT 0,
  last_error     text,
  last_used_at   timestamptz,
  cooldown_until timestamptz,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, key_value)
);

CREATE INDEX IF NOT EXISTS idx_api_key_pool_live
  ON api_key_pool (provider, status, last_used_at NULLS FIRST)
  WHERE status IN ('active','cooling');

-- ---------------------------------------------------------------------------
-- 2. Tenants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenants (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  text NOT NULL,
  slug                  text UNIQUE,
  plan                  text NOT NULL DEFAULT 'starter'
                          CHECK (plan IN ('starter','growth','premium','enterprise')),
  leads_per_month_limit int  NOT NULL DEFAULT 100,
  allow_tier_b          boolean NOT NULL DEFAULT false,
  delivery_channel      text NOT NULL DEFAULT 'telegram'
                          CHECK (delivery_channel IN ('telegram','webhook','email','portal','csv')),
  delivery_config       jsonb NOT NULL DEFAULT '{}',
  status                text NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','paused','churned')),
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants (status) WHERE status = 'active';

-- ---------------------------------------------------------------------------
-- 3. ICP Profiles
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS icp_profiles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL DEFAULT 'default',
  vertical      text NOT NULL,
  geo           jsonb NOT NULL DEFAULT '[]',
  keywords      jsonb NOT NULL DEFAULT '[]',
  weights       jsonb NOT NULL DEFAULT '{}',
  exclusivity   text NOT NULL DEFAULT 'exclusive'
                  CHECK (exclusivity IN ('exclusive','shared')),
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_icp_tenant_active ON icp_profiles (tenant_id) WHERE active = true;
CREATE INDEX IF NOT EXISTS idx_icp_vertical ON icp_profiles (vertical);

-- ---------------------------------------------------------------------------
-- 4. Global Leads Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads_global (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint       text NOT NULL UNIQUE,
  phone_normalized  text,
  phone_e164        text,
  name              text NOT NULL,
  name_normalized   text,
  address           text,
  city              text,
  state             text,
  website           text,
  website_domain    text,
  category          text,
  business_status   text NOT NULL DEFAULT 'OPERATIONAL'
                      CHECK (business_status IN ('OPERATIONAL','CLOSED','TEMPORARILY_CLOSED','UNKNOWN')),
  google_rating     numeric(2,1),
  review_count      int NOT NULL DEFAULT 0,
  google_place_id   text,
  source            text NOT NULL DEFAULT 'google_maps_serper',
  source_url        text,
  raw_data          jsonb NOT NULL DEFAULT '{}',
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_global_phone
  ON leads_global (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_domain
  ON leads_global (website_domain) WHERE website_domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_name_trgm
  ON leads_global USING gin (name_normalized gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_leads_global_status ON leads_global (business_status);

-- ---------------------------------------------------------------------------
-- 5. Enrichment
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrichment (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id           uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  email             text,
  email_valid       boolean,
  emails            text[] NOT NULL DEFAULT '{}',
  phone_from_web    text,
  has_booking       boolean NOT NULL DEFAULT false,
  booking_platform  text,
  services          text[] NOT NULL DEFAULT '{}',
  social_links      jsonb NOT NULL DEFAULT '{}',
  tech_stack        text[] NOT NULL DEFAULT '{}',
  owner_name        text,
  markdown_summary  text,
  raw_extraction    jsonb NOT NULL DEFAULT '{}',
  enrichment_method text,
  enrichment_ok     boolean NOT NULL DEFAULT false,
  error             text,
  extracted_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_enrichment_email ON enrichment (email) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_enrichment_ok ON enrichment (enrichment_ok) WHERE enrichment_ok = true;

-- ---------------------------------------------------------------------------
-- 6. Scores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scores (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id             uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  deterministic_score int  NOT NULL DEFAULT 0,
  llm_score           int,
  total_score         int  NOT NULL DEFAULT 0,
  tier                text NOT NULL DEFAULT 'C' CHECK (tier IN ('A','B','C')),
  reasoning           text,
  scored_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_scores_tier_score ON scores (tier, total_score DESC);

-- ---------------------------------------------------------------------------
-- 7. Lead Assignments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_assignments (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id          uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id           uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  vertical         text NOT NULL,
  geo_tags         text[] NOT NULL DEFAULT '{}',
  delivered_at     timestamptz,
  delivery_channel text,
  delivery_status  text NOT NULL DEFAULT 'pending'
                     CHECK (delivery_status IN ('pending','sent','failed','skipped')),
  delivery_error   text,
  status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','contacted','won','rejected','expired')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id, tenant_id)
);

CREATE INDEX IF NOT EXISTS idx_assignments_tenant_status ON lead_assignments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_exclusivity
  ON lead_assignments (vertical, lead_id) WHERE status NOT IN ('rejected','expired');
CREATE INDEX IF NOT EXISTS idx_assignments_delivered ON lead_assignments (tenant_id, delivered_at DESC);

-- ---------------------------------------------------------------------------
-- 8. Usage Log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  period          date NOT NULL,
  leads_delivered int  NOT NULL DEFAULT 0,
  tier_a_count    int  NOT NULL DEFAULT 0,
  tier_b_count    int  NOT NULL DEFAULT 0,
  tier_c_count    int  NOT NULL DEFAULT 0,
  leads_rejected  int  NOT NULL DEFAULT 0,
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, period)
);

-- ---------------------------------------------------------------------------
-- 9. Pipeline runs + dead-letter
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid REFERENCES tenants(id) ON DELETE SET NULL,
  icp_id          uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  status          text NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running','completed','failed','partial')),
  discovered      int NOT NULL DEFAULT 0,
  stored          int NOT NULL DEFAULT 0,
  enriched        int NOT NULL DEFAULT 0,
  gated_ok        int NOT NULL DEFAULT 0,
  assigned        int NOT NULL DEFAULT 0,
  delivered       int NOT NULL DEFAULT 0,
  error_message   text,
  meta            jsonb NOT NULL DEFAULT '{}',
  started_at      timestamptz NOT NULL DEFAULT now(),
  finished_at     timestamptz
);

CREATE TABLE IF NOT EXISTS enrichment_failures (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id      uuid REFERENCES leads_global(id) ON DELETE CASCADE,
  website      text,
  error        text,
  attempts     int NOT NULL DEFAULT 1,
  last_attempt timestamptz NOT NULL DEFAULT now(),
  resolved     boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_enrich_fail_unresolved
  ON enrichment_failures (resolved, last_attempt) WHERE resolved = false;

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION normalize_phone(p text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    CASE
      WHEN length(d) = 11 AND left(d,1) = '1' THEN substring(d from 2)
      WHEN length(d) = 10 THEN d
      ELSE d
    END,
    ''
  )
  FROM (SELECT regexp_replace(COALESCE(p, ''), '[^0-9]', '', 'g') AS d) s
  WHERE length(d) >= 10;
$$;

CREATE OR REPLACE FUNCTION extract_domain(url text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    lower(regexp_replace(
      regexp_replace(COALESCE(url,''), '^https?://(www\.)?', '', 'i'),
      '/.*$', ''
    )),
    ''
  );
$$;

CREATE OR REPLACE FUNCTION lead_fingerprint(p_name text, p_phone text, p_website text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT md5(
    lower(trim(COALESCE(p_name, ''))) || '|' ||
    COALESCE(normalize_phone(p_phone), '') || '|' ||
    COALESCE(extract_domain(p_website), '')
  );
$$;

CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[]
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected','expired')
      AND icp.exclusivity = 'exclusive'
      AND lower(icp.vertical) = lower(p_vertical)
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;
  RETURN conflict_exists;
END;
$$;

CREATE OR REPLACE FUNCTION bump_usage(p_tenant_id uuid, p_tier text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
BEGIN
  INSERT INTO usage_log (tenant_id, period, leads_delivered, tier_a_count, tier_b_count, tier_c_count)
  VALUES (
    p_tenant_id, p, 1,
    CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END
  )
  ON CONFLICT (tenant_id, period) DO UPDATE SET
    leads_delivered = usage_log.leads_delivered + 1,
    tier_a_count = usage_log.tier_a_count + CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    tier_b_count = usage_log.tier_b_count + CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    tier_c_count = usage_log.tier_c_count + CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END,
    updated_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE
  lim int;
  used int;
  p date := date_trunc('month', now())::date;
BEGIN
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id;
  IF lim IS NULL THEN RETURN 0; END IF;
  SELECT COALESCE(leads_delivered, 0) INTO used
  FROM usage_log WHERE tenant_id = p_tenant_id AND period = p;
  RETURN GREATEST(lim - COALESCE(used, 0), 0);
END;
$$;

CREATE OR REPLACE VIEW deliverable_leads AS
SELECT
  lg.id AS lead_id, lg.name, lg.phone_normalized, lg.phone_e164, lg.website,
  lg.address, lg.city, lg.state, lg.business_status, lg.google_rating, lg.review_count,
  e.email, e.email_valid, e.has_booking, e.booking_platform, e.services,
  e.social_links, e.owner_name, s.total_score, s.tier, s.reasoning
FROM leads_global lg
JOIN enrichment e ON e.lead_id = lg.id AND e.enrichment_ok = true
JOIN scores s ON s.lead_id = lg.id
WHERE lg.business_status IS DISTINCT FROM 'CLOSED'
  AND s.tier IN ('A', 'B')
  AND lg.phone_normalized IS NOT NULL
  AND lg.website IS NOT NULL
  AND (
    (e.email IS NOT NULL AND e.email_valid IS NOT FALSE)::int +
    (e.has_booking)::int +
    (COALESCE(array_length(e.services, 1), 0) > 0)::int +
    (e.social_links IS NOT NULL AND e.social_links != '{}'::jsonb)::int +
    (e.owner_name IS NOT NULL)::int
  ) >= 2;


-- ##### CRM tables (required by 004 RLS) #####


-- =============================================================================
-- CRM portal tables required by RLS (were referenced but not created)
-- =============================================================================

CREATE TABLE IF NOT EXISTS tenant_members (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  auth_user_id  uuid,  -- supabase auth.users id
  email         text,
  role          text NOT NULL DEFAULT 'member'
                  CHECK (role IN ('owner','admin','member','viewer')),
  status        text NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','invited','disabled')),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, auth_user_id)
);
CREATE INDEX IF NOT EXISTS idx_tenant_members_user ON tenant_members (auth_user_id) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_tenant_members_tenant ON tenant_members (tenant_id, status);

CREATE TABLE IF NOT EXISTS pipeline_stages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  slug          text NOT NULL,
  position      int NOT NULL DEFAULT 0,
  color         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE TABLE IF NOT EXISTS lead_activities (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  activity_type text NOT NULL DEFAULT 'note',
  title         text,
  body          text,
  meta          jsonb DEFAULT '{}',
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_activities_assignment ON lead_activities (assignment_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activities_tenant ON lead_activities (tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS lead_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  title         text NOT NULL,
  status        text NOT NULL DEFAULT 'open',
  priority      text DEFAULT 'medium',
  due_at        timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  completed_at  timestamptz
);
CREATE INDEX IF NOT EXISTS idx_tasks_tenant ON lead_tasks (tenant_id, status);

CREATE TABLE IF NOT EXISTS lead_tags (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  tag           text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tags_assignment ON lead_tags (assignment_id);

CREATE TABLE IF NOT EXISTS lead_segments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  filters       jsonb NOT NULL DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crm_audit_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE SET NULL,
  actor_id      uuid,
  action        text NOT NULL,
  entity        text,
  entity_id     text,
  meta          jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_crm_audit_tenant ON crm_audit_log (tenant_id, created_at DESC);


-- ##### Column repair (partial DB safety) #####
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS slug text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS plan text DEFAULT 'starter';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS leads_per_month_limit int DEFAULT 100;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS allow_tier_b boolean DEFAULT false;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS delivery_channel text DEFAULT 'telegram';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS delivery_config jsonb DEFAULT '{}';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS brand_name text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS brand_logo_url text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS brand_accent_color text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS brand_favicon_url text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS custom_domain text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS support_email text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS stripe_customer_id text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS stripe_subscription_id text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_normalized text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS name_normalized text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS fingerprint text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_e164 text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS website_domain text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS business_status text DEFAULT 'OPERATIONAL';
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS talking_points text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS pitch_line text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS state text;

ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS stage_slug text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS status text DEFAULT 'new';
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS vertical text;

ALTER TABLE icp_profiles ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE icp_profiles ADD COLUMN IF NOT EXISTS active boolean DEFAULT true;

ALTER TABLE enrichment ADD COLUMN IF NOT EXISTS enrichment_ok boolean DEFAULT false;
ALTER TABLE enrichment ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE enrichment ADD COLUMN IF NOT EXISTS pitch_line text;
ALTER TABLE enrichment ADD COLUMN IF NOT EXISTS intent_score int;
ALTER TABLE enrichment ADD COLUMN IF NOT EXISTS owner_name text;

UPDATE tenants SET name = COALESCE(NULLIF(trim(name), ''), 'Tenant') WHERE name IS NULL;
UPDATE tenants SET status = COALESCE(status, 'active');


-- ##### 004 RLS (tables exist now) #####

-- =============================================================================
-- Row-Level Security + auth helpers for multi-tenant isolation
-- Run AFTER 002 (lead engine) and 003 (CRM portal) schemas.
-- =============================================================================

-- Map auth.uid() → tenant_id via tenant_members
CREATE OR REPLACE FUNCTION public.current_tenant_ids()
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT tenant_id
  FROM tenant_members
  WHERE auth_user_id = auth.uid()
    AND status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_member(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_admin(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
      AND role IN ('owner', 'admin')
  );
$$;

-- Service role bypasses RLS; anon/authenticated are restricted.
-- Enable RLS on all tenant-scoped tables.

DO $$ BEGIN
  IF to_regclass('public.tenants') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenants ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.icp_profiles') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE icp_profiles ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_assignments') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_assignments ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.enrichment') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE enrichment ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.scores') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE scores ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.usage_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE usage_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE pipeline_runs ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.pipeline_stages') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_activities') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_activities ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_tasks') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_tasks ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_tags') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_tags ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.tenant_members') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenant_members ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_segments') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_segments ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.crm_audit_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE crm_audit_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.enrichment_failures') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE enrichment_failures ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- leads_global is SHARED pool — members can SELECT only leads assigned to them
DO $$ BEGIN
  IF to_regclass('public.leads_global') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE leads_global ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- Drop existing policies if re-running
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT policyname, tablename FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN (
        'tenants','icp_profiles','lead_assignments','leads_global',
        'enrichment','scores','usage_log','pipeline_runs','pipeline_stages',
        'lead_activities','lead_tasks','lead_tags','tenant_members',
        'lead_segments','crm_audit_log','enrichment_failures'
      )
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- TENANTS: members see only their tenants
CREATE POLICY tenants_select ON tenants FOR SELECT
  USING (id IN (SELECT public.current_tenant_ids()));
CREATE POLICY tenants_update ON tenants FOR UPDATE
  USING (public.is_tenant_admin(id));

-- ICP
CREATE POLICY icp_select ON icp_profiles FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY icp_write ON icp_profiles FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- ASSIGNMENTS (core isolation)
CREATE POLICY assignments_select ON lead_assignments FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_insert ON lead_assignments FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_update ON lead_assignments FOR UPDATE
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_delete ON lead_assignments FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- leads_global: only if assigned to one of user's tenants
CREATE POLICY leads_global_select ON leads_global FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = leads_global.id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
-- Writes only via service role (backend pipeline)

-- enrichment / scores: via assigned leads
CREATE POLICY enrichment_select ON enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
CREATE POLICY scores_select ON scores FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = scores.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- usage_log
CREATE POLICY usage_select ON usage_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- pipeline_runs
CREATE POLICY runs_select ON pipeline_runs FOR SELECT
  USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id));

-- CRM tables
CREATE POLICY stages_all ON pipeline_stages FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY activities_all ON lead_activities FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tasks_all ON lead_tasks FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tags_all ON lead_tags FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY segments_all ON lead_segments FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY audit_select ON crm_audit_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_select ON tenant_members FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_admin ON tenant_members FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- api_key_pool: NEVER exposed to clients (service role only)
DO $$ BEGIN
  IF to_regclass('public.api_key_pool') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE api_key_pool ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
-- no policies for authenticated → only service_role can access

COMMENT ON FUNCTION public.current_tenant_ids IS 'Tenants the JWT user belongs to';
COMMENT ON FUNCTION public.is_tenant_member IS 'True if auth.uid() is active member of tenant';


-- ##### 005_outcomes_feedback.sql #####

-- Win/loss feedback storage for adaptive scoring + lookalikes

CREATE TABLE IF NOT EXISTS lead_outcomes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  outcome       text NOT NULL CHECK (outcome IN ('won', 'lost')),
  reason        text,
  features      jsonb NOT NULL DEFAULT '{}',
  recorded_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (assignment_id)
);

CREATE INDEX IF NOT EXISTS idx_outcomes_tenant ON lead_outcomes (tenant_id, outcome);
CREATE INDEX IF NOT EXISTS idx_outcomes_features ON lead_outcomes USING gin (features);

ALTER TABLE lead_outcomes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS outcomes_select ON lead_outcomes;
CREATE POLICY outcomes_select ON lead_outcomes FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS outcomes_insert ON lead_outcomes;
CREATE POLICY outcomes_insert ON lead_outcomes FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));

-- Optional: store last verification timestamps on enrichment
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_mx_ok boolean,
  ADD COLUMN IF NOT EXISTS phone_verified boolean,
  ADD COLUMN IF NOT EXISTS phone_line_type text,
  ADD COLUMN IF NOT EXISTS verified_at timestamptz;

-- Freshness: track when score was last computed
ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS stale boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS refresh_after timestamptz;


-- ##### 006_next_tier.sql #####

-- =============================================================================
-- Next-tier: suppression, global opt-out, signals, sentiment, auto-credits
-- =============================================================================

-- Client suppression lists (tenant CRM exports — never resell these)
CREATE TABLE IF NOT EXISTS suppression_list (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  fingerprint text,                          -- same fingerprint as leads_global
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  source      text DEFAULT 'upload',         -- upload | manual | crm_sync
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_supp_tenant_fp ON suppression_list (tenant_id, fingerprint);
CREATE INDEX IF NOT EXISTS idx_supp_tenant_phone ON suppression_list (tenant_id, phone_normalized)
  WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_email ON suppression_list (tenant_id, email)
  WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_domain ON suppression_list (tenant_id, domain)
  WHERE domain IS NOT NULL;

-- Global opt-out registry (one removal = never for ANY tenant)
CREATE TABLE IF NOT EXISTS global_opt_out (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint text,
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  reason      text,
  requested_by text,                         -- email or 'admin'
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_phone
  ON global_opt_out (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_email
  ON global_opt_out (email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_domain
  ON global_opt_out (domain) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_optout_fp ON global_opt_out (fingerprint)
  WHERE fingerprint IS NOT NULL;

-- Why-now / trigger signals per lead
CREATE TABLE IF NOT EXISTS lead_signals (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id     uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  signal_type text NOT NULL CHECK (signal_type IN (
    'review_velocity_up', 'review_velocity_down',
    'site_redesign', 'new_hire', 'tech_change',
    'complaint_cluster', 'other'
  )),
  strength    numeric(4,2) DEFAULT 1.0,      -- 0–1 relative strength
  detail      jsonb DEFAULT '{}',
  detected_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_signals_lead ON lead_signals (lead_id, signal_type);

-- Review sentiment summary (one row per lead, refreshed)
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS review_sentiment jsonb,   -- {pos, neg, themes: [...], pitch_hooks: [...]}
  ADD COLUMN IF NOT EXISTS tech_stack jsonb,         -- {booking, crm, chat, analytics, ...}
  ADD COLUMN IF NOT EXISTS why_now text[],           -- short human labels
  ADD COLUMN IF NOT EXISTS last_signal_at timestamptz;

-- Auto-credit / refund log
CREATE TABLE IF NOT EXISTS lead_credits (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  lead_id       uuid,
  credit_type   text NOT NULL CHECK (credit_type IN (
    'dead_phone', 'dead_email', 'bounce', 'closed_business', 'duplicate', 'manual'
  )),
  amount        int NOT NULL DEFAULT 1,              -- leads credited back
  period        date NOT NULL,                       -- usage_log period
  detail        jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credits_tenant ON lead_credits (tenant_id, period);

-- Cross-tenant vertical priors (aggregated win rates per feature)
CREATE TABLE IF NOT EXISTS vertical_priors (
  vertical    text NOT NULL,
  feature     text NOT NULL,                         -- email, booking, reviews, owner, rating_high
  win_rate    numeric(6,4) NOT NULL DEFAULT 0.5,
  lose_rate   numeric(6,4) NOT NULL DEFAULT 0.5,
  sample_size int NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (vertical, feature)
);

-- Encrypted delivery config column (app encrypts JSON → store here)
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS delivery_config_enc text;  -- base64 AES ciphertext

-- RLS for new tables
ALTER TABLE suppression_list ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_credits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS supp_tenant ON suppression_list;
CREATE POLICY supp_tenant ON suppression_list FOR ALL
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS signals_via_assignment ON lead_signals;
CREATE POLICY signals_via_assignment ON lead_signals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = lead_signals.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS credits_tenant ON lead_credits;
CREATE POLICY credits_tenant ON lead_credits FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- global_opt_out + vertical_priors: service role only (no client policies)

-- Helper: is suppressed for tenant?
CREATE OR REPLACE FUNCTION is_suppressed(
  p_tenant_id uuid,
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM suppression_list s
    WHERE s.tenant_id = p_tenant_id
      AND (
        (p_fingerprint IS NOT NULL AND s.fingerprint = p_fingerprint)
        OR (p_phone IS NOT NULL AND s.phone_normalized = p_phone)
        OR (p_email IS NOT NULL AND lower(s.email) = lower(p_email))
        OR (p_domain IS NOT NULL AND s.domain = p_domain)
      )
  );
$$;

-- Helper: globally opted out?
CREATE OR REPLACE FUNCTION is_opted_out(
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM global_opt_out g
    WHERE
      (p_fingerprint IS NOT NULL AND g.fingerprint = p_fingerprint)
      OR (p_phone IS NOT NULL AND g.phone_normalized = p_phone)
      OR (p_email IS NOT NULL AND lower(g.email) = lower(p_email))
      OR (p_domain IS NOT NULL AND g.domain = p_domain)
  );
$$;

-- Auto-credit: decrement usage_log.leads_delivered for period
CREATE OR REPLACE FUNCTION credit_tenant_usage(
  p_tenant_id uuid,
  p_period date,
  p_amount int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE usage_log
  SET leads_delivered = GREATEST(0, leads_delivered - p_amount)
  WHERE tenant_id = p_tenant_id AND period = p_period;
END;
$$;


-- ##### 007_team_branding_ops.sql #####

-- Team invites, white-label branding, ops metrics

-- Invite tokens for tenant_members
CREATE TABLE IF NOT EXISTS tenant_invites (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  token       text NOT NULL UNIQUE,
  invited_by  uuid,
  expires_at  timestamptz NOT NULL,
  accepted_at timestamptz,
  status      text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','accepted','expired','revoked')),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invites_token ON tenant_invites (token) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_invites_tenant ON tenant_invites (tenant_id, status);

ALTER TABLE tenant_invites ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS invites_admin ON tenant_invites;
CREATE POLICY invites_admin ON tenant_invites FOR ALL
  USING (public.is_tenant_admin(tenant_id));
DROP POLICY IF EXISTS invites_select_member ON tenant_invites;
CREATE POLICY invites_select_member ON tenant_invites FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- White-label branding on tenants
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS brand_name text,
  ADD COLUMN IF NOT EXISTS brand_logo_url text,
  ADD COLUMN IF NOT EXISTS brand_primary_color text DEFAULT '#6366f1',
  ADD COLUMN IF NOT EXISTS brand_accent_color text DEFAULT '#22c55e',
  ADD COLUMN IF NOT EXISTS brand_favicon_url text,
  ADD COLUMN IF NOT EXISTS custom_domain text,
  ADD COLUMN IF NOT EXISTS support_email text;

-- LinkedIn enrichment fields
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS linkedin_url text,
  ADD COLUMN IF NOT EXISTS linkedin_company_id text,
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS linkedin_fetched_at timestamptz;

-- Ops metrics daily rollup (pipeline health over time)
CREATE TABLE IF NOT EXISTS ops_metrics_daily (
  day               date NOT NULL,
  tenant_id         uuid,                          -- null = global/system
  pipeline_runs     int NOT NULL DEFAULT 0,
  leads_discovered  int NOT NULL DEFAULT 0,
  leads_enriched_ok int NOT NULL DEFAULT 0,
  leads_enriched_fail int NOT NULL DEFAULT 0,
  leads_gated       int NOT NULL DEFAULT 0,
  leads_assigned    int NOT NULL DEFAULT 0,
  suppression_hits  int NOT NULL DEFAULT 0,
  opt_out_hits      int NOT NULL DEFAULT 0,
  credits_issued    int NOT NULL DEFAULT 0,
  serper_calls      int NOT NULL DEFAULT 0,
  firecrawl_calls   int NOT NULL DEFAULT 0,
  avg_enrich_ms     int,
  error_samples     jsonb DEFAULT '[]',
  PRIMARY KEY (day, tenant_id)
);

-- Allow null tenant for global: use sentinel
-- Postgres UNIQUE treats NULLs as distinct — use coalesce in app or:
CREATE UNIQUE INDEX IF NOT EXISTS idx_ops_metrics_global
  ON ops_metrics_daily (day) WHERE tenant_id IS NULL;

CREATE OR REPLACE FUNCTION bump_ops_metric(
  p_day date,
  p_tenant_id uuid,
  p_field text,
  p_delta int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO ops_metrics_daily (day, tenant_id)
  VALUES (p_day, p_tenant_id)
  ON CONFLICT (day, tenant_id) DO NOTHING;

  EXECUTE format(
    'UPDATE ops_metrics_daily SET %I = COALESCE(%I, 0) + $1 WHERE day = $2 AND tenant_id IS NOT DISTINCT FROM $3',
    p_field, p_field
  ) USING p_delta, p_day, p_tenant_id;
EXCEPTION WHEN OTHERS THEN
  -- soft fail — never break pipeline for metrics
  NULL;
END;
$$;


-- ##### 008_stripe_billing.sql #####

-- Stripe billing fields + usage_log report tracking

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS stripe_customer_id text,
  ADD COLUMN IF NOT EXISTS stripe_subscription_item_id text,
  ADD COLUMN IF NOT EXISTS stripe_price_id text;

CREATE INDEX IF NOT EXISTS idx_tenants_stripe
  ON tenants (stripe_customer_id) WHERE stripe_customer_id IS NOT NULL;

ALTER TABLE usage_log
  ADD COLUMN IF NOT EXISTS stripe_reported_at timestamptz,
  ADD COLUMN IF NOT EXISTS stripe_reported_qty int;


-- ##### 009_social_enrich.sql #####

-- Social enrichment (LinkedIn via microservice + Instagram via instaloader)
-- Runs only on quality-gated leads before assign.

CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,              -- serper | drissbri | site_html
  source_instagram        text,              -- instaloader
  enriched_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS social_enrichment_failures (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id    uuid,
  source     text NOT NULL,                  -- linkedin | instagram
  error      text,
  failed_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_social_fail_at ON social_enrichment_failures (failed_at DESC);

ALTER TABLE social_enrichment ENABLE ROW LEVEL SECURITY;
ALTER TABLE social_enrichment_failures ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS social_enrich_select ON social_enrichment;
CREATE POLICY social_enrich_select ON social_enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS social_fail_select ON social_enrichment_failures;
CREATE POLICY social_fail_select ON social_enrichment_failures FOR SELECT
  USING (
    lead_id IS NULL OR EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment_failures.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- Mirror key fields onto enrichment for CRM views
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS instagram_handle text,
  ADD COLUMN IF NOT EXISTS instagram_followers int,
  ADD COLUMN IF NOT EXISTS instagram_last_post_at timestamptz,
  ADD COLUMN IF NOT EXISTS instagram_stale boolean;


-- ##### 010_beat_zoominfo_layer.sql #####

-- Layer that closes gaps vs ZoomInfo/Apollo for LOCAL B2B:
-- contacts (people), intent score, pitch lines, QA feedback, sample packs, sequences.

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]';

ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS pitch_line text;

-- Named decision-makers / people (Apollo-style contacts, local-first)
CREATE TABLE IF NOT EXISTS lead_contacts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  full_name       text,
  title           text,
  email           text,
  phone           text,
  linkedin_url    text,
  is_decision_maker boolean DEFAULT false,
  source          text, -- linkedin | website | serper | manual
  confidence      int DEFAULT 50,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_contacts_lead ON lead_contacts (lead_id);

-- Operator QA (accuracy proof vs ZoomInfo brand trust)
CREATE TABLE IF NOT EXISTS lead_qa (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id   uuid,
  tenant_id       uuid,
  phone_ok        boolean,
  email_ok        boolean,
  business_open   boolean,
  notes           text,
  reviewed_by     text DEFAULT 'ops',
  reviewed_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_qa_tenant ON lead_qa (tenant_id, reviewed_at DESC);

-- Sample packs for sales (beat Apollo free credits narrative)
CREATE TABLE IF NOT EXISTS sample_packs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  vertical        text,
  geo             text,
  lead_ids        uuid[] DEFAULT '{}',
  meta            jsonb DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- Territory exclusivity board (ZoomInfo has territories; we make them real)
CREATE TABLE IF NOT EXISTS territories (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  vertical        text NOT NULL,
  geo_key         text NOT NULL, -- normalized city/region key
  exclusive_until date,
  status          text NOT NULL DEFAULT 'active', -- active | expired | released
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (vertical, geo_key)  -- one exclusive owner per vertical+geo
);

-- Client "report bad lead" requests
CREATE TABLE IF NOT EXISTS bad_lead_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL,
  assignment_id   uuid NOT NULL,
  lead_id         uuid,
  reason          text NOT NULL, -- wrong_number | email_bounce | closed | duplicate | other
  detail          text,
  status          text NOT NULL DEFAULT 'open', -- open | credited | rejected
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);

ALTER TABLE lead_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_qa ENABLE ROW LEVEL SECURITY;
ALTER TABLE bad_lead_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE territories ENABLE ROW LEVEL SECURITY;


-- ##### 011_continuous_discovery.sql #####

-- Continuous supply: track what each ICP has already covered so runs explore NEW space.

CREATE TABLE IF NOT EXISTS discovery_coverage (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  icp_id          uuid,
  vertical        text NOT NULL,
  source          text NOT NULL,          -- maps | linkedin | instagram | web | yelp | facebook
  location_key    text NOT NULL,          -- normalized geo cell
  query_key       text NOT NULL DEFAULT '',
  page_reached    int NOT NULL DEFAULT 0,
  leads_found     int NOT NULL DEFAULT 0,
  last_run_at     timestamptz NOT NULL DEFAULT now(),
  exhausted       boolean NOT NULL DEFAULT false,  -- true when source returns 0 new
  meta            jsonb DEFAULT '{}',
  UNIQUE (icp_id, source, location_key, query_key)
);

CREATE INDEX IF NOT EXISTS idx_coverage_icp ON discovery_coverage (icp_id, exhausted, last_run_at);
CREATE INDEX IF NOT EXISTS idx_coverage_vertical ON discovery_coverage (vertical, location_key);

-- Fingerprints already delivered to a tenant (fast skip at discovery)
CREATE TABLE IF NOT EXISTS tenant_seen_leads (
  tenant_id       uuid NOT NULL,
  fingerprint     text NOT NULL,
  lead_id         uuid,
  first_seen_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_tenant_seen_fp ON tenant_seen_leads (fingerprint);

-- ICP geo expansion cells (zip / neighborhood / adjacent city)
CREATE TABLE IF NOT EXISTS icp_geo_cells (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  icp_id          uuid NOT NULL,
  cell_key        text NOT NULL,           -- "hoboken-nj" | "07030" | "jersey-city-nj"
  cell_label      text NOT NULL,          -- human label for Serper queries
  priority        int NOT NULL DEFAULT 100,
  times_scanned   int NOT NULL DEFAULT 0,
  last_scanned_at timestamptz,
  active          boolean NOT NULL DEFAULT true,
  UNIQUE (icp_id, cell_key)
);

CREATE INDEX IF NOT EXISTS idx_geo_cells_scan ON icp_geo_cells (icp_id, active, times_scanned, last_scanned_at);


-- ##### 012_offer_category_exclusivity.sql #####

-- Competitive exclusivity: lock only against same offer_category (seller type),
-- not against every ICP that targets the same vertical/geo.
--
-- Example: hair-dryer seller + hair-cream seller both target NJ salons → BOTH OK.
--          two SEO agencies targeting NJ salons → CONFLICT if exclusive.

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_category text;

-- Human label for UI
ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_label text;

COMMENT ON COLUMN icp_profiles.offer_category IS
  'Competitive lock key. Same category + overlapping geo + exclusive = conflict. Different categories share the lead.';

COMMENT ON COLUMN icp_profiles.vertical IS
  'Target industry of the LEAD (salon, medspa). NOT the exclusivity lock.';

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS offer_category text;

CREATE INDEX IF NOT EXISTS idx_icp_offer_category
  ON icp_profiles (lower(offer_category)) WHERE active = true;

CREATE INDEX IF NOT EXISTS idx_assignments_offer_cat
  ON lead_assignments (lead_id, lower(offer_category))
  WHERE status NOT IN ('rejected', 'expired');

-- Backfill: if offer_category null, use vertical as conservative default
-- (operator should set real categories for multi-ICP same-vertical sharing)
UPDATE icp_profiles
SET offer_category = lower(regexp_replace(vertical, '\s+', '_', 'g'))
WHERE offer_category IS NULL OR offer_category = '';

UPDATE lead_assignments la
SET offer_category = icp.offer_category
FROM icp_profiles icp
WHERE la.icp_id = icp.id
  AND (la.offer_category IS NULL OR la.offer_category = '');

-- New exclusivity function: compete on offer_category, not vertical alone
CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[],
  p_offer_category text DEFAULT NULL
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
  v_offer text;
BEGIN
  -- Prefer explicit offer category; fall back to vertical (legacy)
  v_offer := lower(nullif(trim(p_offer_category), ''));
  IF v_offer IS NULL THEN
    v_offer := lower(nullif(trim(p_vertical), ''));
  END IF;

  IF v_offer IS NULL THEN
    RETURN false; -- cannot lock without a category
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    LEFT JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected', 'expired')
      AND COALESCE(icp.exclusivity, 'exclusive') = 'exclusive'
      -- SAME competitive set only
      AND lower(COALESCE(nullif(la.offer_category, ''), nullif(icp.offer_category, ''), icp.vertical, la.vertical, ''))
          = v_offer
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR p_geo IS NULL
        OR cardinality(p_geo) = 0
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;

  RETURN conflict_exists;
END;
$$;


-- ##### 013_differentiators.sql #####

-- Differentiators: talking points, outreach, docs, recycle, freshness, territories

ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS first_touch_meta jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS recycled_from_assignment_id uuid,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz;

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS auto_first_touch boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS first_touch_channel text DEFAULT 'sms',
  ADD COLUMN IF NOT EXISTS first_touch_script text,
  ADD COLUMN IF NOT EXISTS vapi_assistant_id text,
  ADD COLUMN IF NOT EXISTS twilio_from_number text,
  ADD COLUMN IF NOT EXISTS whatsapp_from text,
  ADD COLUMN IF NOT EXISTS onboarding_defaults jsonb DEFAULT '{}';

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS client_weight_overrides jsonb DEFAULT '{}';

-- Document templates library
CREATE TABLE IF NOT EXISTS doc_templates (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE CASCADE, -- null = global
  category      text NOT NULL,  -- contract, nda, invoice, proposal, onboarding
  name          text NOT NULL,
  description   text,
  body_html     text NOT NULL,
  body_text     text,
  variables     jsonb NOT NULL DEFAULT '[]', -- ["client_name","amount",...]
  channel_hint  text DEFAULT 'email', -- email, whatsapp, both
  active        boolean DEFAULT true,
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doc_templates_cat ON doc_templates (category) WHERE active;

-- Generated docs / sends log
CREATE TABLE IF NOT EXISTS doc_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  template_id   uuid REFERENCES doc_templates(id) ON DELETE SET NULL,
  category      text,
  to_email      text,
  to_phone      text,
  channel       text NOT NULL, -- email, whatsapp
  subject       text,
  body_html     text,
  body_text     text,
  variables     jsonb DEFAULT '{}',
  status        text DEFAULT 'queued',
  provider_id   text,
  error         text,
  created_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doc_sends_tenant ON doc_sends (tenant_id, created_at DESC);

-- Outreach log
CREATE TABLE IF NOT EXISTS first_touch_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  channel       text NOT NULL,
  status        text NOT NULL,
  provider      text,
  provider_id   text,
  payload       jsonb DEFAULT '{}',
  error         text,
  created_at    timestamptz DEFAULT now()
);

-- Freshness schedule config (global defaults)
CREATE TABLE IF NOT EXISTS freshness_policy (
  tier          text PRIMARY KEY,
  reverify_days int NOT NULL
);

INSERT INTO freshness_policy (tier, reverify_days) VALUES
  ('A', 7), ('B', 21), ('C', 60)
ON CONFLICT (tier) DO NOTHING;

-- Seed a starter global template pack (short, editable)
INSERT INTO doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint)
SELECT NULL, x.category, x.name, x.description, x.body_html, x.body_text, x.variables::jsonb, x.channel_hint
FROM (VALUES
  ('contract', 'Service Agreement (simple)', '1-page services agreement',
   '<h2>Service Agreement</h2><p>This agreement is between <b>{{provider_name}}</b> and <b>{{client_name}}</b>.</p><p>Scope: {{scope}}</p><p>Fee: {{amount}} {{currency}}</p><p>Term: {{term}}</p><p>Signed: ________________</p>',
   'Service Agreement between {{provider_name}} and {{client_name}}. Scope: {{scope}}. Fee: {{amount}} {{currency}}. Term: {{term}}.',
   '["provider_name","client_name","scope","amount","currency","term"]', 'email'),
  ('nda', 'Mutual NDA', 'Short mutual confidentiality',
   '<h2>Mutual NDA</h2><p>{{party_a}} and {{party_b}} agree to keep confidential information private for {{term}}.</p>',
   'Mutual NDA between {{party_a}} and {{party_b}} for {{term}}.',
   '["party_a","party_b","term"]', 'email'),
  ('invoice', 'Standard Invoice', 'Simple invoice',
   '<h2>Invoice {{invoice_number}}</h2><p>Bill to: {{client_name}}</p><p>Amount due: <b>{{amount}} {{currency}}</b></p><p>Due: {{due_date}}</p><p>{{line_items}}</p>',
   'Invoice {{invoice_number}} to {{client_name}} for {{amount}} {{currency}}, due {{due_date}}.',
   '["invoice_number","client_name","amount","currency","due_date","line_items"]', 'both'),
  ('proposal', 'Lead Package Proposal', 'Proposal for exclusive leads',
   '<h2>Proposal</h2><p>Hi {{client_name}},</p><p>We will deliver {{lead_count}} Tier A {{vertical}} leads in {{geo}}.</p><p>Investment: {{amount}}/mo. Exclusivity: {{offer_category}} in {{geo}}.</p>',
   'Proposal for {{client_name}}: {{lead_count}} Tier A {{vertical}} leads in {{geo}} at {{amount}}/mo.',
   '["client_name","lead_count","vertical","geo","amount","offer_category"]', 'email'),
  ('onboarding', 'Client Onboarding Checklist', 'Kickoff email',
   '<h2>Welcome, {{client_name}}</h2><ol><li>Confirm ICP: {{vertical}} in {{geo}}</li><li>CRM login</li><li>Sample pack review</li><li>First pipeline run</li></ol>',
   'Welcome {{client_name}}. Confirm ICP {{vertical}} / {{geo}}, CRM login, sample pack, first run.',
   '["client_name","vertical","geo"]', 'both')
) AS x(category, name, description, body_html, body_text, variables, channel_hint)
WHERE NOT EXISTS (SELECT 1 FROM doc_templates WHERE name = x.name AND tenant_id IS NULL);


-- ##### 014_email_outreach.sql #####

CREATE TABLE IF NOT EXISTS email_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  to_email      text NOT NULL,
  subject       text,
  status        text NOT NULL DEFAULT 'queued',
  provider      text,
  provider_id   text,
  error         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_sends_tenant ON email_sends (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_sends_assignment ON email_sends (assignment_id);
