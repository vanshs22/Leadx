# Run in GitHub Codespaces (or local)

## 1. Supabase (one-time)
- SQL Editor → run `lead-engine-v2/SUPABASE_FULL_MIGRATION.sql`
- Copy Project URL, anon key, service_role key, JWT secret

## 2. Env files
```bash
cp lead-engine-v2/.env.example lead-engine-v2/.env
# edit .env → paste SUPABASE_* and optional SERPER / FIRECRAWL / OPENAI

cp lead-crm-portal/frontend/.env.local.example lead-crm-portal/frontend/.env.local
# edit .env.local → paste NEXT_PUBLIC_SUPABASE_URL + ANON_KEY only
```

## 3. Start
```bash
# Terminal 1 — API
cd lead-engine-v2
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
set -a && source .env && set +a
export PYTHONPATH=.
uvicorn backend.app_service:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2 — Web
cd lead-crm-portal/frontend
npm install
npm run dev -- -H 0.0.0.0 -p 3000
```

## 4. Open
- Forward port **3000** in Codespaces → open that URL
- Admin: `/admin/login` → Continue (open mode)
- Client: `/login` after creating a user + tenant_members row

## Keys
| Key | Where | Needed for |
|-----|--------|------------|
| SUPABASE_* | API `.env` + frontend anon | Login + data |
| LEAD_ENGINE_SERVICE_KEY | API `.env` | Admin in prod |
| SERPER_API_KEY | API `.env` | Finding leads |
| FIRECRAWL_API_KEY | API `.env` | Page crawl / enrich |
| OPENAI_API_KEY | API `.env` | LLM enrich / scoring assist |
| RESEND_* | API `.env` | Sending email |

Do **not** set `NEXT_PUBLIC_API_URL=http://localhost:8000` in Codespaces.
Leave it unset; Next proxies `/backend` → API.
