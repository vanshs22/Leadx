import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js';

const root = process.cwd();
const front = path.join(root, 'lead-crm-portal');
const files = [];
function walk(dir) {
  for (const ent of fs.readdirSync(dir, {withFileTypes:true})) {
    if (['node_modules','.next'].includes(ent.name)) continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else if (/\.(ts|tsx)$/.test(ent.name) && !ent.name.endsWith('.d.ts')) files.push(p);
  }
}
walk(front);
let errors=[];
for (const file of files) {
  const source = fs.readFileSync(file,'utf8');
  const out = ts.transpileModule(source, {
    fileName:file,
    reportDiagnostics:true,
    compilerOptions:{target:ts.ScriptTarget.ES2017, module:ts.ModuleKind.ESNext, jsx:ts.JsxEmit.Preserve, isolatedModules:true, moduleResolution:ts.ModuleResolutionKind.Bundler}
  });
  for (const d of out.diagnostics || []) {
    if (d.category === ts.DiagnosticCategory.Error) {
      errors.push(`${path.relative(front,file)}: ${ts.flattenDiagnosticMessageText(d.messageText,' ')}`);
    }
  }
}
console.log(`frontend_files=${files.length}`);
if (errors.length) {
  console.error(`syntax_errors=${errors.length}`);
  for (const e of errors.slice(0,50)) console.error(e);
  process.exit(1);
}
console.log('frontend_syntax=PASS');
