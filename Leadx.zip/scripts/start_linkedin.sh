#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCRAPER="$ROOT/lead-engine-v2/services/linkedin-scraper"
DOCKER="${DOCKER:-docker}"

if curl -sf http://127.0.0.1:8001/health >/dev/null 2>&1; then
  echo "Already healthy on :8001"
  curl -s http://127.0.0.1:8001/health
  exit 0
fi

if ! command -v docker >/dev/null 2>&1 && ! command -v sudo >/dev/null; then
  echo "Docker required"
  exit 1
fi

if ! docker info >/dev/null 2>&1; then
  sudo service docker start 2>/dev/null || sudo systemctl start docker 2>/dev/null || true
  sleep 2
  if ! docker info >/dev/null 2>&1 && sudo docker info >/dev/null 2>&1; then
    DOCKER="sudo docker"
  fi
fi

$DOCKER rm -f leadx-linkedin 2>/dev/null || true
cd "$SCRAPER"
$DOCKER build -t leadx-linkedin-scraper .
$DOCKER run -d --name leadx-linkedin --restart unless-stopped \
  -p 8001:8001 --memory=512m --cpus=1 \
  -e CHROME_SINGLE_PROCESS=1 \
  leadx-linkedin-scraper

for i in 1 2 3 4 5 6 7 8 9 10; do
  if curl -sf http://127.0.0.1:8001/health; then
    echo ""
    echo "LinkedIn scraper OK on :8001"
    exit 0
  fi
  sleep 3
done
echo "Failed — logs:"
$DOCKER logs leadx-linkedin 2>&1 | tail -40
exit 1
