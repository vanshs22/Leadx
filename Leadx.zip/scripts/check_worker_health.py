from pathlib import Path
import time
p=Path("/tmp/leadx-worker-heartbeat")
if not p.exists(): raise SystemExit("worker heartbeat missing")
if time.time()-p.stat().st_mtime > 120: raise SystemExit("worker heartbeat stale")
print("worker health: PASS")
