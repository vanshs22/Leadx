#!/usr/bin/env python3
"""One terminal command for LeadX offline gates plus optional live probes.

Safe defaults are read-only/static. Live HTTP, worker, cross-tenant, agent-write,
and frontend-build checks are opt-in with flags or environment variables.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run_step(name: str, command: list[str], *, cwd: Path = ROOT, required: bool = True) -> bool:
    print(f"\n== {name} ==")
    print("$ " + " ".join(command))
    started = time.monotonic()
    try:
        result = subprocess.run(command, cwd=cwd, text=True, env=os.environ.copy())
    except OSError as exc:
        print(f"SKIP: {exc}")
        return not required
    elapsed = time.monotonic() - started
    if result.returncode == 0:
        print(f"PASS ({elapsed:.1f}s)")
        return True
    print(f"FAIL ({elapsed:.1f}s, exit {result.returncode})")
    return False


def probe_json(name: str, url: str, *, require_ok: bool = False) -> bool:
    print(f"\n== {name} ==\nGET {url}")
    try:
        with urlopen(Request(url, headers={"Accept": "application/json"}), timeout=8) as response:
            body = response.read().decode("utf-8", "replace")
            status = response.status
    except (HTTPError, URLError, TimeoutError, OSError) as exc:
        print(f"FAIL: {exc}")
        return False
    print(f"HTTP {status}")
    if status < 200 or status >= 300:
        return False
    if not require_ok:
        return True
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        print("FAIL: response was not JSON")
        return False
    ok = payload.get("ok") is True
    print(f"ok={payload.get('ok')!r}")
    return ok


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frontend-build", action="store_true", help="run npm ci, TypeScript, and Next build")
    parser.add_argument("--live", action="store_true", help="probe the configured API and frontend URLs")
    parser.add_argument("--worker", action="store_true", help="require a fresh local worker heartbeat")
    args = parser.parse_args()

    failures: list[str] = []
    skipped: list[str] = []

    def step(name: str, command: list[str], *, required: bool = True, cwd: Path = ROOT) -> None:
        if not run_step(name, command, cwd=cwd, required=required):
            failures.append(name)

    # Python, migration, schema, security, and production-contract checks.
    step("Python compile", [PYTHON, "-m", "compileall", "-q", "app", "services", "tests"])
    if shutil.which("ruff"):
        step("Ruff", ["ruff", "check", "app", "services", "tests"])
    else:
        skipped.append("Ruff (ruff not installed)")
    for name, script in [
        ("Migration chain", "check_migrations.py"),
        ("RLS coverage", "check_rls_coverage.py"),
        ("Runtime schema", "verify_runtime_schema.py"),
        ("Plan contract", "check_plan_contract.py"),
        ("Security release gate", "security_release_gate.py"),
        ("Release audit", "release_audit.py"),
        ("Frontend syntax", "frontend_syntax_check.mjs"),
        ("Frontend accessibility", "check_frontend_accessibility.py"),
        ("Frontend performance", "check_frontend_performance.py"),
    ]:
        path = ROOT / "scripts" / script
        if not path.exists():
            skipped.append(f"{name} (script missing)")
        elif script.endswith(".mjs"):
            if shutil.which("node"):
                step(name, ["node", str(path)])
            else:
                skipped.append(f"{name} (node not installed)")
        else:
            step(name, [PYTHON, str(path)])

    # Agent registry/DAG and strict offline pipeline/agent behavior.
    step("Agent registry and wiring", [PYTHON, "scripts/test_31_agents_crm.py", "--mode", "wiring"])
    if (ROOT / "tests" / "rig").exists():
        step("Strict pipeline and agent rig", [PYTHON, "-m", "pytest", "-q", "tests/rig"])
    else:
        skipped.append("Strict pipeline and agent rig (tests/rig missing)")
    step("Project pytest", [PYTHON, "-m", "pytest", "-q"])

    if args.frontend_build:
        frontend = ROOT / "lead-crm-portal"
        if not shutil.which("npm"):
            failures.append("Frontend build (npm not installed)")
        else:
            if os.getenv("LEADX_NPM_CI", "1") == "1":
                step("Frontend dependency install", ["npm", "ci"], cwd=frontend)
            step("Frontend TypeScript", ["npx", "tsc", "--noEmit"], cwd=frontend)
            step("Frontend production build", ["npm", "run", "build"], cwd=frontend)

    if args.live:
        api = os.getenv("LEADX_API_URL", "http://127.0.0.1:8000").rstrip("/")
        frontend = os.getenv("LEADX_FRONTEND_URL", "http://127.0.0.1:3000").rstrip("/")
        if not probe_json("API readiness", f"{api}/health/ready", require_ok=True):
            failures.append("API readiness")
        if not probe_json("API health", f"{api}/health", require_ok=True):
            failures.append("API health")
        if not probe_json("API route contract", f"{api}/health/routes", require_ok=True):
            failures.append("API route contract")
        try:
            with urlopen(frontend, timeout=8) as response:
                print(f"\n== Frontend HTTP ==\nHTTP {response.status}")
                if response.status < 200 or response.status >= 400:
                    failures.append("Frontend HTTP")
        except (HTTPError, URLError, TimeoutError, OSError) as exc:
            print(f"\n== Frontend HTTP ==\nFAIL: {exc}")
            failures.append("Frontend HTTP")

    if args.worker:
        step("Worker heartbeat", [PYTHON, "scripts/check_worker_health.py"])

    print("\n=== LeadX verification summary ===")
    if failures:
        print("FAIL:")
        for item in failures:
            print(f"  - {item}")
    if skipped:
        print("SKIPPED:")
        for item in skipped:
            print(f"  - {item}")
    if not failures:
        print("PASS: all enabled checks completed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
