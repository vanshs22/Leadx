#!/usr/bin/env bash
# LeadX — one script to run API + optional notes for frontend
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
API="$ROOT/lead-engine-v2"
WEB="$ROOT/lead-crm-portal/frontend"

echo "========================================"
echo " LeadX start"
echo "========================================"

if [ ! -f "$API/.env" ]; then
  echo "Creating $API/.env from example..."
  cp "$API/.env.example" "$API/.env"
  echo ""
  echo "EDIT lead-engine-v2/.env and set at least:"
  echo "  SUPABASE_URL"
  echo "  SUPABASE_SERVICE_KEY"
  echo "  SERPER_API_KEY   (for real leads)"
  echo "  ENVIRONMENT=development"
  echo "  LEAD_ENGINE_DEV_AUTH_BYPASS=1   <-- LOCAL DEV ONLY (see warning below)"
  echo ""
  echo "!! WARNING: LEAD_ENGINE_DEV_AUTH_BYPASS=1 DISABLES AUTHENTICATION."
  echo "!! Any unauthenticated request sending an 'X-Tenant-Id' header gets"
  echo "!! OWNER access to that tenant - a full tenant-isolation bypass."
  echo "!! Keep it ONLY on a local 127.0.0.1 machine. Remove it before any"
  echo "!! shared/staging/public deploy or exposed tunnel."
  echo ""
  echo "Then run: ./start.sh"
  exit 1
fi

# Force simple testing mode if not production
grep -q '^ENVIRONMENT=' "$API/.env" 2>/dev/null || echo 'ENVIRONMENT=development' >> "$API/.env"

if ! grep -q 'LEAD_ENGINE_DEV_AUTH_BYPASS' "$API/.env" 2>/dev/null; then
  echo 'LEAD_ENGINE_DEV_AUTH_BYPASS=1' >> "$API/.env"
  echo ""
  echo "########################################################################"
  echo "# !! SECURITY WARNING: wrote LEAD_ENGINE_DEV_AUTH_BYPASS=1 to .env     #"
  echo "########################################################################"
  echo "#  This DISABLES AUTHENTICATION for the API."
  echo "#  Any unauthenticated request with an 'X-Tenant-Id: <tenant>' header"
  echo "#  is granted OWNER-ROLE access to that tenant. No JWT, no API key."
  echo "#  That is a complete tenant-isolation bypass (all leads, API keys,"
  echo "#  billing and admin actions of every tenant)."
  echo "#"
  echo "#  Safe ONLY for local development bound to 127.0.0.1."
  echo "#  Remove this line from $API/.env before exposing this API to any"
  echo "#  network you do not control (staging, preview, public IP, tunnel)."
  echo "#"
  echo "#  It is force-disabled when ENVIRONMENT=production/staging, but treat"
  echo "#  that as a backstop, not permission to ship it."
  echo "########################################################################"
  echo ""
fi

echo "==> API"
cd "$API"
if command -v docker >/dev/null 2>&1 && [ -f docker-compose.yml ]; then
  docker compose up -d --build api || {
    echo "Docker failed — trying uvicorn..."
    export PYTHONPATH=.
    pip install -q -r requirements-lead-v2.txt 2>/dev/null || pip install -q fastapi uvicorn httpx supabase pydantic python-dotenv
    pkill -f "uvicorn backend.app_service" 2>/dev/null || true
    nohup uvicorn backend.app_service:app --host 0.0.0.0 --port 8000 > /tmp/lead-api.log 2>&1 &
    sleep 3
  }
else
  export PYTHONPATH=.
  pip install -q fastapi uvicorn httpx supabase pydantic python-dotenv 2>/dev/null || true
  pkill -f "uvicorn backend.app_service" 2>/dev/null || true
  nohup uvicorn backend.app_service:app --host 0.0.0.0 --port 8000 > /tmp/lead-api.log 2>&1 &
  sleep 3
fi

echo -n "Health: "
if curl -sf http://127.0.0.1:8000/health; then
  echo ""
  echo "API OK on :8000"
else
  echo "FAILED"
  echo "Logs: docker compose -f $API/docker-compose.yml logs api | tail -50"
  echo " or:  tail -50 /tmp/lead-api.log"
  exit 1
fi

echo ""
echo "==> Frontend"
cd "$WEB"
# Prefer proxy (empty or unset NEXT_PUBLIC_API_URL)
if [ ! -f .env.local ]; then
  echo "# use Next.js /backend proxy → 127.0.0.1:8000" > .env.local
  echo "API_UPSTREAM=http://127.0.0.1:8000" >> .env.local
fi
if [ ! -d node_modules ]; then
  npm install
fi

echo ""
echo "========================================"
echo " Open the UI:"
echo "   http://localhost:3000"
echo " Codespaces: open forwarded port 3000"
echo " Workspace → Create & open → Search"
echo "========================================"
echo ""
npm run dev
