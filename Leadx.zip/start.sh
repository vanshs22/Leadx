#!/usr/bin/env bash
# Quick start after setup.sh --install-only
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
API="$ROOT/lead-engine-v2"
WEB="$ROOT/lead-crm-portal/frontend"
VENV="$API/.venv"

if [ ! -f "$VENV/bin/activate" ]; then
  echo "No venv. Run: chmod +x setup.sh && ./setup.sh --install-only"
  exit 1
fi
# shellcheck source=/dev/null
source "$VENV/bin/activate"
export PYTHONPATH="$API${PYTHONPATH:+:$PYTHONPATH}"

APP_MODULE="backend.app_service:app"
[ -f "$API/backend/app_service.py" ] || APP_MODULE="backend.main:app"

cd "$API"
pkill -f "uvicorn ${APP_MODULE%%:*}" 2>/dev/null || true
nohup uvicorn "$APP_MODULE" --host 0.0.0.0 --port 8000 --reload > /tmp/leadx-api.log 2>&1 &
sleep 2
curl -sf http://127.0.0.1:8000/health && echo "" || echo "API starting… see /tmp/leadx-api.log"

cd "$WEB"
[ -d node_modules ] || npm install
npm run dev
