# LeadX 15.8 Migration Lineage

The executable database source of truth is `supabase/migrations/`, containing **22 ordered migrations**. `SUPABASE_FULL_MIGRATION.sql` is the clean-install mirror of that same chain.

Legacy SQL patches are intentionally not shipped in 15.8. This prevents operators from accidentally applying obsolete patches alongside the canonical chain.

15.7 added `20261001000500_leadx_15_7_oauth_security.sql` for tenant/user/provider-bound, single-use OAuth state.

15.8 adds `20261001000600_leadx_15_8_security_hardening.sql` for service-only billing functions, hardened `search_path`, browser-role revocation, and explicit service-role policies.
