-- FIX_pipeline_run_leads.sql
-- Run once in Supabase SQL Editor if Run Board is empty / errors

CREATE TABLE IF NOT EXISTS public.pipeline_run_leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id uuid NOT NULL REFERENCES public.pipeline_runs(id) ON DELETE CASCADE,
  lead_id uuid NOT NULL REFERENCES public.leads_global(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE SET NULL,
  stage text NOT NULL DEFAULT 'discovered',
  tier text,
  included boolean NOT NULL DEFAULT true,
  score int,
  source text,
  name text,
  phone text,
  website text,
  city text,
  position int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (run_id, lead_id)
);

CREATE INDEX IF NOT EXISTS idx_prl_run ON public.pipeline_run_leads(run_id);
CREATE INDEX IF NOT EXISTS idx_prl_tenant ON public.pipeline_run_leads(tenant_id);
CREATE INDEX IF NOT EXISTS idx_prl_stage ON public.pipeline_run_leads(run_id, stage);

ALTER TABLE public.pipeline_run_leads ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_all_pipeline_run_leads" ON public.pipeline_run_leads;
CREATE POLICY "service_all_pipeline_run_leads" ON public.pipeline_run_leads
  FOR ALL USING (true) WITH CHECK (true);

-- Optional: heal portal deliveries wrongly marked failed
UPDATE public.lead_assignments
SET delivery_status = 'portal', delivery_error = NULL
WHERE lower(coalesce(delivery_status, '')) = 'failed'
  AND lower(coalesce(delivery_channel, 'portal')) IN ('portal', 'crm', 'none', 'internal', 'dashboard', '');

NOTIFY pgrst, 'reload schema';
