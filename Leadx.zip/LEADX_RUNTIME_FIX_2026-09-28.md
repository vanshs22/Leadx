# LeadX — Runtime, Help, Login & Dashboard Performance Fix

## Fixed

### Dashboard `RECOVERABLE_API_404`
- Protected `/crm/me` remains guaranteed.
- Added a protected runtime dashboard safety route if the optional CRM router fails to mount.
- Added tenant-scoped 5-second dashboard caching.
- Moved the synchronous dashboard snapshot RPC off the FastAPI event loop.

### LeadX Help `Internal server error`
- Support conversation inserts now explicitly return the created row.
- Support storage failures return explicit 503 errors instead of opaque 500s.
- `hi`/`hello`/`hey`/`help` get an immediate deterministic response.
- Deterministic FAQ is the fast default.
- LLM rewriting is opt-in with `SUPPORT_LLM_ENHANCE=1`, so an LLM/provider outage cannot break Help.
- FAQ cache remains 60 seconds.

### Login speed
- Successful Supabase login primes an in-memory session cache with the exact session returned by Supabase.
- SessionGate reuses that session instead of immediately reading it again.
- Concurrent session reads are deduplicated.
- Access-token cache is 60 seconds and refreshed by Supabase auth-state events.
- Dashboard JS is prefetched while credentials are entered.
- Existing tenant cache lets returning users enter the shell without another tenant-resolution request.

### General performance
- Existing GET cache/in-flight deduplication retained and extended to 15 seconds.
- Existing pooled backend HTTP and membership caching retained.
- FastAPI GZip compression added for responses over 1 KB.
- Existing Codespaces `/backend` + forwarded `:8000` fallback retained.

## Validation
- Python compilation: PASS
- FastAPI application import: PASS
- `/crm/me`: exactly 1 route
- `/crm/{tenant_id}/dashboard`: exactly 1 route
- Support client routes: mounted
- Full backend pytest suite: PASS — 56 tests
- Selected runtime/support tests: PASS — 9 tests
- Frontend JS configuration syntax: PASS
- Frontend production build: not run because npm registry packages were unavailable in the offline packaging environment.

## Codespaces restart

Replace the source, then restart the old FastAPI process so it cannot keep serving the previous code:

```bash
cd /workspaces/LeadX/lead-engine-v2
pkill -f 'uvicorn.*8000' || true
python -m py_compile app/app_service.py
uvicorn app.app_service:app --host 0.0.0.0 --port 8000 --reload
```

Verify without a token:

```bash
curl -i http://127.0.0.1:8000/crm/me
```

Expected: **401/403**, never 404.

Restart frontend:

```bash
cd /workspaces/LeadX/lead-crm-portal/frontend
npm run clean
npm run dev
```
