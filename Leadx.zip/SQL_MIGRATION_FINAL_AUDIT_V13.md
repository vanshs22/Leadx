# LeadX 15.8 SQL Migration — Final Audit V13

## Source of truth

LeadX 15.8 FINAL SQL HARDENED V12 was used as the source of truth. No older LeadX release was substituted.

## Root cause fixed

The previous full migration defined `public.lead_outcome_events` twice with two incompatible schemas:

- the earlier CRM/competitive schema used `assignment_id`, `note`, and `recorded_at`;
- the later intelligence schema used `signal`, `value`, `positive`, `metadata`, and `occurred_at`.

Because both statements used `CREATE TABLE IF NOT EXISTS`, the second definition did **not** add its columns when the first table already existed. Later indexes referenced `occurred_at`, which caused the reported PostgreSQL `42703: column "occurred_at" does not exist` failure.

V13 reconciles the table into one compatible shape containing both historical and intelligence fields, and explicitly adds every missing column before downstream indexes/policies use them.

## Additional SQL fix

The CRM trigram index previously referenced `contacts.name`, while the canonical `contacts` table uses `full_name`. The index now targets `contacts.full_name`.

## Whole-file checks

- Full migration: 10,000+ lines retained.
- Canonical migrations: 22.
- Malformed single-column `ADD COLUMN IF NOT EXISTS` chains: 0.
- Index column static audit: 0 unresolved column references.
- Duplicate-table compatibility audit: `lead_outcome_events` fully reconciled.
- Runtime schema static contract: PASS.
- Release audit: 14/14 PASS.
- Existing pytest suite: PASS.
- No environment secrets added.

## Important execution limitation

The release environment does not have a live Supabase database/credentials or a PostgreSQL server binary, so a real execution against a live Supabase project was not possible here. The SQL was therefore repaired and checked with repository/runtime schema audits and targeted PostgreSQL-compatibility analysis. This does not claim that your specific live database is already migrated.

## Run

Use only the root:

`SUPABASE_FULL_MIGRATION.sql`

Do not execute the historical `docs/archive/SUPABASE_FULL_MIGRATION_V7.sql`.
