# LeadX Runtime / Login / Realtime QA — 2026-09-28

## Fixed in this build

1. **Client portal `/crm/me` 404**
   - Backend contains a direct protected `GET /crm/me` bootstrap route.
   - Existing CRM router route remains available.
   - Old backend processes must be stopped/restarted; a running stale process cannot pick up source changes.

2. **Supabase Realtime runtime crash**
   - Root cause: two portal components could create/use the same tenant channel. One could subscribe it while the other was still registering `postgres_changes` handlers.
   - Fixed with one browser channel manager per tenant and serialized channel removal/reconnect.
   - Global full-page reload on every realtime event was removed to prevent a multi-user thundering herd.

3. **Login / API hot path**
   - Browser API requests race the same-origin `/backend` path and the Codespaces forwarded `:8000` path for recoverable failures.
   - Access-token reads are cached briefly in-browser instead of calling `getSession()` for every API request.
   - Backend auth uses pooled async HTTP and a larger connection pool.
   - Production Docker defaults to 4 FastAPI workers via `WEB_CONCURRENCY`.

4. **Codespaces development speed**
   - `npm run dev` now uses Next.js Turbopack (`next dev --turbo`) to reduce cold development compilation time.

5. **Branding**
   - Replaced the prior Aurora/blue-purple/cyan direction with **LeadX Deep Teal / Tangerine**.
   - Teal is the identity/primary action color; tangerine is reserved for opportunity/live signals.

## Verification

- Python compilation: PASS
- Backend pytest suite: PASS (56 tests in the packaged suite)
- `/crm/me` route inspection: PASS; protected route exists
- Unauthenticated `GET /crm/me`: **401**, which proves the route exists and is protected (404 is the broken state)
- JavaScript config syntax (`next.config.js`, `tailwind.config.js`, `clean.mjs`): PASS
- Legacy Aurora/Cobalt/Saffron source palette removed from the active UI system
- Full frontend `npm ci` / production build was not completed in this environment because registry access timed out and the offline npm cache did not contain all packages. The package intentionally excludes `node_modules`.

## Required Codespaces restart

### Terminal 1 — API

```bash
cd /workspaces/LeadX/lead-engine-v2
python -m py_compile app/app_service.py
uvicorn app.app_service:app --host 0.0.0.0 --port 8000 --reload
```

Verify:

```bash
curl -i http://127.0.0.1:8000/crm/me
```

Expected without a token: **401/403**, never 404.

### Terminal 2 — frontend

```bash
cd /workspaces/LeadX/lead-crm-portal/frontend
npm install
npm run dev
```

For production, use the Docker image or a managed process with multiple API workers. Do not use `--reload` with multiple workers.
