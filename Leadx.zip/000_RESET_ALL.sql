-- ============================================================
-- LeadX: wipe public schema objects (DATA LOSS)
-- Then run SUPABASE_FULL_MIGRATION.sql once.
-- Does NOT delete Auth users (Authentication → Users).
-- ============================================================

DROP VIEW IF EXISTS public.crm_lead_cards CASCADE;
DROP VIEW IF EXISTS public.deliverable_leads CASCADE;

DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);
DROP FUNCTION IF EXISTS public.check_exclusivity(uuid, text, text[], text);
DROP FUNCTION IF EXISTS public.credit_tenant_usage(uuid, int);
DROP FUNCTION IF EXISTS public.tenant_quota_remaining(uuid);
DROP FUNCTION IF EXISTS public.is_opted_out(text, text, text, text);
DROP FUNCTION IF EXISTS public.is_suppressed(uuid, text, text, text, text);
DROP FUNCTION IF EXISTS public.bump_usage(uuid, int);

DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT tablename
    FROM pg_tables
    WHERE schemaname = 'public'
  ) LOOP
    EXECUTE format('DROP TABLE IF EXISTS public.%I CASCADE', r.tablename);
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';
