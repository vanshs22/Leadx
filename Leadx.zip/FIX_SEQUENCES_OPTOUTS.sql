-- Safe to re-run on existing DB
-- Sequences / opt-outs / inbound replies

-- ─── Email opt-outs, sequences, inbound replies ────────────────────────────
-- Distinct from the global business-suppression list (that's "never resell
-- this business as a lead"); this is specifically "never email this
-- address again", checked before every send regardless of provider.
CREATE TABLE IF NOT EXISTS email_optouts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  reason      text DEFAULT 'unsubscribe_link',
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, email)
);
CREATE INDEX IF NOT EXISTS idx_email_optouts_email ON email_optouts (lower(email));

CREATE TABLE IF NOT EXISTS email_sequences (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
  status      text NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','archived')),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_sequence_steps (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence_id   uuid NOT NULL REFERENCES email_sequences(id) ON DELETE CASCADE,
  step_number   int NOT NULL,
  delay_days    int NOT NULL DEFAULT 0,
  subject       text NOT NULL,
  body_html     text NOT NULL,
  body_text     text,
  UNIQUE (sequence_id, step_number)
);

CREATE TABLE IF NOT EXISTS email_sequence_enrollments (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  sequence_id     uuid NOT NULL REFERENCES email_sequences(id) ON DELETE CASCADE,
  assignment_id   uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  current_step    int NOT NULL DEFAULT 0,
  status          text NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','completed','stopped_reply','stopped_optout','stopped_manual')),
  next_send_at    timestamptz,
  enrolled_at     timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (sequence_id, assignment_id)
);
CREATE INDEX IF NOT EXISTS idx_seq_enroll_due
  ON email_sequence_enrollments (status, next_send_at)
  WHERE status = 'active';

CREATE TABLE IF NOT EXISTS email_replies (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  from_email    text NOT NULL,
  subject       text,
  body_text     text,
  category      text NOT NULL DEFAULT 'unclassified'
                  CHECK (category IN ('positive','negative','opt_out','question','unclassified')),
  raw_meta      jsonb DEFAULT '{}',
  received_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_email_replies_tenant ON email_replies (tenant_id, received_at DESC);

DO $$ BEGIN
  ALTER TABLE email_optouts ENABLE ROW LEVEL SECURITY;
  ALTER TABLE email_sequences ENABLE ROW LEVEL SECURITY;
  ALTER TABLE email_sequence_steps ENABLE ROW LEVEL SECURITY;
  ALTER TABLE email_sequence_enrollments ENABLE ROW LEVEL SECURITY;
  ALTER TABLE email_replies ENABLE ROW LEVEL SECURITY;
EXCEPTION WHEN OTHERS THEN NULL; END $$;

DROP POLICY IF EXISTS tenant_rw_email_sequences ON email_sequences;
CREATE POLICY tenant_rw_email_sequences ON email_sequences
  FOR ALL USING (tenant_id IN (SELECT public.current_tenant_ids()))
  WITH CHECK (tenant_id IN (SELECT public.current_tenant_ids()));

DROP POLICY IF EXISTS tenant_rw_seq_steps ON email_sequence_steps;
CREATE POLICY tenant_rw_seq_steps ON email_sequence_steps
  FOR ALL USING (sequence_id IN (SELECT id FROM email_sequences WHERE tenant_id IN (SELECT public.current_tenant_ids())))
  WITH CHECK (sequence_id IN (SELECT id FROM email_sequences WHERE tenant_id IN (SELECT public.current_tenant_ids())));

DROP POLICY IF EXISTS tenant_rw_seq_enroll ON email_sequence_enrollments;
CREATE POLICY tenant_rw_seq_enroll ON email_sequence_enrollments
  FOR ALL USING (tenant_id IN (SELECT public.current_tenant_ids()))
  WITH CHECK (tenant_id IN (SELECT public.current_tenant_ids()));

DROP POLICY IF EXISTS tenant_rw_email_replies ON email_replies;
CREATE POLICY tenant_rw_email_replies ON email_replies
  FOR ALL USING (tenant_id IN (SELECT public.current_tenant_ids()))
  WITH CHECK (tenant_id IN (SELECT public.current_tenant_ids()));

NOTIFY pgrst, 'reload schema';
