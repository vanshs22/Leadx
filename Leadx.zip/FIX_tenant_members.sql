-- FIX tenant_members for portal login attach
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS role text DEFAULT 'member';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';

-- Unique (tenant_id, auth_user_id) if missing
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tenant_members_tenant_id_auth_user_id_key'
  ) AND NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname LIKE '%tenant_members%auth%'
  ) THEN
    BEGIN
      ALTER TABLE public.tenant_members ADD CONSTRAINT tenant_members_tenant_id_auth_user_id_key UNIQUE (tenant_id, auth_user_id);
    EXCEPTION WHEN others THEN NULL;
    END;
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
