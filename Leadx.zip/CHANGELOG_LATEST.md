# LeadX package — latest

## Included fixes
- Valid UUID hex only in `SUPABASE_FULL_MIGRATION.sql` (no d3m00 / ct001)
- `api_key_pool` allows `linkedin_scraper` (`sql/018_api_key_pool_linkedin.sql`)
- LinkedIn scraper service under `lead-engine-v2/services/linkedin-scraper/`
- Client `/login` outside portal layout; `/` redirects to login
- SessionGate requires Supabase session
- CSS `.shell` flex row (sidebar beside content)
- Admin overview stats cards

## Run provider fix on existing DB
```sql
-- see sql/018_api_key_pool_linkedin.sql
```
