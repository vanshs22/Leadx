-- Mark stuck "running" jobs as failed so UI is not stuck
UPDATE public.pipeline_runs
SET
  status = 'failed',
  error_message = COALESCE(error_message, 'stale_run_auto_finalized'),
  finished_at = COALESCE(finished_at, now()),
  meta = COALESCE(meta, '{}'::jsonb) || '{"stage":"stale","message":"Finalized stuck running job"}'::jsonb
WHERE status IN ('running', 'queued', 'started')
  AND started_at < now() - interval '30 minutes';
