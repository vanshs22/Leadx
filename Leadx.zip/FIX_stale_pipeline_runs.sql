UPDATE public.pipeline_runs
SET
  status = 'failed',
  error_message = COALESCE(NULLIF(error_message, ''), 'stale_run_auto_finalized'),
  finished_at = COALESCE(finished_at, now())
WHERE status IN ('running', 'queued', 'started')
  AND started_at < now() - interval '20 minutes';
