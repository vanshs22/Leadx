#!/usr/bin/env python3
"""Run the LeadX production-readiness matrix without faking live gates.

Local checks are executable in CI or a developer checkout. Live checks are
reported BLOCKED until staging credentials are present; missing credentials are
never treated as a passing test.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Result:
    gate: str
    status: str
    evidence: str
    detail: str = ""


def command_result(gate: str, command: list[str], evidence: str, timeout: int = 300) -> Result:
    try:
        completed = subprocess.run(
            command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=timeout,
        )
    except FileNotFoundError as exc:
        return Result(gate, "NOT TESTED", evidence, f"missing executable: {exc.filename}")
    except subprocess.TimeoutExpired:
        return Result(gate, "FAIL", evidence, f"timed out after {timeout}s")
    if completed.returncode == 0:
        return Result(gate, "PASS", evidence)
    output = (completed.stdout or "").strip().splitlines()
    if completed.returncode == 127 or any("pyenv: " in line and "command not found" in line for line in output):
        return Result(gate, "NOT TESTED", evidence, "executable is not installed in the selected runtime")
    return Result(gate, "FAIL", evidence, "\n".join(output[-8:])[:2000])


def blocked(gate: str, evidence: str, variables: list[str]) -> Result:
    missing = [name for name in variables if not os.getenv(name)]
    return Result(gate, "BLOCKED", evidence, "missing staging variables: " + ", ".join(missing))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-frontend", action="store_true", help="run npm install/typecheck/build")
    parser.add_argument("--run-tests", action="store_true", help="run pytest when dependencies are installed")
    parser.add_argument("--json", action="store_true", help="emit JSON instead of the human-readable report")
    parser.add_argument("--allow-blocked", action="store_true", help="exit zero when only external gates are blocked")
    args = parser.parse_args()

    py = sys.executable
    results: list[Result] = []
    local = [
        ("Python compilation", [py, "-m", "compileall", "-q", "app", "services", "tests"], "compileall"),
        ("Migration contract", [py, "scripts/check_migrations.py"], "check_migrations.py"),
        ("RLS coverage", [py, "scripts/check_rls_coverage.py"], "check_rls_coverage.py"),
        ("Runtime schema", [py, "scripts/verify_runtime_schema.py"], "verify_runtime_schema.py"),
        ("Plan contract", [py, "scripts/check_plan_contract.py"], "check_plan_contract.py"),
        ("Security release gate", [py, "scripts/security_release_gate.py"], "security_release_gate.py"),
        ("Release audit", [py, "scripts/release_audit.py"], "release_audit.py"),
    ]
    for gate, command, evidence in local:
        results.append(command_result(gate, command, evidence))

    ruff = shutil.which("ruff")
    if ruff:
        results.append(command_result("Functional lint", [ruff, "check", "app", "services", "tests"], "ruff"))
    else:
        results.append(Result("Functional lint", "NOT TESTED", "ruff", "install requirements-dev.txt"))

    if args.run_tests:
        if importlib_available("pytest"):
            results.append(command_result("Backend tests", [py, "-m", "pytest", "-q"], "pytest -q", timeout=1800))
        else:
            results.append(Result("Backend tests", "NOT TESTED", "pytest -q", "pytest is not installed"))
    else:
        results.append(Result("Backend tests", "NOT TESTED", "pytest -q", "rerun with --run-tests"))

    if args.run_frontend:
        npm = shutil.which("npm")
        if not npm:
            results.append(Result("Frontend", "NOT TESTED", "npm ci / tsc / build", "npm is not installed"))
        else:
            results.append(command_result("Frontend dependency audit", [npm, "audit", "--audit-level=high"], "npm audit", timeout=300))
            results.append(command_result("Frontend typecheck", [npm, "exec", "tsc", "--noEmit"], "npx tsc --noEmit", timeout=600))
            results.append(command_result("Frontend production build", [npm, "run", "build"], "npm run build", timeout=1200))
    else:
        results.append(Result("Frontend", "NOT TESTED", "npm ci / tsc / build", "rerun with --run-frontend"))

    live_vars = [
        "LEADX_STAGING_URL", "LEADX_TENANT_A_TOKEN", "LEADX_TENANT_B_TOKEN",
        "LEADX_TENANT_A_ID", "LEADX_TENANT_B_ID", "SUPABASE_URL",
        "SUPABASE_SERVICE_KEY", "STRIPE_TEST_SECRET_KEY",
    ]
    results.append(blocked("Live staging isolation and money path", "cross_tenant_smoke.py + Playwright + Stripe", live_vars))
    results.append(blocked("Live queue/provider/concurrency tests", "worker/DB/provider/load tests", ["LEADX_STAGING_URL", "SUPABASE_SERVICE_KEY", "REDIS_URL"]))
    results.append(blocked("Backup/restore/disaster recovery", "operator-controlled backup and PITR rehearsal", ["SUPABASE_PROJECT_ID", "SUPABASE_DB_PASSWORD"]))

    if args.json:
        print(json.dumps([asdict(item) for item in results], indent=2))
    else:
        print("LeadX production-readiness matrix")
        print("=" * 80)
        for item in results:
            print(f"[{item.status:10}] {item.gate}: {item.evidence}")
            if item.detail:
                print(f"             {item.detail}")
        print("=" * 80)
        counts = {status: sum(item.status == status for item in results) for status in ("PASS", "FAIL", "BLOCKED", "NOT TESTED")}
        print(" ".join(f"{key}={value}" for key, value in counts.items()))

    if any(item.status == "FAIL" for item in results):
        return 1
    if not args.allow_blocked and any(item.status in {"BLOCKED", "NOT TESTED"} for item in results):
        return 2
    return 0


def importlib_available(name: str) -> bool:
    import importlib.util
    return importlib.util.find_spec(name) is not None


if __name__ == "__main__":
    raise SystemExit(main())
