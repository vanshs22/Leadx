from pathlib import Path

from app.layers.persistence_layer import _ensure_identity

ROOT = Path(__file__).resolve().parents[1]


def test_persistence_materializes_stable_lead_identity():
    lead = _ensure_identity({
        "name": " Acme Med Spa ",
        "phone": "+1 (512) 746-0102",
        "website": "https://www.acme.example/locations/austin",
    })
    assert lead["name"] == "Acme Med Spa"
    assert lead["phone_normalized"] == "5127460102"
    assert lead["website_domain"] == "acme.example"
    assert lead["fingerprint"]


def test_queue_and_evidence_contracts_are_durable():
    api = (ROOT / "app/api/prod/leads_api.py").read_text()
    persistence = (ROOT / "app/layers/persistence_layer.py").read_text()
    assert "threading.Thread" not in api
    assert 'max_attempts=3' in api
    assert '"value": item.get("value")' in persistence
    assert '"value_json"' not in persistence


def test_specialist_handoffs_expose_persisted_outputs():
    fabric = (ROOT / "app/integrations/prod/agent_fabric.py").read_text()
    assert "async def execute_specialized" in fabric
    assert "_persist_agent_handoff" in fabric
    assert '"persisted"' in fabric
