# LeadX QA — Login / Support / Runtime / Multi-user hardening

## Automated checks

- Backend Python compilation: PASS
- Backend pytest suite: PASS — 56 tests
- `/crm/me` route count: PASS — exactly one `GET /crm/me`
- Unauthenticated `GET /crm/me`: PASS — HTTP 401, proving the route is present and protected
- Support routes mounted: PASS — `/support/health`, conversations, messages, admin routes
- Realtime source audit: PASS — one tenant manager and one `postgres_changes` callback registration before `subscribe()`
- Frontend full TypeScript/build: NOT run because this packaged workspace intentionally has no `node_modules`; global `tsc` reports expected missing React/Next/Supabase modules. Install dependencies in Codespaces before `npm run build`.

## Runtime changes

1. `/crm/me` is now registered exactly once by the guaranteed application bootstrap.
2. Membership lookup is cached for 30s and protected against concurrent stampedes.
3. Sync Supabase operations are moved off the FastAPI event loop where the support path uses them; the API thread limiter is configurable and defaults to 64 per worker.
4. Support FAQ is cached for 60s; support storage/provider failures return a useful 503 rather than an opaque 500.
5. Browser GET requests use a 5s in-memory cache and in-flight request deduplication; mutations clear it.
6. First-login tenant metadata can skip the extra `/crm/me` bootstrap round-trip when provisioning supplies a trusted tenant id. Protected API calls still enforce membership.
7. Realtime uses one tenant channel manager and one callback, eliminating the callback-after-subscribe race seen in the screenshot.
8. Docker defaults to 4 workers and now exposes configurable keep-alive and concurrency limits.
