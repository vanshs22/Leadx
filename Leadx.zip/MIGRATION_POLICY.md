# LeadX migration policy — 2026-09-30

The **only canonical fresh-install / upgrade path for new deployments** is `supabase/migrations/` using Supabase CLI. It contains strictly ordered timestamped migrations and is checked in CI by `scripts/check_migrations.py`.

Current canonical chain:
- `20260930000000_leadx_baseline.sql` — complete LeadX baseline (derived from the idempotent all-in-one schema)
- `20260930000100_integration_deliveries.sql` — integration delivery idempotency/audit table

The older `sql/*.sql` files remain as compatibility/source material for existing deployments and historical documentation. Their duplicate numeric prefixes are **not** a valid new-install path. Do not introduce another numbered file under `sql/`; add a timestamped Supabase CLI migration instead.
