-- Run if board drag fails: lead_assignments_delivery_status_check
ALTER TABLE public.lead_assignments DROP CONSTRAINT IF EXISTS lead_assignments_delivery_status_check;
ALTER TABLE public.lead_assignments
  ADD CONSTRAINT lead_assignments_delivery_status_check
  CHECK (delivery_status IN ('pending','sent','failed','skipped','portal','delivered'));

UPDATE public.lead_assignments
SET delivery_status = 'sent'
WHERE lower(coalesce(delivery_status,'')) IN ('portal','delivered','');

ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;

NOTIFY pgrst, 'reload schema';
