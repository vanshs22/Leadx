#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
API_ENV="$ROOT/lead-engine-v2/.env"
WEB_ENV="$ROOT/lead-crm-portal/frontend/.env.local"
API_PORT="${API_PORT:-8000}"

if [ ! -f "$API_ENV" ]; then
  echo "Missing $API_ENV"
  exit 1
fi

SUPA_URL=$(grep -E '^SUPABASE_URL=' "$API_ENV" | head -1 | cut -d= -f2- | tr -d '\r' | sed 's/^["'\'']//;s/["'\'']$//' | xargs)
SUPA_ANON=$(grep -E '^SUPABASE_ANON_KEY=' "$API_ENV" | head -1 | cut -d= -f2- | tr -d '\r' | sed 's/^["'\'']//;s/["'\'']$//' | xargs)

if [ -z "$SUPA_URL" ] || [[ ! "$SUPA_URL" =~ ^https?:// ]]; then
  echo "ERROR: SUPABASE_URL in lead-engine-v2/.env must be like https://xxxx.supabase.co"
  echo "  current: [$SUPA_URL]"
  exit 1
fi
if [ -z "$SUPA_ANON" ]; then
  echo "ERROR: SUPABASE_ANON_KEY empty in lead-engine-v2/.env"
  exit 1
fi

cat > "$WEB_ENV" << EOF
# Auto-synced from lead-engine-v2/.env — restart Next after this
API_UPSTREAM=http://127.0.0.1:${API_PORT}
NEXT_PUBLIC_SUPABASE_URL=${SUPA_URL}
NEXT_PUBLIC_SUPABASE_ANON_KEY=${SUPA_ANON}
EOF

echo "Wrote $WEB_ENV"
echo "  URL=$SUPA_URL"
echo "Restart frontend (Ctrl+C npm/setup, then ./setup.sh) so Next picks up env."
