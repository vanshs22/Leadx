"""ENRICHMENT LAYER: free-first, field-level paid fallback enrichment."""
from __future__ import annotations
import asyncio
from app.integrations.prod.enricher import enrich_batch
from app.integrations.prod.enrichment_mesh import enrich_intelligent

async def enrich(leads: list[dict], *, max_concurrent: int = 5,
                 use_crawl4ai: bool = True, use_firecrawl: bool = True) -> list[dict]:
    if not leads:
        return []
    sem = asyncio.Semaphore(max(1, max_concurrent))

    async def one(lead: dict) -> dict:
        async with sem:
            try:
                mesh = await enrich_intelligent(dict(lead), use_crawl4ai=use_crawl4ai, paid_fallback=True)
                merged = dict(lead)
                merged.update(mesh.get("patch") or {})
                merged["enrichment_mesh_audit"] = mesh.get("audit") or {}
                merged["enrichment_providers_attempted"] = mesh.get("providers_attempted") or []
                merged["enrichment_credits_spent"] = mesh.get("credits_spent", 0.0)
                return merged
            except Exception:
                # Preserve the mature legacy enricher as a final local fallback.
                return dict(lead)

    mesh_rows = await asyncio.gather(*(one(x) for x in leads), return_exceptions=False)
    # Legacy enrichment remains available for fields the mesh could not fill.
    return await enrich_batch(mesh_rows, max_concurrent=max_concurrent,
                              use_crawl4ai=use_crawl4ai,
                              use_firecrawl=False)

async def enrich_for_pipeline(leads: list[dict], *, max_concurrent: int = 5,
                              use_crawl4ai: bool = True, use_firecrawl: bool = True) -> list[dict]:
    return await enrich(leads, max_concurrent=max_concurrent,
                        use_crawl4ai=use_crawl4ai, use_firecrawl=False)
