"""LeadX layer boundary package.

Discovery -> identity/persistence -> enrichment -> research -> scoring -> CRM/delivery.
Business logic imports layer contracts, never provider SDKs directly.
"""
