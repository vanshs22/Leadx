"""Small, provider-neutral operation telemetry helpers."""
from __future__ import annotations
from contextlib import asynccontextmanager
from time import monotonic
from typing import Any
import logging
logger=logging.getLogger("lead_engine.telemetry")

@asynccontextmanager
async def operation(layer: str, operation_name: str, *, tenant_id: str | None = None, provider: str | None = None):
    started=monotonic(); status="success"; error=None
    try:
        yield
    except Exception as exc:
        status="error"; error=str(exc)[:500]; raise
    finally:
        logger.info("operation layer=%s operation=%s provider=%s tenant=%s status=%s latency_ms=%.1f error=%s", layer, operation_name, provider, tenant_id, status, (monotonic()-started)*1000, error)
