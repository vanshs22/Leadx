"""
Simple in-memory + Redis rate limiter for expensive endpoints.
Protects /pipeline/run, /keys/add, enrichment triggers from abuse.
"""
from __future__ import annotations

import logging
import os
import time
from collections import defaultdict
from threading import Lock
from typing import Optional

from fastapi import HTTPException, Request, status

logger = logging.getLogger("lead_engine.rate_limit")
_ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()
_REQUIRE_DISTRIBUTED = os.getenv("REQUIRE_DISTRIBUTED_RATE_LIMIT", "").lower() in ("1", "true", "yes") or _ENVIRONMENT in ("production", "prod", "staging")

# defaults
PIPELINE_LIMIT = int(os.getenv("RATE_LIMIT_PIPELINE_PER_HOUR", "20"))
KEYS_LIMIT = int(os.getenv("RATE_LIMIT_KEYS_PER_HOUR", "10"))
API_LIMIT = int(os.getenv("RATE_LIMIT_API_PER_MINUTE", "120"))


class _MemoryWindow:
    def __init__(self):
        self._hits: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()
        self._last_purge = 0.0

    def hit(self, key: str, limit: int, window_seconds: int) -> tuple[bool, int]:
        now = time.time()
        cutoff = now - window_seconds
        with self._lock:
            # Bound memory: periodically drop keys with no recent hits.
            if now - self._last_purge > 60 or len(self._hits) > 50_000:
                self._last_purge = now
                for k in [k for k, v in self._hits.items() if not v or v[-1] < now - 3600]:
                    self._hits.pop(k, None)
            bucket = [t for t in self._hits[key] if t > cutoff]
            if len(bucket) >= limit:
                self._hits[key] = bucket
                return False, 0
            bucket.append(now)
            self._hits[key] = bucket
            return True, limit - len(bucket)


_memory = _MemoryWindow()
_REDIS = None
_REDIS_FAILED_UNTIL = 0.0
_ASYNC_REDIS = None
_ASYNC_REDIS_FAILED_UNTIL = 0.0


def _redis_client():
    global _REDIS, _REDIS_FAILED_UNTIL
    try:
        import redis
        url = os.getenv("REDIS_URL")
        if not url:
            return None
        now = time.monotonic()
        if now < _REDIS_FAILED_UNTIL:
            return None
        if _REDIS is not None:
            return _REDIS
        _REDIS = redis.from_url(
            url, decode_responses=True, socket_connect_timeout=0.5, socket_timeout=0.8,
            health_check_interval=30, max_connections=32,
        )
        return _REDIS
    except Exception:
        _REDIS_FAILED_UNTIL = time.monotonic() + 30
        return None


def check_rate_limit(
    identity: str,
    action: str,
    limit: int,
    window_seconds: int,
) -> None:
    """
    Raises 429 if over limit.
    identity: user_id or tenant_id or IP
    """
    key = f"rl:{action}:{identity}"

    r = _redis_client()
    if r:
        try:
            pipe = r.pipeline()
            pipe.incr(key)
            pipe.ttl(key)
            count, ttl = pipe.execute()
            if ttl == -1:
                r.expire(key, window_seconds)
            if int(count) > limit:
                raise HTTPException(
                    status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Rate limit exceeded for {action}. Try again later.",
                    headers={"Retry-After": str(max(ttl, 1))},
                )
            return
        except HTTPException:
            raise
        except Exception as e:
            logger.debug("Redis rate limit fallback to memory: %s", e)

    if _REQUIRE_DISTRIBUTED:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Distributed rate limiting is unavailable")
    ok, remaining = _memory.hit(key, limit, window_seconds)
    if not ok:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit exceeded for {action}. Try again later.",
            headers={"Retry-After": str(window_seconds)},
        )



_RATE_LIMIT_LUA = """
local n = redis.call('INCR', KEYS[1])
if n == 1 then redis.call('EXPIRE', KEYS[1], ARGV[1]) end
return {n, redis.call('TTL', KEYS[1])}
"""

async def check_rate_limit_async(identity: str, action: str, limit: int, window_seconds: int) -> None:
    """Non-blocking, atomic Redis limiter with bounded fallback.

    Redis failure is fail-open to avoid turning a dependency outage into a
    platform-wide outage. The process-local fallback remains only a secondary
    abuse guard and is intentionally not treated as a global quota.
    """
    global _ASYNC_REDIS, _ASYNC_REDIS_FAILED_UNTIL
    key = f"rl:{action}:{identity}"
    try:
        import redis.asyncio as redis_async
        now = time.monotonic()
        if now >= _ASYNC_REDIS_FAILED_UNTIL:
            if _ASYNC_REDIS is None and os.getenv("REDIS_URL"):
                _ASYNC_REDIS = redis_async.from_url(os.getenv("REDIS_URL"), decode_responses=True, socket_connect_timeout=0.5, socket_timeout=0.8, max_connections=64)
            if _ASYNC_REDIS is not None:
                result = await _ASYNC_REDIS.eval(_RATE_LIMIT_LUA, 1, key, window_seconds)
                count, ttl = int(result[0]), max(1, int(result[1]))
                if count > limit:
                    raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, detail=f"Rate limit exceeded for {action}. Try again later.", headers={"Retry-After": str(ttl)})
                return
    except HTTPException:
        raise
    except Exception as exc:
        _ASYNC_REDIS_FAILED_UNTIL = time.monotonic() + 15
        logger.debug("async Redis rate limit unavailable: %s", exc)
    if _REQUIRE_DISTRIBUTED:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Distributed rate limiting is unavailable")
    ok, _ = _memory.hit(key, limit, window_seconds)
    if not ok:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, detail=f"Rate limit exceeded for {action}. Try again later.", headers={"Retry-After": str(window_seconds)})

def rate_limit_pipeline(identity: str) -> None:
    check_rate_limit(identity, "pipeline_run", PIPELINE_LIMIT, 3600)


def rate_limit_keys(identity: str) -> None:
    check_rate_limit(identity, "keys_add", KEYS_LIMIT, 3600)


def rate_limit_api(identity: str) -> None:
    check_rate_limit(identity, "api", API_LIMIT, 60)


def client_ip(request: Request) -> str:
    """Best-effort client IP.

    X-Forwarded-For is attacker-controlled unless a trusted reverse proxy sets
    it, so it is only honoured when TRUST_PROXY_HEADERS=1. Otherwise the socket
    peer is used — an attacker can no longer dodge rate limits by rotating a
    spoofed header.
    """
    if os.getenv("TRUST_PROXY_HEADERS", "").lower() in ("1", "true", "yes"):
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            # The right-most entry was appended by OUR proxy; left-most is client-supplied.
            hops = [h.strip() for h in forwarded.split(",") if h.strip()]
            depth = max(1, int(os.getenv("TRUSTED_PROXY_HOPS", "1")))
            if hops:
                return hops[max(0, len(hops) - depth)]
    return request.client.host if request.client else "unknown"
