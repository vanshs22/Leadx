"""LeadX 7.0 contact verification mesh.

Verification is deliberately ordered by economics and evidence strength:
1) free/local/open-source checks
2) providers with free monthly tiers
3) paid-only providers

A provider is only called when configured/enabled. Results are normalized into
field-level observations; the caller can persist them in lead_verification_observations.
"""
from __future__ import annotations
import os, re
from typing import Any
from urllib.parse import quote_plus
import httpx

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PUBLIC_FREE = False  # No customer PII is sent to an unaudited public verifier.

# Tier 0 = local/open-source/no-key. Tier 1 = free plan/free credits. Tier 2 = paid-only fallback.
EMAIL_PROVIDERS = (
    {"name":"local_dns_disposable", "tier":0, "mode":"free", "env_key":None, "capabilities":["syntax","mx","disposable"]},
    {"name":"self_hosted_email_validator", "tier":0, "mode":"free_self_hosted", "env_key":"LEADX_EMAIL_VALIDATOR_URL", "capabilities":["syntax","mx","smtp","disposable"]},
    {"name":"hunter", "tier":1, "mode":"free_plan_or_paid", "env_key":"HUNTER_API_KEY", "capabilities":["deliverability","score","status"]},
    {"name":"zerobounce", "tier":1, "mode":"free_plan_or_paid", "env_key":"ZEROBOUNCE_API_KEY", "capabilities":["deliverability","disposable","trap","risk","status"]},
    {"name":"abstract", "tier":1, "mode":"free_plan_or_paid", "env_key":"ABSTRACT_API_KEY", "capabilities":["smtp","mx","disposable","catch_all","quality"]},
    {"name":"neverbounce", "tier":2, "mode":"paid", "env_key":"NEVERBOUNCE_API_KEY", "capabilities":["deliverability","status"]},
    {"name":"bouncer", "tier":2, "mode":"paid", "env_key":"BOUNCER_API_KEY", "capabilities":["deliverability","risk","status"]},
    {"name":"kickbox", "tier":2, "mode":"paid", "env_key":"KICKBOX_API_KEY", "capabilities":["deliverability","status"]},
)

PHONE_PROVIDERS = (
    {"name":"libphonenumber_local", "tier":0, "mode":"free_local", "env_key":None, "capabilities":["format","country","type","possible"]},
    {"name":"randomapi_libphonenumber", "tier":0, "mode":"free_public", "env_key":None, "capabilities":["validation","country","type","e164"]},
    {"name":"phonevalidationapi", "tier":0, "mode":"free_plan", "env_key":"PHONEVALIDATIONAPI_KEY", "capabilities":["validation","confidence","carrier","line_type","disposable"]},
    {"name":"numbers_online", "tier":0, "mode":"free_plan", "env_key":"NUMBERS_ONLINE_API_KEY", "capabilities":["carrier","line_type","caller_name","risk"]},
    {"name":"twilio_lookup", "tier":1, "mode":"free_basic_paid_data", "env_key":"TWILIO_AUTH_TOKEN", "capabilities":["validation","line_type","carrier","risk"]},
    {"name":"veriphone", "tier":1, "mode":"free_plan_or_paid", "env_key":"VERIPHONE_API_KEY", "capabilities":["validation","carrier","line_type","location"]},
    {"name":"abstract", "tier":1, "mode":"free_plan_or_paid", "env_key":"ABSTRACT_API_KEY", "capabilities":["validation","carrier","line_type","location","risk"]},
    {"name":"numverify", "tier":1, "mode":"free_plan_or_paid", "env_key":"NUMVERIFY_API_KEY", "capabilities":["validation","carrier","line_type","location"]},
    {"name":"ipqs", "tier":2, "mode":"paid_or_trial", "env_key":"IPQS_API_KEY", "capabilities":["validation","carrier","line_type","fraud_risk"]},
)


def _env_enabled(name: str) -> bool:
    return bool(name and os.getenv(name))


def email_local_check(email: str) -> dict[str, Any]:
    e=(email or '').strip().lower()
    out={"provider":"local_dns_disposable","email":e,"syntax_valid":bool(EMAIL_RE.match(e)),"mx_found":None,"disposable":None,"status":"unknown","tier":0}
    if not out["syntax_valid"]:
        out["status"]="invalid"; return out
    domain=e.rsplit('@',1)[1]
    # Small high-signal disposable list; deployments can replace/extend through a self-hosted validator.
    common_disposable={"mailinator.com","guerrillamail.com","10minutemail.com","tempmail.com","yopmail.com","temp-mail.org","trashmail.com"}
    out["disposable"] = domain in common_disposable
    try:
        import dns.resolver
        dns.resolver.resolve(domain,'MX'); out["mx_found"]=True
        out["status"]="invalid" if out["disposable"] else "syntax_mx_valid"
    except Exception:
        out["mx_found"]=False; out["status"]="invalid" if out["disposable"] else "no_mx_or_unresolved"
    return out


async def _get_json(url: str, **kwargs) -> dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=20, follow_redirects=False) as c:
            r=await c.get(url, **kwargs)
            if r.status_code >= 400: return {"_http_status":r.status_code}
            return r.json()
    except Exception as exc:
        return {"_error":type(exc).__name__}


async def verify_email(email: str, providers: list[str] | None = None) -> dict[str, Any]:
    """Production free-first cascade: local -> free-plan -> paid fallback."""
    base=email_local_check(email); e=base["email"]
    if base["status"] == "invalid":
        return {"ok":True,"canonical":{**base,"confidence":100},"observations":[base]}
    observations=[base]; explicit=bool(providers)
    order=[x["name"] for x in EMAIL_PROVIDERS]; requested=set(providers or order) & set(order)
    def decisive(obs):
        st=str(obs.get("status") or "unknown").lower()
        if st in {"invalid","undeliverable","do_not_mail","spamtrap","disposable"}: obs["confidence"]=95; return True
        if st in {"valid","deliverable"}: obs["confidence"]=float(obs.get("score") or obs.get("quality_score") or 90); return obs["confidence"]>=85
        return False
    async def maybe_return(obs):
        observations.append(obs)
        return decisive(obs) and not explicit
    if "self_hosted_email_validator" in requested and os.getenv("LEADX_EMAIL_VALIDATOR_URL"):
        try:
            d=await _get_json(os.getenv("LEADX_EMAIL_VALIDATOR_URL"),params={"email":e})
            if "_error" not in d and "_http_status" not in d:
                o={"provider":"self_hosted_email_validator","tier":0,"status":str(d.get("status","unknown")).lower(),"smtp":d.get("smtp_valid"),"mx":d.get("mx_valid")}
                if await maybe_return(o): return _canonical_email(e,observations)
        except Exception as exc: __import__("logging").getLogger(__name__).debug("suppressed optional failure: %s", exc)
    async with httpx.AsyncClient(timeout=30,follow_redirects=False) as c:
        for name in ("hunter","zerobounce","abstract"):
            if name not in requested: continue
            key=next((x["env_key"] for x in EMAIL_PROVIDERS if x["name"]==name),None)
            if key and not os.getenv(key): continue
            try:
                if name=="hunter":
                    d=(await c.get('https://api.hunter.io/v2/email-verifier',params={'email':e,'api_key':os.getenv('HUNTER_API_KEY')})).json().get('data',{}); o={"provider":name,"tier":1,"status":str(d.get('status','unknown')).lower(),"score":d.get('score')}
                elif name=="zerobounce":
                    d=(await c.get('https://api.zerobounce.net/v2/validate',params={'email':e,'api_key':os.getenv('ZEROBOUNCE_API_KEY')})).json(); o={"provider":name,"tier":1,"status":str(d.get('status','unknown')).lower(),"sub_status":d.get('sub_status'),"disposable":d.get('disposable')}
                else:
                    d=(await c.get('https://emailvalidation.abstractapi.com/v1/',params={'api_key':os.getenv('ABSTRACT_API_KEY'),'email':e})).json(); o={"provider":name,"tier":1,"status":"valid" if d.get('is_valid_format',{}).get('value') and d.get('is_smtp_valid',{}).get('value') else "unknown","deliverability":d.get('deliverability'),"quality_score":d.get('quality_score')}
                if await maybe_return(o): return _canonical_email(e,observations)
            except Exception: continue
        for name in ("neverbounce","bouncer","kickbox"):
            if name not in requested: continue
            key=next((x["env_key"] for x in EMAIL_PROVIDERS if x["name"]==name),None)
            if key and not os.getenv(key): continue
            try:
                if name=="neverbounce":
                    d=(await c.get('https://api.neverbounce.com/v4/single/check',params={'key':os.getenv('NEVERBOUNCE_API_KEY'),'email':e})).json(); o={"provider":name,"tier":2,"status":str(d.get('result','unknown')).lower(),"flags":d.get('flags')}
                elif name=="bouncer":
                    d=(await c.get('https://api.usebouncer.com/v1.1/email/verify',params={'key':os.getenv('BOUNCER_API_KEY'),'email':e})).json(); o={"provider":name,"tier":2,"status":str(d.get('status','unknown')).lower(),"reason":d.get('reason'),"score":d.get('score')}
                else:
                    d=(await c.get('https://api.kickbox.com/v2/verify',params={'apikey':os.getenv('KICKBOX_API_KEY'),'email':e})).json(); o={"provider":name,"tier":2,"status":str(d.get('result','unknown')).lower(),"reason":d.get('reason'),"sendex":d.get('sendex')}
                if await maybe_return(o): return _canonical_email(e,observations)
            except Exception: continue
    return _canonical_email(e,observations)


def _canonical_email(e, observations):
    statuses=[str(x.get('status','')).lower() for x in observations]
    invalid=sum(s in {'invalid','undeliverable','do_not_mail','disposable','spamtrap'} for s in statuses); valid=sum(s in {'valid','deliverable'} for s in statuses)
    canonical='invalid' if invalid and invalid>=valid else 'valid' if valid else 'unknown'
    return {"ok":True,"canonical":{"email":e,"status":canonical,"confidence":95 if canonical!='unknown' else 50,"providers":len(observations),"tier_order":"free->free_plan->paid"},"observations":observations}


async def _phone_randomapi(p: str, country_code: str | None) -> dict[str, Any] | None:
    if not PUBLIC_FREE:
        return None
    params={"value":p}
    if country_code: params["country"]=country_code
    d=await _get_json("https://randomapi.dev/api/phone-numbers/parse", params=params)
    if "_http_status" in d or "_error" in d: return None
    d=d.get("data",d)
    return {"provider":"randomapi_libphonenumber","tier":0,"status":"valid" if d.get("isValid") else "invalid","possible":d.get("isPossible"),"line_type":d.get("numberType"),"e164":d.get("e164"),"country":d.get("region")}


async def verify_phone(phone: str, country_code: str | None = None, providers: list[str] | None = None) -> dict[str, Any]:
    """Production free-first phone cascade; paid risk lookup is last resort."""
    p=(phone or '').strip(); digits=re.sub(r'\D','',p); base={"provider":"libphonenumber_local","phone":p,"shape_valid":len(digits)>=7,"status":"unknown","tier":0}
    if not base['shape_valid']:
        base['status']='invalid'; return {"ok":True,"canonical":{**base,"confidence":100},"observations":[base]}
    observations=[base]; explicit=bool(providers); requested=set(providers or [x["name"] for x in PHONE_PROVIDERS]) & {x["name"] for x in PHONE_PROVIDERS}
    def decisive(o):
        st=str(o.get('status') or '').lower()
        if st=='invalid': o['confidence']=95; return True
        if st=='valid': o['confidence']=float(o.get('confidence') or 90); return o['confidence']>=85
        return False
    if "randomapi_libphonenumber" in requested and PUBLIC_FREE:
        o=await _phone_randomapi(p,country_code)
        if o: observations.append(o)  # possible/valid shape; not reachability proof
    async with httpx.AsyncClient(timeout=25,follow_redirects=False) as c:
        for name in ("phonevalidationapi","numbers_online","twilio_lookup","veriphone","abstract","numverify"):
            if name not in requested: continue
            key=next((x["env_key"] for x in PHONE_PROVIDERS if x["name"]==name),None)
            if key and not os.getenv(key): continue
            try:
                if name=="phonevalidationapi":
                    d=(await c.post('https://phonevalidationapi.com/api/v1/validate',headers={'Authorization':f'Bearer {os.getenv("PHONEVALIDATIONAPI_KEY")}'},json={'phone':p,'country':country_code})).json(); o={'provider':name,'tier':0,'status':'valid' if d.get('valid') else 'invalid','confidence':d.get('confidence'),'line_type':d.get('line_type'),'carrier':d.get('carrier')}
                elif name=="numbers_online":
                    d=(await c.get(os.getenv('NUMBERS_ONLINE_LOOKUP_URL') or 'https://numbers.online/api/lookup',params={'number':p,'api_key':os.getenv('NUMBERS_ONLINE_API_KEY')})).json(); o={'provider':name,'tier':0,'status':'valid' if d.get('valid',True) else 'invalid','line_type':d.get('line_type'),'carrier':d.get('carrier'),'risk':d.get('risk')}
                elif name=="twilio_lookup":
                    auth=(os.getenv('TWILIO_ACCOUNT_SID'),os.getenv('TWILIO_AUTH_TOKEN')); params={'CountryCode':country_code} if country_code else {}; d=(await c.get('https://lookups.twilio.com/v2/PhoneNumbers/'+quote_plus(p),params=params,auth=auth)).json(); li=d.get('line_type_intelligence') or {}; o={'provider':name,'tier':1,'status':'valid' if d.get('valid',True) else 'invalid','line_type':li.get('type'),'carrier':li.get('carrier_name'),'phone_number':d.get('phone_number')}
                elif name=="veriphone":
                    d=(await c.get('https://api.veriphone.io/v3/verify',params={'phone':p,'key':os.getenv('VERIPHONE_API_KEY')})).json(); o={'provider':name,'tier':1,'status':'valid' if d.get('phone_valid') else 'invalid','line_type':d.get('phone_type'),'carrier':d.get('carrier'),'country':d.get('country')}
                elif name=="abstract":
                    d=(await c.get('https://phonevalidation.abstractapi.com/v1/',params={'api_key':os.getenv('ABSTRACT_API_KEY'),'phone':digits})).json(); o={'provider':name,'tier':1,'status':'valid' if d.get('valid') else 'invalid','line_type':d.get('line_type'),'carrier':d.get('carrier'),'risk_score':d.get('risk_score')}
                else:
                    d=(await c.get('http://apilayer.net/api/validate',params={'access_key':os.getenv('NUMVERIFY_API_KEY'),'number':p,'country_code':country_code or ''})).json(); o={'provider':name,'tier':1,'status':'valid' if d.get('valid') else 'invalid','line_type':d.get('line_type'),'carrier':d.get('carrier'),'country':d.get('country_name')}
                observations.append(o)
                if decisive(o) and not explicit: return _canonical_phone(p,observations)
            except Exception: continue
        if "ipqs" in requested and os.getenv('IPQS_API_KEY'):
            try:
                d=(await c.get(f'https://ipqualityscore.com/api/json/phone/{os.getenv("IPQS_API_KEY")}/{quote_plus(p)}')).json(); o={'provider':'ipqs','tier':2,'status':'valid' if d.get('valid') else 'invalid','line_type':d.get('line_type'),'carrier':d.get('carrier'),'fraud_score':d.get('fraud_score'),'active':d.get('active')}; observations.append(o)
            except Exception as exc: __import__("logging").getLogger(__name__).debug("suppressed optional failure: %s", exc)
    return _canonical_phone(p,observations)


def _canonical_phone(p, observations):
    statuses=[str(x.get('status','')).lower() for x in observations]; invalid=sum(s=='invalid' for s in statuses); valid=sum(s=='valid' for s in statuses)
    canonical='invalid' if invalid and invalid>=valid else 'valid' if valid else 'shape_valid'
    return {'ok':True,'canonical':{'phone':p,'status':canonical,'confidence':95 if canonical in {'valid','invalid'} else 55,'providers':len(observations),'tier_order':'free->free_plan->paid'},'observations':observations}


def verification_catalog() -> dict[str,list[dict]]:
    return {'email':EMAIL_PROVIDERS,'phone':PHONE_PROVIDERS}
