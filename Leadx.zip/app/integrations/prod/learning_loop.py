"""Closed-loop learning: turn outcomes into explainable tenant guidance, never blind self-modification."""
from __future__ import annotations
from app.services.aio import aexec
from collections import Counter
from datetime import datetime, timezone
from app.memory.supabase_client import get_supabase
from app.integrations.prod.feedback import tenant_score_weights, lookalike_queries

async def learning_snapshot(tenant_id: str) -> dict:
    weights = await tenant_score_weights(tenant_id)
    queries = await lookalike_queries(tenant_id, 8)
    shadow = await refresh_vertical_shadow(tenant_id)
    sb = get_supabase()
    try:
        outcomes = (await aexec(sb.table("lead_outcomes").select("outcome").eq("tenant_id", tenant_id).limit(2000))).data or []
    except Exception: outcomes = []
    won = sum(1 for x in outcomes if x.get("outcome") == "won"); lost = sum(1 for x in outcomes if x.get("outcome") == "lost")
    snapshot = {"tenant_id":tenant_id,"outcomes":len(outcomes),"won":won,"lost":lost,"win_rate_pct":round(won/(won+lost)*100,2) if won+lost else 0,"weights":weights,"lookalike_queries":queries,"shadow_learning":shadow,"model_version":"leadx-learning-v2-shadow","created_at":datetime.now(timezone.utc).isoformat()}
    try: (await aexec(sb.table("learning_snapshots").insert(snapshot)))
    except Exception as exc: __import__("logging").getLogger(__name__).debug("suppressed optional failure: %s", exc)
    return snapshot

async def refresh_vertical_shadow(tenant_id: str) -> dict:
    """Compute per-vertical win/loss/booked weight changes in shadow mode.

    Proposed weights are persisted but never applied to production scoring until
    an explicit promotion step exists. Lift is an association lift versus the
    current baseline, reported to the Learning Agent.
    """
    sb=get_supabase()
    try:
        icps=(await aexec(sb.table("icp_profiles").select("vertical").eq("tenant_id",tenant_id).limit(1))).data or []
        vertical=str((icps[0].get("vertical") if icps else "") or "general").lower().strip() or "general"
    except Exception: vertical="general"
    try:
        rows=(await aexec(sb.table("lead_outcomes").select("outcome,lead_id,features").eq("tenant_id",tenant_id).limit(2000))).data or []
    except Exception: rows=[]
    try:
        booked=(await aexec(sb.table("lead_outcome_events").select("outcome,lead_id").eq("tenant_id",tenant_id).eq("outcome","booked").limit(2000))).data or []
    except Exception: booked=[]
    booked_ids={str(r.get("lead_id")) for r in booked}
    features=(r.get("features") or {} for r in rows)
    feature_names={"email":lambda f:bool(f.get("has_email")),"booking":lambda f:bool(f.get("has_booking")),"reviews":lambda f:(f.get("reviews") or 0)>=20,"owner":lambda f:bool(f.get("has_owner")),"rating_high":lambda f:(f.get("rating") or 0)>=4.5}
    wins=[r for r in rows if r.get("outcome")=="won"]; losses=[r for r in rows if r.get("outcome")=="lost"]
    proposed={}; lifts={}
    for feature,pred in feature_names.items():
        wr=sum(1 for r in wins if pred(r.get("features") or {}))/len(wins) if wins else 0
        lr=sum(1 for r in losses if pred(r.get("features") or {}))/len(losses) if losses else 0
        booked_rate=sum(1 for r in rows if str(r.get("lead_id")) in booked_ids and pred(r.get("features") or {}))/len(booked) if booked else 0
        association=(wr*0.6 + booked_rate*0.2 + (1-lr)*0.2)
        weight=max(0.5,min(1.5,0.75+association))
        lift=round((weight-1.0)*100,2)
        proposed[feature]=round(weight,4); lifts[feature]=lift
        try:
            await aexec(sb.table("vertical_score_shadow_weights").upsert({"vertical":vertical,"feature":feature,"baseline_weight":1.0,"proposed_weight":weight,"sample_size":len(rows),"mode":"shadow","lift":lift,"calculated_at":datetime.now(timezone.utc).isoformat()},on_conflict="vertical,feature"))
        except Exception as exc: __import__("logging").getLogger(__name__).debug("suppressed optional failure: %s", exc)
    return {"vertical":vertical,"mode":"shadow","sample_size":len(rows),"won":len(wins),"lost":len(losses),"booked":len(booked),"proposed_weights":proposed,"lift_pct":lifts}
