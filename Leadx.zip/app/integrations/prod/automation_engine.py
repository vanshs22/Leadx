"""LeadX 9.0 event-driven automation engine.

Durable events are queued in Postgres and processed asynchronously by workers.
Workflow graphs are intentionally bounded: conditions + explicit actions only;
no arbitrary code execution and no unbounded recursion.
"""
from __future__ import annotations
import os, socket
from datetime import datetime, timezone, timedelta
from typing import Any
from app.services.aio import aexec, offload
from app.memory.supabase_client import get_supabase

WORKER = f"automation:{socket.gethostname()}:{os.getpid()}"
ALLOWED_ACTIONS = {"send_email","enroll_sequence","stop_sequence","create_task","notify_owner","create_deal","update_lead","escalate_owner","score_reply"}

def _sb(): return get_supabase()

def enqueue_event(tenant_id: str, event_type: str, subject_type: str, subject_id: str|None, payload: dict, key: str) -> str|None:
    try:
        r = _sb().rpc("enqueue_automation_event", {"p_tenant_id":tenant_id,"p_event_type":event_type,"p_subject_type":subject_type,"p_subject_id":subject_id,"p_payload":payload or {},"p_idempotency_key":key}).execute()
        return str(r.data) if r.data else None
    except Exception:
        return None

def _match(trigger: dict, event: dict) -> bool:
    if trigger.get("event") and trigger.get("event") != event.get("event_type"): return False
    conditions = trigger.get("conditions") or []
    payload = event.get("payload") or {}
    for c in conditions:
        field, op, expected = c.get("field"), c.get("op","eq"), c.get("value")
        actual = payload.get(field)
        if op == "eq" and actual != expected: return False
        if op == "neq" and actual == expected: return False
        if op == "gte" and float(actual or 0) < float(expected): return False
        if op == "lte" and float(actual or 0) > float(expected): return False
        if op == "contains" and str(expected).lower() not in str(actual or "").lower(): return False
    return True

async def _action(tenant_id: str, action: dict, event: dict) -> dict:
    kind = action.get("type")
    if kind not in ALLOWED_ACTIONS: return {"ok":False,"error":"unsupported_action"}
    p = {**(event.get("payload") or {}), **(action.get("params") or {})}
    sb = _sb()
    if kind == "score_reply": return {"ok":True,"score":p.get("reply_score",0)}
    if kind == "notify_owner":
        from app.integrations.prod.unsubscribe import notify_tenant
        await notify_tenant(tenant_id, str(p.get("message") or "LeadX automation notification"))
        return {"ok":True}
    if kind == "create_task":
        row = {"tenant_id":tenant_id,"title":str(p.get("title") or "Follow up with lead"),"description":str(p.get("description") or "Created by LeadX automation"),"priority":str(p.get("priority") or "high"),"status":"open","assigned_to":p.get("owner")}
        if p.get("deal_id"): row["deal_id"]=p["deal_id"]
        out=(await aexec(sb.table("tasks").insert(row))).data or []
        return {"ok":True,"task_id":out[0].get("id") if out else None}
    if kind == "create_deal":
        aid=p.get("assignment_id")
        if not aid: return {"ok":False,"error":"assignment_required"}
        existing=(await aexec(sb.table("deals").select("id").eq("tenant_id",tenant_id).eq("source_assignment_id",aid).limit(1))).data or []
        if existing: return {"ok":True,"deal_id":existing[0]["id"],"existing":True}
        a=(await aexec(sb.table("lead_assignments").select("lead_id,assigned_to,value_estimate").eq("id",aid).eq("tenant_id",tenant_id).limit(1))).data or []
        if not a: return {"ok":False,"error":"assignment_not_found"}
        lead=(await aexec(sb.table("leads_global").select("name").eq("id",a[0]["lead_id"]).limit(1))).data or []
        title=f"{(lead[0].get('name') if lead else 'New lead')} opportunity"
        stages=(await aexec(sb.table("deal_stages").select("id").eq("tenant_id",tenant_id).eq("is_won",False).eq("is_lost",False).order("position").limit(1))).data or []
        row={"tenant_id":tenant_id,"title":title[:200],"status":"open","source":"leadx_automation","source_assignment_id":aid,"owner":a[0].get("assigned_to"),"value":a[0].get("value_estimate")}
        if stages: row["stage_id"]=stages[0]["id"]
        out=(await aexec(sb.table("deals").insert(row))).data or []
        return {"ok":True,"deal_id":out[0].get("id") if out else None}
    if kind == "escalate_owner":
        deal = await _action(tenant_id,{"type":"create_deal","params":p},event)
        task = await _action(tenant_id,{"type":"create_task","params":{**p,"deal_id":deal.get("deal_id"),"priority":"urgent","title":p.get("title") or "Hot reply — owner action required"}},event)
        return {"ok":True,"deal":deal,"task":task}
    if kind == "enroll_sequence":
        from app.integrations.prod.sequences import enroll_leads
        return await enroll_leads(tenant_id,str(p.get("sequence_id")),[str(p["assignment_id"])],ai_copy_enabled=bool(p.get("ai_copy_enabled",False)))
    if kind == "stop_sequence":
        q=sb.table("email_sequence_enrollments").update({"status":"stopped_automation","locked_at":None,"locked_by":None}).eq("tenant_id",tenant_id).eq("assignment_id",p.get("assignment_id")).in_("status",["active","sending"])
        return {"ok":bool((await aexec(q)).data is not None)}
    if kind == "update_lead":
        allowed={"lead_state","priority_score","lead_value_score","risk_score","gate_decision"}
        patch={k:v for k,v in (action.get("params") or {}).items() if k in allowed}
        if not patch or not p.get("lead_id"): return {"ok":False,"error":"safe_lead_patch_required"}
        # leads_global is intentionally shared across tenants. Prove tenant ownership
        # through lead_assignments before mutating the global entity.
        owned = (await aexec(
            sb.table("lead_assignments").select("id,lead_id").eq("tenant_id",tenant_id).eq("lead_id",p["lead_id"]).limit(1)
        )).data or []
        if not owned:
            return {"ok":False,"error":"lead_not_assigned_to_tenant"}
        out=(await aexec(sb.table("leads_global").update(patch).eq("id",p["lead_id"]).limit(1))).data or []
        return {"ok":bool(out),"error":None if out else "lead_not_found"}
    if kind == "send_email":
        from app.integrations.prod.email_outreach import send_to_lead
        if not p.get("assignment_id"): return {"ok":False,"error":"assignment_required"}
        return await send_to_lead(tenant_id,p["assignment_id"],str(p.get("subject") or ""),str(p.get("body_html") or ""),str(p.get("body_text") or ""),reply_to=p.get("reply_to"))
    return {"ok":False,"error":"unhandled_action"}

async def process_events(limit: int = 100) -> dict:
    limit=max(1,min(int(limit or 100),500))
    rows=(await aexec(_sb().table("automation_events").select("*").eq("status","queued").lte("available_at",datetime.now(timezone.utc).isoformat()).order("created_at").limit(limit))).data or []
    processed=0; matched=0; failed=0
    for event in rows:
        claimed=(await aexec(_sb().table("automation_events").update({"status":"processing","locked_at":datetime.now(timezone.utc).isoformat(),"locked_by":WORKER,"attempts":int(event.get("attempts") or 0)+1}).eq("id",event["id"]).eq("status","queued"))).data or []
        if not claimed: continue
        try:
            workflows=(await aexec(_sb().table("workflow_definitions").select("*").eq("tenant_id",event["tenant_id"]).eq("enabled",True).eq("trigger_type",event["event_type"]).limit(100))).data or []
            for wf in workflows:
                graph=wf.get("graph") or {}
                trigger=graph.get("trigger") or {"event":event["event_type"],"conditions":graph.get("conditions") or []}
                if not _match(trigger,event): continue
                matched+=1
                idem=f"{wf['id']}:{event['id']}"
                # Idempotency is enforced before executing actions. An upsert alone
                # can return an already-completed row and accidentally replay every
                # action on a retry/reconnect.
                existing=(await aexec(_sb().table("workflow_runs").select("id,status").eq("workflow_id",wf["id"]).eq("idempotency_key",idem).limit(1))).data or []
                if existing and existing[0].get("status") == "completed":
                    continue
                if existing and existing[0].get("status") in {"running","processing"}:
                    continue
                if existing:
                    run_id=existing[0]["id"]
                    await aexec(_sb().table("workflow_runs").update({"status":"running","event_id":event["id"],"context":event.get("payload") or {},"current_node":"start","error":None}).eq("id",run_id))
                else:
                    run=(await aexec(_sb().table("workflow_runs").insert({"workflow_id":wf["id"],"tenant_id":event["tenant_id"],"event_id":event["id"],"idempotency_key":idem,"status":"running","context":event.get("payload") or {},"current_node":"start"}))).data or []
                    if not run: continue
                    run_id=run[0]["id"]
                # Per-workflow concurrency/cooldown guard. These are soft guards;
                # the durable idempotency key remains the hard duplicate boundary.
                max_concurrency=max(1,min(int(wf.get("max_concurrency") or 10),100))
                active=(await aexec(_sb().table("workflow_runs").select("id",count="exact").eq("workflow_id",wf["id"]).in_("status",["running","processing"]))).count or 0
                if active > max_concurrency:
                    await aexec(_sb().table("workflow_runs").update({"status":"queued","current_node":"waiting_for_capacity"}).eq("id",run_id))
                    continue
                cooldown=max(0,int(wf.get("cooldown_seconds") or 0))
                if cooldown:
                    cutoff=(datetime.now(timezone.utc)-timedelta(seconds=cooldown)).isoformat()
                    recent=(await aexec(_sb().table("workflow_runs").select("id").eq("workflow_id",wf["id"]).gte("created_at",cutoff).neq("id",run_id).limit(1))).data or []
                    if recent:
                        await aexec(_sb().table("workflow_runs").update({"status":"queued","current_node":"cooldown"}).eq("id",run_id))
                        continue
                for action in (graph.get("actions") or [])[:25]:
                    res=await _action(event["tenant_id"],action,event)
                    if not res.get("ok") and action.get("required",True): raise RuntimeError(res.get("error") or "automation_action_failed")
                await aexec(_sb().table("workflow_runs").update({"status":"completed","current_node":"done","completed_at":datetime.now(timezone.utc).isoformat()}).eq("id",run_id))
            await aexec(_sb().table("automation_events").update({"status":"done","processed_at":datetime.now(timezone.utc).isoformat(),"locked_at":None,"locked_by":None}).eq("id",event["id"]))
            processed+=1
        except Exception as exc:
            failed+=1
            attempts=int(event.get("attempts") or 0)+1
            status="failed" if attempts>=5 else "queued"
            await aexec(_sb().table("automation_events").update({"status":status,"error":str(exc)[:1000],"available_at":(datetime.now(timezone.utc)+timedelta(minutes=min(60,2**attempts))).isoformat(),"locked_at":None,"locked_by":None}).eq("id",event["id"]))
    return {"ok":True,"processed":processed,"matched":matched,"failed":failed,"scanned":len(rows)}
