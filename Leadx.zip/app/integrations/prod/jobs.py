"""
Job queue — the piece that makes "many tenants at once" actually true.

Long work (pipeline runs, bulk sends, sequence processing, CSV import)
no longer executes inside the HTTP request. The API calls enqueue() and
returns a job id; a separate worker process (backend/worker.py) claims
and runs it. One tenant's statewide pipeline run can't freeze another
tenant's page load, and a crashed run is retried instead of lost.

Broker is Postgres (the `jobs` table), not Redis: Supabase is already a
hard dependency, so this needs no new infra to deploy, and the job rows
double as the admin job monitor's data source. Claiming is a
compare-and-swap on `status` (supabase-py can't express SELECT ... FOR
UPDATE SKIP LOCKED), which is safe for any number of workers — a lost
race just means the worker tries the next candidate.

Handlers live in job_handlers.py and register themselves with
@register("kind").
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable, Optional
from uuid import uuid4

from app.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.jobs")

# kind -> async handler(payload) -> dict
HANDLERS: dict[str, Callable[[dict], Awaitable[dict]]] = {}

# How long a job may sit in `running` before a worker is presumed dead.
STALE_LOCK_MINUTES = int(os.getenv("JOB_STALE_LOCK_MINUTES", "45"))
# Backoff between retries (doubles per attempt).
RETRY_BASE_SECONDS = int(os.getenv("JOB_RETRY_BASE_SECONDS", "60"))
FAIL_CLOSED = os.getenv("JOB_QUEUE_FAIL_CLOSED", "true").lower() not in {"0", "false", "no"}

TERMINAL = ("done", "failed", "cancelled")


def register(kind: str):
    """Decorator: @register("pipeline.run") on an async fn(payload)->dict."""

    def _wrap(fn: Callable[[dict], Awaitable[dict]]):
        HANDLERS[kind] = fn
        return fn

    return _wrap


def _sb():
    return get_supabase()


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------- enqueue


def enqueue(
    kind: str,
    payload: Optional[dict] = None,
    *,
    tenant_id: Optional[str] = None,
    priority: int = 0,
    delay_seconds: int = 0,
    max_attempts: int = 3,
    created_by: str = "api",
    job_id: Optional[str] = None,
) -> str:
    """Insert a queued job and return its id. Never raises — a queue
    insert failing must not 500 the caller's request; it returns the id
    it would have used and logs loudly so the admin job monitor shows a
    gap rather than the user seeing an error."""
    jid = job_id or str(uuid4())
    run_after = _now() + timedelta(seconds=max(0, delay_seconds))
    row = {
        "id": jid,
        "tenant_id": tenant_id,
        "kind": kind,
        "payload": payload or {},
        "status": "queued",
        "priority": priority,
        "attempts": 0,
        "max_attempts": max_attempts,
        "run_after": run_after.isoformat(),
        "created_by": created_by,
    }
    try:
        _sb().table("jobs").insert(row).execute()
    except Exception as exc:
        logger.exception("enqueue failed kind=%s tenant=%s", kind, tenant_id)
        if FAIL_CLOSED:
            raise RuntimeError("Durable job queue unavailable; refusing to run work outside the queue") from exc
    return jid


def enqueue_unique(kind: str, payload: Optional[dict] = None, **kw) -> Optional[str]:
    """Atomically enqueue an active unique job. The DB partial unique index is
    the concurrency authority; the old check-then-insert race is gone."""
    tenant_id = kw.get("tenant_id")
    jid = kw.pop("job_id", None) or str(uuid4())
    row = {
        "id": jid, "tenant_id": tenant_id, "kind": kind, "payload": payload or {},
        "status": "queued", "priority": kw.get("priority", 0), "attempts": 0,
        "max_attempts": kw.get("max_attempts", 3),
        "run_after": (_now() + timedelta(seconds=max(0, kw.get("delay_seconds", 0)))).isoformat(),
        "created_by": kw.get("created_by", "api"),
    }
    try:
        data = _sb().table("jobs").insert(row).execute().data or []
        return data[0].get("id", jid) if data else jid
    except Exception as exc:
        # Unique violation means another worker won the race. Other failures
        # obey the normal queue fail-closed policy.
        msg = str(exc).lower()
        if "unique" in msg or "duplicate" in msg or "23505" in msg:
            return None
        logger.exception("enqueue_unique failed kind=%s tenant=%s", kind, tenant_id)
        if FAIL_CLOSED: raise RuntimeError("Durable job queue unavailable") from exc
        return None


# ---------------------------------------------------------------- claim / finish


def claim_next(worker_id: str, kinds: Optional[list[str]] = None) -> Optional[dict]:
    """Claim exactly one due job using Postgres FOR UPDATE SKIP LOCKED."""
    try:
        rows = _sb().rpc("leadx_claim_next_job", {"p_worker_id": worker_id, "p_kinds": kinds}).execute().data or []
        return rows[0] if rows else None
    except Exception:
        logger.warning("claim_next RPC failed", exc_info=True)
        return None


def complete(job_id: str, result: Optional[dict] = None, *, worker_id: str | None = None) -> None:
    try:
        q = _sb().table("jobs").update({
            "status": "done", "result": result or {}, "error": None,
            "finished_at": _now().isoformat(), "locked_by": None,
        }).eq("id", job_id).eq("status", "running")
        if worker_id:
            q = q.eq("locked_by", worker_id)
        q.execute()
    except Exception:
        logger.exception("complete failed for job %s", job_id)


def fail(job_id: str, error: str, *, attempts: int = 0, max_attempts: int = 3, worker_id: str | None = None) -> None:
    """Requeue with exponential backoff while attempts remain, else mark
    failed and raise an admin notification (a silently dead job is the
    failure mode that actually hurts in production)."""
    error = (error or "")[:2000]
    retry = attempts < max_attempts
    update: dict[str, Any] = {"error": error, "locked_by": None}
    if retry:
        update["status"] = "queued"
        update["run_after"] = (
            _now() + timedelta(seconds=RETRY_BASE_SECONDS * (2 ** max(0, attempts - 1)))
        ).isoformat()
    else:
        update["status"] = "failed"
        update["finished_at"] = _now().isoformat()
    try:
        q = _sb().table("jobs").update(update).eq("id", job_id).eq("status", "running")
        if worker_id:
            q = q.eq("locked_by", worker_id)
        q.execute()
    except Exception:
        logger.exception("fail update failed for job %s", job_id)

    if not retry:
        try:
            from app.integrations.prod.notifications import notify_sync

            notify_sync(
                scope="admin",
                kind="job_failed",
                title="Job failed after all retries",
                body=f"job {job_id}: {error[:300]}",
                severity="critical",
                link="/admin/jobs",
                meta={"job_id": job_id},
            )
        except Exception:
            logger.warning("job-failed notification failed", exc_info=True)


async def run_job(job: dict) -> dict:
    """Dispatch a claimed job to its handler. Raises on handler error so
    the worker can apply retry policy."""
    kind = job.get("kind") or ""
    handler = HANDLERS.get(kind)
    if handler is None:
        raise RuntimeError(f"no handler registered for job kind '{kind}'")
    payload = dict(job.get("payload") or {})
    if job.get("tenant_id") and "tenant_id" not in payload:
        payload["tenant_id"] = str(job["tenant_id"])
    result = await handler(payload)
    return result if isinstance(result, dict) else {"result": result}


# ---------------------------------------------------------------- ops



def renew_lease(job_id: str, worker_id: str) -> bool:
    """Renew a running job lease so legitimate long jobs are never reaped."""
    try:
        rows = (_sb().table("jobs").update({"locked_at": _now().isoformat()})
                .eq("id", job_id).eq("status", "running").eq("locked_by", worker_id)
                .execute().data or [])
        return bool(rows)
    except Exception:
        logger.warning("lease renewal failed for job %s", job_id, exc_info=True)
        return False

def reap_stale(minutes: int = STALE_LOCK_MINUTES) -> int:
    """Requeue stale jobs only while attempts remain; exhaustions become failed."""
    cutoff = (_now() - timedelta(minutes=minutes)).isoformat()
    try:
        rows = (_sb().table("jobs").select("id,attempts,max_attempts")
                .eq("status", "running").lt("locked_at", cutoff).limit(500).execute().data or [])
        reaped = 0
        for job in rows:
            attempts = int(job.get("attempts") or 0)
            maximum = int(job.get("max_attempts") or 3)
            status = "queued" if attempts < maximum else "failed"
            patch = {"status": status, "locked_by": None, "error": "worker_lost_reaped"}
            if status == "failed": patch["finished_at"] = _now().isoformat()
            (_sb().table("jobs").update(patch).eq("id", job["id"]).eq("status", "running").lt("locked_at", cutoff).execute())
            reaped += 1
        if reaped: logger.warning("reaped %d stale job(s)", reaped)
        return reaped
    except Exception:
        logger.warning("reap_stale failed", exc_info=True)
        return 0


def get_job(job_id: str) -> Optional[dict]:
    try:
        rows = _sb().table("jobs").select("*").eq("id", job_id).limit(1).execute().data or []
        return rows[0] if rows else None
    except Exception:
        return None


def list_jobs(
    *,
    status: Optional[str] = None,
    kind: Optional[str] = None,
    tenant_id: Optional[str] = None,
    limit: int = 100,
) -> list[dict]:
    try:
        q = _sb().table("jobs").select("*")
        if status:
            q = q.eq("status", status)
        if kind:
            q = q.eq("kind", kind)
        if tenant_id:
            q = q.eq("tenant_id", tenant_id)
        return q.order("created_at", desc=True).limit(min(max(limit, 1), 500)).execute().data or []
    except Exception:
        logger.warning("list_jobs failed", exc_info=True)
        return []


def queue_stats() -> dict:
    """Exact queue counts from the database, not a 2k-row sample."""
    out = {"queued": 0, "running": 0, "done": 0, "failed": 0, "cancelled": 0}
    try:
        rows = _sb().rpc("leadx_queue_stats").execute().data or []
        oldest = None
        for row in rows:
            st = row.get("status"); count = int(row.get("count") or 0)
            if st in out: out[st] = count
            if st == "queued": oldest = row.get("oldest_created_at")
        age = 0
        if oldest:
            age = max(0, int((_now() - datetime.fromisoformat(str(oldest).replace("Z", "+00:00"))).total_seconds()))
        return {**out, "oldest_queued_seconds": age, "handlers": sorted(HANDLERS)}
    except Exception:
        return {**out, "oldest_queued_seconds": 0, "handlers": sorted(HANDLERS), "stats_error": "queue_stats_rpc_unavailable"}


def retry_job(job_id: str) -> dict:
    try:
        _sb().table("jobs").update(
            {
                "status": "queued",
                "attempts": 0,
                "error": None,
                "locked_by": None,
                "run_after": _now().isoformat(),
                "finished_at": None,
            }
        ).eq("id", job_id).execute()
        return {"ok": True, "job_id": job_id}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def cancel_job(job_id: str) -> dict:
    """Cancels a job that hasn't started. A running job can't be killed
    mid-flight — it's marked cancelled and its handler's writes stand."""
    try:
        _sb().table("jobs").update(
            {"status": "cancelled", "finished_at": _now().isoformat(), "locked_by": None}
        ).eq("id", job_id).in_("status", ["queued", "running"]).execute()
        return {"ok": True, "job_id": job_id}
    except Exception as e:
        return {"ok": False, "error": str(e)}
