"""Strict production runtime configuration checks shared by API and worker."""
from __future__ import annotations
import os

PRODUCTION_REQUIRED = (
    "SUPABASE_URL", "SUPABASE_ANON_KEY", "UNSUBSCRIBE_SECRET",
    "INTEGRATION_OAUTH_STATE_SECRET", "REDIS_URL", "DELIVERY_CONFIG_KEY",
    "LEAD_ENGINE_SERVICE_KEY", "STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET",
    "CORS_ORIGINS",
)

def validate_runtime_configuration(*, process: str = "api") -> None:
    env = os.getenv("ENVIRONMENT", "development").lower()
    missing = [k for k in PRODUCTION_REQUIRED if not os.getenv(k)]
    if not (os.getenv("SUPABASE_SERVICE_KEY") or os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_KEY")):
        missing.append("SUPABASE_SERVICE_ROLE_KEY")
    service_key = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
    delivery_key = os.getenv("DELIVERY_CONFIG_KEY", "")
    unsub = os.getenv("UNSUBSCRIBE_SECRET", "")
    oauth = os.getenv("INTEGRATION_OAUTH_STATE_SECRET", "")
    if service_key and len(service_key) < 32: missing.append("LEAD_ENGINE_SERVICE_KEY>=32 chars")
    if delivery_key and len(delivery_key) < 32: missing.append("DELIVERY_CONFIG_KEY>=32 chars")
    if unsub and len(unsub) < 32: missing.append("UNSUBSCRIBE_SECRET>=32 chars")
    if oauth and len(oauth) < 32: missing.append("INTEGRATION_OAUTH_STATE_SECRET>=32 chars")
    if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in {"1", "true", "yes"}: missing.append("LEAD_ENGINE_DEV_AUTH_BYPASS=false")
    if env in {"production", "prod"} and missing:
        raise RuntimeError(f"Production {process} startup refused: invalid/missing configuration: {', '.join(sorted(set(missing)))}")
    return None
