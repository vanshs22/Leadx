"""Strict production runtime configuration checks shared by API and worker."""
from __future__ import annotations
import os

PRODUCTION_REQUIRED = (
    "SUPABASE_URL", "SUPABASE_ANON_KEY", "UNSUBSCRIBE_SECRET",
    "INTEGRATION_OAUTH_STATE_SECRET", "REDIS_URL", "DELIVERY_CONFIG_KEY",
    "LEAD_ENGINE_SERVICE_KEY", "STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET",
    "CORS_ORIGINS",
)

def validate_runtime_configuration(*, process: str = "api") -> None:
    env = os.getenv("ENVIRONMENT", "development").lower()
    missing = [k for k in PRODUCTION_REQUIRED if not os.getenv(k)]
    if not (os.getenv("SUPABASE_SERVICE_KEY") or os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_KEY")):
        missing.append("SUPABASE_SERVICE_ROLE_KEY")
    service_key = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
    delivery_key = os.getenv("DELIVERY_CONFIG_KEY", "")
    unsub = os.getenv("UNSUBSCRIBE_SECRET", "")
    oauth = os.getenv("INTEGRATION_OAUTH_STATE_SECRET", "")
    if service_key and len(service_key) < 32: missing.append("LEAD_ENGINE_SERVICE_KEY>=32 chars")
    if delivery_key and len(delivery_key) < 32: missing.append("DELIVERY_CONFIG_KEY>=32 chars")
    if unsub and len(unsub) < 32: missing.append("UNSUBSCRIBE_SECRET>=32 chars")
    if oauth and len(oauth) < 32: missing.append("INTEGRATION_OAUTH_STATE_SECRET>=32 chars")
    if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in {"1", "true", "yes"}: missing.append("LEAD_ENGINE_DEV_AUTH_BYPASS=false")
    if env in {"production", "prod", "staging"} and os.getenv("JOB_QUEUE_FAIL_CLOSED", "true").lower() in {"0", "false", "no"}:
        missing.append("JOB_QUEUE_FAIL_CLOSED=true")
    # Emails must carry a working, public unsubscribe link (served by this API).
    pub = (os.getenv("PUBLIC_API_URL") or os.getenv("PUBLIC_APP_URL") or "").strip()
    if not pub or "localhost" in pub or "127.0.0.1" in pub:
        missing.append("PUBLIC_API_URL (public https URL of the API)")
    if env in {"production", "prod", "staging"}:
        # Soft check only: verification is free-first (local SMTP probe + plan
        # rules); surface weaknesses at boot so they are not found at first run.
        try:
            from app.integrations.prod.contact_verification_mesh import verification_readiness
            import logging
            for w in verification_readiness().get("warnings") or []:
                logging.getLogger("lead_engine.config").warning("verification: %s", w)
        except Exception as exc:
            import logging
            logging.getLogger("lead_engine.config").warning("verification readiness check skipped: %s", exc)
    if env in {"production", "prod"} and missing:
        raise RuntimeError(f"Production {process} startup refused: invalid/missing configuration: {', '.join(sorted(set(missing)))}")
    return None
