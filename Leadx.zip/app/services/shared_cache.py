"""Small shared JSON cache with Redis + in-process fallback.

The CRM uses this only for short-lived, tenant-scoped read snapshots. Authorization
is always performed before a cached value is returned; cache keys are never an
authorization boundary. Redis is optional so local/dev installs keep working.
"""
from __future__ import annotations

import json
import logging
import os
import time
from threading import RLock
from typing import Any, Optional

logger = logging.getLogger("lead_engine.cache")

_MEMORY: dict[str, tuple[float, Any]] = {}
_LOCK = RLock()
_REDIS = None
_REDIS_FAILED_UNTIL = 0.0


def _redis():
    global _REDIS, _REDIS_FAILED_UNTIL
    url = (os.getenv("REDIS_URL") or "").strip()
    if not url:
        return None
    now = time.monotonic()
    if now < _REDIS_FAILED_UNTIL:
        return None
    if _REDIS is not None:
        return _REDIS
    try:
        import redis
        _REDIS = redis.Redis.from_url(
            url,
            decode_responses=True,
            socket_connect_timeout=0.5,
            socket_timeout=0.8,
            health_check_interval=30,
        )
        return _REDIS
    except Exception as exc:
        _REDIS_FAILED_UNTIL = now + 30
        logger.debug("redis cache unavailable: %s", exc)
        return None


def _memory_get(key: str):
    now = time.monotonic()
    with _LOCK:
        item = _MEMORY.get(key)
        if not item:
            return None
        expires, value = item
        if expires <= now:
            _MEMORY.pop(key, None)
            return None
        return value


def get_json(key: str) -> Optional[Any]:
    r = _redis()
    if r:
        try:
            raw = r.get(key)
            if raw:
                return json.loads(raw)
        except Exception as exc:
            logger.debug("redis get fallback: %s", exc)
    return _memory_get(key)


def set_json(key: str, value: Any, ttl: int = 5) -> None:
    ttl = max(1, int(ttl))
    with _LOCK:
        _MEMORY[key] = (time.monotonic() + ttl, value)
    r = _redis()
    if r:
        try:
            r.setex(key, ttl, json.dumps(value, separators=(",", ":"), default=str))
        except Exception as exc:
            logger.debug("redis set fallback: %s", exc)


def delete(key: str) -> None:
    with _LOCK:
        _MEMORY.pop(key, None)
    r = _redis()
    if r:
        try:
            r.delete(key)
        except Exception as exc:
            logger.debug("redis delete fallback: %s", exc)


def delete_prefix(prefix: str) -> None:
    with _LOCK:
        for key in list(_MEMORY):
            if key.startswith(prefix):
                _MEMORY.pop(key, None)
    r = _redis()
    if not r:
        return
    try:
        keys = list(r.scan_iter(match=f"{prefix}*", count=200))
        if keys:
            r.delete(*keys)
    except Exception as exc:
        logger.debug("redis prefix delete fallback: %s", exc)
