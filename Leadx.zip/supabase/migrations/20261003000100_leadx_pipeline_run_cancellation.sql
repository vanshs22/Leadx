-- LeadX: durable operator cancellation for pipeline runs.
-- Cancellation is cooperative: the API records the request, then the worker
-- stops the pipeline task at its next await. Existing assignments are kept.
DO $$
DECLARE
  c record;
BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    FOR c IN
      SELECT conname
      FROM pg_constraint
      WHERE conrelid = 'public.pipeline_runs'::regclass
        AND contype = 'c'
        AND pg_get_constraintdef(oid) ILIKE '%status%'
        AND pg_get_constraintdef(oid) ILIKE '%running%'
        AND pg_get_constraintdef(oid) ILIKE '%completed%'
    LOOP
      EXECUTE format('ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS %I', c.conname);
    END LOOP;
    ALTER TABLE public.pipeline_runs
      ADD CONSTRAINT pipeline_runs_status_check
      CHECK (status IN ('queued','running','cancel_requested','completed','failed','partial','cancelled'));
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
