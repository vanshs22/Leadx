-- LeadX 15.8: durable pipeline-run lifecycle compatibility.
-- The API creates a run before enqueueing the worker, so `queued` must be a
-- valid pipeline_runs.status on both fresh and previously provisioned databases.
DO $$
DECLARE
  c record;
BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    FOR c IN
      SELECT conname
      FROM pg_constraint
      WHERE conrelid = 'public.pipeline_runs'::regclass
        AND contype = 'c'
        AND pg_get_constraintdef(oid) ILIKE '%status%'
        AND pg_get_constraintdef(oid) ILIKE '%running%'
        AND pg_get_constraintdef(oid) ILIKE '%completed%'
    LOOP
      EXECUTE format('ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS %I', c.conname);
    END LOOP;
    ALTER TABLE public.pipeline_runs
      ADD CONSTRAINT pipeline_runs_status_check
      CHECK (status IN ('queued','running','completed','failed','partial'));
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
