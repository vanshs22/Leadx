-- LeadX: shared ICP match cache for cross-client lead reuse.
-- This table is tenant-independent by design. Tenant-specific quota,
-- suppression, recency, and exclusivity checks remain in assign_lead().
CREATE TABLE IF NOT EXISTS public.lead_icp_matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  icp_key text NOT NULL,
  lead_id uuid NOT NULL REFERENCES public.leads_global(id) ON DELETE CASCADE,
  vertical text NOT NULL,
  geo_key text NOT NULL DEFAULT '',
  keywords jsonb NOT NULL DEFAULT '[]'::jsonb,
  offer_category text,
  score integer NOT NULL DEFAULT 0,
  tier text NOT NULL DEFAULT 'C' CHECK (tier IN ('A','B','C')),
  reasoning text,
  score_policy_version text NOT NULL DEFAULT 'leadx-v1',
  source_run_id uuid REFERENCES public.pipeline_runs(id) ON DELETE SET NULL,
  scored_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (icp_key, lead_id)
);
CREATE INDEX IF NOT EXISTS idx_lead_icp_matches_key_score
  ON public.lead_icp_matches (icp_key, score DESC, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_icp_matches_lead
  ON public.lead_icp_matches (lead_id);
ALTER TABLE public.lead_icp_matches ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS lead_icp_matches_service_all ON public.lead_icp_matches;
CREATE POLICY lead_icp_matches_service_all ON public.lead_icp_matches
  FOR ALL TO service_role USING (true) WITH CHECK (true);
NOTIFY pgrst, 'reload schema';
