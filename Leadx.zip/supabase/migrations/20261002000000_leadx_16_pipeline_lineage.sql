-- LeadX 16.0: deterministic pipeline lineage and durable funnel counters.
-- Every assignment can be traced to the mission/run that produced it, while
-- pipeline counters remain database-backed rather than UI-derived.
ALTER TABLE public.pipeline_runs
  ADD COLUMN IF NOT EXISTS mission_id uuid REFERENCES public.agent_missions(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS stage text NOT NULL DEFAULT 'starting',
  ADD COLUMN IF NOT EXISTS raw_discovered int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS unique_candidates int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS verification_passed int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS delivery_eligible int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS selected_count int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS assignment_failed int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS crm_saved int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS rejected int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS retryable_failures int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS provider_cost numeric(12,4) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS budget_limit numeric(12,4);

ALTER TABLE public.lead_assignments
  ADD COLUMN IF NOT EXISTS pipeline_run_id uuid REFERENCES public.pipeline_runs(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS mission_id uuid REFERENCES public.agent_missions(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_tenant_stage
  ON public.pipeline_runs(tenant_id, stage, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_mission
  ON public.pipeline_runs(mission_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_assignments_pipeline_run
  ON public.lead_assignments(tenant_id, pipeline_run_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_assignments_mission
  ON public.lead_assignments(tenant_id, mission_id, created_at DESC);
