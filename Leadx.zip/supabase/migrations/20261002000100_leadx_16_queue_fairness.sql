-- LeadX 16.0: fair job claiming under multi-tenant load.
-- Same-priority jobs prefer tenants with fewer active jobs, preventing one
-- large pipeline from monopolizing every worker slot.
CREATE INDEX IF NOT EXISTS idx_jobs_claim_fairness
  ON public.jobs(status, run_after, priority DESC, tenant_id, created_at);

CREATE OR REPLACE FUNCTION public.leadx_claim_next_job(p_worker_id text, p_kinds text[] default null)
RETURNS SETOF public.jobs
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE r public.jobs%rowtype;
BEGIN
  SELECT j.* INTO r
  FROM public.jobs j
  WHERE j.status = 'queued'
    AND j.run_after <= now()
    AND (p_kinds IS NULL OR j.kind = ANY(p_kinds))
  ORDER BY j.priority DESC,
    (SELECT count(*) FROM public.jobs active
      WHERE active.status = 'running'
        AND active.tenant_id IS NOT DISTINCT FROM j.tenant_id),
    j.created_at
  FOR UPDATE SKIP LOCKED
  LIMIT 1;
  IF r.id IS NULL THEN RETURN; END IF;
  UPDATE public.jobs
  SET status='running', locked_by=p_worker_id, locked_at=now(),
      started_at=now(), attempts=coalesce(attempts,0)+1
  WHERE id=r.id AND status='queued'
  RETURNING * INTO r;
  RETURN NEXT r;
END $$;
REVOKE ALL ON FUNCTION public.leadx_claim_next_job(text,text[]) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_claim_next_job(text,text[]) TO service_role;
