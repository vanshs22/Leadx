# LeadX 15.8 SQL Migration Fix

This package is based on LeadX 15.8 FIXED FINAL and retains the full backend, frontend, agent/mission wiring, 22-migration chain, security hardening, worker deployment, and CRM functionality.

The `crm_dashboard_snapshot` function was hardened to use an explicit `generate_series(...) AS gs(day)` column alias and `gs.day`, avoiding ambiguous/invalid `day`/table-alias parsing in SQL clients.

The same corrected function is present in:
- `SUPABASE_FULL_MIGRATION.sql`
- `supabase/migrations/20260930000000_leadx_baseline.sql`

Verification performed on this package:
- `pytest -q`: PASS
- `python scripts/check_migrations.py`: PASS (22 canonical migrations)
- `python scripts/verify_runtime_schema.py`: PASS
- `python scripts/check_rls_coverage.py`: PASS
- `python scripts/full_system_test.py`: PASS=74, FAIL=0, SKIP=2
- Old `delivered_at::date day` pattern: 0 occurrences
- Explicit `AS gs(day)` fix: 2 occurrences (full migration + baseline)
