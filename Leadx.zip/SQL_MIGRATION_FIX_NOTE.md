# LeadX 15.8 SQL Migration Fix — V6

This package is based on LeadX 15.8 FIXED FINAL and retains the full backend, frontend, agent/mission wiring, 22-migration chain, security hardening, worker deployment, and CRM functionality.

## SQL fixes

1. `crm_dashboard_snapshot` uses explicit `generate_series(...) AS gs(day)` and `gs.day`, avoiding the earlier ambiguous `day`/table-alias form.
2. The final dashboard JSON query explicitly uses `FROM c`, so `c.total`, `c.tier_a`, etc. have a valid CTE source.
3. **Legacy-schema compatibility was added for `activities`**. An older/partially-created `public.activities` table can survive a failed migration; `CREATE TABLE IF NOT EXISTS` does not add missing columns. The migration now explicitly adds the timeline columns required before creating indexes, including `occurred_at`.
4. The same compatibility hardening adds `occurred_at` to a pre-existing `call_log` if that legacy column is missing.

The corrected migration is present in:
- `SUPABASE_FULL_MIGRATION.sql`
- `supabase/migrations/20260930000000_leadx_baseline.sql`

## Verification

- `pytest -q`: PASS
- `python scripts/check_migrations.py`: PASS (22 canonical migrations)
- `python scripts/verify_runtime_schema.py`: PASS
- `python scripts/check_rls_coverage.py`: PASS
- `python scripts/full_system_test.py`: PASS=74, FAIL=0, SKIP=2
- `python scripts/release_audit.py`: PASS=14/14
- `python scripts/check_plan_contract.py`: PASS
- `node scripts/frontend_syntax_check.mjs`: PASS (119 files)
- Python compiled artifacts removed from release package
- Real `.env` files removed from release package
- ZIP integrity: PASS

The package has not been run against the user's live Supabase database because live database credentials are not available in the verification environment. The SQL has therefore been hardened and statically checked, but live Postgres execution remains the final external validation step.
