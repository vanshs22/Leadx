# LeadX 15.8 SQL Migration — Run Guide

## Use this file
Run **`SUPABASE_FULL_MIGRATION.sql`** in the Supabase SQL Editor for a clean/full LeadX 15.8 installation.

Do not run `docs/archive/SUPABASE_FULL_MIGRATION_V7.sql` for the current release.
Do not run the canonical migration files separately after running the full migration.

## Important
The full migration has been normalized so trailing `--` comments are on their own lines. This prevents SQL comments from swallowing commas/continuation tokens in long `CREATE TABLE` and `ALTER TABLE` statements.

The canonical `supabase/migrations/` files are also normalized without changing executable SQL semantics.

## Expected result
The SQL is intended to run as one full migration in the Supabase SQL Editor. If the editor shows a line-specific syntax error, verify that the file being executed is the root `SUPABASE_FULL_MIGRATION.sql` from this release and not an older V7/V8/V9 copy.
