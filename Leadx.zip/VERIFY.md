# Leadx — run & verify

Two ways to run:

| Mode | What it uses | Use when |
|------|--------------|----------|
| **local** | JSON files on disk, all integrations stubbed | You want to click through the app with **zero accounts** |
| **live** | Real Supabase + real API keys | Real leads, real tenants, production |

Everything below is copy-paste. Expected output is stated so you can tell pass from fail.

---

## 0. Prerequisites

- Python 3.11+ (verified on 3.11.9)
- Node 20+ (verified on 22.16)
- Docker is **not** required.

---

## 1. Install

```bash
cd lead-engine-v2
pip install -r requirements.txt
```

**Expected:** completes with no error.

> This previously failed outright: `scrapegraphai` pulls `litellm`, which needs a Rust
> toolchain. Heavy scrapers now live in `requirements-scrape.txt` and are optional —
> the enricher falls back to plain HTTP fetching without them.

Optional full scraping cascade:
```bash
pip install -r requirements-scrape.txt
playwright install chromium
```

---

## 2. Backend tests

```bash
cd lead-engine-v2
python -m pytest
```

**Expected:** `143 passed`.

These now import the real modules. Previously several test files defined their *own*
copies of the functions under test (e.g. `test_fingerprint_exclusivity.py` redefined
`fingerprint()`), so the suite passed even when the shipped code was broken.

---

## 3. Run in LOCAL mode (no accounts needed)

```bash
cd lead-engine-v2
export PYTHONPATH=.                      # Windows PowerShell: $env:PYTHONPATH="."
export LEADX_MODE=local
export ENVIRONMENT=development
export LEAD_ENGINE_DEV_AUTH_BYPASS=1
python -m uvicorn backend.app_service:app --port 8000
```

Verify in another shell:
```bash
curl -s localhost:8000/health   # {"ok":true, ... "db":true}
curl -s localhost:8000/ready    # {"ready":true}
```

Data persists as JSON under `.leadx-local/` (override with `LEADX_LOCAL_DIR`).

`LEADX_MODE=local` **refuses to start** when `ENVIRONMENT=production` — it is not a database.

---

## 4. Run in LIVE mode

### 4a. Apply migrations

In the Supabase SQL editor, run **in order**:

1. `lead-engine-v2/SUPABASE_FULL_MIGRATION.sql` — base schema (existing installs: already applied)
2. `lead-engine-v2/sql/015_crm_missing_objects.sql` — **required**
3. `lead-engine-v2/sql/016_crm_full.sql` — CRM: companies / contacts / deals / activities / tasks
4. `lead-engine-v2/sql/017_crm_seed.sql` — optional demo data

Step 2 is not optional. Five CRM endpoints (dashboard, lead list, lead detail, pipeline
board, reports) query a view `crm_lead_cards` that existed in **no** migration, so they
returned HTTP 500 on every fresh install. It also adds the `seed_default_stages()`
function, which the code called but nothing defined.

All files are idempotent — safe to re-run.

### 4b. Configure

```bash
cd lead-engine-v2
cp .env.example .env
```

Set at minimum:
```
ENVIRONMENT=development
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_KEY=<service_role key>
SUPABASE_ANON_KEY=<anon key>
SUPABASE_JWT_SECRET=<JWT secret>
SERPER_API_KEY=<optional — needed for real discovery>
```

### 4c. Start

```bash
export PYTHONPATH=.
python -m uvicorn backend.app_service:app --port 8000
curl -s localhost:8000/ready
```

**`/ready` returns 503 with a specific reason** if the DB is unreachable or
`crm_lead_cards` is missing — it tells you which migration to run instead of failing
later at the first user click.

---

## 5. Frontend

```bash
cd lead-crm-portal/frontend
npm install
npm run build
```

**Expected:** `Compiled successfully`, exit 0.

Dev server:
```bash
echo "API_UPSTREAM=http://127.0.0.1:8000" > .env.local
npm run dev        # http://localhost:3000
```

---

## 6. Production checklist

Production now **refuses to boot** on these rather than running insecurely:

| Guard | Behaviour |
|---|---|
| `CORS_ORIGINS` unset | Startup fails. It used to fall back to `*` in production, letting any origin call the API with a user's token. |
| `LEAD_ENGINE_DEV_AUTH_BYPASS=1` | Force-disabled + CRITICAL log. This flag grants owner role on **any** tenant to unauthenticated requests, and `start.sh` writes it into `.env` by default. |
| `LEADX_MODE=local` | Startup fails. |
| Router import error | Startup fails. Mounts used to be wrapped in `try/except`, so a bad import produced a running API with **zero routes** while `/health` still said ok. |

Also set `ENVIRONMENT=production`, a strong `LEAD_ENGINE_SERVICE_KEY` (≥16 chars), and
`DELIVERY_CONFIG_KEY` so delivery secrets aren't stored in plaintext.

---

## What I could not verify here

Stated plainly so you know where to look first:

- **No Postgres/Docker on this machine**, so the SQL in `015/016/017` was not executed.
  It is written to be idempotent and was desk-checked against the real column names in
  `SUPABASE_FULL_MIGRATION.sql`, but **run step 4a first and report any error** — that is
  the one step I could not prove.
- **No live Supabase**, so live-mode auth (real Supabase JWT → `tenant_members` lookup)
  is unverified end-to-end. Local mode and the dev bypass path are verified.
- **No real API keys**, so Serper/Firecrawl/Stripe/Resend/Telegram calls are unexercised
  against the real services.
