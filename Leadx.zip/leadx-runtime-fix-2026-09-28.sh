#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BACKEND="$ROOT/lead-engine-v2"
FRONTEND="$ROOT/lead-crm-portal/frontend"

printf '\n[1/5] Stopping stale LeadX dev processes...\n'
pkill -f 'uvicorn app\.app_service:app' 2>/dev/null || true
pkill -f 'next dev.*-p 3000' 2>/dev/null || true
sleep 1

printf '[2/5] Verifying backend source...\n'
cd "$BACKEND"
python -m py_compile app/app_service.py app/crm/crm_api.py app/api/prod/support_api.py app/integrations/prod/support_chat.py

printf '[3/5] Starting FastAPI on 8000...\n'
nohup python -m uvicorn app.app_service:app --host 0.0.0.0 --port 8000 > /tmp/leadx-fastapi.log 2>&1 &
BACK_PID=$!
sleep 2

printf '[4/5] Checking live route contract...\n'
python - <<'PY2'
import json, urllib.request
u='http://127.0.0.1:8000/health'
with urllib.request.urlopen(u, timeout=5) as r:
    body=json.load(r)
print(json.dumps(body, indent=2))
checks=body.get('checks',{})
contract=checks.get('crm_routes',{})
required=('me','dashboard','leads','pipeline','reports','deal_reports','support_ask')
missing=[x for x in required if not contract.get(x)]
if missing:
    raise SystemExit('CRM runtime contract missing: '+', '.join(missing))
PY2

printf '[5/5] Starting Next.js on 3000...\n'
cd "$FRONTEND"
if [ ! -x node_modules/.bin/next ]; then
  npm ci
fi
nohup npm run dev -- --hostname 0.0.0.0 > /tmp/leadx-next.log 2>&1 &
FRONT_PID=$!

echo
printf 'LeadX is starting. FastAPI PID=%s, Next PID=%s\n' "$BACK_PID" "$FRONT_PID"
printf 'Backend log: /tmp/leadx-fastapi.log\nFrontend log: /tmp/leadx-next.log\n'
