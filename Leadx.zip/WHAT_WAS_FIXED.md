# What was broken (accidentally) and restored

## 1. supabase_client.py (CRITICAL)
- **Bug:** Test stub `raise RuntimeError("supabase not configured in test")`
- **Effect:** Admin tenants 503, ops 500
- **Restored:** Real client using SUPABASE_URL + SUPABASE_SERVICE_KEY

## 2. Pipeline run_id mismatch
- **Bug:** API created run A; pipeline always created run B
- **Effect:** UI stuck on "running", empty board for that run
- **Fixed:** pipeline accepts `run_id=` from API; progress + board cards on same id

## 3. ses_domain.py missing
- **Bug:** Import failed / SES outbound broken
- **Restored:** ses_domain.py + platform SES fallback when AWS keys set

## 4. SMTP cascade typo
- **Bug:** `await send_via_smtp` (undefined)
- **Fixed:** `asyncio.to_thread(send_via_smtp_sync, ...)`

## Do NOT reintroduce
- Never ship a get_supabase that only raises for tests
- Keep .env when unzipping
