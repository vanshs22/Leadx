-- Optional: align pipeline_runs with code
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
-- Allow running/started aliases if needed
ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS pipeline_runs_status_check;
ALTER TABLE public.pipeline_runs ADD CONSTRAINT pipeline_runs_status_check
  CHECK (status IN ('running','started','completed','failed','partial'));
