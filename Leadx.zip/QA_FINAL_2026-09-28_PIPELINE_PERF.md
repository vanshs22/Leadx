# LeadX pipeline / performance hardening — 2026-09-28

- Final bulk reconciliation guarantees run-board cards for all processed leads.
- Fill-round leads are included on the board.
- Run metadata stores processed lead IDs (cap 2000) for self-healing.
- A/B tier is preserved from post-gate scoring through assignment and board cards.
- Client dashboard has a one-round-trip Postgres snapshot fast path and safe fallback.
- Client dashboard uses stale-while-revalidate so cached cards render immediately.
- Admin run history and active run boards refresh automatically.

Requested N is a target, not a guarantee: assignment is capped by remaining approved/monthly quota and delivery constraints. Thus gated can exceed assigned.

One-time DB migration: `lead-engine-v2/sql/043_FAST_DASHBOARD_SNAPSHOT.sql`.
