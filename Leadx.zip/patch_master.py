from pathlib import Path
root=Path('/mnt/data/leadx_notif_fix/lead-engine-v2')
# Add missing canonical migrations to both single-run installers. These were
# present as individual migrations but absent from the consolidated installers.
missing_files=['021_FIX_pipeline_notifications_jobs.sql','030_CRM_REVENUE_GRAPH.sql','031_BUSINESS_INTEGRATIONS_AND_REVENUE_OPS.sql','032_SUPPORT_CHAT.sql']
blocks=[]
for name in missing_files:
    p=root/'sql'/name
    text=p.read_text()
    blocks.append(f"\n\n-- ============================================================================\n-- CONSOLIDATED INSTALL: {name}\n-- ============================================================================\n{text}\n")
addition=''.join(blocks)
for target in [root/'sql/000_ALL_IN_ONE_migration.sql', root/'SUPABASE_FULL_MIGRATION.sql']:
    s=target.read_text()
    marker='\n-- ============================================================================\n-- CONSOLIDATED MISSING MIGRATIONS / RUNTIME OBJECT COVERAGE\n-- ============================================================================' 
    # remove prior generated section if rerun
    if marker in s:
        s=s.split(marker,1)[0]
    s += marker + addition
    s += "\n\n-- Final PostgREST schema refresh after ALL DDL.\nDO $$ BEGIN PERFORM pg_notify('pgrst','reload schema'); EXCEPTION WHEN OTHERS THEN NULL; END $$;\n"
    target.write_text(s)

# Harden the standalone runtime repair with notifications + all known runtime gaps.
repair=root/'sql/039_RUNTIME_SCHEMA_REPAIR.sql'
s=repair.read_text()
if 'public.notifications' not in s:
    s += r'''

-- ---------------------------------------------------------------------------
-- In-app notifications (used by tenant/admin notification feeds and bells).
-- This object was historically present in 021 but was missing from some
-- consolidated installers, causing PostgREST PGRST205 at runtime.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope text NOT NULL DEFAULT 'tenant' CHECK (scope IN ('tenant','admin')),
  tenant_id uuid,
  kind text NOT NULL,
  severity text NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','critical')),
  title text NOT NULL,
  body text NOT NULL DEFAULT '',
  link text,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notifications_scope_created ON public.notifications(scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_tenant_unread ON public.notifications(tenant_id, created_at DESC) WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_notifications_admin_unread ON public.notifications(scope, created_at DESC) WHERE scope='admin' AND read_at IS NULL;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS service_all_notifications ON public.notifications;
CREATE POLICY service_all_notifications ON public.notifications FOR ALL USING (true) WITH CHECK (true);
'''
# Extend diagnostic function list with notification + other consolidated-gap objects.
s=s.replace("('crm_lead_cards','view')\n  )", "('crm_lead_cards','view'),\n    ('notifications','table'),\n    ('jobs','table'),\n    ('saved_views','table'),\n    ('company_locations','table'),\n    ('contact_roles','table'),\n    ('outbound_webhooks','table'),\n    ('webhook_deliveries','table'),\n    ('prospect_audits','table'),\n    ('support_faq','table'),\n    ('support_conversations','table'),\n    ('support_messages','table')\n  )")
repair.write_text(s)

# Add explicit runtime schema coverage docs.
doc=root/'docs/RUNTIME_SCHEMA_AND_POSTGREST.md'
doc.write_text('''# Runtime schema and PostgREST hardening\n\nThe consolidated installers now include the canonical migrations for notifications, jobs, saved views, CRM revenue graph, business integrations, and support chat.\n\n## Why this matters\n\nIndividual migrations can exist in `sql/` while an older consolidated SQL file omits them. The application then starts normally but a page fails with PostgREST `PGRST205` (table not found in schema cache).\n\nThe single-run installers now include those objects and finish with a PostgREST schema reload.\n\n## Runtime diagnostic\n\n`GET /leads/v2/admin/runtime-health` checks the runtime objects used by the application.\n''')
