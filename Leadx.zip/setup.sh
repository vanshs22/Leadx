#!/usr/bin/env bash
# Leadx — one-shot setup + run (API + frontend)
# Usage:
#   chmod +x setup.sh && ./setup.sh
#   ./setup.sh --install-only
#   ./setup.sh --api-only
#   ./setup.sh --web-only
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
API_DIR="$ROOT/lead-engine-v2"
WEB_DIR="$ROOT/lead-crm-portal/frontend"
VENV="$API_DIR/.venv"
API_PORT="${API_PORT:-8000}"
WEB_PORT="${WEB_PORT:-3000}"

INSTALL_ONLY=0
API_ONLY=0
WEB_ONLY=0
for arg in "$@"; do
  case "$arg" in
    --install-only) INSTALL_ONLY=1 ;;
    --api-only) API_ONLY=1 ;;
    --web-only) WEB_ONLY=1 ;;
    -h|--help)
      echo "Usage: ./setup.sh [--install-only] [--api-only] [--web-only]"
      exit 0
      ;;
  esac
done

echo "========================================"
echo " Leadx setup"
echo " root: $ROOT"
echo "========================================"

# --- Python binary ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install Python 3.10+ first."
  exit 1
fi
echo "==> Python: $(python3 --version)"

# --- Create venv (must succeed before activate) ---
create_venv() {
  echo "==> Creating Python venv at $VENV"
  rm -rf "$VENV"
  if ! python3 -m venv "$VENV"; then
    echo "python3 -m venv failed. Trying with --without-pip then ensurepip..."
    python3 -m venv --without-pip "$VENV" || true
    if [ -f "$VENV/bin/python" ]; then
      "$VENV/bin/python" -m ensurepip --upgrade || true
    fi
  fi
  if [ ! -f "$VENV/bin/activate" ]; then
    echo ""
    echo "ERROR: venv was not created ($VENV/bin/activate missing)."
    echo "On Debian/Ubuntu/Codespaces install the venv package:"
    echo "  sudo apt-get update && sudo apt-get install -y python3-venv python3-pip"
    echo "Then re-run: ./setup.sh"
    exit 1
  fi
}

if [ ! -f "$VENV/bin/activate" ]; then
  create_venv
else
  echo "==> Reusing existing venv $VENV"
fi

# shellcheck disable=SC1091
# shellcheck source=/dev/null
source "$VENV/bin/activate"
echo "==> venv python: $(which python) ($(python --version 2>&1))"

pip install -q --upgrade pip setuptools wheel
REQ="$API_DIR/requirements.txt"
if [ ! -f "$REQ" ]; then
  REQ="$ROOT/requirements.txt"
fi
if [ -f "$REQ" ]; then
  echo "==> pip install -r $REQ"
  if ! pip install -q -r "$REQ"; then
    echo "WARN: full requirements failed — installing minimal API stack"
    pip install -q fastapi "uvicorn[standard]" httpx pydantic supabase python-dotenv cryptography stripe instaloader "boto3>=1.34.0"
  fi
else
  echo "==> No requirements.txt — installing minimal API stack"
  pip install -q fastapi "uvicorn[standard]" httpx pydantic supabase python-dotenv cryptography stripe instaloader "boto3>=1.34.0"
fi

# Always ensure boto3 (Amazon SES) — even if requirements.txt was partial
echo "==> Ensuring boto3 (Amazon SES)"
pip install -q "boto3>=1.34.0"
if python -c "import boto3; print('    boto3', getattr(boto3, '__version__', 'ok'))"; then
  echo "    boto3 ready for SES"
else
  echo "ERROR: boto3 import failed — SES domain connect will not work"
  pip install -q --force-reinstall "boto3>=1.34.0" || true
  python -c "import boto3; print('    boto3', boto3.__version__)" || echo "ERROR: boto3 still missing"
fi

# --- .env API ---
if [ ! -f "$API_DIR/.env" ]; then
  if [ -f "$API_DIR/.env.example" ]; then
    echo "==> Creating $API_DIR/.env from example — EDIT Supabase + Serper keys"
    cp "$API_DIR/.env.example" "$API_DIR/.env"
  else
    echo "==> Writing minimal $API_DIR/.env"
    cat > "$API_DIR/.env" << 'ENVEOF'
ENVIRONMENT=development
LOG_LEVEL=INFO
LEAD_ENGINE_DEV_AUTH_BYPASS=1
LEAD_ENGINE_SERVICE_KEY=dev-local-service-key-16chars
SUPABASE_URL=
SUPABASE_SERVICE_KEY=
SUPABASE_ANON_KEY=
SERPER_API_KEY=
CORS_ORIGINS=
ENVEOF
  fi
  echo "    Fill SUPABASE_* and SERPER_API_KEY in lead-engine-v2/.env"
else
  echo "==> Found $API_DIR/.env"
fi

# --- Frontend deps + .env.local ---
if command -v npm >/dev/null 2>&1; then
  echo "==> npm install (frontend)"
  (cd "$WEB_DIR" && npm install --no-fund --no-audit)
  # Always sync Supabase public URL/anon from API .env so client login works
  SUPA_URL=$(grep -E '^SUPABASE_URL=' "$API_DIR/.env" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '\r' | sed 's/^["'\'']//;s/["'\'']$//' | sed 's/[[:space:]]*$//' || true)
  SUPA_ANON=$(grep -E '^SUPABASE_ANON_KEY=' "$API_DIR/.env" 2>/dev/null | head -1 | cut -d= -f2- | tr -d '\r' | sed 's/^["'\'']//;s/["'\'']$//' | sed 's/[[:space:]]*$//' || true)
  if [ -z "$SUPA_URL" ] || [ -z "$SUPA_ANON" ]; then
    echo "WARN: SUPABASE_URL / SUPABASE_ANON_KEY empty in $API_DIR/.env — client /login will fail"
  fi
  cat > "$WEB_DIR/.env.local" << ENVEOF
# Codespaces / local — use Next.js proxy to API (do NOT set NEXT_PUBLIC_API_URL)
API_UPSTREAM=http://127.0.0.1:${API_PORT}

# Supabase (must be full https://xxxx.supabase.co — copied from lead-engine-v2/.env)
NEXT_PUBLIC_SUPABASE_URL=${SUPA_URL}
NEXT_PUBLIC_SUPABASE_ANON_KEY=${SUPA_ANON}
ENVEOF
  echo "==> Wrote $WEB_DIR/.env.local"
  echo "    NEXT_PUBLIC_SUPABASE_URL=${SUPA_URL:-<empty>}"
else
  echo "WARN: npm not found — skip frontend install"
fi

if [ "$INSTALL_ONLY" = 1 ]; then
  echo "Install only done."
  exit 0
fi

# --- Resolve uvicorn entrypoint ---
APP_MODULE=""
for candidate in backend.app_service:app backend.main:app app.main:app main:app; do
  mod="${candidate%%:*}"
  modpath="$API_DIR/${mod//.//}.py"
  # also accept package path
  if [ -f "$API_DIR/${mod%%.*}/$(echo "$mod" | cut -d. -f2- | tr '.' '/').py" ] 2>/dev/null; then
    APP_MODULE="$candidate"
    break
  fi
  # simpler checks
  case "$candidate" in
    backend.app_service:app)
      [ -f "$API_DIR/backend/app_service.py" ] && APP_MODULE="$candidate" && break
      ;;
    backend.main:app)
      [ -f "$API_DIR/backend/main.py" ] && APP_MODULE="$candidate" && break
      ;;
    app.main:app)
      [ -f "$API_DIR/app/main.py" ] && APP_MODULE="$candidate" && break
      ;;
    main:app)
      [ -f "$API_DIR/main.py" ] && APP_MODULE="$candidate" && break
      ;;
  esac
done
if [ -z "$APP_MODULE" ]; then
  # last resort: find FastAPI app file
  if [ -f "$API_DIR/backend/app_service.py" ]; then APP_MODULE="backend.app_service:app"
  elif [ -f "$API_DIR/backend/main.py" ]; then APP_MODULE="backend.main:app"
  else
    echo "ERROR: could not find FastAPI app module under $API_DIR"
    exit 1
  fi
fi
echo "==> API module: $APP_MODULE"

# --- Social enrich deps (Instagram + LinkedIn) ---
ensure_social_deps() {
  echo "==> Social enrich: instaloader + LinkedIn scraper"
  # shellcheck source=/dev/null
  source "$VENV/bin/activate"
  pip install -q --upgrade "instaloader>=4.10" || echo "WARN: instaloader pip install failed"
  python -c "import instaloader; print('    instaloader', getattr(instaloader, '__version__', 'ok'))" \
    || echo "WARN: instaloader import failed"

  # LINKEDIN_SCRAPER_URL default
  if [ -f "$API_DIR/.env" ]; then
    if ! grep -q '^LINKEDIN_SCRAPER_URL=' "$API_DIR/.env" 2>/dev/null; then
      echo "LINKEDIN_SCRAPER_URL=http://127.0.0.1:8001" >> "$API_DIR/.env"
      echo "    wrote LINKEDIN_SCRAPER_URL=http://127.0.0.1:8001 to .env"
    fi
    if ! grep -q '^SOCIAL_ENRICH_MAX_PER_RUN=' "$API_DIR/.env" 2>/dev/null; then
      echo "SOCIAL_ENRICH_MAX_PER_RUN=10" >> "$API_DIR/.env"
    fi
  fi
  export LINKEDIN_SCRAPER_URL="${LINKEDIN_SCRAPER_URL:-http://127.0.0.1:8001}"

  # Resolve scraper dir (lead-engine-v2/services/...)
  SCRAPER_DIR=""
  for cand in \
    "$API_DIR/services/linkedin-scraper" \
    "$ROOT/lead-engine-v2/services/linkedin-scraper" \
    "$ROOT/services/linkedin-scraper"
  do
    if [ -d "$cand" ]; then SCRAPER_DIR="$cand"; break; fi
  done
  if [ -z "$SCRAPER_DIR" ]; then
    echo "    linkedin-scraper folder missing — skip"
    return 0
  fi
  echo "    scraper dir: $SCRAPER_DIR"

  # Already healthy?
  if curl -sf "http://127.0.0.1:8001/health" >/dev/null 2>&1; then
    echo "    LinkedIn scraper already healthy on :8001"
    return 0
  fi

  started=0
  if command -v docker >/dev/null 2>&1; then
    echo "    Starting LinkedIn scraper (Docker, ~512MB)…"
    ${DOCKER:-docker} rm -f leadx-linkedin 2>/dev/null || true

    # Prefer compose from API_DIR or ROOT
    COMPOSE_FILE=""
    for cf in "$API_DIR/docker-compose.yml" "$ROOT/lead-engine-v2/docker-compose.yml" "$ROOT/docker-compose.yml"; do
      if [ -f "$cf" ]; then COMPOSE_FILE="$cf"; break; fi
    done
    if [ -n "$COMPOSE_FILE" ]; then
      COMPOSE_DIR="$(dirname "$COMPOSE_FILE")"
      # try with profile, then without
      (cd "$COMPOSE_DIR" && ${DOCKER:-docker} compose --profile social up -d --build linkedin-scraper) && started=1 || true
      if [ "$started" != "1" ]; then
        (cd "$COMPOSE_DIR" && ${DOCKER:-docker} compose up -d --build linkedin-scraper) && started=1 || true
      fi
    fi

    if [ "$started" != "1" ]; then
      echo "    docker compose failed — plain docker build/run…"
      (cd "$SCRAPER_DIR" && ${DOCKER:-docker} build -t leadx-linkedin-scraper .) && \
        ${DOCKER:-docker} run -d --name leadx-linkedin --restart unless-stopped \
          -p 8001:8001 --memory=512m --cpus=1 \
          -e CHROME_SINGLE_PROCESS=1 \
          leadx-linkedin-scraper && started=1 || true
    fi

    # Wait up to ~45s for health
    if [ "$started" = "1" ] || ${DOCKER:-docker} ps --format '{{.Names}}' | grep -q leadx-linkedin; then
      for i in 1 2 3 4 5 6 7 8 9; do
        if curl -sf "http://127.0.0.1:8001/health" >/dev/null 2>&1; then
          echo "    LinkedIn scraper OK → http://127.0.0.1:8001/health"
          return 0
        fi
        sleep 5
      done
      echo "    WARN: container up but /health not ready — logs:"
      ${DOCKER:-docker} logs leadx-linkedin 2>&1 | tail -30 || docker compose -f "${COMPOSE_FILE:-}" logs linkedin-scraper 2>&1 | tail -30 || true
    else
      echo "    WARN: Docker could not start LinkedIn scraper"
    fi
  else
    echo "    Docker not installed — cannot start Chromium LinkedIn scraper"
    echo "    Install Docker, then re-run: ./setup.sh"
    echo "    Instagram (instaloader) still works without Docker"
  fi

  if curl -sf "http://127.0.0.1:8001/health" >/dev/null 2>&1; then
    echo "    LinkedIn scraper OK → http://127.0.0.1:8001/health"
  else
    echo "    WARN: LinkedIn scraper not on :8001 (Serper LinkedIn search still works; deep scrape needs this service + li_at cookie)"
  fi
}



# Try to make Docker usable (Codespaces / VPS)
ensure_docker() {
  if curl -sf "http://127.0.0.1:8001/health" >/dev/null 2>&1; then
    return 0
  fi
  if command -v docker >/dev/null 2>&1; then
    if docker info >/dev/null 2>&1; then
      echo "==> Docker OK"
      return 0
    fi
    echo "==> Docker installed but daemon not ready — trying to start…"
    sudo service docker start 2>/dev/null || sudo systemctl start docker 2>/dev/null || true
    sleep 2
    if docker info >/dev/null 2>&1; then
      echo "==> Docker daemon started"
      return 0
    fi
    if sudo docker info >/dev/null 2>&1; then
      echo "==> Docker works with sudo (will use sudo docker)"
      export DOCKER="sudo docker"
      return 0
    fi
    echo "WARN: Docker daemon not running — LinkedIn scraper on :8001 will be skipped"
    return 1
  fi
  echo "WARN: Docker not installed — LinkedIn scraper needs Docker for Chromium"
  return 1
}

ensure_docker || true

ensure_social_deps



start_api() {
  echo "==> Starting API on :$API_PORT"
  cd "$API_DIR"
  # shellcheck source=/dev/null
  source "$VENV/bin/activate"
  export PYTHONPATH="$API_DIR${PYTHONPATH:+:$PYTHONPATH}"
  # Export .env into process environment (uvicorn does not load it by itself)
  if [ -f "$API_DIR/.env" ]; then
    set -a
    # shellcheck disable=SC1091
    source "$API_DIR/.env"
    set +a
    echo "==> Loaded $API_DIR/.env into environment"
  else
    echo "WARN: no $API_DIR/.env — DB calls will fail"
  fi
  pkill -f "uvicorn ${APP_MODULE%%:*}" 2>/dev/null || true
  export PYTHONUNBUFFERED=1
  # Stream API logs to THIS terminal + /tmp/leadx-api.log (like earlier setup)
  (
    cd "$API_DIR" || exit 1
    # shellcheck source=/dev/null
    source "$VENV/bin/activate"
    export PYTHONPATH="$API_DIR${PYTHONPATH:+:$PYTHONPATH}"
    export PYTHONUNBUFFERED=1
    if [ -f "$API_DIR/.env" ]; then set -a; # shellcheck source=/dev/null
      source "$API_DIR/.env"; set +a; fi
    exec uvicorn "$APP_MODULE" --host 0.0.0.0 --port "$API_PORT" --log-level info
  ) 2>&1 | tee -a /tmp/leadx-api.log &
  echo $! > /tmp/leadx-api.pid
  sleep 2
  if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
    echo "API OK http://127.0.0.1:${API_PORT}/health"
    echo "==> API logs appear in this terminal (and /tmp/leadx-api.log)"
  else
    echo "WARN: /health not ready — scroll up or: tail -50 /tmp/leadx-api.log"
  fi
}



start_web() {
  echo "==> Starting frontend on :$WEB_PORT"
  cd "$WEB_DIR"
  npm run dev -- -p "$WEB_PORT"
}

if [ "$WEB_ONLY" = 1 ]; then
  start_web
  exit 0
fi

if [ "$API_ONLY" = 1 ]; then
  echo "==> API-only FOREGROUND mode — all Supabase/pipeline logs print here (Ctrl+C to stop)"
  cd "$API_DIR"
  # shellcheck source=/dev/null
  source "$VENV/bin/activate"
  export PYTHONPATH="$API_DIR${PYTHONPATH:+:$PYTHONPATH}"
  export PYTHONUNBUFFERED=1
  if [ -f "$API_DIR/.env" ]; then set -a; source "$API_DIR/.env"; set +a; fi
  pkill -f "uvicorn ${APP_MODULE%%:*}" 2>/dev/null || true
  exec uvicorn "$APP_MODULE" --host 0.0.0.0 --port "$API_PORT" --log-level info
fi

# default: API background + frontend foreground
start_api
echo ""
echo "========================================"
echo " API:  http://127.0.0.1:${API_PORT}"
echo " UI:   http://localhost:${WEB_PORT}"
echo " Codespaces: open forwarded port ${WEB_PORT}"
echo "========================================"
echo ""
start_web
