#!/usr/bin/env bash
# Leadx — one-shot setup + run (API + frontend)
# Usage:
#   chmod +x setup.sh && ./setup.sh
#   ./setup.sh --install-only
#   ./setup.sh --api-only
#   ./setup.sh --web-only
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
API_DIR="$ROOT/lead-engine-v2"
WEB_DIR="$ROOT/lead-crm-portal/frontend"
VENV="$API_DIR/.venv"
API_PORT="${API_PORT:-8000}"
WEB_PORT="${WEB_PORT:-3000}"

INSTALL_ONLY=0
API_ONLY=0
WEB_ONLY=0
for arg in "$@"; do
  case "$arg" in
    --install-only) INSTALL_ONLY=1 ;;
    --api-only) API_ONLY=1 ;;
    --web-only) WEB_ONLY=1 ;;
    -h|--help)
      echo "Usage: ./setup.sh [--install-only] [--api-only] [--web-only]"
      exit 0
      ;;
  esac
done

echo "========================================"
echo " Leadx setup"
echo " root: $ROOT"
echo "========================================"

# --- Python venv + deps ---
if [ ! -d "$VENV" ]; then
  echo "==> Creating Python venv"
  python3 -m venv "$VENV"
fi
# shellcheck disable=SC1091
source "$VENV/bin/activate"
pip install -q --upgrade pip
REQ="$API_DIR/requirements.txt"
if [ ! -f "$REQ" ]; then
  REQ="$ROOT/requirements.txt"
fi
echo "==> pip install -r $REQ"
pip install -q -r "$REQ" || pip install -q fastapi "uvicorn[standard]" httpx pydantic supabase python-dotenv cryptography stripe instaloader

# --- .env API ---
if [ ! -f "$API_DIR/.env" ]; then
  if [ -f "$API_DIR/.env.example" ]; then
    echo "==> Creating $API_DIR/.env from example — EDIT Supabase + Serper keys"
    cp "$API_DIR/.env.example" "$API_DIR/.env"
  else
    echo "==> Writing minimal $API_DIR/.env"
    cat > "$API_DIR/.env" << EOF
ENVIRONMENT=development
LOG_LEVEL=INFO
LEAD_ENGINE_DEV_AUTH_BYPASS=1
LEAD_ENGINE_SERVICE_KEY=dev-local-service-key-16chars
SUPABASE_URL=
SUPABASE_SERVICE_KEY=
SUPABASE_ANON_KEY=
SERPER_API_KEY=
CORS_ORIGINS=
EOF
  fi
  echo "    Fill SUPABASE_* and SERPER_API_KEY in lead-engine-v2/.env"
fi

# --- Frontend deps + .env.local ---
if command -v npm >/dev/null 2>&1; then
  echo "==> npm install (frontend)"
  (cd "$WEB_DIR" && npm install --silent)
  if [ ! -f "$WEB_DIR/.env.local" ]; then
    # Copy public Supabase URL/anon from API .env if present
    SUPA_URL=$(grep -E '^SUPABASE_URL=' "$API_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
    SUPA_ANON=$(grep -E '^SUPABASE_ANON_KEY=' "$API_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
    cat > "$WEB_DIR/.env.local" << EOF
API_UPSTREAM=http://127.0.0.1:${API_PORT}
NEXT_PUBLIC_SUPABASE_URL=${SUPA_URL}
NEXT_PUBLIC_SUPABASE_ANON_KEY=${SUPA_ANON}
EOF
    echo "==> Wrote $WEB_DIR/.env.local (set NEXT_PUBLIC_SUPABASE_* if empty)"
  fi
else
  echo "WARN: npm not found — skip frontend install"
fi

if [ "$INSTALL_ONLY" = 1 ]; then
  echo "Install done. Run: ./setup.sh"
  exit 0
fi

cleanup() {
  echo ""
  echo "==> Stopping..."
  kill ${API_PID:-} ${WEB_PID:-} 2>/dev/null || true
  wait ${API_PID:-} ${WEB_PID:-} 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# --- Start API ---
if [ "$WEB_ONLY" != 1 ]; then
  echo "==> Starting API on :$API_PORT"
  cd "$API_DIR"
  export PYTHONPATH="$API_DIR${PYTHONPATH:+:$PYTHONPATH}"
  # load .env into environment for uvicorn
  set -a
  # shellcheck disable=SC1091
  source "$API_DIR/.env" 2>/dev/null || true
  set +a
  uvicorn backend.app_service:app --host 0.0.0.0 --port "$API_PORT" --reload &
  API_PID=$!
  sleep 2
  if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
    echo "    API health OK http://127.0.0.1:${API_PORT}/health"
  else
    echo "    API starting… (health not ready yet — check logs)"
  fi
fi

# --- Start frontend ---
if [ "$API_ONLY" != 1 ] && command -v npm >/dev/null 2>&1; then
  echo "==> Starting frontend on :$WEB_PORT"
  cd "$WEB_DIR"
  PORT="$WEB_PORT" npm run dev -- -p "$WEB_PORT" &
  WEB_PID=$!
fi

echo ""
echo "========================================"
echo " Ready"
echo "   API:      http://127.0.0.1:${API_PORT}"
echo "   API docs: http://127.0.0.1:${API_PORT}/docs"
echo "   Admin:    http://127.0.0.1:${WEB_PORT}/admin"
echo "   Portal:   http://127.0.0.1:${WEB_PORT}"
echo " Codespaces: open forwarded ports ${API_PORT} + ${WEB_PORT}"
echo " Stop: Ctrl+C"
echo "========================================"
echo ""

if [ "$API_ONLY" = 1 ]; then
  wait ${API_PID:-}
elif [ "$WEB_ONLY" = 1 ]; then
  wait ${WEB_PID:-}
else
  wait ${API_PID:-} ${WEB_PID:-}
fi
