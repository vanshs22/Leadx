#!/usr/bin/env bash
# Leadx — one-shot setup + run (API + frontend)
# Usage:
#   chmod +x setup.sh && ./setup.sh
#   ./setup.sh --install-only
#   ./setup.sh --api-only
#   ./setup.sh --web-only
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
API_DIR="$ROOT/lead-engine-v2"
WEB_DIR="$ROOT/lead-crm-portal/frontend"
VENV="$API_DIR/.venv"
API_PORT="${API_PORT:-8000}"
WEB_PORT="${WEB_PORT:-3000}"

INSTALL_ONLY=0
API_ONLY=0
WEB_ONLY=0
for arg in "$@"; do
  case "$arg" in
    --install-only) INSTALL_ONLY=1 ;;
    --api-only) API_ONLY=1 ;;
    --web-only) WEB_ONLY=1 ;;
    -h|--help)
      echo "Usage: ./setup.sh [--install-only] [--api-only] [--web-only]"
      exit 0
      ;;
  esac
done

echo "========================================"
echo " Leadx setup"
echo " root: $ROOT"
echo "========================================"

# --- Python binary ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install Python 3.10+ first."
  exit 1
fi
echo "==> Python: $(python3 --version)"

# --- Create venv (must succeed before activate) ---
create_venv() {
  echo "==> Creating Python venv at $VENV"
  rm -rf "$VENV"
  if ! python3 -m venv "$VENV"; then
    echo "python3 -m venv failed. Trying with --without-pip then ensurepip..."
    python3 -m venv --without-pip "$VENV" || true
    if [ -f "$VENV/bin/python" ]; then
      "$VENV/bin/python" -m ensurepip --upgrade || true
    fi
  fi
  if [ ! -f "$VENV/bin/activate" ]; then
    echo ""
    echo "ERROR: venv was not created ($VENV/bin/activate missing)."
    echo "On Debian/Ubuntu/Codespaces install the venv package:"
    echo "  sudo apt-get update && sudo apt-get install -y python3-venv python3-pip"
    echo "Then re-run: ./setup.sh"
    exit 1
  fi
}

if [ ! -f "$VENV/bin/activate" ]; then
  create_venv
else
  echo "==> Reusing existing venv $VENV"
fi

# shellcheck disable=SC1091
# shellcheck source=/dev/null
source "$VENV/bin/activate"
echo "==> venv python: $(which python) ($(python --version 2>&1))"

pip install -q --upgrade pip setuptools wheel
REQ="$API_DIR/requirements.txt"
if [ ! -f "$REQ" ]; then
  REQ="$ROOT/requirements.txt"
fi
if [ -f "$REQ" ]; then
  echo "==> pip install -r $REQ"
  pip install -q -r "$REQ" || {
    echo "WARN: full requirements failed — installing minimal API stack"
    pip install -q fastapi "uvicorn[standard]" httpx pydantic supabase python-dotenv cryptography stripe instaloader
  }
else
  echo "==> No requirements.txt — installing minimal API stack"
  pip install -q fastapi "uvicorn[standard]" httpx pydantic supabase python-dotenv cryptography stripe instaloader
fi

# --- .env API ---
if [ ! -f "$API_DIR/.env" ]; then
  if [ -f "$API_DIR/.env.example" ]; then
    echo "==> Creating $API_DIR/.env from example — EDIT Supabase + Serper keys"
    cp "$API_DIR/.env.example" "$API_DIR/.env"
  else
    echo "==> Writing minimal $API_DIR/.env"
    cat > "$API_DIR/.env" << 'ENVEOF'
ENVIRONMENT=development
LOG_LEVEL=INFO
LEAD_ENGINE_DEV_AUTH_BYPASS=1
LEAD_ENGINE_SERVICE_KEY=dev-local-service-key-16chars
SUPABASE_URL=
SUPABASE_SERVICE_KEY=
SUPABASE_ANON_KEY=
SERPER_API_KEY=
CORS_ORIGINS=
ENVEOF
  fi
  echo "    Fill SUPABASE_* and SERPER_API_KEY in lead-engine-v2/.env"
else
  echo "==> Found $API_DIR/.env"
fi

# --- Frontend deps + .env.local ---
if command -v npm >/dev/null 2>&1; then
  echo "==> npm install (frontend)"
  (cd "$WEB_DIR" && npm install --no-fund --no-audit)
  if [ ! -f "$WEB_DIR/.env.local" ]; then
    SUPA_URL=$(grep -E '^SUPABASE_URL=' "$API_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
    SUPA_ANON=$(grep -E '^SUPABASE_ANON_KEY=' "$API_DIR/.env" 2>/dev/null | cut -d= -f2- || true)
    cat > "$WEB_DIR/.env.local" << ENVEOF
API_UPSTREAM=http://127.0.0.1:${API_PORT}
NEXT_PUBLIC_SUPABASE_URL=${SUPA_URL}
NEXT_PUBLIC_SUPABASE_ANON_KEY=${SUPA_ANON}
ENVEOF
    echo "==> Wrote $WEB_DIR/.env.local (fill Supabase URL/anon if empty)"
  else
    echo "==> Found $WEB_DIR/.env.local"
  fi
else
  echo "WARN: npm not found — skip frontend install"
fi

if [ "$INSTALL_ONLY" = 1 ]; then
  echo "Install only done."
  exit 0
fi

# --- Resolve uvicorn entrypoint ---
APP_MODULE=""
for candidate in backend.app_service:app backend.main:app app.main:app main:app; do
  mod="${candidate%%:*}"
  modpath="$API_DIR/${mod//.//}.py"
  # also accept package path
  if [ -f "$API_DIR/${mod%%.*}/$(echo "$mod" | cut -d. -f2- | tr '.' '/').py" ] 2>/dev/null; then
    APP_MODULE="$candidate"
    break
  fi
  # simpler checks
  case "$candidate" in
    backend.app_service:app)
      [ -f "$API_DIR/backend/app_service.py" ] && APP_MODULE="$candidate" && break
      ;;
    backend.main:app)
      [ -f "$API_DIR/backend/main.py" ] && APP_MODULE="$candidate" && break
      ;;
    app.main:app)
      [ -f "$API_DIR/app/main.py" ] && APP_MODULE="$candidate" && break
      ;;
    main:app)
      [ -f "$API_DIR/main.py" ] && APP_MODULE="$candidate" && break
      ;;
  esac
done
if [ -z "$APP_MODULE" ]; then
  # last resort: find FastAPI app file
  if [ -f "$API_DIR/backend/app_service.py" ]; then APP_MODULE="backend.app_service:app"
  elif [ -f "$API_DIR/backend/main.py" ]; then APP_MODULE="backend.main:app"
  else
    echo "ERROR: could not find FastAPI app module under $API_DIR"
    exit 1
  fi
fi
echo "==> API module: $APP_MODULE"

start_api() {
  echo "==> Starting API on :$API_PORT"
  cd "$API_DIR"
  # shellcheck source=/dev/null
  source "$VENV/bin/activate"
  export PYTHONPATH="$API_DIR${PYTHONPATH:+:$PYTHONPATH}"
  pkill -f "uvicorn ${APP_MODULE%%:*}" 2>/dev/null || true
  nohup uvicorn "$APP_MODULE" --host 0.0.0.0 --port "$API_PORT" --reload \
    > /tmp/leadx-api.log 2>&1 &
  echo $! > /tmp/leadx-api.pid
  sleep 2
  if curl -sf "http://127.0.0.1:${API_PORT}/health" >/dev/null 2>&1; then
    echo "API OK http://127.0.0.1:${API_PORT}/health"
  else
    echo "WARN: /health not ready yet — check: tail -50 /tmp/leadx-api.log"
  fi
}

start_web() {
  echo "==> Starting frontend on :$WEB_PORT"
  cd "$WEB_DIR"
  npm run dev -- -p "$WEB_PORT"
}

if [ "$WEB_ONLY" = 1 ]; then
  start_web
  exit 0
fi

if [ "$API_ONLY" = 1 ]; then
  start_api
  echo "API running in background. Logs: /tmp/leadx-api.log"
  exit 0
fi

# default: API background + frontend foreground
start_api
echo ""
echo "========================================"
echo " API:  http://127.0.0.1:${API_PORT}"
echo " UI:   http://localhost:${WEB_PORT}"
echo " Codespaces: open forwarded port ${WEB_PORT}"
echo "========================================"
echo ""
start_web
