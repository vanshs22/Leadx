# LeadX 15.8 Setup

## Database
Apply `supabase/migrations/` in order with the Supabase CLI, or use `SUPABASE_FULL_MIGRATION.sql` for a clean install. The canonical chain is **22 migrations**.

## API environment
```bash
cp .env.example .env
```
Production/staging requires `SUPABASE_URL`, server-only `SUPABASE_SERVICE_KEY`, `SUPABASE_ANON_KEY`, `LEAD_ENGINE_SERVICE_KEY` (32+ chars), `DELIVERY_CONFIG_KEY` (32+ chars), `UNSUBSCRIBE_SECRET` (32+ chars), `INTEGRATION_OAUTH_STATE_SECRET` (32+ chars), `REDIS_URL`, `STRIPE_SECRET_KEY`, and `STRIPE_WEBHOOK_SECRET`. Set `REQUIRE_DISTRIBUTED_RATE_LIMIT=1`. Never put service-role credentials in frontend environment variables.

## Start
```bash
docker compose up --build
```
Readiness: `http://localhost:8000/health/ready`.
Portal: `http://localhost:3000`. Admin: `http://localhost:3000/admin/login`.

## Security model
Browser sessions use scoped cookies, not localStorage/sessionStorage. Next middleware validates the session before protected pages render. Backend tenant/platform-admin authorization remains authoritative. OAuth state is signed, tenant/user/provider-bound, expires after 10 minutes, and is single-use. Production rate limits require Redis.

## Verification
```bash
python scripts/run_production_gate.py
RUN_FRONTEND_GATE=1 python scripts/run_production_gate.py
```
Live staging gates are only marked configured when the required staging credentials are supplied and actually exercised.
