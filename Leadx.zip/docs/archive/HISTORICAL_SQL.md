# Historical SQL

Legacy SQL patches are intentionally excluded from the 15.8 distribution. The executable source of truth is `supabase/migrations/` (22 ordered migrations) and `SUPABASE_FULL_MIGRATION.sql`.
