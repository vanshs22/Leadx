# LeadX Documentation

LeadX 15.8 keeps documentation intentionally small and current.

- `../SETUP.md` — setup, auth, database and production verification
- `../MIGRATION_LINEAGE.md` — canonical 21-migration lineage
- `PRODUCTION.md` — production operations
- `SECURITY_AND_QUALITY_FIXES.md` — current security model
- `SECURITY_NO_CLIENT_SERVICE_KEY.md` — browser credential rules
- `SERVICE_RUNBOOK.md` — service operations
- `releases/LEADX_15_6.md` and `releases/LEADX_15_8_RELEASE.md` — release notes

The executable schema is only `supabase/migrations/` plus the generated `SUPABASE_FULL_MIGRATION.sql`.
