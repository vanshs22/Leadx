# LeadX Production Readiness Matrix

This is the launch gate for putting LeadX in front of paying customers. A local/static PASS is not a live production PASS. Every gate is explicitly marked `PASS`, `FAIL`, `BLOCKED`, or `NOT TESTED`.

## Current release status

**Release posture: BLOCKED for production; eligible for staging.** The code-level and offline gates pass, but the live Supabase, worker, provider, billing, browser, load, backup/restore, and observability gates require deployment credentials and infrastructure that are not available in this workspace.

| Gate | Status | Evidence / command | Remaining proof |
|---|---|---|---|
| Functional critical workflows | PASS (offline) / BLOCKED (live) | `pytest -q`; `scripts/full_system_test.py --skip-pytest` | Execute signup → verification → tenant → onboarding → pipeline → CRM against staging |
| Authentication and sessions | PASS (static) / BLOCKED (live) | `security_release_gate.py`; Playwright auth-guard tests | Test signup, login, logout, reset, verification, expiry, refresh, OAuth, deletion, suspension, concurrent sessions |
| Multi-tenancy and RBAC | PASS (static) / BLOCKED (live) | RLS audit; `scripts/cross_tenant_smoke.py` contract mode | Two real tenants, member/admin roles, ID tampering, exports, search, jobs, and negative API requests |
| Database integrity | PASS (static) / BLOCKED (live) | Migration, runtime-schema, RLS, and pipeline contract tests | Clean Supabase reset, FK/unique/cascade/transaction/race tests, query plans, restore test |
| Lead pipeline | PASS (offline) / BLOCKED (live) | Pipeline rig, ID/persistence tests, agent DAG audit | Real discovery/enrichment/provider response matrix and UI count reconciliation |
| API behavior | PASS (contract coverage) / BLOCKED (full HTTP) | Route contract and backend tests | Per-endpoint 2xx/400/401/403/404/409/429/5xx, idempotency, payload abuse, SSRF/path traversal checks |
| Frontend | PASS | TypeScript, Next production build, route/API contract audit | Staging crawl of every protected/public route with browser console/network error capture |
| Integrations | NOT TESTED live | Provider adapters and failure-safe code contracts exist | Success, timeout, 401, 429, 5xx, malformed/partial response for every configured provider |
| Webhooks | PASS (static) / BLOCKED (live) | Stripe ledger/idempotency code and security audit | Valid/invalid/expired signatures, duplicate/out-of-order/missing/unknown/retry events |
| Queue and workers | PASS (code contracts) / BLOCKED (live) | Durable jobs, claim/retry/reap/lease code and tests | Worker crash, retry/DLQ, cancellation, priority, tenant context, duplicate side-effect tests |
| Concurrency and quotas | PASS (offline idempotency contracts) / BLOCKED (Postgres) | Assignment/quota hardening tests | Concurrent discovery, assignments, payments, exports; prove quota never exceeds limit |
| Load and stress | NOT TESTED | k6 and benchmark assets exist | Run 10/100/500/1k-user profiles; record P50/P95/P99, queue depth, DB connections, error rate |
| Security | PASS (static/dependency) / BLOCKED (live pentest) | `security_release_gate.py`; `npm audit`; Ruff; SSRF/auth/RLS tests | Authenticated DAST, IDOR, CSRF, XSS, SQLi, upload, secrets, TLS/CORS/firewall review |
| Secrets | PASS (repository contract) / BLOCKED (deployment scan) | `.env` excluded; startup validation | Scan Git history, image layers, frontend bundles, logs, CI artifacts, deployed env |
| Billing and entitlements | PASS (static) / BLOCKED (Stripe) | Billing tests, Stripe ledger contracts, `stripe_test_clock.py` | Upgrade/downgrade/proration/coupon/refund/failure/grace/cancel/renewal and entitlement enforcement |
| Data accuracy | PASS (offline contracts) / BLOCKED (live) | Pipeline/CRM board and persistence tests | Compare DB/API/dashboard/export counts and IDs for seeded tenants |
| Data loss and recovery | NOT TESTED | No destructive live test performed | Kill API/worker/DB/Redis during processing; verify preservation and replay |
| Observability and alerts | PARTIAL | Request IDs, structured logs, worker heartbeat, queue metrics exist | Central log/metric sink, dashboards, alert routing, secret redaction, alert-fire tests |
| Browser/device compatibility | NOT TESTED | Desktop Chromium build checks only | Chrome/Safari/Edge/Firefox plus iOS Safari and Android Chrome |
| Accessibility | PASS (static checks) / BLOCKED (browser audit) | `check_frontend_accessibility.py` | Keyboard, focus, screen reader, contrast, zoom, form errors on staging |
| SEO/public pages | PARTIAL | Public routes/build pass | Metadata, OG, favicon, sitemap, robots, canonical, HTTPS redirect, 404/500 review |
| Deployment and rollback | PARTIAL | Docker/CI definitions exist | Staging promotion, rollback, migration rollback, health/readiness, zero-downtime test |
| Migration safety | PASS (static) / BLOCKED (live) | `check_migrations.py`, full migration audit | Backup → reset/apply → schema validation → app smoke → rollback/PITR |
| Dependencies | PASS | `npm audit --audit-level=high`, hashed lock generated in CI, Python audit in CI | Repeat at release time and review licenses/abandoned packages |
| Production configuration | BLOCKED | Startup validation is fail-closed | Verify deployed Supabase, Redis, SMTP, Stripe, OAuth, delivery, CORS, URLs, encryption |
| Real-client simulation | BLOCKED | Tenant test harness exists | Tenant A/B/C full money-path and deliberate cross-tenant attacks |
| Money path | BLOCKED | Individual offline contracts pass | Visitor → signup → verify → payment → tenant → integration → import → processing → dashboard → usage → invoice → renewal |

## Launch decision rules

- Any `FAIL` blocks launch immediately.
- Any `BLOCKED` in authentication, tenant isolation, database/RLS, billing, pipeline, queue, security, recovery, or money-path blocks launch.
- No provider is enabled for customers until its success and failure matrix has a passing staging result.
- No production migration is approved without a backup, clean rehearsal, schema validation, and rollback/PITR evidence.
- The final launch record must attach test output, environment/version details, timestamps, and the tenant/user/job IDs used for every live test.

## Required staging sequence

1. Create a disposable Supabase project or reset the linked staging project from `SUPABASE_FULL_MIGRATION.sql`.
2. Start API, worker, Redis, and frontend with staging-only secrets; verify `/health/ready`, `/health/routes`, and worker heartbeat.
3. Create Tenant A/B/C and users with owner/admin/member roles.
4. Run authenticated API negative tests and `scripts/cross_tenant_smoke.py`.
5. Run the money path with Stripe test clock and email verification.
6. Run discovery with deterministic provider fixtures, then real provider adapters one at a time.
7. Kill/restart API and workers during queued and running jobs; verify retries and no duplicate assignments/quota usage.
8. Run Playwright across public, auth, CRM, pipeline, billing, integrations, admin, mobile-sized, and error states.
9. Run k6 at staged concurrency and record P50/P95/P99, errors, queue depth, worker throughput, and DB connections.
10. Execute backup/restore/PITR and rollback rehearsal.
11. Attach all evidence to the release and promote only if every critical gate is PASS.

Run the local matrix with:

```bash
python scripts/production_readiness_matrix.py
```

Run live staging gates only after supplying the documented staging variables:

```bash
RUN_FRONTEND_GATE=1 RUN_CROSS_TENANT=1 python scripts/run_production_gate.py
```
