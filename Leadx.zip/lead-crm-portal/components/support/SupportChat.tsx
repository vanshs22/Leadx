"use client";
import { setVisibleInterval, clearVisibleInterval } from "@/lib/live";
import { useEffect, useRef, useState } from "react";
import { support } from "@/lib/api";
import { BrandMark } from "@/components/ui/BrandMark";
import { Icon } from "@/components/ui/Icon";
export function SupportChat({ admin = false }: { admin?: boolean }) {
  const [open,setOpen]=useState(false),[conversationId,setConversationId]=useState<string|null>(null),[messages,setMessages]=useState<any[]>([]),[input,setInput]=useState(""),[busy,setBusy]=useState(false); const endRef=useRef<HTMLDivElement>(null);
  useEffect(()=>{if(!open||admin)return; support.conversations().then(r=>{const c=r.conversations?.find((x:any)=>x.status!=="closed")||r.conversations?.[0];if(c)setConversationId(c.id)}).catch(()=>{})},[open,admin]);
  useEffect(()=>{if(!conversationId||!open||admin)return; const load=()=>support.messages(conversationId).then(r=>setMessages(r.messages||[])).catch(()=>{}); load(); const t=setVisibleInterval(load,5000); return()=>clearVisibleInterval(t)},[conversationId,open,admin]);
  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"})},[messages]);
  async function send(){const body=input.trim();if(!body||busy)return;setBusy(true);try{let id=conversationId;setMessages(m=>[...m,{sender_type:"user",body,created_at:new Date().toISOString()}]);setInput("");
    // Greetings and simple Help prompts do not need a persisted conversation.
    // Use the stateless endpoint first so a DB/support-storage hiccup cannot
    // turn a basic "hi" into an Internal Server Error.
    if (/^(hi|hello|hey|yo|help)[!?. ]*$/i.test(body)) {
      const fallback=await support.ask(body);
      setMessages(m=>[...m,{sender_type:"bot",body:fallback.answer,created_at:new Date().toISOString(),metadata:{escalated:fallback.escalated}}]);
      return;
    }
    if(!id){try{const r=await support.createConversation();id=r.conversation.id;setConversationId(id)}catch{const fallback=await support.ask(body);setMessages(m=>[...m,{sender_type:"bot",body:fallback.answer,created_at:new Date().toISOString(),metadata:{escalated:fallback.escalated}}]);return}}
    try{const r=await support.sendMessage(id!,body);setMessages(m=>[...m,{sender_type:"bot",body:r.answer,created_at:new Date().toISOString(),metadata:{escalated:r.escalated}}])}catch{const fallback=await support.ask(body);setMessages(m=>[...m,{sender_type:"bot",body:fallback.answer,created_at:new Date().toISOString(),metadata:{escalated:fallback.escalated}}])}
  }catch(e:any){setMessages(m=>[...m,{sender_type:"system",body:"LeadX Help is temporarily unavailable. Please try again."}])}finally{setBusy(false)}}
  if(admin)return null;
  return <><div className={open?"fixed bottom-20 right-4 z-[80] flex h-[min(620px,calc(100dvh-110px))] w-[min(390px,calc(100vw-32px))] flex-col overflow-hidden rounded-3xl border border-line bg-surface-2 shadow-2xl":"hidden"}>
    <div className="flex items-center gap-3 border-b border-line bg-gradient-to-r from-brand-50 to-signal-50/40 px-4 py-4 dark:from-brand-500/10 dark:to-signal-500/10"><BrandMark size={38} /><div className="min-w-0 flex-1"><div className="font-semibold">LeadX Help</div><div className="text-[11px] text-ink-faint">FAQ copilot · human support when needed</div></div><button aria-label="Close help" className="icon-button h-8 w-8" onClick={()=>setOpen(false)}><Icon name="close" className="h-4 w-4" /></button></div>
    <div className="flex-1 space-y-3 overflow-y-auto p-4">{messages.length===0&&<div className="rounded-2xl border border-line bg-surface-3/40 p-4"><div className="text-sm font-semibold">How can I help?</div><p className="mt-1 text-xs leading-5 text-ink-muted">Ask about leads, discovery, quotas, CRM, email sequences, replies, opt-outs, billing, reports, team access, or anything else in LeadX.</p><div className="mt-3 grid gap-2">{["How does my monthly lead limit work?","How do email follow-ups work?","Why is my lead request pending?"].map(q=><button aria-label="Action" key={q} onClick={()=>setInput(q)} className="rounded-xl border border-line bg-surface-2 px-3 py-2 text-left text-xs hover:border-brand-300">{q}</button>)}</div></div>}{messages.map((m,i)=><div key={i} className={`flex ${m.sender_type==="user"?"justify-end":"justify-start"}`}><div className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-sm leading-5 ${m.sender_type==="user"?"bg-brand-600 text-white":m.sender_type==="system"?"border border-rust-200 bg-rust-50 text-rust-700 dark:bg-rust-900/20 dark:text-rust-300":"border border-line bg-surface-3/50 text-ink"}`}>{m.body}{m.metadata?.escalated&&<div className="mt-2 text-[10px] font-semibold uppercase tracking-wide opacity-70">Escalated to support</div>}</div></div>)}{busy&&<div className="text-xs text-ink-faint">LeadX is checking the help knowledge base…</div>}<div ref={endRef}/></div>
    <div className="border-t border-line p-3"><div className="flex items-end gap-2 rounded-2xl border border-line bg-surface-2 p-2 focus-within:border-brand-400"><textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}} rows={2} placeholder="Ask anything about LeadX…" className="min-h-10 flex-1 resize-none bg-transparent px-1 py-1 text-sm outline-none placeholder:text-ink-faint"/><button aria-label="Send" onClick={send} disabled={!input.trim()||busy} className="btn-primary h-9 shrink-0 px-3">Send</button></div><div className="mt-1 text-[10px] text-ink-faint">Enter to send · Shift+Enter for a new line</div></div>
  </div><button aria-label="Open LeadX Help" onClick={()=>setOpen(v=>!v)} className="fixed bottom-4 right-4 z-[79] flex items-center gap-2 rounded-full border border-brand-300/60 bg-brand-600 px-4 py-3 text-sm font-bold text-white shadow-xl transition hover:-translate-y-0.5 hover:shadow-2xl dark:bg-brand-400 dark:text-ink"><Icon name="sparkles" className="h-4 w-4" /> Help</button></>;
}
