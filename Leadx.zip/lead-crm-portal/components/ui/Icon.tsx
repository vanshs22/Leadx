/**
 * LeadX icon system — one inline-SVG set replacing the ad-hoc Unicode glyphs
 * (⌂ ◷ ◈ ✦ ⌕ ▤ ▥ etc.) that used to stand in for navigation icons. Those
 * render inconsistently across operating systems/fonts and read as a
 * placeholder UI. A single `<Icon name="..."/>` keeps every surface visually
 * consistent and crisp at any size/theme.
 */
"use client";

export type IconName =
  | "home" | "clock" | "radar" | "sparkles" | "check" | "search" | "list"
  | "columns" | "trending" | "zap" | "pencil" | "reply" | "activity" | "bar"
  | "dollar" | "logs" | "users" | "plug" | "card" | "settings" | "command"
  | "sun" | "moon" | "menu" | "close" | "chevronRight" | "logout" | "bell";

const PATHS: Record<IconName, React.ReactNode> = {
  home: <path d="M3 10.5 12 3l9 7.5M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5" />,
  clock: <><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></>,
  radar: <><circle cx="12" cy="12" r="8.5" /><circle cx="12" cy="12" r="4.5" /><path d="M12 12 17 8" /></>,
  sparkles: <path d="M12 3v4M12 17v4M4.2 5.2l2.8 2.8M17 16l2.8 2.8M3 12h4M17 12h4M4.2 18.8 7 16M17 8l2.8-2.8" />,
  check: <path d="M4 12.5 9 17l11-11" />,
  search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="M20 20l-4.5-4.5" /></>,
  list: <><path d="M8 6h12M8 12h12M8 18h12" /><path d="M4 6h.01M4 12h.01M4 18h.01" strokeWidth={3} /></>,
  columns: <><rect x="3.5" y="4.5" width="17" height="15" rx="2" /><path d="M9.5 4.5v15M14.5 4.5v15" /></>,
  trending: <><path d="M3.5 17 10 10.5l4 4 6.5-6.5" /><path d="M15.5 7h5v5" /></>,
  zap: <path d="M12.5 3 5 13.5h5.5L10.5 21 19 10.5h-5.5L12.5 3Z" />,
  pencil: <path d="M4 20h4l10.5-10.5a2 2 0 0 0-4-4L4 16v4Z" />,
  reply: <path d="M9 7 3.5 12.5 9 18M3.5 12.5h10a6.5 6.5 0 0 1 6.5 6.5v1" />,
  activity: <path d="M3 12h4l3-7 4 14 3-7h4" />,
  bar: <><rect x="4" y="12" width="4" height="8" /><rect x="10" y="7" width="4" height="13" /><rect x="16" y="3" width="4" height="17" /></>,
  dollar: <><circle cx="12" cy="12" r="9" /><path d="M9.5 15.5c0 1.1 1.1 2 2.5 2s2.5-.8 2.5-1.8c0-1.2-1-1.6-2.5-2s-2.5-.9-2.5-2c0-1 1.1-1.8 2.5-1.8s2.3.7 2.4 1.6M12 7.5v9" /></>,
  logs: <><path d="M4 6h16M4 12h16M4 18h10" /></>,
  users: <><circle cx="9" cy="8" r="3.2" /><path d="M3 20c0-3 2.7-5.2 6-5.2s6 2.2 6 5.2" /><circle cx="17.5" cy="9" r="2.4" /><path d="M15.8 14.3c2.6.4 4.7 2.3 4.7 5" /></>,
  plug: <path d="M9 3v4M15 3v4M7 7h10v4a5 5 0 0 1-10 0V7ZM12 16v5" />,
  card: <><rect x="3" y="5.5" width="18" height="13" rx="2.2" /><path d="M3 9.5h18" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l1.7-1.3-1.5-2.6-2 .5a7.6 7.6 0 0 0-2.6-1.5L14.6 3h-3l-.4 2.6a7.6 7.6 0 0 0-2.6 1.5l-2-.5-1.5 2.6 1.7 1.3a7.6 7.6 0 0 0 0 3l-1.7 1.3 1.5 2.6 2-.5a7.6 7.6 0 0 0 2.6 1.5l.4 2.6h3l.4-2.6a7.6 7.6 0 0 0 2.6-1.5l2 .5 1.5-2.6-1.7-1.3Z" /></>,
  command: <><rect x="4" y="4" width="6" height="6" rx="1.6" /><rect x="14" y="4" width="6" height="6" rx="1.6" /><rect x="4" y="14" width="6" height="6" rx="1.6" /><rect x="14" y="14" width="6" height="6" rx="1.6" /></>,
  sun: <><circle cx="12" cy="12" r="4.2" /><path d="M12 2.5v2.4M12 19.1v2.4M4.6 4.6l1.7 1.7M17.7 17.7l1.7 1.7M2.5 12h2.4M19.1 12h2.4M4.6 19.4l1.7-1.7M17.7 6.3l1.7-1.7" /></>,
  moon: <path d="M20 13.2A8.3 8.3 0 1 1 10.8 4 6.7 6.7 0 0 0 20 13.2Z" />,
  menu: <path d="M4 6h16M4 12h16M4 18h16" />,
  close: <path d="M5 5l14 14M19 5 5 19" />,
  chevronRight: <path d="M9 5l7 7-7 7" />,
  logout: <path d="M9 7V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2v-2M14 12H3m0 0 4-4m-4 4 4 4" />,
  bell: <path d="M15 17h5l-1.4-2.1A2 2 0 0 1 18 13.8V11a6 6 0 1 0-12 0v2.8a2 2 0 0 1-.6 1.1L4 17h11Zm-5.5 3a2.5 2.5 0 0 0 5 0" />,
};

export function Icon({
  name,
  className = "h-[18px] w-[18px]",
  strokeWidth = 1.8,
}: {
  name: IconName;
  className?: string;
  strokeWidth?: number;
}) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {PATHS[name]}
    </svg>
  );
}
