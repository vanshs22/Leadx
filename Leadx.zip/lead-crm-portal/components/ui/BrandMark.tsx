/**
 * LeadX brand mark — a single source of truth for the logo lockup.
 *
 * Deep-teal rounded square with a stacked "LX" wordmark and a tangerine
 * signal dot (the product's "verified signal" motif, echoed in TierBadge's
 * signal-meter). Used in the sidebar, auth screens, marketing header and
 * the browser chrome — one component instead of five copy-pasted spans.
 */
export function BrandMark({ size = 32, className = "" }: { size?: number; className?: string }) {
  const dot = Math.max(5, Math.round(size * 0.16));
  return (
    <span
      className={`relative inline-flex shrink-0 items-center justify-center rounded-[28%] bg-gradient-to-br from-brand-500 via-brand-600 to-brand-800 font-display font-bold text-white shadow-sm ${className}`}
      style={{ width: size, height: size, fontSize: size * 0.42, letterSpacing: "-0.03em" }}
    >
      LX
      <span
        className="absolute rounded-full bg-signal-500 ring-2 ring-white/90 dark:ring-slate-950/80"
        style={{ width: dot, height: dot, top: -dot * 0.18, right: -dot * 0.18 }}
      />
    </span>
  );
}
