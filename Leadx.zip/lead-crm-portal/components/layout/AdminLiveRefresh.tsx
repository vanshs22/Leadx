"use client";

import { useEffect, useRef } from "react";
import { admin } from "@/lib/admin";
import { setVisibleInterval, clearVisibleInterval } from "@/lib/live";

/**
 * Admin freshness monitor.
 *
 * Polls one cheap aggregate (only while the tab is visible) and, when it
 * changes, asks the layout to SOFT-refresh the current screen. There is no
 * full page reload any more: sidebar, scroll position of the shell and the
 * session stay intact, and nothing happens while the operator is typing.
 */
export function AdminLiveRefresh({ onChange }: { onChange?: () => void }) {
  const previous = useRef("");
  const pendingEdit = useRef(false);
  const cb = useRef(onChange);
  cb.current = onChange;

  useEffect(() => {
    let stopped = false;
    const isEditing = () => {
      const a = document.activeElement as HTMLElement | null;
      return !!a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.tagName === "SELECT" || a.isContentEditable);
    };
    const check = async () => {
      try {
        const snapshot = await admin.globalStats();
        if (stopped) return;
        const next = JSON.stringify(snapshot);
        const changed = !!previous.current && next !== previous.current;
        previous.current = next;
        if (changed || pendingEdit.current) {
          if (isEditing()) { pendingEdit.current = true; return; } // apply once the operator stops typing
          pendingEdit.current = false;
          cb.current?.();
        }
      } catch {
        // Individual admin pages surface their own errors; this monitor is only
        // a freshness signal and must never turn a healthy UI into an error page.
      }
    };
    void check();
    const timer = setVisibleInterval(check, 6000);
    return () => { stopped = true; clearVisibleInterval(timer); };
  }, []);

  return null;
}
