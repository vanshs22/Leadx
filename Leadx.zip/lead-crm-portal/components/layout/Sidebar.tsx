"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { NotificationBell } from "@/components/layout/NotificationBell";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { getTenantName, clearTenant } from "@/lib/tenant";
import { signOut } from "@/lib/auth";

import { Icon, type IconName } from "@/components/ui/Icon";
import { BrandMark } from "@/components/ui/BrandMark";

const GROUPS: { title: string; items: [string, string, IconName][] }[] = [
  { title: "Workspace", items: [
    ["/dashboard", "Overview", "home"], ["/today", "Today", "clock"], ["/intelligence", "Intelligence", "radar"], ["/agents", "Agents", "sparkles"], ["/approvals", "Approvals", "check"], ["/search", "Discover", "search"], ["/leads", "Leads", "list"], ["/pipeline", "Pipeline", "columns"],
  ]},
  { title: "Engage", items: [
    ["/sequences", "Sequences", "trending"], ["/automations", "Automations", "zap"], ["/compose", "Write email", "pencil"], ["/replies", "Replies", "reply"], ["/activities", "Activity", "activity"],
  ]},
  { title: "Measure", items: [
    ["/reports", "Reports", "bar"], ["/revenue", "Revenue", "trending"], ["/reports/deals", "Deal revenue", "dollar"], ["/logs", "Logs", "logs"],
  ]},
  { title: "Workspace settings", items: [
    ["/team", "Team", "users"], ["/settings/integrations", "Integrations", "plug"], ["/settings/billing", "Billing", "card"], ["/settings", "Settings", "settings"],
  ]},
];

export function Sidebar() {
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);

  async function handleSignOut() {
    try { clearTenant(); await signOut(); } catch {}
    router.replace("/login");
  }

  return <>
    <div className="fixed inset-x-0 top-0 z-40 flex h-14 items-center gap-2.5 border-b border-line bg-[rgb(var(--sidebar))]/95 px-3 backdrop-blur-xl md:hidden">
      <button type="button" aria-label="Open navigation" onClick={() => setOpen(true)} className="icon-button h-9 w-9"><Icon name="menu" className="h-4 w-4" /></button>
      <BrandMark size={30} />
      <span className="brand-wordmark text-[15px]">LeadX</span>
      <span className="ml-auto"><NotificationBell /></span>
    </div>
    {open && <button type="button" aria-label="Close navigation" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-slate-950/40 backdrop-blur-[2px] md:hidden" />}
    <aside className={`fixed inset-y-0 left-0 z-50 flex w-[260px] flex-col border-r border-[rgb(var(--sidebar-border))] bg-[rgb(var(--sidebar))] transition-transform duration-200 md:static md:z-auto md:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}>
      <div className="border-b border-line px-4 py-4">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <BrandMark size={34} />
          <span className="brand-wordmark">LeadX</span>
        </Link>
        <div className="mt-3 flex items-center justify-between rounded-xl border border-line/80 bg-surface-2 px-2.5 py-2">
          <div className="min-w-0"><div className="truncate text-xs font-semibold text-ink">{typeof window !== "undefined" ? getTenantName() || "Workspace" : "Workspace"}</div><div className="text-[10px] text-ink-faint">Lead intelligence</div></div>
          <span className="live-dot" />
        </div>
      </div>
      <nav className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
        {GROUPS.map((group) => <div key={group.title} className="mb-5 last:mb-0">
          <div className="px-2 pb-1.5 text-[9px] font-bold uppercase tracking-[.14em] text-ink-faint">{group.title}</div>
          <div className="space-y-0.5">
            {group.items.map(([href, label, icon]) => {
              const active = path === href || (href !== "/reports" && path?.startsWith(href + "/"));
              return <Link key={href} href={href} className={`group flex items-center gap-3 rounded-xl px-2.5 py-2 text-[13px] font-medium transition-all ${active ? "bg-brand-50 text-brand-800 shadow-sm dark:bg-brand-500/15 dark:text-brand-200" : "text-ink-muted hover:bg-surface-3 hover:text-ink"}`}>
                <Icon name={icon} className={`h-[17px] w-[17px] shrink-0 transition-transform ${active ? "scale-105" : "opacity-70 group-hover:opacity-100"}`} />
                <span>{label}</span>
              </Link>;
            })}
          </div>
        </div>)}
      </nav>
      <div className="border-t border-line p-3">
        <Link href="/search" className="mb-2 flex items-center justify-between rounded-xl border border-line bg-surface-2 px-3 py-2.5 text-xs font-semibold text-ink transition hover:border-brand-300">
          <span className="flex items-center gap-2"><Icon name="search" className="h-3.5 w-3.5" />Find prospects</span>
          <kbd className="rounded border border-line bg-surface-3 px-1.5 py-0.5 text-[9px] text-ink-faint">⌘K</kbd>
        </Link>
        <div className="mb-2"><ThemeToggle className="w-full" /></div>
        <button aria-label="Sign out" type="button" onClick={handleSignOut} className="flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-left text-xs font-medium text-ink-muted transition hover:bg-rust-50 hover:text-rust-600 dark:hover:bg-rust-500/10 dark:hover:text-rust-300">
          <Icon name="logout" className="h-3.5 w-3.5" />Sign out
        </button>
      </div>
    </aside>
  </>;
}
