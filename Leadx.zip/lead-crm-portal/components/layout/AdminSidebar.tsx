"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { NotificationBell } from "@/components/layout/NotificationBell";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { clearAdminKey } from "@/lib/admin";

const NAV = [
  { href: "/admin", label: "Overview", exact: true },
  { href: "/admin/tenants", label: "Clients" },
  { href: "/admin/health", label: "Tenant health" },
  { href: "/admin/territory", label: "Territory" },
  { href: "/admin/icps", label: "ICPs" },
  { href: "/admin/discovery", label: "Discovery approvals" },
  { href: "/admin/search", label: "Search & email" },
  { href: "/admin/pipeline", label: "Pipeline" },
  { href: "/admin/automation", label: "Automation" },
  { href: "/admin/autonomous", label: "Autonomous growth" },
  { href: "/admin/runs", label: "Run history" },
  { href: "/admin/leads", label: "Leads" },
  { href: "/admin/jobs", label: "Jobs" },
  { href: "/admin/notifications", label: "Notifications" },
  { href: "/admin/support", label: "Support inbox" },
  { href: "/admin/replies", label: "Replies" },
  { href: "/admin/prospecting", label: "Our prospecting" },
  { href: "/admin/keys", label: "API keys" },
  { href: "/admin/usage", label: "Usage & billing" },
  { href: "/admin/suppression", label: "Suppression" },
  { href: "/admin/intelligence", label: "Intelligence" },
  { href: "/admin/ops", label: "Ops health" },
  { href: "/admin/scale", label: "Scale & reliability" },
  { href: "/admin/security", label: "Security & audit" },
];

// Operator view uses the signal-teal accent (distinct from the client
// portal's brass) — a deliberate cue you're in the control room, not
// the client-facing product.
export function AdminSidebar() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [path]);
  return (
    <>
      <div className="fixed inset-x-0 top-0 z-40 flex items-center border-b border-line bg-[rgb(var(--sidebar))] px-3 py-2 md:hidden">
        <button aria-label="Open operator navigation" onClick={() => setOpen(true)} className="h-8 w-8 rounded-lg border border-line bg-surface text-ink">☰</button>
        <span className="ml-3 font-display text-sm font-semibold text-ink">LeadX Operator</span>
        <span className="ml-auto"><NotificationBell scope="admin" /></span>
      </div>
      {open && <button aria-label="Close operator navigation" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-black/40 md:hidden" />}
      <aside className={`sticky top-0 z-50 flex h-[100dvh] max-h-[100dvh] w-64 shrink-0 flex-col border-r border-line bg-[rgb(var(--sidebar))] transition-transform md:static md:w-60 md:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}>
      <div className="border-b border-line px-4 py-5 pt-14 md:pt-5">
        <div className="mb-3 flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 via-brand-600 to-signal-500 text-xs font-black text-white">LX</span>
          <div><div className="text-[10px] font-bold uppercase tracking-[0.14em] text-brand-700 dark:text-brand-300">LeadX</div><div className="text-[11px] text-ink-faint">Control plane</div></div>
        </div>
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="font-mono text-[10px] font-semibold uppercase tracking-[0.15em] text-signal-600 dark:text-signal-400">
              Operator
            </div>
            <div className="mt-1 font-display text-sm font-semibold text-ink">Lead Admin</div>
          </div>
          <NotificationBell scope="admin" />
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto p-3">
        <div className="mb-2 px-3 pt-1 text-[9px] font-bold uppercase tracking-[0.16em] text-ink-faint">Operations</div>
        {NAV.map((item, index) => {
          const active = item.exact ? path === item.href : path?.startsWith(item.href);
          return (
            <div key={item.href}>
            {index === 5 && <div className="mb-2 mt-4 px-3 pt-1 text-[9px] font-bold uppercase tracking-[0.16em] text-ink-faint">Revenue & intelligence</div>}
            <Link
              href={item.href}
              aria-current={active ? "page" : undefined}
              className={
                active
                  ? "block rounded-xl2 border-l-2 border-brand-500 bg-signal-50 px-3 py-2 text-sm font-medium text-signal-800 dark:bg-signal-500/15 dark:text-signal-300"
                  : "block rounded-xl2 border-l-2 border-transparent px-3 py-2 text-sm text-ink-muted hover:bg-surface-3 hover:text-ink"
              }
            >
              {item.label}
            </Link>
            </div>
          );
        })}
      </nav>
      <div className="space-y-2 border-t border-line p-3">
        <ThemeToggle className="w-full" />
        <button aria-label="Action"
          className="btn-ghost w-full text-xs"
          onClick={() => {
            clearAdminKey();
            window.location.href = "/admin/login";
          }}
        >
          Sign out
        </button>
      </div>
      </aside>
    </>
  );
}
