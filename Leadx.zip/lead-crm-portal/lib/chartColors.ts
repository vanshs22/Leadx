/**
 * Mirrors the brand/signal/rust scales in tailwind.config.js. Recharts
 * renders SVG fill/stroke as literal attributes, which can't resolve
 * CSS custom properties the way Tailwind classes can — so chart color
 * gets its own small constant file instead of trying to read theme
 * variables at runtime. Keep in sync with tailwind.config.js by hand.
 */
export const chartColors = {
  brand: { 300: "#72D2C1", 400: "#3FBDA8", 500: "#168C7A", 600: "#0F766E" },
  signal: { 300: "#FFAA6B", 400: "#FF8A3D", 500: "#F46B22", 600: "#D95412" },
  rust: { 300: "#FF8E70", 400: "#F86A49", 500: "#DF4B2F", 600: "#BC3823" },
};

export function tierColor(tier: string, dark = false) {
  const t = (tier || "C").toUpperCase();
  if (t === "A") return dark ? chartColors.brand[400] : chartColors.brand[500];
  if (t === "B") return dark ? chartColors.signal[400] : chartColors.signal[500];
  return dark ? chartColors.rust[400] : chartColors.rust[500];
}

// Even-stepped brass shades for funnel stages — darker brass = further
// down the funnel, so "closer to won" visually reads as more saturated.
export const funnelShades = [
  chartColors.brand[300],
  chartColors.brand[400],
  chartColors.brand[500],
  chartColors.brand[600],
  chartColors.signal[500],
];
