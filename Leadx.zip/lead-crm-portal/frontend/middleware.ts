import { NextRequest, NextResponse } from "next/server";

/**
 * LeadX portal URL compatibility layer.
 *
 * The current Next app exposes tenant/client CRM pages at the root paths
 * (/dashboard, /leads, /pipeline, ...). Older deployments and bookmarks used
 * /client/*, /portal/*, and /crm/* for those same browser pages. Those prefixes
 * are NOT Next route groups and therefore produced a real 404 when opened
 * directly. Normalize those legacy browser URLs before Next resolves routes.
 *
 * /backend/* is deliberately excluded: it is the API proxy used by the CRM.
 */
const PORTAL_PREFIXES = ["/client", "/portal"];
const PORTAL_ROUTES = new Set([
  "dashboard", "today", "search", "leads", "companies", "contacts", "deals",
  "sequences", "compose", "replies", "notifications", "pipeline", "activities",
  "reports", "revenue", "import", "team", "docs", "settings", "login",
  "accept-invite",
]);

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname === "/backend" || pathname.startsWith("/backend/")) {
    return NextResponse.next();
  }

  for (const prefix of PORTAL_PREFIXES) {
    if (pathname === prefix || pathname.startsWith(`${prefix}/`)) {
      const rest = pathname.slice(prefix.length) || "/";
      const first = rest.replace(/^\//, "").split("/")[0];
      if (!first || PORTAL_ROUTES.has(first)) {
        const url = req.nextUrl.clone();
        url.pathname = rest === "/" || !rest ? "/dashboard" : rest;
        return NextResponse.redirect(url, 308);
      }
    }
  }

  // Older client URLs also used /crm/<page>. Normalize both /crm and /crm/<page>;
  // API traffic never goes through this frontend prefix (it uses /backend).
  if (pathname === "/crm") {
    const url = req.nextUrl.clone();
    url.pathname = "/dashboard";
    return NextResponse.redirect(url, 308);
  }
  if (pathname.startsWith("/crm/")) {
    const rest = pathname.slice("/crm".length);
    const first = rest.replace(/^\//, "").split("/")[0];
    if (PORTAL_ROUTES.has(first)) {
      const url = req.nextUrl.clone();
      url.pathname = rest;
      return NextResponse.redirect(url, 308);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
