/** @type {import('next').NextConfig} */
const fs = require("fs");
const path = require("path");

/** Load KEY=VAL from a file into process.env (does not override existing). */
function loadEnvFile(filePath) {
  try {
    if (!fs.existsSync(filePath)) return;
    const text = fs.readFileSync(filePath, "utf8");
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("#")) continue;
      const eq = line.indexOf("=");
      if (eq <= 0) continue;
      const key = line.slice(0, eq).trim();
      let val = line.slice(eq + 1).trim();
      if (
        (val.startsWith('"') && val.endsWith('"')) ||
        (val.startsWith("'") && val.endsWith("'"))
      ) {
        val = val.slice(1, -1);
      }
      if (key && process.env[key] === undefined) {
        process.env[key] = val;
      }
    }
  } catch (e) {
    console.warn("[next.config] loadEnvFile failed:", filePath, e.message);
  }
}

// 1) frontend .env.local  2) backend .env (fallback for Supabase URL/keys)
loadEnvFile(path.join(__dirname, ".env.local"));
loadEnvFile(path.join(__dirname, ".env"));
loadEnvFile(path.join(__dirname, "..", "..", "lead-engine-v2", ".env"));

// Map backend names → NEXT_PUBLIC so client login always gets a URL
if (!process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_URL) {
  process.env.NEXT_PUBLIC_SUPABASE_URL = process.env.SUPABASE_URL.trim();
}
if (!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY && process.env.SUPABASE_ANON_KEY) {
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY.trim();
}

const SUPA_URL = (process.env.NEXT_PUBLIC_SUPABASE_URL || "").trim();
const SUPA_ANON = (process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "").trim();
const API_UPSTREAM =
  process.env.API_UPSTREAM ||
  process.env.NEXT_PUBLIC_API_URL ||
  "http://127.0.0.1:8000";

console.log(
  "[next.config] Supabase URL for client:",
  SUPA_URL ? SUPA_URL.slice(0, 40) + "…" : "(EMPTY — client /login will fail)"
);

const nextConfig = {
  reactStrictMode: true,
  // Force-embed into the browser bundle (fixes stale/missing NEXT_PUBLIC_*)
  env: {
    NEXT_PUBLIC_SUPABASE_URL: SUPA_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: SUPA_ANON,
  },
  async rewrites() {
    return [
      {
        source: "/backend/:path*",
        destination: `${API_UPSTREAM.replace(/\/$/, "")}/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
