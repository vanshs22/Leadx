/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // LeadX Deep Teal / Tangerine identity — premium B2B, not a generic AI gradient.
        brand: {
          50: "#E7F8F4", 100: "#D2F1EB", 200: "#A7E3D8", 300: "#72D2C1",
          400: "#3FBDA8", 500: "#168C7A", 600: "#0F766E", 700: "#0D625D",
          800: "#0B4F4B", 900: "#083B39",
        },
        signal: {
          50: "#FFF4EA", 100: "#FFE4CE", 200: "#FFC89E", 300: "#FFAA6B",
          400: "#FF8A3D", 500: "#F46B22", 600: "#D95412", 700: "#B8420D",
          800: "#92340B", 900: "#6F2808",
        },
        rust: {
          50: "#FFF1EC", 100: "#FFDCCF", 200: "#FFB9A3", 300: "#FF8E70",
          400: "#F86A49", 500: "#DF4B2F", 600: "#BC3823", 700: "#982D1D",
          800: "#702318", 900: "#4B1811",
        },
        surface: {
          DEFAULT: "rgb(var(--surface) / <alpha-value>)",
          2: "rgb(var(--surface-2) / <alpha-value>)",
          3: "rgb(var(--surface-3) / <alpha-value>)",
        },
        ink: {
          DEFAULT: "rgb(var(--ink) / <alpha-value>)",
          muted: "rgb(var(--ink-muted) / <alpha-value>)",
          faint: "rgb(var(--ink-faint) / <alpha-value>)",
        },
        line: "rgb(var(--line) / <alpha-value>)",
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif", "system-ui", "sans-serif"],
        sans: [
          "var(--font-sans)",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px rgb(15 23 42 / .05), 0 10px 30px rgb(15 23 42 / .07)",
        lift: "0 18px 50px rgb(15 23 42 / .14)",
        glow: "0 0 0 1px rgb(22 140 122 / .18), 0 12px 36px rgb(22 140 122 / .15)",
      },
      borderRadius: {
        xl2: "0.625rem",
      },
    },
  },
  plugins: [],
};
