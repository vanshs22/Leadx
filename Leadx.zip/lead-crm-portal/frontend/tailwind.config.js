/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // LeadX Cobalt / Saffron identity — distinctive, high-contrast, not a generic AI gradient.
        brand: {
          50: "#EFF4FF", 100: "#DCE7FF", 200: "#B9CEFF", 300: "#8EAEFF",
          400: "#5E86F5", 500: "#2F63D7", 600: "#2451B8", 700: "#1D4298",
          800: "#193678", 900: "#142955",
        },
        signal: {
          50: "#FFF8E7", 100: "#FFEDB8", 200: "#FFDB70", 300: "#FFC83D",
          400: "#FFB91F", 500: "#F4A900", 600: "#D88F00", 700: "#B87500",
          800: "#8F5C00", 900: "#674100",
        },
        rust: {
          50: "#FFF1EC", 100: "#FFDCCF", 200: "#FFB9A3", 300: "#FF8E70",
          400: "#F86A49", 500: "#DF4B2F", 600: "#BC3823", 700: "#982D1D",
          800: "#702318", 900: "#4B1811",
        },
        surface: {
          DEFAULT: "rgb(var(--surface) / <alpha-value>)",
          2: "rgb(var(--surface-2) / <alpha-value>)",
          3: "rgb(var(--surface-3) / <alpha-value>)",
        },
        ink: {
          DEFAULT: "rgb(var(--ink) / <alpha-value>)",
          muted: "rgb(var(--ink-muted) / <alpha-value>)",
          faint: "rgb(var(--ink-faint) / <alpha-value>)",
        },
        line: "rgb(var(--line) / <alpha-value>)",
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif", "system-ui", "sans-serif"],
        sans: [
          "var(--font-sans)",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px rgb(15 23 42 / .05), 0 10px 30px rgb(15 23 42 / .07)",
        lift: "0 18px 50px rgb(15 23 42 / .14)",
        glow: "0 0 0 1px rgb(47 99 215 / .16), 0 12px 36px rgb(47 99 215 / .13)",
      },
      borderRadius: {
        xl2: "0.625rem",
      },
    },
  },
  plugins: [],
};
