/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // "Brass" — verified/gold-standard signal. Replaces stock indigo.
        brand: {
          50: "#F1EEFF",
          100: "#E5DFFF",
          200: "#CEC4FF",
          300: "#B5A6FF",
          400: "#9B88FF",
          500: "#7C63F6",
          600: "#6348E8",
          700: "#5136C7",
          800: "#3F2B9D",
          900: "#2C216E",
        },
        // "Signal" teal — verified contact data, secondary actions.
        signal: {
          50: "#ECFEFF",
          100: "#CFFAFE",
          200: "#A5F3FC",
          300: "#67E8F9",
          400: "#22D3EE",
          500: "#06B6D4",
          600: "#0891B2",
          700: "#0E7490",
          800: "#155E75",
          900: "#164E63",
        },
        // "Rust" — tier C / muted alerts. Deliberately not stock red.
        rust: {
          50: "#FBEFEC",
          100: "#F2D6CE",
          200: "#E3AC9C",
          300: "#D3826A",
          400: "#C2643F",
          500: "#B0503F",
          600: "#8F3F31",
          700: "#6E3025",
          800: "#4E221A",
          900: "#301511",
        },
        surface: {
          DEFAULT: "rgb(var(--surface) / <alpha-value>)",
          2: "rgb(var(--surface-2) / <alpha-value>)",
          3: "rgb(var(--surface-3) / <alpha-value>)",
        },
        ink: {
          DEFAULT: "rgb(var(--ink) / <alpha-value>)",
          muted: "rgb(var(--ink-muted) / <alpha-value>)",
          faint: "rgb(var(--ink-faint) / <alpha-value>)",
        },
        line: "rgb(var(--line) / <alpha-value>)",
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif", "system-ui", "sans-serif"],
        sans: [
          "var(--font-sans)",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px rgb(15 23 42 / .05), 0 10px 30px rgb(15 23 42 / .07)",
        lift: "0 18px 50px rgb(15 23 42 / .14)",
        glow: "0 0 0 1px rgb(124 99 246 / .14), 0 12px 36px rgb(124 99 246 / .12)",
      },
      borderRadius: {
        xl2: "0.625rem",
      },
    },
  },
  plugins: [],
};
