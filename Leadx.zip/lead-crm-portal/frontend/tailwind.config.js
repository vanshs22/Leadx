/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // "Brass" — verified/gold-standard signal. Replaces stock indigo.
        brand: {
          50: "#FBF6EA",
          100: "#F3E7C9",
          200: "#E6CD95",
          300: "#D6AF68",
          400: "#C6994F",
          500: "#B3853F",
          600: "#966D31",
          700: "#785527",
          800: "#5A3F1E",
          900: "#3D2A14",
        },
        // "Signal" teal — verified contact data, secondary actions.
        signal: {
          50: "#EDF6F3",
          100: "#D1E9E2",
          200: "#A3D3C4",
          300: "#75BCA7",
          400: "#52A78D",
          500: "#3D8E77",
          600: "#2F715F",
          700: "#24594B",
          800: "#1A4137",
          900: "#112C25",
        },
        // "Rust" — tier C / muted alerts. Deliberately not stock red.
        rust: {
          50: "#FBEFEC",
          100: "#F2D6CE",
          200: "#E3AC9C",
          300: "#D3826A",
          400: "#C2643F",
          500: "#B0503F",
          600: "#8F3F31",
          700: "#6E3025",
          800: "#4E221A",
          900: "#301511",
        },
        surface: {
          DEFAULT: "rgb(var(--surface) / <alpha-value>)",
          2: "rgb(var(--surface-2) / <alpha-value>)",
          3: "rgb(var(--surface-3) / <alpha-value>)",
        },
        ink: {
          DEFAULT: "rgb(var(--ink) / <alpha-value>)",
          muted: "rgb(var(--ink-muted) / <alpha-value>)",
          faint: "rgb(var(--ink-faint) / <alpha-value>)",
        },
        line: "rgb(var(--line) / <alpha-value>)",
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif", "system-ui", "sans-serif"],
        sans: [
          "var(--font-sans)",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        mono: ["var(--font-mono)", "ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      boxShadow: {
        card: "0 1px 2px rgb(15 23 42 / 0.04), 0 8px 24px rgb(15 23 42 / 0.05)",
        lift: "0 12px 40px rgb(15 23 42 / 0.1)",
      },
      borderRadius: {
        xl2: "0.625rem",
      },
    },
  },
  plugins: [],
};
