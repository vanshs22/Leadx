#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "==> Cleaning Next/TypeScript build cache"
npm run clean
echo "==> Starting LeadX frontend on :3000"
exec npm run dev
