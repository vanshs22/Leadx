#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "==> Clearing Next cache (.next) so env is re-read"
rm -rf .next
echo "==> Starting Next on :3000"
exec npm run dev -- -p 3000
