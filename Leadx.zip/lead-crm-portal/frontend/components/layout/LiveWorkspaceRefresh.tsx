"use client";

/**
 * Intentionally empty. Realtime is a cache-invalidation signal, not a reason
 * to reload the entire application. Individual screens subscribe with
 * useCrmChange() and refetch only their authoritative data.
 *
 * A global location.reload() here caused a thundering-herd effect: one CRM
 * change could force every connected client to reload simultaneously.
 */
export function LiveWorkspaceRefresh() {
  return null;
}
