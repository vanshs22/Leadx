"use client";

import { useEffect, useRef, useState } from "react";
import { useCrmRealtime } from "@/lib/crmRealtime";
import { getTenantId } from "@/lib/tenant";

/**
 * Keeps pages that fetch data locally in sync too. Individual screens can use
 * useCrmChange for a smooth in-place refresh; this is the safety net that
 * guarantees cards that don't subscribe individually never stay stale.
 * It waits while a user is editing a form instead of destroying their input.
 */
export function LiveWorkspaceRefresh() {
  const [tenantId, setTenantId] = useState("");
  useEffect(() => {
    const check = () => setTenantId(getTenantId());
    check();
    const timer = window.setInterval(check, 1000);
    return () => window.clearInterval(timer);
  }, []);

  const pending = useRef(false);
  const reloadTimer = useRef<number | null>(null);

  useCrmRealtime(() => {
    if (pending.current) return;
    pending.current = true;
    const schedule = () => {
      const active = document.activeElement as HTMLElement | null;
      const editing = !!active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA" || active.tagName === "SELECT" || active.isContentEditable);
      if (editing) {
        reloadTimer.current = window.setTimeout(schedule, 1500);
        return;
      }
      window.location.reload();
    };
    reloadTimer.current = window.setTimeout(schedule, 650);
  }, tenantId);

  useEffect(() => () => {
    if (reloadTimer.current) window.clearTimeout(reloadTimer.current);
  }, []);

  return null;
}
