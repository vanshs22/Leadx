"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { clearAdminKey } from "@/lib/admin";

const NAV = [
  { href: "/admin", label: "Overview", exact: true },
  { href: "/admin/tenants", label: "Clients" },
  { href: "/admin/health", label: "Tenant health" },
  { href: "/admin/territory", label: "Territory" },
  { href: "/admin/icps", label: "ICPs" },
  { href: "/admin/search", label: "Search & email" },
  { href: "/admin/pipeline", label: "Pipeline" },
  { href: "/admin/runs", label: "Run history" },
  { href: "/admin/leads", label: "Leads" },
  { href: "/admin/keys", label: "API keys" },
  { href: "/admin/usage", label: "Usage & billing" },
  { href: "/admin/suppression", label: "Suppression" },
  { href: "/admin/intelligence", label: "Intelligence" },
  { href: "/admin/ops", label: "Ops health" },
];

export function AdminSidebar() {
  const path = usePathname();
  return (
    <aside className="flex h-screen w-56 shrink-0 flex-col border-r border-line bg-[rgb(var(--sidebar))]">
      <div className="border-b border-line px-4 py-5">
        <div className="text-[11px] font-semibold uppercase tracking-widest text-amber-600 dark:text-amber-400">
          Operator
        </div>
        <div className="mt-1 text-sm font-semibold text-ink">Lead Admin</div>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto p-3">
        {NAV.map((item) => {
          const active = item.exact ? path === item.href : path?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={
                active
                  ? "block rounded-xl bg-amber-50 px-3 py-2 text-sm font-medium text-amber-900 dark:bg-amber-500/15 dark:text-amber-200"
                  : "block rounded-xl px-3 py-2 text-sm text-ink-muted hover:bg-surface-3 hover:text-ink"
              }
            >
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="space-y-2 border-t border-line p-3">
        <ThemeToggle className="w-full" />
        <button
          className="btn-ghost w-full text-xs"
          onClick={() => {
            clearAdminKey();
            window.location.href = "/admin/login";
          }}
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
