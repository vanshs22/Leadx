"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "@/components/theme/ThemeProvider";

const OPS = [
  { href: "/admin", label: "Overview", icon: "◆" },
  { href: "/admin/pipeline", label: "Pipeline", icon: "▶" },
  { href: "/admin/runs", label: "Run history", icon: "◷" },
  { href: "/admin/leads", label: "Client leads", icon: "◎" },
  { href: "/admin/icps", label: "ICPs", icon: "◎" },
  { href: "/admin/tenants", label: "Clients", icon: "♟" },
];

const SYSTEM = [
  { href: "/admin/keys", label: "API keys", icon: "⚙" },
  { href: "/admin/ops", label: "Ops health", icon: "♥" },
  { href: "/admin/health", label: "Health", icon: "+" },
  { href: "/admin/suppression", label: "Suppression", icon: "✕" },
  { href: "/admin/usage", label: "Usage", icon: "▤" },
  { href: "/admin/territory", label: "Territory", icon: "▣" },
  { href: "/admin/intelligence", label: "Intelligence", icon: "◇" },
  { href: "/admin/search", label: "Search & email", icon: "⌕" },
];

function NavItem({ href, label, icon }: { href: string; label: string; icon: string }) {
  const path = usePathname();
  const active =
    href === "/admin" ? path === "/admin" : path === href || path?.startsWith(href + "/");
  return (
    <Link href={href} className={`nav-link ${active ? "nav-link-active" : ""}`}>
      <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-3 text-xs opacity-90">
        {icon}
      </span>
      <span>{label}</span>
    </Link>
  );
}

export function AdminSidebar() {
  return (
    <aside className="flex w-[260px] shrink-0 flex-col border-r border-[rgb(var(--sidebar-border))] bg-[rgb(var(--sidebar))]">
      <div className="flex items-center gap-3 border-b border-line px-4 py-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[rgb(var(--brand))] text-sm font-bold text-white">
          Lx
        </div>
        <div>
          <div className="text-sm font-semibold text-ink">LeadX Admin</div>
          <div className="text-[11px] text-ink-faint">Operator console</div>
        </div>
      </div>

      <nav className="flex flex-1 flex-col overflow-y-auto px-2 pb-3">
        <div className="nav-section">Operations</div>
        {OPS.map((item) => (
          <NavItem key={item.href} {...item} />
        ))}
        <div className="nav-section">System</div>
        {SYSTEM.map((item) => (
          <NavItem key={item.href} {...item} />
        ))}
      </nav>

      <div className="border-t border-line p-3">
        <ThemeToggle />
        <Link href="/dashboard" className="btn-ghost mt-2 w-full justify-start text-xs">
          ← Client CRM
        </Link>
      </div>
    </aside>
  );
}
