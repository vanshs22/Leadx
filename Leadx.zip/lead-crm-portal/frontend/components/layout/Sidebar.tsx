"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { getTenantName, clearTenant } from "@/lib/tenant";

const GENERAL = [
  { href: "/dashboard", label: "Dashboard", icon: "◆" },
  { href: "/search", label: "Search", icon: "⌕" },
  { href: "/leads", label: "Leads", icon: "◎" },
  { href: "/companies", label: "Companies", icon: "▣" },
  { href: "/contacts", label: "Contacts", icon: "☺" },
  { href: "/deals", label: "Deals", icon: "◇" },
  { href: "/pipeline", label: "Pipeline", icon: "☰" },
  { href: "/activities", label: "Activity", icon: "◷" },
];

const SUPPORT = [
  { href: "/reports", label: "Reports", icon: "▤" },
  { href: "/team", label: "Team", icon: "♟" },
  { href: "/docs", label: "Docs", icon: "☰" },
  { href: "/onboarding", label: "Get started", icon: "→" },
  { href: "/settings", label: "Settings", icon: "⚙" },
];

function NavItem({ href, label, icon }: { href: string; label: string; icon: string }) {
  const path = usePathname();
  const active = path === href || (href !== "/dashboard" && path?.startsWith(href));
  return (
    <Link href={href} className={`nav-link ${active ? "nav-link-active" : ""}`}>
      <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-3 text-xs opacity-90">
        {icon}
      </span>
      <span>{label}</span>
    </Link>
  );
}

export function Sidebar() {
  const name = typeof window !== "undefined" ? getTenantName() || "Workspace" : "Workspace";
  return (
    <aside className="flex w-[260px] shrink-0 flex-col border-r border-[rgb(var(--sidebar-border))] bg-[rgb(var(--sidebar))]">
      <div className="flex items-center gap-3 border-b border-line px-4 py-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[rgb(var(--brand))] text-sm font-bold text-white shadow-sm">
          Lx
        </div>
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold tracking-tight text-ink">LeadX CRM</div>
          <div className="truncate text-[11px] text-ink-faint">{name}</div>
        </div>
      </div>

      <nav className="flex flex-1 flex-col overflow-y-auto px-2 pb-3">
        <div className="nav-section">General</div>
        {GENERAL.map((item) => (
          <NavItem key={item.href} {...item} />
        ))}
        <div className="nav-section">Workspace</div>
        {SUPPORT.map((item) => (
          <NavItem key={item.href} {...item} />
        ))}
      </nav>

      <div className="border-t border-line p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <ThemeToggle />
          <button
            type="button"
            className="btn-ghost text-xs"
            onClick={() => {
              clearTenant();
              window.location.href = "/dashboard";
            }}
          >
            Switch
          </button>
        </div>
        <div className="rounded-xl border border-line bg-surface-3/50 px-3 py-2.5">
          <div className="truncate text-xs font-medium text-ink">{name}</div>
          <div className="text-[10px] text-ink-faint">Active workspace</div>
        </div>
      </div>
    </aside>
  );
}
