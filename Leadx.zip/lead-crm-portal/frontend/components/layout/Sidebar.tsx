"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { getTenantName, clearTenant } from "@/lib/tenant";

const NAV = [
  { href: "/dashboard", label: "Home", hint: "Overview & next steps" },
  // Search disabled for clients — admin delivers leads; re-enable later if needed
  // { href: "/search", label: "Search", hint: "Find leads → email" },
  { href: "/leads", label: "Leads", hint: "Call, email, export" },
  { href: "/pipeline", label: "Pipeline", hint: "Stages & deals" },
  { href: "/activities", label: "Activity", hint: "Calls & notes" },
  { href: "/reports", label: "Reports", hint: "Wins & quality" },
  { href: "/team", label: "Team", hint: "Members & roles" },
  { href: "/docs", label: "Docs", hint: "Contracts & invoices" },
  { href: "/settings", label: "Settings", hint: "Account & weights" },
];

export function Sidebar() {
  const path = usePathname();
  return (
    <aside className="flex w-60 shrink-0 flex-col border-r border-[rgb(var(--sidebar-border))] bg-[rgb(var(--sidebar))]">
      <div className="border-b border-line px-4 py-5">
        <div className="text-sm font-semibold tracking-tight text-ink">Lead CRM</div>
        <div className="mt-0.5 text-xs text-ink-faint">
          {typeof window !== "undefined" ? getTenantName() || "Workspace" : "Workspace"}
        </div>
        <button
          type="button"
          className="mt-2 text-[11px] text-brand-600 hover:underline dark:text-brand-300"
          onClick={() => {
            clearTenant();
            window.location.href = "/dashboard";
          }}
        >
          Switch workspace
        </button>
      </div>

      <nav className="flex flex-1 flex-col gap-0.5 p-3">
        {NAV.map((item) => {
          const active = path === item.href || path?.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={active ? "sidebar-link-active" : "sidebar-link"}
            >
              <div>
                <div>{item.label}</div>
                <div className="text-[11px] font-normal text-ink-faint">{item.hint}</div>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="space-y-3 border-t border-line p-3">
        <ThemeToggle className="w-full" />
        <div className="rounded-xl border border-line bg-surface-3/60 p-3 text-[11px] leading-relaxed text-ink-muted">
          New batches land here automatically. Filter <strong className="text-ink">Tier A</strong> first.
        </div>
      </div>
    </aside>
  );
}
