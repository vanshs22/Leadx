"use client";

import { useEffect, useRef } from "react";
import { admin } from "@/lib/admin";

/** Admin safety-net for screens that fetch their own data. Polls a cheap aggregate
 * and refreshes the whole control plane only when the aggregate actually changes. */
export function AdminLiveRefresh() {
  const previous = useRef("");
  const pending = useRef(false);

  useEffect(() => {
    let stopped = false;
    const check = async () => {
      try {
        const snapshot = await admin.globalStats();
        if (stopped) return;
        const next = JSON.stringify(snapshot);
        if (previous.current && next !== previous.current && !pending.current) {
          pending.current = true;
          const active = document.activeElement as HTMLElement | null;
          const editing = !!active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA" || active.tagName === "SELECT" || active.isContentEditable);
          if (!editing) window.location.reload();
          else pending.current = false;
        }
        previous.current = next;
      } catch {
        // Individual admin pages surface their own errors; this monitor is only
        // a freshness signal and must never turn a healthy UI into an error page.
      }
    };
    void check();
    const timer = window.setInterval(check, 5000);
    return () => { stopped = true; window.clearInterval(timer); };
  }, []);

  return null;
}
