/**
 * Shared empty / loading / error states.
 *
 * Every table and panel in the portal was rolling its own "no rows" div and
 * its own spinner, and several just rendered nothing at all — which is how a
 * failed fetch ended up looking identical to an empty result set. One set of
 * primitives so the three states are always visually distinct.
 */
import type { ReactNode } from "react";

export function EmptyState({
  title,
  hint,
  action,
  icon,
}: {
  title: string;
  hint?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-14 text-center">
      {icon ? <div className="mb-1 text-ink-faint">{icon}</div> : null}
      <p className="text-sm font-medium text-ink">{title}</p>
      {hint ? <p className="max-w-sm text-xs text-ink-muted">{hint}</p> : null}
      {action ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}

/** Skeleton rows sized to a table, so layout doesn't jump when data lands. */
export function LoadingRows({ rows = 5, cols = 4 }: { rows?: number; cols?: number }) {
  return (
    <div className="animate-pulse divide-y divide-line" aria-busy="true" aria-live="polite">
      <span className="sr-only">Loading…</span>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="flex gap-4 px-4 py-3">
          {Array.from({ length: cols }).map((_, c) => (
            <div
              key={c}
              className="h-3 rounded bg-surface-3"
              style={{ width: c === 0 ? "28%" : `${Math.max(10, 22 - c * 3)}%` }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

export function ErrorState({
  error,
  onRetry,
}: {
  error: unknown;
  onRetry?: () => void;
}) {
  const msg =
    error instanceof Error
      ? error.message
      : typeof error === "string"
        ? error
        : "Something went wrong.";
  return (
    <div role="alert" className="mx-4 my-6 rounded-lg border border-rust-300/60 bg-rust-50/60 px-4 py-3 dark:bg-transparent">
      <p className="text-sm font-medium text-ink">Couldn&apos;t load this</p>
      <p className="mt-1 break-words text-xs text-ink-muted">{msg}</p>
      {onRetry ? (
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 rounded-md border border-line px-2.5 py-1 text-xs font-medium text-ink hover:bg-surface-2"
        >
          Retry
        </button>
      ) : null}
    </div>
  );
}

/**
 * The whole decision tree in one call, so a page can't accidentally render an
 * empty state while a request is still in flight or has failed.
 */
export function DataState({
  loading,
  error,
  isEmpty,
  empty,
  onRetry,
  children,
  skeleton,
}: {
  loading: boolean;
  error?: unknown;
  isEmpty?: boolean;
  empty?: ReactNode;
  onRetry?: () => void;
  children: ReactNode;
  skeleton?: ReactNode;
}) {
  if (loading) return <>{skeleton ?? <LoadingRows />}</>;
  if (error) return <ErrorState error={error} onRetry={onRetry} />;
  if (isEmpty) return <>{empty ?? <EmptyState title="Nothing here yet" />}</>;
  return <>{children}</>;
}
