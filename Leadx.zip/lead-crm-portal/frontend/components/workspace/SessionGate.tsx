"use client";

/**
 * Requires Supabase session, then resolves workspace via GET /crm/me.
 * Shows real API errors instead of only a slow timeout.
 */
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { getSupabase } from "@/lib/supabaseClient";
import { getApiBase } from "@/lib/config";
import { getAccessToken, signOut } from "@/lib/auth";
import { setTenant, clearTenant } from "@/lib/tenant";

export function SessionGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [detail, setDetail] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function resolve() {
      try {
        const { data } = await getSupabase().auth.getSession();
        if (!data.session) {
          router.replace(`/login?next=${encodeURIComponent(pathname || "/")}`);
          return;
        }

        const base = getApiBase();
        const token = await getAccessToken();
        if (!token) {
          if (!cancelled) {
            setError("No session token. Sign in again.");
            setDetail("Supabase session missing access_token");
          }
          return;
        }

        // 1) Quick API health (3s)
        try {
          const hc = new AbortController();
          const ht = window.setTimeout(() => hc.abort(), 3000);
          const hr = await fetch(`${base}/health`, { signal: hc.signal, cache: "no-store" });
          window.clearTimeout(ht);
          if (!hr.ok) {
            if (!cancelled) {
              setError("API is up but /health failed.");
              setDetail(`GET ${base}/health → HTTP ${hr.status}`);
            }
            return;
          }
        } catch (e: any) {
          if (!cancelled) {
            setError("Cannot reach API. Backend may be down or /backend proxy is wrong.");
            setDetail(`Tried ${base}/health — ${e?.message || e}`);
          }
          return;
        }

        // 2) /crm/me with 10s timeout
        const ctrl = new AbortController();
        const timer = window.setTimeout(() => ctrl.abort(), 10000);
        let res: Response;
        try {
          res = await fetch(`${base}/crm/me`, {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
            cache: "no-store",
            signal: ctrl.signal,
          });
        } catch (e: any) {
          window.clearTimeout(timer);
          if (!cancelled) {
            setError("Workspace lookup timed out or network failed.");
            setDetail(`${base}/crm/me — ${e?.name === "AbortError" ? "timeout 10s" : e?.message || e}`);
          }
          return;
        }
        window.clearTimeout(timer);

        const text = await res.text();
        let body: any = {};
        try {
          body = text ? JSON.parse(text) : {};
        } catch {
          body = { raw: text };
        }

        if (!res.ok) {
          const msg =
            typeof body.detail === "string"
              ? body.detail
              : body.message || text || res.statusText;
          if (!cancelled) {
            clearTenant();
            if (String(msg).toLowerCase().includes("not a member")) {
              setError("Logged in, but not linked to a client workspace.");
              setDetail(
                "Admin → Clients → open this client → Create/attach portal login with this same email. " +
                  "Then Sign out and sign in again. Also check tenant_members has auth_user_id + status=active."
              );
            } else {
              setError(`Workspace error (HTTP ${res.status}): ${msg}`);
              setDetail(`GET ${base}/crm/me`);
            }
          }
          return;
        }

        const tenantId = body.tenant_id;
        if (!tenantId) {
          if (!cancelled) {
            clearTenant();
            setError("API returned no tenant_id for this login.");
            setDetail("Attach portal login under Admin → Clients for this email.");
          }
          return;
        }

        setTenant(tenantId, body.tenant_name || "Workspace");
        if (!cancelled) setReady(true);
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || "Unexpected error loading workspace");
          setDetail(String(e));
        }
      }
    }

    resolve();
    return () => {
      cancelled = true;
    };
  }, [pathname, router]);

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-canvas p-6 text-center">
        <p className="max-w-lg text-sm font-medium text-ink">{error}</p>
        {detail ? (
          <p className="max-w-lg text-xs text-ink-muted whitespace-pre-wrap break-all">{detail}</p>
        ) : null}
        <div className="flex flex-wrap justify-center gap-2">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              clearTenant();
              window.location.reload();
            }}
          >
            Clear workspace & retry
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={async () => {
              clearTenant();
              await signOut();
              window.location.href = "/login";
            }}
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-2 bg-canvas text-sm text-ink-muted">
        <p>Loading workspace…</p>
        <p className="text-xs text-ink-faint">Checking API and linking your login</p>
      </div>
    );
  }

  return <>{children}</>;
}
