"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getSupabase } from "@/lib/supabaseClient";
import { getApiBases } from "@/lib/config";
import { signOut } from "@/lib/auth";
import { getTenantId, setTenant, clearTenant } from "@/lib/tenant";

const BOOTSTRAP_TIMEOUT_MS = 6500;

async function fetchWithTimeout(url: string, init: RequestInit, ms: number) {
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal, cache: "no-store" });
  } finally {
    window.clearTimeout(timer);
  }
}

export function SessionGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [detail, setDetail] = useState("");

  useEffect(() => {
    let cancelled = false;
    async function resolve() {
      try {
        const sessionResult = await Promise.race([
          getSupabase().auth.getSession(),
          new Promise<never>((_, reject) => window.setTimeout(() => reject(new Error("Session restore timed out. Please retry.")), 5000)),
        ]);
        const { data } = sessionResult;
        if (!data.session) {
          router.replace("/login");
          return;
        }

        // Tenant resolution is intentionally done once per browser session.
        // Previously this ran on every pathname change, causing slow navigation.
        const cachedTenant = getTenantId();
        if (cachedTenant) {
          if (!cancelled) setReady(true);
          return;
        }

        const token = data.session.access_token;
        const bases = getApiBases();
        let lastError = "";

        for (const base of bases) {
          try {
            const res = await fetchWithTimeout(`${base}/crm/me`, {
              headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
            }, BOOTSTRAP_TIMEOUT_MS);
            const raw = await res.text();
            let body: any = {};
            try { body = raw ? JSON.parse(raw) : {}; } catch { body = { raw }; }

            if (res.ok && body.tenant_id) {
              setTenant(body.tenant_id, body.tenant_name || "Workspace");
              if (!cancelled) setReady(true);
              return;
            }

            lastError = `HTTP ${res.status}: ${body.detail || body.message || raw || res.statusText}`;
            // A proxy 404 is specifically retried against the Codespaces forwarded API.
            if (res.status !== 404 && res.status !== 502 && res.status !== 503) break;
          } catch (e: any) {
            lastError = e?.name === "AbortError" ? "API bootstrap timed out" : (e?.message || "network error");
          }
        }

        if (!cancelled) {
          setError(lastError.includes("403") || /not a member/i.test(lastError)
            ? "Your login is valid, but it is not linked to a client workspace."
            : "We couldn't connect your client workspace.");
          setDetail(`${lastError}. Make sure the FastAPI service is running on port 8000, then retry.`);
          clearTenant();
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || "Unable to restore your session.");
          setDetail("The login service did not respond in time. Retry once; your credentials are not lost.");
        }
      }
    }
    resolve();
    return () => { cancelled = true; };
  }, [router]);

  if (error) return (
    <div className="auth-shell">
      <div className="auth-card max-w-lg text-center">
        <span className="auth-logo">LX</span>
        <div className="mt-5 text-xs font-bold uppercase tracking-[.16em] text-brand-600">Workspace connection</div>
        <h1 className="mt-2 text-2xl font-bold text-ink">Almost there</h1>
        <p className="mt-2 text-sm text-ink-muted">{error}</p>
        <p className="mt-3 text-xs leading-5 text-ink-faint">{detail}</p>
        <div className="mt-6 flex justify-center gap-2">
          <button className="btn btn-secondary" onClick={() => window.location.reload()}>Retry</button>
          <button className="btn-primary" onClick={async () => { clearTenant(); await signOut().catch(() => {}); window.location.href = "/login"; }}>Sign out</button>
        </div>
      </div>
    </div>
  );

  if (!ready) return (
    <div className="auth-shell">
      <div className="auth-card max-w-sm text-center">
        <span className="auth-logo">LX</span>
        <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-surface-3"><div className="h-full w-1/2 animate-pulse rounded-full bg-brand-500" /></div>
        <p className="mt-4 text-sm font-semibold text-ink">Opening your workspace</p>
        <p className="mt-1 text-xs text-ink-muted">Securing your session…</p>
      </div>
    </div>
  );

  return <>{children}</>;
}
