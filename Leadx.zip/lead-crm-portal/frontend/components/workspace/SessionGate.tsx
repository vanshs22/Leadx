"use client";

/**
 * Requires a real Supabase session, then resolves workspace via /crm/me.
 * Never trusts a stale localStorage tenant_id alone — membership is always checked.
 */
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { getSupabase } from "@/lib/supabaseClient";
import { crm } from "@/lib/api";
import { setTenant, getTenantId, clearTenant } from "@/lib/tenant";
import { signOut } from "@/lib/auth";

export function SessionGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      if (!cancelled && !ready) {
        setError(
          "Workspace is taking too long. Check API is running and Admin → Clients has Create/attach login for this email."
        );
      }
    }, 15000);

    async function resolve() {
      try {
        const { data } = await getSupabase().auth.getSession();
        if (!data.session) {
          router.replace(`/login?next=${encodeURIComponent(pathname || "/")}`);
          return;
        }

        // Always ask backend which tenant this user belongs to
        try {
          const me = await crm.me();
          if (me?.tenant_id) {
            setTenant(me.tenant_id, (me as any).tenant_name || "Workspace");
            if (!cancelled) setReady(true);
            return;
          }
          clearTenant();
          if (!cancelled)
            setError(
              "Signed in, but no workspace is linked. In Admin → Clients open this client and use Create / attach portal login for this email."
            );
        } catch (e: any) {
          const msg = String(e?.message || e || "");
          // Stale tenant in storage often causes this — clear and show fix steps
          clearTenant();
          if (!cancelled) {
            if (msg.toLowerCase().includes("not a member")) {
              setError(
                "Not a member of this workspace. Your login works, but tenant_members is missing or not active for this user. " +
                  "Admin → Clients → attach portal login again for this email, or run the SQL check below. Then sign out and sign in again."
              );
            } else {
              setError(
                msg ||
                  "Couldn't load workspace. Confirm backend is up and tenant_members has this user (auth_user_id + status=active)."
              );
            }
          }
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(
            e?.message ||
              "Supabase session error — fix NEXT_PUBLIC_SUPABASE_URL in frontend .env.local and restart."
          );
        }
      }
    }

    resolve();
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [pathname, router]);

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-canvas p-6 text-center">
        <p className="max-w-lg text-sm text-ink-muted whitespace-pre-wrap">{error}</p>
        <div className="flex flex-wrap justify-center gap-2">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              clearTenant();
              window.location.reload();
            }}
          >
            Clear workspace & retry
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={async () => {
              clearTenant();
              await signOut();
              router.replace("/login");
            }}
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-2 bg-canvas text-sm text-ink-muted">
        <p>Loading workspace…</p>
        <p className="text-xs text-ink-faint">Linking your login to the client account</p>
      </div>
    );
  }

  return <>{children}</>;
}
