"use client";

/**
 * Requires a real Supabase session, then resolves workspace via /crm/me.
 */
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { getSupabase } from "@/lib/supabaseClient";
import { crm } from "@/lib/api";
import { setTenant, getTenantId, clearTenant } from "@/lib/tenant";
import { signOut } from "@/lib/auth";

export function SessionGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      if (!cancelled && !getTenantId()) {
        setError(
          "Workspace is taking too long. Check API is running and this login is linked under Admin → Clients → Client portal login."
        );
      }
    }, 12000);

    async function resolve() {
      try {
        const { data } = await getSupabase().auth.getSession();
        if (!data.session) {
          router.replace(`/login?next=${encodeURIComponent(pathname || "/")}`);
          return;
        }
        if (getTenantId()) {
          if (!cancelled) setReady(true);
          return;
        }
        try {
          const me = await crm.me();
          if (me?.tenant_id) {
            setTenant(me.tenant_id, (me as any).tenant_name || "Workspace");
            if (!cancelled) setReady(true);
          } else {
            if (!cancelled)
              setError(
                "Signed in, but no workspace is linked. Admin must Create/attach login for this email under the client."
              );
          }
        } catch (e: any) {
          if (!cancelled) {
            setError(
              e.message ||
                "Couldn't load workspace. Confirm backend is up and tenant_members has this user."
            );
          }
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(
            e.message ||
              "Supabase session error — fix NEXT_PUBLIC_SUPABASE_URL in frontend .env.local and restart."
          );
        }
      }
    }

    resolve();
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [pathname, router]);

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-canvas p-6 text-center">
        <p className="max-w-md text-sm text-ink-muted">{error}</p>
        <div className="flex flex-wrap justify-center gap-2">
          <a href="/leads" className="btn-secondary">
            Try Leads
          </a>
          <button
            type="button"
            className="btn-secondary"
            onClick={() => {
              clearTenant();
              setError("");
              setReady(false);
              window.location.reload();
            }}
          >
            Retry
          </button>
          <button
            type="button"
            className="btn-ghost"
            onClick={async () => {
              clearTenant();
              await signOut();
              router.replace("/login");
            }}
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-2 bg-canvas text-sm text-ink-muted">
        <p>Loading workspace…</p>
        <p className="text-xs text-ink-faint">Linking your login to the client account</p>
      </div>
    );
  }

  return <>{children}</>;
}
