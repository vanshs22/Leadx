"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getTenantId, setTenant } from "@/lib/tenant";
import { admin } from "@/lib/admin";
import { getApiBase } from "@/lib/config";

export function WorkspacePicker({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [hasTenant, setHasTenant] = useState(false);
  const [tenants, setTenants] = useState<any[]>([]);
  const [newName, setNewName] = useState("My workspace");
  const [manualId, setManualId] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [apiOk, setApiOk] = useState<boolean | null>(null);

  async function checkApi() {
    try {
      const base = getApiBase();
      const r = await fetch(`${base}/health`, { cache: "no-store" });
      setApiOk(r.ok);
      if (!r.ok) setMsg(`API health HTTP ${r.status}`);
      return r.ok;
    } catch (e: any) {
      setApiOk(false);
      setMsg(`API not reachable (${getApiBase()}). Start backend on :8000`);
      return false;
    }
  }

  async function loadTenants() {
    try {
      const data: any = await admin.listTenants();
      const rows = data?.tenants || (Array.isArray(data) ? data : []);
      setTenants(rows);
      setMsg("");
    } catch (e: any) {
      setMsg(e.message || "Could not list workspaces");
      setTenants([]);
    }
  }

  useEffect(() => {
    const id = getTenantId();
    if (id) {
      setHasTenant(true);
      setReady(true);
      return;
    }
    (async () => {
      await checkApi();
      await loadTenants();
      setReady(true);
    })();
  }, []);

  function pick(t: { id: string; name?: string }) {
    setTenant(t.id, t.name || "");
    setHasTenant(true);
    router.refresh();
  }

  async function createWorkspace() {
    setBusy(true);
    setMsg("");
    try {
      const r: any = await admin.createTenant({
        name: newName.trim() || "My workspace",
        delivery_channel: "portal",
        leads_per_month_limit: 500,
        status: "active",
        allow_tier_b: true,
      });
      const id = r?.id || r?.tenant?.id || r?.tenant_id;
      if (!id) throw new Error("API did not return tenant id — check Supabase migration");
      setTenant(id, r?.name || newName);
      setHasTenant(true);
      router.refresh();
    } catch (e: any) {
      setMsg(e.message || "Create failed");
    } finally {
      setBusy(false);
    }
  }

  function useManual() {
    const id = manualId.trim();
    if (id.length < 10) {
      setMsg("Paste a full tenant UUID");
      return;
    }
    setTenant(id, "");
    setHasTenant(true);
    router.refresh();
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas text-ink-muted text-sm">
        Loading…
      </div>
    );
  }
  if (hasTenant) return <>{children}</>;

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas p-4">
      <div className="w-full max-w-md space-y-4 rounded-2xl border border-line bg-panel p-6 shadow-lg">
        <div>
          <h1 className="text-xl font-semibold text-ink">LeadX workspace</h1>
          <p className="mt-1 text-sm text-ink-muted">
            Create a workspace and start searching leads. No service key required.
          </p>
          <p className="mt-2 text-xs text-ink-faint">
            API: {getApiBase()}{" "}
            {apiOk === true && <span className="text-green-500">● online</span>}
            {apiOk === false && <span className="text-red-400">● offline</span>}
          </p>
        </div>

        {msg && (
          <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
            {msg}
          </p>
        )}

        {tenants.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
              Existing
            </div>
            {tenants.map((t) => (
              <button
                key={t.id}
                type="button"
                className="btn-secondary w-full justify-start text-left"
                onClick={() => pick(t)}
              >
                {t.name || t.id}
              </button>
            ))}
          </div>
        )}

        <div className="space-y-2 border-t border-line pt-4">
          <div className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
            Create new
          </div>
          <input
            className="input w-full"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Workspace name"
          />
          <button
            type="button"
            className="btn-primary w-full"
            disabled={busy || apiOk === false}
            onClick={createWorkspace}
          >
            {busy ? "Creating…" : "Create & open"}
          </button>
        </div>

        <div className="space-y-2 border-t border-line pt-4">
          <div className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
            Or paste tenant UUID
          </div>
          <input
            className="input w-full font-mono text-xs"
            value={manualId}
            onChange={(e) => setManualId(e.target.value)}
            placeholder="uuid…"
          />
          <button type="button" className="btn-ghost w-full" onClick={useManual}>
            Use this id
          </button>
        </div>

        <button
          type="button"
          className="btn-ghost w-full text-xs"
          onClick={async () => {
            await checkApi();
            await loadTenants();
          }}
        >
          Retry connection
        </button>
      </div>
    </div>
  );
}
