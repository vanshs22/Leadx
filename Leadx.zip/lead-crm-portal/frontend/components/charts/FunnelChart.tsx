"use client";

import { funnelShades } from "@/lib/chartColors";

export function FunnelChart({
  stages,
}: {
  stages: { stage: string; count: number; slug?: string }[];
}) {
  const max = Math.max(1, ...stages.map((s) => s.count));
  return (
    <div className="space-y-2">
      {stages.map((s, i) => {
        const pct = Math.max(6, Math.round((s.count / max) * 100));
        const color = funnelShades[i % funnelShades.length];
        return (
          <div key={s.slug || s.stage} className="group">
            <div
              className="flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium text-white transition-all"
              style={{ width: `${pct}%`, minWidth: "140px", background: color }}
            >
              <span className="truncate">{s.stage}</span>
              <span className="font-mono tabular-nums">{s.count}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
