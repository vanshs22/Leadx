"use client";

export function TierBadge({ tier }: { tier?: string | null }) {
  const t = (tier || "C").toUpperCase();
  const styles =
    t === "A"
      ? "bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:ring-emerald-500/30"
      : t === "B"
        ? "bg-amber-50 text-amber-800 ring-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:ring-amber-500/30"
        : "bg-slate-100 text-slate-600 ring-slate-200 dark:bg-slate-500/15 dark:text-slate-400 dark:ring-slate-500/30";
  return <span className={`pill ring-1 ${styles}`}>Tier {t}</span>;
}

export function StagePill({ stage }: { stage?: string | null }) {
  if (!stage) return null;
  return (
    <span className="pill bg-surface-3 text-ink-muted ring-1 ring-line">
      {stage}
    </span>
  );
}

export function ScoreBar({ score }: { score?: number | null }) {
  const s = Math.max(0, Math.min(100, Number(score) || 0));
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs text-ink-muted">
        <span>Score</span>
        <span className="tabular-nums font-medium text-ink">{s}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-surface-3">
        <div
          className="h-full rounded-full bg-brand-500 transition-all"
          style={{ width: `${s}%` }}
        />
      </div>
    </div>
  );
}
