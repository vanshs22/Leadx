# LeadX Aurora Signal UI System

## Direction
LeadX uses a premium high-contrast revenue-console aesthetic. The product should feel analytical, fast, and trustworthy rather than generic SaaS.

## Color roles
- **Aurora Indigo** (`brand-*`): primary actions, active navigation, key product identity.
- **Signal Cyan** (`signal-*`): healthy systems, verified data, secondary data accents.
- **Coral/Rose**: destructive or exception states only.
- **Ink**: primary text. Never use low-contrast gray for primary content.
- **Ink muted/faint**: secondary metadata; must remain readable in both themes.

## Light mode
Canvas: cool near-white slate. Cards: pure white. Borders: visible slate. Use indigo/cyan gradients sparingly for hero surfaces and important CTAs.

## Dark mode
Canvas: deep blue-black. Cards: raised graphite-blue surfaces. Borders remain visible. Primary text is near-white; secondary text is silver-blue, not gray-on-black.

## Card language
Use `data-card`, `premium-card`, `hero-panel`, `action-card`, and `kpi` for repeated product surfaces. Cards should have visible hierarchy, subtle depth, and a clear hover state.

## Typography
- Space Grotesk: headings, product identity, metrics.
- Inter: body/UI.
- IBM Plex Mono: labels, system/status readouts.

## Signature
The `LX` gradient mark and Aurora Indigo → Cyan accent are the primary LeadX identity. Keep navigation, auth, client portal, and operator control plane visually related.
