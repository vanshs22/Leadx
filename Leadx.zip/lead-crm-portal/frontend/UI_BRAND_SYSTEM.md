# LeadX Deep Teal / Tangerine UI System

LeadX uses a deliberately non-Aurora visual identity for its client portal and operator surfaces.

- **Deep Teal (`brand-*`)** — product identity, navigation, primary actions and focus states.
- **Tangerine (`signal-*`)** — opportunities, live activity, attention states and selected highlights.
- **Ink / warm neutral surfaces** — the foundation for readable B2B data-heavy screens.

## Mark
Use the compact `LX` mark with a deep-teal-to-tangerine micro-gradient. Avoid the old blue/purple/cyan Aurora treatment.

## Login
The login screen should feel like a secure operations console: warm neutral grid, deep-teal identity, restrained tangerine signal glow, strong typography, and no decorative rainbow/AI gradients.

## Client portal
Keep primary actions teal. Use tangerine sparingly for live opportunity signals, alerts and high-value status. Do not turn every card into a gradient.
