import { getApiBase } from "./config";

async function adminApi(path: string, init?: RequestInit) {
  const base = getApiBase();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch (e: any) {
    throw new Error(`Cannot reach API at ${base}: ${e?.message || "network error"}`);
  }
  if (!res.ok) {
    const t = await res.text();
    let d = t;
    try {
      d = JSON.parse(t).detail || t;
    } catch {
      /* */
    }
    throw new Error(typeof d === "string" ? d : JSON.stringify(d));
  }
  return res.json();
}

export const admin = {
  listTenants: () => adminApi("/leads/v2/admin/tenants").catch(() => adminApi("/leads/v2/tenants")),
  createTenant: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/tenants", { method: "POST", body: JSON.stringify(body) }),
};

// no-ops kept for any old imports
export function setAdminKey(_k: string) {}
export function clearAdminKey() {}
export function hasAdminKey() {
  return true;
}
