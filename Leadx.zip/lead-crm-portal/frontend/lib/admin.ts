import { getApiBase } from "./config";

const STORAGE_KEY = "lead_admin_service_key";
const REMEMBER_KEY = "lead_admin_remember_key";

export function setAdminKey(k: string) {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(STORAGE_KEY, k);
}

export function clearAdminKey() {
  if (typeof window === "undefined") return;
  sessionStorage.removeItem(STORAGE_KEY);
}

export function getAdminKey(): string {
  if (typeof window === "undefined") return "";
  // Prefer live session; fall back to remembered key so refresh stays signed in
  return (
    sessionStorage.getItem(STORAGE_KEY) ||
    localStorage.getItem(REMEMBER_KEY) ||
    ""
  );
}

export function hasAdminKey(): boolean {
  const k = getAdminKey();
  // "dev-open-mode" is set by the login page when backend allows open access
  return k.length >= 8 || k === "dev-open-mode";
}

async function adminApi(path: string, init?: RequestInit) {
  const base = getApiBase();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;
  const key = getAdminKey();
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(key ? { Authorization: `Bearer ${key}` } : {}),
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch (e: any) {
    throw new Error(`Cannot reach API at ${base}: ${e?.message || "network error"}`);
  }
  if (res.status === 401 || res.status === 403) {
    clearAdminKey();
    if (typeof window !== "undefined") window.location.href = "/admin/login";
    throw new Error("Session expired — please log in again");
  }
  if (!res.ok) {
    const t = await res.text();
    let d = t;
    try {
      d = JSON.parse(t).detail || t;
    } catch {
      /* keep text */
    }
    throw new Error(typeof d === "string" ? d : JSON.stringify(d));
  }
  if (res.status === 204) return undefined;
  return res.json();
}

export const admin = {
  // Tenants
  /**
   * GET /leads/v2/admin/tenants — backend accepts optional `status` and
   * `limit` query params (see api/prod/leads_api.py list_tenants).
   */
  tenants: (status?: string, limit?: number) => {
    const q = new URLSearchParams();
    if (status) q.set("status", status);
    if (limit !== undefined) q.set("limit", String(limit));
    const qs = q.toString();
    return adminApi(`/leads/v2/admin/tenants${qs ? `?${qs}` : ""}`);
  },
  tenant: (id: string) => adminApi(`/leads/v2/admin/tenants/${id}`),
  updateTenant: (id: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/tenants/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
  createTenant: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/tenants", { method: "POST", body: JSON.stringify(body) }),

  // Admin-provisioned client login — sets the client's email/password
  // directly instead of a self-serve signup flow.
  createTenantUser: (tenantId: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/tenants/${tenantId}/users`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  tenantUsers: (tenantId: string) =>
    adminApi(`/leads/v2/admin/tenants/${tenantId}/users`),
  resetTenantUserPassword: (tenantId: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/tenants/${tenantId}/users/reset-password`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  // ICPs
  icps: (tenantId?: string) =>
    adminApi(`/leads/v2/admin/icps${tenantId ? `?tenant_id=${tenantId}` : ""}`),
  createIcp: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/icps", { method: "POST", body: JSON.stringify(body) }),
  updateIcp: (id: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/icps/${id}`, { method: "PATCH", body: JSON.stringify(body) }),

  // Pipeline
  runPipeline: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/pipeline/run", { method: "POST", body: JSON.stringify(body) }),
  /**
   * POST /leads/v2/pipeline/run-all-icps — body is CronRequest
   * (limit_per_location, skip_enrichment, max_enrich_concurrent), all optional.
   */
  runAllIcps: (body: Record<string, unknown> = {}) =>
    adminApi("/leads/v2/pipeline/run-all-icps", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  // Pipeline runs history
  runs: (tenantId?: string) =>
    adminApi(`/leads/v2/admin/runs${tenantId ? `?tenant_id=${tenantId}` : ""}`),

  // Keys
  keys: () => adminApi("/leads/v2/admin/keys"),
  addKey: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/keys/add", { method: "POST", body: JSON.stringify(body) }),
  keysHealth: () => adminApi("/leads/v2/keys/health"),

  // Ops / usage / stats
  usage: (params = "") => adminApi(`/leads/v2/admin/usage${params}`),
  adminPing: () => adminApi("/leads/v2/admin/ping"),
  globalStats: () => adminApi("/leads/v2/admin/global-stats"),
  ops: (days = 14) => adminApi(`/leads/v2/ops/dashboard?days=${days}`),
  health: () => adminApi("/health"),

  // Sample pack / QA / bad leads
  samplePack: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/sample-pack", { method: "POST", body: JSON.stringify(body) }),
  qaSubmit: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/qa", { method: "POST", body: JSON.stringify(body) }),
  qaStats: () => adminApi("/leads/v2/admin/qa/stats"),
  badLeads: () => adminApi("/leads/v2/admin/bad-leads"),
  resolveBadLead: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/bad-leads/resolve", { method: "POST", body: JSON.stringify(body) }),

  // Territories
  territories: () => adminApi("/leads/v2/admin/territories"),
  createTerritory: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/territories", { method: "POST", body: JSON.stringify(body) }),
  /** Availability check: locked vertical+geo+offer combos */
  territory: (query = "") =>
    adminApi(`/leads/v2/admin/territory${query ? `?${query}` : ""}`),
  /** Tenant health rollup for churn risk */
  tenantHealth: () => adminApi("/leads/v2/admin/tenant-health"),

  // Billing
  billingLink: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/billing/link", { method: "POST", body: JSON.stringify(body) }),
  billingReport: (tenantId: string) =>
    adminApi(`/leads/v2/billing/report/${tenantId}`, { method: "POST" }),
  billingReportAll: () => adminApi("/leads/v2/billing/report-all", { method: "POST" }),

  // Suppression / opt-out
  /**
   * POST /leads/v2/suppression/upload — backend body is
   * SuppressionUpload { tenant_id, rows[] }.
   */
  suppressionUpload: (tenantId: string, rows: Record<string, unknown>[]) =>
    adminApi("/leads/v2/suppression/upload", {
      method: "POST",
      body: JSON.stringify({ tenant_id: tenantId, rows }),
    }),
  optOut: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/opt-out", { method: "POST", body: JSON.stringify(body) }),

  // Priors / team
  refreshPriors: (vertical: string) =>
    adminApi(`/leads/v2/priors/refresh/${vertical}`, { method: "POST" }),
  teamInvite: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/team/invite", { method: "POST", body: JSON.stringify(body) }),

  runAlerts: () =>
    adminApi("/leads/v2/admin/alerts/run", { method: "POST" }),
  featureFlags: (tenantId?: string) =>
    adminApi(`/leads/v2/admin/feature-flags${tenantId ? `?tenant_id=${tenantId}` : ""}`),

  // Admin leads by client
  leadsClients: () => adminApi("/leads/v2/admin/leads"),
  clientLeads: (tenantId: string, limit = 100, offset = 0) =>
    adminApi(`/leads/v2/admin/leads?tenant_id=${tenantId}&limit=${limit}&offset=${offset}`),
  unassignLead: (assignmentId: string, tenantId?: string) =>
    adminApi(
      `/leads/v2/admin/leads/${assignmentId}${tenantId ? `?tenant_id=${tenantId}` : ""}`,
      { method: "DELETE" }
    ),

  runLeads: (runId: string) => adminApi(`/leads/v2/admin/runs/${runId}/leads`),
  patchRunLead: (runId: string, leadId: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/runs/${runId}/leads/${leadId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),
};
