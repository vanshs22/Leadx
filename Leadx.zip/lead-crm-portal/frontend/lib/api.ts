/**
 * CRM Portal API client — tenant-scoped.
 *
 * Every call attaches the logged-in user's Supabase access token. The
 * backend (require_tenant) re-verifies that token and re-checks tenant
 * membership on every request — the tenantId in the URL is only a hint,
 * never trusted on its own.
 */
import { getApiBase } from "./config";
import { getAccessToken } from "./auth";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const base = getApiBase();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;
  const token = await getAccessToken();
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch (e: any) {
    throw new Error(
      `Cannot reach API at ${base} (${e?.message || "network error"}). ` +
        `Is the backend running on port 8000?`
    );
  }
  if (res.status === 401) {
    if (typeof window !== "undefined") window.location.href = "/login";
    throw new Error("Please log in again");
  }
  if (!res.ok) {
    const err = await res.text();
    let detail = err || res.statusText;
    try {
      const j = JSON.parse(err);
      detail = j.detail || j.message || detail;
      if (Array.isArray(detail)) detail = detail.map((d: any) => d.msg || d).join(", ");
    } catch {
      /* keep text */
    }
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

async function downloadAuthed(path: string, filename: string): Promise<void> {
  const base = getApiBase();
  const token = await getAccessToken();
  const res = await fetch(`${base}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Export failed (HTTP ${res.status})`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ────────────────────────────────────────────────────────────────────────────
 * Response shapes.
 *
 * These mirror what backend/crm/crm_api.py actually returns. Lead rows come
 * from the `crm_lead_cards` view (sql/003_crm_portal_schema.sql), so field
 * names follow that view, not the raw `leads_global` table.
 * ──────────────────────────────────────────────────────────────────────────── */

/** Row of `pipeline_stages` — GET /crm/{tenant}/stages */
export interface Stage {
  id: string;
  tenant_id?: string;
  name: string;
  slug: string;
  position: number;
  color: string;
  is_won: boolean;
  is_lost: boolean;
  created_at?: string;
}

/**
 * A lead as shown in the CRM. Two endpoints produce this shape:
 *  - the `crm_lead_cards` view (leads list, lead detail, pipeline board)
 *  - POST /{tenant}/search-run, which hand-builds cards from
 *    lead_assignments + leads_global + enrichment
 * The two overlap but are not identical, so everything except assignment_id
 * is optional. Fields marked "search-run only" are absent from the view.
 */
export interface LeadCard {
  assignment_id: string;
  lead_id?: string;
  tenant_id?: string;

  // ── crm_lead_cards view ──
  assignment_status?: string | null;
  delivery_status?: string | null;
  delivered_at?: string | null;
  priority?: string | null;
  next_action_at?: string | null;
  last_contacted_at?: string | null;
  value_estimate?: number | null;
  tags?: string[] | null;
  custom_fields?: Record<string, unknown> | null;
  assigned_to?: string | null;
  stage_id?: string | null;
  stage_name?: string | null;
  stage_slug?: string | null;
  stage_color?: string | null;
  stage_position?: number | null;
  company_name?: string | null;
  phone_normalized?: string | null;
  phone_e164?: string | null;
  website?: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  business_status?: string | null;
  google_rating?: number | null;
  review_count?: number | null;
  category?: string | null;
  email?: string | null;
  email_valid?: boolean | null;
  has_booking?: boolean | null;
  booking_platform?: string | null;
  services?: unknown;
  social_links?: unknown;
  owner_name?: string | null;
  enrichment_ok?: boolean | null;
  total_score?: number | null;
  tier?: string | null;
  score_reasoning?: string | null;

  // ── search-run only ──
  /** search-run returns `name`; the view exposes the same value as company_name */
  name?: string | null;
  /** search-run returns a single collapsed `phone`; the view has phone_e164/phone_normalized */
  phone?: string | null;
  rating?: number | null;
  reviews?: number | null;
  pitch_line?: string | null;
  talking_points?: string | null;
  intent_score?: number | null;
  status?: string | null;

  /**
   * Legacy aliases the UI still falls back to. NOT returned by the current
   * backend — kept so existing `total_score ?? score` fallbacks keep type
   * checking without behaviour change. See report note.
   */
  score?: number | null;
  sources_hit?: string[] | string | null;
}

/** Row of `lead_activities` */
export interface Activity {
  id: string;
  tenant_id?: string;
  assignment_id?: string;
  lead_id?: string;
  actor_id?: string | null;
  activity_type: string;
  title?: string | null;
  body?: string | null;
  meta?: Record<string, unknown> | null;
  created_at: string;
}

/** Row of `lead_tasks` */
export interface Task {
  id: string;
  tenant_id?: string;
  assignment_id?: string;
  lead_id?: string;
  assigned_to?: string | null;
  created_by?: string | null;
  title: string;
  description?: string | null;
  due_at?: string | null;
  completed_at?: string | null;
  status?: string;
  priority?: string;
  created_at?: string;
}

/** GET /crm/{tenant}/pipeline */
export interface PipelineStageColumn extends Stage {
  leads: LeadCard[];
}

export interface PipelineBoard {
  stages: PipelineStageColumn[];
  unstaged: LeadCard[];
}

/** GET /crm/{tenant}/reports/summary */
export interface ReportsSummary {
  total: number;
  with_email: number;
  with_email_pct: number;
  with_booking: number;
  by_tier: Record<string, number>;
  by_stage: Record<string, number>;
  avg_score: number;
}

/** GET /crm/{tenant}/dashboard */
export interface DashboardResponse {
  tenant: {
    name?: string;
    plan?: string;
    leads_per_month_limit?: number | null;
    delivery_channel?: string | null;
  } | null;
  kpis: {
    total_leads: number;
    tier_a: number;
    tier_b: number;
    new: number;
    in_pipeline: number;
    won: number;
    lost: number;
    win_rate_pct: number;
  };
  funnel: { stage: string; slug: string; color: string; count: number }[];
  usage: Record<string, unknown> | null;
  quota_limit: number | null;
  tasks_due: Task[];
  recent_activity: Activity[];
}

/** GET /crm/{tenant}/leads/{assignment} */
export interface WhyThisLead {
  total_score?: number | null;
  tier?: string | null;
  reasoning?: string;
  bullets?: string[];
  scored_at?: string | null;
}

export interface LeadDetail {
  lead: LeadCard;
  activities: Activity[];
  tasks: Task[];
  why_this_lead: WhyThisLead | null;
}

/** GET /crm/{tenant}/branding — selected columns of `tenants` */
export interface Branding {
  id: string;
  name?: string | null;
  brand_name?: string | null;
  brand_logo_url?: string | null;
  brand_primary_color?: string | null;
  brand_accent_color?: string | null;
  brand_favicon_url?: string | null;
  custom_domain?: string | null;
  support_email?: string | null;
}

/** Row of `doc_templates` */
export interface DocTemplate {
  id: string;
  tenant_id?: string | null;
  category: string;
  name: string;
  description?: string | null;
  body_html?: string;
  body_text?: string | null;
  variables?: string[];
  channel_hint?: string | null;
  active?: boolean;
}

/** POST /crm/{tenant}/search-run */
export interface SearchRunResponse {
  ok: boolean;
  icp_id: string | null;
  run: Record<string, unknown>;
  leads: LeadCard[];
  count: number;
  with_email: number;
  with_phone: number;
  tiers: Record<string, number>;
  sources: Record<string, number>;
  duration_ms: number;
  duration_sec: number;
}

export const crm = {
  dashboard: (tenantId: string) => api<DashboardResponse>(`/crm/${tenantId}/dashboard`),

  leads: (tenantId: string, params: Record<string, string | number | undefined> = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== "") q.set(k, String(v));
    });
    return api<{ total: number; limit: number; offset: number; leads: LeadCard[] }>(
      `/crm/${tenantId}/leads?${q}`
    );
  },

  lead: (tenantId: string, assignmentId: string) =>
    api<LeadDetail>(`/crm/${tenantId}/leads/${assignmentId}`),

  updateLead: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/leads/${assignmentId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  searchRun: (tenantId: string, body: Record<string, unknown>) =>
    api<SearchRunResponse>(`/crm/${tenantId}/search-run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  branding: (tenantId: string) => api<Branding>(`/crm/${tenantId}/branding`),

  sendEmailBulk: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/email/bulk`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  /** Single-lead email — backend: POST /crm/{tenant}/leads/{assignment}/email */
  sendEmail: (
    tenantId: string,
    assignmentId: string,
    body: { subject: string; body_html: string; body_text?: string; reply_to?: string }
  ) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/email`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  pipeline: (tenantId: string) => api<PipelineBoard>(`/crm/${tenantId}/pipeline`),

  changeStage: (tenantId: string, assignmentId: string, stageId: string, note?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/stage`, {
      method: "POST",
      body: JSON.stringify({ stage_id: stageId, note }),
    }),

  stages: (tenantId: string) => api<Stage[]>(`/crm/${tenantId}/stages`),

  addActivity: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api<Activity>(`/crm/${tenantId}/leads/${assignmentId}/activities`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  createTask: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api<Task>(`/crm/${tenantId}/leads/${assignmentId}/tasks`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  completeTask: (tenantId: string, taskId: string) =>
    api(`/crm/${tenantId}/tasks/${taskId}/complete`, { method: "POST" }),

  reportBadLead: (tenantId: string, assignmentId: string, reason: string, detail?: string) =>
    api<{
      ok: boolean;
      report?: any;
      credit?: {
        applied: boolean;
        already_credited?: boolean;
        credit_type?: string;
        message?: string;
      };
    }>(`/crm/${tenantId}/leads/${assignmentId}/bad-lead`, {
      method: "POST",
      body: JSON.stringify({ reason, detail: detail || "" }),
    }),

  firstTouch: (tenantId: string, assignmentId: string, channel?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/first-touch`, {
      method: "POST",
      body: JSON.stringify({ channel }),
    }),

  icpWeights: (tenantId: string, icpId: string, weights: Record<string, number>) =>
    api(`/crm/${tenantId}/icp/weights`, {
      method: "PATCH",
      body: JSON.stringify({ icp_id: icpId, weights }),
    }),

  docsTemplates: (tenantId: string) =>
    api<{ templates: DocTemplate[] }>(`/crm/${tenantId}/docs/templates`),

  docsSend: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/docs/send`, { method: "POST", body: JSON.stringify(body) }),

  teamMembers: (tenantId: string) => api<{ members: any[]; invites: any[] }>(`/crm/${tenantId}/team/members`),

  teamInvite: (
    tenantId: string,
    emailOrBody: string | { email: string; role?: string; send_email?: boolean },
    role?: string
  ) => {
    const body =
      typeof emailOrBody === "string"
        ? { email: emailOrBody, role: role || "member" }
        : { email: emailOrBody.email, role: emailOrBody.role || "member", send_email: emailOrBody.send_email };
    return api(`/crm/${tenantId}/team/invite`, {
      method: "POST",
      body: JSON.stringify(body),
    });
  },

  reportsSummary: (tenantId: string) => api<ReportsSummary>(`/crm/${tenantId}/reports/summary`),
  reports: (tenantId: string) => api<ReportsSummary>(`/crm/${tenantId}/reports/summary`),

  // Returns JSON rows — the leads page builds the CSV client-side itself.
  exportCsv: (tenantId: string, params: Record<string, string | undefined> = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => v && q.set(k, v));
    return api<{ rows: any[]; filename?: string }>(`/crm/${tenantId}/export/csv?${q}`);
  },

  // Raw CSV response — the endpoint now requires a Bearer token, which
  // window.open() can't send, so fetch as a blob and trigger the download
  // in-memory instead of returning a bare URL to open.
  exportInstantlyUrl: (tenantId: string) =>
    downloadAuthed(`/crm/${tenantId}/export/instantly`, "leads-instantly.csv"),

  setup: (tenantId: string, body: Record<string, unknown> = {}) =>
    api<{ ok: boolean; stages: Stage[] }>(`/crm/${tenantId}/setup`, {
      method: "POST",
      body: JSON.stringify(body || {}),
    }),

  updateBranding: (tenantId: string, body: Record<string, unknown>) =>
    api<{ ok: boolean; updated?: string[]; error?: string }>(`/crm/${tenantId}/branding`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  me: () => api<{ tenant_id: string; role: string; email?: string }>(`/crm/me`),

  /** Free sample pack of high-quality leads (sales / onboarding demo). */
  samplePack: (
    tenantId: string,
    body: { vertical: string; geo?: string; limit?: number; min_score?: number }
  ) =>
    api<{ pack_id?: string; count: number; leads: any[]; vertical: string; geo: string }>(
      `/crm/${tenantId}/sample-pack`,
      { method: "POST", body: JSON.stringify(body) }
    ),

  /** Territory exclusivity availability (vertical+geo+offer). */
  territory: (tenantId: string, params?: { vertical?: string; geo?: string }) => {
    const q = new URLSearchParams();
    if (params?.vertical) q.set("vertical", params.vertical);
    if (params?.geo) q.set("geo", params.geo);
    const qs = q.toString();
    return api<{ locked: any[]; total_active_icps: number; note?: string }>(
      `/crm/${tenantId}/territory${qs ? `?${qs}` : ""}`
    );
  },

  /** Remaining on-demand search-runs this billing period. */
  searchQuota: (tenantId: string) =>
    api<{
      ok: boolean;
      used: number;
      limit: number;
      remaining: number;
      unlimited?: boolean;
      period_start?: string;
    }>(`/crm/${tenantId}/search-quota`),
};

// Not tenant-scoped — accepting an invite is what creates tenant
// membership in the first place, so it only needs a logged-in user.
export const acceptInvite = (token: string, fullName?: string) =>
  api(`/crm/team/accept`, {
    method: "POST",
    body: JSON.stringify({ token, full_name: fullName }),
  });

// Interfaces for DashboardResponse / LeadCard / LeadDetail / Stage /
// PipelineBoard / ReportsSummary are declared above, next to the client.
