/**
 * CRM Portal API client — tenant-scoped.
 */
import { getApiBase } from "./config";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const base = getApiBase();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch (e: any) {
    throw new Error(
      `Cannot reach API at ${base} (${e?.message || "network error"}). ` +
        `Is the backend running on port 8000?`
    );
  }
  if (!res.ok) {
    const err = await res.text();
    let detail = err || res.statusText;
    try {
      const j = JSON.parse(err);
      detail = j.detail || j.message || detail;
      if (Array.isArray(detail)) detail = detail.map((d: any) => d.msg || d).join(", ");
    } catch {
      /* keep text */
    }
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

export const crm = {
  dashboard: (tenantId: string) => api(`/crm/${tenantId}/dashboard`),

  leads: (tenantId: string, params: Record<string, string | number | undefined> = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== "") q.set(k, String(v));
    });
    return api<{ total: number; leads: any[] }>(`/crm/${tenantId}/leads?${q}`);
  },

  lead: (tenantId: string, assignmentId: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}`),

  updateLead: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/leads/${assignmentId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  searchRun: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/search-run`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  branding: (tenantId: string) => api(`/crm/${tenantId}/branding`),

  sendEmailBulk: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/email/send-bulk`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  sendEmail: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/email/send`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  pipeline: (tenantId: string) => api(`/crm/${tenantId}/pipeline`),

  changeStage: (tenantId: string, assignmentId: string, stageId: string, note?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/stage`, {
      method: "POST",
      body: JSON.stringify({ stage_id: stageId, note }),
    }),
};

export type DashboardResponse = any;
export type LeadCard = any;
export type LeadDetail = any;
