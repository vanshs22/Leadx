"use client";

/**
 * Live-update helpers.
 *
 * Design: Supabase realtime is the primary push channel (see crmRealtime.ts).
 * Polling is only a safety net, and it must be cheap:
 *   - it pauses completely while the tab is hidden (no background traffic),
 *   - it fires once immediately when the tab becomes visible again,
 *   - it never replaces page navigation with a hard reload.
 */
import { useEffect, useRef } from "react";

/** Drop-in for setInterval/clearInterval that skips ticks while the tab is hidden. */
export function setVisibleInterval(fn: () => void, ms: number): number {
  const tick = () => {
    if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
    fn();
  };
  const id = window.setInterval(tick, ms);
  const onVisible = () => { if (document.visibilityState === "visible") fn(); };
  document.addEventListener("visibilitychange", onVisible);
  VISIBLE_CLEANUPS.set(id, () => document.removeEventListener("visibilitychange", onVisible));
  return id;
}

const VISIBLE_CLEANUPS = new Map<number, () => void>();

export function clearVisibleInterval(id: number | undefined | null) {
  if (id == null) return;
  window.clearInterval(id);
  VISIBLE_CLEANUPS.get(id)?.();
  VISIBLE_CLEANUPS.delete(id);
}

/**
 * Run `load` on mount, whenever `deps` change, on tab re-focus, and on a slow
 * visibility-aware interval. Keeps the latest `load` in a ref so callers don't
 * need to memoise it.
 */
export function useLiveLoader(load: () => void | Promise<void>, pollMs = 30_000, deps: unknown[] = []) {
  const ref = useRef(load);
  ref.current = load;
  useEffect(() => {
    let alive = true;
    const run = () => { if (alive) void Promise.resolve(ref.current()).catch(() => {}); };
    run();
    const id = pollMs > 0 ? setVisibleInterval(run, pollMs) : undefined;
    return () => { alive = false; clearVisibleInterval(id); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pollMs, ...deps]);
}
