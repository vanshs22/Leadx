import { getSupabase } from "./supabaseClient";
import { clearTenant } from "./tenant";

let cachedAccessToken: string | null = null;
let cachedTokenAt = 0;
const TOKEN_CACHE_MS = 30_000;

export async function getAccessToken(): Promise<string | null> {
  const now = Date.now();
  if (cachedAccessToken && now - cachedTokenAt < TOKEN_CACHE_MS) return cachedAccessToken;
  const { data } = await getSupabase().auth.getSession();
  cachedAccessToken = data.session?.access_token || null;
  cachedTokenAt = now;
  return cachedAccessToken;
}

async function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label} timed out. Please retry.`)), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function signInWithPassword(email: string, password: string) {
  const client = getSupabase();
  const result: Awaited<ReturnType<typeof client.auth.signInWithPassword>> = await withTimeout(
    client.auth.signInWithPassword({ email, password }),
    12000,
    "Sign-in"
  );
  if (result.error) throw new Error(result.error.message);
}

export async function signUpWithPassword(email: string, password: string) {
  const { error } = await getSupabase().auth.signUp({ email, password });
  if (error) throw new Error(error.message);
}

/** Passwordless — Supabase emails a one-tap link. */
export async function signInWithMagicLink(email: string) {
  const redirectTo =
    typeof window !== "undefined" ? `${window.location.origin}/dashboard` : undefined;
  const { error } = await getSupabase().auth.signInWithOtp({
    email,
    options: redirectTo ? { emailRedirectTo: redirectTo } : undefined,
  });
  if (error) throw new Error(error.message);
}

export async function signOut() {
  clearTenant();
  cachedAccessToken = null;
  cachedTokenAt = 0;
  await getSupabase().auth.signOut();
}

export async function isLoggedIn(): Promise<boolean> {
  return !!(await getAccessToken());
}
