"use client";

import { useEffect, useRef, useState } from "react";
import { getSupabase } from "./supabaseClient";
import { getTenantId } from "./tenant";
import { invalidateApiCache } from "./api";

type CrmTable = string;
export type CrmRealtimeState = "connecting" | "connected" | "reconnecting" | "offline";
export const CRM_REALTIME_EVENT = "leadx:crm-change";

export function emitCrmChange(detail?: { table?: string; event?: string }) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(CRM_REALTIME_EVENT, { detail }));
}

type Manager = {
  tenantId: string;
  channel: any | null;
  state: CrmRealtimeState;
  retry: number;
  reconnectTimer?: number;
  refreshTimer?: number;
  disposed: boolean;
  listeners: Set<() => void>;
  stateListeners: Set<(state: CrmRealtimeState) => void>;
  connecting: boolean;
};

const managers = new Map<string, Manager>();

function publishState(manager: Manager, state: CrmRealtimeState) {
  if (manager.disposed) return;
  manager.state = state;
  manager.stateListeners.forEach((listener) => listener(state));
}

function scheduleRefresh(manager: Manager) {
  if (typeof window === "undefined" || manager.disposed) return;
  if (manager.refreshTimer) window.clearTimeout(manager.refreshTimer);
  manager.refreshTimer = window.setTimeout(() => {
    manager.refreshTimer = undefined;
    // Realtime is an invalidation signal, not a second source of truth.
    // Clear the client GET cache first so listeners fetch the newly persisted
    // database state instead of receiving the previous 10-second snapshot.
    invalidateApiCache();
    manager.listeners.forEach((listener) => listener());
  }, 150);
}

async function removeChannel(manager: Manager) {
  const channel = manager.channel;
  manager.channel = null;
  if (!channel) return;
  try { await getSupabase().removeChannel(channel); } catch { /* best effort */ }
}

async function connect(manager: Manager) {
  if (manager.disposed || manager.connecting) return;
  manager.connecting = true;
  publishState(manager, manager.retry ? "reconnecting" : "connecting");

  await removeChannel(manager);
  if (manager.disposed) { manager.connecting = false; return; }

  const sb = getSupabase();
  const channel = sb.channel(`crm:${manager.tenantId}`, {
    config: { broadcast: { self: false }, presence: { key: manager.tenantId } },
  });
  manager.channel = channel;

  // One callback for all tenant-scoped public-table changes. Keeping exactly
  // one handler makes it impossible for a second component to register a
  // postgres_changes callback after this channel has subscribed.
  channel.on(
    "postgres_changes",
    { event: "*", schema: "public", table: "*", filter: `tenant_id=eq.${manager.tenantId}` },
    (payload: { table?: string; eventType?: string }) => {
      emitCrmChange({ table: payload.table, event: payload.eventType });
      scheduleRefresh(manager);
    },
  );

  channel.subscribe((status: string) => {
    if (manager.disposed || manager.channel !== channel) return;
    if (status === "SUBSCRIBED") {
      manager.connecting = false;
      manager.retry = 0;
      publishState(manager, "connected");
      return;
    }
    if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
      manager.connecting = false;
      publishState(manager, "reconnecting");
      const delay = Math.min(30000, 1000 * 2 ** Math.min(manager.retry, 5));
      manager.retry += 1;
      if (manager.reconnectTimer) window.clearTimeout(manager.reconnectTimer);
      manager.reconnectTimer = window.setTimeout(() => {
        manager.reconnectTimer = undefined;
        void connect(manager);
      }, delay);
    }
  });
}

function acquireManager(tenantId: string, onChange?: () => void, onState?: (state: CrmRealtimeState) => void) {
  let manager = managers.get(tenantId);
  if (!manager) {
    manager = { tenantId, channel: null, state: "connecting", retry: 0, disposed: false, listeners: new Set(), stateListeners: new Set(), connecting: false };
    managers.set(tenantId, manager);
    void connect(manager);
  }
  if (onChange) manager.listeners.add(onChange);
  if (onState) { manager.stateListeners.add(onState); onState(manager.state); }
  return manager;
}

function releaseManager(tenantId: string, onChange?: () => void, onState?: (state: CrmRealtimeState) => void) {
  const manager = managers.get(tenantId);
  if (!manager) return;
  if (onChange) manager.listeners.delete(onChange);
  if (onState) manager.stateListeners.delete(onState);
  if (manager.listeners.size || manager.stateListeners.size) return;
  manager.disposed = true;
  if (manager.reconnectTimer) window.clearTimeout(manager.reconnectTimer);
  if (manager.refreshTimer) window.clearTimeout(manager.refreshTimer);
  managers.delete(tenantId);
  void removeChannel(manager);
}

export function useCrmRealtime(onChange?: (() => void), tenantIdOverride?: string): CrmRealtimeState {
  const tenantId = tenantIdOverride || getTenantId();
  const [state, setState] = useState<CrmRealtimeState>(tenantId ? "connecting" : "offline");
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  useEffect(() => {
    if (!tenantId) { setState("offline"); return; }
    const handleChange = () => onChangeRef.current?.();
    const handleState = (next: CrmRealtimeState) => setState(next);
    acquireManager(tenantId, handleChange, handleState);
    const onVisibility = () => {
      if (document.visibilityState !== "visible") return;
      const manager = managers.get(tenantId);
      if (manager && manager.state !== "connected" && !manager.connecting) void connect(manager);
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      releaseManager(tenantId, handleChange, handleState);
    };
  }, [tenantId]);
  return state;
}

export function useCrmChange(onChange: (detail?: { table?: string; event?: string }) => void, options?: { tables?: string[] }) {
  const cb = useRef(onChange);
  const tablesRef = useRef(options?.tables);
  cb.current = onChange;
  tablesRef.current = options?.tables;
  useEffect(() => {
    const handler = (event: Event) => {
      const detail = (event as CustomEvent).detail as { table?: string; event?: string } | undefined;
      const allowed = tablesRef.current;
      if (allowed?.length && detail?.table && !allowed.includes(detail.table)) return;
      if (allowed?.length && !detail?.table) return;
      cb.current(detail);
    };
    window.addEventListener(CRM_REALTIME_EVENT, handler);
    return () => window.removeEventListener(CRM_REALTIME_EVENT, handler);
  }, []);
}
