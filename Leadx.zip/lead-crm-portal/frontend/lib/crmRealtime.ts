"use client";

import { useEffect, useRef, useState } from "react";
import { getSupabase } from "./supabaseClient";
import { getTenantId } from "./tenant";

type CrmTable =
  | "companies"
  | "contacts"
  | "deals"
  | "deal_stages"
  | "activities"
  | "tasks"
  | "notes"
  | "lead_assignments"
  | "lead_activities"
  | "lead_tasks"
  | "notifications"
  | "discovery_requests"

export type CrmRealtimeState = "connecting" | "connected" | "reconnecting" | "offline";

export const CRM_REALTIME_EVENT = "leadx:crm-change";

export function emitCrmChange(detail?: { table?: string; event?: string }) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(CRM_REALTIME_EVENT, { detail }));
}

/**
 * One tenant-scoped Supabase Realtime channel for the whole portal.
 *
 * The browser never receives another tenant's rows: every table subscription
 * is filtered by tenant_id and Supabase RLS remains the final authorization
 * boundary. Pages listen for CRM_REALTIME_EVENT and refetch their authoritative
 * API data, so realtime is a cache-invalidation signal rather than a second
 * source of truth.
 */
export function useCrmRealtime(onChange?: (() => void), tenantIdOverride?: string): CrmRealtimeState {
  const [state, setState] = useState<CrmRealtimeState>("connecting");
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  useEffect(() => {
    const tenantId = tenantIdOverride || getTenantId();
    if (!tenantId) {
      setState("offline");
      return;
    }

    let disposed = false;
    let reconnectTimer: number | undefined;
    let retry = 0;
    let refreshTimer: number | undefined;
    const sb = getSupabase();
    let activeChannel: any = null;
    const tables: CrmTable[] = [
      "companies",
      "contacts",
      "deals",
      "deal_stages",
      "activities",
      "tasks",
      "notes",
      "lead_assignments",
      "lead_activities",
      "lead_tasks",
      "notifications",
      "discovery_requests",
    ];

    const connect = () => {
      if (disposed) return;
      setState(retry ? "reconnecting" : "connecting");
      if (activeChannel) {
        try { void sb.removeChannel(activeChannel); } catch { /* best effort */ }
      }
      const channel = sb.channel(`crm:${tenantId}`);
      activeChannel = channel;
      tables.forEach((table) => {
        channel.on(
          "postgres_changes",
          { event: "*", schema: "public", table, filter: `tenant_id=eq.${tenantId}` },
          (payload: { eventType?: string }) => {
            emitCrmChange({ table, event: payload.eventType });
            if (refreshTimer) window.clearTimeout(refreshTimer);
            refreshTimer = window.setTimeout(() => onChangeRef.current?.(), 120);
          }
        );
      });

      channel.subscribe((status: string) => {
        if (disposed) return;
        if (status === "SUBSCRIBED") {
          retry = 0;
          setState("connected");
          return;
        }
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          setState("reconnecting");
          if (reconnectTimer) window.clearTimeout(reconnectTimer);
      if (refreshTimer) window.clearTimeout(refreshTimer);
          const delay = Math.min(30000, 1000 * 2 ** Math.min(retry, 5));
          retry += 1;
          reconnectTimer = window.setTimeout(connect, delay);
          try { void sb.removeChannel(channel); } catch { /* best effort */ }
        }
      });

      return channel;
    };

    const channel = connect();
    const onVisibility = () => {
      if (document.visibilityState !== "visible" || disposed) return;
      // A sleeping browser tab can silently lose a websocket. Refresh the
      // authoritative data and reconnect rather than trusting stale state.
      emitCrmChange({ event: "visibility_resume" });
      onChangeRef.current?.();
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      disposed = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      if (refreshTimer) window.clearTimeout(refreshTimer);
      document.removeEventListener("visibilitychange", onVisibility);
      if (activeChannel) {
        try { void sb.removeChannel(activeChannel); } catch { /* best effort */ }
      }
      activeChannel = null;
    };
  }, [tenantIdOverride]);

  return state;
}

export function useCrmChange(onChange: () => void) {
  const cb = useRef(onChange);
  cb.current = onChange;
  useEffect(() => {
    const handler = () => cb.current();
    window.addEventListener(CRM_REALTIME_EVENT, handler);
    return () => window.removeEventListener(CRM_REALTIME_EVENT, handler);
  }, []);
}
