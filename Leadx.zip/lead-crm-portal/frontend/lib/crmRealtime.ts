"use client";

import { useEffect, useRef, useState } from "react";
import { getSupabase } from "./supabaseClient";
import { getTenantId } from "./tenant";

type CrmTable =
  | "companies" | "contacts" | "deals" | "deal_stages" | "activities" | "tasks"
  | "notes" | "lead_assignments" | "lead_activities" | "lead_tasks"
  | "notifications" | "discovery_requests" | "pipeline_stages";

export type CrmRealtimeState = "connecting" | "connected" | "reconnecting" | "offline";

export const CRM_REALTIME_EVENT = "leadx:crm-change";

export function emitCrmChange(detail?: { table?: string; event?: string }) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(CRM_REALTIME_EVENT, { detail }));
}

const TABLES: CrmTable[] = [
  "companies", "contacts", "deals", "deal_stages", "activities", "tasks",
  "notes", "lead_assignments", "lead_activities", "lead_tasks",
  "notifications", "discovery_requests", "pipeline_stages",
];

/**
 * Keep exactly one Realtime channel per tenant in a browser.
 *
 * Previously RealtimeStatus and LiveWorkspaceRefresh both called
 * useCrmRealtime(), so they could obtain the same Supabase channel and one
 * component would call channel.on() after the other had already subscribed.
 * Supabase correctly throws in that case: "cannot add postgres_changes
 * callbacks ... after subscribe()".
 *
 * This manager also serializes reconnects so a timeout cannot create a second
 * channel before the old one is fully removed.
 */
type Manager = {
  tenantId: string;
  channel: any | null;
  state: CrmRealtimeState;
  retry: number;
  reconnectTimer?: number;
  refreshTimer?: number;
  disposed: boolean;
  listeners: Set<() => void>;
  stateListeners: Set<(state: CrmRealtimeState) => void>;
  connecting: boolean;
};

const managers = new Map<string, Manager>();

function publishState(manager: Manager, state: CrmRealtimeState) {
  if (manager.disposed) return;
  manager.state = state;
  manager.stateListeners.forEach((listener) => listener(state));
}

function scheduleRefresh(manager: Manager) {
  if (typeof window === "undefined" || manager.disposed) return;
  if (manager.refreshTimer) window.clearTimeout(manager.refreshTimer);
  manager.refreshTimer = window.setTimeout(() => {
    manager.refreshTimer = undefined;
    manager.listeners.forEach((listener) => listener());
  }, 120);
}

async function removeChannel(manager: Manager) {
  const channel = manager.channel;
  manager.channel = null;
  if (!channel) return;
  try {
    await getSupabase().removeChannel(channel);
  } catch {
    // Best effort. The manager never reuses this channel object.
  }
}

async function connect(manager: Manager) {
  if (manager.disposed || manager.connecting) return;
  manager.connecting = true;
  publishState(manager, manager.retry ? "reconnecting" : "connecting");

  // Never attach callbacks to a channel that may still be JOINED/JOINING.
  await removeChannel(manager);
  if (manager.disposed) {
    manager.connecting = false;
    return;
  }

  const sb = getSupabase();
  // The topic is tenant-scoped. The manager map guarantees one channel per
  // tenant, while the tenant filter + Supabase RLS enforce data isolation.
  const channel = sb.channel(`crm:${manager.tenantId}`);
  manager.channel = channel;

  // IMPORTANT: every postgres_changes handler is attached BEFORE subscribe().
  TABLES.forEach((table) => {
    channel.on(
      "postgres_changes",
      { event: "*", schema: "public", table, filter: `tenant_id=eq.${manager.tenantId}` },
      (payload: { eventType?: string }) => {
        emitCrmChange({ table, event: payload.eventType });
        scheduleRefresh(manager);
      },
    );
  });

  channel.subscribe((status: string) => {
    if (manager.disposed || manager.channel !== channel) return;

    if (status === "SUBSCRIBED") {
      manager.connecting = false;
      manager.retry = 0;
      publishState(manager, "connected");
      return;
    }

    if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
      manager.connecting = false;
      publishState(manager, "reconnecting");
      const delay = Math.min(30000, 1000 * 2 ** Math.min(manager.retry, 5));
      manager.retry += 1;
      if (manager.reconnectTimer) window.clearTimeout(manager.reconnectTimer);
      manager.reconnectTimer = window.setTimeout(() => {
        manager.reconnectTimer = undefined;
        void connect(manager);
      }, delay);
    }
  });
}

function acquireManager(tenantId: string, onChange?: () => void, onState?: (state: CrmRealtimeState) => void) {
  let manager = managers.get(tenantId);
  if (!manager) {
    manager = {
      tenantId,
      channel: null,
      state: "connecting",
      retry: 0,
      disposed: false,
      listeners: new Set(),
      stateListeners: new Set(),
      connecting: false,
    };
    managers.set(tenantId, manager);
    void connect(manager);
  }
  if (onChange) manager.listeners.add(onChange);
  if (onState) {
    manager.stateListeners.add(onState);
    onState(manager.state);
  }
  return manager;
}

function releaseManager(tenantId: string, onChange?: () => void, onState?: (state: CrmRealtimeState) => void) {
  const manager = managers.get(tenantId);
  if (!manager) return;
  if (onChange) manager.listeners.delete(onChange);
  if (onState) manager.stateListeners.delete(onState);

  // Keep the single channel alive while any portal component needs it.
  if (manager.listeners.size || manager.stateListeners.size) return;

  manager.disposed = true;
  if (manager.reconnectTimer) window.clearTimeout(manager.reconnectTimer);
  if (manager.refreshTimer) window.clearTimeout(manager.refreshTimer);
  managers.delete(tenantId);
  void removeChannel(manager);
}

export function useCrmRealtime(onChange?: (() => void), tenantIdOverride?: string): CrmRealtimeState {
  const tenantId = tenantIdOverride || getTenantId();
  const [state, setState] = useState<CrmRealtimeState>(tenantId ? "connecting" : "offline");
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  useEffect(() => {
    if (!tenantId) {
      setState("offline");
      return;
    }

    const handleChange = () => onChangeRef.current?.();
    const handleState = (next: CrmRealtimeState) => setState(next);
    acquireManager(tenantId, handleChange, handleState);

    const onVisibility = () => {
      if (document.visibilityState !== "visible") return;
      emitCrmChange({ event: "visibility_resume" });
      onChangeRef.current?.();
      const manager = managers.get(tenantId);
      if (manager && manager.state !== "connected" && !manager.connecting) void connect(manager);
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      releaseManager(tenantId, handleChange, handleState);
    };
  }, [tenantId]);

  return state;
}

export function useCrmChange(onChange: () => void) {
  const cb = useRef(onChange);
  cb.current = onChange;
  useEffect(() => {
    const handler = () => cb.current();
    window.addEventListener(CRM_REALTIME_EVENT, handler);
    return () => window.removeEventListener(CRM_REALTIME_EVENT, handler);
  }, []);
}
