/**
 * Browser API routing. Prefer same-origin /backend, but in GitHub Codespaces
 * fall back to the forwarded FastAPI port when the Next proxy is unavailable.
 */
function isRemoteBrowser() {
  if (typeof window === "undefined") return false;
  const host = window.location.hostname;
  return host.includes("github.dev") || host.includes("app.github.dev") ||
    host.includes("webcontainer") || host.includes("codesandbox") || host.includes("githubpreview.dev") ||
    (host !== "localhost" && host !== "127.0.0.1");
}

export function getForwardedApiBase(): string | null {
  if (typeof window === "undefined" || !isRemoteBrowser()) return null;
  const { protocol, hostname } = window.location;
  const forwarded = hostname.replace(/-3000(?=\.|$)/, "-8000");
  if (forwarded === hostname) return null;
  return `${protocol}//${forwarded}`;
}

export function getApiBase(): string {
  if (typeof window !== "undefined") {
    const configured = process.env.NEXT_PUBLIC_API_URL?.trim().replace(/\/$/, "");
    if (configured) {
      if (isRemoteBrowser() && /localhost|127\.0\.0\.1/.test(configured)) return "/backend";
      return configured;
    }
    return "/backend";
  }
  return (process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000").replace(/\/$/, "");
}

export function getApiBases(): string[] {
  const bases = [getApiBase()];
  const forwarded = getForwardedApiBase();
  if (forwarded && !bases.includes(forwarded)) bases.push(forwarded);
  return bases;
}
