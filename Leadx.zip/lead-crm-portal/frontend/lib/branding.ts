/**
 * White-label branding — load via CRM API (tenant-scoped).
 * NEVER uses operator service key in the browser.
 */
import { useEffect, useState } from "react";

export type Branding = {
  id: string;
  name: string;
  brand_name?: string;
  brand_logo_url?: string;
  brand_primary_color?: string;
  brand_accent_color?: string;
  brand_favicon_url?: string;
  custom_domain?: string;
  support_email?: string;
};

function getBrandingBase(): string {
  if (typeof window !== "undefined") {
    const configured = process.env.NEXT_PUBLIC_API_URL?.trim();
    if (configured) {
      const host = window.location.hostname;
      const remote = host !== "localhost" && host !== "127.0.0.1";
      if (remote && /localhost|127\.0\.0\.1/.test(configured)) return "/backend";
      return configured.replace(/\/$/, "");
    }
    return "/backend";
  }
  return process.env.NEXT_PUBLIC_API_URL?.replace(/\/$/, "") || "http://127.0.0.1:8000";
}

const BASE = getBrandingBase();

function toRgb(value: string): string | null {
  const v = value.trim();
  const m = v.match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}

export async function fetchBranding(tenantId: string): Promise<Branding | null> {
  try {
    const res = await fetch(`${BASE}/crm/${tenantId}/branding`, {
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export function applyBranding(b: Branding) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (b.brand_primary_color) {
    root.style.setProperty("--brand-primary", b.brand_primary_color);
    const rgb = toRgb(b.brand_primary_color);
    if (rgb) root.style.setProperty("--brand", rgb);
  }
  if (b.brand_accent_color) {
    root.style.setProperty("--brand-accent", b.brand_accent_color);
    const rgb = toRgb(b.brand_accent_color);
    if (rgb) root.style.setProperty("--accent", rgb);
  }
  if (b.brand_favicon_url) {
    let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.href = b.brand_favicon_url;
  }
  if (b.brand_name || b.name) {
    document.title = `${b.brand_name || b.name} — Leads`;
  }
}

export function useBranding(tenantId: string) {
  const [brand, setBrand] = useState<Branding | null>(null);
  useEffect(() => {
    if (!tenantId || tenantId === "YOUR_TENANT_UUID") return;
    fetchBranding(tenantId).then((b) => {
      if (b) {
        setBrand(b);
        applyBranding(b);
      }
    });
  }, [tenantId]);
  return brand;
}
