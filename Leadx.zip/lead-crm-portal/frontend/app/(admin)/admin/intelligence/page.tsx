"use client";

import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";

export default function AdminIntelligencePage() {
  const [pack, setPack] = useState<any>(null);
  const [qa, setQa] = useState<any>(null);
  const [bad, setBad] = useState<any[]>([]);
  const [territories, setTerritories] = useState<any[]>([]);
  const [form, setForm] = useState({ vertical: "medspa", geo: "Hoboken", limit: 20 });
  const [terr, setTerr] = useState({ tenant_id: "", vertical: "medspa", geo_key: "hoboken nj" });
  const [tenants, setTenants] = useState<any[]>([]);
  const [msg, setMsg] = useState("");
  const [qaForm, setQaForm] = useState({
    lead_id: "",
    phone_ok: true,
    email_ok: true,
    business_open: true,
    notes: "",
  });

  useEffect(() => {
    admin.qaStats().then(setQa).catch(() => {});
    admin.badLeads().then((d) => setBad(d.reports || [])).catch(() => {});
    admin.territories().then((d) => setTerritories(d.territories || [])).catch(() => {});
    admin.tenants().then((d) => setTenants(d.tenants || [])).catch(() => {});
  }, []);

  async function genPack() {
    try {
      const r = await admin.samplePack(form);
      setPack(r);
      setMsg(`Sample pack: ${r.count} leads`);
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  async function submitQa() {
    try {
      await admin.qaSubmit(qaForm);
      setMsg("QA saved");
      admin.qaStats().then(setQa);
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  async function resolve(id: string, credit: boolean, tenant_id?: string, assignment_id?: string) {
    await admin.resolveBadLead({ report_id: id, credit, tenant_id, assignment_id });
    setMsg(credit ? "Credited" : "Rejected");
    admin.badLeads().then((d) => setBad(d.reports || []));
  }

  async function addTerritory() {
    try {
      await admin.createTerritory(terr);
      setMsg("Territory locked exclusive");
      admin.territories().then((d) => setTerritories(d.territories || []));
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  return (
    <div className="space-y-8 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-ink">Intelligence layer</h1>
        <p className="text-sm text-ink-muted">
          Sample packs · QA accuracy · territories · bad-lead queue — beyond ZoomInfo lists
        </p>
      </header>

      {msg && <p className="text-sm text-amber-300">{msg}</p>}

      {/* Accuracy */}
      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Contact accuracy (last 30d)</h2>
        {qa ? (
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ["Samples", qa.samples],
              ["Phone OK %", qa.phone_ok_pct ?? "—"],
              ["Email OK %", qa.email_ok_pct ?? "—"],
              ["Open %", qa.business_open_pct ?? "—"],
            ].map(([l, v]) => (
              <div key={String(l)} className="rounded-lg bg-surface/50 p-3">
                <div className="text-xs text-ink-faint">{l}</div>
                <div className="text-xl font-semibold text-ink">{v}</div>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-2 text-sm text-ink-faint">No QA samples yet — submit below</p>
        )}
      </section>

      {/* Sample pack */}
      <section className="space-y-3 rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Sales sample pack</h2>
        <div className="flex flex-wrap gap-2">
          <input
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.vertical}
            onChange={(e) => setForm({ ...form, vertical: e.target.value })}
            placeholder="vertical"
          />
          <input
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.geo}
            onChange={(e) => setForm({ ...form, geo: e.target.value })}
            placeholder="geo"
          />
          <button onClick={genPack} className="rounded-lg bg-amber-600 px-4 py-2 text-sm text-ink">
            Generate pack
          </button>
        </div>
        {pack && (
          <pre className="max-h-64 overflow-auto text-xs text-ink-muted">
            {JSON.stringify(pack.leads?.slice(0, 5), null, 2)}
            {pack.count > 5 ? `\n… +${pack.count - 5} more` : ""}
          </pre>
        )}
      </section>

      {/* QA submit */}
      <section className="space-y-2 rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">QA a lead</h2>
        <input
          placeholder="lead_id"
          className="w-full rounded-lg border border-line bg-surface px-3 py-2 text-sm"
          value={qaForm.lead_id}
          onChange={(e) => setQaForm({ ...qaForm, lead_id: e.target.value })}
        />
        <div className="flex gap-4 text-sm text-ink-muted">
          {(["phone_ok", "email_ok", "business_open"] as const).map((k) => (
            <label key={k} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={!!qaForm[k]}
                onChange={(e) => setQaForm({ ...qaForm, [k]: e.target.checked })}
              />
              {k}
            </label>
          ))}
        </div>
        <button onClick={submitQa} className="rounded-lg border border-line px-3 py-1.5 text-sm text-ink-muted">
          Save QA
        </button>
      </section>

      {/* Bad leads */}
      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Bad-lead queue</h2>
        <ul className="mt-3 divide-y divide-line">
          {bad.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
              <span className="text-ink-muted">
                {r.reason} · {r.detail || "—"}
              </span>
              <span className="flex gap-2">
                <button
                  onClick={() => resolve(r.id, true, r.tenant_id, r.assignment_id)}
                  className="rounded bg-signal-800 px-2 py-1 text-xs text-ink"
                >
                  Credit
                </button>
                <button
                  onClick={() => resolve(r.id, false)}
                  className="rounded bg-surface-3 px-2 py-1 text-xs text-ink-muted"
                >
                  Reject
                </button>
              </span>
            </li>
          ))}
          {bad.length === 0 && <li className="py-2 text-ink-faint">No open reports</li>}
        </ul>
      </section>

      {/* Territories */}
      <section className="space-y-3 rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Exclusive territories</h2>
        <div className="flex flex-wrap gap-2">
          <select
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={terr.tenant_id}
            onChange={(e) => setTerr({ ...terr, tenant_id: e.target.value })}
          >
            <option value="">Client…</option>
            {tenants.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
          <input
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={terr.vertical}
            onChange={(e) => setTerr({ ...terr, vertical: e.target.value })}
            placeholder="vertical"
          />
          <input
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={terr.geo_key}
            onChange={(e) => setTerr({ ...terr, geo_key: e.target.value })}
            placeholder="geo key"
          />
          <button onClick={addTerritory} className="rounded-lg bg-brand-600 px-3 py-2 text-sm text-ink">
            Lock exclusive
          </button>
        </div>
        <ul className="mt-2 space-y-1 text-sm text-ink-muted">
          {territories.map((t) => (
            <li key={t.id}>
              {t.vertical} · {t.geo_key} → {t.tenant_id?.slice(0, 8)}…
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
