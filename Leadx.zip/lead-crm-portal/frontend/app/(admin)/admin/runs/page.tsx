"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { admin } from "@/lib/admin";

export default function AdminRunsPage() {
  const [runs, setRuns] = useState<any[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    admin
      .runs()
      .then((d) => setRuns(d.runs || []))
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="p-8 text-red-400">{error}</div>;

  return (
    <div className="page">
      <header>
        <h1 className="text-2xl font-semibold text-ink">Pipeline runs</h1>
        <p className="text-sm text-ink-muted">Recent discover → deliver jobs</p>
      </header>

      <div className="overflow-x-auto rounded-xl border border-line">
        <table className="w-full min-w-[800px] text-left text-sm">
          <thead className="border-b border-line bg-surface-2 text-xs uppercase text-ink-faint">
            <tr>
              <th className="px-3 py-3">Started</th>
              <th className="px-3 py-3">Status</th>
              <th className="px-3 py-3">Found</th>
              <th className="px-3 py-3">Enriched</th>
              <th className="px-3 py-3">Gated</th>
              <th className="px-3 py-3">Assigned</th>
              <th className="px-3 py-3">Delivered</th>
              <th className="px-3 py-3">Error</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {runs.map((r) => (
              <tr key={r.id} className="hover:bg-surface-3/60">
                <td className="px-3 py-2 text-xs text-ink-muted">
                  {r.started_at ? new Date(r.started_at).toLocaleString() : "—"}
                  <div><Link href={`/admin/runs/${r.id}`} className="text-[11px] text-amber-400">Board →</Link></div>
                </td>
                <td className="px-3 py-2">
                  <span
                    className={`rounded px-1.5 py-0.5 text-xs ${
                      r.status === "completed"
                        ? "bg-signal-900/40 text-signal-300"
                        : r.status === "failed"
                          ? "bg-red-900/40 text-red-300"
                          : "bg-surface-3 text-ink-muted"
                    }`}
                  >
                    {r.status}
                  </span>
                </td>
                <td className="px-3 py-2 tabular-nums text-ink-muted">{r.discovered ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-ink-muted">{r.enriched ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-ink-muted">{r.gated_ok ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-ink-muted">{r.assigned ?? "—"}</td>
                <td className="px-3 py-2 tabular-nums text-ink-muted">{r.delivered ?? "—"}</td>
                <td className="max-w-[200px] truncate px-3 py-2 text-xs text-red-400">
                  {r.error_message || ""}
                </td>
              </tr>
            ))}
            {runs.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-ink-faint">
                  No runs yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
