"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { admin } from "@/lib/admin";

type RunLead = {
  id?: string;
  lead_id: string;
  run_id: string;
  stage: string;
  tier?: string | null;
  included?: boolean;
  score?: number;
  name?: string;
  phone?: string;
  website?: string;
  city?: string;
  source?: string;
};

const COLUMNS: { key: string; title: string; hint: string }[] = [
  { key: "discovered", title: "Discovered", hint: "All found leads" },
  { key: "enriched", title: "Enriched", hint: "Website/data pulled" },
  { key: "gated", title: "Passed gate", hint: "Quality OK" },
  { key: "assigned", title: "Assigned · Tier A", hint: "On client leads (A)" },
  { key: "assigned_B", title: "Assigned · Tier B", hint: "On client leads (B)" },
  { key: "excluded", title: "Excluded", hint: "Removed from client" },
];

function columnFor(L: RunLead): string {
  if (L.stage === "excluded" || L.included === false) return "excluded";
  if (L.stage === "assigned") {
    return (L.tier || "").toUpperCase() === "B" ? "assigned_B" : "assigned";
  }
  if (L.stage === "gated") return "gated";
  if (L.stage === "enriched") return "enriched";
  return "discovered";
}

function LeadCard({
  lead,
  onDragStart,
}: {
  lead: RunLead;
  onDragStart: (e: React.DragEvent, lead: RunLead) => void;
}) {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, lead)}
      className="cursor-grab rounded-lg border border-line bg-surface-2 shadow-sm p-3 active:cursor-grabbing hover:border-brand-500/50"
    >
      <div className="text-sm font-medium text-ink line-clamp-2">
        {lead.name || "Unnamed"}
      </div>
      <div className="mt-1 text-xs tabular-nums text-ink-muted">
        {lead.phone || "—"}
      </div>
      <div className="mt-0.5 text-[11px] text-ink-faint line-clamp-1">
        {[lead.city, lead.source].filter(Boolean).join(" · ") || "—"}
      </div>
      {lead.website && (
        <a
          href={lead.website.startsWith("http") ? lead.website : `https://${lead.website}`}
          target="_blank"
          rel="noreferrer"
          className="mt-1 block truncate text-[11px] text-brand-600 dark:text-brand-400/80 hover:underline"
          onClick={(e) => e.stopPropagation()}
        >
          {lead.website.replace(/^https?:\/\//, "")}
        </a>
      )}
      <div className="mt-2 flex items-center justify-between text-[10px] text-ink-faint">
        <span>{lead.tier ? `Tier ${lead.tier}` : "No tier"}</span>
        {lead.score != null && <span>Score {lead.score}</span>}
      </div>
    </div>
  );
}

export default function RunBoardPage() {
  const params = useParams();
  const runId = String(params?.runId || "");
  const [run, setRun] = useState<any>(null);
  const [leads, setLeads] = useState<RunLead[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    if (!runId) return;
    admin
      .runLeads(runId)
      .then((d: any) => {
        setRun(d.run);
        setLeads(d.leads || []);
        if (d.error) setError(d.error);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [runId]);

  useEffect(() => {
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [load]);

  const buckets = useMemo(() => {
    const map: Record<string, RunLead[]> = {};
    COLUMNS.forEach((c) => (map[c.key] = []));
    for (const L of leads) {
      const k = columnFor(L);
      if (!map[k]) map[k] = [];
      map[k].push(L);
    }
    return map;
  }, [leads]);

  function onDragStart(e: React.DragEvent, lead: RunLead) {
    e.dataTransfer.setData("text/lead_id", lead.lead_id);
    e.dataTransfer.effectAllowed = "move";
  }

  function onDragOver(e: React.DragEvent) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }

  async function onDrop(e: React.DragEvent, columnKey: string) {
    e.preventDefault();
    const leadId = e.dataTransfer.getData("text/lead_id");
    if (!leadId || !runId) return;

    let stage = columnKey;
    let tier: string | undefined;
    let included = true;
    let assign: boolean | undefined;

    if (columnKey === "assigned") {
      stage = "assigned";
      tier = "A";
      assign = true;
    } else if (columnKey === "assigned_B") {
      stage = "assigned";
      tier = "B";
      assign = true;
    } else if (columnKey === "excluded") {
      stage = "excluded";
      included = false;
      assign = false;
    } else {
      assign = false;
    }

    setSaving(true);
    setMsg("");
    try {
      const res: any = await admin.patchRunLead(runId, leadId, { stage, tier, included, assign });
      const c = res?.run_counts;
      setMsg(
        c
          ? `Updated → ${columnKey.replace(/_/g, " ")} · funnel ${c.discovered ?? "?"}→${c.enriched ?? "?"}→${c.gated_ok ?? c.gated ?? "?"}→${c.assigned ?? "?"} (delivered ${c.delivered ?? "?"})`
          : `Updated → ${columnKey.replace(/_/g, " ")}`
      );
      load();
    } catch (err: any) {
      setMsg(err.message || "Update failed");
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="p-8 text-ink-faint">Loading board…</div>;

  return (
    <div className="flex h-[calc(100vh-0px)] flex-col p-6">
      <header className="mb-4 shrink-0">
        <Link href="/admin/runs" className="text-xs text-ink-faint hover:text-brand-600 dark:text-brand-500">
          ← Run history
        </Link>
        <h1 className="mt-1 text-xl font-semibold text-ink">Run board</h1>
        <p className="text-sm text-ink-muted">
          Drag cards between columns. Assigned A/B appear on client Leads. Excluded removes assignment.
        </p>
        {run && (
          <div className="mt-2 flex flex-wrap gap-3 text-xs text-ink-faint">
            <span>Status: <span className="text-ink-muted">{run.status}</span></span>
            <span>Found {run.discovered ?? 0}</span>
            <span>Enriched {run.enriched ?? 0}</span>
            <span>Gated {run.gated_ok ?? 0}</span>
            <span>Assigned {run.assigned ?? 0}</span>
          </div>
        )}
        {error && (
          <p className="mt-2 text-sm text-brand-600 dark:text-brand-500">
            {error}
            <span className="block text-xs text-ink-faint">
              Run in Supabase SQL: lead-engine-v2/sql/010_pipeline_run_leads.sql
            </span>
          </p>
        )}
        {msg && <p className="mt-1 text-xs text-signal-400">{msg}</p>}
        {saving && <p className="text-xs text-ink-faint">Saving…</p>}
      </header>

      <div className="flex min-h-0 flex-1 gap-3 overflow-x-auto pb-4">
        {COLUMNS.map((col) => (
          <div
            key={col.key}
            onDragOver={onDragOver}
            onDrop={(e) => onDrop(e, col.key)}
            className="flex w-64 shrink-0 flex-col rounded-xl border border-line bg-surface-2 shadow-sm"
          >
            <div className="border-b border-line px-3 py-2">
              <div className="text-sm font-medium text-ink">{col.title}</div>
              <div className="text-[11px] text-ink-faint">
                {col.hint} · {buckets[col.key]?.length || 0}
              </div>
            </div>
            <div className="flex-1 space-y-2 overflow-y-auto p-2">
              {(buckets[col.key] || []).map((L) => (
                <LeadCard key={L.lead_id} lead={L} onDragStart={onDragStart} />
              ))}
              {(buckets[col.key] || []).length === 0 && (
                <div className="rounded-lg border border-dashed border-line px-2 py-8 text-center text-[11px] text-ink-muted">
                  <span className="text-ink-faint">No cards yet — open Board after a run that wrote cards, or refresh</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
