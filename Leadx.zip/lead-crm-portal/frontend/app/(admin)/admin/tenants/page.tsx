"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { admin } from "@/lib/admin";

export default function AdminTenantsPage() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    plan: "starter",
    leads_per_month_limit: 100,
    allow_tier_b: false,
    delivery_channel: "telegram",
    bot_token: "",
    chat_id: "",
    // Combined ICP fields
    vertical: "",
    geo: "",
    keywords: "",
    offer_category: "lead_gen_service",
    // Branding
    brand_color: "",
    logo_url: "",
  });
  const [msg, setMsg] = useState("");

  function load() {
    admin
      .tenants()
      .then((d) => setTenants(d.tenants || []))
      .catch((e) => setError(e.message));
  }

  useEffect(() => {
    load();
  }, []);

  async function create() {
    setMsg("");
    try {
      const delivery_config: Record<string, string> = {};
      if (form.bot_token) delivery_config.bot_token = form.bot_token;
      if (form.chat_id) delivery_config.chat_id = form.chat_id;
      const created: any = await admin.createTenant({
        name: form.name,
        plan: form.plan,
        leads_per_month_limit: Number(form.leads_per_month_limit),
        allow_tier_b: form.allow_tier_b,
        delivery_channel: form.delivery_channel,
        delivery_config,
        branding: {
          primary_color: form.brand_color || undefined,
          logo_url: form.logo_url || undefined,
        },
      });
      const tenantId = created?.id || created?.tenant_id;
      // Optionally create first ICP in the same flow
      if (tenantId && form.vertical.trim()) {
        try {
          await admin.createIcp({
            tenant_id: tenantId,
            name: `${form.vertical} — ${form.geo || "default"}`,
            vertical: form.vertical.trim(),
            geo: form.geo.split(",").map((s) => s.trim()).filter(Boolean),
            keywords: form.keywords.split(",").map((s) => s.trim()).filter(Boolean),
            offer_category: form.offer_category || "lead_gen_service",
            active: true,
          });
        } catch {
          /* ICP creation is best-effort in combined flow */
        }
      }
      setShowForm(false);
      setMsg(
        tenantId && form.vertical.trim()
          ? "Client + ICP created"
          : "Client created"
      );
      load();
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  if (error)
    return (
      <div className="p-8 text-red-400">
        {error}{" "}
        <Link href="/admin/login" className="text-amber-400">
          Login
        </Link>
      </div>
    );

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-ink">Clients</h1>
          <p className="text-sm text-ink-muted">Tenants who buy your lead service</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="rounded-lg bg-amber-600 px-4 py-2 text-sm font-medium text-ink"
        >
          {showForm ? "Cancel" : "New client"}
        </button>
      </header>

      {msg && <p className="text-sm text-amber-300">{msg}</p>}

      {showForm && (
        <div className="grid gap-3 rounded-xl border border-line bg-surface-2/60 p-5 sm:grid-cols-2">
          <input
            placeholder="Agency / company name"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <select
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.plan}
            onChange={(e) => setForm({ ...form, plan: e.target.value })}
          >
            <option value="starter">Starter</option>
            <option value="growth">Growth</option>
            <option value="premium">Premium</option>
            <option value="enterprise">Enterprise</option>
          </select>
          <input
            type="number"
            placeholder="Monthly lead limit"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.leads_per_month_limit}
            onChange={(e) =>
              setForm({ ...form, leads_per_month_limit: Number(e.target.value) })
            }
          />
          <select
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.delivery_channel}
            onChange={(e) => setForm({ ...form, delivery_channel: e.target.value })}
          >
            <option value="telegram">Telegram</option>
            <option value="webhook">Webhook</option>
            <option value="email">Email</option>
            <option value="csv">CSV only</option>
          </select>
          <input
            placeholder="Telegram bot token (optional)"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.bot_token}
            onChange={(e) => setForm({ ...form, bot_token: e.target.value })}
          />
          <input
            placeholder="Telegram chat id"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.chat_id}
            onChange={(e) => setForm({ ...form, chat_id: e.target.value })}
          />
          <label className="flex items-center gap-2 text-sm text-ink-muted sm:col-span-2">
            <input
              type="checkbox"
              checked={form.allow_tier_b}
              onChange={(e) => setForm({ ...form, allow_tier_b: e.target.checked })}
            />
            Allow Tier B leads
          </label>

          <div className="sm:col-span-2 border-t border-line pt-3 text-xs font-semibold uppercase tracking-wide text-ink-faint">
            First ICP (optional)
          </div>
          <input
            placeholder="Vertical (e.g. medspa)"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.vertical}
            onChange={(e) => setForm({ ...form, vertical: e.target.value })}
          />
          <input
            placeholder="Geo (comma-separated)"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.geo}
            onChange={(e) => setForm({ ...form, geo: e.target.value })}
          />
          <input
            placeholder="Keywords"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.keywords}
            onChange={(e) => setForm({ ...form, keywords: e.target.value })}
          />
          <input
            placeholder="Offer category"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.offer_category}
            onChange={(e) => setForm({ ...form, offer_category: e.target.value })}
          />

          <div className="sm:col-span-2 border-t border-line pt-3 text-xs font-semibold uppercase tracking-wide text-ink-faint">
            Branding (optional)
          </div>
          <input
            placeholder="Brand color (#hex)"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.brand_color}
            onChange={(e) => setForm({ ...form, brand_color: e.target.value })}
          />
          <input
            placeholder="Logo URL"
            className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={form.logo_url}
            onChange={(e) => setForm({ ...form, logo_url: e.target.value })}
          />

          <button
            onClick={create}
            disabled={!form.name}
            className="rounded-lg bg-brand-600 px-4 py-2 text-sm text-ink disabled:opacity-50 sm:col-span-2"
          >
            Create client{form.vertical.trim() ? " + ICP" : ""}
          </button>
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-line">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line bg-surface-2 text-xs uppercase text-ink-faint">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Plan</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Quota</th>
              <th className="px-4 py-3">Delivery</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {tenants.map((t) => (
              <tr key={t.id} className="hover:bg-surface-3/50">
                <td className="px-4 py-3 font-medium text-ink">{t.name}</td>
                <td className="px-4 py-3 text-ink-muted">{t.plan}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded px-2 py-0.5 text-xs ${
                      t.status === "active"
                        ? "bg-signal-900/50 text-signal-300"
                        : "bg-surface-3 text-ink-muted"
                    }`}
                  >
                    {t.status}
                  </span>
                </td>
                <td className="px-4 py-3 tabular-nums text-ink-muted">
                  {t.leads_per_month_limit}/mo
                </td>
                <td className="px-4 py-3 text-ink-faint">{t.delivery_channel}</td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/tenants/${t.id}`} className="text-amber-400 hover:underline">
                    Manage
                  </Link>
                </td>
              </tr>
            ))}
            {tenants.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-ink-faint">
                  No clients yet — create one above
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
