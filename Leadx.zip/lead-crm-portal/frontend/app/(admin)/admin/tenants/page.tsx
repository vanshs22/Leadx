"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { admin } from "@/lib/admin";

export default function AdminTenantsPage() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    name: "",
    plan: "starter",
    leads_per_month_limit: 100,
    allow_tier_b: false,
    delivery_channel: "telegram",
    bot_token: "",
    chat_id: "",
  });
  const [msg, setMsg] = useState("");

  function load() {
    admin
      .tenants()
      .then((d) => setTenants(d.tenants || []))
      .catch((e) => setError(e.message));
  }

  useEffect(() => {
    load();
  }, []);

  async function create() {
    setMsg("");
    try {
      const delivery_config: Record<string, string> = {};
      if (form.bot_token) delivery_config.bot_token = form.bot_token;
      if (form.chat_id) delivery_config.chat_id = form.chat_id;
      await admin.createTenant({
        name: form.name,
        plan: form.plan,
        leads_per_month_limit: Number(form.leads_per_month_limit),
        allow_tier_b: form.allow_tier_b,
        delivery_channel: form.delivery_channel,
        delivery_config,
      });
      setShowForm(false);
      setMsg("Client created");
      load();
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  if (error)
    return (
      <div className="p-8 text-red-400">
        {error}{" "}
        <Link href="/admin/login" className="text-amber-400">
          Login
        </Link>
      </div>
    );

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-white">Clients</h1>
          <p className="text-sm text-slate-400">Tenants who buy your lead service</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="rounded-lg bg-amber-600 px-4 py-2 text-sm font-medium text-white"
        >
          {showForm ? "Cancel" : "New client"}
        </button>
      </header>

      {msg && <p className="text-sm text-amber-300">{msg}</p>}

      {showForm && (
        <div className="grid gap-3 rounded-xl border border-slate-800 bg-slate-900/60 p-5 sm:grid-cols-2">
          <input
            placeholder="Agency / company name"
            className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <select
            className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.plan}
            onChange={(e) => setForm({ ...form, plan: e.target.value })}
          >
            <option value="starter">Starter</option>
            <option value="growth">Growth</option>
            <option value="premium">Premium</option>
            <option value="enterprise">Enterprise</option>
          </select>
          <input
            type="number"
            placeholder="Monthly lead limit"
            className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.leads_per_month_limit}
            onChange={(e) =>
              setForm({ ...form, leads_per_month_limit: Number(e.target.value) })
            }
          />
          <select
            className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.delivery_channel}
            onChange={(e) => setForm({ ...form, delivery_channel: e.target.value })}
          >
            <option value="telegram">Telegram</option>
            <option value="webhook">Webhook</option>
            <option value="email">Email</option>
            <option value="csv">CSV only</option>
          </select>
          <input
            placeholder="Telegram bot token (optional)"
            className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.bot_token}
            onChange={(e) => setForm({ ...form, bot_token: e.target.value })}
          />
          <input
            placeholder="Telegram chat id"
            className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
            value={form.chat_id}
            onChange={(e) => setForm({ ...form, chat_id: e.target.value })}
          />
          <label className="flex items-center gap-2 text-sm text-slate-400">
            <input
              type="checkbox"
              checked={form.allow_tier_b}
              onChange={(e) => setForm({ ...form, allow_tier_b: e.target.checked })}
            />
            Allow Tier B leads
          </label>
          <button
            onClick={create}
            disabled={!form.name}
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm text-white disabled:opacity-50"
          >
            Create client
          </button>
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-slate-800">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-800 bg-slate-900/80 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Plan</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Quota</th>
              <th className="px-4 py-3">Delivery</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {tenants.map((t) => (
              <tr key={t.id} className="hover:bg-slate-900/40">
                <td className="px-4 py-3 font-medium text-white">{t.name}</td>
                <td className="px-4 py-3 text-slate-400">{t.plan}</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded px-2 py-0.5 text-xs ${
                      t.status === "active"
                        ? "bg-emerald-900/50 text-emerald-300"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {t.status}
                  </span>
                </td>
                <td className="px-4 py-3 tabular-nums text-slate-400">
                  {t.leads_per_month_limit}/mo
                </td>
                <td className="px-4 py-3 text-slate-500">{t.delivery_channel}</td>
                <td className="px-4 py-3 text-right">
                  <Link href={`/admin/tenants/${t.id}`} className="text-amber-400 hover:underline">
                    Manage
                  </Link>
                </td>
              </tr>
            ))}
            {tenants.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                  No clients yet — create one above
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
