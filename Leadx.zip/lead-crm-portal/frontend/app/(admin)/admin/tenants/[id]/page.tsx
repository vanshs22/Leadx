"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { admin } from "@/lib/admin";

export default function AdminTenantDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<any>(null);
  const [msg, setMsg] = useState("");
  const [stripe, setStripe] = useState({ customer: "", item: "" });
  const [inviteEmail, setInviteEmail] = useState("");

  function load() {
    admin.tenant(id).then(setData).catch((e) => setMsg(e.message));
  }

  useEffect(() => {
    load();
  }, [id]);

  async function setStatus(status: string) {
    await admin.updateTenant(id, { status });
    setMsg(`Status → ${status}`);
    load();
  }

  async function saveQuota(limit: number) {
    await admin.updateTenant(id, { leads_per_month_limit: limit });
    setMsg("Quota updated");
    load();
  }

  async function linkStripe() {
    await admin.billingLink({
      tenant_id: id,
      stripe_customer_id: stripe.customer,
      stripe_subscription_item_id: stripe.item || undefined,
    });
    setMsg("Stripe linked");
    load();
  }

  async function reportBilling() {
    const r = await admin.billingReport(id);
    setMsg(JSON.stringify(r));
  }

  async function invite() {
    const r = await admin.teamInvite({
      tenant_id: id,
      email: inviteEmail,
      role: "member",
      send_email: true,
    });
    setMsg(r.ok ? `Invite: ${r.invite_url || "sent"}` : r.error);
  }

  if (!data && !msg) return <div className="p-8 text-ink-faint">Loading…</div>;
  if (!data) return <div className="p-8 text-red-400">{msg}</div>;

  const t = data.tenant;

  return (
    <div className="space-y-6 p-8">
      <Link href="/admin/tenants" className="text-sm text-ink-faint hover:text-ink-muted">
        ← Clients
      </Link>
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-ink">{t.name}</h1>
          <p className="mt-1 font-mono text-xs text-ink-muted">{t.id}</p>
        </div>
        <div className="flex gap-2">
          {t.status === "active" ? (
            <button
              onClick={() => setStatus("paused")}
              className="rounded-lg border border-line px-3 py-1.5 text-sm text-ink-muted"
            >
              Pause
            </button>
          ) : (
            <button
              onClick={() => setStatus("active")}
              className="rounded-lg bg-signal-700 px-3 py-1.5 text-sm text-ink"
            >
              Activate
            </button>
          )}
          <Link
            href={`/admin/pipeline?tenant=${id}`}
            className="rounded-lg bg-amber-600 px-3 py-1.5 text-sm text-ink"
          >
            Run pipeline
          </Link>
        </div>
      </header>

      {msg && <p className="text-sm text-amber-300">{msg}</p>}

      <div className="grid gap-4 lg:grid-cols-3">
        <section className="rounded-xl border border-line bg-surface-2/60 p-5">
          <h2 className="text-sm font-semibold text-ink">Plan & quota</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-ink-faint">Plan</dt>
              <dd className="text-ink">{t.plan}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-faint">Status</dt>
              <dd className="text-ink">{t.status}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-faint">Monthly limit</dt>
              <dd className="text-ink">{t.leads_per_month_limit}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-faint">Delivery</dt>
              <dd className="text-ink">{t.delivery_channel}</dd>
            </div>
          </dl>
          <div className="mt-4 flex gap-2">
            {[50, 100, 300, 500].map((n) => (
              <button
                key={n}
                onClick={() => saveQuota(n)}
                className="rounded border border-line px-2 py-1 text-xs text-ink-muted hover:bg-surface-3"
              >
                {n}
              </button>
            ))}
          </div>
        </section>

        <section className="rounded-xl border border-line bg-surface-2/60 p-5">
          <h2 className="text-sm font-semibold text-ink">Stripe</h2>
          <p className="mt-1 text-xs text-ink-faint">
            Customer: {t.stripe_customer_id || "—"}
          </p>
          <input
            placeholder="cus_..."
            className="mt-3 w-full rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={stripe.customer}
            onChange={(e) => setStripe({ ...stripe, customer: e.target.value })}
          />
          <input
            placeholder="si_... (optional)"
            className="mt-2 w-full rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={stripe.item}
            onChange={(e) => setStripe({ ...stripe, item: e.target.value })}
          />
          <div className="mt-3 flex gap-2">
            <button onClick={linkStripe} className="rounded-lg bg-brand-600 px-3 py-1.5 text-sm text-ink">
              Link
            </button>
            <button onClick={reportBilling} className="rounded-lg border border-line px-3 py-1.5 text-sm text-ink-muted">
              Report usage
            </button>
          </div>
        </section>

        <section className="rounded-xl border border-line bg-surface-2/60 p-5">
          <h2 className="text-sm font-semibold text-ink">Invite teammate</h2>
          <input
            type="email"
            placeholder="email@agency.com"
            className="mt-3 w-full rounded-lg border border-line bg-surface px-3 py-2 text-sm"
            value={inviteEmail}
            onChange={(e) => setInviteEmail(e.target.value)}
          />
          <button
            onClick={invite}
            className="mt-3 rounded-lg border border-line px-3 py-1.5 text-sm text-ink-muted"
          >
            Send invite
          </button>
        </section>
      </div>

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-ink">ICPs</h2>
          <Link href={`/admin/icps?tenant=${id}`} className="text-xs text-amber-400">
            Manage ICPs
          </Link>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {(data.icps || []).map((i: any) => (
            <li key={i.id} className="flex justify-between py-2 text-sm">
              <span className="text-ink">
                {i.vertical} · {(i.geo || []).join(", ")}
              </span>
              <span className="text-ink-faint">{i.active ? "active" : "off"}</span>
            </li>
          ))}
          {(data.icps || []).length === 0 && (
            <li className="py-2 text-sm text-ink-faint">No ICPs — create under ICPs</li>
          )}
        </ul>
      </section>

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Recent usage</h2>
        <ul className="mt-3 space-y-1 text-sm text-ink-muted">
          {(data.usage || []).map((u: any) => (
            <li key={u.period} className="flex justify-between">
              <span>{u.period}</span>
              <span>
                delivered {u.leads_delivered || 0} · credited {u.leads_credited || 0}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
