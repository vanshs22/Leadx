"use client";

import { useCallback, useEffect, useState } from "react";

import { NotificationList, type NotificationRow } from "@/components/layout/NotificationList";
import { adminExtras } from "@/lib/admin";

export default function AdminNotificationsPage() {
  const [rows, setRows] = useState<NotificationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const d = await adminExtras.notifications();
      setRows((d.notifications || []) as NotificationRow[]);
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="page">
      <header>
        <h1 className="page-title">Notifications</h1>
        <p className="page-sub">
          Operator-scoped: failed jobs, complaint spikes, positive replies across every client
        </p>
      </header>

      <NotificationList
        rows={rows}
        loading={loading}
        error={error}
        onMarkRead={async (ids) => {
          await adminExtras.markRead(ids);
          await load();
        }}
        onMarkAll={async () => {
          await adminExtras.markAllRead();
          await load();
        }}
      />
    </div>
  );
}
