"use client";

import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";

export default function AdminOpsPage() {
  const [ops, setOps] = useState<any>(null);
  const [health, setHealth] = useState<any>(null);
  const [keys, setKeys] = useState<any>(null);
  const [days, setDays] = useState(14);
  const [msg, setMsg] = useState("");

  function load() {
    admin.ops(days).then(setOps).catch((e) => setMsg(e.message));
    admin.health().then(setHealth).catch(() => {});
    admin.keysHealth().then(setKeys).catch(() => {});
  }

  useEffect(() => {
    load();
  }, [days]);

  async function refreshPriors(vertical: string) {
    const r = await admin.refreshPriors(vertical);
    setMsg(`Priors ${vertical}: ${JSON.stringify(r)}`);
  }

  return (
    <div className="space-y-6 p-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-ink">Ops health</h1>
          <p className="text-sm text-ink-muted">Enrich rates, keys, system status</p>
        </div>
        <select
          className="rounded-lg border border-line bg-surface px-3 py-2 text-sm"
          value={days}
          onChange={(e) => setDays(Number(e.target.value))}
        >
          <option value={7}>7 days</option>
          <option value={14}>14 days</option>
          <option value={30}>30 days</option>
        </select>
      </header>

      {msg && <p className="text-sm text-amber-300">{msg}</p>}

      {health && (
        <div
          className={`rounded-xl border px-4 py-3 text-sm ${
            health.ok
              ? "border-signal-800 bg-signal-900/30 text-signal-300"
              : "border-red-800 bg-red-950/30 text-red-300"
          }`}
        >
          Health: {health.ok ? "OK" : "DEGRADED"} · DB:{" "}
          {String(health.checks?.db)} · version {health.version}
        </div>
      )}

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Refresh vertical priors</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {["medspa", "salon", "dental", "gym", "wellness"].map((v) => (
            <button
              key={v}
              onClick={() => refreshPriors(v)}
              className="rounded-lg border border-line px-3 py-1.5 text-xs text-ink-muted hover:bg-surface-3"
            >
              {v}
            </button>
          ))}
        </div>
      </section>

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Ops metrics</h2>
        <pre className="mt-3 max-h-96 overflow-auto text-xs text-ink-muted">
          {ops ? JSON.stringify(ops, null, 2) : "Loading…"}
        </pre>
      </section>

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-ink">Key pool health</h2>
        <pre className="mt-3 max-h-64 overflow-auto text-xs text-ink-muted">
          {keys ? JSON.stringify(keys, null, 2) : "—"}
        </pre>
      </section>
    </div>
  );
}
