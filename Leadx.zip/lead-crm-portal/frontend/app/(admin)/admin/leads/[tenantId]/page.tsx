"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { admin } from "@/lib/admin";

export default function AdminClientLeadsPage() {
  const params = useParams();
  const tenantId = String(params?.tenantId || params?.id || "");
  const [leads, setLeads] = useState<any[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [clientName, setClientName] = useState("");

  useEffect(() => {
    if (!tenantId) return;
    setLoading(true);
    Promise.all([
      admin.clientLeads(tenantId, 200, 0),
      admin.tenants().catch(() => ({ tenants: [] })),
    ])
      .then(([leadRes, tenRes]: any[]) => {
        setLeads(leadRes.leads || []);
        const t = (tenRes.tenants || []).find((x: any) => x.id === tenantId);
        setClientName(t?.brand_name || t?.name || tenantId.slice(0, 8));
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [tenantId]);

  if (error) return <div className="p-8 text-red-400">{error}</div>;

  return (
    <div className="space-y-6 p-8">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link href="/admin/leads" className="text-xs text-slate-500 hover:text-amber-400">
            ← All clients
          </Link>
          <h1 className="mt-1 text-2xl font-semibold text-white">
            Leads · {clientName || "Client"}
          </h1>
          <p className="text-sm text-slate-400">
            {loading ? "Loading…" : `${leads.length} assigned lead${leads.length === 1 ? "" : "s"}`}
          </p>
        </div>
      </header>

      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full min-w-[900px] text-left text-sm">
          <thead className="border-b border-slate-800 bg-slate-900/80 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-3 py-3">Name</th>
              <th className="px-3 py-3">Phone</th>
              <th className="px-3 py-3">City</th>
              <th className="px-3 py-3">Website</th>
              <th className="px-3 py-3">Source</th>
              <th className="px-3 py-3">Tier</th>
              <th className="px-3 py-3">Status</th>
              <th className="px-3 py-3">Assigned</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {leads.map((l) => (
              <tr key={l.assignment_id || l.lead_id} className="hover:bg-slate-900/40">
                <td className="px-3 py-2 font-medium text-slate-200">
                  {l.name || "—"}
                </td>
                <td className="px-3 py-2 tabular-nums text-slate-400">
                  {l.phone || "—"}
                </td>
                <td className="px-3 py-2 text-slate-400">
                  {[l.city, l.state].filter(Boolean).join(", ") || "—"}
                </td>
                <td className="max-w-[180px] truncate px-3 py-2 text-slate-400">
                  {l.website ? (
                    <a
                      href={l.website}
                      target="_blank"
                      rel="noreferrer"
                      className="text-amber-400/90 hover:underline"
                    >
                      {l.website.replace(/^https?:\/\//, '')}
                    </a>
                  ) : (
                    "—"
                  )}
                </td>
                <td className="px-3 py-2 text-xs text-slate-500">{l.source || "—"}</td>
                <td className="px-3 py-2 text-slate-300">{l.tier || "—"}</td>
                <td className="px-3 py-2 text-xs text-slate-400">
                  {l.delivery_status || l.status || "—"}
                </td>
                <td className="px-3 py-2 text-xs text-slate-500">
                  {l.assigned_at
                    ? new Date(l.assigned_at).toLocaleString()
                    : "—"}
                </td>
              </tr>
            ))}
            {!loading && leads.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-slate-500">
                  No leads assigned to this client yet. Run the pipeline for them first.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
