"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { admin } from "@/lib/admin";

export default function AdminLeadDetailPage() {
  const { tenantId, leadId } = useParams<{ tenantId: string; leadId: string }>();
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!leadId) return;
    admin
      .leadDetail(String(leadId), tenantId ? String(tenantId) : undefined)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [leadId, tenantId]);

  if (error) {
    return (
      <div className="space-y-4 p-8">
        <Link href={`/admin/leads/${tenantId}`} className="text-sm text-brand-400">
          ← Back to leads
        </Link>
        <p className="text-rust-400">{error}</p>
      </div>
    );
  }

  if (!data) {
    return <div className="p-8 text-ink-faint">Loading lead…</div>;
  }

  const d = data.display || {};
  const g = data.lead || {};
  const en = data.enrichment || {};
  const sc = data.score || {};
  const a = data.assignment || {};

  const fields: [string, any][] = [
    ["Name", d.name || g.name],
    ["Tier", d.tier || sc.tier || "—"],
    ["Score", d.score ?? sc.total_score ?? "—"],
    ["Phone", d.phone || g.phone_e164 || g.phone_normalized],
    ["Email", d.email || en.email],
    ["Website", d.website || g.website],
    ["Address", d.address || g.address],
    ["City", d.city || g.city],
    ["State", d.state || g.state],
    ["Owner", d.owner || en.owner_name],
    ["Booking", d.booking || en.booking_platform || (en.has_booking ? "Yes" : "—")],
    ["Pitch", d.pitch || en.pitch_line],
    ["Rating", d.rating ?? g.google_rating],
    ["Reviews", d.reviews ?? g.review_count],
    ["Source", d.source || g.source],
    ["Category", g.category],
    ["Business status", g.business_status],
    ["Assignment status", a.status || d.status],
    ["Delivery status", a.delivery_status || d.delivery_status],
    ["Score reason", sc.reasoning || sc.score_reason],
    ["Intent score", en.intent_score],
    ["Lead ID", g.id || leadId],
  ];

  return (
    <div className="mx-auto max-w-3xl space-y-6 p-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link href={`/admin/leads/${tenantId}`} className="text-sm text-brand-400 hover:underline">
            ← Back to leads
          </Link>
          <h1 className="mt-2 text-2xl font-semibold text-ink">{d.name || g.name || "Lead"}</h1>
          <p className="text-sm text-ink-faint">
            Tier {(d.tier || "—").toString().toUpperCase()} · Score {d.score ?? "—"}
          </p>
        </div>
        {(d.website || g.website) && (
          <a
            href={
              String(d.website || g.website).startsWith("http")
                ? String(d.website || g.website)
                : `https://${d.website || g.website}`
            }
            target="_blank"
            rel="noreferrer"
            className="rounded-lg border border-line px-3 py-1.5 text-sm text-ink-muted hover:border-brand-500"
          >
            Open website
          </a>
        )}
      </div>

      <div className="overflow-hidden rounded-2xl border border-line bg-surface-2/40">
        <table className="w-full text-left text-sm">
          <tbody>
            {fields.map(([label, value]) => (
              <tr key={label} className="border-b border-line/60 last:border-0">
                <td className="w-40 px-4 py-2.5 text-xs font-medium uppercase tracking-wide text-ink-faint">
                  {label}
                </td>
                <td className="px-4 py-2.5 text-ink break-words">
                  {value === null || value === undefined || value === ""
                    ? "—"
                    : String(value)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {en.emails && Array.isArray(en.emails) && en.emails.length > 0 && (
        <div className="rounded-xl border border-line p-4 text-sm">
          <h2 className="mb-2 text-xs font-semibold uppercase text-ink-faint">Emails found</h2>
          <ul className="space-y-1 font-mono text-xs text-ink">
            {en.emails.map((e: string, i: number) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
