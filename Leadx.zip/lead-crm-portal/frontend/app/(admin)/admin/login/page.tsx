"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { setAdminKey, admin } from "@/lib/admin";

export default function AdminLoginPage() {
  const [key, setKey] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    setAdminKey(key.trim());
    try {
      await admin.globalStats();
      router.push("/admin");
    } catch (err: any) {
      setError(err.message || "Invalid service key");
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <form
        onSubmit={submit}
        className="w-full max-w-md space-y-4 rounded-2xl border border-slate-800 bg-slate-900/80 p-8 shadow-xl"
      >
        <div>
          <div className="text-xs uppercase tracking-widest text-amber-500/80">Operator</div>
          <h1 className="mt-1 text-xl font-semibold text-white">Admin access</h1>
          <p className="mt-2 text-sm text-slate-400">
            Enter your <code className="text-slate-300">LEAD_ENGINE_SERVICE_KEY</code>
          </p>
        </div>
        <input
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="Service key"
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2.5 text-sm text-white"
          autoFocus
        />
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={busy || key.length < 8}
          className="w-full rounded-lg bg-amber-600 py-2.5 text-sm font-medium text-white hover:bg-amber-500 disabled:opacity-50"
        >
          {busy ? "Checking…" : "Enter admin"}
        </button>
      </form>
    </div>
  );
}
