"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { setAdminKey, clearAdminKey, admin } from "@/lib/admin";
import { getSupabase } from "@/lib/supabaseClient";

export default function AdminLoginPage() {
  const [mode,setMode]=useState<"secure"|"service">("secure");
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [key,setKey]=useState("");
  const [error,setError]=useState(""); const [busy,setBusy]=useState(false); const router=useRouter();

  async function secureLogin(e:React.FormEvent){
    e.preventDefault(); setBusy(true); setError(""); clearAdminKey();
    try{
      const {data,error}=await getSupabase().auth.signInWithPassword({email:email.trim(),password});
      if(error||!data.session) throw new Error(error?.message||"Could not create admin session");
      setAdminKey(data.session.access_token);
      await admin.adminPing();
      router.push("/admin");
    }catch(err:any){await getSupabase().auth.signOut().catch(()=>{});clearAdminKey();setError(err?.message||"Admin login failed");setBusy(false);}
  }

  async function serviceLogin(e:React.FormEvent){
    e.preventDefault(); setBusy(true); setError(""); const k=key.trim(); setAdminKey(k);
    try{await admin.adminPing();router.push("/admin");}
    catch(err:any){clearAdminKey();setError(err?.message||"Service-key login failed");setBusy(false);}
  }

  return <div className="auth-shell"><div className="auth-card">
    <span className="auth-logo">LX</span><div className="eyebrow mt-4 text-brand-700 dark:text-brand-300">LeadX · Control plane</div><h1 className="auth-title">Admin access</h1><p className="mt-2 text-sm text-ink-muted">Use a Supabase-authenticated platform-admin session. The service-key path remains available for internal/local operations.</p>
    <div className="mt-5 flex rounded-xl border border-line bg-surface-2 p-1 text-xs font-semibold"><button type="button" onClick={()=>setMode("secure")} className={`flex-1 rounded-lg px-3 py-2 ${mode==="secure"?'bg-surface text-ink shadow-sm':'text-ink-muted'}`}>Secure session</button><button type="button" onClick={()=>setMode("service")} className={`flex-1 rounded-lg px-3 py-2 ${mode==="service"?'bg-surface text-ink shadow-sm':'text-ink-muted'}`}>Service key</button></div>
    {mode==="secure"?<form onSubmit={secureLogin} className="mt-5 space-y-3"><input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Admin email" className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm" autoFocus/><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password" className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm"/><button disabled={busy||!email||!password} className="btn-primary w-full py-2.5">{busy?'Signing in…':'Sign in securely'}</button><p className="text-xs text-ink-faint">Your user must exist in <code>platform_admins</code> with <code>active=true</code>.</p></form>:<form onSubmit={serviceLogin} className="mt-5 space-y-3"><input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="Internal service key" className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm" autoFocus/><button disabled={busy||key.length<8} className="btn-primary w-full py-2.5">{busy?'Checking…':'Enter with service key'}</button><p className="text-xs text-ink-faint">Prefer the secure session in production. Never expose service credentials to untrusted users.</p></form>}
    {error&&<div className="mt-4 rounded-xl border border-rust-300 bg-rust-50 p-3 text-sm text-rust-700 dark:bg-rust-500/10 dark:text-rust-300">{error}</div>}
  </div></div>;
}
