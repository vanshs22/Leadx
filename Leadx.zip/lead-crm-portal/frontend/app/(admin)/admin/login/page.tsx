"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { setAdminKey, clearAdminKey, admin } from "@/lib/admin";

export default function AdminLoginPage() {
  const [key, setKey] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const k = key.trim();
    setAdminKey(k);
    try {
      // 1) Prove API + service key without needing DB
      try {
        await admin.adminPing();
      } catch (err: any) {
        // Older backends without /admin/ping — fall through to globalStats
        const msg = String(err?.message || "");
        if (!msg.includes("404") && !msg.includes("Not Found")) {
          throw err;
        }
      }
      // 2) Optional stats (must not block login if DB is empty/partial)
      try {
        await admin.globalStats();
      } catch (err: any) {
        const msg = String(err?.message || "");
        // Auth failures already clear key in adminApi
        if (msg.includes("Session expired") || msg.includes("401") || msg.includes("Invalid")) {
          throw err;
        }
        // Network / 500 from stats — still allow entry if ping worked
        console.warn("global-stats after login:", msg);
      }
      router.push("/admin");
    } catch (err: any) {
      clearAdminKey();
      const raw = String(err?.message || "Login failed");
      let hint = raw;
      if (raw.includes("Cannot reach API") || raw.includes("Failed to fetch") || raw.includes("network")) {
        hint =
          "Cannot reach API. Start the backend on port 8000 and keep API_UPSTREAM=http://127.0.0.1:8000 in frontend .env.local.";
      } else if (raw === "Internal Server Error" || raw.includes("500")) {
        hint =
          "API returned 500. Check backend terminal logs. Usually SUPABASE_URL / SUPABASE_SERVICE_KEY missing or wrong in lead-engine-v2/.env — then restart the API.";
      } else if (raw.includes("Invalid or missing service key")) {
        hint =
          "Wrong LEAD_ENGINE_SERVICE_KEY. Copy the exact value from lead-engine-v2/.env (or set LEAD_ENGINE_DEV_AUTH_BYPASS=1 and ENVIRONMENT=development).";
      }
      setError(hint);
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <form
        onSubmit={submit}
        className="w-full max-w-md space-y-4 rounded-2xl border border-line bg-surface/80 p-8 shadow-xl"
      >
        <div>
          <div className="text-xs uppercase tracking-widest text-brand-500/80">Operator</div>
          <h1 className="mt-1 text-xl font-semibold text-ink">Admin access</h1>
          <p className="mt-2 text-sm text-ink-faint">
            Enter your <code className="text-ink-muted">LEAD_ENGINE_SERVICE_KEY</code> from{" "}
            <code className="text-ink-muted">lead-engine-v2/.env</code>
          </p>
        </div>
        <input
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="Service key"
          className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm text-ink"
          autoFocus
        />
        {error && <p className="text-sm text-rust-500 whitespace-pre-wrap">{error}</p>}
        <button
          type="submit"
          disabled={busy || key.length < 8}
          className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-medium text-white hover:bg-brand-500 disabled:opacity-50"
        >
          {busy ? "Checking…" : "Enter admin"}
        </button>
        <p className="text-xs text-ink-faint">
          Dev tip: set <code>ENVIRONMENT=development</code> and{" "}
          <code>LEAD_ENGINE_DEV_AUTH_BYPASS=1</code> so any 16+ char key works while testing.
        </p>
      </form>
    </div>
  );
}
