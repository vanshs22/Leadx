"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { setAdminKey, clearAdminKey, admin } from "@/lib/admin";
import { getSupabase } from "@/lib/supabaseClient";

export default function AdminLoginPage() {
  const [mode,setMode]=useState<"secure"|"service">("secure");
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [key,setKey]=useState("");
  const [error,setError]=useState(""); const [busy,setBusy]=useState(false); const router=useRouter();

  async function secureLogin(e:React.FormEvent){
    e.preventDefault(); setBusy(true); setError(""); clearAdminKey();
    try{
      const {data,error}=await getSupabase().auth.signInWithPassword({email:email.trim(),password});
      if(error||!data.session) throw new Error(error?.message||"Could not create admin session");
      setAdminKey(data.session.access_token);
      await admin.adminPing();
      router.push("/admin");
    }catch(err:any){await getSupabase().auth.signOut().catch(()=>{});clearAdminKey();setError(err?.message||"Admin login failed");setBusy(false);}
  }

  async function serviceLogin(e:React.FormEvent){
    e.preventDefault(); setBusy(true); setError(""); const k=key.trim(); setAdminKey(k);
    try{await admin.adminPing();router.push("/admin");}
    catch(err:any){clearAdminKey();setError(err?.message||"Service-key login failed");setBusy(false);}
  }

  return <div className="flex min-h-screen items-center justify-center p-6"><div className="w-full max-w-md rounded-2xl border border-line bg-surface/90 p-8 shadow-xl">
    <div className="text-xs uppercase tracking-widest text-signal-600">LeadX Control Plane</div><h1 className="mt-1 text-xl font-semibold text-ink">Admin access</h1><p className="mt-2 text-sm text-ink-faint">Use a Supabase-authenticated platform-admin session. The service-key path remains available for internal/local operations.</p>
    <div className="mt-5 flex rounded-xl border border-line bg-surface-2 p-1 text-xs font-semibold"><button type="button" onClick={()=>setMode("secure")} className={`flex-1 rounded-lg px-3 py-2 ${mode==="secure"?'bg-surface text-ink shadow-sm':'text-ink-muted'}`}>Secure session</button><button type="button" onClick={()=>setMode("service")} className={`flex-1 rounded-lg px-3 py-2 ${mode==="service"?'bg-surface text-ink shadow-sm':'text-ink-muted'}`}>Service key</button></div>
    {mode==="secure"?<form onSubmit={secureLogin} className="mt-5 space-y-3"><input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="Admin email" className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm" autoFocus/><input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password" className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm"/><button disabled={busy||!email||!password} className="w-full rounded-lg bg-signal-600 py-2.5 text-sm font-medium text-white disabled:opacity-50">{busy?'Signing in…':'Sign in securely'}</button><p className="text-xs text-ink-faint">Your user must exist in <code>platform_admins</code> with <code>active=true</code>.</p></form>:<form onSubmit={serviceLogin} className="mt-5 space-y-3"><input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="Internal service key" className="w-full rounded-lg border border-line bg-surface-2 px-3 py-2.5 text-sm" autoFocus/><button disabled={busy||key.length<8} className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-medium text-white disabled:opacity-50">{busy?'Checking…':'Enter with service key'}</button><p className="text-xs text-ink-faint">Prefer the secure session in production. Never expose service credentials to untrusted users.</p></form>}
    {error&&<div className="mt-4 rounded-xl border border-rust-300 bg-rust-50 p-3 text-sm text-rust-700 dark:bg-rust-500/10 dark:text-rust-300">{error}</div>}
  </div></div>;
}
