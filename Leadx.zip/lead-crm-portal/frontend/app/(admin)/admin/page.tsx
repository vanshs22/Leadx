"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { admin } from "@/lib/admin";
import { Sparkline } from "@/components/charts/Sparkline";
import { chartColors } from "@/lib/chartColors";

export default function AdminOverviewPage() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [ops, setOps] = useState<any>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      admin.tenants().then((d: any) => setTenants(d.tenants || d || [])),
      admin.globalStats().then(setStats),
      admin.ops(14).then(setOps),
    ])
      .catch((e) => setErr(e.message))
      .finally(() => setLoading(false));
  }, []);

  const actions = [
    { href: "/admin/pipeline", title: "Run pipeline", desc: "Discover → enrich → deliver for a client ICP" },
    { href: "/admin/intelligence", title: "Intelligence", desc: "Sample packs, QA accuracy, territories, bad leads" },
    { href: "/admin/tenants", title: "Clients", desc: "Quotas, branding, delivery channels" },
    { href: "/admin/icps", title: "ICPs", desc: "Vertical + geo + offer category targets" },
    { href: "/admin/keys", title: "API keys", desc: "Serper / crawl pools & cooldowns" },
    { href: "/admin/ops", title: "Ops health", desc: "Enrichment success, suppression, failures" },
  ];

  const byDay = (ops?.by_day || []).slice().reverse(); // oldest → newest for the sparkline
  const enrichTrend = byDay.map((d: any) => ({ value: d.leads_enriched_ok || 0 }));
  const runsTrend = byDay.map((d: any) => ({ value: d.pipeline_runs || 0 }));
  const totals = ops?.totals || {};
  const enrichOk = totals.leads_enriched_ok || 0;
  const enrichFail = totals.leads_enriched_fail || 0;
  const enrichRate = enrichOk + enrichFail ? Math.round((100 * enrichOk) / (enrichOk + enrichFail)) : null;

  const kpis = [
    { label: "Active clients", value: stats?.tenants_active ?? "—", hint: `${stats?.tenants_total ?? 0} total` },
    { label: "Leads in pool", value: stats?.leads_global ?? "—", hint: "Global inventory" },
    { label: "Delivered", value: stats?.assignments ?? "—", hint: "Total assignments" },
    { label: "Enrichment success", value: enrichRate != null ? `${enrichRate}%` : "—", hint: `last ${ops?.days ?? 14}d`, spark: enrichTrend, color: chartColors.signal[500] },
  ];

  return (
    <div className="page">
      <header>
        <h1 className="page-title">Operator console</h1>
        <p className="page-sub">Run the service, protect quality, keep clients supplied</p>
      </header>

      {err && <p className="text-sm text-rust-500 dark:text-rust-300">{err}</p>}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className="kpi">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="label">{k.label}</div>
                <div className="kpi-value mt-2">{loading ? "…" : k.value}</div>
              </div>
              {k.spark && k.spark.length > 1 && <Sparkline data={k.spark} color={k.color} />}
            </div>
            <div className="mt-1 text-xs text-ink-faint">{k.hint}</div>
          </div>
        ))}
      </div>

      {byDay.length > 1 && (
        <div className="card-pad">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Pipeline runs — last {ops?.days ?? 14} days</h2>
            <Link href="/admin/runs" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-300">
              Run history
            </Link>
          </div>
          <div className="mt-4 h-16 w-full">
            <Sparkline data={runsTrend} color={chartColors.brand[500]} />
          </div>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {actions.map((a) => (
          <Link key={a.href} href={a.href} className="card-pad transition hover:shadow-lift hover:border-brand-300 dark:hover:border-brand-500/40">
            <div className="text-base font-semibold text-ink">{a.title}</div>
            <p className="mt-2 text-sm text-ink-muted">{a.desc}</p>
          </Link>
        ))}
      </div>

      <div className="card-pad">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-ink">Clients</h2>
          <Link href="/admin/tenants" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-300">Manage all</Link>
        </div>
        <ul className="mt-3 divide-y divide-line">
          {tenants.slice(0, 12).map((t) => (
            <li key={t.id} className="flex items-center justify-between py-2.5 text-sm">
              <Link href={`/admin/tenants/${t.id}`} className="font-medium text-ink hover:text-brand-600 dark:hover:text-brand-300">{t.name || t.id}</Link>
              <span className="pill bg-surface-3 text-ink-muted">{t.status || "active"}</span>
            </li>
          ))}
          {!loading && !tenants.length && <li className="py-2 text-sm text-ink-faint">No tenants yet — create one under Clients</li>}
        </ul>
      </div>
    </div>
  );
}
