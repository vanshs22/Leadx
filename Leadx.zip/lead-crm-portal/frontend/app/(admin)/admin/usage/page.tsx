"use client";

import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";

export default function AdminUsagePage() {
  const [data, setData] = useState<any>(null);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    admin.usage().then(setData).catch((e) => setMsg(e.message));
  }, []);

  async function reportAll() {
    const r = await admin.billingReportAll();
    setMsg(JSON.stringify(r));
  }

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-ink">Usage & billing</h1>
          <p className="text-sm text-ink-muted">
            Period: {data?.period || "…"} · net delivered leads
          </p>
        </div>
        <button
          onClick={reportAll}
          className="rounded-lg bg-brand-600 px-4 py-2 text-sm text-ink"
        >
          Report all to Stripe
        </button>
      </header>

      {msg && <p className="text-sm text-amber-300 break-all">{msg}</p>}

      <div className="overflow-hidden rounded-xl border border-line">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line bg-surface-2 text-xs uppercase text-ink-faint">
            <tr>
              <th className="px-4 py-3">Tenant</th>
              <th className="px-4 py-3">Delivered</th>
              <th className="px-4 py-3">Credited</th>
              <th className="px-4 py-3">Stripe qty</th>
              <th className="px-4 py-3">Reported at</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {(data?.usage || []).map((u: any) => (
              <tr key={u.tenant_id}>
                <td className="px-4 py-3 font-mono text-xs text-ink-muted">
                  {u.tenant_id?.slice(0, 8)}…
                </td>
                <td className="px-4 py-3 tabular-nums text-ink">{u.leads_delivered || 0}</td>
                <td className="px-4 py-3 tabular-nums text-ink-muted">{u.leads_credited || 0}</td>
                <td className="px-4 py-3 tabular-nums text-ink-muted">
                  {u.stripe_reported_qty ?? "—"}
                </td>
                <td className="px-4 py-3 text-xs text-ink-faint">
                  {u.stripe_reported_at
                    ? new Date(u.stripe_reported_at).toLocaleString()
                    : "—"}
                </td>
              </tr>
            ))}
            {(!data?.usage || data.usage.length === 0) && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-ink-faint">
                  No usage this period
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
