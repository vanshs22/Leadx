"use client";
import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";
const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
export default function AdminSearchPage() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [tenantId, setTenantId] = useState("");
  const [vertical, setVertical] = useState("medspa");
  const [geo, setGeo] = useState("Hoboken");
  const [keywords, setKeywords] = useState("med spa");
  const [offer, setOffer] = useState("lead_gen_service");
  const [limit, setLimit] = useState(15);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [leads, setLeads] = useState<any[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [emailOpen, setEmailOpen] = useState(false);
  const [subj, setSubj] = useState("Proposal for {{company}}");
  const [body, setBody] = useState("<p>Hi {{owner}}, idea for {{company}} in {{city}}.</p><p>{{pitch}}</p>");
  useEffect(() => { admin.tenants("active").then(d => setTenants(d.tenants||[])).catch(e=>setMsg(e.message)); }, []);
  async function findLeads() {
    if (!tenantId) return setMsg("Select client");
    setLoading(true);
    try {
      const res = await fetch(`${BASE}/crm/${tenantId}/search-run`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vertical, geo: geo.split(",").map(s=>s.trim()).filter(Boolean), keywords: keywords.split(",").map(s=>s.trim()).filter(Boolean), offer_category: offer, limit_per_location: limit }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(typeof data.detail==="string"?data.detail:JSON.stringify(data));
      setLeads(data.leads||[]); setMsg(`Found ${data.count||0} (${data.with_email||0} with email)`); setSelected(new Set());
    } catch(e:any) { setMsg(e.message); } finally { setLoading(false); }
  }
  async function sendSelected() {
    setLoading(true);
    try {
      const res = await fetch(`${BASE}/crm/${tenantId}/email/bulk`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ subject:subj, body_html:body, assignment_ids:Array.from(selected)})});
      const data = await res.json();
      if (!res.ok) throw new Error(JSON.stringify(data));
      setMsg(`Sent ${data.sent||0}, failed ${data.failed||0}`); setEmailOpen(false);
    } catch(e:any) { setMsg(e.message); } finally { setLoading(false); }
  }
  return (
    <div className="page">
      <h1 className="page-title">Search & outreach</h1>
      <p className="page-sub">Pick client → ICP → Find → email proposal</p>
      {msg && <div className="rounded-xl border border-line bg-surface-2 px-4 py-2 text-sm">{msg}</div>}
      <div className="card-pad space-y-3">
        <select className="input" value={tenantId} onChange={e=>setTenantId(e.target.value)}>
          <option value="">Client…</option>
          {tenants.map(t=><option key={t.id} value={t.id}>{t.name||t.id}</option>)}
        </select>
        <div className="grid gap-2 sm:grid-cols-2">
          <input className="input" value={vertical} onChange={e=>setVertical(e.target.value)} placeholder="vertical" />
          <input className="input" value={geo} onChange={e=>setGeo(e.target.value)} placeholder="geo" />
          <input className="input sm:col-span-2" value={keywords} onChange={e=>setKeywords(e.target.value)} placeholder="keywords" />
          <input className="input" value={offer} onChange={e=>setOffer(e.target.value)} placeholder="offer_category" />
          <input className="input" type="number" value={limit} onChange={e=>setLimit(Number(e.target.value))} />
        </div>
        <button className="btn-primary" disabled={loading} onClick={findLeads}>{loading?"Working…":"Find leads"}</button>
      </div>
      {leads.length>0 && (
        <div className="card-pad flex gap-2 flex-wrap">
          <button className="btn-secondary" onClick={()=>setSelected(new Set(leads.filter(l=>l.email).map(l=>l.assignment_id)))}>Select with email</button>
          <button className="btn-primary" disabled={!selected.size} onClick={()=>setEmailOpen(true)}>Email proposal ({selected.size})</button>
        </div>
      )}
      <div className="space-y-2">
        {leads.map(l=>(
          <label key={l.assignment_id} className="card-pad flex gap-3 text-sm">
            <input type="checkbox" checked={selected.has(l.assignment_id)} onChange={()=>{const n=new Set(selected); n.has(l.assignment_id)?n.delete(l.assignment_id):n.add(l.assignment_id); setSelected(n);}} />
            <div><div className="font-semibold">{l.name} · {l.tier}</div><div className="text-ink-muted">{l.email||"no email"} · {l.city}</div></div>
          </label>
        ))}
      </div>
      {emailOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="card-pad w-full max-w-lg space-y-3">
            <input className="input" value={subj} onChange={e=>setSubj(e.target.value)} />
            <textarea className="input min-h-[120px] font-mono text-xs" value={body} onChange={e=>setBody(e.target.value)} />
            <button className="btn-primary" onClick={sendSelected}>Send</button>
            <button className="btn-ghost" onClick={()=>setEmailOpen(false)}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
