"use client";

import { useEffect, useState, useRef, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { admin } from "@/lib/admin";

function PipelineForm() {
  const params = useSearchParams();
  const [tenants, setTenants] = useState<any[]>([]);
  const [icps, setIcps] = useState<any[]>([]);
  const [form, setForm] = useState({
    tenant_id: params.get("tenant") || "",
    icp_id: "",
    industry: "medspa",
    locations: "Hoboken NJ, Jersey City NJ",
    limit_per_location: 30,
    total_leads: 50,
    deliver: true,
    allow_tier_b: true,
    skip_enrichment: false,
  });
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [progress, setProgress] = useState<any>(null);
  const pollRef = useRef<any>(null);

  useEffect(() => {
    admin.tenants("active").then((d) => setTenants(d.tenants || []));
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  useEffect(() => {
    if (!form.tenant_id) return;
    admin.icps(form.tenant_id).then((d) => setIcps(d.icps || []));
  }, [form.tenant_id]);

  function startPolling(tenantId: string, hintRunId?: string) {
    if (pollRef.current) clearInterval(pollRef.current);
    const tick = async () => {
      try {
        const d = await admin.runs(tenantId);
        const runs = d.runs || [];
        let run =
          (hintRunId && runs.find((r: any) => r.id === hintRunId)) ||
          runs.find((r: any) => r.status === "running" || r.status === "queued") ||
          runs[0];
        if (!run) return;
        setProgress(run);
        if (run.status === "completed" || run.status === "failed" || run.status === "done") {
          clearInterval(pollRef.current);
          pollRef.current = null;
          setBusy(false);
          setResult(run);
        }
      } catch {
        /* ignore poll errors */
      }
    };
    tick();
    pollRef.current = setInterval(tick, 2500);
  }

  async function run() {
    setBusy(true);
    setError("");
    setResult(null);
    setProgress({ status: "queued", meta: { stage: "starting" }, discovered: 0 });
    try {
      const locations = form.locations
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
      const r = await admin.runPipeline({
        tenant_id: form.tenant_id,
        icp_id: form.icp_id || undefined,
        industry: form.industry,
        locations,
        limit_per_location: Number(form.limit_per_location),
        target_new_leads: Number(form.total_leads) || 0,
        deliver: form.deliver,
        allow_tier_b: form.allow_tier_b,
        skip_enrichment: form.skip_enrichment,
      });
      setResult(r);
      // Background start — poll for live progress (no more Internal Server Error timeout)
      if (r?.status === "started" || r?.run_id || r?.status === "running") {
        startPolling(form.tenant_id, r.run_id);
      } else {
        // sync response with final summary
        setBusy(false);
        setProgress(r);
      }
    } catch (e: any) {
      // Even on network timeout, pipeline may still be running server-side
      setError(e.message || "Request failed — checking Run history for progress…");
      startPolling(form.tenant_id);
    }
  }

  async function runAll() {
    setBusy(true);
    setError("");
    try {
      const r = await admin.runAllIcps({
        limit_per_location: Number(form.limit_per_location),
      });
      setResult(r);
      startPolling(form.tenant_id);
    } catch (e: any) {
      setError(e.message);
      setBusy(false);
    }
  }

  const stage = progress?.meta?.stage || progress?.status || "";
  const stageLabel: Record<string, string> = {
    queued: "Queued…",
    starting: "Starting…",
    discovered: "Discovery done — storing leads",
    enriching: "Enriching websites…",
    enriched: "Enrichment done",
    gating: "Scoring & quality gate…",
    assigning: "Assigning to client…",
    running: "Running…",
    completed: "Completed",
    failed: "Failed",
    done: "Done",
  };

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Run pipeline</h1>
        <p className="mt-1 text-sm text-slate-400">
          Discover → enrich → gate → deliver for one client
        </p>
      </header>

      <div className="max-w-xl space-y-3 rounded-xl border border-slate-800 bg-slate-900/60 p-5">
        <label className="block text-xs text-slate-500">
          Client
          <select
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            value={form.tenant_id}
            onChange={(e) => setForm({ ...form, tenant_id: e.target.value })}
          >
            <option value="">Select client…</option>
            {tenants.map((t) => (
              <option key={t.id} value={t.id}>
                {t.brand_name || t.name}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-xs text-slate-500">
          ICP (optional)
          <select
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            value={form.icp_id}
            onChange={(e) => setForm({ ...form, icp_id: e.target.value })}
          >
            <option value="">Manual industry / locations</option>
            {icps.map((i) => (
              <option key={i.id} value={i.id}>
                {i.label || i.vertical || i.id}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-xs text-slate-500">
          Industry
          <input
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            value={form.industry}
            onChange={(e) => setForm({ ...form, industry: e.target.value })}
          />
        </label>

        <label className="block text-xs text-slate-500">
          Locations (comma-separated)
          <input
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            value={form.locations}
            onChange={(e) => setForm({ ...form, locations: e.target.value })}
          />
        </label>

        <label className="block text-xs text-slate-500">
          Limit per location
          <input
            type="number"
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            value={form.limit_per_location}
            onChange={(e) =>
              setForm({ ...form, limit_per_location: Number(e.target.value) })
            }
          />
        </label>

        <label className="block text-xs text-slate-500">
          Total leads (target)
          <input
            type="number"
            min={0}
            className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-white"
            value={form.total_leads}
            onChange={(e) =>
              setForm({ ...form, total_leads: Number(e.target.value) })
            }
          />
          <span className="mt-1 block text-[11px] text-slate-600">
            Target unique leads in the locations you entered only. 0 = only limit
            per location.
          </span>
        </label>

        <div className="flex flex-wrap gap-4 text-sm text-slate-400">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.deliver}
              onChange={(e) => setForm({ ...form, deliver: e.target.checked })}
            />
            Deliver
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.allow_tier_b}
              onChange={(e) =>
                setForm({ ...form, allow_tier_b: e.target.checked })
              }
            />
            Allow Tier B
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.skip_enrichment}
              onChange={(e) =>
                setForm({ ...form, skip_enrichment: e.target.checked })
              }
            />
            Skip enrichment
          </label>
        </div>

        <div className="flex gap-3 pt-2">
          <button
            type="button"
            disabled={busy || !form.tenant_id}
            onClick={run}
            className="rounded-lg bg-amber-500 px-4 py-2 text-sm font-medium text-black disabled:opacity-40"
          >
            {busy ? "Running…" : "Run for client"}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={runAll}
            className="rounded-lg border border-slate-600 px-4 py-2 text-sm text-slate-300"
          >
            Run all active ICPs
          </button>
        </div>

        {error && (
          <p className="text-sm text-amber-400">
            {error}{" "}
            <span className="text-slate-500">
              (pipeline may still be running — see progress below)
            </span>
          </p>
        )}
      </div>

      {/* Live progress */}
      {(busy || progress) && (
        <div className="max-w-xl rounded-xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="text-xs uppercase tracking-wide text-slate-500">
            Live progress
          </div>
          <div className="mt-1 text-lg font-medium text-white">
            {stageLabel[stage] || stage || "…"}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-5">
            {[
              ["Found", progress?.discovered ?? 0],
              ["Enriched", progress?.enriched ?? 0],
              ["Gated", progress?.gated_ok ?? 0],
              ["Assigned", progress?.assigned ?? 0],
              ["Delivered", progress?.delivered ?? 0],
            ].map(([label, val]) => (
              <div
                key={String(label)}
                className="rounded-lg bg-slate-950/80 px-3 py-2 text-center"
              >
                <div className="text-lg font-semibold tabular-nums text-amber-400">
                  {val as number}
                </div>
                <div className="text-[11px] text-slate-500">{label as string}</div>
              </div>
            ))}
          </div>
          {progress?.status && (
            <div className="mt-3 text-xs text-slate-500">
              Status:{" "}
              <span className="text-slate-300">{progress.status}</span>
              {progress.error_message && (
                <span className="text-red-400"> — {progress.error_message}</span>
              )}
            </div>
          )}
        </div>
      )}

      {result && !busy && (
        <pre className="max-w-2xl overflow-auto rounded-xl border border-slate-800 bg-slate-950 p-4 text-xs text-slate-400">
          {JSON.stringify(result, null, 2)}
        </pre>
      )}
    </div>
  );
}

export default function PipelinePage() {
  return (
    <Suspense fallback={<div className="p-8 text-slate-500">Loading…</div>}>
      <PipelineForm />
    </Suspense>
  );
}
