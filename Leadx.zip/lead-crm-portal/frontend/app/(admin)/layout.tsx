"use client";

import { useEffect, useState } from "react";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { usePathname, useRouter } from "next/navigation";
import { hasAdminKey } from "@/lib/admin";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const isLogin = path === "/admin/login";
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (isLogin) return;
    if (!hasAdminKey()) {
      router.replace("/admin/login");
      return;
    }
    setChecked(true);
  }, [isLogin, path, router]);

  if (isLogin) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  if (!checked) {
    return <div className="min-h-screen bg-surface" />;
  }

  return (
    <div className="flex min-h-screen bg-surface text-ink">
      <AdminSidebar />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
