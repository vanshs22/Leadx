"use client";

import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { usePathname } from "next/navigation";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const isLogin = path === "/admin/login";

  if (isLogin) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  return (
    <div className="flex min-h-screen bg-surface text-ink">
      <AdminSidebar />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
