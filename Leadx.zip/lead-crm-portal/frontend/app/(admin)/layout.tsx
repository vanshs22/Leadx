"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { hasAdminKey } from "@/lib/admin";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [ok, setOk] = useState(path === "/admin/login");

  useEffect(() => {
    if (path === "/admin/login") {
      setOk(true);
      return;
    }
    if (!hasAdminKey()) {
      router.replace("/admin/login");
      return;
    }
    setOk(true);
  }, [path, router]);

  if (path === "/admin/login") {
    return <>{children}</>;
  }

  if (!ok) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-surface text-sm text-ink-muted">
        Checking operator session…
      </div>
    );
  }

  return (
    <div className="shell">
      <AdminSidebar />
      <div className="shell-main">
        <header className="topbar">
          <div className="text-sm font-medium text-ink">Operator</div>
          <div className="topbar-search ml-4">
            <span>⌕</span>
            <span>Jump to runs, clients, keys…</span>
          </div>
          <div className="ml-auto">
            <span className="rounded-full border border-line bg-surface-3 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-ink-muted">
              Admin
            </span>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
