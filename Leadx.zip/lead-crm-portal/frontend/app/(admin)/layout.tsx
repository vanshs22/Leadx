"use client";

import { useEffect, useState } from "react";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { usePathname, useRouter } from "next/navigation";
import { hasAdminKey } from "@/lib/admin";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const isLogin = path === "/admin/login";
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (isLogin) return;
    if (!hasAdminKey()) {
      router.replace("/admin/login");
      return;
    }
    setChecked(true);
  }, [isLogin, path, router]);

  if (isLogin) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  if (!checked) {
    return <div className="min-h-screen bg-surface" />;
  }

  return (
    <div className="flex min-h-screen bg-surface text-ink">
      <AdminSidebar />
      <main className="min-w-0 flex-1 overflow-auto bg-surface/70"><div className="sticky top-0 z-30 flex h-12 items-center justify-between border-b border-line/70 bg-surface-2/85 px-5 backdrop-blur-xl"><div className="hidden text-[10px] font-bold uppercase tracking-[0.14em] text-ink-faint md:block">LeadX Control Plane</div><div className="ml-auto flex items-center gap-2"><span className="rounded-full border border-signal-200 bg-signal-50 px-2.5 py-1 text-[10px] font-bold text-signal-700 dark:border-signal-500/20 dark:bg-signal-500/10 dark:text-signal-300">● Systems online</span><a href="/admin/support" className="btn-ghost px-2.5 py-1.5 text-xs">Support inbox</a></div></div>{children}</main>
    </div>
  );
}
