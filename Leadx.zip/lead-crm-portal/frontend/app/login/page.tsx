
"use client";
import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { signInWithPassword } from "@/lib/auth";
function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/dashboard";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  async function submit(e) {
    e.preventDefault();
    try {
      await signInWithPassword(email.trim(), password);
      router.replace(next);
    } catch (ex) {
      setErr(ex.message || "Sign-in failed");
    }
  }
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-2xl border border-line bg-surface-2 p-8">
        <h1 className="text-xl font-semibold">Client sign in</h1>
        <input className="input" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="Email" required />
        <input className="input" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="Password" required />
        {err && <p className="text-sm text-red-500">{err}</p>}
        <button className="btn-primary w-full" type="submit">Sign in</button>
      </form>
    </div>
  );
}
export default function Page() {
  return <Suspense><LoginForm /></Suspense>;
}
