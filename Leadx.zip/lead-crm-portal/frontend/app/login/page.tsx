"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { signInWithPassword } from "@/lib/auth";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/dashboard";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      await signInWithPassword(email.trim(), password);
      router.replace(next);
    } catch (ex: unknown) {
      setErr(ex instanceof Error ? ex.message : "Sign-in failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[rgb(var(--surface))] p-6">
      <form
        onSubmit={submit}
        className="w-full max-w-sm space-y-4 rounded-2xl border border-[rgb(var(--line))] bg-[rgb(var(--surface-2))] p-8 shadow-lg"
      >
        <div>
          <h1 className="text-xl font-semibold text-[rgb(var(--ink))]">Client sign in</h1>
          <p className="mt-1 text-sm text-[rgb(var(--ink-muted))]">
            Use the email and password your admin set for your workspace.
          </p>
        </div>
        <label className="block space-y-1.5">
          <span className="text-xs font-medium text-[rgb(var(--ink-muted))]">Email</span>
          <input
            className="input w-full"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@company.com"
            required
          />
        </label>
        <label className="block space-y-1.5">
          <span className="text-xs font-medium text-[rgb(var(--ink-muted))]">Password</span>
          <input
            className="input w-full"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
          />
        </label>
        {err ? <p className="text-sm text-red-500">{err}</p> : null}
        <button className="btn-primary w-full" type="submit" disabled={loading}>
          {loading ? "Signing in…" : "Sign in"}
        </button>
        <p className="text-center text-xs text-[rgb(var(--ink-faint))]">
          Operator?{" "}
          <a href="/admin/login" className="text-[rgb(var(--brand))] underline-offset-2 hover:underline">
            Admin login
          </a>
        </p>
      </form>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center text-sm text-[rgb(var(--ink-muted))]">
          Loading…
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
