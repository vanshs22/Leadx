"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { crm, DashboardResponse } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { Sparkline } from "@/components/charts/Sparkline";
import { FunnelChart } from "@/components/charts/FunnelChart";
import { TierDonut } from "@/components/charts/TierDonut";
import { chartColors } from "@/lib/chartColors";


export default function DashboardPage() {
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    crm.dashboard(getTenantId()).then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) {
    return (
      <div className="page">
        <div className="card-pad border-red-200 text-red-700 dark:border-red-900/50 dark:text-red-300">
          Couldn’t load dashboard: {error}
        </div>
      </div>
    );
  }
  if (!data) {
    return <div className="page text-ink-faint">Loading your workspace…</div>;
  }

  const { kpis, funnel, usage, quota_limit, tasks_due, recent_activity, tenant, trend } = data as any;
  const used = usage?.leads_delivered ?? 0;
  const limit = quota_limit ?? 0;
  const quotaPct = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const sparkData = (trend || []).map((t: any) => ({ value: t.count }));

  const cards = [
    { label: "Leads ready", value: kpis?.total_leads ?? 0, hint: "Assigned to you", href: "/leads", spark: sparkData, color: chartColors.brand[500] },
    { label: "Best quality", value: kpis?.tier_a ?? 0, hint: "Tier A — call first", href: "/leads", color: chartColors.brand[500] },
    { label: "In pipeline", value: kpis?.in_pipeline ?? 0, hint: "Active work", href: "/pipeline", color: chartColors.signal[500] },
    { label: "Win rate", value: `${kpis?.win_rate_pct ?? 0}%`, hint: `${kpis?.won ?? 0} won`, href: "/reports", color: chartColors.signal[500] },
  ];

  return (
    <div className="page">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="page-title">{tenant?.name ? tenant.name : "Your workspace"}</h1>
          <p className="page-sub">Exclusive leads · scored · ready to call</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/leads" className="btn-primary">
            Work leads →
          </Link>
          <Link href="/reports" className="btn-secondary">
            Reports
          </Link>
        </div>
      </header>

      {/* Workflow guide */}
      <div className="card overflow-hidden border-brand-200 bg-gradient-to-br from-brand-50 to-surface-2 dark:border-brand-500/20 dark:from-brand-500/10 dark:to-surface-2">
        <div className="p-5 md:p-6">
          <div className="label text-brand-600 dark:text-brand-300">Start here — 4 steps</div>
          <ol className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              "Open Leads → filter Tier A",
              "Read the pitch line",
              "Call or email the contact",
              "Update stage · report bad leads",
            ].map((step, i) => (
              <li key={step} className="flex gap-3 text-sm text-ink">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-600 text-xs font-bold text-white">
                  {i + 1}
                </span>
                <span className="pt-0.5">{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Link key={c.label} href={c.href} className="kpi block">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="label">{c.label}</div>
                <div className="mt-2 text-3xl font-semibold tabular-nums tracking-tight text-ink">
                  {c.value}
                </div>
              </div>
              {c.spark && c.spark.length > 1 && <Sparkline data={c.spark} color={c.color} />}
            </div>
            <div className="mt-1 text-xs text-ink-faint">{c.hint}</div>
          </Link>
        ))}
      </div>

      {limit > 0 && (
        <div className="card-pad">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-ink">Monthly delivery quota</span>
            <span className="tabular-nums text-ink-muted">
              {used} / {limit}
            </span>
          </div>
          <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-surface-3">
            <div
              className="h-full rounded-full bg-brand-500 transition-all"
              style={{ width: `${quotaPct}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-ink-faint">
            {quotaPct >= 90 ? "Near limit — contact your operator for more capacity." : "Resets each calendar month."}
          </p>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card-pad lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Pipeline funnel</h2>
            <Link href="/pipeline" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-300">
              Open board
            </Link>
          </div>
          <div className="mt-4">
            {(funnel || []).length ? (
              <FunnelChart stages={funnel} />
            ) : (
              <p className="text-sm text-ink-faint">No stage data yet — work leads to fill the funnel</p>
            )}
          </div>
        </div>

        <div className="card-pad flex flex-col items-center justify-center gap-4">
          <h2 className="self-start text-sm font-semibold text-ink">Lead quality</h2>
          <TierDonut a={kpis?.tier_a ?? 0} b={kpis?.tier_b ?? 0} c={kpis?.tier_c ?? 0} />
          <div className="flex gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-ink-muted">
              <span className="h-2 w-2 rounded-full bg-brand-500" /> A {kpis?.tier_a ?? 0}
            </span>
            <span className="flex items-center gap-1.5 text-ink-muted">
              <span className="h-2 w-2 rounded-full bg-signal-500" /> B {kpis?.tier_b ?? 0}
            </span>
            <span className="flex items-center gap-1.5 text-ink-muted">
              <span className="h-2 w-2 rounded-full bg-rust-400" /> C {kpis?.tier_c ?? 0}
            </span>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card-pad">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink">Due tasks</h2>
            <Link href="/activities" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-300">
              Activity
            </Link>
          </div>
          <ul className="mt-4 space-y-2.5">
            {(tasks_due || []).slice(0, 6).map((t: any) => (
              <li key={t.id} className="flex justify-between gap-3 text-sm">
                <span className="text-ink">{t.title}</span>
                {t.due_at && (
                  <span className="shrink-0 text-xs text-ink-faint">{String(t.due_at).slice(0, 10)}</span>
                )}
              </li>
            ))}
            {!(tasks_due || []).length && (
              <li className="text-sm text-ink-faint">No tasks due — you’re clear</li>
            )}
          </ul>
        </div>
      </div>

      <div className="card-pad">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-ink">Recent activity</h2>
          <Link href="/activities" className="text-xs font-medium text-brand-600 hover:underline dark:text-brand-300">
            View all
          </Link>
        </div>
        <ul className="mt-4 divide-y divide-line">
          {(recent_activity || []).slice(0, 8).map((a: any, i: number) => (
            <li key={a.id || i} className="flex justify-between gap-3 py-2.5 text-sm">
              <span className="text-ink">{a.title || a.activity_type || "Update"}</span>
              <span className="shrink-0 text-xs text-ink-faint">
                {a.created_at ? String(a.created_at).slice(0, 16).replace("T", " ") : ""}
              </span>
            </li>
          ))}
          {!(recent_activity || []).length && (
            <li className="py-2 text-sm text-ink-faint">Activity appears as you work leads</li>
          )}
        </ul>
      </div>

      {/* Quick actions */}
      <div className="grid gap-3 sm:grid-cols-3">
        {[
          { href: "/leads", title: "Call list", desc: "Tier A contacts ready to dial" },
          { href: "/settings", title: "Export", desc: "CSV or Instantly sequences" },
          { href: "/reports", title: "Results", desc: "Wins, losses, quality feedback" },
        ].map((a) => (
          <Link key={a.href} href={a.href} className="card-pad transition hover:shadow-lift">
            <div className="font-semibold text-ink">{a.title}</div>
            <p className="mt-1 text-sm text-ink-muted">{a.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
