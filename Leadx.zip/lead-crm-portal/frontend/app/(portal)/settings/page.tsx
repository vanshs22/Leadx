"use client";

import { useEffect, useState } from "react";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function SettingsPage() {
  const [brand, setBrand] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    crm
      .getBranding(getTenantId())
      .then((b) =>
        setBrand({
          brand_name: b.brand_name || "",
          brand_primary_color: b.brand_primary_color || "",
          brand_logo_url: b.brand_logo_url || "",
          support_email: b.support_email || "",
        })
      )
      .catch((e) => setMsg(e.message));
  }, []);

  async function save() {
    setBusy(true);
    try {
      await crm.updateBranding(getTenantId(), brand);
      setMsg("Branding saved");
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function seedStages() {
    setBusy(true);
    try {
      // tenant-scoped CRM setup — no service key
      const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
      const res = await fetch(`${BASE}/crm/${getTenantId()}/stages/seed`, { method: "POST" });
      if (!res.ok) throw new Error(await res.text());
      setMsg("Pipeline stages seeded");
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="page max-w-xl">
      <header>
        <h1 className="page-title">Settings</h1>
        <p className="page-sub">Workspace branding & pipeline setup</p>
      </header>

      {msg && (
        <div className="rounded-xl border border-line bg-surface-2 px-4 py-2.5 text-sm text-ink-muted">{msg}</div>
      )}

      <section className="card-pad space-y-3">
        <h2 className="text-sm font-semibold text-ink">Branding</h2>
        {(["brand_name", "brand_primary_color", "brand_logo_url", "support_email"] as const).map((k) => (
          <label key={k} className="block text-xs text-ink-faint">
            {k.replace(/_/g, " ")}
            <input
              className="input mt-1"
              value={brand[k] || ""}
              onChange={(e) => setBrand({ ...brand, [k]: e.target.value })}
            />
          </label>
        ))}
        <button onClick={save} disabled={busy} className="btn-primary">
          Save branding
        </button>
      </section>

      <section className="card-pad space-y-3">
        <h2 className="text-sm font-semibold text-ink">Scoring preferences</h2>
        <p className="text-sm text-ink-muted">
          Tell us what matters more when ranking leads (applied on next pipeline run). Ask your operator for your ICP id, or set via admin.
        </p>
        <p className="text-xs text-ink-faint">Weights: email, booking, reviews, owner — values around 0.5–1.5</p>
      </section>

      <section className="card-pad space-y-3">
        <h2 className="text-sm font-semibold text-ink">Pipeline</h2>
        <p className="text-sm text-ink-muted">Seed default stages (New → Contacted → Qualified → Won / Lost).</p>
        <button onClick={seedStages} disabled={busy} className="btn-secondary">
          Seed stages
        </button>
      </section>
    </div>
  );
}
