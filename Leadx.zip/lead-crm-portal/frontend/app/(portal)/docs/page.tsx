"use client";

import { useEffect, useMemo, useState } from "react";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";

function applyVars(html: string, vars: Record<string, string>) {
  return (html || "").replace(/\\{\\{\\s*([a-zA-Z0-9_]+)\\s*\\}\\}/g, (_, k) =>
    vars[k] != null && vars[k] !== "" ? String(vars[k]) : `{{${k}}}`
  );
}

const FIELD_LABELS: Record<string, string> = {
  client_name: "Client name",
  provider_name: "Provider / your company",
  amount: "Amount",
  currency: "Currency",
  scope: "Scope of work",
  term: "Term",
  vertical: "Vertical / industry",
  geo: "Geography",
  lead_count: "Lead count",
  offer_category: "Offer category",
  invoice_number: "Invoice number",
  due_date: "Due date",
  line_items: "Line items",
  party_a: "Party A",
  party_b: "Party B",
};

const CATEGORY_META: Record<string, { label: string; color: string }> = {
  contract: { label: "Contract", color: "bg-indigo-500/15 text-indigo-600 dark:text-indigo-300" },
  nda: { label: "NDA", color: "bg-sky-500/15 text-sky-600 dark:text-sky-300" },
  invoice: { label: "Invoice", color: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300" },
  proposal: { label: "Proposal", color: "bg-violet-500/15 text-violet-600 dark:text-violet-300" },
  onboarding: { label: "Onboarding", color: "bg-amber-500/15 text-amber-700 dark:text-amber-300" },
};

export default function DocsPage() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [selected, setSelected] = useState("");
  const [channel, setChannel] = useState("email");
  const [toEmail, setToEmail] = useState("");
  const [toPhone, setToPhone] = useState("");
  const [filter, setFilter] = useState("all");
  const [vars, setVars] = useState<Record<string, string>>({
    client_name: "Acme Agency",
    provider_name: "LeadX",
    amount: "1,499",
    currency: "USD",
    scope: "Exclusive Tier A local business lead delivery for the agreed ICP and geography.",
    term: "12 months",
    vertical: "medspa",
    geo: "New Jersey",
    lead_count: "200",
    offer_category: "lead_gen_service",
    invoice_number: "INV-001",
    due_date: "Net 15",
    line_items: "Monthly exclusive lead package — Tier A priority delivery",
    party_a: "LeadX",
    party_b: "Acme Agency",
  });
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    crm
      .docsTemplates(getTenantId())
      .then((r) => {
        const list = r.templates || [];
        setTemplates(list);
        if (list.length) setSelected((prev) => prev || list[0].id);
      })
      .catch((e) => setMsg(e.message));
  }, []);

  const selectedTpl = templates.find((t) => t.id === selected);
  const filtered = useMemo(() => {
    if (filter === "all") return templates;
    return templates.filter((t) => (t.category || "") === filter);
  }, [templates, filter]);
  const previewHtml = useMemo(() => {
    if (!selectedTpl?.body_html) {
      return `<div style="padding:48px;text-align:center;font-family:system-ui;color:#94a3b8">Select a template to preview</div>`;
    }
    return applyVars(selectedTpl.body_html, vars);
  }, [selectedTpl, vars]);

  async function send() {
    if (!selected) return;
    setBusy(true);
    try {
      const r: any = await crm.docsSend(getTenantId(), {
        template_id: selected,
        variables: vars,
        channel,
        to_email: toEmail || undefined,
        to_phone: toPhone || undefined,
      });
      setMsg(r.ok ? `Sent via ${channel}` : r.error || "Failed");
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  const categories = ["all", ...Array.from(new Set(templates.map((t) => t.category).filter(Boolean)))];

  return (
    <div className="page max-w-7xl space-y-5">
      <header>
        <h1 className="page-title">Docs &amp; templates</h1>
        <p className="page-sub">Pick a design, edit fields, preview live — then email or WhatsApp</p>
      </header>
      {msg && <div className="rounded-xl border border-line bg-surface-2 px-4 py-2.5 text-sm text-ink-muted">{msg}</div>}
      <div className="flex flex-wrap gap-2">
        {categories.map((c) => (
          <button key={c} type="button" onClick={() => setFilter(c)}
            className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${filter === c ? "bg-indigo-600 text-white" : "bg-surface-2 text-ink-muted border border-line"}`}>
            {c === "all" ? "All designs" : CATEGORY_META[c]?.label || c}
          </button>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {filtered.map((t) => {
          const meta = CATEGORY_META[t.category] || { label: t.category, color: "bg-surface-2 text-ink-muted" };
          const active = t.id === selected;
          return (
            <button key={t.id} type="button" onClick={() => setSelected(t.id)}
              className={`text-left rounded-2xl border p-4 transition ${active ? "border-indigo-500 ring-2 ring-indigo-500/30 bg-indigo-500/5" : "border-line bg-surface hover:bg-surface-2"}`}>
              <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${meta.color}`}>{meta.label}</span>
              <div className="text-sm font-semibold text-ink mt-2">{t.name}</div>
              {t.description && <p className="mt-1 text-xs text-ink-faint line-clamp-2">{t.description}</p>}
            </button>
          );
        })}
      </div>
      <div className="grid gap-5 lg:grid-cols-5">
        <div className="lg:col-span-2 card-pad space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-ink-faint">Edit fields</div>
          <div className="grid gap-3 sm:grid-cols-2">
            {Object.keys(vars).map((k) => (
              <label key={k} className="block text-xs font-medium text-ink-muted">
                {FIELD_LABELS[k] || k}
                <input className="input mt-1" value={vars[k]} onChange={(e) => setVars({ ...vars, [k]: e.target.value })} />
              </label>
            ))}
          </div>
          <div className="flex flex-wrap gap-2 pt-3 border-t border-line">
            <select className="input max-w-[130px]" value={channel} onChange={(e) => setChannel(e.target.value)}>
              <option value="email">Email</option>
              <option value="whatsapp">WhatsApp</option>
            </select>
            <input className="input flex-1" placeholder="client@email.com" value={toEmail} onChange={(e) => setToEmail(e.target.value)} />
            <input className="input flex-1" placeholder="WhatsApp +1…" value={toPhone} onChange={(e) => setToPhone(e.target.value)} />
          </div>
          <button disabled={busy || !selected} onClick={send} className="btn-primary w-full">{busy ? "Sending…" : "Generate & send"}</button>
        </div>
        <div className="lg:col-span-3 space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-ink-faint">Live preview</div>
          <div className="rounded-2xl border border-line bg-slate-200/80 dark:bg-slate-900/60 p-4 shadow-inner">
            <div className="mx-auto max-w-[720px] overflow-hidden rounded-xl shadow-2xl ring-1 ring-black/10">
              <iframe title="Document preview" className="w-full border-0 bg-white" style={{ minHeight: 560, height: "min(72vh, 720px)" }} srcDoc={previewHtml} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
