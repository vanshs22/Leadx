"use client";

import { useEffect, useState } from "react";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function DocsPage() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [selected, setSelected] = useState("");
  const [channel, setChannel] = useState("email");
  const [toEmail, setToEmail] = useState("");
  const [toPhone, setToPhone] = useState("");
  const [vars, setVars] = useState<Record<string, string>>({
    client_name: "",
    provider_name: "",
    amount: "",
    currency: "USD",
    scope: "Lead delivery services",
    term: "12 months",
    vertical: "",
    geo: "",
    lead_count: "200",
    offer_category: "",
    invoice_number: "INV-001",
    due_date: "",
    line_items: "",
    party_a: "",
    party_b: "",
  });
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    crm.docsTemplates(getTenantId()).then((r) => setTemplates(r.templates || [])).catch((e) => setMsg(e.message));
  }, []);

  async function send() {
    if (!selected) return;
    setBusy(true);
    try {
      const r: any = await crm.docsSend(getTenantId(), {
        template_id: selected,
        variables: vars,
        channel,
        to_email: toEmail || undefined,
        to_phone: toPhone || undefined,
      });
      setMsg(r.ok ? `Sent via ${channel}` : r.error || "Failed");
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  const selectedTpl = templates.find((t) => t.id === selected);
  const previewHtml = (selectedTpl?.body_html || selectedTpl?.body || "")
    .replace(/\{\{(\w+)\}\}/g, (_: string, k: string) => vars[k] || `{{${k}}}`);


  return (
    <div className="page max-w-5xl">
      <header>
        <h1 className="page-title">Docs & onboarding</h1>
        <p className="page-sub">Contracts, NDA, invoices, proposals — email or WhatsApp in one click</p>
      </header>

      {selectedTpl && (
        <div className="mt-8 rounded-2xl border border-line bg-surface-2/50 p-5">
          <h2 className="mb-2 text-sm font-semibold text-ink">Live preview</h2>
          <p className="mb-3 text-xs text-ink-faint">Updates as you edit fields above. You can also tweak text in the box.</p>
          <textarea
            className="min-h-[220px] w-full rounded-lg border border-line bg-surface p-3 font-mono text-xs text-ink"
            value={previewHtml.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim() || "(empty template body)"}
            onChange={() => {}}
            readOnly
          />
          <div
            className="prose prose-sm mt-4 max-w-none rounded-lg border border-line bg-white p-4 text-black dark:bg-surface-3 dark:text-ink"
            dangerouslySetInnerHTML={{ __html: previewHtml || "<p className=\"text-ink-faint\">Select a template</p>" }}
          />
        </div>
      )}
      {msg && <div className="rounded-xl border border-line bg-surface-2 px-4 py-2.5 text-sm text-ink-muted">{msg}</div>}

      <div className="card-pad space-y-4">
        <label className="block text-sm font-medium text-ink">
          Template
          <select className="input mt-1" value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">Select…</option>
            {templates.map((t) => (
              <option key={t.id} value={t.id}>{t.category} — {t.name}</option>
            ))}
          </select>
        </label>
        {selectedTpl && (
          <p className="text-xs text-ink-faint">{selectedTpl.description}</p>
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          {Object.keys(vars).map((k) => (
            <label key={k} className="block text-xs text-ink-faint">
              {k}
              <input className="input mt-1" value={vars[k]} onChange={(e) => setVars({ ...vars, [k]: e.target.value })} />
            </label>
          ))}
        </div>

        <div className="flex flex-wrap gap-2">
          <select className="input max-w-[140px]" value={channel} onChange={(e) => setChannel(e.target.value)}>
            <option value="email">Email</option>
            <option value="whatsapp">WhatsApp</option>
          </select>
          <input className="input flex-1" placeholder="client@email.com" value={toEmail} onChange={(e) => setToEmail(e.target.value)} />
          <input className="input flex-1" placeholder="WhatsApp +1…" value={toPhone} onChange={(e) => setToPhone(e.target.value)} />
        </div>

        <button disabled={busy || !selected} onClick={send} className="btn-primary">
          Generate & send
        </button>
      </div>
    </div>
  );
}
