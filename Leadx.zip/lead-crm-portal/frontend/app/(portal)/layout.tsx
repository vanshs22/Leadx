import { Sidebar } from "@/components/layout/Sidebar";
import { SessionGate } from "@/components/workspace/SessionGate";

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell">
      <Sidebar />
      <div className="shell-main">
        <header className="topbar">
          <div className="topbar-search">
            <span className="text-ink-faint">⌕</span>
            <span>Search leads, companies, contacts…</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden rounded-full border border-line bg-surface-3 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-ink-muted sm:inline">
              Portal
            </span>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto">
          <SessionGate>{children}</SessionGate>
        </main>
      </div>
    </div>
  );
}
