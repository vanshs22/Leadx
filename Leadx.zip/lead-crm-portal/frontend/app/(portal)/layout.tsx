"use client";

import { Sidebar } from "@/components/layout/Sidebar";
import { WorkspacePicker } from "@/components/workspace/WorkspacePicker";

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  return (
    <WorkspacePicker>
      <div className="flex min-h-screen bg-surface text-ink">
        <Sidebar />
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </WorkspacePicker>
  );
}
