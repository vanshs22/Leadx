"use client";

import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { SessionGate } from "@/components/workspace/SessionGate";
import { CommandPalette } from "@/components/CommandPalette";
import { RealtimeStatus } from "@/components/layout/RealtimeStatus";
import { SupportChat } from "@/components/support/SupportChat";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { useEffect } from "react";

const PUBLIC_PATHS = ["/login", "/accept-invite"];

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();

  // Warm the two most frequently visited CRM datasets after the shell is ready.
  // This is idle/low-priority work and uses the API client's short-lived cache,
  // so clicking Leads/Pipeline immediately after Home does not pay another DB round-trip.
  useEffect(() => {
    if (PUBLIC_PATHS.includes(path || "") || path !== "/dashboard") return;
    const tid = getTenantId();
    if (!tid) return;
    const warm = () => {
      void Promise.allSettled([
        crm.leads(tid, { limit: 50 }),
        crm.pipeline(tid),
      ]);
    };
    const idle = (window as any).requestIdleCallback;
    const id = idle ? idle(warm, { timeout: 900 }) : window.setTimeout(warm, 350);
    return () => {
      if (idle && typeof id === "number") (window as any).cancelIdleCallback?.(id);
      else window.clearTimeout(id);
    };
  }, [path]);

  if (PUBLIC_PATHS.includes(path || "")) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  return (
    <SessionGate>
      <CommandPalette />
      <SupportChat />
      <div className="flex h-[100dvh] max-h-[100dvh] overflow-hidden bg-surface text-ink">
        <Sidebar />
        <div className="pointer-events-none fixed right-4 top-3 z-30 hidden md:block"><RealtimeStatus /></div>
        <main className="flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto pt-12 md:pt-0">
          <div className="topbar sticky top-0 z-30 hidden h-12 items-center justify-between px-5 md:flex">
            <div className="flex items-center gap-2"><span className="brand-mark h-7 w-7 rounded-lg text-[9px]">LX</span><span className="brand-wordmark">LeadX</span><span className="ml-1 h-1.5 w-1.5 rounded-full bg-signal-500" /><span className="eyebrow">Workspace online</span></div>
            <div className="flex items-center gap-2">
              <a href="/search" className="btn-ghost px-2.5 py-1.5 text-xs">⌘K Find opportunities</a>
              <a href="/compose" className="btn-secondary px-2.5 py-1.5 text-xs">Compose</a>
            </div>
          </div>
          {children}
        </main>
      </div>
    </SessionGate>
  );
}
