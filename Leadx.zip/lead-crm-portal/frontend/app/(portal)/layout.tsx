"use client";

import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { SessionGate } from "@/components/workspace/SessionGate";

const PUBLIC_PATHS = ["/login", "/accept-invite"];

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  if (PUBLIC_PATHS.includes(path || "")) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  return (
    <SessionGate>
      <div className="flex min-h-screen bg-surface text-ink">
        <Sidebar />
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </SessionGate>
  );
}
