"use client";

import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { SessionGate } from "@/components/workspace/SessionGate";
import { CommandPalette } from "@/components/CommandPalette";
import { RealtimeStatus } from "@/components/layout/RealtimeStatus";
import { SupportChat } from "@/components/support/SupportChat";

const PUBLIC_PATHS = ["/login", "/accept-invite"];

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  if (PUBLIC_PATHS.includes(path || "")) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  return (
    <SessionGate>
      <CommandPalette />
      <SupportChat />
      <div className="flex h-[100dvh] max-h-[100dvh] overflow-hidden bg-surface text-ink">
        <Sidebar />
        <div className="pointer-events-none fixed right-4 top-3 z-30 hidden md:block"><RealtimeStatus /></div>
        <main className="flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto pt-12 md:pt-0">
          <div className="sticky top-0 z-30 hidden h-12 items-center justify-between border-b border-line/70 bg-surface-2/80 px-5 backdrop-blur-xl md:flex">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.14em] text-ink-faint"><span className="h-1.5 w-1.5 rounded-full bg-signal-500" />Workspace online</div>
            <div className="flex items-center gap-2">
              <a href="/search" className="btn-ghost px-2.5 py-1.5 text-xs">⌘K Find opportunities</a>
              <a href="/compose" className="btn-secondary px-2.5 py-1.5 text-xs">Compose</a>
            </div>
          </div>
          {children}
        </main>
      </div>
    </SessionGate>
  );
}
