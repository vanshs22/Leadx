"use client";

import { useEffect, useState } from "react";
import { crm } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";

type Step = { subject: string; body_html: string; delay_days: number };

export default function SequencesPage() {
  const [sequences, setSequences] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [steps, setSteps] = useState<Step[]>([{ subject: "", body_html: "", delay_days: 0 }]);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  function load() {
    crm.sequences(getTenantId()).then((d: any) => setSequences(d.sequences || [])).catch((e) => setMsg(e.message));
  }
  useEffect(load, []);

  function updateStep(i: number, patch: Partial<Step>) {
    setSteps((s) => s.map((st, idx) => (idx === i ? { ...st, ...patch } : st)));
  }

  async function save() {
    if (!name.trim() || steps.some((s) => !s.subject.trim() || !s.body_html.trim())) {
      setMsg("Name and every step's subject/body are required");
      return;
    }
    setBusy(true);
    setMsg("");
    try {
      await crm.createSequence(getTenantId(), { name: name.trim(), steps });
      setName("");
      setSteps([{ subject: "", body_html: "", delay_days: 0 }]);
      setMsg("Sequence created");
      load();
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="page">
      <header>
        <h1 className="page-title">Follow-up sequences</h1>
        <p className="page-sub">Build once, enroll leads from the Leads page — stops automatically on reply or unsubscribe</p>
      </header>

      <div className="card-pad space-y-4">
        <h2 className="text-sm font-semibold text-ink">New sequence</h2>
        <input className="input" placeholder="Sequence name (e.g. Initial outreach)" value={name} onChange={(e) => setName(e.target.value)} />

        {steps.map((s, i) => (
          <div key={i} className="space-y-2 rounded-xl2 border border-line p-3">
            <div className="flex items-center justify-between">
              <span className="label">Step {i + 1}</span>
              <div className="flex items-center gap-2 text-xs text-ink-muted">
                Send after
                <input
                  type="number"
                  min={0}
                  className="input w-16 py-1"
                  value={s.delay_days}
                  onChange={(e) => updateStep(i, { delay_days: parseInt(e.target.value) || 0 })}
                />
                day(s) {i === 0 ? "of enrollment" : "of previous step"}
                {steps.length > 1 && (
                  <button className="btn-ghost text-xs" onClick={() => setSteps((s2) => s2.filter((_, idx) => idx !== i))}>
                    Remove
                  </button>
                )}
              </div>
            </div>
            <input className="input" placeholder="Subject" value={s.subject} onChange={(e) => updateStep(i, { subject: e.target.value })} />
            <textarea
              className="input min-h-[100px] font-mono text-xs"
              placeholder="Body HTML — merge tags: {{name}} {{company}} {{owner}} {{city}} {{pitch}} {{tier}}"
              value={s.body_html}
              onChange={(e) => updateStep(i, { body_html: e.target.value })}
            />
          </div>
        ))}

        <div className="flex flex-wrap gap-2">
          <button className="btn-secondary" onClick={() => setSteps((s) => [...s, { subject: "", body_html: "", delay_days: 3 }])}>
            + Add step
          </button>
          <button className="btn-primary" disabled={busy} onClick={save}>
            {busy ? "Saving…" : "Create sequence"}
          </button>
        </div>
        {msg && <p className="text-sm text-ink-muted">{msg}</p>}
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line bg-surface-3/60 text-xs uppercase tracking-wide text-ink-faint">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Steps</th>
              <th className="px-4 py-3 font-medium">Active</th>
              <th className="px-4 py-3 font-medium">Completed</th>
              <th className="px-4 py-3 font-medium">Stopped (reply)</th>
              <th className="px-4 py-3 font-medium">Stopped (opt-out)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {sequences.map((s) => (
              <tr key={s.id}>
                <td className="px-4 py-3 font-medium text-ink">{s.name}</td>
                <td className="px-4 py-3 text-ink-muted">{s.steps?.length || 0}</td>
                <td className="px-4 py-3 font-mono tabular-nums text-ink">{s.enrollment_counts?.active || 0}</td>
                <td className="px-4 py-3 font-mono tabular-nums text-signal-600 dark:text-signal-300">{s.enrollment_counts?.completed || 0}</td>
                <td className="px-4 py-3 font-mono tabular-nums text-brand-600 dark:text-brand-300">{s.enrollment_counts?.stopped_reply || 0}</td>
                <td className="px-4 py-3 font-mono tabular-nums text-rust-500 dark:text-rust-300">{s.enrollment_counts?.stopped_optout || 0}</td>
              </tr>
            ))}
            {sequences.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-10 text-center text-ink-faint">No sequences yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
