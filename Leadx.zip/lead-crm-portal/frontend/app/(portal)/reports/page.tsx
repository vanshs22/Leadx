"use client";

import { useEffect, useState } from "react";
import { crm, ReportsSummary } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { FunnelChart } from "@/components/charts/FunnelChart";
import { TierDonut } from "@/components/charts/TierDonut";

export default function ReportsPage() {
  const [data, setData] = useState<ReportsSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    crm.reports(getTenantId()).then(setData).catch((e) => setError(e.message));
  }, []);

  async function exportCsv() {
    setExporting(true);
    try {
      const res = await crm.exportCsv(getTenantId());
      if (!res.rows?.length) {
        setError("No leads to export yet");
        return;
      }
      const headers = Object.keys(res.rows[0]);
      const csv = [
        headers.join(","),
        ...res.rows.map((row: any) => headers.map((h) => JSON.stringify(row[h] ?? "")).join(",")),
      ].join("\n");
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
      a.download = res.filename || "leads.csv";
      a.click();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setExporting(false);
    }
  }

  if (error) return <div className="p-8 text-rust-500 dark:text-rust-300">{error}</div>;
  if (!data) return <div className="p-8 text-ink-faint">Loading reports…</div>;

  const byTier = data.by_tier || {};
  const byStage = Object.entries(data.by_stage || {}).map(([stage, count]) => ({ stage, count: count as number }));

  return (
    <div className="page">
      <header className="flex items-start justify-between">
        <div>
          <h1 className="page-title">Reports</h1>
          <p className="page-sub">Quality mix and conversion snapshot</p>
        </div>
        <button onClick={exportCsv} disabled={exporting} className="btn-secondary disabled:opacity-50">
          {exporting ? "Exporting…" : "Export CSV"}
        </button>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Total leads", value: data.total },
          { label: "With email", value: `${data.with_email} (${data.with_email_pct}%)` },
          { label: "With booking", value: data.with_booking },
          { label: "Avg score", value: data.avg_score },
        ].map((c) => (
          <div key={c.label} className="kpi">
            <div className="label">{c.label}</div>
            <div className="kpi-value mt-2">{c.value}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card-pad flex flex-col items-center justify-center gap-4">
          <h2 className="self-start text-sm font-semibold text-ink">Quality mix</h2>
          <TierDonut a={byTier.A || 0} b={byTier.B || 0} c={byTier.C || 0} />
        </div>
        <div className="card-pad lg:col-span-2">
          <h2 className="text-sm font-semibold text-ink">By stage</h2>
          <div className="mt-4">
            {byStage.length ? (
              <FunnelChart stages={byStage} />
            ) : (
              <p className="text-sm text-ink-faint">No stage data yet</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
