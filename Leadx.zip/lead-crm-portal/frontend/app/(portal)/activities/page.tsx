"use client";

import { useEffect, useState } from "react";
import { crm, Activity, DashboardResponse, Task } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";


export default function ActivitiesPage() {
  const [data, setData] = useState<DashboardResponse | null>(null);

  useEffect(() => {
    crm.dashboard(getTenantId()).then(setData).catch(() => {});
  }, []);

  const tasks = data?.tasks_due || [];
  const activity = data?.recent_activity || [];

  return (
    <div className="space-y-6 p-8">
      <header>
        <h1 className="text-2xl font-semibold text-white">Tasks & Activity</h1>
        <p className="mt-1 text-sm text-ink-faint">Follow-ups and recent workspace activity</p>
      </header>

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-white">Open tasks</h2>
        <ul className="mt-3 space-y-2">
          {tasks.length === 0 && <li className="text-sm text-ink-faint">No open tasks</li>}
          {tasks.map((t: Task) => (
            <li
              key={t.id}
              className="flex items-center justify-between rounded-lg bg-surface/50 px-3 py-2 text-sm"
            >
              <span className="text-ink-muted">{t.title}</span>
              <span className="text-xs text-ink-faint">
                {t.due_at ? new Date(t.due_at).toLocaleDateString() : "—"} · {t.priority}
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-xl border border-line bg-surface-2/60 p-5">
        <h2 className="text-sm font-semibold text-white">Recent activity</h2>
        <ul className="mt-3 divide-y divide-line">
          {activity.length === 0 && <li className="py-2 text-sm text-ink-faint">No activity yet</li>}
          {activity.map((a: Activity) => (
            <li key={a.id} className="flex justify-between py-2 text-sm">
              <span>
                <span className="rounded bg-surface-3 px-1.5 py-0.5 text-xs text-ink-faint">
                  {a.activity_type}
                </span>
                <span className="ml-2 text-ink-muted">{a.title || "—"}</span>
              </span>
              <span className="text-xs text-ink-muted">
                {new Date(a.created_at).toLocaleString()}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
