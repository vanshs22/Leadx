"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { crmIntelligence } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
export default function TodayPage(){
 const [d,setD]=useState<any>(); const [e,setE]=useState("");
 useEffect(()=>{const t=getTenantId();if(!t)return;crmIntelligence.dailyBrief(t).then(setD).catch(x=>setE(x.message||"Could not load daily brief"));},[]);
 const items=[['New leads',d?.new_assignments||0,'/leads'],['Replies',d?.replies||0,'/replies'],['Positive replies',d?.positive_replies||0,'/replies'],['Won deals',d?.won_deals||0,'/pipeline']];
 return <div className="page space-y-5"><header><div className="section-kicker text-brand-600">Daily command center</div><h1 className="page-title">Today</h1><p className="page-sub">The work and opportunities most relevant to your revenue motion.</p></header>{e&&<div className="card-pad text-rust-500">{e}</div>}<div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{items.map(([a,b,h])=><Link key={String(a)} href={String(h)} className="kpi hover:border-brand-300"><div className="label">{a}</div><div className="kpi-value mt-2">{String(b)}</div><div className="mt-1 text-xs text-ink-faint">Open →</div></Link>)}</div><section className="hero-panel p-5 md:p-6"><div className="section-kicker text-signal-700 dark:text-signal-300">Revenue pulse</div><h2 className="mt-1 text-xl font-semibold">${Number(d?.revenue_won||0).toLocaleString()} won recently</h2><p className="mt-2 max-w-2xl text-sm text-ink-muted">Use Revenue Intelligence to connect lead sources, signals, outreach, meetings and closed revenue.</p><div className="mt-4 flex flex-wrap gap-2"><Link href="/revenue" className="btn-primary">Open revenue intelligence</Link><Link href="/search" className="btn-secondary">Find opportunities</Link></div></section></div>
}
