"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { crm, PipelineBoard, LeadCard } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { TierBadge } from "@/components/leads/TierBadge";


function LeadMiniCard({ lead }: { lead: LeadCard }) {
  return (
    <Link
      href={`/leads/${lead.assignment_id}`}
      className="block rounded-lg border border-line bg-surface/80 p-3 hover:border-brand-500/40 transition"
    >
      <div className="flex items-start justify-between gap-2">
        <span className="text-sm font-medium text-ink-faint line-clamp-2">
          {lead.company_name}
        </span>
        <TierBadge tier={lead.tier} />
      </div>
      <div className="mt-2 text-xs text-ink-faint">
        {lead.phone_e164 || lead.phone_normalized || "No phone"}
      </div>
      {lead.email && (
        <div className="mt-0.5 truncate text-xs text-ink-muted">{lead.email}</div>
      )}
      <div className="mt-2 flex items-center justify-between text-xs">
        <span className="tabular-nums text-ink-faint">
          Score {lead.total_score ?? 0}
        </span>
        {lead.city && <span className="text-ink-muted">{lead.city}</span>}
      </div>
    </Link>
  );
}

export default function PipelinePage() {
  const [board, setBoard] = useState<PipelineBoard | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    crm
      .pipeline(getTenantId())
      .then(setBoard)
      .catch((e) => setError(e.message));
  }, []);

  if (error) {
    return (
      <div className="p-8 text-rust-500">
        {error}
        <button
          className="ml-4 text-brand-400 underline"
          onClick={() => crm.setup(getTenantId()).then(() => location.reload())}
        >
          Seed default stages
        </button>
      </div>
    );
  }
  if (!board) {
    return <div className="p-8 text-ink-faint">Loading pipeline…</div>;
  }

  return (
    <div className="flex h-full flex-col p-6">
      <header className="mb-4">
        <h1 className="text-2xl font-semibold text-white">Pipeline</h1>
        <p className="mt-1 text-sm text-ink-faint">
          Drag-ready board · click a card for details · move stages from lead page
        </p>
      </header>

      <div className="flex flex-1 gap-4 overflow-x-auto pb-4">
        {board.stages.map((stage) => (
          <div
            key={stage.id}
            className="flex w-72 shrink-0 flex-col rounded-xl border border-line bg-surface/40"
          >
            <div
              className="flex items-center justify-between rounded-t-xl px-3 py-2.5"
              style={{ borderBottom: `2px solid ${stage.color}` }}
            >
              <span className="text-sm font-semibold text-white">
                {stage.name}
              </span>
              <span className="rounded-full bg-surface-3 px-2 py-0.5 text-xs tabular-nums text-ink-faint">
                {stage.leads.length}
              </span>
            </div>
            <div className="flex-1 space-y-2 overflow-y-auto p-2 max-h-[calc(100vh-220px)]">
              {stage.leads.map((lead) => (
                <LeadMiniCard key={lead.assignment_id} lead={lead} />
              ))}
              {stage.leads.length === 0 && (
                <p className="py-6 text-center text-xs text-ink-muted">Empty</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {board.unstaged.length > 0 && (
        <div className="mt-4 rounded-xl border border-dashed border-line p-4">
          <h3 className="text-sm font-medium text-ink-faint">
            Unstaged ({board.unstaged.length})
          </h3>
          <div className="mt-2 flex flex-wrap gap-2">
            {board.unstaged.slice(0, 12).map((l) => (
              <Link
                key={l.assignment_id}
                href={`/leads/${l.assignment_id}`}
                className="rounded-lg bg-surface px-3 py-1.5 text-xs text-ink-muted hover:bg-surface-3"
              >
                {l.company_name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
