"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { crm, PipelineBoard, LeadCard } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { TierBadge } from "@/components/leads/TierBadge";

function LeadMiniCard({
  lead,
  onDragStart,
}: {
  lead: LeadCard;
  onDragStart: (assignmentId: string) => void;
}) {
  return (
    <div
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData("text/assignment_id", lead.assignment_id);
        e.dataTransfer.effectAllowed = "move";
        onDragStart(lead.assignment_id);
      }}
      className="cursor-grab active:cursor-grabbing rounded-lg border border-line bg-surface p-3 shadow-sm hover:border-brand-500/50 transition"
    >
      <Link
        href={`/leads/${lead.assignment_id}`}
        onClick={(e) => e.stopPropagation()}
        className="block"
      >
        <div className="flex items-start justify-between gap-2">
          <span className="text-sm font-medium text-ink line-clamp-2">
            {lead.company_name || "Lead"}
          </span>
          <TierBadge tier={lead.tier} />
        </div>
        <div className="mt-2 text-xs text-ink-muted">
          {lead.phone_e164 || lead.phone_normalized || "No phone"}
        </div>
        {lead.email ? (
          <div className="mt-0.5 truncate text-xs text-ink-faint">{lead.email}</div>
        ) : null}
        <div className="mt-2 flex items-center justify-between text-xs">
          <span className="tabular-nums text-ink-muted">Score {lead.total_score ?? 0}</span>
          {lead.city ? <span className="text-ink-faint">{lead.city}</span> : null}
        </div>
      </Link>
    </div>
  );
}

export default function PipelinePage() {
  const [board, setBoard] = useState<PipelineBoard | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [moving, setMoving] = useState(false);
  const [dragId, setDragId] = useState<string | null>(null);
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    const tid = getTenantId();
    if (!tid) {
      setError("No workspace selected");
      return;
    }
    crm
      .pipeline(tid)
      .then(setBoard)
      .catch((e) => setError(e.message));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function moveToStage(assignmentId: string, stageId: string) {
    const tid = getTenantId();
    if (!tid || !assignmentId || !stageId) return;
    setMoving(true);
    setMsg("");
    try {
      await crm.changeStage(tid, assignmentId, stageId);
      setMsg("Moved");
      load();
    } catch (e: any) {
      setMsg(e?.message || "Move failed");
    } finally {
      setMoving(false);
      setDragId(null);
    }
  }

  if (error) {
    return (
      <div className="p-8 text-rust-500">
        {error}
        <button
          className="ml-4 text-brand-400 underline"
          onClick={() => crm.setup(getTenantId()).then(() => location.reload())}
        >
          Seed default stages
        </button>
      </div>
    );
  }
  if (!board) {
    return <div className="p-8 text-ink-faint">Loading pipeline…</div>;
  }

  return (
    <div className="flex h-[calc(100vh-3rem)] flex-col p-6">
      <header className="mb-4 shrink-0">
        <h1 className="text-2xl font-semibold text-ink">Pipeline</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Drag cards between columns · click name for full lead · {moving ? "Saving…" : msg || "Ready"}
        </p>
      </header>

      <div className="flex min-h-0 flex-1 gap-4 overflow-x-auto pb-2">
        {board.stages.map((stage) => (
          <div
            key={stage.id}
            className="flex w-80 shrink-0 flex-col rounded-xl border border-line bg-surface-2/40"
            onDragOver={(e) => {
              e.preventDefault();
              e.dataTransfer.dropEffect = "move";
            }}
            onDrop={(e) => {
              e.preventDefault();
              const id =
                e.dataTransfer.getData("text/assignment_id") ||
                e.dataTransfer.getData("text/plain") ||
                dragId ||
                "";
              if (id) moveToStage(id, stage.id);
            }}
          >
            <div
              className="flex shrink-0 items-center justify-between border-b border-line px-3 py-2"
              style={{ borderBottomColor: stage.color || undefined }}
            >
              <span className="text-sm font-semibold text-ink">{stage.name}</span>
              <span className="rounded-full bg-surface px-2 py-0.5 text-xs tabular-nums text-ink-muted">
                {stage.leads?.length ?? 0}
              </span>
            </div>
            <div className="flex min-h-[200px] flex-1 flex-col gap-2 overflow-y-auto p-2">
              {(stage.leads || []).map((lead) => (
                <LeadMiniCard
                  key={lead.assignment_id}
                  lead={lead}
                  onDragStart={setDragId}
                />
              ))}
              {(stage.leads || []).length === 0 && (
                <p className="py-8 text-center text-xs text-ink-faint">Drop leads here</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {board.unstaged && board.unstaged.length > 0 && (
        <div
          className="mt-4 shrink-0 rounded-xl border border-dashed border-line p-4"
          onDragOver={(e) => e.preventDefault()}
        >
          <h3 className="text-sm font-medium text-ink-muted">
            Unstaged ({board.unstaged.length}) — open lead and set stage, or drag into a column
          </h3>
          <div className="mt-2 flex max-h-40 flex-wrap gap-2 overflow-y-auto">
            {board.unstaged.map((l) => (
              <div
                key={l.assignment_id}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData("text/assignment_id", l.assignment_id);
                  setDragId(l.assignment_id);
                }}
                className="cursor-grab rounded-lg bg-surface px-3 py-1.5 text-xs text-ink-muted hover:bg-surface-3"
              >
                <Link href={`/leads/${l.assignment_id}`}>{l.company_name || l.assignment_id}</Link>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
