"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { crm, PipelineBoard, LeadCard } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { TierBadge } from "@/components/leads/TierBadge";

function LeadMiniCard({
  lead,
  onDragStart,
}: {
  lead: LeadCard;
  onDragStart: (e: React.DragEvent, lead: LeadCard) => void;
}) {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, lead)}
      className="cursor-grab rounded-lg border border-slate-800 bg-slate-950/80 p-3 transition hover:border-indigo-500/40 active:cursor-grabbing"
    >
      <div className="flex items-start justify-between gap-2">
        <Link
          href={`/leads/${lead.assignment_id}`}
          className="text-sm font-medium text-slate-200 line-clamp-2 hover:text-white"
          onClick={(e) => e.stopPropagation()}
        >
          {lead.company_name || lead.name || "Lead"}
        </Link>
        <TierBadge tier={lead.tier} />
      </div>
      <div className="mt-2 text-xs text-slate-500">
        {lead.phone_e164 || lead.phone_normalized || lead.phone || "No phone"}
      </div>
      {lead.email && (
        <div className="mt-0.5 truncate text-xs text-slate-600">{lead.email}</div>
      )}
      <div className="mt-2 flex items-center justify-between text-xs">
        <span className="tabular-nums text-slate-500">
          Score {lead.total_score ?? lead.score ?? 0}
        </span>
        {lead.city && <span className="text-slate-600">{lead.city}</span>}
      </div>
    </div>
  );
}

export default function PipelinePage() {
  const tenantId = getTenantId();
  const [board, setBoard] = useState<PipelineBoard | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    if (!tenantId) return;
    crm
      .pipeline(tenantId)
      .then(setBoard)
      .catch((e) => setError(e.message));
  }, [tenantId]);

  useEffect(() => {
    load();
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, [load]);

  function onDragStart(e: React.DragEvent, lead: LeadCard) {
    e.dataTransfer.setData("text/assignment_id", lead.assignment_id);
    e.dataTransfer.effectAllowed = "move";
  }

  function onDragOver(e: React.DragEvent) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }

  async function onDrop(e: React.DragEvent, stageId: string, stageName: string) {
    e.preventDefault();
    const assignmentId = e.dataTransfer.getData("text/assignment_id");
    if (!assignmentId || !tenantId) return;
    setSaving(true);
    setMsg("");
    try {
      await crm.changeStage(tenantId, assignmentId, stageId);
      setMsg(`Moved → ${stageName}`);
      load();
    } catch (err: any) {
      setMsg(err.message || "Move failed");
    } finally {
      setSaving(false);
    }
  }

  if (error) {
    return (
      <div className="p-8 text-red-400">
        {error}
        <button
          className="ml-4 text-indigo-400 underline"
          onClick={() =>
            crm.setup(tenantId).then(() => location.reload()).catch((e) => setError(e.message))
          }
        >
          Seed default stages (New → Contacted → … → Won / Lost)
        </button>
      </div>
    );
  }
  if (!board) {
    return <div className="p-8 text-slate-500">Loading pipeline…</div>;
  }

  return (
    <div className="flex h-full flex-col p-6">
      <header className="mb-4 shrink-0">
        <h1 className="text-2xl font-semibold text-white">Pipeline</h1>
        <p className="mt-1 text-sm text-slate-400">
          Drag leads between stages · New → Contacted → Qualified → Won / Lost
        </p>
        {msg && <p className="mt-1 text-xs text-emerald-400">{msg}</p>}
        {saving && <p className="text-xs text-slate-500">Saving…</p>}
      </header>

      <div className="flex flex-1 gap-3 overflow-x-auto pb-4">
        {(board.stages || []).map((stage: any) => (
          <div
            key={stage.id}
            onDragOver={onDragOver}
            onDrop={(e) => onDrop(e, stage.id, stage.name)}
            className="flex w-72 shrink-0 flex-col rounded-xl border border-slate-800 bg-slate-900/40"
          >
            <div
              className="flex items-center justify-between rounded-t-xl px-3 py-2.5"
              style={{ borderBottom: `2px solid ${stage.color || "#6366f1"}` }}
            >
              <span className="text-sm font-semibold text-white">{stage.name}</span>
              <span className="rounded-full bg-slate-800 px-2 py-0.5 text-xs tabular-nums text-slate-400">
                {(stage.leads || []).length}
              </span>
            </div>
            <div className="max-h-[calc(100vh-220px)] flex-1 space-y-2 overflow-y-auto p-2">
              {(stage.leads || []).map((lead: LeadCard) => (
                <LeadMiniCard
                  key={lead.assignment_id}
                  lead={lead}
                  onDragStart={onDragStart}
                />
              ))}
              {(stage.leads || []).length === 0 && (
                <p className="rounded-lg border border-dashed border-slate-800 py-8 text-center text-xs text-slate-600">
                  Drop leads here
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {(board.unstaged || []).length > 0 && (
        <div
          className="mt-4 rounded-xl border border-dashed border-slate-700 p-4"
          onDragOver={onDragOver}
        >
          <h3 className="text-sm font-medium text-slate-400">
            Unstaged ({board.unstaged.length}) — open a lead or drag into a stage above
          </h3>
          <div className="mt-2 flex flex-wrap gap-2">
            {board.unstaged.slice(0, 24).map((l: LeadCard) => (
              <div
                key={l.assignment_id}
                draggable
                onDragStart={(e) => onDragStart(e, l)}
                className="cursor-grab rounded-lg bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
              >
                {l.company_name || l.name}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
