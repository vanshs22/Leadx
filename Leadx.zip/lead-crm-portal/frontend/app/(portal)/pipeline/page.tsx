"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { crm, PipelineBoard, LeadCard } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";
import { TierBadge } from "@/components/leads/TierBadge";

function LeadMiniCard({
  lead,
  onDragStart,
}: {
  lead: LeadCard;
  onDragStart: (e: React.DragEvent, lead: LeadCard) => void;
}) {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, lead)}
      className="cursor-grab rounded-xl2 border border-line bg-surface-2 p-3 transition hover:border-brand-400/50 active:cursor-grabbing"
    >
      <div className="flex items-start justify-between gap-2">
        <Link
          href={`/leads/${lead.assignment_id}`}
          className="text-sm font-medium text-ink line-clamp-2 hover:text-brand-600 dark:hover:text-brand-300"
          onClick={(e) => e.stopPropagation()}
        >
          {lead.company_name || lead.name || "Lead"}
        </Link>
        <TierBadge tier={lead.tier} />
      </div>
      <div className="mt-2 font-mono text-xs text-ink-faint">
        {lead.phone_e164 || lead.phone_normalized || lead.phone || "No phone"}
      </div>
      {lead.email && (
        <div className="mt-0.5 truncate text-xs text-ink-faint">{lead.email}</div>
      )}
      <div className="mt-2 flex items-center justify-between text-xs">
        <span className="font-mono tabular-nums text-ink-faint">
          Score {lead.total_score ?? lead.score ?? 0}
        </span>
        {lead.city && <span className="text-ink-faint">{lead.city}</span>}
      </div>
    </div>
  );
}

export default function PipelinePage() {
  const tenantId = getTenantId();
  const [board, setBoard] = useState<PipelineBoard | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    if (!tenantId) return;
    crm
      .pipeline(tenantId)
      .then(setBoard)
      .catch((e) => setError(e.message));
  }, [tenantId]);

  useEffect(() => {
    load();
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, [load]);

  function onDragStart(e: React.DragEvent, lead: LeadCard) {
    e.dataTransfer.setData("text/assignment_id", lead.assignment_id);
    e.dataTransfer.effectAllowed = "move";
  }

  function onDragOver(e: React.DragEvent) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  }

  async function onDrop(e: React.DragEvent, stageId: string, stageName: string) {
    e.preventDefault();
    const assignmentId = e.dataTransfer.getData("text/assignment_id");
    if (!assignmentId || !tenantId) return;
    setSaving(true);
    setMsg("");
    try {
      await crm.changeStage(tenantId, assignmentId, stageId);
      setMsg(`Moved → ${stageName}`);
      load();
    } catch (err: any) {
      setMsg(err.message || "Move failed");
    } finally {
      setSaving(false);
    }
  }

  if (error) {
    return (
      <div className="p-8 text-rust-500 dark:text-rust-300">
        {error}
        <button
          className="ml-4 text-brand-600 underline dark:text-brand-300"
          onClick={() =>
            crm.setup(tenantId).then(() => location.reload()).catch((e) => setError(e.message))
          }
        >
          Seed default stages (New → Contacted → … → Won / Lost)
        </button>
      </div>
    );
  }
  if (!board) {
    return <div className="p-8 text-ink-faint">Loading pipeline…</div>;
  }

  return (
    <div className="flex h-full flex-col p-6">
      <header className="mb-4 shrink-0">
        <h1 className="font-display text-2xl font-semibold text-ink">Pipeline</h1>
        <p className="mt-1 text-sm text-ink-muted">
          Drag leads between stages · New → Contacted → Qualified → Won / Lost
        </p>
        {msg && <p className="mt-1 text-xs text-signal-600 dark:text-signal-300">{msg}</p>}
        {saving && <p className="text-xs text-ink-faint">Saving…</p>}
      </header>

      <div className="flex flex-1 gap-3 overflow-x-auto pb-4">
        {(board.stages || []).map((stage: any) => (
          <div
            key={stage.id}
            onDragOver={onDragOver}
            onDrop={(e) => onDrop(e, stage.id, stage.name)}
            className="flex w-72 shrink-0 flex-col rounded-xl2 border border-line bg-surface-2/60"
          >
            <div
              className="flex items-center justify-between rounded-t-xl2 px-3 py-2.5"
              style={{ borderBottom: `2px solid ${stage.color || "rgb(var(--brand))"}` }}
            >
              <span className="text-sm font-semibold text-ink">{stage.name}</span>
              <span className="rounded-full bg-surface-3 px-2 py-0.5 font-mono text-xs tabular-nums text-ink-muted">
                {(stage.leads || []).length}
              </span>
            </div>
            <div className="max-h-[calc(100vh-220px)] flex-1 space-y-2 overflow-y-auto p-2">
              {(stage.leads || []).map((lead: LeadCard) => (
                <LeadMiniCard
                  key={lead.assignment_id}
                  lead={lead}
                  onDragStart={onDragStart}
                />
              ))}
              {(stage.leads || []).length === 0 && (
                <p className="rounded-xl2 border border-dashed border-line py-8 text-center text-xs text-ink-faint">
                  Drop leads here
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {(board.unstaged || []).length > 0 && (
        <div
          className="mt-4 rounded-xl2 border border-dashed border-line p-4"
          onDragOver={onDragOver}
        >
          <h3 className="text-sm font-medium text-ink-muted">
            Unstaged ({board.unstaged.length}) — open a lead or drag into a stage above
          </h3>
          <div className="mt-2 flex flex-wrap gap-2">
            {board.unstaged.slice(0, 24).map((l: LeadCard) => (
              <div
                key={l.assignment_id}
                draggable
                onDragStart={(e) => onDragStart(e, l)}
                className="cursor-grab rounded-lg bg-surface-3 px-3 py-1.5 text-xs text-ink-muted hover:bg-surface-3/70"
              >
                {l.company_name || l.name}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
