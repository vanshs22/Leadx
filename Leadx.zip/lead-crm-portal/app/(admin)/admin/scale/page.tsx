"use client";
import { setVisibleInterval, clearVisibleInterval } from "@/lib/live";
import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";

function Metric({label,value,hint}:{label:string,value:any,hint?:string}){return <div className="kpi"><div className="label">{label}</div><div className="kpi-value mt-2">{value ?? "—"}</div>{hint&&<div className="mt-1 text-xs text-ink-faint">{hint}</div>}</div>}
export default function ScalePage(){
  const [d,setD]=useState<any>(); const [err,setErr]=useState("");
  const load=()=>admin.platformSummary().then(setD).catch(e=>setErr(e.message));
  useEffect(()=>{load();const t=setVisibleInterval(load,15000);return()=>clearVisibleInterval(t)},[]);
  const q=d?.queue||{}; const workers=d?.workers||[]; const providers=d?.providers||[]; const stale=d?.stale_workers||[];
  return <div className="page space-y-5">
    <header><div className="section-kicker text-signal-700 dark:text-signal-300">Production control</div><h1 className="page-title">Scale & reliability</h1><p className="page-sub">Worker liveness, queue pressure, provider health and recent security events.</p></header>
    {err&&<div className="card-pad text-rust-500">{err}</div>}
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5"><Metric label="Workers" value={workers.length} hint={stale.length?`${stale.length} stale`:'all reporting'}/><Metric label="Queued" value={q.queued} hint={`oldest ${q.oldest_queued_seconds||0}s`}/><Metric label="Running" value={q.running}/><Metric label="Failed" value={q.failed}/><Metric label="System" value={d?.ok===false?'Degraded':'Healthy'}/></div>
    <section className="data-card p-5"><div className="section-kicker">Worker fleet</div><div className="mt-4 overflow-x-auto"><table className="min-w-full text-sm"><thead><tr className="border-b border-line text-left text-xs text-ink-faint"><th className="py-2">Worker</th><th>Capacity</th><th>Status</th><th>Last seen</th></tr></thead><tbody>{workers.map((w:any)=><tr key={w.worker_id} className="border-b border-line/60"><td className="py-3 font-mono text-xs">{w.worker_id}</td><td>{w.capacity}</td><td><span className="pill bg-signal-50 text-signal-700 dark:bg-signal-500/10 dark:text-signal-300">{w.status}</span></td><td className="text-xs text-ink-muted">{w.last_seen_at}</td></tr>)}</tbody></table>{!workers.length&&<p className="py-6 text-sm text-ink-faint">No live workers reported. Start the worker process.</p>}</div></section>
    <section className="data-card p-5"><div className="flex items-center justify-between"><div><div className="section-kicker">Provider health</div><h2 className="mt-1 text-lg font-semibold">Source reliability & cost</h2></div><span className="pill bg-surface-3 text-ink-muted">Auto-refresh 15s</span></div><div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">{providers.map((p:any)=><div key={`${p.provider}:${p.operation}`} className="action-card"><div className="flex justify-between"><strong>{p.provider}</strong><span className="pill bg-surface-3">{p.status}</span></div><div className="mt-2 text-xs text-ink-muted">{p.operation} · {p.success_count||0} success · {p.failure_count||0} failures</div><div className="mt-1 text-xs text-ink-faint">Latency {Math.round(p.latency_ms||0)}ms · cost ${Number(p.estimated_cost||0).toFixed(2)}</div></div>)}</div></section>
    <section className="data-card p-5"><div className="section-kicker">Security signals</div><div className="mt-3 space-y-2">{(d?.recent_security_events||[]).slice(0,10).map((e:any)=><div key={e.id} className="flex items-center justify-between rounded-xl border border-line bg-surface-2 px-3 py-2 text-sm"><span>{e.event_type}</span><span className="pill bg-surface-3">{e.severity}</span></div>)}{!(d?.recent_security_events||[]).length&&<span className="text-sm text-ink-faint">No recent security events.</span>}</div></section>
  </div>
}
