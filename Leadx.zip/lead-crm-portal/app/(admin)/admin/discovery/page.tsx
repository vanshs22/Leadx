"use client";

import { useEffect, useMemo, useState } from "react";
import { admin } from "@/lib/admin";
import { setVisibleInterval, clearVisibleInterval } from "@/lib/live";

type RequestRow = any;

export default function AdminDiscoveryPage() {
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [tenants, setTenants] = useState<any[]>([]);
  const [status, setStatus] = useState("pending_approval");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  const tenantNames = useMemo(() => new Map(tenants.map((t) => [String(t.id), t.name])), [tenants]);

  async function load() {
    try {
      const [requestResponse, tenantResponse] = await Promise.all([
        admin.discoveryRequests(status),
        tenants.length ? Promise.resolve({ tenants }) : admin.tenants("active", 200),
      ]);
      setRequests(requestResponse.requests || []);
      if (!tenants.length) setTenants(tenantResponse.tenants || []);
      setMessage("");
    } catch (error: any) {
      setMessage(error?.message || "Unable to load discovery requests");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    const timer = setVisibleInterval(() => { void load(); }, 10000);
    return () => clearVisibleInterval(timer);
  }, [status]);

  async function approve(row: RequestRow) {
    const suggested = Number(row.requested_leads || 0);
    const value = window.prompt(`Approve how many leads? Requested: ${suggested}`, String(suggested));
    if (value === null) return;
    const approved = Math.max(1, Number(value) || 0);
    const reason = window.prompt("Approval note", "Approved for client discovery") || "Approved by admin";
    setBusyId(row.id);
    try {
      await admin.approveDiscovery(row.id, { approved_leads: approved, reason });
      setMessage(`Approved ${approved} leads for ${row.vertical}. The worker will process it.`);
      await load();
    } catch (error: any) {
      setMessage(error?.message || "Approval failed");
    } finally {
      setBusyId(null);
    }
  }

  async function reject(row: RequestRow) {
    const reason = window.prompt("Reason for rejection", "Not approved at this time.");
    if (reason === null) return;
    setBusyId(row.id);
    try {
      await admin.rejectDiscovery(row.id, reason || "Not approved at this time.");
      setMessage("Discovery request rejected.");
      await load();
    } catch (error: any) {
      setMessage(error?.message || "Rejection failed");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="page">
      <header className="flex flex-col gap-4 border-b border-line pb-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="section-kicker text-brand-700 dark:text-brand-300">Revenue operations</p>
          <h1 className="page-title mt-1">Discovery approvals</h1>
          <p className="page-sub">Review client opportunity requests before the discovery worker spends provider time or quota.</p>
        </div>
        <select className="input w-full sm:w-52" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="pending_approval">Pending approval</option>
          <option value="queued">Queued</option>
          <option value="running">Running</option>
          <option value="completed">Completed</option>
          <option value="failed">Failed</option>
          <option value="rejected">Rejected</option>
        </select>
      </header>

      {message && <div className="rounded-xl border border-line bg-surface-2 px-4 py-3 text-sm text-ink-muted">{message}</div>}

      {loading ? (
        <div className="grid gap-4 lg:grid-cols-2" aria-busy="true">
          {[0, 1].map((item) => <div key={item} className="skeleton h-56 rounded-2xl" />)}
        </div>
      ) : requests.length === 0 ? (
        <div className="card-pad border-dashed text-center">
          <div className="text-sm font-semibold text-ink">No {status.replace("_", " ")} requests</div>
          <p className="mt-1 text-sm text-ink-muted">New client requests will appear here automatically.</p>
        </div>
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {requests.map((row) => {
            const active = row.status === "pending_approval";
            return (
              <article key={row.id} className="data-card p-5 md:p-6">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="section-kicker">{row.vertical || "General"}</p>
                    <h2 className="mt-1 text-lg font-semibold text-ink">{tenantNames.get(String(row.tenant_id)) || "Client workspace"}</h2>
                    <p className="mt-1 text-xs text-ink-faint">{(row.locations || []).join(", ") || "Any location"}</p>
                  </div>
                  <span className="pill bg-surface-3 text-ink-muted">{String(row.status || "unknown").replace(/_/g, " ")}</span>
                </div>
                <div className="mt-5 grid grid-cols-3 gap-3">
                  <div className="rounded-xl border border-line bg-surface-3/60 p-3"><div className="stat-label">Requested</div><div className="mt-1 metric-number text-xl">{row.requested_leads ?? 0}</div></div>
                  <div className="rounded-xl border border-line bg-surface-3/60 p-3"><div className="stat-label">Approved</div><div className="mt-1 metric-number text-xl">{row.approved_leads ?? "—"}</div></div>
                  <div className="rounded-xl border border-line bg-surface-3/60 p-3"><div className="stat-label">Assigned</div><div className="mt-1 metric-number text-xl">{row.assigned_count ?? 0}</div></div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2 text-xs text-ink-muted">
                  <span className="pill bg-brand-50 text-brand-800 dark:bg-brand-500/15 dark:text-brand-200">Offer: {row.offer_category || "lead gen"}</span>
                  <span className="pill bg-surface-3 text-ink-muted">Created {row.created_at ? new Date(row.created_at).toLocaleString() : "—"}</span>
                </div>
                {active && (
                  <div className="mt-5 flex justify-end gap-2 border-t border-line pt-4">
                    <button type="button" className="btn-secondary" disabled={busyId === row.id} onClick={() => void reject(row)}>Reject</button>
                    <button type="button" className="btn-primary" disabled={busyId === row.id} onClick={() => void approve(row)}>{busyId === row.id ? "Saving…" : "Approve request"}</button>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
