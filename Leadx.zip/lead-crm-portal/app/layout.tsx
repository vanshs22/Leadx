import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme/ThemeProvider";

// Real font loading (next/font self-hosts at build time — no runtime request
// to Google Fonts, no layout-shift flash of unstyled text). Previously the
// CSS variables referenced "Inter" / "Space Grotesk" without ever loading
// them, so every browser silently fell back to the OS default UI font —
// the single biggest reason the product read as generic.
const sans = Inter({ subsets: ["latin"], variable: "--font-sans-loaded", display: "swap" });
const display = Space_Grotesk({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-display-loaded", display: "swap" });
const mono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400", "500", "600"], variable: "--font-mono-loaded", display: "swap" });

export const metadata: Metadata = {
  title: "LeadX — Verified Local Lead Intelligence",
  description: "Exclusive, verified local leads with evidence — delivered straight into your CRM workflow.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f6f7f4" },
    { media: "(prefers-color-scheme: dark)", color: "#090c12" },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${sans.variable} ${display.variable} ${mono.variable}`}>
      <body className="font-sans antialiased">
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
