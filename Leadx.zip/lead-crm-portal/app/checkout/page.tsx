"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { billing } from "@/lib/api";
import { getSessionFast } from "@/lib/auth";
import { BrandMark } from "@/components/ui/BrandMark";
import { Icon } from "@/components/ui/Icon";

const PLANS: Record<string, { name: string; monthly: number; annual: number; leads: string }> = {
  starter: { name: "Starter", monthly: 49, annual: 39, leads: "500 qualified leads / month" },
  growth: { name: "Growth", monthly: 149, annual: 119, leads: "2,500 qualified leads / month" },
  agency: { name: "Agency", monthly: 399, annual: 319, leads: "8,000 qualified leads / month" },
};

export default function CheckoutPage() {
  const [planKey, setPlanKey] = useState("growth");
  const [interval, setBillingInterval] = useState<"monthly" | "annual">("annual");
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setPlanKey(params.get("plan") || "growth");
    setBillingInterval(params.get("interval") === "monthly" ? "monthly" : "annual");
    getSessionFast().then((s) => setSignedIn(!!s));
  }, []);

  const plan = PLANS[planKey] || PLANS.growth;
  const price = interval === "annual" ? plan.annual : plan.monthly;
  const yearlyTotal = interval === "annual" ? price * 12 : plan.monthly * 12;

  async function pay() {
    setBusy(true); setError("");
    try {
      const result = await billing.createCheckout(planKey, interval);
      if (result.redirect_url) window.location.href = result.redirect_url;
      else if (result.free) window.location.href = "/dashboard";
      else throw new Error("Checkout session was not created.");
    } catch (e: any) {
      setError(e?.message || "Could not start checkout");
      setBusy(false);
    }
  }

  if (new URLSearchParams(typeof window !== "undefined" ? window.location.search : "").get("success") === "1") {
    return (
      <main className="min-h-screen bg-surface px-5 py-16">
        <div className="card-pad mx-auto max-w-xl text-center shadow-lift">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"><Icon name="check" className="h-5 w-5" /></span>
          <h1 className="mt-5 text-2xl font-bold tracking-tight text-ink">Payment received</h1>
          <p className="mt-2 text-sm leading-6 text-ink-muted">Your workspace is being upgraded. Stripe will confirm the subscription and LeadX will apply the new plan automatically.</p>
          <Link href="/dashboard" className="btn-primary mt-7 inline-flex px-5 py-3">Open workspace</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-surface text-ink">
      <header className="border-b border-line bg-surface-2">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8">
          <Link href="/pricing" className="flex items-center gap-2.5"><BrandMark size={34} /><span className="brand-wordmark">LeadX</span></Link>
          <Link href="/pricing" className="text-sm font-semibold text-ink-muted hover:text-ink">Back to pricing</Link>
        </div>
      </header>
      <div className="mx-auto grid max-w-5xl gap-8 px-5 py-12 lg:grid-cols-[1fr_420px] sm:px-8">
        <section className="pt-4">
          <p className="eyebrow text-brand-700 dark:text-brand-300">Secure checkout</p>
          <h1 className="mt-3 text-4xl font-bold tracking-[-.03em] text-ink">Upgrade your LeadX workspace.</h1>
          <p className="mt-4 max-w-xl text-base leading-7 text-ink-muted">One subscription covers discovery, enrichment, research and the CRM workspace. Your final card details are handled by Stripe.</p>
          <div className="mt-10 grid gap-3 sm:grid-cols-2">
            <div className="card-pad"><p className="label">Included</p><p className="mt-2 text-sm font-semibold text-ink">{plan.leads}</p></div>
            <div className="card-pad"><p className="label">Billing</p><p className="mt-2 text-sm font-semibold text-ink">{interval === "annual" ? "Annual · 20% savings" : "Monthly · cancel anytime"}</p></div>
          </div>
        </section>
        <section className="card-pad shadow-lift">
          <div className="flex items-start justify-between"><div><p className="text-sm font-semibold text-ink">{plan.name}</p><p className="mt-1 text-xs text-ink-faint">LeadX subscription</p></div><Link href={`/checkout?plan=${planKey}&interval=${interval === "annual" ? "monthly" : "annual"}`} className="text-xs font-semibold text-brand-600 hover:underline dark:text-brand-300">Switch {interval === "annual" ? "monthly" : "annual"}</Link></div>
          <div className="mt-7 flex items-end gap-1"><span className="font-display text-4xl font-bold tracking-[-.03em] text-ink">${price}</span><span className="mb-1 text-sm text-ink-faint">/mo</span></div>
          <p className="mt-1 text-xs text-ink-faint">{interval === "annual" ? `$${yearlyTotal} billed annually` : "Billed monthly"}</p>
          <div className="my-6 border-t border-line" />
          {signedIn ? (
            <button type="button" aria-label="Continue to secure payment" onClick={pay} disabled={busy} className="btn-primary w-full py-3">{busy ? "Opening secure checkout…" : "Continue to secure payment"}</button>
          ) : (
            <Link href={`/login?next=${encodeURIComponent(`/checkout?plan=${planKey}&interval=${interval}`)}`} className="btn-primary block w-full py-3 text-center">Sign in to continue</Link>
          )}
          {error && <p className="mt-3 rounded-lg bg-rust-50 px-3 py-2 text-xs leading-5 text-rust-700 dark:bg-rust-500/10 dark:text-rust-300">{error}</p>}
          <p className="mt-4 text-center text-[11px] leading-5 text-ink-faint">You will be redirected to Stripe for card entry and confirmation. LeadX does not store your full card number.</p>
        </section>
      </div>
    </main>
  );
}
