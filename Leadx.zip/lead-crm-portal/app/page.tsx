import Link from "next/link";
import { BrandMark } from "@/components/ui/BrandMark";
import { Icon } from "@/components/ui/Icon";

const FEATURES = [
  { icon: "radar" as const, title: "Exclusive", body: "Territory and assignment controls reduce duplicate delivery across every workspace." },
  { icon: "sparkles" as const, title: "Why now", body: "Review, booking, website and intent signals explain the exact angle to call on." },
  { icon: "check" as const, title: "Quality guarantee", body: "Dead or invalid contacts return a lead credit automatically through the SLA workflow." },
];

const PLANS = [
  { name: "Free", price: "$0", detail: "100 qualified leads / month", description: "Explore the engine with no card required." },
  { name: "Starter", price: "$39", detail: "500 qualified leads / month", description: "Focused prospecting for a growing motion." },
  { name: "Growth", price: "$119", detail: "2,500 qualified leads / month", description: "Repeatable lead generation for active teams." },
  { name: "Agency", price: "$319", detail: "8,000 qualified leads / month", description: "Multi-client operations with room to scale." },
];

export default function Landing() {
  return (
    <main className="min-h-screen bg-surface text-ink">
      <header className="sticky top-0 z-10 border-b border-line/70 bg-surface/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
          <Link href="#top" className="flex items-center gap-2.5">
            <BrandMark size={34} />
            <span className="brand-wordmark">LeadX</span>
          </Link>
          <nav aria-label="Main navigation" className="flex items-center gap-5 text-sm font-medium text-ink-muted">
            <a href="#pricing" className="hidden hover:text-ink sm:inline">Pricing</a>
            <a href="#security" className="hidden hover:text-ink sm:inline">Security</a>
            <Link href="/login" className="btn-secondary px-3.5 py-2 text-sm">Sign in</Link>
          </nav>
        </div>
      </header>

      <div id="top">
        <section className="relative mx-auto max-w-6xl overflow-hidden px-5 py-16 sm:px-8 md:py-24">
          <div
            aria-hidden
            className="pointer-events-none absolute inset-x-0 -top-24 h-[480px] opacity-70"
            style={{
              backgroundImage:
                "radial-gradient(55% 60% at 20% 20%, rgb(var(--brand) / .16), transparent 65%), radial-gradient(40% 45% at 85% 10%, rgb(var(--accent) / .14), transparent 65%)",
            }}
          />
          <div className="relative max-w-3xl">
            <span className="label inline-flex items-center gap-1.5 rounded-full border border-line bg-surface-2 px-3 py-1.5 text-brand-700 dark:text-brand-300">
              <Icon name="radar" className="h-3 w-3" /> Local lead intelligence
            </span>
            <h1 className="mt-5 text-4xl font-bold leading-[1.05] tracking-tight text-ink sm:text-6xl md:text-7xl">
              Exclusive local leads. Verified. Explained. Delivered.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-muted">
              LeadX finds local businesses, verifies the contact data, surfaces the reason to reach out now,
              and drops every lead straight into the CRM workflow your team already runs.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/sample" className="btn-primary px-5 py-3 text-sm">Get a free sample pack</Link>
              <a href="#pricing" className="btn-secondary px-5 py-3 text-sm">See pricing</a>
              <Link href="/login" className="btn-ghost px-5 py-3 text-sm">Sign in</Link>
            </div>
          </div>

          <div className="relative mt-16 grid gap-4 sm:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="data-card-hover card-pad">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                  <Icon name={f.icon} className="h-5 w-5" />
                </span>
                <b className="mt-4 block text-ink">{f.title}</b>
                <p className="mt-2 text-sm leading-6 text-ink-muted">{f.body}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="pricing" className="scroll-mt-24 border-t border-line">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 md:py-20">
            <div className="max-w-2xl">
              <div className="section-kicker text-brand-500">PRICING</div>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight md:text-4xl">Pay for qualified leads, not a maze of credits.</h2>
              <p className="mt-4 text-ink-muted">Start free, then scale when your prospecting motion is working. Annual plans shown below save 20%.</p>
            </div>
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {PLANS.map((plan) => (
                <article key={plan.name} className="card-pad flex min-h-52 flex-col">
                  <h3 className="text-lg font-semibold">{plan.name}</h3>
                  <p className="mt-4 text-3xl font-semibold">{plan.price}<span className="text-sm font-normal text-ink-muted"> /mo</span></p>
                  <p className="mt-2 text-sm font-medium text-brand-500">{plan.detail}</p>
                  <p className="mt-2 text-sm text-ink-muted">{plan.description}</p>
                </article>
              ))}
            </div>
            <p className="mt-6 text-sm text-ink-muted">Need custom security, procurement, or data terms? <Link href="/login" className="font-semibold text-ink hover:underline">Talk to sales</Link>.</p>
          </div>
        </section>

        <section id="security" className="scroll-mt-24 border-t border-line">
          <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 md:py-20">
            <div className="max-w-2xl">
              <div className="section-kicker text-brand-500">SECURITY</div>
              <h2 className="mt-2 text-3xl font-semibold tracking-tight md:text-4xl">Security is part of the workspace, not an afterthought.</h2>
              <p className="mt-4 text-ink-muted">LeadX scopes requests to the authenticated workspace and keeps browser sessions in protected cookies. Customer data is handled for discovery, enrichment, scoring, delivery, and CRM automation.</p>
            </div>
            <div className="mt-8 grid gap-4 md:grid-cols-3">
              <div className="card-pad"><h3 className="font-semibold">Tenant isolation</h3><p className="mt-2 text-sm leading-6 text-ink-muted">Every CRM request is verified against the signed-in user&apos;s active workspace membership.</p></div>
              <div className="card-pad"><h3 className="font-semibold">Customer controls</h3><p className="mt-2 text-sm leading-6 text-ink-muted">Export and deletion requests are available through support, with suppression controls for outreach.</p></div>
              <div className="card-pad"><h3 className="font-semibold">Responsible outreach</h3><p className="mt-2 text-sm leading-6 text-ink-muted">Customers remain responsible for CAN-SPAM, TCPA, GDPR/ePrivacy, consent, and local marketing requirements.</p></div>
            </div>
          </div>
        </section>
      </div>

      <section className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-10 sm:px-8">
          <div className="flex items-center gap-2 text-sm text-ink-faint">
            <BrandMark size={22} /> © {new Date().getFullYear()} LeadX
          </div>
          <div className="flex flex-wrap gap-5">
            <a href="#pricing" className="text-sm text-ink-muted hover:text-ink">Pricing</a>
            <a href="#security" className="text-sm text-ink-muted hover:text-ink">Security</a>
            <Link href="/privacy" className="text-sm text-ink-muted hover:text-ink">Privacy</Link>
            <Link href="/terms" className="text-sm text-ink-muted hover:text-ink">Terms</Link>
            <Link href="/dpa" className="text-sm text-ink-muted hover:text-ink">DPA</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
