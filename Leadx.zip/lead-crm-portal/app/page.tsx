import Link from "next/link";
import { BrandMark } from "@/components/ui/BrandMark";
import { Icon } from "@/components/ui/Icon";

const FEATURES = [
  { icon: "radar" as const, title: "Exclusive", body: "Territory and assignment controls reduce duplicate delivery across every workspace." },
  { icon: "sparkles" as const, title: "Why now", body: "Review, booking, website and intent signals explain the exact angle to call on." },
  { icon: "check" as const, title: "Quality guarantee", body: "Dead or invalid contacts return a lead credit automatically through the SLA workflow." },
];

export default function Landing() {
  return (
    <main className="min-h-screen bg-surface text-ink">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="flex items-center gap-2.5">
          <BrandMark size={34} />
          <span className="brand-wordmark">LeadX</span>
        </Link>
        <nav className="flex items-center gap-5 text-sm font-medium text-ink-muted">
          <Link href="/pricing" className="hidden hover:text-ink sm:inline">Pricing</Link>
          <Link href="/security" className="hidden hover:text-ink sm:inline">Security</Link>
          <Link href="/login" className="btn-secondary px-3.5 py-2 text-sm">Sign in</Link>
        </nav>
      </header>

      <section className="relative mx-auto max-w-6xl overflow-hidden px-5 py-16 sm:px-8 md:py-24">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 -top-24 h-[480px] opacity-70"
          style={{
            backgroundImage:
              "radial-gradient(55% 60% at 20% 20%, rgb(var(--brand) / .16), transparent 65%), radial-gradient(40% 45% at 85% 10%, rgb(var(--accent) / .14), transparent 65%)",
          }}
        />
        <div className="relative max-w-3xl">
          <span className="label inline-flex items-center gap-1.5 rounded-full border border-line bg-surface-2 px-3 py-1.5 text-brand-700 dark:text-brand-300">
            <Icon name="radar" className="h-3 w-3" /> Local lead intelligence
          </span>
          <h1 className="mt-5 text-4xl font-bold leading-[1.05] tracking-tight text-ink sm:text-6xl md:text-7xl">
            Exclusive local leads. Verified. Explained. Delivered.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-ink-muted">
            LeadX finds local businesses, verifies the contact data, surfaces the reason to reach out now,
            and drops every lead straight into the CRM workflow your team already runs.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/sample" className="btn-primary px-5 py-3 text-sm">Get a free sample pack</Link>
            <Link href="/pricing" className="btn-secondary px-5 py-3 text-sm">See pricing</Link>
            <Link href="/login" className="btn-ghost px-5 py-3 text-sm">Sign in</Link>
          </div>
        </div>

        <div className="relative mt-16 grid gap-4 sm:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="data-card-hover card-pad">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                <Icon name={f.icon} className="h-5 w-5" />
              </span>
              <b className="mt-4 block text-ink">{f.title}</b>
              <p className="mt-2 text-sm leading-6 text-ink-muted">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-10 sm:px-8">
          <div className="flex items-center gap-2 text-sm text-ink-faint">
            <BrandMark size={22} /> © {new Date().getFullYear()} LeadX
          </div>
          <div className="flex flex-wrap gap-5">
            <Link href="/privacy" className="text-sm text-ink-muted hover:text-ink">Privacy</Link>
            <Link href="/terms" className="text-sm text-ink-muted hover:text-ink">Terms</Link>
            <Link href="/dpa" className="text-sm text-ink-muted hover:text-ink">DPA</Link>
            <Link href="/security" className="text-sm text-ink-muted hover:text-ink">Security</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
