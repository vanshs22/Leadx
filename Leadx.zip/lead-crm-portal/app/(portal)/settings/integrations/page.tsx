"use client";

import { useEffect, useMemo, useState } from "react";
import { crmIntegrations } from "@/lib/api";
import { getTenantId } from "@/lib/tenant";

const BYOK_FIELDS: Record<string, Record<string,string>> = {
  gmail:{access_token:""}, google_calendar:{access_token:""}, google_drive:{access_token:""}, google_sheets:{access_token:""},
  outlook:{access_token:""}, microsoft_calendar:{access_token:""}, microsoft_teams:{access_token:""}, slack:{access_token:""},
  hubspot:{access_token:""}, salesforce:{access_token:"",instance_url:"https://your-domain.my.salesforce.com"},
  pipedrive:{api_key:""}, close:{api_key:""}, calcom:{api_key:""}, notion:{api_key:""}, airtable:{api_key:""}, asana:{api_key:""}, clickup:{api_key:""}, linear:{api_key:""},
  webhook:{url:"https://example.com/webhook",secret:""}, zapier:{url:"https://hooks.zapier.com/..."}, make:{url:"https://hook.us1.make.com/..."}, n8n:{url:"https://example.com/webhook"}, generic_http:{url:"https://api.example.com/health",headers:"{}"}
};

export default function IntegrationsPage(){
  const [catalog,setCatalog]=useState<any[]>([]); const [connections,setConnections]=useState<any[]>([]);
  const [provider,setProvider]=useState("gmail"); const [mode,setMode]=useState<"platform"|"byok">("platform");
  const [name,setName]=useState(""); const [config,setConfig]=useState<Record<string,string>>({}); const [query,setQuery]=useState("");
  const [busy,setBusy]=useState(false); const [msg,setMsg]=useState("");
  const tenant=getTenantId();
  async function load(){ const r=await crmIntegrations.catalog(tenant); setCatalog(r.providers||[]); setConnections(r.connections||[]); }
  useEffect(()=>{load().catch(e=>setMsg(e.message));},[]);
  const selected=useMemo(()=>catalog.find(x=>x.provider===provider),[catalog,provider]);
  const filtered=catalog.filter(p=>`${p.name} ${p.purpose} ${p.category}`.toLowerCase().includes(query.toLowerCase()));
  function select(p:any){setProvider(p.provider);setMode("platform");setConfig(BYOK_FIELDS[p.provider]||{});setName("");setMsg("");}
  async function connect(){
    setBusy(true);setMsg("");
    try{
      if(mode==="platform"){
        const r=await crmIntegrations.oauthStart(tenant,provider); window.location.href=r.authorization_url; return;
      }
      const parsed={...config}; if(typeof parsed.headers==="string"){try{parsed.headers=JSON.parse(parsed.headers as string);}catch{throw new Error("Headers must be valid JSON")}}
      await crmIntegrations.saveConnection(tenant,{provider,config:parsed,metadata:{source:"user_byok"},connection_name:name||undefined,auth_mode:"byok"});
      await load(); setMsg("BYOK connection saved securely.");
    }catch(e:any){setMsg(e.message||"Connection failed");}finally{setBusy(false);}
  }
  async function test(id:string){setBusy(true);setMsg("");try{const r=await crmIntegrations.testConnection(tenant,id);setMsg(r.ok?"Connection healthy ✓":r.error||r.message||"Connection failed");await load();}catch(e:any){setMsg(e.message)}finally{setBusy(false)}}
  return <div className="page max-w-7xl space-y-5">
    <header className="hero-panel p-6 md:p-8"><div className="label text-brand-700 dark:text-brand-300">LeadX Connect</div><h1 className="mt-2 page-title">Bring your revenue stack into LeadX.</h1><p className="page-sub">Connect your own accounts or use LeadX-managed OAuth apps. Credentials stay server-side and are never rendered back to the browser.</p></header>
    {msg&&<div className="rounded-xl border border-line bg-surface-2 px-4 py-3 text-sm text-ink-muted">{msg}</div>}
    <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr]">
      <section className="card-pad">
        <div className="flex items-center justify-between gap-3"><h2 className="text-sm font-semibold">Connector catalog</h2><span className="pill bg-brand-50 text-brand-800 dark:bg-brand-500/15 dark:text-brand-200">{catalog.length} connectors</span></div>
        <input className="input mt-4" placeholder="Search connectors…" value={query} onChange={e=>setQuery(e.target.value)}/>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">{filtered.map(p=><button aria-label="Action" key={p.provider} onClick={()=>select(p)} className={`rounded-xl border p-3 text-left transition ${provider===p.provider?"border-brand-400 bg-brand-50/70 dark:bg-brand-500/10":"border-line bg-surface-2 hover:border-brand-300"}`}><div className="font-semibold text-sm text-ink">{p.name}</div><div className="mt-1 text-xs text-ink-muted">{p.purpose}</div><div className="mt-2 text-[10px] uppercase tracking-wide text-ink-faint">{p.category} · {p.auth}</div></button>)}</div>
      </section>
      <section className="card-pad">
        <div className="label">Connect account</div><h2 className="mt-1 text-lg font-semibold text-ink">{selected?.name||provider}</h2>
        <div className="mt-4 grid grid-cols-2 rounded-xl border border-line p-1 bg-surface-2"><button aria-label="Action" onClick={()=>setMode("platform")} className={`rounded-lg px-3 py-2 text-sm ${mode==="platform"?"bg-brand-400 text-black":"text-ink-muted"}`}>LeadX OAuth</button><button aria-label="Action" onClick={()=>{setMode("byok");setConfig(BYOK_FIELDS[provider]||{})}} className={`rounded-lg px-3 py-2 text-sm ${mode==="byok"?"bg-brand-400 text-black":"text-ink-muted"}`}>My BYOK</button></div>
        {mode==="byok"&&<label className="mt-4 block text-xs font-semibold text-ink-muted">Connection name<input className="input mt-1" placeholder="e.g. Sales Gmail" value={name} onChange={e=>setName(e.target.value)}/></label>}
        {mode==="byok"&&<div className="mt-4 space-y-3">{Object.entries(config).map(([k,v])=><label key={k} className="block text-xs font-semibold text-ink-muted">{k.replace(/_/g," ")}<input className="input mt-1" type={k.includes("token")||k.includes("key")||k.includes("secret")?"password":"text"} value={v} onChange={e=>setConfig({...config,[k]:e.target.value})}/></label>)}</div>}
        <button aria-label="Action" className="btn-primary mt-4 w-full" disabled={busy} onClick={connect}>{busy?"Connecting…":mode==="platform"?`Connect ${selected?.name||provider}`:"Save encrypted BYOK connection"}</button>
        <p className="mt-3 text-[11px] leading-4 text-ink-faint">A workspace may keep multiple accounts for the same provider. OAuth uses the provider's official authorization flow; BYOK encrypts the supplied credential server-side.</p>
      </section>
    </div>
    <section className="card-pad"><div className="flex items-center justify-between"><h2 className="text-sm font-semibold">Connected accounts</h2><span className="text-xs text-ink-faint">{connections.length} connected</span></div><div className="mt-3 space-y-2">{connections.length?connections.map(c=><div key={c.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface-3/50 p-3"><div><div className="font-semibold text-sm text-ink">{c.connection_name||catalog.find(x=>x.provider===c.provider)?.name||c.provider}</div><div className="text-xs text-ink-muted">{catalog.find(x=>x.provider===c.provider)?.name||c.provider} · {c.auth_mode||"platform"} · {c.status}</div></div><button aria-label="Action" className="btn-secondary" disabled={busy} onClick={()=>test(c.id)}>Test connection</button></div>):<p className="text-sm text-ink-muted">No connections yet.</p>}</div></section>
  </div>
}
