# LeadX Product UI / Brand System

LeadX is a serious B2B lead-intelligence product, not an AI demo. The interface should feel closer to a mature revenue workspace than a generative-AI landing page.

## Product principles
- **Dense when useful, quiet when not.** Data tables and pipeline views can be information-rich; navigation and chrome stay restrained.
- **One primary action per surface.** Secondary actions are visually quieter.
- **Hierarchy before decoration.** Typography, spacing and alignment communicate state before gradients, glows or illustrations.
- **Evidence over ornament.** Research/source/freshness metadata should look like product data, not AI magic.
- **Progressive disclosure.** Keep advanced controls behind details, filters, drawers or settings rather than exposing every capability at once.
- **Predictable navigation.** Group work into Workspace, Engage, Measure and Settings; remove long explanatory nav subtitles.

## Competitive inspiration translated for LeadX
- **Clay:** modular workflows, powerful data operations, clear usage concepts. LeadX borrows the modularity but keeps client-facing pricing much simpler.
- **Apollo:** prospecting-first information architecture, fast search-to-action flow and dense records. LeadX uses this discipline without copying its visual identity.
- **HubSpot:** mature object navigation, clear lifecycle/status language, billing that explains what is included. LeadX adopts the clarity while keeping the product narrower.
- **Linear:** restrained chrome, strong typography, keyboard-friendly interaction and low visual noise. LeadX follows the same principle for everyday workspace surfaces.

## Visual language
- **Ink / warm neutral surfaces:** default foundation.
- **Deep teal:** product identity, primary action, selected navigation.
- **Tangerine:** scarce signal color for opportunity/attention states.
- Avoid rainbow gradients, excessive glassmorphism, decorative grid backgrounds, oversized glowing blobs and card-per-metric layouts.
- Cards are used for meaningful grouping, not every paragraph.
- Borders are subtle; shadows are shallow.
- Use rounded corners consistently but avoid excessive pill shapes.

## Brand mark
The LeadX mark (`components/ui/BrandMark.tsx`) is a deep-teal rounded-square `LX` lockup with a tangerine signal dot. It replaces every ad-hoc `<span className="brand-mark">LX</span>` copy with one component so the gradient, radius and dot stay identical everywhere (sidebar, auth screens, marketing header, error/404 pages).

## Icon system
`components/ui/Icon.tsx` is a single inline-SVG icon set. It replaces the Unicode glyphs (⌂ ◷ ◈ ✦ ⌕ ▤ ▥ …) that previously stood in for navigation icons — those rendered inconsistently across operating systems and fonts and were the clearest "placeholder UI" signal in the product. Add new icons to the `PATHS` map; never reach for an emoji or Unicode symbol as an icon.

## Typography
Inter (text), Space Grotesk (display/headings) and IBM Plex Mono (numeric/tabular data) are loaded with `next/font/google` in `app/layout.tsx`. Fonts are self-hosted at build time — no runtime request to Google Fonts and no flash of unstyled text. Previously the CSS referenced these families by name without ever loading them, so every browser silently rendered the OS default UI font instead.

## Pricing / checkout
Pricing is outcome-oriented: qualified leads per month and research capacity, not internal provider credits. Growth is the highlighted self-serve plan. Checkout explains the selected plan, billing interval, included capacity and Stripe handoff before payment.
