# Reports Runtime Fix — 2026-09-28

## Fixed
- `/crm/{tenant_id}/reports/summary` is protected by a runtime route contract fallback.
- The report summary no longer selects `has_booking` from `crm_lead_cards`; that field is owned by enrichment and was causing PostgREST failures.
- Report summary falls back from `crm_lead_cards` to `lead_assignments` + `leads_global`.
- Deal reporting has a protected runtime fallback and returns a valid zero-data shape if the optional revenue-report implementation is unavailable.
- Dashboard falls back from an empty/stale CRM view to `lead_assignments` instead of showing false all-zero KPIs.
- Pipeline falls back to `lead_assignments` and `leads_global`, creates default columns when stages are absent, and groups by stable stage slug.
- Health route contract now explicitly checks `reports` and `deal_reports`.
- Runtime restart script verifies both report routes.
- Reports page keeps a tenant-scoped session snapshot visible while the backend is restarting.

## Verification
- Python compilation: PASS
- Full pytest suite: PASS (56 tests)
- FastAPI route inspection: PASS for dashboard, leads, pipeline, reports, deal reports, support
- Frontend TypeScript production validation was not run because the extracted package has no complete `node_modules` installation in this environment.
