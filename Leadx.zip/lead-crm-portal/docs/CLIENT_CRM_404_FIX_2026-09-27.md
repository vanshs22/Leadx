# Client/CRM page 404 fix — 2026-09-27

## Root cause

The current Next.js portal uses App Router route groups `(portal)` and `(admin)`. Route groups do not appear in the URL, so client pages are served at `/dashboard`, `/leads`, `/pipeline`, `/companies`, etc.

Older links/bookmarks can still use `/client/*`, `/portal/*`, or `/crm/*`. Those paths are not actual Next routes and returned the Next 404 page even though the underlying client CRM pages existed.

The backend CRM API was checked separately: the `/crm/*` API routers are mounted by `app/app_service.py`, so this specific browser-page failure is not caused by missing CRM API route registration.

## Fix

`frontend/middleware.ts` now redirects known legacy browser prefixes to the current portal paths. `/backend/*` is explicitly excluded so API proxy traffic is untouched.

The compatibility middleware is included in both the canonical frontend and the `leadx_release` copy contained in this archive.
