# LeadX Leads/Pipeline Runtime & Performance Fix — 2026-09-28

## Root-cause analysis

### 1. Leads/Pipeline 404
The browser pages themselves existed and their API client paths were correct:
- `GET /crm/{tenant_id}/leads`
- `GET /crm/{tenant_id}/pipeline`

The packaged FastAPI application also registers both routes. Therefore the screenshot's `RECOVERABLE_API_404` indicates the browser was reaching a FastAPI instance that did not expose the expected CRM route contract (stale/partial runtime or failed optional router mount), not a missing Next page.

The frontend previously converted a real API 404 into a generic recoverable error and raced another base, producing the confusing:
`RECOVERABLE_API_404 | RECOVERABLE_API_404`.

A runtime route-contract safety net has now been added for Leads and Pipeline, matching the existing Dashboard safety net. Startup logs also report whether Dashboard, Leads, and Pipeline are mounted.

### 2. Leads API was blocking the FastAPI event loop
`list_leads()` used synchronous Supabase calls directly inside an `async` endpoint. A slow database/view/count query could block unrelated requests for the process.

Fixed by executing the complete synchronous query/fallback path in `asyncio.to_thread()`.

### 3. Pipeline API was also blocking the event loop
`pipeline_board()` had the same synchronous Supabase behavior and fetched `select("*")` for every pipeline card.

Fixed with:
- `asyncio.to_thread()`
- a short tenant-scoped cache
- explicit pipeline/card columns instead of `select("*")`
- bounded fallback assignment read

### 4. Repeated navigation/realtime reads
The frontend already had a 15-second in-memory GET cache and in-flight request deduplication. That is retained.

Added dashboard idle-prefetch for Leads and Pipeline. Once the Home page is open, the two core datasets are warmed in the existing API cache during browser idle time. Navigating to Leads/Pipeline can therefore render from memory instead of waiting for another DB round-trip.

### 5. Search typing could generate excessive reads
The Leads page previously called the loader on every search-state change. A 220ms debounce now prevents a request for every keystroke.

### 6. Data remains correct
The existing tenant JWT + membership verification remains in place. No client-side direct database bypass was added. Cache keys remain tenant/token scoped on the browser side; backend caches are tenant/filter scoped.

## Changes

### Backend
- 5s Leads response cache keyed by tenant + filters + pagination.
- 5s Pipeline response cache keyed by tenant.
- Leads query work moved to a worker thread.
- Pipeline query work moved to a worker thread.
- Pipeline selects only fields needed by the board.
- Runtime protected route safety nets for Leads and Pipeline.
- Startup route-contract logging.

### Frontend
- Idle-prefetch Leads + Pipeline after Dashboard shell is ready.
- 220ms Leads search debounce.
- Existing GET cache/in-flight deduplication retained.
- Existing auth/session caching retained.

## Validation
- Python compilation: PASS
- Critical runtime/support/schema tests: 9/9 PASS
- Full backend pytest suite: 56/56 PASS
- Route contract: `/crm/me`, `/crm/{tenant_id}/dashboard`, `/crm/{tenant_id}/leads`, `/crm/{tenant_id}/pipeline` all present.
- Full Next production build was not run because `node_modules` is not present in the package environment and registry access is unavailable here. No claim of a frontend build pass is made.

## Restart
Restart FastAPI from the `lead-engine-v2` directory and restart Next from `lead-crm-portal/frontend`. The route-contract changes do not affect the database schema.
