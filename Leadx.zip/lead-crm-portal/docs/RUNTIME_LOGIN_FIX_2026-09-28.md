# Runtime login / workspace fix — 2026-09-28

## Root cause
The previous delivery contained the updated frontend but did not include the `lead-engine-v2` backend source. The Codespaces FastAPI process therefore continued serving an older build without `GET /crm/me`, producing repeated HTTP 404 responses after successful Supabase login.

## Fix
- Full `lead-engine-v2` backend is included in this delivery.
- `GET /crm/me` is registered directly on `app.app_service` as a runtime bootstrap guarantee and uses the same `require_tenant` authentication/membership resolver.
- The existing CRM router `/crm/me` remains in place; both are protected and return the same tenant context.
- Frontend races the same-origin `/backend` route and the Codespaces forwarded `:8000` route instead of waiting serially.
- Auth hot path uses pooled async HTTP, cached JWT/JWKS verification, and short membership caching.
- No database reset or schema migration is required.

## Required restart
Stop the old FastAPI process before starting the backend from this package. Hot reload cannot repair a process that is serving an older source tree.

```bash
cd /workspaces/LeadX/lead-engine-v2
python -m py_compile app/app_service.py
uvicorn app.app_service:app --host 0.0.0.0 --port 8000 --reload
```

Verify before opening the client portal:

```bash
curl -i http://127.0.0.1:8000/crm/me
```

A **401/403 is expected without an Authorization header**. A **404 means the wrong backend process/source tree is still running**.

Then restart the frontend:

```bash
cd /workspaces/LeadX/lead-crm-portal/frontend
npm install
npm run dev
```

## Verification performed on the packaged source
- Python compilation: PASS
- FastAPI route inspection: `/crm/me` present
- Unauthenticated `/crm/me`: HTTP 401 (correct; proves route exists)
- Existing backend test suite from the previous update: 56/56 passing
- Frontend production build: not run to completion in the packaging environment because the local `node_modules` installation is incomplete (`next` executable unavailable). `node_modules` is intentionally excluded from the ZIP; run `npm install` in Codespaces.
