import { test, expect } from "@playwright/test";

test("LeadX critical browser flow", async ({ page }) => {
  const base = process.env.PLAYWRIGHT_BASE_URL;
  test.skip(!base, "Set PLAYWRIGHT_BASE_URL for staging smoke tests");
  await page.goto(`${base}/signup`);
  await expect(page.getByRole("heading", { name: /create your account/i })).toBeVisible();
  await page.goto(`${base}/login`);
  await expect(page.getByRole("heading", { name: /welcome back/i })).toBeVisible();
  await page.goto(`${base}/admin/login`);
  await expect(page.getByRole("heading", { name: /admin access/i })).toBeVisible();
});
