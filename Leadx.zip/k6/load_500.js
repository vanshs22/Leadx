import http from 'k6/http';
import { check, sleep } from 'k6';

const base = (__ENV.LEADX_URL || '').replace(/\/$/, '');
const tenant = __ENV.LEADX_TENANT_ID || '';
const tokenFile = __ENV.LEADX_TOKEN_FILE || '';
const path = __ENV.LEADX_LOAD_PATH || `/crm/${tenant}/dashboard`;
const tokens = tokenFile
  ? open(tokenFile).split(/\r?\n/).map((value) => value.trim()).filter(Boolean)
  : [];

export const options = {
  vus: Number(__ENV.VUS || 500),
  duration: __ENV.DURATION || '60s',
  thresholds: {
    http_req_duration: ['p(95)<800', 'p(99)<1500'],
    http_req_failed: ['rate<0.01'],
    checks: ['rate>0.99'],
  },
};

export function setup() {
  if (!base) throw new Error('LEADX_URL is required');
  if (!tenant) throw new Error('LEADX_TENANT_ID is required');
  if (tokens.length !== 500) {
    throw new Error(`LEADX_TOKEN_FILE must contain exactly 500 non-empty tokens; found ${tokens.length}`);
  }
  return { base, tenant, tokens };
}

export default function (data) {
  const token = data.tokens[(__VU - 1) % data.tokens.length];
  const response = http.get(`${data.base}${path.startsWith('/') ? path : `/${path}`}`, {
    headers: { Authorization: `Bearer ${token}` },
    tags: { endpoint: path },
  });
  check(response, {
    'protected endpoint returns 2xx': (res) => res.status >= 200 && res.status < 300,
    'not unauthorized': (res) => res.status !== 401 && res.status !== 403,
    'not rate limited': (res) => res.status !== 429,
  });
  sleep(Number(__ENV.THINK_SECONDS || 1));
}
