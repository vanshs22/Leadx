# Amazon SES — your account, client domains (automated)

## Payment (read this first)

| Question | Answer |
|----------|--------|
| Upfront SES fee? | **No** on **Essentials** |
| Pay before sending? | **No** — pay-as-you-go for usage |
| When billed? | AWS bills **monthly** for that month’s usage (card on file) |
| Cost to *verify* a domain? | **$0** |
| Cost for SES API (CreateEmailIdentity, etc.)? | **$0** (no per-call fee for that) |
| What you pay | **~$0.16 per 1,000 emails** sent (+ tiny $/GB data) on Essentials |

You add a payment method to AWS once. You are charged later for **actual sends**, not for linking domains.

**Sandbox:** new accounts can only send to verified emails until you request **production access** (free request, once).

---

## Model

- SES lives in **your** AWS account (you pay).
- Each client **verifies their domain** on your SES via API (no console per client).
- Client only adds **DNS CNAMEs** at their registrar.
- LeadX polls SES until verified → client can bulk-send as `From: them@their-domain.com`.

---

## Env (`lead-engine-v2/.env`)

```bash
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
# optional default from for platform mail
SES_FROM=LeadX <noreply@yourdomain.com>
EMAIL_PROVIDER=cascade
```

IAM needs at least:
`ses:CreateEmailIdentity`, `ses:GetEmailIdentity`, `ses:DeleteEmailIdentity`, `ses:SendEmail`, `ses:SendRawEmail`
(SESv2 equivalent permissions).

---

## API (CRM / tenant-scoped)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/crm/{tenant_id}/email-settings` | Current domain + verified flag + DNS records |
| POST | `/crm/{tenant_id}/email-settings/domain` | Body `{ "domain", "from_email", "from_name" }` → create SES identity + DNS list |
| POST | `/crm/{tenant_id}/email-settings/check` | Refresh verified status from SES |
| POST | `/crm/{tenant_id}/email/bulk` | Existing bulk; uses tenant From when domain_verified |

---

## SQL

`sql/020_tenant_email_ses.sql` — also appended to full migration.

---

## Code files

| File | Role |
|------|------|
| `backend/integrations/prod/ses_domain.py` | Create identity, DKIM records, status, send |
| `sql/020_tenant_email_ses.sql` | `tenant_email_settings` |
| CRM routes for email-settings | Wire in app (see changelog) |
| Client Settings → Email | UI for domain + DNS + check status |

---

## Client steps

1. Settings → Email → enter domain + from email  
2. Click **Connect domain** → see CNAME table  
3. Add CNAMEs at registrar  
4. **Check status** until Verified  
5. Bulk email with tags / preview as usual  

Operator does **not** open SES console per client.
