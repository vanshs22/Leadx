"""Rewrite bare `from app import <names>` -> `from fastapi import <names>` (app/__init__.py is empty)."""
import os, re, py_compile

ROOT = r"C:\Users\vansh\Leadx-main\Leadx-main\lead-engine-v2"
EXCLUDE = {"__pycache__", ".venv", "node_modules", ".git"}

rx = re.compile(rb"(from[ \t]+)app([ \t]+import[ \t]+)")
fixed, fails, total = [], [], 0
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EXCLUDE]
    for f in fn:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        d = open(p, "rb").read()
        n, c = rx.subn(rb"\1fastapi\2", d)
        if c:
            open(p, "wb").write(n)
            total += c
            try:
                py_compile.compile(p, doraise=True)
                fixed.append((os.path.relpath(p, ROOT), c))
            except Exception as e:
                open(p, "wb").write(d)
                fails.append((os.path.relpath(p, ROOT), str(e)))

print("SUBS:", total)
for r, c in fixed:
    print("   ", r, c)
for r, e in fails:
    print("COMPILE_FAIL(restored):", r, e)

# Any bare 'from app import' left? (legit ones would import names defined in app/__init__.py, which is empty)
left = []
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EXCLUDE]
    for f in fn:
        if f.endswith(".py"):
            for i, ln in enumerate(open(os.path.join(dp, f), encoding="utf-8", errors="replace")):
                if ln.lstrip().startswith("from app import") or re.match(r"^\s*import app\s*$", ln):
                    left.append((os.path.relpath(os.path.join(dp, f), ROOT), i + 1, ln.strip()))
print("REMAINING_BARE:", len(left))
for r, i, s in left[:10]:
    print("   ", r + ":" + str(i), s)
