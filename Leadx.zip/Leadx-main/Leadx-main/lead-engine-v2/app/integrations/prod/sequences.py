"""
Follow-up sequences: define N steps (subject/body/day-offset), enroll
selected or all leads, and a cron-callable process_due_sends() that
advances every active enrollment whose next_send_at has passed. Stops
automatically on unsubscribe (checked in email_outreach.send_to_lead) or
on a positive/negative reply (checked here before each step).
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from app.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.sequences")

# tenant_id -> from_email, populated per process_due_sends pass.
_FROM_CACHE: dict[str, str] = {}


def _sb():
    return get_supabase()


async def create_sequence(tenant_id: str, name: str, steps: list[dict]) -> dict:
    """steps: [{subject, body_html, body_text?, delay_days}, ...] — step 1 delay_days is
    days after enrollment; later steps are days after the previous step sent."""
    sb = _sb()
    seq = sb.table("email_sequences").insert({"tenant_id": tenant_id, "name": name}).execute().data[0]
    rows = [
        {
            "sequence_id": seq["id"],
            "step_number": i + 1,
            "delay_days": s.get("delay_days", 0 if i == 0 else 3),
            "subject": s["subject"],
            "body_html": s["body_html"],
            "body_text": s.get("body_text", ""),
        }
        for i, s in enumerate(steps)
    ]
    if rows:
        sb.table("email_sequence_steps").insert(rows).execute()
    return seq


async def enroll_leads(tenant_id: str, sequence_id: str, assignment_ids: list[str]) -> dict:
    sb = _sb()
    steps = (
        sb.table("email_sequence_steps")
        .select("step_number, delay_days")
        .eq("sequence_id", sequence_id)
        .order("step_number")
        .execute()
        .data
        or []
    )
    if not steps:
        return {"ok": False, "error": "sequence_has_no_steps"}
    first_delay = steps[0]["delay_days"]
    next_send = (datetime.now(timezone.utc) + timedelta(days=first_delay)).isoformat()

    enrolled, skipped = 0, 0
    for aid in assignment_ids:
        try:
            sb.table("email_sequence_enrollments").upsert(
                {
                    "tenant_id": tenant_id,
                    "sequence_id": sequence_id,
                    "assignment_id": aid,
                    "current_step": 0,
                    "status": "active",
                    "next_send_at": next_send,
                },
                on_conflict="sequence_id,assignment_id",
            ).execute()
            enrolled += 1
        except Exception:
            logger.warning("enroll failed for assignment %s", aid, exc_info=True)
            skipped += 1
    return {"ok": True, "enrolled": enrolled, "skipped": skipped}


async def _has_disqualifying_reply(tenant_id: str, assignment_id: str) -> bool:
    rows = (
        _sb()
        .table("email_replies")
        .select("category")
        .eq("assignment_id", assignment_id)
        .in_("category", ["positive", "negative", "opt_out"])
        .limit(1)
        .execute()
        .data
    )
    return bool(rows)


async def _lead_for_assignment(assignment_id: str) -> dict:
    """Minimal lead row for the timezone gate — state/city/address only."""
    try:
        a = (
            _sb()
            .table("lead_assignments")
            .select("lead_id")
            .eq("id", assignment_id)
            .limit(1)
            .execute()
            .data
            or []
        )
        if not a:
            return {}
        rows = (
            _sb()
            .table("leads_global")
            .select("id, city, state, address, full_address")
            .eq("id", a[0]["lead_id"])
            .limit(1)
            .execute()
            .data
            or []
        )
        return rows[0] if rows else {}
    except Exception:
        return {}


def _defer(enrollment_id: str, until: str, reason: str) -> None:
    """Push next_send_at forward instead of sending. The step stays
    active and is retried at `until` — this is how the daily domain cap
    spills tomorrow's overflow into tomorrow."""
    try:
        _sb().table("email_sequence_enrollments").update(
            {"next_send_at": until, "deferred_reason": reason}
        ).eq("id", enrollment_id).execute()
    except Exception:
        logger.warning("defer failed for enrollment %s", enrollment_id, exc_info=True)


async def process_due_sends(limit: int = 200) -> dict:
    """Cron/worker-callable. Every send passes the send_policy gates
    (business hours in the recipient's timezone, per-domain daily cap,
    minimum cross-channel touch gap) and is jittered so a batch of due
    steps doesn't fire as one visible blast."""
    import asyncio

    from app.integrations.prod import send_policy
    from app.integrations.prod.email_outreach import send_to_lead

    sb = _sb()
    now = datetime.now(timezone.utc).isoformat()
    due = (
        sb.table("email_sequence_enrollments")
        .select("id, tenant_id, sequence_id, assignment_id, current_step")
        .eq("status", "active")
        .lte("next_send_at", now)
        .limit(limit)
        .execute()
        .data
        or []
    )

    sent, stopped, errors, deferred = 0, 0, 0, 0
    defer_reasons: dict[str, int] = {}
    for enr in due:
        try:
            if await _has_disqualifying_reply(enr["tenant_id"], enr["assignment_id"]):
                sb.table("email_sequence_enrollments").update({"status": "stopped_reply"}).eq("id", enr["id"]).execute()
                stopped += 1
                continue

            steps = (
                sb.table("email_sequence_steps")
                .select("*")
                .eq("sequence_id", enr["sequence_id"])
                .order("step_number")
                .execute()
                .data
                or []
            )
            next_step_num = enr["current_step"] + 1
            step = next((s for s in steps if s["step_number"] == next_step_num), None)
            if not step:
                sb.table("email_sequence_enrollments").update({"status": "completed"}).eq("id", enr["id"]).execute()
                continue

            # Pre-flight the policy so a blocked send costs one cheap
            # check instead of a full render + provider round-trip.
            lead = await _lead_for_assignment(enr["assignment_id"])
            gate = send_policy.can_send_now(
                enr["tenant_id"],
                lead,
                assignment_id=enr["assignment_id"],
                from_email=_from_email(enr["tenant_id"]),
                respect_hours=True,
            )
            if not gate["ok"]:
                _defer(enr["id"], gate["retry_after"], gate["reason"])
                deferred += 1
                defer_reasons[gate["reason"]] = defer_reasons.get(gate["reason"], 0) + 1
                continue

            # Send-time spreading: without this, every step due at the
            # top of the hour leaves in the same second.
            await asyncio.sleep(send_policy.jitter_seconds())

            result = await send_to_lead(
                enr["tenant_id"],
                enr["assignment_id"],
                step["subject"],
                step["body_html"],
                step.get("body_text") or "",
                enforce_policy=True,
            )
            if result.get("deferred"):
                _defer(enr["id"], result.get("retry_after") or now, result.get("error") or "deferred")
                deferred += 1
                continue
            if not result.get("ok"):
                errors += 1
                # Don't retry forever on a hard failure (bad address etc.) — stop, don't loop.
                if result.get("error") in ("no_email_on_lead", "recipient_opted_out"):
                    sb.table("email_sequence_enrollments").update({"status": "stopped_optout"}).eq("id", enr["id"]).execute()
                    continue

            sent += 1
            following = next((s for s in steps if s["step_number"] == next_step_num + 1), None)
            update = {
                "current_step": next_step_num,
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "deferred_reason": None,
            }
            if following:
                update["next_send_at"] = (
                    datetime.now(timezone.utc) + timedelta(days=following["delay_days"])
                ).isoformat()
                update["status"] = "active"
            else:
                update["status"] = "completed"
                update["next_send_at"] = None
            sb.table("email_sequence_enrollments").update(update).eq("id", enr["id"]).execute()
        except Exception:
            logger.warning("process_due_sends failed for enrollment %s", enr.get("id"), exc_info=True)
            errors += 1

    return {
        "processed": len(due),
        "sent": sent,
        "stopped": stopped,
        "deferred": deferred,
        "defer_reasons": defer_reasons,
        "errors": errors,
    }


def _from_email(tenant_id: str) -> str:
    """Cached per run — one lookup per tenant, not per enrollment."""
    if tenant_id in _FROM_CACHE:
        return _FROM_CACHE[tenant_id]
    from app.integrations.prod.email_outreach import tenant_from_email

    _FROM_CACHE[tenant_id] = tenant_from_email(tenant_id)
    return _FROM_CACHE[tenant_id]

