"""
Worker process — runs queued jobs. This is what makes the API fast.

  python -m app.worker                    # all job kinds
  python -m app.worker --kinds pipeline.run,email.bulk
  python -m app.worker --concurrency 4

Run at least one worker alongside uvicorn. Nothing long-running executes
in the web process any more, so a statewide pipeline run for one tenant
can't block another tenant's dashboard.

Scaling: start more worker processes. Claiming is a CAS on the job row,
so N workers never double-run a job. Dedicate a worker to a kind
(--kinds) when you want heavy pipeline runs isolated from quick sends.

It also runs two housekeeping passes on an interval: reaping jobs whose
worker died mid-run, and enqueuing the cron-style kinds (sequence
processing, scheduled discovery, alert checks, lead re-verification) so
those don't depend on an external cron hitting an HTTP endpoint — the
failure mode that has already bitten this project once.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import socket
import time
from datetime import datetime, timezone
from pathlib import Path

try:
    from dotenv import load_dotenv

    _env_file = Path(__file__).resolve().parents[1] / ".env"
    load_dotenv(_env_file if _env_file.is_file() else None, override=True)
except ImportError:
    pass

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("lead_engine.worker")

POLL_INTERVAL = float(os.getenv("WORKER_POLL_SECONDS", "3"))
REAP_INTERVAL = float(os.getenv("WORKER_REAP_SECONDS", "300"))
# Internal cron: how often to enqueue the recurring kinds.
SEQUENCE_INTERVAL = float(os.getenv("WORKER_SEQUENCE_SECONDS", "900"))  # 15 min
ALERTS_INTERVAL = float(os.getenv("WORKER_ALERTS_SECONDS", "3600"))  # hourly
# Scheduled discovery. The tick only *enqueues* due campaign_schedules rows, so
# it is cheap; 5 minutes bounds how late a schedule can fire.
SCHEDULES_INTERVAL = float(os.getenv("WORKER_SCHEDULES_SECONDS", "300"))
# leads.reverify and reviews.mine were registered handlers that nothing ever
# scheduled — /admin/cron-audit tracked their freshness and always showed them
# stale, because the only way to run them was a manual admin enqueue.
REVERIFY_INTERVAL = float(os.getenv("WORKER_REVERIFY_SECONDS", "86400"))  # daily

_shutdown = asyncio.Event()


def _worker_id() -> str:
    return f"{socket.gethostname()}:{os.getpid()}"


async def _run_one(job: dict) -> None:
    from app.integrations.prod import jobs

    jid = job["id"]
    kind = job.get("kind")
    started = time.monotonic()
    logger.info("job start id=%s kind=%s tenant=%s attempt=%s", jid, kind, job.get("tenant_id"), job.get("attempts"))
    try:
        result = await jobs.run_job(job)
        jobs.complete(jid, result)
        logger.info("job done id=%s kind=%s in %.1fs", jid, kind, time.monotonic() - started)
    except Exception as e:
        logger.exception("job failed id=%s kind=%s: %s", jid, kind, e)
        jobs.fail(
            jid,
            f"{type(e).__name__}: {e}",
            attempts=int(job.get("attempts") or 1),
            max_attempts=int(job.get("max_attempts") or 3),
        )


async def _housekeeping() -> None:
    """Reaper + internal cron. Runs in the worker rather than relying on
    an external scheduler calling HTTP endpoints."""
    from app.integrations.prod import jobs

    # kind -> (interval seconds, payload). enqueue_unique with no tenant_id means
    # each of these is globally single-flight: a slow run delays the next tick
    # rather than stacking duplicates behind it.
    cron: list[tuple[str, float, dict]] = [
        ("sequences.process_due", SEQUENCE_INTERVAL, {"limit": 200}),
        ("alerts.run", ALERTS_INTERVAL, {}),
        ("schedules.tick", SCHEDULES_INTERVAL, {}),
        ("leads.reverify", REVERIFY_INTERVAL, {}),
    ]
    last: dict[str, float] = {kind: 0.0 for kind, _, _ in cron}
    last_reap = 0.0
    cron_enabled = os.getenv("WORKER_INTERNAL_CRON", "true").lower() in ("1", "true", "yes")
    while not _shutdown.is_set():
        now = time.monotonic()
        if now - last_reap >= REAP_INTERVAL:
            last_reap = now
            jobs.reap_stale()
        if cron_enabled:
            for kind, interval, payload in cron:
                if now - last[kind] < interval:
                    continue
                last[kind] = now
                if jobs.enqueue_unique(kind, payload, created_by="worker_cron"):
                    logger.info("cron: enqueued %s", kind)
        try:
            await asyncio.wait_for(_shutdown.wait(), timeout=30)
        except asyncio.TimeoutError:
            pass


async def _loop(concurrency: int, kinds: list[str] | None) -> None:
    from app.integrations.prod import jobs
    import app.integrations.prod.job_handlers  # noqa: F401  registers handlers

    wid = _worker_id()
    logger.info(
        "worker %s up — concurrency=%d kinds=%s handlers=%s",
        wid,
        concurrency,
        kinds or "all",
        sorted(jobs.HANDLERS),
    )
    running: set[asyncio.Task] = set()
    idle_logged = False

    while not _shutdown.is_set():
        running = {t for t in running if not t.done()}
        if len(running) >= concurrency:
            await asyncio.wait(running, return_when=asyncio.FIRST_COMPLETED)
            continue

        job = await asyncio.to_thread(jobs.claim_next, wid, kinds)
        if job is None:
            if not idle_logged:
                logger.debug("queue empty — polling every %.1fs", POLL_INTERVAL)
                idle_logged = True
            try:
                await asyncio.wait_for(_shutdown.wait(), timeout=POLL_INTERVAL)
            except asyncio.TimeoutError:
                pass
            continue

        idle_logged = False
        running.add(asyncio.create_task(_run_one(job)))

    if running:
        logger.info("draining %d in-flight job(s)…", len(running))
        await asyncio.gather(*running, return_exceptions=True)
    logger.info("worker %s stopped at %s", wid, datetime.now(timezone.utc).isoformat())


async def main_async(concurrency: int, kinds: list[str] | None) -> None:
    await asyncio.gather(_loop(concurrency, kinds), _housekeeping())


def main() -> None:
    ap = argparse.ArgumentParser(description="LeadX job worker")
    ap.add_argument("--concurrency", type=int, default=int(os.getenv("WORKER_CONCURRENCY", "3")))
    ap.add_argument("--kinds", default=os.getenv("WORKER_KINDS", ""), help="comma-separated job kinds; empty = all")
    args = ap.parse_args()
    kinds = [k.strip() for k in args.kinds.split(",") if k.strip()] or None

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    def _stop(*_a):
        logger.info("shutdown signal — finishing in-flight jobs")
        loop.call_soon_threadsafe(_shutdown.set)

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _stop)
        except (ValueError, AttributeError):
            pass  # not available on all platforms / non-main thread

    try:
        loop.run_until_complete(main_async(max(1, args.concurrency), kinds))
    finally:
        loop.close()


if __name__ == "__main__":
    main()
