"use client";

import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { SessionGate } from "@/components/workspace/SessionGate";
import { CommandPalette } from "@/components/CommandPalette";

const PUBLIC_PATHS = ["/login", "/accept-invite"];

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  if (PUBLIC_PATHS.includes(path || "")) {
    return <div className="min-h-screen bg-surface text-ink">{children}</div>;
  }

  return (
    <SessionGate>
      <CommandPalette />
      <div className="flex h-[100dvh] max-h-[100dvh] overflow-hidden bg-surface text-ink">
        <Sidebar />
        <main className="flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto pt-12 md:pt-0">
          {children}
        </main>
      </div>
    </SessionGate>
  );
}
