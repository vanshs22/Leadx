"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { NotificationBell } from "@/components/layout/NotificationBell";
import { ThemeToggle } from "@/components/theme/ThemeProvider";
import { getTenantName, clearTenant } from "@/lib/tenant";
import { signOut } from "@/lib/auth";

const NAV = [
  { href: "/dashboard", label: "Home", hint: "Overview & next steps" },
  // Search disabled for clients — admin delivers leads; re-enable later if needed
  // { href: "/search", label: "Search", hint: "Find leads → email" },
  { href: "/leads", label: "Leads", hint: "Call, email, export" },
  { href: "/sequences", label: "Sequences", hint: "Follow-up automation" },
  { href: "/compose", label: "Write email", hint: "Proven copy + rewrite" },
  { href: "/replies", label: "Replies", hint: "Inbound, categorized" },
  { href: "/notifications", label: "Notifications", hint: "Deliveries & alerts" },
  { href: "/pipeline", label: "Pipeline", hint: "Stages & deals" },
  { href: "/activities", label: "Activity", hint: "Calls & notes" },
  { href: "/reports", label: "Reports", hint: "Wins & quality" },
  { href: "/reports/deals", label: "Deal revenue", hint: "Forecast & attribution" },
  { href: "/import", label: "Import", hint: "Your own customer list" },
  { href: "/team", label: "Team", hint: "Members & roles" },
  { href: "/docs", label: "Docs", hint: "Contracts & invoices" },
  { href: "/settings/email", label: "Email", hint: "Domain & bulk send" },
  { href: "/settings", label: "Settings", hint: "Account & weights" },
];

export function Sidebar() {
  const path = usePathname();
  const router = useRouter();
  // Off-canvas below md: a 240px fixed rail leaves nothing usable on a
  // phone, and reps do check leads from their phone.
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [path]);

  async function handleSignOut() {
    try {
      clearTenant();
      await signOut();
    } catch {
      /* still leave */
    }
    router.replace("/login");
    // hard navigation clears any stuck client state
    if (typeof window !== "undefined") {
      window.location.href = "/login";
    }
  }

  return (
    <>
      {/* Mobile header: hamburger + bell, so neither needs the drawer open. */}
      <div className="fixed inset-x-0 top-0 z-40 flex items-center gap-2 border-b border-line bg-[rgb(var(--sidebar))] px-3 py-2 md:hidden">
        <button
          type="button"
          aria-label="Open navigation"
          onClick={() => setOpen(true)}
          className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-line bg-surface text-ink-muted"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-4 w-4">
            <path d="M4 7h16M4 12h16M4 17h16" />
          </svg>
        </button>
        <span className="text-sm font-semibold text-ink">Lead CRM</span>
        <span className="ml-auto">
          <NotificationBell />
        </span>
      </div>

      {open && (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={() => setOpen(false)}
          className="fixed inset-0 z-40 bg-black/40 md:hidden"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex h-full min-h-0 w-60 shrink-0 flex-col overflow-hidden border-r border-[rgb(var(--sidebar-border))] bg-[rgb(var(--sidebar))] transition-transform md:static md:z-auto md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="shrink-0 border-b border-line px-4 py-5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-sm font-semibold tracking-tight text-ink">Lead CRM</div>
              <div className="mt-0.5 text-xs text-ink-faint">
                {typeof window !== "undefined" ? getTenantName() || "Workspace" : "Workspace"}
              </div>
            </div>
            <span className="hidden md:block">
              <NotificationBell />
            </span>
          </div>
        </div>

        <nav className="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto overscroll-contain p-3">
          {NAV.map((item) => {
            // Exact match for /reports so /reports/deals doesn't light both.
            const active =
              path === item.href ||
              (item.href !== "/reports" && path?.startsWith(item.href + "/"));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={active ? "sidebar-link-active" : "sidebar-link"}
              >
                <div>
                  <div>{item.label}</div>
                  {item.hint ? (
                    <div className="text-[11px] font-normal text-ink-faint">{item.hint}</div>
                  ) : null}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="mt-auto space-y-3 shrink-0 border-t border-line p-3">
          <ThemeToggle className="w-full" />
          <div className="rounded-xl border border-line bg-surface-3/60 p-3 text-[11px] leading-relaxed text-ink-muted">
            New batches land here automatically. Filter <strong className="text-ink">Tier A</strong> first.
          </div>
          <button
            type="button"
            onClick={handleSignOut}
            className="w-full rounded-lg border border-line bg-surface px-3 py-2 text-left text-sm font-medium text-ink hover:bg-surface-2 hover:border-red-500/40 hover:text-red-600 dark:hover:text-red-400"
          >
            Sign out
          </button>
        </div>
      </aside>
    </>
  );
}
