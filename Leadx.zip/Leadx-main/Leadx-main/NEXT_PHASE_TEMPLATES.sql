-- Additional visual designs for every document category.
-- Idempotent and additive: each INSERT is guarded by NOT EXISTS on the
-- template name, so re-running this file is a no-op and nothing already in
-- doc_templates is touched. tenant_id NULL = available to every tenant.
--
-- Run in Supabase SQL editor after FIX_professional_doc_templates.sql.
-- Design brief for all of these: table-based layout only (Outlook has no
-- flexbox), inline styles only (Gmail strips <style>), max 680px wide,
-- and every colour readable on a white background in case the client's
-- mail app kills backgrounds.
BEGIN;

-- A/B attribution: which copy variant produced a given send. Without this
-- the variant_stats table can count sends but never replies, so
-- best_variant() would have nothing to choose on.
ALTER TABLE public.email_sends ADD COLUMN IF NOT EXISTS variant_key text;
ALTER TABLE public.email_sends ADD COLUMN IF NOT EXISTS variant_category text;
CREATE INDEX IF NOT EXISTS idx_email_sends_variant
  ON public.email_sends (assignment_id, created_at DESC)
  WHERE variant_key IS NOT NULL;

-- ---------------------------------------------------------------- invoice

INSERT INTO public.doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint, active)
SELECT NULL, 'invoice', 'Invoice — Statement', 'Clean accounting-style statement with totals block', '<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#f4f5f7;font-family:-apple-system,''Segoe UI'',Inter,Helvetica,Arial,sans-serif;color:#111827;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f4f5f7;padding:40px 16px;"><tr><td align="center">
<table role="presentation" width="680" cellspacing="0" cellpadding="0" style="max-width:680px;width:100%;background:#ffffff;border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;">
<tr><td style="padding:32px 40px 24px;border-bottom:2px solid #111827;">
  <table width="100%"><tr>
    <td style="vertical-align:top;">
      <div style="font-size:11px;letter-spacing:0.18em;text-transform:uppercase;color:#6b7280;font-weight:700;">Invoice</div>
      <div style="font-size:28px;font-weight:800;color:#111827;margin-top:4px;letter-spacing:-0.02em;">{{invoice_number}}</div>
    </td>
    <td align="right" style="vertical-align:top;">
      <div style="font-size:13px;font-weight:700;color:#111827;">{{provider_name}}</div>
      <div style="font-size:12px;color:#6b7280;margin-top:4px;">Issued {{issue_date}}</div>
      <div style="font-size:12px;color:#6b7280;">Due {{due_date}}</div>
    </td>
  </tr></table>
</td></tr>
<tr><td style="padding:24px 40px 8px;">
  <div style="font-size:10px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#6b7280;">Billed to</div>
  <div style="font-size:16px;font-weight:700;margin-top:4px;color:#111827;">{{client_name}}</div>
</td></tr>
<tr><td style="padding:16px 40px 0;">
  <table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;">
    <tr>
      <td style="padding:10px 0;border-bottom:1px solid #e5e7eb;font-size:10px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#6b7280;">Description</td>
      <td align="right" style="padding:10px 0;border-bottom:1px solid #e5e7eb;font-size:10px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#6b7280;">Amount</td>
    </tr>
    <tr>
      <td style="padding:16px 0;border-bottom:1px solid #f3f4f6;font-size:14px;line-height:1.6;color:#374151;">{{description}}</td>
      <td align="right" style="padding:16px 0;border-bottom:1px solid #f3f4f6;font-size:14px;font-weight:600;color:#111827;white-space:nowrap;">{{amount}} {{currency}}</td>
    </tr>
  </table>
</td></tr>
<tr><td style="padding:20px 40px 32px;">
  <table width="100%"><tr>
    <td width="55%"></td>
    <td width="45%" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:10px;padding:16px 20px;">
      <table width="100%"><tr>
        <td style="font-size:13px;color:#6b7280;">Total due</td>
        <td align="right" style="font-size:20px;font-weight:800;color:#111827;white-space:nowrap;">{{amount}} {{currency}}</td>
      </tr></table>
    </td>
  </tr></table>
</td></tr>
<tr><td style="padding:0 40px 32px;">
  <div style="border-top:1px solid #e5e7eb;padding-top:20px;font-size:12px;line-height:1.7;color:#6b7280;">
    <strong style="color:#374151;">Payment details:</strong> {{payment_details}}<br/>
    Reference <strong style="color:#374151;">{{invoice_number}}</strong> on your transfer so it reconciles automatically.
  </div>
</td></tr>
</table></td></tr></table>
</body></html>',
'Invoice {{invoice_number}} from {{provider_name}} to {{client_name}}. {{description}}. Total due: {{amount}} {{currency}} by {{due_date}}. Payment details: {{payment_details}}',
'["invoice_number","provider_name","client_name","issue_date","due_date","description","amount","currency","payment_details"]'::jsonb, 'email', true
WHERE NOT EXISTS (SELECT 1 FROM public.doc_templates WHERE name = 'Invoice — Statement' AND tenant_id IS NULL);

INSERT INTO public.doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint, active)
SELECT NULL, 'invoice', 'Invoice — Receipt (paid)', 'Compact green confirmation for settled invoices', '<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#f0fdf4;font-family:-apple-system,''Segoe UI'',Inter,Helvetica,Arial,sans-serif;color:#052e16;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f0fdf4;padding:48px 16px;"><tr><td align="center">
<table role="presentation" width="560" cellspacing="0" cellpadding="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 30px rgba(5,46,22,0.08);">
<tr><td align="center" style="padding:36px 40px 8px;">
  <div style="width:52px;height:52px;border-radius:26px;background:#dcfce7;line-height:52px;text-align:center;font-size:24px;color:#16a34a;font-weight:800;">&#10003;</div>
  <div style="font-size:11px;letter-spacing:0.16em;text-transform:uppercase;color:#16a34a;font-weight:700;margin-top:16px;">Payment received</div>
  <div style="font-size:30px;font-weight:800;color:#052e16;margin-top:6px;letter-spacing:-0.02em;">{{amount}} {{currency}}</div>
  <div style="font-size:13px;color:#4b5563;margin-top:6px;">Thank you, {{client_name}}.</div>
</td></tr>
<tr><td style="padding:24px 40px 36px;">
  <table width="100%" style="background:#f9fafb;border-radius:10px;">
    <tr><td style="padding:14px 18px;border-bottom:1px solid #f3f4f6;font-size:13px;color:#6b7280;">Invoice</td>
        <td align="right" style="padding:14px 18px;border-bottom:1px solid #f3f4f6;font-size:13px;font-weight:600;color:#111827;">{{invoice_number}}</td></tr>
    <tr><td style="padding:14px 18px;border-bottom:1px solid #f3f4f6;font-size:13px;color:#6b7280;">Paid on</td>
        <td align="right" style="padding:14px 18px;border-bottom:1px solid #f3f4f6;font-size:13px;font-weight:600;color:#111827;">{{paid_date}}</td></tr>
    <tr><td style="padding:14px 18px;font-size:13px;color:#6b7280;">For</td>
        <td align="right" style="padding:14px 18px;font-size:13px;font-weight:600;color:#111827;">{{description}}</td></tr>
  </table>
  <p style="margin:20px 0 0;font-size:12px;line-height:1.7;color:#6b7280;text-align:center;">Keep this receipt for your records. Questions? Just reply to this email.</p>
</td></tr>
</table></td></tr></table>
</body></html>',
'Payment received: {{amount}} {{currency}} for invoice {{invoice_number}} ({{description}}) on {{paid_date}}. Thank you, {{client_name}}.',
'["amount","currency","client_name","invoice_number","paid_date","description"]'::jsonb, 'email', true
WHERE NOT EXISTS (SELECT 1 FROM public.doc_templates WHERE name = 'Invoice — Receipt (paid)' AND tenant_id IS NULL);

-- ---------------------------------------------------------------- proposal

INSERT INTO public.doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint, active)
SELECT NULL, 'proposal', 'Proposal — Editorial (light)', 'Light serif editorial layout with a pricing block', '<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#faf9f7;font-family:Georgia,''Times New Roman'',serif;color:#1c1917;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#faf9f7;padding:48px 16px;"><tr><td align="center">
<table role="presentation" width="660" cellspacing="0" cellpadding="0" style="max-width:660px;width:100%;background:#ffffff;border:1px solid #e7e5e4;">
<tr><td style="padding:44px 48px 0;">
  <div style="font-family:-apple-system,''Segoe UI'',Helvetica,Arial,sans-serif;font-size:10px;letter-spacing:0.22em;text-transform:uppercase;color:#a8a29e;font-weight:700;">Proposal</div>
  <h1 style="margin:14px 0 0;font-size:34px;line-height:1.15;font-weight:400;letter-spacing:-0.02em;color:#1c1917;">A steady flow of {{vertical}} customers in {{geo}}.</h1>
  <p style="margin:18px 0 0;font-size:15px;line-height:1.75;color:#57534e;">Prepared for <strong>{{client_name}}</strong>. Everything below is what we would do in the first 30 days — no retainer for strategy decks, no setup fee.</p>
  <div style="height:1px;background:#e7e5e4;margin:32px 0 0;"></div>
</td></tr>
<tr><td style="padding:32px 48px 0;">
  <table width="100%" cellspacing="0" cellpadding="0">
    <tr>
      <td width="48%" style="vertical-align:top;padding-bottom:24px;">
        <div style="font-family:-apple-system,''Segoe UI'',Helvetica,Arial,sans-serif;font-size:10px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#b45309;">What you get</div>
        <p style="margin:8px 0 0;font-size:14px;line-height:1.7;color:#44403c;">{{lead_count}} qualified enquiries per month, delivered the day they are generated, exclusive to you in {{offer_category}}.</p>
      </td>
      <td width="4%"></td>
      <td width="48%" style="vertical-align:top;padding-bottom:24px;">
        <div style="font-family:-apple-system,''Segoe UI'',Helvetica,Arial,sans-serif;font-size:10px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#b45309;">How we do it</div>
        <p style="margin:8px 0 0;font-size:14px;line-height:1.7;color:#44403c;">{{scope}}</p>
      </td>
    </tr>
  </table>
</td></tr>
<tr><td style="padding:8px 48px 0;">
  <table width="100%" style="background:#fffbeb;border:1px solid #fde68a;">
    <tr>
      <td style="padding:24px 28px;">
        <div style="font-family:-apple-system,''Segoe UI'',Helvetica,Arial,sans-serif;font-size:10px;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;color:#b45309;">Investment</div>
        <div style="font-size:32px;font-weight:400;color:#78350f;margin-top:6px;">{{amount}} <span style="font-size:14px;">{{currency}} / month</span></div>
        <div style="font-family:-apple-system,''Segoe UI'',Helvetica,Arial,sans-serif;font-size:12px;color:#92400e;margin-top:8px;">No setup fee. Cancel with 30 days notice. {{term}}</div>
      </td>
    </tr>
  </table>
</td></tr>
<tr><td style="padding:32px 48px 48px;">
  <p style="margin:0 0 24px;font-size:15px;line-height:1.75;color:#57534e;">If this looks right, reply with <strong>&ldquo;approved&rdquo;</strong> and we start this week. If something needs changing, tell me which part and I will send a revised version the same day.</p>
  <div style="height:1px;background:#e7e5e4;"></div>
  <p style="margin:20px 0 0;font-size:14px;color:#1c1917;">{{provider_name}}</p>
</td></tr>
</table></td></tr></table>
</body></html>',
'Proposal for {{client_name}}: {{lead_count}} qualified {{vertical}} enquiries per month in {{geo}}, exclusive in {{offer_category}}. Approach: {{scope}}. Investment: {{amount}} {{currency}}/month, no setup fee, cancel with 30 days notice. {{term}}. — {{provider_name}}',
'["client_name","vertical","geo","lead_count","offer_category","scope","amount","currency","term","provider_name"]'::jsonb, 'email', true
WHERE NOT EXISTS (SELECT 1 FROM public.doc_templates WHERE name = 'Proposal — Editorial (light)' AND tenant_id IS NULL);

-- ---------------------------------------------------------------- nda

INSERT INTO public.doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint, active)
SELECT NULL, 'nda', 'Mutual NDA — Plain', 'Numbered-clause NDA, deliberately readable', '<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#f8fafc;font-family:-apple-system,''Segoe UI'',Inter,Helvetica,Arial,sans-serif;color:#0f172a;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f8fafc;padding:40px 16px;"><tr><td align="center">
<table role="presentation" width="660" cellspacing="0" cellpadding="0" style="max-width:660px;width:100%;background:#ffffff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;">
<tr><td style="padding:32px 40px 20px;border-bottom:1px solid #e2e8f0;">
  <div style="font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#64748b;font-weight:700;">Mutual non-disclosure agreement</div>
  <div style="font-size:22px;font-weight:700;color:#0f172a;margin-top:8px;">{{provider_name}} &amp; {{client_name}}</div>
  <div style="font-size:12px;color:#64748b;margin-top:6px;">Effective {{issue_date}} · Term {{term}}</div>
</td></tr>
<tr><td style="padding:28px 40px 36px;font-size:14px;line-height:1.75;color:#334155;">
  <p style="margin:0 0 20px;">Both parties expect to share confidential information while exploring working together. This agreement sets out how that information is handled. It is mutual — the same obligations apply in both directions.</p>
  <table width="100%" cellspacing="0" cellpadding="0">
    <tr><td style="padding:0 0 18px;">
      <div style="font-size:11px;font-weight:800;color:#0ea5a4;letter-spacing:0.08em;text-transform:uppercase;">1 · What is confidential</div>
      <p style="margin:6px 0 0;">Any non-public business, technical, customer or pricing information shared in any form, whether or not it is marked confidential. {{scope}}</p>
    </td></tr>
    <tr><td style="padding:0 0 18px;">
      <div style="font-size:11px;font-weight:800;color:#0ea5a4;letter-spacing:0.08em;text-transform:uppercase;">2 · What each party agrees to</div>
      <p style="margin:6px 0 0;">Use the information only to evaluate or perform the work between us; share it only with people who need it and are under equivalent obligations; protect it with at least the care used for your own confidential information.</p>
    </td></tr>
    <tr><td style="padding:0 0 18px;">
      <div style="font-size:11px;font-weight:800;color:#0ea5a4;letter-spacing:0.08em;text-transform:uppercase;">3 · What is not covered</div>
      <p style="margin:6px 0 0;">Information that is already public, was already known without obligation, is independently developed, or is required to be disclosed by law or a court — in which case the other party is told first where legally possible.</p>
    </td></tr>
    <tr><td style="padding:0 0 18px;">
      <div style="font-size:11px;font-weight:800;color:#0ea5a4;letter-spacing:0.08em;text-transform:uppercase;">4 · Duration and return</div>
      <p style="margin:6px 0 0;">Obligations last {{term}} from the effective date. On request, each party deletes or returns the other&rsquo;s material, except copies retained automatically in backups or as required by law.</p>
    </td></tr>
    <tr><td>
      <div style="font-size:11px;font-weight:800;color:#0ea5a4;letter-spacing:0.08em;text-transform:uppercase;">5 · No other rights</div>
      <p style="margin:6px 0 0;">Nothing here transfers ownership, grants a licence, or obliges either party to enter into any further agreement.</p>
    </td></tr>
  </table>
  <table width="100%" style="margin-top:36px;"><tr>
    <td width="45%"><p style="margin:0 0 40px;font-size:11px;letter-spacing:0.08em;text-transform:uppercase;color:#94a3b8;">Signed for {{provider_name}}</p><div style="border-bottom:1px solid #94a3b8;"></div></td>
    <td width="10%"></td>
    <td width="45%"><p style="margin:0 0 40px;font-size:11px;letter-spacing:0.08em;text-transform:uppercase;color:#94a3b8;">Signed for {{client_name}}</p><div style="border-bottom:1px solid #94a3b8;"></div></td>
  </tr></table>
</td></tr>
</table></td></tr></table>
</body></html>',
'Mutual NDA between {{provider_name}} and {{client_name}}, effective {{issue_date}}, term {{term}}. Covers non-public business, technical, customer and pricing information ({{scope}}). Each party uses it only for the work between them, limits access to those who need it, and protects it with reasonable care. Excludes public, already-known, independently developed, or legally compelled disclosures. Material returned or deleted on request. No transfer of ownership or licence.',
'["provider_name","client_name","issue_date","term","scope"]'::jsonb, 'email', true
WHERE NOT EXISTS (SELECT 1 FROM public.doc_templates WHERE name = 'Mutual NDA — Plain' AND tenant_id IS NULL);

-- ---------------------------------------------------------------- onboarding

INSERT INTO public.doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint, active)
SELECT NULL, 'onboarding', 'Welcome — First 7 days', 'Numbered checklist so a new client knows exactly what happens next', '<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#eef2ff;font-family:-apple-system,''Segoe UI'',Inter,Helvetica,Arial,sans-serif;color:#0f172a;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#eef2ff;padding:40px 16px;"><tr><td align="center">
<table role="presentation" width="640" cellspacing="0" cellpadding="0" style="max-width:640px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 10px 34px rgba(15,23,42,0.10);">
<tr><td style="background:linear-gradient(135deg,#4F46E5 0%,#312e81 100%);padding:36px 40px;">
  <div style="font-size:10px;letter-spacing:0.18em;text-transform:uppercase;color:rgba(255,255,255,0.72);font-weight:700;">Welcome aboard</div>
  <div style="font-size:26px;font-weight:800;color:#ffffff;margin-top:8px;letter-spacing:-0.02em;">{{client_name}}, here is your first week.</div>
</td></tr>
<tr><td style="padding:32px 40px 8px;">
  <p style="margin:0 0 24px;font-size:14px;line-height:1.75;color:#475569;">No long onboarding call needed. Four things happen, three of them on our side.</p>
  <table width="100%" cellspacing="0" cellpadding="0">
    <tr><td style="padding-bottom:20px;vertical-align:top;width:36px;">
      <div style="width:28px;height:28px;border-radius:14px;background:#eef2ff;color:#4F46E5;font-weight:800;font-size:13px;line-height:28px;text-align:center;">1</div>
    </td><td style="padding-bottom:20px;">
      <div style="font-size:14px;font-weight:700;color:#0f172a;">Today — your portal is live</div>
      <p style="margin:4px 0 0;font-size:13px;line-height:1.7;color:#64748b;">Sign in at {{portal_url}}. Every lead we deliver lands there with contact details, a quality score, and the reason it scored that way.</p>
    </td></tr>
    <tr><td style="padding-bottom:20px;vertical-align:top;width:36px;">
      <div style="width:28px;height:28px;border-radius:14px;background:#eef2ff;color:#4F46E5;font-weight:800;font-size:13px;line-height:28px;text-align:center;">2</div>
    </td><td style="padding-bottom:20px;">
      <div style="font-size:14px;font-weight:700;color:#0f172a;">Day 1–2 — we build your target list</div>
      <p style="margin:4px 0 0;font-size:13px;line-height:1.7;color:#64748b;">{{scope}} Nothing is delivered until it has been verified — no dead numbers, no closed businesses.</p>
    </td></tr>
    <tr><td style="padding-bottom:20px;vertical-align:top;width:36px;">
      <div style="width:28px;height:28px;border-radius:14px;background:#eef2ff;color:#4F46E5;font-weight:800;font-size:13px;line-height:28px;text-align:center;">3</div>
    </td><td style="padding-bottom:20px;">
      <div style="font-size:14px;font-weight:700;color:#0f172a;">Day 3 onwards — leads start arriving</div>
      <p style="margin:4px 0 0;font-size:13px;line-height:1.7;color:#64748b;">Up to {{lead_count}} per month for {{geo}}. You will get an in-app notification each time a batch lands.</p>
    </td></tr>
    <tr><td style="vertical-align:top;width:36px;">
      <div style="width:28px;height:28px;border-radius:14px;background:#fef3c7;color:#b45309;font-weight:800;font-size:13px;line-height:28px;text-align:center;">4</div>
    </td><td>
      <div style="font-size:14px;font-weight:700;color:#0f172a;">Your only job: mark what happened</div>
      <p style="margin:4px 0 0;font-size:13px;line-height:1.7;color:#64748b;">Won, lost, or bad lead — one click per lead. That feedback retrains the scoring for your market, so month two is measurably better than month one. Bad leads get replaced.</p>
    </td></tr>
  </table>
</td></tr>
<tr><td style="padding:28px 40px 36px;">
  <div style="border-top:1px solid #e2e8f0;padding-top:20px;font-size:13px;line-height:1.7;color:#64748b;">
    Anything unclear, reply to this email — it reaches a person, not a ticket queue.<br/>
    <span style="color:#0f172a;font-weight:600;">{{provider_name}}</span>
  </div>
</td></tr>
</table></td></tr></table>
</body></html>',
'Welcome {{client_name}}. 1) Your portal is live at {{portal_url}} — every lead lands there with contact details and a quality score. 2) Day 1-2 we build your target list: {{scope}} Nothing is delivered unverified. 3) From day 3, up to {{lead_count}} leads per month for {{geo}}, with a notification per batch. 4) Your only job: mark each lead won, lost or bad — that feedback retrains scoring for your market, and bad leads get replaced. Questions? Reply to this email. — {{provider_name}}',
'["client_name","portal_url","scope","lead_count","geo","provider_name"]'::jsonb, 'email', true
WHERE NOT EXISTS (SELECT 1 FROM public.doc_templates WHERE name = 'Welcome — First 7 days' AND tenant_id IS NULL);

-- ---------------------------------------------------------------- contract

INSERT INTO public.doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint, active)
SELECT NULL, 'contract', 'Service Agreement — One page', 'Short plain-English agreement that still covers the essentials', '<!DOCTYPE html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#ffffff;font-family:-apple-system,''Segoe UI'',Inter,Helvetica,Arial,sans-serif;color:#111827;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:40px 16px;"><tr><td align="center">
<table role="presentation" width="640" cellspacing="0" cellpadding="0" style="max-width:640px;width:100%;">
<tr><td style="border-top:4px solid #111827;padding:24px 0 20px;">
  <div style="font-size:10px;letter-spacing:0.2em;text-transform:uppercase;color:#6b7280;font-weight:700;">Service agreement · one page</div>
  <div style="font-size:24px;font-weight:800;color:#111827;margin-top:8px;letter-spacing:-0.02em;">{{provider_name}} &amp; {{client_name}}</div>
  <div style="font-size:12px;color:#6b7280;margin-top:6px;">Effective {{issue_date}}</div>
</td></tr>
<tr><td style="font-size:14px;line-height:1.8;color:#374151;">
  <p style="margin:0 0 18px;">This is the whole agreement. It is written to be read, not to be survived.</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">1. The work.</strong> {{scope}}</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">2. The fee.</strong> {{amount}} {{currency}}, {{term}}. Invoices are due 14 days from issue.</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">3. Quality.</strong> A lead that has no working contact, no real business behind it, or no genuine need is not a lead. Flag it and it is replaced at no charge.</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">4. Ending it.</strong> Either party may end this agreement with 30 days written notice. Work already delivered is payable; work not yet delivered is not.</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">5. Confidentiality.</strong> Neither party discloses the other&rsquo;s non-public information except to those who need it to do the work, or where the law requires it.</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">6. Data.</strong> Contact data is provided for {{client_name}}&rsquo;s own outreach only. It is not resold or shared onward, and deletion requests from any individual are honoured promptly by both parties.</p>
  <p style="margin:0 0 14px;"><strong style="color:#111827;">7. Liability.</strong> Neither party is liable for indirect or consequential loss. Total liability is capped at the fees paid in the three months before the claim.</p>
  <p style="margin:0 0 28px;"><strong style="color:#111827;">8. Everything else.</strong> Changes must be agreed in writing by both parties. This document replaces any earlier discussion on the same subject.</p>
  <table width="100%" style="border-top:1px solid #e5e7eb;padding-top:24px;"><tr>
    <td width="45%" style="padding-top:24px;"><p style="margin:0 0 44px;font-size:11px;letter-spacing:0.08em;text-transform:uppercase;color:#9ca3af;">Provider</p><div style="border-bottom:1px solid #9ca3af;"></div><p style="margin:8px 0 0;font-size:13px;color:#374151;">{{provider_name}}</p></td>
    <td width="10%"></td>
    <td width="45%" style="padding-top:24px;"><p style="margin:0 0 44px;font-size:11px;letter-spacing:0.08em;text-transform:uppercase;color:#9ca3af;">Client</p><div style="border-bottom:1px solid #9ca3af;"></div><p style="margin:8px 0 0;font-size:13px;color:#374151;">{{client_name}}</p></td>
  </tr></table>
</td></tr>
</table></td></tr></table>
</body></html>',
'Service Agreement between {{provider_name}} and {{client_name}}, effective {{issue_date}}. 1. Work: {{scope}} 2. Fee: {{amount}} {{currency}}, {{term}}; invoices due 14 days from issue. 3. Quality: leads without working contact, real business or genuine need are replaced free. 4. Either party may end with 30 days written notice. 5. Confidentiality both ways. 6. Contact data for {{client_name}} outreach only, not resold; deletion requests honoured. 7. No indirect loss; liability capped at 3 months of fees. 8. Changes in writing; supersedes earlier discussions.',
'["provider_name","client_name","issue_date","scope","amount","currency","term"]'::jsonb, 'email', true
WHERE NOT EXISTS (SELECT 1 FROM public.doc_templates WHERE name = 'Service Agreement — One page' AND tenant_id IS NULL);

COMMIT;

NOTIFY pgrst, 'reload schema';
