# LeadX package — latest

## 2026-08-23 — job queue, notifications, deliverability, copy A/B

**Migrations to run (in order, both idempotent):** `NEXT_PHASE_MIGRATION.sql`,
then `NEXT_PHASE_TEMPLATES.sql`.

**New required process:** a worker. `python -m backend.worker --concurrency 3`.
Started automatically by `start.sh` and `docker compose`. Queued work does not
run without it — watch **Operator → Jobs**.

- **Job queue** (`jobs` table, not Redis — see below). Pipeline runs, bulk
  sends >25 recipients, CSV imports and due sequence steps now enqueue and
  return a job id instead of blocking the request. Every call site falls back
  to the old inline path if the table is missing, so deploying before the
  migration degrades rather than breaks.
- **Notifications** — one `notifications` table, two scopes. Bell + badge in
  both consoles, pages at `/notifications` and `/admin/notifications`. Fires
  on lead delivery, pipeline failure, bulk-send completion and every inbound
  reply (the existing push alerts only fired on positives).
- **Operator additions** — Jobs monitor with a **cron audit** that flags any
  cron-driven feature that has not run inside its expected window; Replies
  inbox; own prospecting pipeline against an internal operator tenant.
- **Client additions** — saved views on Leads, CSV import of your own customer
  list, deal revenue/forecast report, mobile drawer navigation.
- **Deliverability** — SES bounce/complaint webhook auto-suppresses hard
  bounces and complaints; per-domain daily caps with a warm-up ramp;
  business-hours-only sending in the recipient's timezone; minimum gap
  between touches; send-time jitter.
- **Copy library + A/B** — 15 persuasive variants across cold outreach,
  follow-up, proposal and invoice. Sends are tagged with their variant and
  inbound replies credit it back, so `best_variant()` learns per tenant.
- **Email writing tool** (`/compose`) — click-to-edit editor, rule-based
  subject and body lint (instant, no LLM), and LLM rewrite for six tones plus
  shorten/expand/fix/subject-ideas. Needs `OPENROUTER_API_KEY` (or
  `OPENAI_API_KEY` / `GROQ_API_KEY` / `ANTHROPIC_API_KEY`) for the rewrite
  half only; the lint works with no keys at all.
- **Bug fixed:** `crm_entities_api` was never mounted, so every
  `/crm/{tenant}/companies|contacts|deals|activities|notes` route was a 404
  and the Companies, Contacts and Deals pages were dead.
- **6 new document designs** across invoice, proposal, NDA, onboarding and
  contract (`NEXT_PHASE_TEMPLATES.sql`).

### Deviation from the plan
The plan specified Celery or RQ with Redis. This uses a Postgres-backed queue
(`jobs` table, compare-and-swap claim on `status`) instead: no new
infrastructure to run or pay for, and the job rows are themselves the data
behind the operator's Jobs page. The trade-off is polling latency of a few
seconds instead of sub-second pickup, and throughput bounded by Postgres
round-trips — neither matters at this volume. If it ever does, the handler
registry in `job_handlers.py` is the only thing a Celery swap would touch.

## Included fixes
- Valid UUID hex only in `SUPABASE_FULL_MIGRATION.sql` (no d3m00 / ct001)
- `api_key_pool` allows `linkedin_scraper` (`sql/018_api_key_pool_linkedin.sql`)
- LinkedIn scraper service under `lead-engine-v2/services/linkedin-scraper/`
- Client `/login` outside portal layout; `/` redirects to login
- SessionGate requires Supabase session
- CSS `.shell` flex row (sidebar beside content)
- Admin overview stats cards

## Run provider fix on existing DB
```sql
-- see sql/018_api_key_pool_linkedin.sql
```

## 2026-08-16 — risks + social + email

- Brevo email provider (`BREVO_API_KEY`, `EMAIL_PROVIDER=brevo|auto`)
- Team invites use unified email stack (Resend/Brevo/SMTP)
- SQL: `FIX_MULTIUSER_TEAM_SOCIAL.sql` for tenant_members, invites, linkedin provider
- instaloader in requirements; LinkedIn scraper via setup + Docker
