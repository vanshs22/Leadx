#!/usr/bin/env bash
# Quick start after setup.sh --install-only
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
API="$ROOT/lead-engine-v2"
WEB="$ROOT/lead-crm-portal/frontend"
VENV="$API/.venv"

if [ ! -f "$VENV/bin/activate" ]; then
  echo "No venv. Run: chmod +x setup.sh && ./setup.sh --install-only"
  exit 1
fi
# shellcheck source=/dev/null
source "$VENV/bin/activate"
export PYTHONPATH="$API${PYTHONPATH:+:$PYTHONPATH}"

# Project refactored: backend/ → app/
APP_MODULE="app.app_service:app"
if [ -f "$API/app/app_service.py" ]; then
  APP_MODULE="app.app_service:app"
elif [ -f "$API/backend/app_service.py" ]; then
  APP_MODULE="backend.app_service:app"
elif [ -f "$API/backend/main.py" ]; then
  APP_MODULE="backend.main:app"
else
  echo "ERROR: could not find FastAPI app module under $API"
  exit 1
fi
echo "API module: $APP_MODULE"

cd "$API"
pkill -f "uvicorn ${APP_MODULE%%:*}" 2>/dev/null || true
nohup uvicorn "$APP_MODULE" --host 0.0.0.0 --port 8000 --reload > /tmp/leadx-api.log 2>&1 &
sleep 2
curl -sf http://127.0.0.1:8000/health && echo "" || echo "API starting… see /tmp/leadx-api.log"

# Background worker: drains the jobs table (pipeline runs, bulk sends,
# imports, due sequence steps). Nothing queued executes without it.
# Module is app.worker (was backend.worker before refactor)
pkill -f "app.worker\|backend.worker" 2>/dev/null || true
WORKER_MODULE="app.worker"
[ -f "$API/app/worker.py" ] || WORKER_MODULE="backend.worker"
WORKER_INTERNAL_CRON=true nohup python -m "$WORKER_MODULE" --concurrency 3 > /tmp/leadx-worker.log 2>&1 &
echo "Worker started ($WORKER_MODULE) log: /tmp/leadx-worker.log"

cd "$WEB"
[ -d node_modules ] || npm install
npm run dev
