# Leadx — Run (fixed entrypoints)

The codebase was refactored from `backend/` → `app/`.  
Correct modules:

- API: `app.app_service:app`
- Worker: `app.worker`

## Quick start (recommended)

```bash
cd Leadx-main/Leadx-main   # this folder
chmod +x setup.sh start.sh
./setup.sh                 # installs deps + starts API + frontend
# or install only, then:
./setup.sh --install-only
./start.sh                 # API + worker + Next.js
```

## Manual

**Terminal 1 – API**
```bash
cd lead-engine-v2
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PYTHONPATH=.
uvicorn app.app_service:app --host 0.0.0.0 --port 8000 --reload
```

**Terminal 2 – Worker (required for queues)**
```bash
cd lead-engine-v2
source .venv/bin/activate
export PYTHONPATH=.
WORKER_INTERNAL_CRON=true python -m app.worker --concurrency 3
```

**Terminal 3 – Frontend**
```bash
cd lead-crm-portal/frontend
npm install
npm run dev
```

## Docker
```bash
# fill lead-engine-v2/.env first
docker compose up --build
```

## Env (minimum)

`lead-engine-v2/.env`:
```
ENVIRONMENT=development
LEAD_ENGINE_DEV_AUTH_BYPASS=1
LEAD_ENGINE_SERVICE_KEY=dev-local-service-key-16chars
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_KEY=eyJ...
SUPABASE_ANON_KEY=eyJ...
```

`lead-crm-portal/frontend/.env.local` is written automatically by `./setup.sh` from the API `.env`.

## URLs
- http://localhost:3000  — CRM
- http://localhost:8000/docs — API docs
- http://localhost:8000/health — health

## Database
Run in Supabase SQL Editor:
1. `lead-engine-v2/sql/000_ALL_IN_ONE_migration.sql` (or SUPABASE_FULL_MIGRATION.sql)
2. Any NEXT_PHASE_*.sql files if present
