-- ============================================================
-- LeadX next-phase migration (idempotent — safe to re-run)
-- Run in Supabase SQL editor AFTER SUPABASE_FULL_MIGRATION.sql
--   1. job queue          (jobs)
--   2. notifications      (notifications)
--   3. deliverability     (email_domain_daily, domain_warmup, email_bounces)
--   4. send timing        (lead_touches)
--   5. saved views        (saved_views)
--   6. template A/B       (template_variant_stats)
--   7. operator pipeline  (tenants.is_operator)
-- ============================================================

-- ---------- 1. Job queue -------------------------------------
-- DB-backed queue: API enqueues, a separate worker process claims and
-- runs. Claim is a compare-and-swap on status, so N workers are safe
-- without SKIP LOCKED (supabase-py can't express row locks).
CREATE TABLE IF NOT EXISTS public.jobs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kind         text NOT NULL,
  payload      jsonb NOT NULL DEFAULT '{}'::jsonb,
  status       text NOT NULL DEFAULT 'queued',   -- queued|running|done|failed|cancelled
  priority     int  NOT NULL DEFAULT 0,          -- higher runs first
  attempts     int  NOT NULL DEFAULT 0,
  max_attempts int  NOT NULL DEFAULT 3,
  run_after    timestamptz NOT NULL DEFAULT now(),
  locked_by    text,
  locked_at    timestamptz,
  result       jsonb,
  error        text,
  created_by   text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  started_at   timestamptz,
  finished_at  timestamptz
);
CREATE INDEX IF NOT EXISTS jobs_claim_idx   ON public.jobs (status, run_after, priority DESC);
CREATE INDEX IF NOT EXISTS jobs_tenant_idx  ON public.jobs (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS jobs_kind_idx    ON public.jobs (kind, created_at DESC);

-- ---------- 2. Notifications ---------------------------------
-- scope='admin' rows have tenant_id NULL (operator inbox) or a
-- tenant_id for "this client needs attention". scope='tenant' rows are
-- what the client portal shows.
CREATE TABLE IF NOT EXISTS public.notifications (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope      text NOT NULL DEFAULT 'tenant',      -- tenant|admin
  tenant_id  uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  kind       text NOT NULL,                       -- lead_delivered|reply_received|job_failed|...
  severity   text NOT NULL DEFAULT 'info',        -- info|warning|critical
  title      text NOT NULL,
  body       text NOT NULL DEFAULT '',
  link       text,
  meta       jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at    timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notifications_feed_idx
  ON public.notifications (scope, tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS notifications_unread_idx
  ON public.notifications (scope, tenant_id) WHERE read_at IS NULL;

-- ---------- 3. Deliverability --------------------------------
-- Per-sending-domain daily counter (mirrors email_provider_daily,
-- one level down: provider caps protect the account, domain caps
-- protect the domain's reputation).
CREATE TABLE IF NOT EXISTS public.email_domain_daily (
  day        date NOT NULL,
  tenant_id  uuid NOT NULL,
  domain     text NOT NULL,
  sent_count int  NOT NULL DEFAULT 0,
  PRIMARY KEY (day, tenant_id, domain)
);

-- Warm-up ramp: a new domain starts small and grows daily until it
-- reaches full_cap. Absent row = no ramp (established domain).
CREATE TABLE IF NOT EXISTS public.domain_warmup (
  tenant_id   uuid NOT NULL,
  domain      text NOT NULL,
  started_on  date NOT NULL DEFAULT CURRENT_DATE,
  start_cap   int  NOT NULL DEFAULT 20,
  full_cap    int  NOT NULL DEFAULT 500,
  ramp_days   int  NOT NULL DEFAULT 21,
  paused      boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, domain)
);

-- Bounce / complaint audit trail. Hard bounces + complaints are also
-- pushed into global_opt_out so no pipeline can re-deliver them.
CREATE TABLE IF NOT EXISTS public.email_bounces (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid,
  email        text NOT NULL,
  event_type   text NOT NULL,          -- Bounce|Complaint|Delivery|Reject
  bounce_type  text,                   -- Permanent|Transient|Undetermined
  sub_type     text,
  diagnostic   text,
  suppressed   boolean NOT NULL DEFAULT false,
  raw          jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS email_bounces_email_idx ON public.email_bounces (lower(email));
CREATE INDEX IF NOT EXISTS email_bounces_day_idx   ON public.email_bounces (created_at DESC);

-- ---------- 4. Cross-channel touch log ----------------------
-- One row per outbound contact on any channel, so two independent
-- automations can't both hit the same lead on the same day.
CREATE TABLE IF NOT EXISTS public.lead_touches (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL,
  assignment_id uuid,
  channel       text NOT NULL,          -- email|call|sms|linkedin
  touched_at    timestamptz NOT NULL DEFAULT now(),
  meta          jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS lead_touches_assignment_idx
  ON public.lead_touches (assignment_id, touched_at DESC);
CREATE INDEX IF NOT EXISTS lead_touches_tenant_idx
  ON public.lead_touches (tenant_id, touched_at DESC);

-- ---------- 5. Saved views ----------------------------------
CREATE TABLE IF NOT EXISTS public.saved_views (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id  uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id    uuid,                      -- NULL = shared with whole workspace
  entity     text NOT NULL DEFAULT 'leads',
  name       text NOT NULL,
  filters    jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS saved_views_tenant_idx ON public.saved_views (tenant_id, entity);

-- ---------- 6. Template A/B ---------------------------------
-- Per-variant send/reply counters. Variant selection reads this and
-- prefers the best reply rate once a variant has enough sends.
CREATE TABLE IF NOT EXISTS public.template_variant_stats (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid,
  category    text NOT NULL,
  variant_key text NOT NULL,
  sent        int NOT NULL DEFAULT 0,
  opened      int NOT NULL DEFAULT 0,
  replied     int NOT NULL DEFAULT 0,
  positive    int NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, category, variant_key)
);

-- ---------- 7. Operator's own pipeline ----------------------
-- The internal tenant that holds LeadX's own prospecting (ICP =
-- agencies). Same tables, different scope — no parallel data model.
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS is_operator boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS tenants_operator_idx ON public.tenants (is_operator) WHERE is_operator;

-- Sequence enrollments need a deferral reason when send policy holds
-- a step back (business hours / domain cap), so the UI can explain it.
ALTER TABLE public.email_sequence_enrollments
  ADD COLUMN IF NOT EXISTS deferred_reason text;

NOTIFY pgrst, 'reload schema';
