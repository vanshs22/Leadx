"""Revert app.X.Y imports where X.Y doesn't exist under app/ but resolves in a site-package."""
import os, re, py_compile

ROOT = r"C:\Users\vansh\Leadx-main\Leadx-main\lead-engine-v2"
APP = os.path.join(ROOT, "app")
SP = os.path.join(ROOT, ".venv", "Lib", "site-packages")
LIBS = [l for l in ("fastapi", "starlette", "pydantic") if os.path.isdir(os.path.join(SP, l))]

def local_ok(path):
    p = os.path.join(APP, *path.split("."))
    return os.path.isdir(p) or os.path.isfile(p + ".py")

def lib_for(path):
    for lib in LIBS:
        p = os.path.join(SP, lib, *path.split("."))
        if os.path.isdir(p) or os.path.isfile(p + ".py"):
            return lib
    return None

rx = re.compile(rb"((?:from|import)[ \t]+)app\.([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)")
EX = {"__pycache__", ".venv", "node_modules", ".git"}
fixed, fails = [], 0
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EX]
    for f in fn:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        d = open(p, "rb").read()
        n = rx.sub(lambda m: m.group(0) if local_ok(m.group(2).decode())
                   else (m.group(1) + lib_for(m.group(2).decode()).encode() + b"." + m.group(2))
                   if lib_for(m.group(2).decode()) else m.group(0), d)
        if n != d:
            open(p, "wb").write(n)
            try:
                py_compile.compile(p, doraise=True)
            except Exception as e:
                open(p, "wb").write(d); fails.append((p, str(e))); continue
            fixed.append(os.path.relpath(p, ROOT));
print("FIXED:", len(fixed))
for r in fixed:
    print("   ", r)
for p, e in fails:
    print("FAIL(restored):", p, e)

# Final sanity: every 'app.' import must resolve now
bad = 0
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EX]
    for f in fn:
        if f.endswith(".py"):
            p = os.path.join(dp, f)
            for m in rx.finditer(open(p, "rb").read()):
                if not local_ok(m.group(2).decode()) and not lib_for(m.group(2).decode()):
                    bad += 1
                    print("UNRESOLVED:", os.path.relpath(p, ROOT), m.group(0).decode())
print("UNRESOLVED_COUNT:", bad)
