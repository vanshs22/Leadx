import os, re

ROOT = r'C:\Users\vansh\Leadx-main\Leadx-main\lead-engine-v2'
FILES = []
for d in ('app', 'services', 'scripts', 'tests'):
    base = os.path.join(ROOT, d)
    if not os.path.isdir(base):
        continue
    for dp, dn, fn in os.walk(base):
        dn[:] = [x for x in dn if x != '__pycache__']
        FILES += [os.path.join(dp, f) for f in fn if f.endswith('.py')]
for f in ('pytest.ini', 'Dockerfile', 'docker-compose.yml'):
    p = os.path.join(ROOT, f)
    if os.path.isfile(p):
        FILES.append(p)

# invisible homoglyphs sit between 'the' and 'model'; allow up to 6 junk bytes
pat_imp = re.compile(rb'\b(from|import)([ \t]+)the[^A-Za-z0-9_]{0,6}model\b')
pat_any = re.compile(rb'the[^A-Za-z0-9_]{0,6}model')

total = 0
leftover = []
for path in FILES:
    with open(path, 'rb') as fh:
        raw = fh.read()
    new, n = pat_imp.subn(lambda m: m.group(1) + m.group(2) + b'app', raw)
    if n:
        with open(path, 'wb') as fh:
            fh.write(new)
        total += n
        print('FIXED', n, os.path.relpath(path, ROOT))
    for m in pat_any.finditer(new):
        s = max(0, m.start() - 45)
        leftover.append((os.path.relpath(path, ROOT), new[s:m.end() + 45]))
print('TOTAL_IMPORT_FIXES:', total)
print('LEFTOVER:', len(leftover))
for f, ctx in leftover[:30]:
    print(' -', f, '::', ctx)
