"""Byte-level repair: rewrite mangled package refs in import statements to 'app'."""
import os, re, sys, py_compile

ROOT = r"C:\Users\vansh\Leadx-main\Leadx-main\lead-engine-v2"
EXCLUDE = {"__pycache__", ".venv", "node_modules", ".git"}

svc = open(os.path.join(ROOT, "app", "app_service.py"), "rb").read()

# 1. Discover the exact byte sequence used as the top-level package name.
tokens = set()
for ln in svc.split(b"\n"):
    m = re.match(rb"[ \t]*(?:from|import)[ \t]+([^\s.;]+)\.", ln)
    if m and m.group(1) != b"app":
        tokens.add(m.group(1))
if not tokens:
    print("IMPORTS_ALREADY_CLEAN")
    sys.exit(0)
for t in tokens:
    print("BAD_TOKEN:", repr(t))

# 2. Build patterns: dotted form (from X.y / import X.y) and bare-from form (from X import y)
rx_dot = [(re.compile(rb"((?:from|import)[ \t]+)" + re.escape(t) + rb"\.")) for t in tokens]
rx_bare = [(re.compile(rb"(from[ \t]+)" + re.escape(t) + rb"([ \t]+import[ \t]+)")) for t in tokens]

fixed_files, total, fails = [], 0, []
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EXCLUDE]
    for f in fn:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        try:
            d = open(p, "rb").read()
        except OSError:
            continue
        n, c = d, 0
        for rx in rx_dot:
            n, k = rx.subn(rb"\1app.", n); c += k
        for rx in rx_bare:
            n, k = rx.subn(rb"\1app\2", n); c += k
        if c:
            open(p, "wb").write(n)
            try:
                py_compile.compile(p, doraise=True)
            except Exception as e:
                open(p, "wb").write(d)  # restore original on failure
                fails.append((os.path.relpath(p, ROOT), str(e)))
                continue
            fixed_files.append(os.path.relpath(p, ROOT)); total += c

print("FILES_FIXED:", len(fixed_files), "SUBS:", total)
for r in fixed_files[:25]:
    print("   ", r)
for r, e in fails:
    print("COMPILE_FAIL(kept original):", r, e)

# 3. Leftover scan across every .py file
left = 0
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EXCLUDE]
    for f in fn:
        if f.endswith(".py"):
            d = open(os.path.join(dp, f), "rb").read()
            left += sum(d.count(t) for t in tokens)
print("LEFTOVER_TOKEN_BYTES:", left)

# 4. Show the repaired import lines as proof
out = []
for i, ln in enumerate(open(os.path.join(ROOT, "app", "app_service.py"), "rb").read().split(b"\n")):
    if b".api.prod." in ln or b".crm." in ln or b".integrations." in ln:
        out.append((i + 1, ln.decode("utf-8", "replace").strip()))
print("REPAIRED_LINES:")
for i, s in out[:10]:
    print(f"   {i}: {s}")
