"""Revert wrongful app.<fastapi-submodule> rewrites; keep genuine backend->app fixes."""
import os, re, sys, py_compile

ROOT = r"C:\Users\vansh\Leadx-main\Leadx-main\lead-engine-v2"
EXCLUDE = {"__pycache__", ".venv", "node_modules", ".git"}
APP = os.path.join(ROOT, "app")
VENV_SP = os.path.join(ROOT, ".venv", "Lib", "site-packages")
LIBS = [l for l in ("fastapi", "starlette", "pydantic") if os.path.isdir(os.path.join(VENV_SP, l))]

def lib_has(lib, sub):
    base = os.path.join(VENV_SP, lib, *sub.split("."))
    return os.path.isdir(base) or os.path.isfile(base + ".py")

def local_has(sub):
    p = os.path.join(APP, *sub.split("."))
    return os.path.isdir(p) or os.path.isfile(p + ".py")

imp_rx = re.compile(rb"((?:from|import)[ \t]+)app\.([A-Za-z_][\w]*(?:\.[A-Za-z_]\w*)*)")
fixed_files, subs_total, fails = [], 0, []
unknown = {}
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EXCLUDE]
    for f in fn:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        try:
            d = open(p, "rb").read()
        except OSError:
            continue

        def rep(m):
            global subs_total
            seg = m.group(2)
            head = seg.split(b".")[0].decode()
            if local_has(head):
                return m.group(0)          # genuinely our app.* module -> keep
            for lib in LIBS:
                if lib_has(lib, seg.decode()):
                    subs_total += 1
                    return m.group(1) + lib.encode() + b"." + seg
            unknown.setdefault(seg.decode(), []).append(os.path.relpath(p, ROOT))
            return m.group(0)

        n, c = imp_rx.subn(rep, d), None
        n2 = imp_rx.sub(rep, d)
        if n2 != d:
            open(p, "wb").write(n2)
            try:
                py_compile.compile(p, doraise=True)
            except Exception as e:
                open(p, "wb").write(d)
                fails.append((os.path.relpath(p, ROOT), str(e)))
                continue
            fixed_files.append(os.path.relpath(p, ROOT))

print("REVERTED:", subs_total, "in", len(fixed_files), "files")
for r in fixed_files[:20]:
    print("   ", r)
for seg, locs in unknown.items():
    print("UNRESOLVED app.%s -> %d place(s), e.g. %s" % (seg, len(locs), locs[0]))
for r, e in fails:
    print("COMPILE_FAIL(restored):", r, e)

# Where do the 36 leftover 'the model' bytes live? Show context.
tok = b"the model"
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in EXCLUDE]
    for f in fn:
        if f.endswith(".py"):
            p = os.path.join(dp, f)
            d = open(p, "rb").read()
            i = d.find(tok)
            if i >= 0:
                ln_no = d[:i].count(b"\n") + 1
                print("LEFTOVER %s:%d :: %r" % (os.path.relpath(p, ROOT), ln_no, d[max(0, i-40):i+25]))
