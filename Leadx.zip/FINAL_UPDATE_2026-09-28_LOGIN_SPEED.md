# LeadX Login Speed + Multi-User Fix

- Fixed Codespaces API race causing ~6–7s login stalls.
- Removed post-login `router.refresh()`.
- Added safe GET/HEAD API failover to forwarded port 8000.
- Optimized `/crm/me` authentication with local/JWKS JWT verification, pooled async HTTP, and short membership cache.
- Removed synchronous Supabase membership lookup from the async auth hot path.
- Tenant cache is now user-bound and cleared on sign-out.
- Existing CRM functionality and tenant authorization remain enforced.

Validation:
- Python compile: PASS
- Backend pytest: 56/56 PASS
- Frontend production build: not runnable in this environment because the supplied `node_modules` is incomplete (`next` executable missing); `npm ci` timed out while fetching dependencies.
