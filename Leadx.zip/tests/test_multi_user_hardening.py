from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_queue_claim_prefers_tenants_with_less_active_work():
    migration = (ROOT / "supabase/migrations/20261002000100_leadx_16_queue_fairness.sql").read_text()
    assert "active.status = 'running'" in migration
    assert "active.tenant_id IS NOT DISTINCT FROM j.tenant_id" in migration
    assert "FOR UPDATE SKIP LOCKED" in migration


def test_crm_client_deduplicates_reads_and_invalidates_mutations():
    crm = (ROOT / "lead-crm-portal/lib/crm.ts").read_text()
    assert "CRM_GET_CACHE" in crm
    assert "CRM_GET_INFLIGHT" in crm
    assert "invalidateCrmCache" in crm
    assert "CRM_CACHE_STALE" in crm


def test_runtime_has_separate_api_and_worker_processes():
    compose = (ROOT / "docker-compose.yml").read_text()
    assert "LEADX_PROCESS=api" in compose
    assert "LEADX_PROCESS=worker" in compose
    assert "WORKER_CONCURRENCY" in compose
