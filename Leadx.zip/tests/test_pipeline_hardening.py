from pathlib import Path

from app.layers.persistence_layer import _ensure_identity

ROOT = Path(__file__).resolve().parents[1]


def test_persistence_materializes_stable_lead_identity():
    lead = _ensure_identity({
        "name": " Acme Med Spa ",
        "phone": "+1 (512) 746-0102",
        "website": "https://www.acme.example/locations/austin",
    })
    assert lead["name"] == "Acme Med Spa"
    assert lead["phone_normalized"] == "5127460102"
    assert lead["website_domain"] == "acme.example"
    assert lead["fingerprint"]


def test_queue_and_evidence_contracts_are_durable():
    api = (ROOT / "app/api/prod/leads_api.py").read_text()
    persistence = (ROOT / "app/layers/persistence_layer.py").read_text()
    assert "threading.Thread" not in api
    assert 'max_attempts=3' in api
    assert '"value": item.get("value")' in persistence
    assert '"value_json"' not in persistence


def test_specialist_handoffs_expose_persisted_outputs():
    fabric = (ROOT / "app/integrations/prod/agent_fabric.py").read_text()
    assert "async def execute_specialized" in fabric
    assert "_persist_agent_handoff" in fabric
    assert '"persisted"' in fabric


def test_pipeline_lineage_and_database_funnel_contract():
    migration = (ROOT / "supabase/migrations/20261002000000_leadx_16_pipeline_lineage.sql").read_text()
    pipeline = (ROOT / "app/integrations/prod/pipeline.py").read_text()
    quality = (ROOT / "app/integrations/prod/quality.py").read_text()
    for field in ("mission_id", "pipeline_run_id", "raw_discovered", "unique_candidates", "verification_passed", "delivery_eligible", "selected_count", "assignment_failed", "crm_saved"):
        assert field in migration
    assert "mission_id: Optional[str] = None" in pipeline
    assert '"pipeline_run_id": run_id' in quality
    assert '"mission_id": mission_id' in quality
