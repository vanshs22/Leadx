"""Compatibility entrypoint for the LeadX 15.8 security-quality suite.

Some Codespaces runbooks reference this filename with an underscore. Keep that
entrypoint stable while the canonical implementation remains in
`test_leadx15_8_security_quality.py`.
"""
from test_leadx15_8_security_quality import *  # noqa: F401,F403
