from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_crm_mutations_validate_all_tenant_scoped_associations():
    source = (ROOT / "app/crm/crm_entities_api.py").read_text()
    assert "def _validate_associations" in source
    for field in ("company_id", "contact_id", "deal_id", "assignment_id", "stage_id", "parent_company_id"):
        assert f'"{field}"' in source
    assert "Source lead not found for this workspace" in source
    assert "_validate_associations(payload, tid)" in source


def test_lead_conversion_has_view_independent_fallback():
    source = (ROOT / "app/crm/crm_entities_api.py").read_text()
    assert "def _load_conversion_card" in source
    assert '_get_one("lead_assignments", aid, tid, "Lead")' in source
    assert "_load_conversion_card(tid, aid)" in source


def test_crm_task_completion_is_not_false_success():
    source = (ROOT / "app/crm/crm_api.py").read_text()
    assert 'if not (result.data or []):' in source
    assert 'raise HTTPException(404, "Task not found")' in source


def test_cookie_sessions_and_connector_health_are_safe():
    auth = (ROOT / "lead-crm-portal/lib/auth.ts").read_text()
    connectors = (ROOT / "app/integrations/prod/connectors.py").read_text()
    assert 'return !!(await getSessionFast())?.user' in auth
    assert 'has_credentials": bool(row.get("secret_ref"))' in connectors
    assert "assert_public_url(base)" in connectors
