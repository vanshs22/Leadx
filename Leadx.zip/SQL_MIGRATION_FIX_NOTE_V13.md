# SQL Migration Fix Note — V13

The repeated `42703: column "occurred_at" does not exist` error was caused by a duplicate table-definition collision, not by a single missing line.

`lead_outcome_events` was created earlier with `recorded_at`, then created again later with `occurred_at`. `CREATE TABLE IF NOT EXISTS` intentionally leaves the existing table unchanged, so the later schema never added `occurred_at`.

V13 resolves this at every relevant layer:

1. Root `SUPABASE_FULL_MIGRATION.sql` now reconciles both shapes.
2. Canonical migration `20260930000600_lead_intelligence_6.sql` now reconciles both shapes.
3. `occurred_at`, `recorded_at`, `assignment_id`, `note`, `signal`, `value`, `positive`, and `metadata` are explicitly present before their indexes/policies are created.
4. The contacts trigram index now uses `full_name`, matching the actual table column.
5. The previously fixed malformed multi-column `ADD COLUMN` statements remain split into valid PostgreSQL statements.
