# LeadX Runtime / Build / CRM Fix — 2026-09-28

## Fixed in this package

### Frontend build/runtime
- Removed `next/font/google` from the root layout. The existing `--font-sans`, `--font-display`, and `--font-mono` Tailwind contracts remain intact using resilient system font stacks.
- Changed the frontend dev script from `next dev --turbo` to standard `next dev`. This avoids the Codespaces compiler failure:
  `@vercel/turbopack-next/internal/font/google/font-display`.
- Frontend restart now stops stale Next :3000 processes before starting.

### CRM/API performance
- Browser GET cache increased to 30 seconds with a 5-minute stale window and request de-duplication.
- Stale cached CRM reads return immediately while a single background refresh updates the cache.
- Existing tenant/token cache isolation is preserved.
- Existing mutation cache invalidation is preserved.

### Leads / Pipeline / Reports / Dashboard 404s
- The current backend source contains and successfully imports all required routes:
  - `/crm/me`
  - `/crm/{tenant_id}/dashboard`
  - `/crm/{tenant_id}/leads`
  - `/crm/{tenant_id}/pipeline`
  - `/crm/{tenant_id}/reports/summary`
  - `/crm/{tenant_id}/reports/deals`
  - `/support/ask`
- The Codespaces runtime script now kills stale Uvicorn processes serving port 8000 and always starts the canonical `app.app_service:app` entrypoint.
- The runtime script validates the backend route contract before starting the frontend.

### LeadX Help
- Greeting/help-only messages (`hi`, `hello`, `hey`, `yo`, `help`) use the stateless `/support/ask` endpoint directly instead of first creating/loading a support conversation.
- This removes an unnecessary database round-trip and preserves the emergency Help path when support storage is degraded.
- Generic support failures are shown as a friendly temporary-unavailable message rather than exposing an internal server error.

## Verification
- Backend pytest: **56 passed**.
- Backend Python compilation: **passed**.
- Backend application import and CRM route contract: **passed; no required routes missing**.
- Shell syntax checks for runtime/restart scripts: **passed**.
- Frontend source check: no remaining `next/font/google` or `@vercel/turbopack-next` imports.
- Frontend production build could not be executed in this isolated build environment because the npm registry dependency download timed out and the offline npm cache does not contain all packages. No build result is being represented as successful.

## Codespaces startup

From the package root, run:

```bash
bash leadx-runtime-fix-2026-09-28.sh
```

This starts the canonical backend on :8000, verifies its CRM route contract, and starts the frontend on :3000.
