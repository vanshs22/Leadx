# LeadX — Discovery Approval, Monthly Quota & Global Inventory

## Client workflow
1. Client creates an ICP/discovery request.
2. Request is durable in `discovery_requests` with `pending_approval` status.
3. Client can leave the portal; the request remains visible and updates by realtime/polling.
4. Client plan `tenants.leads_per_month_limit` is the hard monthly ceiling.
5. Client may request up to their plan ceiling; admin may approve a smaller batch.
6. Admin approval requires a reason; that reason is shown to the client.
7. Approval atomically reserves the approved number of monthly lead slots.
8. Pipeline runs asynchronously and consumes only the approved reservation.
9. Unused approved reservation is released when the run completes.

## Shared global inventory
Every discovery run stores raw businesses in `leads_global` before expensive enrichment. This database is shared across tenants. A future client can receive a previously discovered business if it matches their ICP and is not blocked by tenant-level recency, suppression, or exclusivity rules.

## Deduplication
Global identity uses fingerprint plus secondary checks for normalized phone, website domain, and exact normalized name + city/state. Source provenance is retained so one business can accumulate evidence from Google, directories, OSM, web, LinkedIn, Instagram and other public sources without becoming duplicate CRM records.

## Geography
A state-level location such as `Texas` is expanded using:
- curated metro/county coverage
- free OpenStreetMap/Overpass public geography for cities/towns/villages/municipalities
- the original state-level search

This produces city-by-city partitions instead of treating a state as one search query.

## Global exhaustion ledger
`global_discovery_coverage` tracks source + geography + query partitions independently of tenants. It records pages, raw results, unique results, run count, exhaustion and last error/time. This lets Admin see which coverage partitions are exhausted across all customer runs and which frontier remains.

## Provider-budget behavior
Client approval does not expose provider credentials. Discovery uses the shared LeadX provider pool. Existing global inventory is checked first so repeated ICPs can reuse already collected businesses before spending Serper/Firecrawl requests.

## Database quota safety
`usage_log.quota_reserved` separates monthly reservations from delivered usage. Atomic PostgreSQL functions prevent approved reservations and direct/admin discovery jobs from exceeding the same monthly ceiling concurrently.
