"""
Dedup fingerprint + exclusivity geo overlap.

These tests import the REAL implementations from backend.integrations.prod.utils.
They previously defined their own local copies of normalize_phone/extract_domain/
fingerprint and asserted against those, so the suite stayed green even if the
shipped functions were deleted or broken.

Run: pytest tests/test_fingerprint_exclusivity.py -v
"""
from __future__ import annotations

from backend.integrations.prod.utils import (
    extract_domain,
    fingerprint,
    normalize_phone,
)


def geo_overlap(a: list[str], b: list[str]) -> bool:
    """Exclusivity conflict if geo sets intersect OR either is empty (global)."""
    sa, sb = set(a or []), set(b or [])
    if not sa or not sb:
        return True
    return bool(sa & sb)


# ─── Fingerprint ────────────────────────────────────────────────────────────

def test_same_business_same_fingerprint():
    """Formatting differences must not create duplicate leads."""
    a = fingerprint("Glow Med Spa", "(201) 555-0100", "https://www.glowmedspa.com/about")
    b = fingerprint("glow med spa", "2015550100", "http://glowmedspa.com")
    assert a == b


def test_different_phone_different_fingerprint():
    a = fingerprint("Glow Med Spa", "2015550100", "https://glowmedspa.com")
    b = fingerprint("Glow Med Spa", "2015550199", "https://glowmedspa.com")
    assert a != b


def test_www_stripped():
    assert fingerprint("X", None, "https://www.example.com") == fingerprint(
        "X", None, "https://example.com"
    )


def test_fingerprint_is_stable_across_calls():
    """Dedup depends on this being deterministic, not salted per-process."""
    assert fingerprint("A Co", "2015550100", "https://a.co") == fingerprint(
        "A Co", "2015550100", "https://a.co"
    )


def test_fingerprint_handles_all_missing_fields():
    assert isinstance(fingerprint("", None, None), str)


# ─── normalize_phone ────────────────────────────────────────────────────────

def test_normalize_phone_us_formats():
    for raw in ("(201) 555-0100", "201-555-0100", "201.555.0100", "+1 201 555 0100", "12015550100"):
        assert normalize_phone(raw) == "2015550100", raw


def test_normalize_phone_rejects_too_short():
    assert normalize_phone("555-0100") is None


def test_normalize_phone_empty():
    assert normalize_phone(None) is None
    assert normalize_phone("") is None


# ─── extract_domain ─────────────────────────────────────────────────────────

def test_extract_domain_strips_scheme_www_path_and_query():
    assert extract_domain("https://www.Example.com/a/b?c=1") == "example.com"


def test_extract_domain_none():
    assert extract_domain(None) is None


# ─── Exclusivity geo overlap ────────────────────────────────────────────────

def test_geo_overlap_intersecting():
    assert geo_overlap(["Newark NJ", "Hoboken NJ"], ["Hoboken NJ"]) is True


def test_geo_overlap_disjoint():
    assert geo_overlap(["Newark NJ"], ["Austin TX"]) is False


def test_geo_overlap_empty_is_global_conflict():
    assert geo_overlap([], ["Newark NJ"]) is True
    assert geo_overlap(["Newark NJ"], []) is True
