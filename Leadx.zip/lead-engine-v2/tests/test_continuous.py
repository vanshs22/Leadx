from backend.integrations.prod.continuous_discovery import expand_queries, expand_geo_labels, _cell_key

def test_query_expansion_medspa():
    qs = expand_queries("medspa")
    assert len(qs) >= 5
    assert any("botox" in q.lower() or "spa" in q.lower() for q in qs)

def test_geo_expansion_is_strict_by_default():
    """
    strict=True is the intended default: only the locations the operator asked
    for, no nearby-city expansion. Auto-expanding a single city into its
    neighbours caused multi-minute runs and surprise API spend.
    This test previously asserted the old expanding behaviour and failed.
    """
    assert expand_geo_labels(["Hoboken NJ"]) == ["Hoboken NJ"]


def test_geo_expansion_dedupes_and_trims():
    assert expand_geo_labels([" Hoboken NJ ", "hoboken nj", ""]) == ["Hoboken NJ"]


def test_geo_expansion_non_strict_expands_state():
    """Opt-in expansion still works for genuine statewide ICPs."""
    labels = expand_geo_labels(["New Jersey"], strict=False)
    assert len(labels) >= 20

def test_cell_key_stable():
    assert _cell_key("Hoboken NJ") == _cell_key("hoboken  nj")

def test_base_queries_prepended():
    qs = expand_queries("medspa", ["custom query"])
    assert qs[0] == "custom query"
