from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_runtime_repair_contains_notifications():
    sql = (ROOT / "sql" / "039_RUNTIME_SCHEMA_REPAIR.sql").read_text().lower()
    assert "create table if not exists public.notifications" in sql
    assert "idx_notifications_scope_created" in sql


def test_consolidated_migrations_contain_notifications():
    for rel in ("sql/000_ALL_IN_ONE_migration.sql", "SUPABASE_FULL_MIGRATION.sql"):
        sql = (ROOT / rel).read_text().lower()
        assert "create table if not exists public.notifications" in sql


def test_notifications_legacy_endpoint_is_preserved():
    source = (ROOT / "app" / "api" / "prod" / "ops_api.py").read_text()
    assert '/admin/notifications/unread' in source
    assert '/admin/notifications' in source
