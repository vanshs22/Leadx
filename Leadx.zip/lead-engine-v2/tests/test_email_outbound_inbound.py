"""Unit tests for outbound merge/opt-out/SES config and inbound routing (no AWS calls)."""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def test_render_merge_tags():
    from backend.integrations.prod.email_outreach import render_merge
    lead = {
        "name": "Glow Spa",
        "city": "Hoboken",
        "email": "a@b.com",
        "tier": "A",
        "_unsubscribe_url": "https://app/unsub?token=x",
    }
    out = render_merge("Hi {{company}} in {{city}} tier {{tier}} {{unsubscribe_url}}", lead)
    assert "Glow Spa" in out
    assert "Hoboken" in out
    assert "https://app/unsub" in out


def test_ses_configured_false_without_keys(monkeypatch):
    monkeypatch.delenv("AWS_ACCESS_KEY_ID", raising=False)
    monkeypatch.delenv("AWS_SECRET_ACCESS_KEY", raising=False)
    from backend.integrations.prod import ses_domain
    # reload flags
    assert ses_domain.ses_configured() is False


def test_ses_configured_true_with_keys(monkeypatch):
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIATEST")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret")
    from backend.integrations.prod import ses_domain
    assert ses_domain.ses_configured() is True


def test_ses_send_missing_from(monkeypatch):
    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "AKIATEST")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret")
    monkeypatch.delenv("SES_FROM", raising=False)
    monkeypatch.delenv("EMAIL_FROM", raising=False)
    monkeypatch.delenv("RESEND_FROM", raising=False)
    from backend.integrations.prod.ses_domain import send_via_ses
    r = asyncio.get_event_loop().run_until_complete(
        send_via_ses("a@b.com", "Hi", "<p>x</p>", from_addr=None)
    )
    assert r["ok"] is False
    assert r["error"] == "ses_from_missing"


def test_plus_tag_extracts_tenant_uuid():
    from backend.integrations.prod.inbound_email import _PLUS_TAG
    tid = "00000000-0000-0000-0000-00000000d300"
    m = _PLUS_TAG.search(f"Replies <replies+{tid}@replies.example.com>")
    assert m is not None
    assert m.group(1).lower() == tid


def test_keyword_category_optout():
    from backend.integrations.prod.inbound_email import keyword_category
    assert keyword_category("Please unsubscribe me from this list") == "opt_out"
    assert keyword_category("I'm interested, let's talk next week") == "positive"


def test_unsubscribe_token_roundtrip(monkeypatch):
    monkeypatch.setenv("UNSUBSCRIBE_SECRET", "test-secret-for-hmac-12")
    monkeypatch.setenv("PUBLIC_APP_URL", "https://app.example.com")
    from backend.integrations.prod import unsubscribe as unsub
    unsub._SECRET = b"test-secret-for-hmac-12"
    url = unsub.unsubscribe_url("tenant-1", "lead@example.com")
    assert "token=" in url
    token = url.split("token=", 1)[1]
    pair = unsub.verify_token(token)
    assert pair is not None
    tid, email = pair
    assert tid == "tenant-1"
    assert email == "lead@example.com"


def test_handle_sns_subscription_confirmation():
    from backend.integrations.prod.inbound_email import handle_sns_payload

    async def run():
        with patch("httpx.AsyncClient") as Client:
            inst = Client.return_value.__aenter__.return_value
            inst.get = AsyncMock()
            body = {
                "Type": "SubscriptionConfirmation",
                "SubscribeURL": "https://sns.example.com/confirm",
            }
            res = await handle_sns_payload(body)
            assert res.get("confirmed") is True
            inst.get.assert_awaited()

    asyncio.get_event_loop().run_until_complete(run())


def test_is_opted_out_fail_closed(monkeypatch):
    from backend.integrations.prod import email_outreach as eo

    class Boom:
        def table(self, *a, **k):
            raise RuntimeError("db down")

    monkeypatch.setattr(eo, "_sb", lambda: Boom())
    r = asyncio.get_event_loop().run_until_complete(
        eo.is_email_opted_out("t1", "a@b.com")
    )
    assert r is True  # fail closed


def test_reply_to_default_uses_reply_domain(monkeypatch):
    monkeypatch.setenv("REPLY_DOMAIN", "replies.example.com")
    from backend.integrations.prod import email_outreach as eo

    captured = {}

    async def fake_send_for_tenant(tenant_id, to, subject, html, text="", reply_to=None):
        captured["reply_to"] = reply_to
        return {"ok": True, "provider": "test"}

    async def fake_opted(*a, **k):
        return False

    async def fake_log(*a, **k):
        return None

    monkeypatch.setattr(eo, "is_email_opted_out", fake_opted)
    monkeypatch.setattr(eo, "send_for_tenant", fake_send_for_tenant)
    monkeypatch.setattr(eo, "_log_send", fake_log)
    monkeypatch.setattr(eo, "_activity", fake_log)

    # minimal assignment/lead fetch
    class SB:
        def table(self, name):
            return self
        def select(self, *a, **k):
            return self
        def eq(self, *a, **k):
            return self
        def limit(self, *a, **k):
            return self
        def execute(self):
            if not hasattr(self, "_n"):
                self._n = 0
            self._n += 1
            if self._n == 1:
                return MagicMock(data=[{"id": "as1", "lead_id": "ld1", "tenant_id": "t1"}])
            return MagicMock(data=[{
                "id": "ld1", "name": "Co", "email": "lead@co.com",
                "city": "NY", "phone": None, "website": None,
            }])

    monkeypatch.setattr(eo, "_sb", lambda: SB())
    monkeypatch.setattr(eo, "get_supabase", lambda: SB(), raising=False)

    # send_to_lead imports get_supabase via _sb only
    r = asyncio.get_event_loop().run_until_complete(
        eo.send_to_lead("00000000-0000-0000-0000-00000000d300", "as1", "Hi", "<p>x</p>")
    )
    assert r.get("ok") is True
    assert captured["reply_to"] == "replies+00000000-0000-0000-0000-00000000d300@replies.example.com"
