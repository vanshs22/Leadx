"""
API key pool: quota detection + rotation.

Regression cover for a credit-burning bug — _is_quota_error() used to
substring-match "402" / "credit" / "exceeded" against the whole error text.
Scraper errors routinely embed page content, so an address like
"402 Main Street" or a URL like "/credit-cards" marked a perfectly healthy
key as quota-exhausted and cooled it for 30 minutes.
"""
from __future__ import annotations

import pytest

from backend.integrations.prod.key_pool import (
    KeyPoolExhausted,
    _is_quota_error,
    with_key_rotation,
)


# ─── Real quota errors must be detected ─────────────────────────────────────

@pytest.mark.parametrize("msg", [
    "Serper quota/rate: 429 Too Many Requests",
    "Firecrawl quota: 402",
    'Serper quota/rate: 402 {"message":"Not enough credits"}',
    "rate limit exceeded for this key",
    "Client error '429 Too Many Requests' for url https://api.x/v1",
    "429",
    "Payment required",
    "insufficient credits remaining",
])
def test_detects_real_quota_errors(msg):
    assert _is_quota_error(Exception(msg)) is True


# ─── Incidental substrings must NOT cool a healthy key ──────────────────────

@pytest.mark.parametrize("msg", [
    "scrape ok but page text mentions 402 Main Street Suite credit union",
    "timeout fetching https://example.com/credit-cards",
    "read timeout after 402 ms",
    "SSL error connecting to 402.example.com",
    "Connection reset by peer",
    "Server error '503 Service Unavailable'",
    "DNS resolution failed",
])
def test_ignores_incidental_substrings(msg):
    assert _is_quota_error(Exception(msg)) is False


# ─── Rotation behaviour ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_returns_result_on_first_success(monkeypatch):
    import backend.integrations.prod.key_pool as kp
    monkeypatch.setattr(kp, "get_active_key", _fake_keys(["k1"]))
    monkeypatch.setattr(kp, "increment_usage", _noop)

    calls = []

    async def call_fn(key):
        calls.append(key)
        return f"ok:{key}"

    assert await with_key_rotation("serper", call_fn) == "ok:k1"
    assert calls == ["k1"], "should not retry after success"


@pytest.mark.asyncio
async def test_rotates_to_next_key_on_quota(monkeypatch):
    import backend.integrations.prod.key_pool as kp
    monkeypatch.setattr(kp, "get_active_key", _fake_keys(["k1", "k2"]))
    monkeypatch.setattr(kp, "increment_usage", _noop)
    monkeypatch.setattr(kp, "mark_quota_error", _noop4)

    seen = []

    async def call_fn(key):
        seen.append(key)
        if key == "k1":
            raise Exception("429 Too Many Requests")
        return "ok"

    assert await with_key_rotation("serper", call_fn) == "ok"
    assert seen == ["k1", "k2"]


@pytest.mark.asyncio
async def test_non_quota_error_propagates_without_burning_keys(monkeypatch):
    """A bug in our own code must not be mistaken for exhausted quota."""
    import backend.integrations.prod.key_pool as kp
    monkeypatch.setattr(kp, "get_active_key", _fake_keys(["k1", "k2"]))
    monkeypatch.setattr(kp, "increment_usage", _noop)

    cooled = []

    async def track(provider, key, err, cooldown=30):
        cooled.append(key)

    monkeypatch.setattr(kp, "mark_quota_error", track)

    async def call_fn(key):
        raise ValueError("bug in our parsing code")

    with pytest.raises(ValueError):
        await with_key_rotation("serper", call_fn)
    assert cooled == [], "non-quota failure must not cool any key"


@pytest.mark.asyncio
async def test_raises_when_all_keys_exhausted(monkeypatch):
    import backend.integrations.prod.key_pool as kp
    monkeypatch.setattr(kp, "get_active_key", _fake_keys(["k1"]))
    monkeypatch.setattr(kp, "increment_usage", _noop)
    monkeypatch.setattr(kp, "mark_quota_error", _noop4)

    async def call_fn(key):
        raise Exception("429 quota")

    with pytest.raises(KeyPoolExhausted):
        await with_key_rotation("serper", call_fn)


# ─── helpers ────────────────────────────────────────────────────────────────

def _fake_keys(keys: list[str]):
    """get_active_key stub that hands out `keys` in order, then repeats the last."""
    seq = list(keys)

    async def _get(provider):
        return (seq.pop(0) if len(seq) > 1 else seq[0]), None

    return _get


async def _noop(*a, **kw):
    return None


async def _noop4(provider, key, err, cooldown=30):
    return None
