-- LeadX CRM revenue graph upgrade. Idempotent.

-- 1) Parent/child account hierarchy.
ALTER TABLE companies ADD COLUMN IF NOT EXISTS parent_company_id uuid REFERENCES companies(id) ON DELETE SET NULL;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS lifecycle_stage text NOT NULL DEFAULT 'prospect';
ALTER TABLE companies ADD COLUMN IF NOT EXISTS health_score int CHECK (health_score IS NULL OR health_score BETWEEN 0 AND 100);
ALTER TABLE companies ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;
ALTER TABLE companies ADD COLUMN IF NOT EXISTS next_action_at timestamptz;
CREATE INDEX IF NOT EXISTS idx_companies_parent ON companies(parent_company_id) WHERE parent_company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_lifecycle ON companies(tenant_id,lifecycle_stage);

-- 2) First-class physical locations for franchises/multi-location accounts.
CREATE TABLE IF NOT EXISTS company_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name text,
  address text,
  city text,
  state text,
  country text,
  postal_code text,
  phone text,
  website text,
  latitude numeric(10,7),
  longitude numeric(10,7),
  is_primary boolean NOT NULL DEFAULT false,
  source text,
  source_key text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_company_locations_company ON company_locations(company_id);
CREATE INDEX IF NOT EXISTS idx_company_locations_geo ON company_locations(state,city);

-- 3) Contact role/influence graph.
CREATE TABLE IF NOT EXISTS contact_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
  role_type text NOT NULL,
  influence_score int CHECK (influence_score IS NULL OR influence_score BETWEEN 0 AND 100),
  buying_authority int CHECK (buying_authority IS NULL OR buying_authority BETWEEN 0 AND 100),
  verified_at timestamptz,
  evidence jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,contact_id,role_type)
);
CREATE INDEX IF NOT EXISTS idx_contact_roles_company ON contact_roles(tenant_id,role_type,influence_score DESC);
ALTER TABLE contacts ADD COLUMN IF NOT EXISTS timezone text;
ALTER TABLE contacts ADD COLUMN IF NOT EXISTS last_verified_at timestamptz;
ALTER TABLE contacts ADD COLUMN IF NOT EXISTS influence_score int CHECK (influence_score IS NULL OR influence_score BETWEEN 0 AND 100);
ALTER TABLE contacts ADD COLUMN IF NOT EXISTS persona text;

-- 4) Deal health/risk/next action.
ALTER TABLE deals ADD COLUMN IF NOT EXISTS health_score int CHECK (health_score IS NULL OR health_score BETWEEN 0 AND 100);
ALTER TABLE deals ADD COLUMN IF NOT EXISTS risk_flags jsonb NOT NULL DEFAULT '[]';
ALTER TABLE deals ADD COLUMN IF NOT EXISTS next_action_at timestamptz;
ALTER TABLE deals ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;
ALTER TABLE deals ADD COLUMN IF NOT EXISTS competitor text;
CREATE INDEX IF NOT EXISTS idx_deals_health ON deals(tenant_id,health_score);
CREATE INDEX IF NOT EXISTS idx_deals_next_action ON deals(tenant_id,next_action_at) WHERE status='open';

-- 5) SLA-aware tasks/reminders/recurrence.
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS sla_due_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS reminder_at timestamptz;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS recurring_rule text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS snoozed_until timestamptz;
CREATE INDEX IF NOT EXISTS idx_tasks_sla ON tasks(tenant_id,status,sla_due_at) WHERE status='open';

-- 6) Activity channel + external idempotency.
ALTER TABLE activities ADD COLUMN IF NOT EXISTS channel text;
ALTER TABLE activities ADD COLUMN IF NOT EXISTS external_id text;
CREATE UNIQUE INDEX IF NOT EXISTS idx_activities_external ON activities(tenant_id,external_id) WHERE external_id IS NOT NULL;

-- 7) Lead lifecycle / routing metadata.
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS owner text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS lifecycle_stage text NOT NULL DEFAULT 'new';
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS next_action_at timestamptz;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS last_replied_at timestamptz;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS source_campaign_id uuid;
CREATE INDEX IF NOT EXISTS idx_assignments_lifecycle ON lead_assignments(tenant_id,lifecycle_stage,next_action_at);

-- 8) Revenue attribution snapshots.
CREATE TABLE IF NOT EXISTS revenue_attribution (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  deal_id uuid REFERENCES deals(id) ON DELETE SET NULL,
  source text,
  campaign_id uuid,
  first_touch_at timestamptz,
  last_touch_at timestamptz,
  attribution_weight numeric(8,5) NOT NULL DEFAULT 1,
  attributed_value numeric(16,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_revenue_attribution_tenant ON revenue_attribution(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_revenue_attribution_deal ON revenue_attribution(deal_id);

-- 9) Forecast snapshots.
CREATE TABLE IF NOT EXISTS forecast_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  period_start date NOT NULL,
  period_end date NOT NULL,
  pipeline_value numeric(16,2) NOT NULL DEFAULT 0,
  weighted_value numeric(16,2) NOT NULL DEFAULT 0,
  won_value numeric(16,2) NOT NULL DEFAULT 0,
  open_deals int NOT NULL DEFAULT 0,
  generated_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_forecast_tenant_period ON forecast_snapshots(tenant_id,period_end DESC);

-- 10) Prospect audits / shareable sales artifacts.
CREATE TABLE IF NOT EXISTS prospect_audits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  company_id uuid REFERENCES companies(id) ON DELETE SET NULL,
  public_token text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  title text,
  summary text,
  sections jsonb NOT NULL DEFAULT '{}',
  expires_at timestamptz,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_prospect_audits_tenant ON prospect_audits(tenant_id,created_at DESC);

NOTIFY pgrst, 'reload schema';
