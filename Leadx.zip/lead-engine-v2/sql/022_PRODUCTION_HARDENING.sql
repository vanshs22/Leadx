
-- ---------------------------------------------------------------------------
-- Evidence-first intelligence fields. Existing score remains compatible;
-- these fields expose why a lead is an opportunity rather than replacing the
-- customer's existing score/tier contract.
-- ---------------------------------------------------------------------------
ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS fit_score int,
  ADD COLUMN IF NOT EXISTS opportunity_score int,
  ADD COLUMN IF NOT EXISTS contactability_score int,
  ADD COLUMN IF NOT EXISTS opportunity_score_overall int,
  ADD COLUMN IF NOT EXISTS opportunity_evidence jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS intelligence_confidence numeric(4,3);
