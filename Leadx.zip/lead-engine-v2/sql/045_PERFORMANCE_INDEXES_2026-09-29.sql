-- LeadX hot-path indexes. Safe to re-run; all are non-destructive.
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_stage_score
  ON public.lead_assignments (tenant_id, stage_id, score DESC);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_delivered
  ON public.lead_assignments (tenant_id, delivered_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_status
  ON public.lead_assignments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_pipeline_stages_tenant_position
  ON public.pipeline_stages (tenant_id, position);
CREATE INDEX IF NOT EXISTS idx_lead_activities_tenant_created
  ON public.lead_activities (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_tasks_tenant_status_due
  ON public.lead_tasks (tenant_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_tenant_seen_leads_tenant_fp
  ON public.tenant_seen_leads (tenant_id, fingerprint);
CREATE INDEX IF NOT EXISTS idx_enrichment_lead_extracted
  ON public.enrichment (lead_id, extracted_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_global_fingerprint
  ON public.leads_global (fingerprint);
CREATE INDEX IF NOT EXISTS idx_leads_global_domain_name
  ON public.leads_global (website_domain, name_normalized);
