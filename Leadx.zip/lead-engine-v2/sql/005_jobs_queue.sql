-- ============================================================================
-- jobs — the Postgres-backed work queue drained by `python -m app.worker`.
--
-- This table had NO migration anywhere in the repo: app/integrations/prod/jobs.py
-- reads and writes it, but nothing ever created it, so a fresh database made the
-- worker fail on its first claim_next() with PGRST205 "Could not find the table
-- public.jobs". Columns below are derived from jobs.py (enqueue / claim_next /
-- complete / fail / reap_stale / retry_job / cancel_job).
--
-- Idempotent: safe to re-run.
-- ============================================================================

create table if not exists jobs (
  id           uuid primary key default gen_random_uuid(),
  tenant_id    uuid,
  kind         text        not null,
  payload      jsonb       not null default '{}',
  -- queued -> running -> done | failed | cancelled
  status       text        not null default 'queued',
  priority     int         not null default 0,
  attempts     int         not null default 0,
  max_attempts int         not null default 3,
  -- Delay/backoff: claim_next only takes rows whose run_after has passed.
  run_after    timestamptz not null default now(),
  created_by   text                 default 'api',
  -- Lock held by a worker while status='running'; locked_at drives reap_stale.
  locked_by    text,
  locked_at    timestamptz,
  started_at   timestamptz,
  finished_at  timestamptz,
  result       jsonb,
  error        text,
  created_at   timestamptz not null default now()
);

-- Backfill for databases where an older, narrower `jobs` already exists.
alter table jobs add column if not exists tenant_id    uuid;
alter table jobs add column if not exists payload      jsonb       not null default '{}';
alter table jobs add column if not exists status       text        not null default 'queued';
alter table jobs add column if not exists priority     int         not null default 0;
alter table jobs add column if not exists attempts     int         not null default 0;
alter table jobs add column if not exists max_attempts int         not null default 3;
alter table jobs add column if not exists run_after    timestamptz not null default now();
alter table jobs add column if not exists created_by   text                 default 'api';
alter table jobs add column if not exists locked_by    text;
alter table jobs add column if not exists locked_at    timestamptz;
alter table jobs add column if not exists started_at   timestamptz;
alter table jobs add column if not exists finished_at  timestamptz;
alter table jobs add column if not exists result       jsonb;
alter table jobs add column if not exists error        text;
alter table jobs add column if not exists created_at   timestamptz not null default now();

-- The claim path: status='queued' and run_after <= now(), ordered by
-- priority desc, created_at asc. Partial index keeps it small — done/failed
-- rows accumulate but are never scanned by the hot query.
create index if not exists idx_jobs_claim
  on jobs (priority desc, created_at)
  where status = 'queued';

-- enqueue_unique's precheck: kind + status in (queued, running).
create index if not exists idx_jobs_kind_status on jobs (kind, status);

-- reap_stale: status='running' and locked_at < cutoff.
create index if not exists idx_jobs_stale on jobs (locked_at) where status = 'running';

-- Admin job monitor listing (ops_api list_jobs): newest first, filterable.
create index if not exists idx_jobs_created  on jobs (created_at desc);
create index if not exists idx_jobs_tenant   on jobs (tenant_id, created_at desc);

-- Operator-only table: reached exclusively through the service key, never with
-- a tenant JWT. RLS is therefore left off deliberately — enabling it without a
-- policy would silently stop the worker from seeing any rows at all.

-- Housekeeping (optional): keep the table from growing without bound.
--   delete from jobs
--    where status in ('done','cancelled')
--      and finished_at < now() - interval '14 days';
