-- 043_CRM_PORTAL_SCHEMA_GAPS.sql
-- Pipeline stages, seed RPC, email settings, activities.
-- Fixed: DROP FUNCTION before recreate (avoids 42P13 return type error).

CREATE TABLE IF NOT EXISTS public.pipeline_stages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  name text NOT NULL,
  slug text NOT NULL,
  position int DEFAULT 0,
  color text DEFAULT '#94a3b8',
  is_won boolean DEFAULT false,
  is_lost boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE (tenant_id, slug)
);
CREATE INDEX IF NOT EXISTS pipeline_stages_tenant_idx ON public.pipeline_stages (tenant_id);

-- Must DROP first if an older overload exists with a different return type
DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);
DROP FUNCTION IF EXISTS public.seed_default_stages(p_tenant_id uuid);

CREATE OR REPLACE FUNCTION public.seed_default_stages(p_tenant_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.pipeline_stages (tenant_id, name, slug, position, color, is_won, is_lost)
  VALUES
    (p_tenant_id, 'New', 'new', 0, '#94a3b8', false, false),
    (p_tenant_id, 'Contacted', 'contacted', 1, '#3b82f6', false, false),
    (p_tenant_id, 'Qualified', 'qualified', 2, '#8b5cf6', false, false),
    (p_tenant_id, 'Proposal', 'proposal', 3, '#f59e0b', false, false),
    (p_tenant_id, 'Negotiation', 'negotiation', 4, '#f97316', false, false),
    (p_tenant_id, 'Won', 'won', 5, '#22c55e', true, false),
    (p_tenant_id, 'Lost', 'lost', 6, '#ef4444', false, true)
  ON CONFLICT (tenant_id, slug) DO NOTHING;
END;
$$;

CREATE TABLE IF NOT EXISTS public.tenant_email_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL UNIQUE,
  domain text,
  from_email text,
  from_name text,
  reply_to text,
  domain_verified boolean DEFAULT false,
  dkim_tokens jsonb DEFAULT '[]'::jsonb,
  dkim_status text,
  verification_status text,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  assignment_id uuid,
  lead_id uuid,
  activity_type text,
  body text,
  meta jsonb DEFAULT '{}'::jsonb,
  created_by text,
  created_at timestamptz DEFAULT now()
);

NOTIFY pgrst, 'reload schema';
