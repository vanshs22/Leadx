-- ============================================================================
-- Admin-as-a-tenant + scheduled automation.
--
-- Three things, all idempotent:
--
--  1. tenants.is_operator — operator_pipeline.py has always written this column
--     ("LeadX (internal)" tenant) but NO migration ever created it. So
--     get_operator_tenant() logged "is_operator column missing?" and returned
--     None, ensure_operator_tenant() then failed its insert, and the admin's own
--     prospecting raised RuntimeError on every call. It has never worked.
--
--  2. campaign_schedules — recurring lead-finding. The worker had exactly two
--     self-scheduled kinds (sequences.process_due, alerts.run); nothing could
--     run discovery on a cadence, so "automated lead finding" required a human
--     to press Run. A schedule row is (who, what to search, how often, which
--     sequence to drop the results into).
--
--  3. lead_assignments.assigned_to index — the column exists and the CRM filters
--     on it, but there was no index behind that filter.
-- ============================================================================

alter table tenants add column if not exists is_operator boolean not null default false;

-- Only one internal tenant may exist; operator_pipeline picks `.limit(1)` and a
-- second row would make which-one-you-get depend on row order.
create unique index if not exists idx_tenants_single_operator
  on tenants (is_operator) where is_operator;

-- is_operator rows must stay out of client-facing tenant lists.
create index if not exists idx_tenants_client_facing on tenants (created_at desc)
  where not is_operator;


create table if not exists campaign_schedules (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     uuid not null references tenants(id) on delete cascade,
  name          text not null,
  -- What to run. icp_id wins when set; otherwise industry/locations/queries are
  -- passed straight through to run_pipeline. Deliberately plain uuid, not FKs:
  -- this file must apply cleanly regardless of whether icp_profiles /
  -- email_sequences were created by an earlier migration in this database.
  icp_id        uuid,
  industry      text,
  locations     jsonb not null default '[]',
  queries       jsonb not null default '[]',
  -- Extra run_pipeline kwargs (source toggles, limits). Filtered against the
  -- real signature before use — a stale key here would TypeError the job.
  params        jsonb not null default '{}',
  target_new_leads int not null default 25,
  -- Cadence. interval_hours=24 → daily. Deliberately not cron syntax: a single
  -- interval is what the UI offers and what the worker tick can honour.
  interval_hours int not null default 24 check (interval_hours >= 1),
  -- The automation link: newly assigned leads are enrolled into this sequence,
  -- so discovery → outreach → follow-up → auto-stop-on-reply needs no human.
  -- Null = discover only, leave them in the CRM.
  auto_enroll_sequence_id uuid,
  active        boolean not null default true,
  last_run_at   timestamptz,
  last_status   text,
  last_result   jsonb,
  next_run_at   timestamptz not null default now(),
  created_by    text default 'admin',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- The tick query: active and next_run_at <= now(). Partial index stays small
-- as paused schedules accumulate.
create index if not exists idx_schedules_due on campaign_schedules (next_run_at)
  where active;
create index if not exists idx_schedules_tenant on campaign_schedules (tenant_id, created_at desc);

-- Backfills for an older campaign_schedules.
alter table campaign_schedules add column if not exists params jsonb not null default '{}';
alter table campaign_schedules add column if not exists auto_enroll_sequence_id uuid;
alter table campaign_schedules add column if not exists last_status text;
alter table campaign_schedules add column if not exists last_result jsonb;
alter table campaign_schedules add column if not exists created_by text default 'admin';

-- Operator-only table, reached with the service key. RLS left off deliberately,
-- same reasoning as jobs (005): enabling it without a policy would make the
-- worker see zero due schedules and automation would silently stop.

create index if not exists idx_assignments_assigned_to
  on lead_assignments (tenant_id, assigned_to) where assigned_to is not null;
