-- =============================================================================
-- 040_FIX_NOTIFICATIONS_AND_RUNTIME_GAPS.sql
-- Safe, idempotent. Does NOT drop or alter data in existing tables.
-- Fixes PGRST205: public.notifications (and related runtime gaps if absent).
-- Run in Supabase SQL Editor, then:  NOTIFY pgrst, 'reload schema';
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1) notifications (admin + tenant in-app feed)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope       text NOT NULL DEFAULT 'tenant'
                CHECK (scope IN ('tenant', 'admin')),
  tenant_id   uuid,
  kind        text NOT NULL,
  severity    text NOT NULL DEFAULT 'info'
                CHECK (severity IN ('info', 'warning', 'critical')),
  title       text NOT NULL,
  body        text NOT NULL DEFAULT '',
  link        text,
  meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Add any missing columns if an older partial table exists
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS scope text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS kind text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS severity text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS body text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS link text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS read_at timestamptz;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_notifications_scope_created
  ON public.notifications (scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_tenant_unread
  ON public.notifications (tenant_id, created_at DESC)
  WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_notifications_admin_unread
  ON public.notifications (scope, created_at DESC)
  WHERE scope = 'admin' AND read_at IS NULL;

-- Service-role access (API uses service key). Does not drop existing rows.
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_all_notifications" ON public.notifications;
CREATE POLICY "service_all_notifications"
  ON public.notifications
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ---------------------------------------------------------------------------
-- 2) email_replies (admin Replies) — only create if missing
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.email_replies (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL,
  assignment_id uuid,
  lead_id       uuid,
  from_email    text,
  to_email      text,
  subject       text,
  body_text     text,
  category      text DEFAULT 'unclassified',
  provider      text,
  message_id    text,
  metadata      jsonb NOT NULL DEFAULT '{}'::jsonb,
  raw           jsonb NOT NULL DEFAULT '{}'::jsonb,
  received_at   timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.email_replies ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE public.email_replies ADD COLUMN IF NOT EXISTS from_email text;
ALTER TABLE public.email_replies ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE public.email_replies ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE public.email_replies ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE public.email_replies ADD COLUMN IF NOT EXISTS received_at timestamptz;
CREATE INDEX IF NOT EXISTS idx_email_replies_tenant_received
  ON public.email_replies (tenant_id, received_at DESC);

-- ---------------------------------------------------------------------------
-- 3) campaign_schedules (admin Automation)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.campaign_schedules (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL,
  name            text,
  icp_id          uuid,
  industry        text,
  locations       jsonb NOT NULL DEFAULT '[]'::jsonb,
  queries         jsonb NOT NULL DEFAULT '[]'::jsonb,
  params          jsonb NOT NULL DEFAULT '{}'::jsonb,
  target_new_leads int NOT NULL DEFAULT 25,
  interval_hours  int NOT NULL DEFAULT 24,
  auto_enroll_sequence_id uuid,
  active          boolean NOT NULL DEFAULT true,
  last_run_at     timestamptz,
  last_status     text,
  last_result     jsonb,
  next_run_at     timestamptz NOT NULL DEFAULT now(),
  created_by      text DEFAULT 'admin',
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.campaign_schedules ADD COLUMN IF NOT EXISTS params jsonb;
ALTER TABLE public.campaign_schedules ADD COLUMN IF NOT EXISTS auto_enroll_sequence_id uuid;
ALTER TABLE public.campaign_schedules ADD COLUMN IF NOT EXISTS last_status text;
ALTER TABLE public.campaign_schedules ADD COLUMN IF NOT EXISTS last_result jsonb;
ALTER TABLE public.campaign_schedules ADD COLUMN IF NOT EXISTS next_run_at timestamptz;
CREATE INDEX IF NOT EXISTS idx_schedules_due_040
  ON public.campaign_schedules (next_run_at) WHERE active;
CREATE INDEX IF NOT EXISTS idx_schedules_tenant_040
  ON public.campaign_schedules (tenant_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- 4) autonomous_campaigns + daily ledger
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.autonomous_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  name text NOT NULL,
  icp_id uuid,
  sequence_id uuid,
  status text NOT NULL DEFAULT 'draft',
  locations jsonb NOT NULL DEFAULT '[]'::jsonb,
  queries jsonb NOT NULL DEFAULT '[]'::jsonb,
  offer text,
  goal text,
  daily_new_lead_limit int NOT NULL DEFAULT 25,
  daily_email_limit int NOT NULL DEFAULT 25,
  max_active_enrollments int NOT NULL DEFAULT 5000,
  send_window_start time NOT NULL DEFAULT '09:00',
  send_window_end time NOT NULL DEFAULT '17:00',
  timezone text NOT NULL DEFAULT 'America/New_York',
  generate_ai_copy boolean NOT NULL DEFAULT true,
  auto_followup boolean NOT NULL DEFAULT true,
  stop_on_reply boolean NOT NULL DEFAULT true,
  stop_on_optout boolean NOT NULL DEFAULT true,
  require_verified_email boolean NOT NULL DEFAULT true,
  score_threshold int NOT NULL DEFAULT 70,
  schedule_hours int NOT NULL DEFAULT 24,
  next_discovery_at timestamptz,
  last_discovery_at timestamptz,
  last_discovery_result jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.autonomous_campaigns ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE public.autonomous_campaigns ADD COLUMN IF NOT EXISTS next_discovery_at timestamptz;
ALTER TABLE public.autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_result jsonb;

CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_tenant_040
  ON public.autonomous_campaigns (tenant_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_due_040
  ON public.autonomous_campaigns (next_discovery_at) WHERE status = 'active';

CREATE TABLE IF NOT EXISTS public.autonomous_campaign_daily (
  campaign_id uuid NOT NULL REFERENCES public.autonomous_campaigns(id) ON DELETE CASCADE,
  day date NOT NULL,
  leads_discovered int NOT NULL DEFAULT 0,
  emails_sent int NOT NULL DEFAULT 0,
  emails_reserved int NOT NULL DEFAULT 0,
  replies int NOT NULL DEFAULT 0,
  positive_replies int NOT NULL DEFAULT 0,
  meetings int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (campaign_id, day)
);

-- Optional columns on existing tables (no-op if table missing)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='lead_assignments') THEN
    ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS source_campaign_id uuid;
    ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS lifecycle_stage text;
    ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS last_replied_at timestamptz;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='email_sends') THEN
    ALTER TABLE public.email_sends ADD COLUMN IF NOT EXISTS campaign_id uuid;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='email_sequence_enrollments') THEN
    ALTER TABLE public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS campaign_id uuid;
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
