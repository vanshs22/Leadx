-- Evidence-grounded AI briefs and next-best actions
CREATE TABLE IF NOT EXISTS lead_ai_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  model_version text NOT NULL,
  summary text,
  why_now jsonb NOT NULL DEFAULT '[]',
  next_best_actions jsonb NOT NULL DEFAULT '[]',
  scores jsonb NOT NULL DEFAULT '{}',
  confidence numeric(5,4),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_ai_briefs_lead ON lead_ai_briefs(lead_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_ai_briefs_tenant ON lead_ai_briefs(tenant_id,created_at DESC);

CREATE TABLE IF NOT EXISTS intelligence_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid,
  signal text NOT NULL,
  feedback text NOT NULL,
  actor_id text,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_intelligence_feedback_tenant ON intelligence_feedback(tenant_id,created_at DESC);
