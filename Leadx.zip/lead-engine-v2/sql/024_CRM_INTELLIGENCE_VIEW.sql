-- Expose opportunity intelligence to the CRM without requiring another API
-- query. Safe to reapply after 020_crm_lead_cards.sql.
DROP VIEW IF EXISTS crm_lead_cards CASCADE;
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  la.tenant_id, la.id AS assignment_id, la.lead_id,
  lg.name AS company_name, lg.name AS name, lg.category, lg.category AS industry,
  la.vertical, la.offer_category,
  la.stage_id, COALESCE(ps.slug, la.stage_slug, 'new') AS stage_slug,
  COALESCE(ps.name, initcap(COALESCE(la.stage_slug, 'New'))) AS stage_name,
  ps.color AS stage_color, ps.position AS stage_position,
  COALESCE(ps.is_won,false) AS stage_is_won, COALESCE(ps.is_lost,false) AS stage_is_lost,
  la.status AS assignment_status, la.status, la.priority, la.assigned_to,
  la.assigned_at, la.delivered_at, la.delivery_channel, la.delivery_status,
  la.delivery_error, la.next_action_at, la.last_contacted_at, la.value_estimate,
  COALESCE(la.custom_fields,'{}'::jsonb) AS custom_fields,
  COALESCE(la.tags,'{}'::text[]) AS tags, la.notes, la.icp_id, la.geo_tags,
  la.exclusive_until, la.first_touch_status, la.first_touch_at, la.first_touch_channel,
  la.created_at,
  COALESCE(s.total_score,0) AS total_score, COALESCE(s.total_score,0) AS score,
  s.deterministic_score, s.llm_score, COALESCE(s.tier,la.tier,'C') AS tier,
  s.reasoning AS score_reasoning, s.scored_at,
  COALESCE(s.intent_score,e.intent_score,0) AS intent_score,
  s.fit_score, s.opportunity_score, s.contactability_score,
  s.opportunity_score_overall, COALESCE(s.opportunity_evidence,'[]'::jsonb) AS opportunity_evidence,
  s.intelligence_confidence,
  COALESCE(lg.phone_e164,lg.phone_normalized,e.phone_from_web) AS phone,
  lg.phone_normalized, lg.phone_e164, e.phone_from_web,
  COALESCE(e.email,lg.email) AS email, e.email_valid, COALESCE(e.emails,'{}'::text[]) AS emails,
  lg.website, lg.website_domain, lg.website_domain AS domain,
  lg.address, lg.city, lg.state, lg.business_status, lg.google_rating, lg.review_count,
  lg.google_place_id, lg.source, lg.source_url,
  COALESCE(e.has_booking,false) AS has_booking, e.booking_platform, e.services,
  e.social_links, e.owner_name, e.enrichment_ok, e.pitch_line,
  COALESCE(e.raw_extraction->'why_now','[]'::jsonb) AS why_now
FROM lead_assignments la
JOIN leads_global lg ON lg.id=la.lead_id
LEFT JOIN enrichment e ON e.lead_id=la.lead_id
LEFT JOIN scores s ON s.lead_id=la.lead_id
LEFT JOIN pipeline_stages ps ON ps.id=la.stage_id AND ps.tenant_id=la.tenant_id;

GRANT SELECT ON crm_lead_cards TO authenticated, service_role;
