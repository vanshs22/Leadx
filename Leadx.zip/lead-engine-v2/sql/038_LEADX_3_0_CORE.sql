ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS active_jobs integer NOT NULL DEFAULT 0;

-- LeadX 3.0 core: security, observability, evidence, opportunity, compliance,
-- automation, learning and product analytics. Backend-owned tables use the
-- service role; tenant-facing access remains through authenticated APIs.

CREATE TABLE IF NOT EXISTS platform_admins (
  user_id uuid PRIMARY KEY,
  email text,
  role text NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin','admin','ops','support','finance','analyst')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id text,
  actor_type text NOT NULL DEFAULT 'system',
  tenant_id uuid,
  action text NOT NULL,
  resource_type text,
  resource_id text,
  before_state jsonb,
  after_state jsonb,
  reason text,
  ip_address inet,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_log_tenant_time ON audit_log(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_resource ON audit_log(resource_type,resource_id,created_at DESC);

CREATE TABLE IF NOT EXISTS security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  severity text NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','high','critical')),
  event_type text NOT NULL,
  actor_id text,
  tenant_id uuid,
  ip_address inet,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_security_events_time ON security_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity,created_at DESC);

CREATE TABLE IF NOT EXISTS queue_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  queue_name text NOT NULL,
  queued integer NOT NULL DEFAULT 0,
  running integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  oldest_queued_seconds integer NOT NULL DEFAULT 0,
  throughput_per_minute numeric(12,2) NOT NULL DEFAULT 0,
  captured_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_queue_metrics_time ON queue_metrics(queue_name,captured_at DESC);

CREATE TABLE IF NOT EXISTS provider_health (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  operation text NOT NULL DEFAULT 'default',
  status text NOT NULL DEFAULT 'healthy',
  success_count bigint NOT NULL DEFAULT 0,
  failure_count bigint NOT NULL DEFAULT 0,
  latency_ms numeric(12,2) NOT NULL DEFAULT 0,
  estimated_cost numeric(16,6) NOT NULL DEFAULT 0,
  last_error text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(provider,operation)
);

CREATE TABLE IF NOT EXISTS data_lineage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  field_name text,
  value_hash text,
  source text NOT NULL,
  source_url text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  confidence numeric(6,5),
  metadata jsonb NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_data_lineage_entity ON data_lineage(entity_type,entity_id,observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_data_lineage_source ON data_lineage(source,observed_at DESC);

CREATE TABLE IF NOT EXISTS lead_signals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  signal_type text NOT NULL,
  strength numeric(6,3) NOT NULL DEFAULT 0,
  confidence numeric(6,5) NOT NULL DEFAULT 0.5,
  observed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  source text,
  evidence jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'active'
);
CREATE INDEX IF NOT EXISTS idx_lead_signals_lead ON lead_signals(lead_id,observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_signals_type ON lead_signals(signal_type,strength DESC);

CREATE TABLE IF NOT EXISTS lead_opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  recipe_id text,
  opportunity_type text NOT NULL,
  fit_score numeric(6,2) NOT NULL DEFAULT 0,
  need_score numeric(6,2) NOT NULL DEFAULT 0,
  timing_score numeric(6,2) NOT NULL DEFAULT 0,
  contactability_score numeric(6,2) NOT NULL DEFAULT 0,
  evidence_score numeric(6,2) NOT NULL DEFAULT 0,
  overall_score numeric(6,2) NOT NULL DEFAULT 0,
  confidence numeric(6,5) NOT NULL DEFAULT 0.5,
  why_now jsonb NOT NULL DEFAULT '[]',
  recommended_action text,
  evidence jsonb NOT NULL DEFAULT '[]',
  model_version text NOT NULL DEFAULT 'leadx-opportunity-v1',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_opportunities_lead ON lead_opportunities(lead_id,overall_score DESC,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_opportunities_tenant ON lead_opportunities(tenant_id,overall_score DESC);

CREATE TABLE IF NOT EXISTS contact_graph_edges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  company_id uuid,
  contact_id uuid,
  role text,
  influence numeric(6,2),
  authority numeric(6,2),
  confidence numeric(6,5) DEFAULT 0.5,
  evidence jsonb NOT NULL DEFAULT '{}',
  observed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_contact_graph_company ON contact_graph_edges(company_id,observed_at DESC);

CREATE TABLE IF NOT EXISTS company_change_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid,
  event_type text NOT NULL,
  before_value jsonb,
  after_value jsonb,
  confidence numeric(6,5) DEFAULT 0.5,
  source text,
  observed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_company_changes_lead ON company_change_events(lead_id,observed_at DESC);

CREATE TABLE IF NOT EXISTS website_audits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  url text,
  booking_score numeric(6,2),
  conversion_score numeric(6,2),
  seo_score numeric(6,2),
  mobile_score numeric(6,2),
  speed_score numeric(6,2),
  trust_score numeric(6,2),
  technologies jsonb NOT NULL DEFAULT '[]',
  issues jsonb NOT NULL DEFAULT '[]',
  evidence jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_website_audits_lead ON website_audits(lead_id,created_at DESC);

CREATE TABLE IF NOT EXISTS technographics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  technology text NOT NULL,
  category text,
  confidence numeric(6,5) DEFAULT 0.5,
  source text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(lead_id,technology)
);
CREATE INDEX IF NOT EXISTS idx_technographics_tech ON technographics(technology,confidence DESC);

CREATE TABLE IF NOT EXISTS lead_quality_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  assignment_id uuid NOT NULL,
  issue_type text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  evidence jsonb NOT NULL DEFAULT '{}',
  resolution text,
  replacement_assignment_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_quality_reports_tenant ON lead_quality_reports(tenant_id,status,created_at DESC);

CREATE TABLE IF NOT EXISTS lead_replacement_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  original_assignment_id uuid NOT NULL,
  replacement_assignment_id uuid,
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS campaign_guardrails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  campaign_id uuid,
  max_leads_per_day integer,
  max_emails_per_day integer,
  max_cost_per_day numeric(16,2),
  max_bounce_pct numeric(6,3) DEFAULT 5,
  max_complaint_pct numeric(6,3) DEFAULT 0.2,
  max_ai_cost_per_day numeric(16,2),
  enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(campaign_id)
);

CREATE TABLE IF NOT EXISTS email_domain_health (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  domain text NOT NULL,
  spf_ok boolean,
  dkim_ok boolean,
  dmarc_ok boolean,
  mx_ok boolean,
  bounce_pct numeric(7,3) DEFAULT 0,
  complaint_pct numeric(7,3) DEFAULT 0,
  sent_count bigint DEFAULT 0,
  last_checked_at timestamptz,
  status text NOT NULL DEFAULT 'unknown',
  UNIQUE(tenant_id,domain)
);

CREATE TABLE IF NOT EXISTS compliance_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  event_type text NOT NULL,
  legal_basis text,
  region text,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_compliance_subject ON compliance_events(subject_type,subject_id,created_at DESC);

CREATE TABLE IF NOT EXISTS workflow_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  name text NOT NULL,
  trigger_type text NOT NULL,
  graph jsonb NOT NULL DEFAULT '{}',
  enabled boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL,
  tenant_id uuid,
  status text NOT NULL DEFAULT 'queued',
  current_node text,
  context jsonb NOT NULL DEFAULT '{}',
  error text,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_workflow_runs_workflow ON workflow_runs(workflow_id,created_at DESC);

CREATE TABLE IF NOT EXISTS product_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  user_id text,
  event_name text NOT NULL,
  properties jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_product_events_tenant ON product_events(tenant_id,created_at DESC);

CREATE TABLE IF NOT EXISTS daily_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  brief_date date NOT NULL,
  content jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,brief_date)
);

CREATE TABLE IF NOT EXISTS next_best_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  action text NOT NULL,
  reason text,
  priority numeric(8,3) DEFAULT 0,
  confidence numeric(6,5) DEFAULT 0.5,
  status text NOT NULL DEFAULT 'open',
  due_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_nba_tenant ON next_best_actions(tenant_id,status,priority DESC);

CREATE TABLE IF NOT EXISTS export_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  actor_id text,
  export_type text NOT NULL,
  row_count integer NOT NULL DEFAULT 0,
  fields text[] NOT NULL DEFAULT '{}',
  filters jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS data_subject_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  subject_type text NOT NULL,
  subject_value text NOT NULL,
  request_type text NOT NULL CHECK(request_type IN ('access','correct','delete','suppress','export')),
  status text NOT NULL DEFAULT 'open',
  requested_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  resolution text
);

CREATE TABLE IF NOT EXISTS feature_flags (
  key text PRIMARY KEY,
  enabled boolean NOT NULL DEFAULT false,
  rollout_pct integer NOT NULL DEFAULT 100 CHECK(rollout_pct BETWEEN 0 AND 100),
  tenant_ids uuid[] NOT NULL DEFAULT '{}',
  metadata jsonb NOT NULL DEFAULT '{}',
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_model_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_key text NOT NULL,
  provider text NOT NULL,
  version text NOT NULL,
  status text NOT NULL DEFAULT 'candidate',
  evaluation_score numeric(8,4),
  cost_per_1k numeric(16,8),
  latency_ms numeric(12,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(model_key,provider,version)
);

CREATE TABLE IF NOT EXISTS ai_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  claim text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  confidence numeric(6,5),
  model_version text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ai_claims_entity ON ai_claims(entity_type,entity_id,created_at DESC);

CREATE TABLE IF NOT EXISTS ai_claim_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id uuid NOT NULL,
  source text,
  source_url text,
  excerpt text,
  evidence_strength numeric(6,5) DEFAULT 0.5,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS review_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  source text,
  theme text NOT NULL,
  sentiment numeric(6,3),
  mention_count integer NOT NULL DEFAULT 1,
  examples jsonb NOT NULL DEFAULT '[]',
  observed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_review_insights_lead ON review_insights(lead_id,mention_count DESC);

CREATE TABLE IF NOT EXISTS discovery_frontier (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vertical_key text NOT NULL,
  source text NOT NULL,
  location_key text NOT NULL,
  query_key text NOT NULL,
  state text NOT NULL DEFAULT 'active' CHECK(state IN ('active','exhausted','blocked','failed','stale')),
  page_reached integer NOT NULL DEFAULT 0,
  raw_found bigint NOT NULL DEFAULT 0,
  unique_found bigint NOT NULL DEFAULT 0,
  last_yield bigint NOT NULL DEFAULT 0,
  last_run_at timestamptz,
  exhausted_at timestamptz,
  last_error text,
  metadata jsonb NOT NULL DEFAULT '{}',
  UNIQUE(vertical_key,source,location_key,query_key)
);
CREATE INDEX IF NOT EXISTS idx_discovery_frontier_state ON discovery_frontier(state,last_run_at);

CREATE TABLE IF NOT EXISTS inventory_freshness (
  lead_id uuid PRIMARY KEY,
  last_verified_at timestamptz,
  next_refresh_at timestamptz,
  change_probability numeric(6,5) DEFAULT 0.5,
  priority numeric(8,3) DEFAULT 0,
  status text NOT NULL DEFAULT 'fresh'
);

CREATE TABLE IF NOT EXISTS unit_economics_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  period_start date NOT NULL,
  period_end date NOT NULL,
  revenue numeric(16,2) DEFAULT 0,
  provider_cost numeric(16,2) DEFAULT 0,
  ai_cost numeric(16,2) DEFAULT 0,
  email_cost numeric(16,2) DEFAULT 0,
  other_cost numeric(16,2) DEFAULT 0,
  gross_margin numeric(16,2) DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Atomic idempotency primitive. The unique constraint is the correctness guard.
CREATE OR REPLACE FUNCTION claim_operation_idempotency(
  p_key text, p_operation text, p_tenant_id uuid DEFAULT NULL
) RETURNS TABLE(acquired boolean, existing_response jsonb)
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  INSERT INTO operation_idempotency(idempotency_key,operation,tenant_id,status,response)
  VALUES(p_key,p_operation,p_tenant_id,'processing','{}')
  ON CONFLICT(idempotency_key,operation) DO NOTHING;
  IF FOUND THEN RETURN QUERY SELECT true, NULL::jsonb; RETURN; END IF;
  SELECT response INTO r FROM operation_idempotency WHERE idempotency_key=p_key AND operation=p_operation LIMIT 1;
  RETURN QUERY SELECT false, r;
END; $$;

CREATE OR REPLACE FUNCTION finish_operation_idempotency(
  p_key text, p_operation text, p_response jsonb, p_status text DEFAULT 'completed'
) RETURNS void LANGUAGE sql AS $$
  UPDATE operation_idempotency SET response=COALESCE(p_response,'{}'), status=p_status
  WHERE idempotency_key=p_key AND operation=p_operation;
$$;

-- Useful secure helper for platform admin checks. The service role executes it.
CREATE OR REPLACE FUNCTION is_platform_admin(p_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE AS $$
  SELECT EXISTS(SELECT 1 FROM platform_admins WHERE user_id=p_user_id AND active=true);
$$;

-- Backend-owned data: deny direct client access by default. The service role
-- used by the FastAPI API bypasses RLS; tenant access is enforced in the API.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY[
    'platform_admins','audit_log','security_events','queue_metrics','provider_health',
    'data_lineage','lead_signals','lead_opportunities','contact_graph_edges','company_change_events',
    'website_audits','technographics','lead_quality_reports','lead_replacement_events','campaign_guardrails',
    'email_domain_health','compliance_events','workflow_definitions','workflow_runs','product_events',
    'daily_briefs','next_best_actions','export_audit','data_subject_requests','feature_flags',
    'ai_model_versions','ai_claims','ai_claim_evidence','review_insights','discovery_frontier',
    'inventory_freshness','unit_economics_snapshots'
  ] LOOP
    EXECUTE format('ALTER TABLE IF EXISTS %I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;
