-- Explainable closed-loop learning snapshots. Snapshots inform recommendations;
-- they do not silently rewrite scoring rules.
CREATE TABLE IF NOT EXISTS learning_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  model_version text NOT NULL,
  outcomes integer NOT NULL DEFAULT 0,
  won integer NOT NULL DEFAULT 0,
  lost integer NOT NULL DEFAULT 0,
  win_rate_pct numeric(7,3) NOT NULL DEFAULT 0,
  weights jsonb NOT NULL DEFAULT '{}',
  lookalike_queries jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_learning_snapshots_tenant ON learning_snapshots(tenant_id,created_at DESC);
