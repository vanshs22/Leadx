-- Discovery approvals, monthly reservations, and global source-coverage ledger.
-- The global coverage ledger is intentionally NOT tenant-scoped: discovery is a shared
-- LeadX data asset and should not repeat exhausted source/geo/query partitions per customer.

ALTER TABLE usage_log
  ADD COLUMN IF NOT EXISTS quota_reserved int NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS discovery_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  vertical text NOT NULL,
  locations jsonb NOT NULL DEFAULT '[]',
  keywords jsonb NOT NULL DEFAULT '[]',
  offer_category text,
  requested_leads int NOT NULL CHECK (requested_leads > 0),
  approved_leads int,
  status text NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval','approved','queued','running','completed','partially_completed','rejected','cancelled','failed')),
  admin_reason text,
  rejection_reason text,
  requested_by uuid,
  approved_by text,
  approved_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  pipeline_run_id uuid REFERENCES pipeline_runs(id) ON DELETE SET NULL,
  assigned_count int NOT NULL DEFAULT 0,
  discovered_count int NOT NULL DEFAULT 0,
  global_stored_count int NOT NULL DEFAULT 0,
  enriched_count int NOT NULL DEFAULT 0,
  exhausted_partitions int NOT NULL DEFAULT 0,
  total_partitions int NOT NULL DEFAULT 0,
  meta jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_discovery_requests_tenant_status ON discovery_requests(tenant_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_discovery_requests_status ON discovery_requests(status, created_at);
CREATE INDEX IF NOT EXISTS idx_discovery_requests_icp ON discovery_requests(icp_id, created_at DESC);

CREATE TABLE IF NOT EXISTS global_discovery_coverage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vertical_key text NOT NULL,
  source text NOT NULL,
  location_key text NOT NULL,
  query_key text NOT NULL DEFAULT '',
  page_reached int NOT NULL DEFAULT 0,
  raw_found int NOT NULL DEFAULT 0,
  unique_new_found int NOT NULL DEFAULT 0,
  runs int NOT NULL DEFAULT 0,
  exhausted boolean NOT NULL DEFAULT false,
  exhausted_at timestamptz,
  last_run_at timestamptz NOT NULL DEFAULT now(),
  last_error text,
  meta jsonb NOT NULL DEFAULT '{}',
  UNIQUE(vertical_key, source, location_key, query_key)
);
CREATE INDEX IF NOT EXISTS idx_global_coverage_frontier ON global_discovery_coverage(vertical_key, exhausted, last_run_at);
CREATE INDEX IF NOT EXISTS idx_global_coverage_location ON global_discovery_coverage(location_key, source, exhausted);

-- Reserve monthly quota at approval time. This is separate from actual delivered usage.
CREATE OR REPLACE FUNCTION public.reserve_tenant_discovery_quota(p_tenant_id uuid, p_requested int)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
  lim int;
  used int;
  reserved int;
  available int;
  granted int;
BEGIN
  IF p_requested IS NULL OR p_requested <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'granted', 0, 'reason', 'invalid_amount');
  END IF;
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id FOR UPDATE;
  IF lim IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'granted', 0, 'reason', 'tenant_not_found');
  END IF;
  INSERT INTO usage_log(tenant_id, period, leads_delivered, quota_reserved)
  VALUES(p_tenant_id, p, 0, 0)
  ON CONFLICT(tenant_id, period) DO NOTHING;
  SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0)
    INTO used, reserved
  FROM usage_log WHERE tenant_id=p_tenant_id AND period=p FOR UPDATE;
  available := GREATEST(lim - used - reserved, 0);
  granted := LEAST(p_requested, available);
  IF granted <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'granted', 0, 'reason', 'quota_exhausted', 'limit', lim, 'used', used, 'reserved', reserved);
  END IF;
  UPDATE usage_log SET quota_reserved=quota_reserved+granted, updated_at=now()
   WHERE tenant_id=p_tenant_id AND period=p;
  RETURN jsonb_build_object('ok', true, 'granted', granted, 'limit', lim, 'used', used, 'reserved', reserved);
END;
$$;

-- Consume one approved request slot and one monthly reservation atomically.
CREATE OR REPLACE FUNCTION public.consume_tenant_discovery_slot(p_tenant_id uuid, p_request_id uuid, p_tier text DEFAULT 'A')
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
  req_reserved int;
BEGIN
  SELECT approved_leads - assigned_count INTO req_reserved
    FROM discovery_requests WHERE id=p_request_id AND tenant_id=p_tenant_id FOR UPDATE;
  IF COALESCE(req_reserved,0) <= 0 THEN RETURN false; END IF;
  UPDATE discovery_requests SET assigned_count=assigned_count+1, updated_at=now() WHERE id=p_request_id;
  UPDATE usage_log
  SET quota_reserved=GREATEST(quota_reserved-1,0),
      leads_delivered=leads_delivered+1,
      tier_a_count=tier_a_count+CASE WHEN upper(coalesce(p_tier,'A'))='A' THEN 1 ELSE 0 END,
      tier_b_count=tier_b_count+CASE WHEN upper(coalesce(p_tier,'A'))='B' THEN 1 ELSE 0 END,
      tier_c_count=tier_c_count+CASE WHEN upper(coalesce(p_tier,'A'))='C' THEN 1 ELSE 0 END,
      updated_at=now()
  WHERE tenant_id=p_tenant_id AND period=p;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_discovery_quota_reservation(p_tenant_id uuid, p_count int)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE p date := date_trunc('month', now())::date;
BEGIN
  UPDATE usage_log SET quota_reserved=GREATEST(quota_reserved-GREATEST(p_count,0),0), updated_at=now()
   WHERE tenant_id=p_tenant_id AND period=p;
END;
$$;

CREATE OR REPLACE FUNCTION public.tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE lim int; used int; reserved int; p date := date_trunc('month', now())::date;
BEGIN
 SELECT leads_per_month_limit INTO lim FROM tenants WHERE id=p_tenant_id;
 IF lim IS NULL THEN RETURN 0; END IF;
 SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0) INTO used,reserved FROM usage_log WHERE tenant_id=p_tenant_id AND period=p;
 RETURN GREATEST(lim-COALESCE(used,0)-COALESCE(reserved,0),0);
END;
$$;

-- Add city/state coverage metadata to global records without changing existing identity semantics.
ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS first_discovered_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS last_discovered_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS source_provenance jsonb NOT NULL DEFAULT '{}';

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS discovery_request_id uuid REFERENCES discovery_requests(id) ON DELETE SET NULL;

ALTER TABLE discovery_coverage
  ADD COLUMN IF NOT EXISTS global_exhausted boolean NOT NULL DEFAULT false;

-- RLS for client-visible request objects.
ALTER TABLE discovery_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_requests_member_select ON discovery_requests;
CREATE POLICY discovery_requests_member_select ON discovery_requests FOR SELECT USING (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=discovery_requests.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);
DROP POLICY IF EXISTS discovery_requests_member_insert ON discovery_requests;
CREATE POLICY discovery_requests_member_insert ON discovery_requests FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=discovery_requests.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);

CREATE OR REPLACE FUNCTION public.release_tenant_discovery_slot(p_tenant_id uuid, p_request_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE p date := date_trunc('month', now())::date;
BEGIN
  UPDATE discovery_requests
    SET assigned_count=GREATEST(assigned_count-1,0), updated_at=now()
    WHERE id=p_request_id AND tenant_id=p_tenant_id;
  UPDATE usage_log SET quota_reserved=quota_reserved+1, updated_at=now()
    WHERE tenant_id=p_tenant_id AND period=p;
END;
$$;
