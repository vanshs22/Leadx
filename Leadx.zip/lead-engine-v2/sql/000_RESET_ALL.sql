-- ============================================================
-- LeadX: wipe public schema objects (DATA LOSS)
-- Then run SUPABASE_FULL_MIGRATION.sql once.
-- Does NOT delete Auth users (Authentication → Users).
-- ============================================================

DROP VIEW IF EXISTS public.crm_lead_cards CASCADE;
DROP VIEW IF EXISTS public.deliverable_leads CASCADE;

DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);
DROP FUNCTION IF EXISTS public.check_exclusivity(uuid, text, text[], text);
DROP FUNCTION IF EXISTS public.credit_tenant_usage(uuid, int);
DROP FUNCTION IF EXISTS public.tenant_quota_remaining(uuid);
DROP FUNCTION IF EXISTS public.is_opted_out(text, text, text, text);
DROP FUNCTION IF EXISTS public.is_suppressed(uuid, text, text, text, text);
DROP FUNCTION IF EXISTS public.bump_usage(uuid, int);

DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (
    SELECT tablename
    FROM pg_tables
    WHERE schemaname = 'public'
  ) LOOP
    EXECUTE format('DROP TABLE IF EXISTS public.%I CASCADE', r.tablename);
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';

-- Discovery approval/global coverage additions
DROP FUNCTION IF EXISTS public.reserve_tenant_discovery_quota(uuid,int);
DROP FUNCTION IF EXISTS public.consume_tenant_discovery_slot(uuid,uuid,text);
DROP FUNCTION IF EXISTS public.release_tenant_discovery_slot(uuid,uuid);
DROP FUNCTION IF EXISTS public.release_discovery_quota_reservation(uuid,int);
DROP TABLE IF EXISTS public.discovery_requests CASCADE;
DROP TABLE IF EXISTS public.global_discovery_coverage CASCADE;

-- 029/030 revenue intelligence + autonomous automation reset
DROP FUNCTION IF EXISTS reserve_campaign_email_slot(uuid,int);
DROP FUNCTION IF EXISTS consume_campaign_email_slot(uuid,int);
DROP FUNCTION IF EXISTS release_campaign_email_slot(uuid,int);
DROP TABLE IF EXISTS campaign_email_copies CASCADE;
DROP TABLE IF EXISTS autonomous_campaign_daily CASCADE;
DROP TABLE IF EXISTS autonomous_campaigns CASCADE;
DROP TABLE IF EXISTS workflow_runs CASCADE;
DROP TABLE IF EXISTS workflow_rules CASCADE;
DROP TABLE IF EXISTS saved_searches CASCADE;
DROP TABLE IF EXISTS provider_usage_daily CASCADE;
DROP TABLE IF EXISTS lead_feedback CASCADE;
DROP TABLE IF EXISTS lead_refresh_state CASCADE;
DROP TABLE IF EXISTS lead_score_versions CASCADE;
DROP TABLE IF EXISTS lead_observations CASCADE;
DROP TABLE IF EXISTS lead_evidence CASCADE;
DROP TABLE IF EXISTS prospect_audits CASCADE;
DROP TABLE IF EXISTS forecast_snapshots CASCADE;
DROP TABLE IF EXISTS revenue_attribution CASCADE;
DROP TABLE IF EXISTS contact_roles CASCADE;
DROP TABLE IF EXISTS company_locations CASCADE;

-- 031 business integrations reset
DROP TABLE IF EXISTS revenue_events CASCADE;
DROP TABLE IF EXISTS customer_success_records CASCADE;
DROP TABLE IF EXISTS proposals CASCADE;
DROP TABLE IF EXISTS form_submissions CASCADE;
DROP TABLE IF EXISTS lead_forms CASCADE;
DROP TABLE IF EXISTS thread_messages CASCADE;
DROP TABLE IF EXISTS message_threads CASCADE;
DROP TABLE IF EXISTS phone_calls CASCADE;
DROP TABLE IF EXISTS meetings CASCADE;
DROP TABLE IF EXISTS routing_rules CASCADE;
DROP TABLE IF EXISTS webhook_deliveries CASCADE;
DROP TABLE IF EXISTS outbound_webhooks CASCADE;
DROP TABLE IF EXISTS integration_connections CASCADE;

-- LeadX 3.0 core reset
DROP FUNCTION IF EXISTS claim_operation_idempotency(text,text,uuid);
DROP FUNCTION IF EXISTS finish_operation_idempotency(text,text,jsonb,text);
DROP FUNCTION IF EXISTS is_platform_admin(uuid);
DROP TABLE IF EXISTS unit_economics_snapshots CASCADE;
DROP TABLE IF EXISTS inventory_freshness CASCADE;
DROP TABLE IF EXISTS discovery_frontier CASCADE;
DROP TABLE IF EXISTS review_insights CASCADE;
DROP TABLE IF EXISTS ai_claim_evidence CASCADE;
DROP TABLE IF EXISTS ai_claims CASCADE;
DROP TABLE IF EXISTS ai_model_versions CASCADE;
DROP TABLE IF EXISTS feature_flags CASCADE;
DROP TABLE IF EXISTS data_subject_requests CASCADE;
DROP TABLE IF EXISTS export_audit CASCADE;
DROP TABLE IF EXISTS next_best_actions CASCADE;
DROP TABLE IF EXISTS daily_briefs CASCADE;
DROP TABLE IF EXISTS product_events CASCADE;
DROP TABLE IF EXISTS workflow_runs CASCADE;
DROP TABLE IF EXISTS workflow_definitions CASCADE;
DROP TABLE IF EXISTS compliance_events CASCADE;
DROP TABLE IF EXISTS email_domain_health CASCADE;
DROP TABLE IF EXISTS campaign_guardrails CASCADE;
DROP TABLE IF EXISTS lead_replacement_events CASCADE;
DROP TABLE IF EXISTS lead_quality_reports CASCADE;
DROP TABLE IF EXISTS technographics CASCADE;
DROP TABLE IF EXISTS website_audits CASCADE;
DROP TABLE IF EXISTS company_change_events CASCADE;
DROP TABLE IF EXISTS contact_graph_edges CASCADE;
DROP TABLE IF EXISTS lead_opportunities CASCADE;
DROP TABLE IF EXISTS lead_signals CASCADE;
DROP TABLE IF EXISTS data_lineage CASCADE;
DROP TABLE IF EXISTS provider_health CASCADE;
DROP TABLE IF EXISTS queue_metrics CASCADE;
DROP TABLE IF EXISTS security_events CASCADE;
DROP TABLE IF EXISTS audit_log CASCADE;
DROP TABLE IF EXISTS platform_admins CASCADE;

-- LeadX runtime schema repair reset
DROP FUNCTION IF EXISTS leadx_runtime_schema_status();
DROP TABLE IF EXISTS webhook_events CASCADE;
DROP TABLE IF EXISTS template_variant_stats CASCADE;
DROP TABLE IF EXISTS lead_touches CASCADE;
DROP TABLE IF EXISTS email_replies CASCADE;
DROP TABLE IF EXISTS email_optouts CASCADE;
