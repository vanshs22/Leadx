-- Wipe public schema objects then run SUPABASE_FULL_MIGRATION.sql once
DROP VIEW IF EXISTS public.crm_lead_cards CASCADE;
DROP VIEW IF EXISTS public.deliverable_leads CASCADE;
DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public') LOOP
    EXECUTE format('DROP TABLE IF EXISTS public.%I CASCADE', r.tablename);
  END LOOP;
END $$;
NOTIFY pgrst, 'reload schema';
