-- =============================================================================
-- 017 — CRM demo seed
--
-- Gives a fresh install a populated UI instead of empty states: one demo
-- tenant on a fixed well-known UUID, its lead pipeline stages, its deal
-- stages, and a handful of companies / contacts / deals / activities /
-- tasks / notes.
--
-- Safe to run repeatedly: every INSERT is either ON CONFLICT DO NOTHING on a
-- real unique constraint, or guarded by NOT EXISTS. Re-running changes nothing.
--
-- Run AFTER sql/015_crm_missing_objects.sql and sql/016_crm_full.sql.
--
-- The demo tenant UUID is deterministic so the frontend, tests and fixtures
-- can hardcode it:
--     00000000-0000-0000-0000-0000000d3000   ("demo")
-- Delete the tenant to remove everything below — all seeded rows cascade.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. Demo tenant
-- ---------------------------------------------------------------------------
INSERT INTO tenants (id, name, slug, plan, leads_per_month_limit, delivery_channel, status)
VALUES (
  '00000000-0000-0000-0000-0000000d3000',
  'Demo Agency',
  'demo-agency',
  'growth',
  500,
  'portal',
  'active'
)
ON CONFLICT (id) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 2. Lead pipeline stages (lead engine) — reuse the function from 015 so the
--    demo tenant gets exactly the same pipeline a real tenant gets.
-- ---------------------------------------------------------------------------
SELECT public.seed_default_stages('00000000-0000-0000-0000-0000000d3000'::uuid);


-- ---------------------------------------------------------------------------
-- 3. Deal stages (CRM) — UNIQUE (tenant_id, slug) makes this idempotent
-- ---------------------------------------------------------------------------
INSERT INTO deal_stages (tenant_id, name, slug, position, color, probability, is_won, is_lost)
VALUES
  ('00000000-0000-0000-0000-0000000d3000', 'Discovery',   'discovery',   1, '#94a3b8',  10, false, false),
  ('00000000-0000-0000-0000-0000000d3000', 'Qualified',   'qualified',   2, '#3b82f6',  25, false, false),
  ('00000000-0000-0000-0000-0000000d3000', 'Proposal',    'proposal',    3, '#8b5cf6',  50, false, false),
  ('00000000-0000-0000-0000-0000000d3000', 'Negotiation', 'negotiation', 4, '#f59e0b',  75, false, false),
  ('00000000-0000-0000-0000-0000000d3000', 'Closed Won',  'closed-won',  5, '#22c55e', 100, true,  false),
  ('00000000-0000-0000-0000-0000000d3000', 'Closed Lost', 'closed-lost', 6, '#ef4444',   0, false, true)
ON CONFLICT (tenant_id, slug) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 4. Custom field definitions
-- ---------------------------------------------------------------------------
INSERT INTO custom_field_defs (tenant_id, entity_type, field_key, label, field_type, options, position, required)
VALUES
  ('00000000-0000-0000-0000-0000000d3000', 'company', 'locations',      'Locations',        'number', '[]', 1, false),
  ('00000000-0000-0000-0000-0000000d3000', 'company', 'booking_system', 'Booking System',   'select',
     '["Mindbody","Square","Vagaro","Boulevard","None"]', 2, false),
  ('00000000-0000-0000-0000-0000000d3000', 'contact', 'best_time',      'Best Time to Call','select',
     '["Morning","Afternoon","Evening"]', 1, false),
  ('00000000-0000-0000-0000-0000000d3000', 'deal',    'contract_months','Contract (months)','number', '[]', 1, false)
ON CONFLICT (tenant_id, entity_type, field_key) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 5. Companies
--
-- Idempotent via idx_companies_tenant_domain — the partial unique index on
-- (tenant_id, lower(domain)). ON CONFLICT cannot name a partial index
-- directly, so each row is guarded with NOT EXISTS instead. Fixed UUIDs let
-- the contacts/deals below reference them without a lookup.
-- ---------------------------------------------------------------------------
INSERT INTO companies (
  id, tenant_id, name, domain, website, phone, address, city, state, country,
  industry, employee_count, annual_revenue, description, owner, status, tags, custom_fields
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Lumen Medspa', 'lumenmedspa.com', 'https://lumenmedspa.com', '2015550142',
   '412 Washington St', 'Hoboken', 'NJ', 'US',
   'medspa', 14, 1850000.00,
   'Three-location medspa group. Injectables and laser. Actively hiring.',
   'sales@demo-agency.test', 'customer',
   ARRAY['medspa','multi-location','priority'], '{"locations": 3, "booking_system": "Boulevard"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Ironline Fitness', 'ironlinefit.com', 'https://ironlinefit.com', '2015550188',
   '77 Hudson Pl', 'Jersey City', 'NJ', 'US',
   'gym', 22, 2400000.00,
   'Strength-focused gym. No online booking — strong automation fit.',
   'sales@demo-agency.test', 'prospect',
   ARRAY['gym','inbound'], '{"locations": 1, "booking_system": "None"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Bright Smile Dental', 'brightsmiledental.com', 'https://brightsmiledental.com', '2015550204',
   '1200 Bloomfield St', 'Hoboken', 'NJ', 'US',
   'dental', 9, 1200000.00,
   'Family dental practice. Two chairs idle midweek.',
   'ae2@demo-agency.test', 'prospect',
   ARRAY['dental'], '{"locations": 1, "booking_system": "Square"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Coastal Hair Studio', 'coastalhairstudio.com', 'https://coastalhairstudio.com', '2015550311',
   '58 Newark St', 'Hoboken', 'NJ', 'US',
   'salon', 6, 480000.00,
   'Boutique salon. Owner-operated, books by phone only.',
   'ae2@demo-agency.test', 'active',
   ARRAY['salon','small'], '{"locations": 1}'::jsonb),

  ('00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Verity Legal Group', 'veritylegal.com', 'https://veritylegal.com', '2015550377',
   '30 Montgomery St', 'Jersey City', 'NJ', 'US',
   'legal', 31, 5600000.00,
   'Mid-size firm. Intake handled by an answering service today.',
   'sales@demo-agency.test', 'churned',
   ARRAY['legal','enterprise'], '{}'::jsonb)
) AS v(id, tenant_id, name, domain, website, phone, address, city, state, country,
       industry, employee_count, annual_revenue, description, owner, status, tags, custom_fields)
WHERE NOT EXISTS (SELECT 1 FROM companies c WHERE c.id = v.id);

-- ---------------------------------------------------------------------------
-- 6. Contacts
--
-- Note idx_contacts_one_primary: at most one is_primary contact per company,
-- so the second contact at Lumen is deliberately not primary.
-- ---------------------------------------------------------------------------
INSERT INTO contacts (
  id, tenant_id, company_id, full_name, first_name, last_name, title,
  email, phone, mobile, linkedin_url, is_primary, is_decision_maker,
  owner, status, tags, custom_fields, do_not_contact
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000ct001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   'Dana Reyes', 'Dana', 'Reyes', 'Owner',
   'dana@lumenmedspa.com', '2015550142', '2015550143',
   'https://www.linkedin.com/in/dana-reyes-demo', true, true,
   'sales@demo-agency.test', 'active', ARRAY['decision-maker'],
   '{"best_time": "Morning"}'::jsonb, false),

  ('00000000-0000-0000-0000-0000000ct002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   'Priya Shah', 'Priya', 'Shah', 'Operations Manager',
   'priya@lumenmedspa.com', '2015550144', NULL,
   NULL, false, false,
   'sales@demo-agency.test', 'active', ARRAY['influencer'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-0000000ct003'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c002'::uuid,
   'Marcus Hale', 'Marcus', 'Hale', 'Founder',
   'marcus@ironlinefit.com', '2015550188', '2015550189',
   'https://www.linkedin.com/in/marcus-hale-demo', true, true,
   'sales@demo-agency.test', 'active', ARRAY['decision-maker','warm'],
   '{"best_time": "Evening"}'::jsonb, false),

  ('00000000-0000-0000-0000-0000000ct004'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   'Dr. Alan Whitfield', 'Alan', 'Whitfield', 'Practice Owner',
   'alan@brightsmiledental.com', '2015550204', NULL,
   NULL, true, true,
   'ae2@demo-agency.test', 'active', ARRAY['decision-maker'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-0000000ct005'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c004'::uuid,
   'Nina Alvarez', 'Nina', 'Alvarez', 'Owner / Stylist',
   'nina@coastalhairstudio.com', '2015550311', NULL,
   NULL, true, true,
   'ae2@demo-agency.test', 'active', ARRAY['decision-maker'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-0000000ct006'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c005'::uuid,
   'Grant Okafor', 'Grant', 'Okafor', 'Managing Partner',
   'grant@veritylegal.com', '2015550377', NULL,
   NULL, true, true,
   'sales@demo-agency.test', 'unqualified', ARRAY['do-not-call'],
   '{}'::jsonb, true)
) AS v(id, tenant_id, company_id, full_name, first_name, last_name, title,
       email, phone, mobile, linkedin_url, is_primary, is_decision_maker,
       owner, status, tags, custom_fields, do_not_contact)
WHERE NOT EXISTS (SELECT 1 FROM contacts c WHERE c.id = v.id);


-- ---------------------------------------------------------------------------
-- 7. Deals — stage_id resolved by slug so this survives stage re-ordering
-- ---------------------------------------------------------------------------
INSERT INTO deals (
  id, tenant_id, company_id, primary_contact_id, title, description,
  value, currency, stage_id, probability, expected_close_date,
  actual_close_date, status, lost_reason, owner, source, tags, custom_fields
)
SELECT
  v.id, v.tenant_id, v.company_id, v.primary_contact_id, v.title, v.description,
  v.value, v.currency,
  (SELECT ds.id FROM deal_stages ds
    WHERE ds.tenant_id = v.tenant_id AND ds.slug = v.stage_slug),
  v.probability, v.expected_close_date, v.actual_close_date, v.status,
  v.lost_reason, v.owner, v.source, v.tags, v.custom_fields
FROM (VALUES
  ('00000000-0000-0000-0000-0000000dd001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   'Lumen Medspa — 3-location automation rollout',
   'Booking automation plus reactivation campaign across all three locations.',
   36000.00, 'USD', 'negotiation', 75,
   (CURRENT_DATE + 21), NULL, 'open', NULL,
   'sales@demo-agency.test', 'referral',
   ARRAY['expansion'], '{"contract_months": 12}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-0000000ct003'::uuid,
   'Ironline Fitness — inbound booking build',
   'No online booking today. Replace phone-only intake.',
   14400.00, 'USD', 'proposal', 50,
   (CURRENT_DATE + 30), NULL, 'open', NULL,
   'sales@demo-agency.test', 'lead_engine',
   ARRAY['new-logo'], '{"contract_months": 6}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd003'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-0000000ct004'::uuid,
   'Bright Smile Dental — midweek fill campaign',
   'Fill idle midweek chair time with a recall campaign.',
   9600.00, 'USD', 'qualified', 25,
   (CURRENT_DATE + 45), NULL, 'open', NULL,
   'ae2@demo-agency.test', 'lead_engine',
   ARRAY['new-logo'], '{"contract_months": 6}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd004'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-0000000ct005'::uuid,
   'Coastal Hair Studio — starter retainer',
   'Single-location starter package. Signed after one call.',
   4800.00, 'USD', 'closed-won', 100,
   (CURRENT_DATE - 12), (CURRENT_DATE - 12), 'won', NULL,
   'ae2@demo-agency.test', 'referral',
   ARRAY['won'], '{"contract_months": 12}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd005'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-0000000ct006'::uuid,
   'Verity Legal Group — intake automation',
   'Lost to an incumbent answering service on price.',
   28000.00, 'USD', 'closed-lost', 0,
   (CURRENT_DATE - 30), (CURRENT_DATE - 25), 'lost', 'Price — incumbent undercut',
   'sales@demo-agency.test', 'outbound',
   ARRAY['lost'], '{}'::jsonb)
) AS v(id, tenant_id, company_id, primary_contact_id, title, description,
       value, currency, stage_slug, probability, expected_close_date,
       actual_close_date, status, lost_reason, owner, source, tags, custom_fields)
WHERE NOT EXISTS (SELECT 1 FROM deals d WHERE d.id = v.id);


-- ---------------------------------------------------------------------------
-- 8. Activities — the timeline the UI renders
-- ---------------------------------------------------------------------------
INSERT INTO activities (
  id, tenant_id, activity_type, subject, body, direction,
  occurred_at, duration_minutes, outcome, company_id, contact_id, deal_id, meta
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000a0001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'call', 'Discovery call — Dana Reyes',
   'Walked through the three-location booking gap. Wants a rollout plan.',
   'outbound', (now() - interval '9 days'), 28, 'connected',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'email', 'Sent proposal v2',
   'Revised pricing for 12 months across 3 locations.',
   'outbound', (now() - interval '4 days'), NULL, 'sent',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid, '{"attachment": "proposal-v2.pdf"}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0003'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'meeting', 'On-site demo at Ironline',
   'Demoed booking flow on the front-desk tablet.',
   'outbound', (now() - interval '6 days'), 45, 'positive',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-0000000ct003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0004'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'note', 'Budget cycle note', 'Dental budget resets next quarter — time the close.',
   NULL, (now() - interval '2 days'), NULL, NULL,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-0000000ct004'::uuid,
   '00000000-0000-0000-0000-0000000dd003'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0005'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'stage_change', 'Moved to Closed Won', 'Contract signed, 12 months.',
   NULL, (now() - interval '12 days'), NULL, 'won',
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-0000000ct005'::uuid,
   '00000000-0000-0000-0000-0000000dd004'::uuid,
   '{"from": "negotiation", "to": "closed-won"}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0006'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'call', 'Inbound — Verity Legal declined',
   'Chose to keep their answering service. Revisit in 6 months.',
   'inbound', (now() - interval '25 days'), 11, 'lost',
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-0000000ct006'::uuid,
   '00000000-0000-0000-0000-0000000dd005'::uuid, '{}'::jsonb)
) AS v(id, tenant_id, activity_type, subject, body, direction,
       occurred_at, duration_minutes, outcome, company_id, contact_id, deal_id, meta)
WHERE NOT EXISTS (SELECT 1 FROM activities a WHERE a.id = v.id);


-- ---------------------------------------------------------------------------
-- 9. Tasks
-- ---------------------------------------------------------------------------
INSERT INTO tasks (
  id, tenant_id, title, description, due_at, completed_at, status,
  priority, assigned_to, company_id, contact_id, deal_id
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000t0001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Follow up on Lumen proposal v2',
   'Chase Dana for a decision on the 12-month term.',
   (now() + interval '1 day'), NULL, 'open', 'high',
   'sales@demo-agency.test',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid),

  ('00000000-0000-0000-0000-0000000t0002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Send Ironline the security questionnaire', NULL,
   (now() + interval '3 days'), NULL, 'open', 'medium',
   'sales@demo-agency.test',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-0000000ct003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid),

  ('00000000-0000-0000-0000-0000000t0003'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Book Bright Smile technical review', NULL,
   (now() + interval '7 days'), NULL, 'open', 'low',
   'ae2@demo-agency.test',
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-0000000ct004'::uuid,
   '00000000-0000-0000-0000-0000000dd003'::uuid),

  ('00000000-0000-0000-0000-0000000t0004'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Kick off Coastal Hair onboarding', 'Signed — hand to delivery.',
   (now() - interval '10 days'), (now() - interval '9 days'), 'done', 'high',
   'ae2@demo-agency.test',
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-0000000ct005'::uuid,
   '00000000-0000-0000-0000-0000000dd004'::uuid)
) AS v(id, tenant_id, title, description, due_at, completed_at, status,
       priority, assigned_to, company_id, contact_id, deal_id)
WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.id = v.id);


-- ---------------------------------------------------------------------------
-- 10. Notes
-- ---------------------------------------------------------------------------
INSERT INTO notes (id, tenant_id, body, company_id, contact_id, deal_id)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000n0001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Dana prefers morning calls. Priya handles scheduling day to day.',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   NULL::uuid),

  ('00000000-0000-0000-0000-0000000n0002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Marcus is price sensitive but moves fast once convinced.',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-0000000ct003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid),

  ('00000000-0000-0000-0000-0000000n0003'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'Verity: do not call — contact flagged do_not_contact. Email only, after Q3.',
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-0000000ct006'::uuid,
   NULL::uuid)
) AS v(id, tenant_id, body, company_id, contact_id, deal_id)
WHERE NOT EXISTS (SELECT 1 FROM notes n WHERE n.id = v.id);


-- ---------------------------------------------------------------------------
-- 11. Email + call logs
-- ---------------------------------------------------------------------------
INSERT INTO email_log (
  id, tenant_id, to_email, from_email, subject, body_preview,
  status, provider, provider_message_id, contact_id, deal_id, sent_at
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000e0001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'dana@lumenmedspa.com', 'sales@demo-agency.test',
   'Revised proposal — Lumen Medspa',
   'Hi Dana, attached is v2 with the 12-month pricing we discussed...',
   'opened', 'resend', 'demo-msg-0001',
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid,
   (now() - interval '4 days')),

  ('00000000-0000-0000-0000-0000000e0002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   'marcus@ironlinefit.com', 'sales@demo-agency.test',
   'Recap + next steps',
   'Great meeting you both — here is the booking flow we demoed...',
   'replied', 'resend', 'demo-msg-0002',
   '00000000-0000-0000-0000-0000000ct003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid,
   (now() - interval '5 days'))
) AS v(id, tenant_id, to_email, from_email, subject, body_preview,
       status, provider, provider_message_id, contact_id, deal_id, sent_at)
WHERE NOT EXISTS (SELECT 1 FROM email_log el WHERE el.id = v.id);

INSERT INTO call_log (
  id, tenant_id, contact_id, deal_id, direction,
  duration_minutes, outcome, notes, occurred_at
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000k0001'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-0000000ct001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid,
   'outbound', 28, 'connected',
   'Discovery. Confirmed budget owner is Dana.',
   (now() - interval '9 days')),

  ('00000000-0000-0000-0000-0000000k0002'::uuid,
   '00000000-0000-0000-0000-0000000d3000'::uuid,
   '00000000-0000-0000-0000-0000000ct006'::uuid,
   '00000000-0000-0000-0000-0000000dd005'::uuid,
   'inbound', 11, 'lost',
   'Declined. Revisit in 6 months.',
   (now() - interval '25 days'))
) AS v(id, tenant_id, contact_id, deal_id, direction,
       duration_minutes, outcome, notes, occurred_at)
WHERE NOT EXISTS (SELECT 1 FROM call_log cl WHERE cl.id = v.id);


-- ---------------------------------------------------------------------------
-- Done. To wipe the demo data entirely (everything above cascades):
--   DELETE FROM tenants WHERE id = '00000000-0000-0000-0000-0000000d3000';
--
-- NOTE: no tenant_members row is seeded, because membership must bind to a
-- real Supabase auth.users id. To log into the demo tenant, create the auth
-- user first, then:
--   INSERT INTO tenant_members (tenant_id, auth_user_id, email, role, status)
--   VALUES ('00000000-0000-0000-0000-0000000d3000', '<auth uid>',
--           '<email>', 'owner', 'active')
--   ON CONFLICT (tenant_id, auth_user_id) DO NOTHING;
-- Until then the seeded rows are only visible to the service role, since RLS
-- gates every table on tenant_members.
-- ---------------------------------------------------------------------------
