-- =============================================================================
-- 016 — Full CRM / customer database
--
-- The lead engine's own tables (leads_global, lead_assignments, enrichment,
-- scores) model SCRAPED PROSPECTS. This file adds the layer above them: the
-- accounts, people, opportunities and timeline a user actually works after a
-- prospect converts — companies, contacts, deal_stages, deals, activities,
-- tasks, notes, custom_field_defs, email_log, call_log.
--
-- Relationship to the lead engine:
--   leads_global.id  ──► companies.source_lead_id   (provenance on convert)
--   lead_assignments.id ──► deals.source_assignment_id
--                       ──► activities.assignment_id / email_log / call_log
-- Nothing here modifies or drops an existing table.
--
-- Idempotent / re-runnable throughout.
-- Tags: this schema uses `tags text[]` columns (matching lead_assignments.tags
-- and the GIN-indexed pattern already used elsewhere). There is deliberately
-- NO separate tags/taggings join table — see the note at the end of the file.
-- =============================================================================

-- pg_trgm backs the fuzzy company-name search index below. Already created by
-- sql/001, repeated here so 016 can be applied standalone.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------------------
-- Shared updated_at trigger helper
--
-- Checked first: the existing schema (sql/001..014, SUPABASE_FULL_MIGRATION)
-- has NO trigger function at all — every updated_at is set by the application.
-- So this helper is new, and is named distinctly to avoid colliding with any
-- future Supabase-provided function. Reused by every table below.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.crm_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION public.crm_set_updated_at IS
  'BEFORE UPDATE trigger: stamps updated_at = now(). Shared by all 016 CRM tables.';


-- ---------------------------------------------------------------------------
-- 1. companies — the customer / account record
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS companies (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name            text NOT NULL,
  domain          text,
  website         text,
  phone           text,
  address         text,
  city            text,
  state           text,
  country         text,
  postal_code     text,
  industry        text,
  employee_count  int,
  annual_revenue  numeric(16,2),
  description     text,
  owner           text,                   -- tenant_members.email / free text,
                                          -- matching lead_assignments.assigned_to
  status          text NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','prospect','customer','churned','archived')),
  tags            text[] NOT NULL DEFAULT '{}',
  custom_fields   jsonb  NOT NULL DEFAULT '{}',
  source          text,
  source_lead_id  uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

-- One account per domain per tenant (case-insensitive); NULL domain unconstrained
CREATE UNIQUE INDEX IF NOT EXISTS idx_companies_tenant_domain
  ON companies (tenant_id, lower(domain)) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_tenant_status
  ON companies (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_companies_tenant_owner
  ON companies (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_tenant_name
  ON companies (tenant_id, lower(name));
CREATE INDEX IF NOT EXISTS idx_companies_name_trgm
  ON companies USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_companies_tags
  ON companies USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_companies_source_lead
  ON companies (source_lead_id) WHERE source_lead_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_companies_updated_at ON companies;
CREATE TRIGGER trg_companies_updated_at BEFORE UPDATE ON companies
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE companies IS
  'Customer/account record. source_lead_id preserves provenance when an '
  'account is converted from a scraped leads_global row.';


-- ---------------------------------------------------------------------------
-- 2. contacts — people at an account
--
-- Distinct from lead_contacts (which hangs off leads_global and holds
-- scraped, unverified decision-makers). contacts are the tenant's own
-- curated people records.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contacts (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id        uuid REFERENCES companies(id) ON DELETE CASCADE,
  full_name         text,
  first_name        text,
  last_name         text,
  title             text,
  email             text,
  phone             text,
  mobile            text,
  linkedin_url      text,
  is_primary        boolean NOT NULL DEFAULT false,
  is_decision_maker boolean NOT NULL DEFAULT false,
  owner             text,
  status            text NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','unqualified','bounced','archived')),
  tags              text[] NOT NULL DEFAULT '{}',
  custom_fields     jsonb  NOT NULL DEFAULT '{}',
  do_not_contact    boolean NOT NULL DEFAULT false,
  source            text,
  source_lead_id    uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_by        uuid,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_contacts_tenant_email
  ON contacts (tenant_id, lower(email));
CREATE INDEX IF NOT EXISTS idx_contacts_company
  ON contacts (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_status
  ON contacts (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_owner
  ON contacts (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_contacts_tags
  ON contacts USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_contacts_dnc
  ON contacts (tenant_id) WHERE do_not_contact = true;
-- At most one primary contact per company
CREATE UNIQUE INDEX IF NOT EXISTS idx_contacts_one_primary
  ON contacts (company_id) WHERE is_primary = true AND company_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_contacts_updated_at ON contacts;
CREATE TRIGGER trg_contacts_updated_at BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE contacts IS
  'Tenant-curated people. Distinct from lead_contacts (scraped decision-makers '
  'attached to leads_global). do_not_contact must be honoured by all outreach.';

-- ---------------------------------------------------------------------------
-- 3. deal_stages — per-tenant configurable deal pipeline
--
-- Separate from pipeline_stages (which stages LEAD ASSIGNMENTS in the lead
-- engine). Deals move through their own stages with win probabilities.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deal_stages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  slug          text NOT NULL,
  position      int  NOT NULL DEFAULT 0,
  color         text,
  probability   int  NOT NULL DEFAULT 0 CHECK (probability BETWEEN 0 AND 100),
  is_won        boolean NOT NULL DEFAULT false,
  is_lost       boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_deal_stages_tenant_position
  ON deal_stages (tenant_id, position);

DROP TRIGGER IF EXISTS trg_deal_stages_updated_at ON deal_stages;
CREATE TRIGGER trg_deal_stages_updated_at BEFORE UPDATE ON deal_stages
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE deal_stages IS
  'Deal pipeline stages per tenant. Distinct from pipeline_stages, which '
  'stages lead_assignments in the lead engine.';


-- ---------------------------------------------------------------------------
-- 4. deals — opportunities
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deals (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id           uuid REFERENCES companies(id) ON DELETE CASCADE,
  primary_contact_id   uuid REFERENCES contacts(id) ON DELETE SET NULL,
  title                text NOT NULL,
  description          text,
  value                numeric(14,2),
  currency             text NOT NULL DEFAULT 'USD',
  stage_id             uuid REFERENCES deal_stages(id) ON DELETE SET NULL,
  probability          int CHECK (probability IS NULL OR probability BETWEEN 0 AND 100),
  expected_close_date  date,
  actual_close_date    date,
  status               text NOT NULL DEFAULT 'open'
                         CHECK (status IN ('open','won','lost')),
  lost_reason          text,
  owner                text,
  source               text,
  source_assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  tags                 text[] NOT NULL DEFAULT '{}',
  custom_fields        jsonb  NOT NULL DEFAULT '{}',
  created_by           uuid,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_deals_tenant_status
  ON deals (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_stage
  ON deals (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_deals_company
  ON deals (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_contact
  ON deals (primary_contact_id) WHERE primary_contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_tenant_owner
  ON deals (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_expected_close
  ON deals (tenant_id, expected_close_date) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_deals_tags
  ON deals USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_deals_source_assignment
  ON deals (source_assignment_id) WHERE source_assignment_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_deals_updated_at ON deals;
CREATE TRIGGER trg_deals_updated_at BEFORE UPDATE ON deals
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE deals IS
  'Opportunities. source_assignment_id ties a deal back to the lead engine '
  'assignment it originated from, for closed-loop attribution.';


-- ---------------------------------------------------------------------------
-- 5. activities — unified polymorphic timeline
--
-- NEW TABLE, distinct from the existing lead_activities. Do not conflate:
--   lead_activities : keyed to a lead_assignment only; columns title/created_at.
--                     Written by /crm/{t}/leads/{a}/activities and kept as-is.
--   activities      : account/contact/deal grain; columns subject/occurred_at/
--                     direction/duration_minutes/outcome. Can ALSO reference an
--                     assignment_id, so a lead-era event can be carried forward
--                     onto the account timeline after conversion.
-- Both remain live. lead_activities is untouched by this migration.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activities (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  activity_type    text NOT NULL DEFAULT 'note'
                     CHECK (activity_type IN
                       ('call','email','meeting','note','task','stage_change','system')),
  subject          text,
  body             text,
  direction        text CHECK (direction IS NULL OR direction IN ('inbound','outbound')),
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  duration_minutes int,
  outcome          text,
  company_id       uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id       uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id          uuid REFERENCES deals(id) ON DELETE CASCADE,
  assignment_id    uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  created_by       uuid,
  meta             jsonb NOT NULL DEFAULT '{}',
  created_at       timestamptz NOT NULL DEFAULT now()
);

-- Primary timeline query
CREATE INDEX IF NOT EXISTS idx_activities_tenant_occurred
  ON activities (tenant_id, occurred_at DESC);
-- Per-entity timelines
CREATE INDEX IF NOT EXISTS idx_activities_company
  ON activities (company_id, occurred_at DESC) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_contact
  ON activities (contact_id, occurred_at DESC) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_deal
  ON activities (deal_id, occurred_at DESC) WHERE deal_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_assignment
  ON activities (assignment_id, occurred_at DESC) WHERE assignment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_tenant_type
  ON activities (tenant_id, activity_type, occurred_at DESC);

COMMENT ON TABLE activities IS
  'Unified CRM timeline across companies/contacts/deals (and optionally a lead '
  'assignment). NEW and separate from lead_activities, which stays the lead-'
  'assignment-only timeline with its own title/created_at columns.';


-- ---------------------------------------------------------------------------
-- 6. tasks — CRM to-dos (distinct from lead_tasks, which is assignment-scoped)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  title         text NOT NULL,
  description   text,
  due_at        timestamptz,
  completed_at  timestamptz,
  status        text NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open','done','cancelled')),
  priority      text NOT NULL DEFAULT 'medium'
                  CHECK (priority IN ('low','medium','high','urgent')),
  assigned_to   text,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id    uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id       uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tasks_tenant_status_due
  ON tasks (tenant_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_tasks_tenant_assigned
  ON tasks (tenant_id, assigned_to) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_tasks_company
  ON tasks (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tasks_contact
  ON tasks (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tasks_deal
  ON tasks (deal_id) WHERE deal_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_tasks_updated_at ON tasks;
CREATE TRIGGER trg_tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE tasks IS
  'CRM tasks against companies/contacts/deals. Separate from lead_tasks, '
  'which is scoped to a lead_assignment.';


-- ---------------------------------------------------------------------------
-- 7. notes
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  body          text NOT NULL,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id    uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id       uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notes_tenant_created
  ON notes (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_company
  ON notes (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notes_contact
  ON notes (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notes_deal
  ON notes (deal_id) WHERE deal_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_notes_updated_at ON notes;
CREATE TRIGGER trg_notes_updated_at BEFORE UPDATE ON notes
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();


-- ---------------------------------------------------------------------------
-- 8. custom_field_defs — schema for the custom_fields jsonb on each entity
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS custom_field_defs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  entity_type   text NOT NULL CHECK (entity_type IN ('company','contact','deal')),
  field_key     text NOT NULL,
  label         text NOT NULL,
  field_type    text NOT NULL DEFAULT 'text'
                  CHECK (field_type IN ('text','number','date','select','bool')),
  options       jsonb NOT NULL DEFAULT '[]',   -- choices when field_type = 'select'
  position      int   NOT NULL DEFAULT 0,
  required      boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, entity_type, field_key)
);

CREATE INDEX IF NOT EXISTS idx_custom_field_defs_tenant_entity
  ON custom_field_defs (tenant_id, entity_type, position);

DROP TRIGGER IF EXISTS trg_custom_field_defs_updated_at ON custom_field_defs;
CREATE TRIGGER trg_custom_field_defs_updated_at BEFORE UPDATE ON custom_field_defs
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE custom_field_defs IS
  'Declares the keys allowed in companies/contacts/deals.custom_fields jsonb, '
  'and how the UI should render them.';


-- ---------------------------------------------------------------------------
-- 9. email_log
--
-- Complements email_sends (sql/014), which is the lead-engine outreach ledger
-- keyed by assignment/lead. email_log is the CRM-side record keyed by
-- contact/deal. Both are kept; neither is modified.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS email_log (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  to_email            text NOT NULL,
  from_email          text,
  subject             text,
  body_preview        text,
  status              text NOT NULL DEFAULT 'queued'
                        CHECK (status IN ('queued','sent','failed','bounced','opened','replied')),
  provider            text,
  provider_message_id text,
  error               text,
  contact_id          uuid REFERENCES contacts(id) ON DELETE SET NULL,
  deal_id             uuid REFERENCES deals(id) ON DELETE SET NULL,
  assignment_id       uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  sent_at             timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_log_tenant_sent
  ON email_log (tenant_id, sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_log_tenant_status
  ON email_log (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_email_log_contact
  ON email_log (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_deal
  ON email_log (deal_id) WHERE deal_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_assignment
  ON email_log (assignment_id) WHERE assignment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_provider_msg
  ON email_log (provider_message_id) WHERE provider_message_id IS NOT NULL;


-- ---------------------------------------------------------------------------
-- 10. call_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS call_log (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id       uuid REFERENCES contacts(id) ON DELETE SET NULL,
  deal_id          uuid REFERENCES deals(id) ON DELETE SET NULL,
  assignment_id    uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  direction        text CHECK (direction IS NULL OR direction IN ('inbound','outbound')),
  duration_minutes int,
  outcome          text,
  notes            text,
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  created_by       uuid,
  created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_call_log_tenant_occurred
  ON call_log (tenant_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_log_contact
  ON call_log (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_call_log_deal
  ON call_log (deal_id) WHERE deal_id IS NOT NULL;

-- =============================================================================
-- Row-Level Security
--
-- Exact pattern from sql/004_rls_and_auth.sql: membership is gated through
-- tenant_members via public.is_tenant_member() / public.is_tenant_admin().
-- Service role bypasses RLS (that is how the backend pipeline writes).
-- Every policy is dropped before create so this file is re-runnable.
--
-- Reads + writes are member-scoped; DELETE is admin-only on the four
-- durable record types (companies, contacts, deals, deal_stages) and on
-- custom_field_defs, matching how 004 restricts assignments_delete.
-- =============================================================================

ALTER TABLE companies          ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts           ENABLE ROW LEVEL SECURITY;
ALTER TABLE deal_stages        ENABLE ROW LEVEL SECURITY;
ALTER TABLE deals              ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities         ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks              ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes              ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_field_defs  ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_log          ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_log           ENABLE ROW LEVEL SECURITY;

-- companies
DROP POLICY IF EXISTS companies_select ON companies;
CREATE POLICY companies_select ON companies FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_insert ON companies;
CREATE POLICY companies_insert ON companies FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_update ON companies;
CREATE POLICY companies_update ON companies FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_delete ON companies;
CREATE POLICY companies_delete ON companies FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- contacts
DROP POLICY IF EXISTS contacts_select ON contacts;
CREATE POLICY contacts_select ON contacts FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_insert ON contacts;
CREATE POLICY contacts_insert ON contacts FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_update ON contacts;
CREATE POLICY contacts_update ON contacts FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_delete ON contacts;
CREATE POLICY contacts_delete ON contacts FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- deal_stages: everyone reads, admins reshape the pipeline
DROP POLICY IF EXISTS deal_stages_select ON deal_stages;
CREATE POLICY deal_stages_select ON deal_stages FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deal_stages_write ON deal_stages;
CREATE POLICY deal_stages_write ON deal_stages FOR ALL
  USING (public.is_tenant_admin(tenant_id))
  WITH CHECK (public.is_tenant_admin(tenant_id));

-- deals
DROP POLICY IF EXISTS deals_select ON deals;
CREATE POLICY deals_select ON deals FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_insert ON deals;
CREATE POLICY deals_insert ON deals FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_update ON deals;
CREATE POLICY deals_update ON deals FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_delete ON deals;
CREATE POLICY deals_delete ON deals FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- activities / tasks / notes: full member access (matches 004's *_all pattern)
DROP POLICY IF EXISTS activities_all ON activities;
CREATE POLICY activities_all ON activities FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS crm_tasks_all ON tasks;
CREATE POLICY crm_tasks_all ON tasks FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS notes_all ON notes;
CREATE POLICY notes_all ON notes FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

-- custom_field_defs: members read the schema, admins change it
DROP POLICY IF EXISTS custom_field_defs_select ON custom_field_defs;
CREATE POLICY custom_field_defs_select ON custom_field_defs FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS custom_field_defs_write ON custom_field_defs;
CREATE POLICY custom_field_defs_write ON custom_field_defs FOR ALL
  USING (public.is_tenant_admin(tenant_id))
  WITH CHECK (public.is_tenant_admin(tenant_id));

-- email_log / call_log: read-only to members; writes come from the backend
-- (service role) so no INSERT policy is granted to authenticated clients.
DROP POLICY IF EXISTS email_log_select ON email_log;
CREATE POLICY email_log_select ON email_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS call_log_select ON call_log;
CREATE POLICY call_log_select ON call_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
-- Manual call logging from the UI is a member action, so allow inserts there.
DROP POLICY IF EXISTS call_log_insert ON call_log;
CREATE POLICY call_log_insert ON call_log FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));


-- =============================================================================
-- Tags: decision recorded
--
-- Tags in this schema are the `tags text[]` columns on companies, contacts and
-- deals, GIN-indexed for `@>` / Supabase `.contains()` lookups. This matches
-- the pattern already used by lead_assignments.tags (sql/015) and keeps
-- filtering to a single index-backed predicate with no join.
--
-- Consequences accepted: no rename-in-one-place, no per-tag colour or usage
-- count. If those become requirements, add tags + taggings later and backfill
-- from these arrays — do NOT run both models at once.
--
-- The existing lead_tags table is a different thing (one row per tag per lead
-- ASSIGNMENT, in the lead engine) and is left untouched.
-- =============================================================================

COMMENT ON COLUMN companies.tags IS 'Free-form tags; GIN-indexed. Canonical tag store for this entity — there is no separate tags table.';
COMMENT ON COLUMN contacts.tags  IS 'Free-form tags; GIN-indexed.';
COMMENT ON COLUMN deals.tags     IS 'Free-form tags; GIN-indexed.';
