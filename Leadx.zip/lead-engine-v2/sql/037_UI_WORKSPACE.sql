-- Workspace UI preferences and saved command-center layouts
CREATE TABLE IF NOT EXISTS workspace_preferences (
  tenant_id uuid PRIMARY KEY,
  dashboard_layout jsonb NOT NULL DEFAULT '{}',
  density text NOT NULL DEFAULT 'comfortable',
  default_view text NOT NULL DEFAULT 'command_center',
  updated_at timestamptz NOT NULL DEFAULT now()
);
