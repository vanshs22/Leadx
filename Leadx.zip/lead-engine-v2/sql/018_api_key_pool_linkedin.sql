-- Allow LinkedIn li_at cookies (and related providers) in api_key_pool
-- Error fixed: violates check constraint "api_key_pool_provider_check"

ALTER TABLE public.api_key_pool
  DROP CONSTRAINT IF EXISTS api_key_pool_provider_check;

ALTER TABLE public.api_key_pool
  ADD CONSTRAINT api_key_pool_provider_check
  CHECK (provider IN (
    'serper',
    'firecrawl',
    'anthropic',
    'gemini',
    'groq',
    'openai',
    'resend',
    'linkedin_scraper',
    'linkedin',
    'instagram',
    'twilio',
    'vapi',
    'scrapingbee',
    'bright_data'
  ));
