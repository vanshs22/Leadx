-- Explicit revenue funnel/event ledger for attribution and auditability
CREATE TABLE IF NOT EXISTS revenue_funnel_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  lead_id uuid,
  assignment_id uuid,
  deal_id uuid,
  event_type text NOT NULL,
  source text,
  metadata jsonb NOT NULL DEFAULT '{}',
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_revenue_funnel_tenant ON revenue_funnel_events(tenant_id,occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_revenue_funnel_lead ON revenue_funnel_events(lead_id,occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_revenue_funnel_deal ON revenue_funnel_events(deal_id,occurred_at DESC);

CREATE TABLE IF NOT EXISTS revenue_attribution (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  deal_id uuid,
  lead_id uuid,
  assignment_id uuid,
  attribution_model text NOT NULL DEFAULT 'first_touch',
  revenue_amount numeric(16,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  weight numeric(8,5) NOT NULL DEFAULT 1,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_revenue_attribution_tenant ON revenue_attribution(tenant_id,created_at DESC);
