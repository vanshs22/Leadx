-- Atomic monthly lead quota reservations.
-- Normal/direct pipeline slots cannot consume quota already reserved by approved discovery requests.
CREATE OR REPLACE FUNCTION public.reserve_tenant_lead_slot(p_tenant_id uuid, p_tier text DEFAULT 'A')
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
  lim int;
  used int;
  reserved int;
BEGIN
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id FOR UPDATE;
  IF lim IS NULL THEN RETURN false; END IF;
  INSERT INTO usage_log (tenant_id, period, leads_delivered, quota_reserved, tier_a_count, tier_b_count, tier_c_count)
  VALUES (p_tenant_id, p, 0, 0, 0, 0, 0)
  ON CONFLICT (tenant_id, period) DO NOTHING;
  SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0) INTO used, reserved
  FROM usage_log WHERE tenant_id = p_tenant_id AND period = p FOR UPDATE;
  IF used + reserved >= lim THEN RETURN false; END IF;
  UPDATE usage_log
  SET leads_delivered = leads_delivered + 1,
      tier_a_count = tier_a_count + CASE WHEN upper(coalesce(p_tier,'A')) = 'A' THEN 1 ELSE 0 END,
      tier_b_count = tier_b_count + CASE WHEN upper(coalesce(p_tier,'A')) = 'B' THEN 1 ELSE 0 END,
      tier_c_count = tier_c_count + CASE WHEN upper(coalesce(p_tier,'A')) = 'C' THEN 1 ELSE 0 END,
      updated_at = now()
  WHERE tenant_id = p_tenant_id AND period = p;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_tenant_lead_slot(p_tenant_id uuid, p_tier text DEFAULT 'A')
RETURNS void LANGUAGE plpgsql AS $$
DECLARE p date := date_trunc('month', now())::date;
BEGIN
  UPDATE usage_log
  SET leads_delivered = GREATEST(leads_delivered - 1, 0),
      tier_a_count = GREATEST(tier_a_count - CASE WHEN upper(coalesce(p_tier,'A')) = 'A' THEN 1 ELSE 0 END, 0),
      tier_b_count = GREATEST(tier_b_count - CASE WHEN upper(coalesce(p_tier,'A')) = 'B' THEN 1 ELSE 0 END, 0),
      tier_c_count = GREATEST(tier_c_count - CASE WHEN upper(coalesce(p_tier,'A')) = 'C' THEN 1 ELSE 0 END, 0),
      updated_at = now()
  WHERE tenant_id = p_tenant_id AND period = p;
END;
$$;
