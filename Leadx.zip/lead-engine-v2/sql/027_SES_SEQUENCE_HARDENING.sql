-- LeadX: production SES sequence hardening
-- Idempotent migration. Apply after the existing email/CRM migrations.

CREATE TABLE IF NOT EXISTS public.email_sequences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_email_sequences_tenant ON public.email_sequences(tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.email_sequence_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence_id uuid NOT NULL REFERENCES public.email_sequences(id) ON DELETE CASCADE,
  step_number int NOT NULL CHECK (step_number > 0),
  delay_days int NOT NULL DEFAULT 0 CHECK (delay_days >= 0),
  subject text NOT NULL,
  body_html text NOT NULL,
  body_text text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(sequence_id, step_number)
);
CREATE INDEX IF NOT EXISTS idx_email_sequence_steps_sequence ON public.email_sequence_steps(sequence_id, step_number);

CREATE TABLE IF NOT EXISTS public.email_sequence_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  sequence_id uuid NOT NULL REFERENCES public.email_sequences(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL,
  current_step int NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  next_send_at timestamptz,
  deferred_reason text,
  locked_at timestamptz,
  locked_by text,
  last_error text,
  last_provider_id text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(sequence_id, assignment_id)
);
CREATE INDEX IF NOT EXISTS idx_email_sequence_due ON public.email_sequence_enrollments(status, next_send_at);
CREATE INDEX IF NOT EXISTS idx_email_sequence_tenant ON public.email_sequence_enrollments(tenant_id, status);

-- One durable record per attempted sequence step. This is the idempotency/audit
-- boundary: a worker crash after provider acceptance can be reconciled instead
-- of blindly sending the same step again.
CREATE TABLE IF NOT EXISTS public.email_sequence_sends (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id uuid NOT NULL REFERENCES public.email_sequence_enrollments(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL,
  step_number int NOT NULL,
  idempotency_key text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'sending',
  provider text,
  provider_id text,
  to_email text,
  subject text,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  UNIQUE(enrollment_id, step_number)
);
CREATE INDEX IF NOT EXISTS idx_email_sequence_sends_enrollment ON public.email_sequence_sends(enrollment_id, step_number);
CREATE INDEX IF NOT EXISTS idx_email_sequence_sends_provider_id ON public.email_sequence_sends(provider, provider_id);

CREATE TABLE IF NOT EXISTS public.email_bounces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  email text NOT NULL,
  event_type text NOT NULL,
  bounce_type text,
  sub_type text,
  diagnostic text,
  suppressed boolean NOT NULL DEFAULT false,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_email_bounces_email ON public.email_bounces(lower(email), created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_bounces_tenant ON public.email_bounces(tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.email_domain_daily (
  day date NOT NULL,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  domain text NOT NULL,
  sent_count int NOT NULL DEFAULT 0,
  PRIMARY KEY(day, tenant_id, domain)
);

CREATE TABLE IF NOT EXISTS public.domain_warmup (
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  domain text NOT NULL,
  started_on date NOT NULL DEFAULT current_date,
  start_cap int NOT NULL DEFAULT 20,
  full_cap int NOT NULL DEFAULT 500,
  ramp_days int NOT NULL DEFAULT 21,
  paused boolean NOT NULL DEFAULT false,
  PRIMARY KEY(tenant_id, domain)
);

-- Provider-independent suppression + opt-out tables are created elsewhere in
-- the project; these indexes make the sequence send-time gate inexpensive.
CREATE INDEX IF NOT EXISTS idx_email_sends_to_email ON public.email_sends(lower(to_email), created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_sends_assignment_created ON public.email_sends(assignment_id, created_at DESC);

NOTIFY pgrst, 'reload schema';
