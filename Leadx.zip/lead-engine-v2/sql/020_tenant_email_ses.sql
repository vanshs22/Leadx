
-- Tenant email / SES domain (idempotent)
CREATE TABLE IF NOT EXISTS public.tenant_email_settings (
  tenant_id uuid PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'ses',
  from_name text,
  from_email text,
  reply_to text,
  domain text,
  domain_verified boolean NOT NULL DEFAULT false,
  dkim_status text,
  dns_records jsonb DEFAULT '[]'::jsonb,
  daily_limit int DEFAULT 500,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tenant_email_domain
  ON public.tenant_email_settings(domain)
  WHERE domain IS NOT NULL;

NOTIFY pgrst, 'reload schema';
