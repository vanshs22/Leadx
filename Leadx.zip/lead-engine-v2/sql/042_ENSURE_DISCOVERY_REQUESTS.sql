-- 042_ENSURE_DISCOVERY_REQUESTS.sql
-- Client "Request opportunities" needs this table.
CREATE TABLE IF NOT EXISTS public.discovery_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  icp_id uuid,
  vertical text,
  locations jsonb DEFAULT '[]'::jsonb,
  keywords jsonb DEFAULT '[]'::jsonb,
  offer_category text,
  requested_leads int DEFAULT 0,
  approved_leads int,
  assigned_count int DEFAULT 0,
  discovered_count int DEFAULT 0,
  global_stored_count int DEFAULT 0,
  enriched_count int DEFAULT 0,
  status text DEFAULT 'pending_approval',
  requested_by text,
  meta jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);
CREATE INDEX IF NOT EXISTS discovery_requests_tenant_idx ON public.discovery_requests (tenant_id);
CREATE INDEX IF NOT EXISTS discovery_requests_status_idx ON public.discovery_requests (status);

-- usage_log for quota display
CREATE TABLE IF NOT EXISTS public.usage_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  period text NOT NULL,
  leads_delivered int DEFAULT 0,
  quota_reserved int DEFAULT 0,
  UNIQUE (tenant_id, period)
);

NOTIFY pgrst, 'reload schema';
