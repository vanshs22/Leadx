-- Fix: seed_default_stages was defined twice (RETURNS int then RETURNS void)
DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);

CREATE OR REPLACE FUNCTION public.seed_default_stages(p_tenant_id uuid)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted int := 0;
BEGIN
  IF p_tenant_id IS NULL THEN
    RETURN 0;
  END IF;

  IF EXISTS (SELECT 1 FROM pipeline_stages WHERE tenant_id = p_tenant_id) THEN
    RETURN 0;
  END IF;

  INSERT INTO pipeline_stages (tenant_id, name, slug, position, color, is_won, is_lost)
  VALUES
    (p_tenant_id, 'New',         'new',         1, '#94a3b8', false, false),
    (p_tenant_id, 'Contacted',   'contacted',   2, '#3b82f6', false, false),
    (p_tenant_id, 'Qualified',   'qualified',   3, '#8b5cf6', false, false),
    (p_tenant_id, 'Proposal',    'proposal',    4, '#f59e0b', false, false),
    (p_tenant_id, 'Negotiation', 'negotiation', 5, '#f97316', false, false),
    (p_tenant_id, 'Won',         'won',         6, '#22c55e', true,  false),
    (p_tenant_id, 'Lost',        'lost',        7, '#ef4444', false, true)
  ON CONFLICT (tenant_id, slug) DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted;
END;
$$;

GRANT EXECUTE ON FUNCTION public.seed_default_stages(uuid) TO authenticated, service_role;
