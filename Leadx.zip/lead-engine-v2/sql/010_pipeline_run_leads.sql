-- 010_pipeline_run_leads.sql
-- Per-run lead board: stage + tier + include for operator drag-drop review

create table if not exists public.pipeline_run_leads (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.pipeline_runs(id) on delete cascade,
  lead_id uuid not null references public.leads_global(id) on delete cascade,
  tenant_id uuid references public.tenants(id) on delete set null,
  stage text not null default 'discovered',  -- discovered | enriched | gated | assigned | excluded
  tier text,                                 -- A | B | C
  included boolean not null default true,
  score int,
  source text,
  name text,
  phone text,
  website text,
  city text,
  position int default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (run_id, lead_id)
);

create index if not exists idx_prl_run on public.pipeline_run_leads(run_id);
create index if not exists idx_prl_tenant on public.pipeline_run_leads(tenant_id);
create index if not exists idx_prl_stage on public.pipeline_run_leads(run_id, stage);

-- Optional: allow service role full access (RLS policies as needed)
alter table public.pipeline_run_leads enable row level security;
drop policy if exists "service_all_pipeline_run_leads" on public.pipeline_run_leads;
create policy "service_all_pipeline_run_leads" on public.pipeline_run_leads
  for all using (true) with check (true);
