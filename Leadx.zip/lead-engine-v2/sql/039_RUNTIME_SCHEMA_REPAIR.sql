-- LeadX runtime schema repair / compatibility migration.
-- Safe to run against an existing installation. This repairs runtime tables that
-- were referenced by application code but were missing from older migration
-- chains, and backfills columns on automation tables created by early builds.

-- ---------------------------------------------------------------------------
-- Worker heartbeat compatibility. Older installs used last_seen_at only; newer
-- control-plane diagnostics also record an observation timestamp. Keep both so
-- old databases cannot break the scale/admin pages during migration.
CREATE TABLE IF NOT EXISTS worker_heartbeats (
  worker_id text PRIMARY KEY,
  kinds text[] NOT NULL DEFAULT '{}',
  capacity integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'healthy',
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  observed_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  active_jobs integer NOT NULL DEFAULT 0
);
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS kinds text[] NOT NULL DEFAULT '{}';
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS capacity integer NOT NULL DEFAULT 1;
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'healthy';
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS last_seen_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE worker_heartbeats ADD COLUMN IF NOT EXISTS active_jobs integer NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS idx_worker_heartbeats_observed_runtime ON worker_heartbeats(observed_at DESC);

-- ---------------------------------------------------------------------------
-- Replies / inbound email
CREATE TABLE IF NOT EXISTS email_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  from_email text NOT NULL,
  subject text,
  body_text text,
  category text NOT NULL DEFAULT 'unclassified',
  message_id text,
  metadata jsonb NOT NULL DEFAULT '{}',
  received_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS from_email text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'unclassified';
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS message_id text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}';
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS received_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_email_replies_tenant_received ON email_replies(tenant_id, received_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_replies_assignment ON email_replies(assignment_id, received_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_replies_category ON email_replies(tenant_id, category, received_at DESC);

-- ---------------------------------------------------------------------------
-- Tenant/global opt-out ledger. The application intentionally fails closed if
-- this table cannot be read, so it must exist before email automation is used.
CREATE TABLE IF NOT EXISTS email_optouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  email text NOT NULL,
  reason text,
  source text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE email_optouts ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE email_optouts ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE email_optouts ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_email_optouts_tenant_email ON email_optouts(tenant_id, email);
CREATE INDEX IF NOT EXISTS idx_email_optouts_email ON email_optouts(lower(email));

-- ---------------------------------------------------------------------------
-- Lead contact/touch history used by send-policy minimum-gap protection.
CREATE TABLE IF NOT EXISTS lead_touches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  channel text NOT NULL,
  meta jsonb NOT NULL DEFAULT '{}',
  touched_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS channel text;
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS meta jsonb NOT NULL DEFAULT '{}';
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS touched_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_lead_touches_assignment ON lead_touches(assignment_id, touched_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_touches_tenant ON lead_touches(tenant_id, touched_at DESC);

-- ---------------------------------------------------------------------------
-- AI email/template experiment ledger.
CREATE TABLE IF NOT EXISTS template_variant_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  category text NOT NULL,
  variant_key text NOT NULL,
  sent int NOT NULL DEFAULT 0,
  opened int NOT NULL DEFAULT 0,
  replied int NOT NULL DEFAULT 0,
  positive int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS sent int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS opened int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS replied int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS positive int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_template_variant_stats_tenant ON template_variant_stats(tenant_id, category, variant_key) WHERE tenant_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_template_variant_stats_global ON template_variant_stats(category, variant_key) WHERE tenant_id IS NULL;

-- ---------------------------------------------------------------------------
-- Webhook idempotency ledger.
CREATE TABLE IF NOT EXISTS webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id text NOT NULL UNIQUE,
  source text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  received_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}';
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS received_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_webhook_events_event_id ON webhook_events(event_id);
CREATE INDEX IF NOT EXISTS idx_webhook_events_received ON webhook_events(received_at DESC);

-- ---------------------------------------------------------------------------
-- Automation compatibility backfill. Older installs may have created these
-- tables with a subset of the current columns. CREATE TABLE IF NOT EXISTS does
-- not add columns, so explicitly repair them here. The CREATE guards also make
-- this repair file safe to run by itself after a partially-applied migration.
CREATE TABLE IF NOT EXISTS campaign_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  icp_id uuid,
  industry text,
  locations jsonb NOT NULL DEFAULT '[]',
  queries jsonb NOT NULL DEFAULT '[]',
  params jsonb NOT NULL DEFAULT '{}',
  target_new_leads int NOT NULL DEFAULT 25,
  interval_hours int NOT NULL DEFAULT 24,
  auto_enroll_sequence_id uuid,
  active boolean NOT NULL DEFAULT true,
  last_run_at timestamptz,
  last_status text,
  last_result jsonb,
  next_run_at timestamptz NOT NULL DEFAULT now(),
  created_by text DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS industry text;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS locations jsonb NOT NULL DEFAULT '[]';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS queries jsonb NOT NULL DEFAULT '[]';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS params jsonb NOT NULL DEFAULT '{}';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS target_new_leads int NOT NULL DEFAULT 25;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS interval_hours int NOT NULL DEFAULT 24;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS auto_enroll_sequence_id uuid;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS last_status text;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS last_result jsonb;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS next_run_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS created_by text DEFAULT 'admin';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_schedules_due_runtime ON campaign_schedules(next_run_at) WHERE active;
CREATE INDEX IF NOT EXISTS idx_schedules_tenant_runtime ON campaign_schedules(tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS autonomous_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  icp_id uuid,
  sequence_id uuid,
  status text NOT NULL DEFAULT 'draft',
  locations jsonb NOT NULL DEFAULT '[]',
  queries jsonb NOT NULL DEFAULT '[]',
  offer text,
  goal text,
  daily_new_lead_limit int NOT NULL DEFAULT 25,
  daily_email_limit int NOT NULL DEFAULT 25,
  max_active_enrollments int NOT NULL DEFAULT 5000,
  send_window_start time NOT NULL DEFAULT '09:00',
  send_window_end time NOT NULL DEFAULT '17:00',
  timezone text NOT NULL DEFAULT 'America/New_York',
  generate_ai_copy boolean NOT NULL DEFAULT true,
  auto_followup boolean NOT NULL DEFAULT true,
  stop_on_reply boolean NOT NULL DEFAULT true,
  stop_on_optout boolean NOT NULL DEFAULT true,
  require_verified_email boolean NOT NULL DEFAULT true,
  score_threshold int NOT NULL DEFAULT 70,
  schedule_hours int NOT NULL DEFAULT 24,
  next_discovery_at timestamptz,
  last_discovery_at timestamptz,
  last_discovery_result jsonb NOT NULL DEFAULT '{}',
  created_by text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS sequence_id uuid;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'draft';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS locations jsonb NOT NULL DEFAULT '[]';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS queries jsonb NOT NULL DEFAULT '[]';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS offer text;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS goal text;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_new_lead_limit int NOT NULL DEFAULT 25;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_email_limit int NOT NULL DEFAULT 25;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS max_active_enrollments int NOT NULL DEFAULT 5000;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_start time NOT NULL DEFAULT '09:00';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_end time NOT NULL DEFAULT '17:00';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS timezone text NOT NULL DEFAULT 'America/New_York';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS generate_ai_copy boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS auto_followup boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_reply boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_optout boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS require_verified_email boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS score_threshold int NOT NULL DEFAULT 70;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS schedule_hours int NOT NULL DEFAULT 24;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS next_discovery_at timestamptz;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_at timestamptz;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_result jsonb NOT NULL DEFAULT '{}';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS created_by text NOT NULL DEFAULT 'admin';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_due_runtime ON autonomous_campaigns(next_discovery_at) WHERE status = 'active';

-- The operator tenant flag is required by admin automation/prospecting.
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS is_operator boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS idx_tenants_single_operator_runtime ON tenants(is_operator) WHERE is_operator;

-- ---------------------------------------------------------------------------
-- Lightweight schema verification view/function for diagnostics. It does not
-- expose secrets and is safe for the service-key backend to query.
CREATE OR REPLACE FUNCTION leadx_runtime_schema_status()
RETURNS TABLE(object_name text, object_kind text, present boolean)
LANGUAGE sql STABLE AS $$
  SELECT x.name, x.kind,
    CASE WHEN x.kind = 'table' THEN to_regclass('public.' || x.name) IS NOT NULL
         WHEN x.kind = 'view' THEN to_regclass('public.' || x.name) IS NOT NULL
         ELSE false END AS present
  FROM (VALUES
    ('email_replies','table'),
    ('email_optouts','table'),
    ('lead_touches','table'),
    ('template_variant_stats','table'),
    ('webhook_events','table'),
    ('campaign_schedules','table'),
    ('autonomous_campaigns','table'),
    ('crm_lead_cards','view'),
    ('worker_heartbeats','table')
  ) AS x(name,kind);
$$;

-- Supabase/PostgREST may retain a schema cache briefly after DDL. Ask it to
-- reload so newly repaired tables are visible immediately to REST clients.
NOTIFY pgrst, 'reload schema';

-- PostgREST must refresh its schema cache after new runtime tables/columns are
-- introduced. Without this, Supabase can return PGRST205 even though the table
-- was successfully created in public.
DO $$
BEGIN
  PERFORM pg_notify('pgrst', 'reload schema');
EXCEPTION WHEN OTHERS THEN
  -- pg_notify is best-effort; the migration itself must remain successful.
  NULL;
END $$;

-- ---------------------------------------------------------------------------
-- In-app notifications. Required by tenant/admin notification feeds and by
-- pipeline/SES/job handlers. Keep this in the runtime repair so an installation
-- that ran only the consolidated/safe migration cannot miss this table.
CREATE TABLE IF NOT EXISTS public.notifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope       text NOT NULL DEFAULT 'tenant'
              CHECK (scope IN ('tenant', 'admin')),
  tenant_id   uuid,
  kind        text NOT NULL,
  severity    text NOT NULL DEFAULT 'info'
              CHECK (severity IN ('info', 'warning', 'critical')),
  title       text NOT NULL,
  body        text NOT NULL DEFAULT '',
  link        text,
  meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS scope text NOT NULL DEFAULT 'tenant';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'system';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS severity text NOT NULL DEFAULT 'info';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS title text NOT NULL DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS body text NOT NULL DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS link text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS meta jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS read_at timestamptz;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_notifications_scope_created ON public.notifications(scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_tenant_unread ON public.notifications(tenant_id, created_at DESC) WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_notifications_admin_unread ON public.notifications(scope, created_at DESC) WHERE scope = 'admin' AND read_at IS NULL;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_all_notifications" ON public.notifications;
CREATE POLICY "service_all_notifications" ON public.notifications FOR ALL USING (true) WITH CHECK (true);

-- PostgREST must refresh its schema cache after all runtime DDL above.
NOTIFY pgrst, 'reload schema';
DO $$
BEGIN
  PERFORM pg_notify('pgrst', 'reload schema');
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;
