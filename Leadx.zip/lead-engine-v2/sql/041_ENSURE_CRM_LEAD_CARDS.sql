-- 041_ENSURE_CRM_LEAD_CARDS.sql
-- Safe view for client portal leads. Matches real leads_global columns.
-- Run in Supabase SQL Editor, then: NOTIFY pgrst, 'reload schema';

-- Ensure common columns exist (no-op if already present)
ALTER TABLE public.leads_global
  ADD COLUMN IF NOT EXISTS phone_normalized text,
  ADD COLUMN IF NOT EXISTS phone_e164 text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS name text;

ALTER TABLE public.lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS score int,
  ADD COLUMN IF NOT EXISTS delivered_at timestamptz,
  ADD COLUMN IF NOT EXISTS priority text,
  ADD COLUMN IF NOT EXISTS delivery_status text,
  ADD COLUMN IF NOT EXISTS vertical text,
  ADD COLUMN IF NOT EXISTS offer_category text;

CREATE OR REPLACE VIEW public.crm_lead_cards AS
SELECT
  la.id AS assignment_id,
  la.tenant_id,
  la.lead_id,
  COALESCE(la.status, 'active') AS assignment_status,
  la.delivery_status,
  COALESCE(la.delivered_at, la.created_at) AS delivered_at,
  la.priority,
  la.next_action_at,
  la.last_contacted_at,
  la.value_estimate,
  la.tags,
  la.custom_fields,
  la.assigned_to,
  la.stage_id,
  COALESCE(ps.name, 'New') AS stage_name,
  COALESCE(ps.slug, la.stage_slug, 'new') AS stage_slug,
  COALESCE(ps.color, '#888888') AS stage_color,
  COALESCE(ps.position, 0) AS stage_position,
  lg.name AS company_name,
  lg.name AS name,
  lg.category,
  -- phone column may not exist on older schemas — use normalized/e164 only
  COALESCE(lg.phone_e164, lg.phone_normalized) AS phone,
  lg.phone_normalized,
  lg.phone_e164,
  lg.email,
  lg.website,
  lg.city,
  lg.state,
  lg.address,
  COALESCE(la.tier, 'B') AS tier,
  COALESCE(la.score, 0) AS total_score,
  la.vertical,
  la.offer_category,
  la.created_at
FROM public.lead_assignments la
LEFT JOIN public.leads_global lg ON lg.id = la.lead_id
LEFT JOIN public.pipeline_stages ps ON ps.id = la.stage_id AND ps.tenant_id = la.tenant_id;

GRANT SELECT ON public.crm_lead_cards TO authenticated, anon, service_role;

NOTIFY pgrst, 'reload schema';
