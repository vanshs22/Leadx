-- =============================================================================
-- 015 — CRM missing objects (runtime-breaking gap repair)
--
-- Fixes three verified gaps that make the CRM portal return HTTP 500:
--   (a) view  crm_lead_cards      — queried by 5 endpoints, defined nowhere
--   (b) func  seed_default_stages — called via sb.rpc(), defined nowhere
--   (c) note  email_outreach.py writes to a table named `activities`
--
-- Idempotent / re-runnable. Does NOT drop or redefine any existing table;
-- only ADD COLUMN IF NOT EXISTS (the same additive "column repair" pattern
-- already used in SUPABASE_FULL_MIGRATION.sql around line 466).
-- =============================================================================


-- ---------------------------------------------------------------------------
-- 0. Column repair — columns the CRM code reads/writes that were never created
--
-- These are NOT cosmetic. Every one of them is referenced by
-- backend/crm/crm_api.py today:
--   lead_assignments.stage_id          crm_api.py:410,439,573 (change_stage, pipeline_board)
--   lead_assignments.priority          crm_api.py:262,271,688 (filter, sort, export)
--   lead_assignments.assigned_to       crm_api.py:260          (filter)
--   lead_assignments.next_action_at    crm_api.py:271          (sort)
--   lead_assignments.value_estimate    crm_api.py:55           (LeadUpdate PATCH)
--   lead_assignments.custom_fields     crm_api.py:57           (LeadUpdate PATCH)
--   lead_assignments.tags              crm_api.py:264          (contains filter)
--   lead_assignments.last_contacted_at crm_api.py:441,496      (write on activity)
--   lead_assignments.assigned_at       crm_api.py:787, leads_api.py:1030,1184
--   pipeline_stages.is_won/is_lost     crm_api.py:130,614-615
--   lead_activities.lead_id/actor_id   crm_api.py:96-97,486
--   lead_tasks.lead_id/description/assigned_to  crm_api.py:521-526
-- Without them the view below cannot be built and the PATCH/stage/task
-- endpoints fail on insert.
-- ---------------------------------------------------------------------------

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id          uuid,
  ADD COLUMN IF NOT EXISTS priority          text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to       text,
  ADD COLUMN IF NOT EXISTS next_action_at    timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate    numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields     jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags              text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at       timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes             text;

-- stage_id -> pipeline_stages(id), added separately so a re-run is safe
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'lead_assignments_stage_id_fkey'
  ) THEN
    ALTER TABLE lead_assignments
      ADD CONSTRAINT lead_assignments_stage_id_fkey
      FOREIGN KEY (stage_id) REFERENCES pipeline_stages(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Backfill assigned_at from created_at for rows that predate the column
UPDATE lead_assignments
SET assigned_at = created_at
WHERE assigned_at IS NULL AND created_at IS NOT NULL;

ALTER TABLE pipeline_stages
  ADD COLUMN IF NOT EXISTS is_won     boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_lost    boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE lead_activities
  ADD COLUMN IF NOT EXISTS lead_id  uuid,
  ADD COLUMN IF NOT EXISTS actor_id uuid;

ALTER TABLE lead_tasks
  ADD COLUMN IF NOT EXISTS lead_id     uuid,
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS assigned_to text;

-- Partial-DB safety: these exist in SUPABASE_FULL_MIGRATION.sql's CREATE TABLE
-- but NOT in the older sql/001 definitions, so a DB built from 001 lacks them
-- and the view below would fail to compile. Additive, no-op when present.
ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS google_place_id text,
  ADD COLUMN IF NOT EXISTS source_url      text,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier     text;

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_valid boolean;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS geo_tags            text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS delivery_status     text DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS delivery_error      text,
  ADD COLUMN IF NOT EXISTS exclusive_until     timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_status  text,
  ADD COLUMN IF NOT EXISTS first_touch_at      timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text;

-- social_enrichment is created by sql/009_social_enrich.sql and is a hard
-- dependency of the view. Guarded here so 015 can be applied to a DB where
-- 009 has not been run yet (IF NOT EXISTS — never alters an existing table).
CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,
  source_instagram        text,
  enriched_at             timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_assignments_stage
  ON lead_assignments (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_priority
  ON lead_assignments (tenant_id, priority);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_assigned_to
  ON lead_assignments (tenant_id, assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_assignments_next_action
  ON lead_assignments (tenant_id, next_action_at) WHERE next_action_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tags
  ON lead_assignments USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_lead_activities_lead
  ON lead_activities (lead_id) WHERE lead_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_tasks_lead
  ON lead_tasks (lead_id) WHERE lead_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- (a) crm_lead_cards — the denormalized lead card the CRM portal reads
--
-- Consumed by:
--   crm_api.py:138  dashboard      -> assignment_id, stage_slug, tier,
--                                     total_score, assignment_status
--   crm_api.py:251  list_leads     -> select *, filters on stage_slug, tier,
--                                     assignment_status, assigned_to, priority,
--                                     tags (contains), company_name (ilike);
--                                     orders by delivered_at | total_score |
--                                     company_name | next_action_at | priority
--   crm_api.py:291  lead_detail    -> select *, needs lead_id
--   crm_api.py:563  pipeline_board -> select *, needs stage_id, orders total_score
--   crm_api.py:637  reports_summary-> tier, stage_slug, total_score,
--                                     delivered_at, has_booking, email
--   crm_api.py:679  export_csv     -> company_name, phone_e164,
--                                     phone_normalized, email, website, city,
--                                     tier, total_score, stage_name,
--                                     booking_platform, priority, delivered_at
--   app_service.py:144 healthcheck -> assignment_id
--
-- Plain (non-materialized) view so the CRM is always fresh — the portal
-- writes to lead_assignments and immediately re-reads this view.
-- LEFT JOINs throughout: a lead with no enrichment / score / stage must still
-- appear on the board, otherwise freshly-assigned leads vanish from the UI.
-- ---------------------------------------------------------------------------

-- DROP first: CREATE OR REPLACE VIEW cannot change or reorder existing
-- columns, so a re-run after any edit to the column list below would fail
-- with "cannot change name of view column". Dropping a view is non-
-- destructive (no data lives in it) and it is recreated immediately.
DROP VIEW IF EXISTS crm_lead_cards;

CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  -- ── identity / tenancy ──────────────────────────────────────────────────
  la.tenant_id                                    AS tenant_id,
  la.id                                           AS assignment_id,
  la.lead_id                                      AS lead_id,

  -- ── company / display ───────────────────────────────────────────────────
  lg.name                                         AS company_name,
  lg.name                                         AS name,
  lg.category                                     AS category,
  lg.category                                     AS industry,
  la.vertical                                     AS vertical,
  la.offer_category                               AS offer_category,

  -- ── pipeline position ───────────────────────────────────────────────────
  la.stage_id                                     AS stage_id,
  COALESCE(ps.slug, la.stage_slug, 'new')         AS stage_slug,
  COALESCE(ps.name, initcap(COALESCE(la.stage_slug, 'New'))) AS stage_name,
  ps.color                                        AS stage_color,
  ps.position                                     AS stage_position,
  COALESCE(ps.is_won,  false)                     AS stage_is_won,
  COALESCE(ps.is_lost, false)                     AS stage_is_lost,

  -- ── assignment state (note the aliases the API filters on) ──────────────
  la.status                                       AS assignment_status,
  la.status                                       AS status,
  la.priority                                     AS priority,
  la.assigned_to                                  AS assigned_to,
  la.assigned_at                                  AS assigned_at,
  la.delivered_at                                 AS delivered_at,
  la.delivery_channel                             AS delivery_channel,
  la.delivery_status                              AS delivery_status,
  la.delivery_error                               AS delivery_error,
  la.next_action_at                               AS next_action_at,
  la.last_contacted_at                            AS last_contacted_at,
  la.value_estimate                               AS value_estimate,
  COALESCE(la.custom_fields, '{}'::jsonb)         AS custom_fields,
  COALESCE(la.tags, '{}'::text[])                 AS tags,
  la.notes                                        AS notes,
  la.icp_id                                       AS icp_id,
  la.geo_tags                                     AS geo_tags,
  la.exclusive_until                              AS exclusive_until,
  la.first_touch_status                           AS first_touch_status,
  la.first_touch_at                               AS first_touch_at,
  la.first_touch_channel                          AS first_touch_channel,
  la.created_at                                   AS created_at,

  -- ── scoring (score/tier prefer the scores table, fall back to assignment)
  COALESCE(s.total_score, 0)                      AS total_score,
  COALESCE(s.total_score, 0)                      AS score,
  s.deterministic_score                           AS deterministic_score,
  s.llm_score                                     AS llm_score,
  COALESCE(s.tier, la.tier, 'C')                  AS tier,
  s.reasoning                                     AS score_reasoning,
  s.scored_at                                     AS scored_at,
  COALESCE(s.intent_score, e.intent_score, 0)     AS intent_score,

  -- ── contact channels ────────────────────────────────────────────────────
  -- leads_global has NO plain `phone` column (only phone_normalized /
  -- phone_e164). The frontend reads lead.phone, so it is synthesized here.
  COALESCE(lg.phone_e164, lg.phone_normalized, e.phone_from_web) AS phone,
  lg.phone_normalized                             AS phone_normalized,
  lg.phone_e164                                   AS phone_e164,
  e.phone_from_web                                AS phone_from_web,
  COALESCE(e.email, lg.email)                     AS email,
  e.email_valid                                   AS email_valid,
  COALESCE(e.emails, '{}'::text[])                AS emails,
  lg.website                                      AS website,
  lg.website_domain                               AS website_domain,
  lg.website_domain                               AS domain,
  lg.address                                      AS address,
  lg.city                                         AS city,
  lg.state                                        AS state,

  -- ── quality / provenance signals ────────────────────────────────────────
  lg.business_status                              AS business_status,
  lg.google_rating                                AS google_rating,
  lg.review_count                                 AS review_count,
  lg.google_place_id                              AS google_place_id,
  lg.source                                       AS source,
  lg.source_url                                   AS source_url,
  -- entity_resolution.py joins multi-source hits into `source` as "a+b+c";
  -- split it back out so the UI's lead.sources_hit array works.
  string_to_array(COALESCE(lg.source, ''), '+')   AS sources_hit,
  lg.last_verified_at                             AS last_verified_at,
  lg.verify_tier                                  AS verify_tier,

  -- ── enrichment / sales-enablement ───────────────────────────────────────
  COALESCE(e.has_booking, false)                  AS has_booking,
  e.booking_platform                              AS booking_platform,
  COALESCE(e.services, '{}'::text[])              AS services,
  COALESCE(e.tech_stack, '{}'::text[])            AS tech_stack,
  COALESCE(e.social_links, '{}'::jsonb)           AS social_links,
  e.owner_name                                    AS owner_name,
  COALESCE(e.linkedin_url, se.linkedin_url)       AS linkedin_url,
  COALESCE(e.decision_makers, se.decision_makers, '[]'::jsonb) AS decision_makers,
  se.decision_maker_name                          AS decision_maker_name,
  se.decision_maker_title                         AS decision_maker_title,
  se.instagram_handle                             AS instagram_handle,
  se.instagram_followers                          AS instagram_followers,
  COALESCE(lg.pitch_line, e.pitch_line, s.pitch_line) AS pitch_line,
  lg.talking_points                               AS talking_points,
  e.markdown_summary                              AS markdown_summary,
  COALESCE(e.enrichment_ok, false)                AS enrichment_ok,
  e.enrichment_method                             AS enrichment_method,
  e.extracted_at                                  AS enriched_at
FROM lead_assignments la
LEFT JOIN leads_global      lg ON lg.id = la.lead_id
LEFT JOIN enrichment        e  ON e.lead_id = la.lead_id
LEFT JOIN scores            s  ON s.lead_id = la.lead_id
LEFT JOIN social_enrichment se ON se.lead_id = la.lead_id
LEFT JOIN pipeline_stages   ps ON ps.id = la.stage_id
                              AND ps.tenant_id = la.tenant_id;

COMMENT ON VIEW crm_lead_cards IS
  'Denormalized CRM lead card: lead_assignments + leads_global + enrichment + '
  'scores + social_enrichment + pipeline_stages. Read by /crm dashboard, '
  'leads list/detail, pipeline board, reports and CSV export. Plain view '
  '(not materialized) so portal writes are immediately visible.';

-- Tenant isolation: by default a view runs as its OWNER, which would BYPASS
-- the RLS policies on lead_assignments and leak other tenants' leads to any
-- authenticated caller. security_invoker makes the view evaluate the caller's
-- RLS instead (Postgres 15+ / current Supabase). Wrapped in a DO block so
-- this file still applies on an older server — but on a pre-15 server the
-- view must only ever be read by the service role.
DO $$
BEGIN
  EXECUTE 'ALTER VIEW crm_lead_cards SET (security_invoker = true)';
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'crm_lead_cards: security_invoker unsupported on this server — restrict this view to service_role';
END $$;

GRANT SELECT ON crm_lead_cards TO authenticated, service_role;


-- ---------------------------------------------------------------------------
-- (b) seed_default_stages(p_tenant_id uuid)
--
-- Called via sb.rpc("seed_default_stages", {"p_tenant_id": ...}) at
-- crm_api.py:605 (POST /crm/{tenant_id}/stages/seed and /setup).
-- Idempotent twice over: it returns early if the tenant already has any
-- stage, and the INSERT still carries ON CONFLICT DO NOTHING against the
-- existing UNIQUE (tenant_id, slug).
--
-- Slugs/colors/order match the Python fallback list in crm_api.py:608-616 so
-- the RPC path and the fallback path produce identical pipelines.
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.seed_default_stages(p_tenant_id uuid)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted int := 0;
BEGIN
  IF p_tenant_id IS NULL THEN
    RETURN 0;
  END IF;

  -- Already configured (possibly customized) — never overwrite operator setup.
  IF EXISTS (SELECT 1 FROM pipeline_stages WHERE tenant_id = p_tenant_id) THEN
    RETURN 0;
  END IF;

  INSERT INTO pipeline_stages (tenant_id, name, slug, position, color, is_won, is_lost)
  VALUES
    (p_tenant_id, 'New',         'new',         1, '#94a3b8', false, false),
    (p_tenant_id, 'Contacted',   'contacted',   2, '#3b82f6', false, false),
    (p_tenant_id, 'Qualified',   'qualified',   3, '#8b5cf6', false, false),
    (p_tenant_id, 'Proposal',    'proposal',    4, '#f59e0b', false, false),
    (p_tenant_id, 'Negotiation', 'negotiation', 5, '#f97316', false, false),
    (p_tenant_id, 'Won',         'won',         6, '#22c55e', true,  false),
    (p_tenant_id, 'Lost',        'lost',        7, '#ef4444', false, true)
  ON CONFLICT (tenant_id, slug) DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted;
END;
$$;

COMMENT ON FUNCTION public.seed_default_stages(uuid) IS
  'Seed the default 7-stage pipeline for a tenant. No-op if the tenant '
  'already has stages. Called by POST /crm/{tenant_id}/stages/seed.';

GRANT EXECUTE ON FUNCTION public.seed_default_stages(uuid) TO authenticated, service_role;


-- ---------------------------------------------------------------------------
-- (c) NOTE — the `activities` table referenced by email_outreach.py
--
-- backend/integrations/prod/email_outreach.py:206 inserts into a table named
-- `activities`. Historically no such table existed: the lead-engine timeline
-- table is `lead_activities` (tenant_id, assignment_id, activity_type, title,
-- body, meta, created_by, created_at). That insert was silently swallowed by
-- its surrounding try/except, so email sends were never timelined.
--
-- Deliberately NOT creating an `activities` shim here. Two things resolve it:
--   1. The Python fix (in progress) writes to `lead_activities` first.
--   2. sql/016_crm_full.sql introduces a genuinely NEW, richer `activities`
--      table for the company/contact/deal CRM — with DIFFERENT columns
--      (subject + occurred_at + direction, not title). email_outreach.py's
--      fallback branch already targets that shape.
-- Do not "fix" this by aliasing activities -> lead_activities; the two tables
-- have different grains (lead assignment vs. account/contact/deal) and
-- different column names.
-- ---------------------------------------------------------------------------
