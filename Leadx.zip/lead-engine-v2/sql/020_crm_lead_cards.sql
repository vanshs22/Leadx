
-- ========== Pre-view column safety (all refs used by crm_lead_cards) ==========
ALTER TABLE public.leads_global
  ADD COLUMN IF NOT EXISTS phone_normalized text,
  ADD COLUMN IF NOT EXISTS phone_e164 text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS website_domain text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS business_status text,
  ADD COLUMN IF NOT EXISTS google_rating numeric,
  ADD COLUMN IF NOT EXISTS review_count int,
  ADD COLUMN IF NOT EXISTS google_place_id text,
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS source_url text,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text,
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS pitch_line text;

ALTER TABLE public.enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS has_booking boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS booking_platform text,
  ADD COLUMN IF NOT EXISTS services text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS owner_name text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS email_valid boolean,
  ADD COLUMN IF NOT EXISTS enrichment_ok boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS enrichment_method text,
  ADD COLUMN IF NOT EXISTS extracted_at timestamptz,
  ADD COLUMN IF NOT EXISTS markdown_summary text;

ALTER TABLE public.scores
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_score numeric,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS reasoning text;

ALTER TABLE public.lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to text,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS offer_category text,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS geo_tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS icp_id uuid,
  ADD COLUMN IF NOT EXISTS delivery_channel text,
  ADD COLUMN IF NOT EXISTS delivery_error text;

ALTER TABLE public.pipeline_stages
  ADD COLUMN IF NOT EXISTS is_won boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_lost boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS color text,
  ADD COLUMN IF NOT EXISTS position int DEFAULT 0;

-- social_enrichment optional cols
DO $$ BEGIN
  IF to_regclass('public.social_enrichment') IS NOT NULL THEN
    ALTER TABLE public.social_enrichment
      ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
      ADD COLUMN IF NOT EXISTS decision_maker_name text,
      ADD COLUMN IF NOT EXISTS decision_maker_title text,
      ADD COLUMN IF NOT EXISTS instagram_handle text,
      ADD COLUMN IF NOT EXISTS instagram_followers int;
  END IF;
END $$;
-- ========== end pre-view safety ==========


DROP VIEW IF EXISTS crm_lead_cards CASCADE;
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  -- ── identity / tenancy ──────────────────────────────────────────────────
  la.tenant_id                                    AS tenant_id,
  la.id                                           AS assignment_id,
  la.lead_id                                      AS lead_id,

  -- ── company / display ───────────────────────────────────────────────────
  lg.name                                         AS company_name,
  lg.name                                         AS name,
  lg.category                                     AS category,
  lg.category                                     AS industry,
  la.vertical                                     AS vertical,
  la.offer_category                               AS offer_category,

  -- ── pipeline position ───────────────────────────────────────────────────
  la.stage_id                                     AS stage_id,
  COALESCE(ps.slug, la.stage_slug, 'new')         AS stage_slug,
  COALESCE(ps.name, initcap(COALESCE(la.stage_slug, 'New'))) AS stage_name,
  ps.color                                        AS stage_color,
  ps.position                                     AS stage_position,
  COALESCE(ps.is_won,  false)                     AS stage_is_won,
  COALESCE(ps.is_lost, false)                     AS stage_is_lost,

  -- ── assignment state (note the aliases the API filters on) ──────────────
  la.status                                       AS assignment_status,
  la.status                                       AS status,
  la.priority                                     AS priority,
  la.assigned_to                                  AS assigned_to,
  la.assigned_at                                  AS assigned_at,
  la.delivered_at                                 AS delivered_at,
  la.delivery_channel                             AS delivery_channel,
  la.delivery_status                              AS delivery_status,
  la.delivery_error                               AS delivery_error,
  la.next_action_at                               AS next_action_at,
  la.last_contacted_at                            AS last_contacted_at,
  la.value_estimate                               AS value_estimate,
  COALESCE(la.custom_fields, '{}'::jsonb)         AS custom_fields,
  COALESCE(la.tags, '{}'::text[])                 AS tags,
  la.notes                                        AS notes,
  la.icp_id                                       AS icp_id,
  la.geo_tags                                     AS geo_tags,
  la.exclusive_until                              AS exclusive_until,
  la.first_touch_status                           AS first_touch_status,
  la.first_touch_at                               AS first_touch_at,
  la.first_touch_channel                          AS first_touch_channel,
  la.created_at                                   AS created_at,

  -- ── scoring (score/tier prefer the scores table, fall back to assignment)
  COALESCE(s.total_score, 0)                      AS total_score,
  COALESCE(s.total_score, 0)                      AS score,
  s.deterministic_score                           AS deterministic_score,
  s.llm_score                                     AS llm_score,
  COALESCE(s.tier, la.tier, 'C')                  AS tier,
  s.reasoning                                     AS score_reasoning,
  s.scored_at                                     AS scored_at,
  COALESCE(s.intent_score, e.intent_score, 0)     AS intent_score,

  -- ── contact channels ────────────────────────────────────────────────────
  -- leads_global has NO plain `phone` column (only phone_normalized /
  -- phone_e164). The frontend reads lead.phone, so it is synthesized here.
  COALESCE(lg.phone_e164, lg.phone_normalized, e.phone_from_web) AS phone,
  lg.phone_normalized                             AS phone_normalized,
  lg.phone_e164                                   AS phone_e164,
  e.phone_from_web                                AS phone_from_web,
  COALESCE(e.email, lg.email)                     AS email,
  e.email_valid                                   AS email_valid,
  COALESCE(e.emails, '{}'::text[])                AS emails,
  lg.website                                      AS website,
  lg.website_domain                               AS website_domain,
  lg.website_domain                               AS domain,
  lg.address                                      AS address,
  lg.city                                         AS city,
  lg.state                                        AS state,

  -- ── quality / provenance signals ────────────────────────────────────────
  lg.business_status                              AS business_status,
  lg.google_rating                                AS google_rating,
  lg.review_count                                 AS review_count,
  lg.google_place_id                              AS google_place_id,
  lg.source                                       AS source,
  lg.source_url                                   AS source_url,
  -- entity_resolution.py joins multi-source hits into `source` as "a+b+c";

GRANT SELECT ON crm_lead_cards TO authenticated, service_role;
