-- Finish migration after stage_slug error
-- 1) Add missing CRM columns on lead_assignments
ALTER TABLE public.lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to text,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}'::text[],
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes text;

DROP VIEW IF EXISTS crm_lead_cards;

CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  -- ── identity / tenancy ──────────────────────────────────────────────────
  la.tenant_id                                    AS tenant_id,
  la.id                                           AS assignment_id,
  la.lead_id                                      AS lead_id,

  -- ── company / display ───────────────────────────────────────────────────
  lg.name                                         AS company_name,
  lg.name                                         AS name,
  lg.category                                     AS category,
  lg.category                                     AS industry,
  la.vertical                                     AS vertical,
  la.offer_category                               AS offer_category,

  -- ── pipeline position ───────────────────────────────────────────────────
  la.stage_id                                     AS stage_id,
  COALESCE(ps.slug, la.stage_slug, 'new')         AS stage_slug,
  COALESCE(ps.name, initcap(COALESCE(la.stage_slug, 'New'))) AS stage_name,
  ps.color                                        AS stage_color,
  ps.position                                     AS stage_position,
  COALESCE(ps.is_won,  false)                     AS stage_is_won,
  COALESCE(ps.is_lost, false)                     AS stage_is_lost,

  -- ── assignment state (note the aliases the API filters on) ──────────────
  la.status                                       AS assignment_status,
  la.status                                       AS status,
  la.priority                                     AS priority,
  la.assigned_to                                  AS assigned_to,
  la.assigned_at                                  AS assigned_at,
  la.delivered_at                                 AS delivered_at,
  la.delivery_channel                             AS delivery_channel,
  la.delivery_status                              AS delivery_status,
  la.delivery_error                               AS delivery_error,
  la.next_action_at                               AS next_action_at,
  la.last_contacted_at                            AS last_contacted_at,
  la.value_estimate                               AS value_estimate,
  COALESCE(la.custom_fields, '{}'::jsonb)         AS custom_fields,
  COALESCE(la.tags, '{}'::text[])                 AS tags,
  la.notes                                        AS notes,
  la.icp_id                                       AS icp_id,
  la.geo_tags                                     AS geo_tags,
  la.exclusive_until                              AS exclusive_until,
  la.first_touch_status                           AS first_touch_status,
  la.first_touch_at                               AS first_touch_at,
  la.first_touch_channel                          AS first_touch_channel,
  la.created_at                                   AS created_at,

  -- ── scoring (score/tier prefer the scores table, fall back to assignment)
  COALESCE(s.total_score, 0)                      AS total_score,
  COALESCE(s.total_score, 0)                      AS score,
  s.deterministic_score                           AS deterministic_score,
  s.llm_score                                     AS llm_score,
  COALESCE(s.tier, la.tier, 'C')                  AS tier,
  s.reasoning                                     AS score_reasoning,
  s.scored_at                                     AS scored_at,
  COALESCE(s.intent_score, e.intent_score, 0)     AS intent_score,

  -- ── contact channels ────────────────────────────────────────────────────
  -- leads_global has NO plain `phone` column (only phone_normalized /
  -- phone_e164). The frontend reads lead.phone, so it is synthesized here.
  COALESCE(lg.phone_e164, lg.phone_normalized, e.phone_from_web) AS phone,
  lg.phone_normalized                             AS phone_normalized,
  lg.phone_e164                                   AS phone_e164,
  e.phone_from_web                                AS phone_from_web,
  COALESCE(e.email, lg.email)                     AS email,
  e.email_valid                                   AS email_valid,
  COALESCE(e.emails, '{}'::text[])                AS emails,
  lg.website                                      AS website,
  lg.website_domain                               AS website_domain,
  lg.website_domain                               AS domain,
  lg.address                                      AS address,
  lg.city                                         AS city,
  lg.state                                        AS state,

  -- ── quality / provenance signals ────────────────────────────────────────
  lg.business_status                              AS business_status,
  lg.google_rating                                AS google_rating,
  lg.review_count                                 AS review_count,
  lg.google_place_id                              AS google_place_id,
  lg.source                                       AS source,
  lg.source_url                                   AS source_url,
  -- entity_resolution.py joins multi-source hits into `source` as "a+b+c";
  -- split it back out so the UI's lead.sources_hit array works.
  string_to_array(COALESCE(lg.source, ''), '+')   AS sources_hit,
  lg.last_verified_at                             AS last_verified_at,
  lg.verify_tier                                  AS verify_tier,

  -- ── enrichment / sales-enablement ───────────────────────────────────────
  COALESCE(e.has_booking, false)                  AS has_booking,
  e.booking_platform                              AS booking_platform,
  COALESCE(e.services, '{}'::text[])              AS services,
  COALESCE(e.tech_stack, '{}'::text[])            AS tech_stack,
  COALESCE(e.social_links, '{}'::jsonb)           AS social_links,
  e.owner_name                                    AS owner_name,
  COALESCE(e.linkedin_url, se.linkedin_url)       AS linkedin_url,
  COALESCE(e.decision_makers, se.decision_makers, '[]'::jsonb) AS decision_makers,
  se.decision_maker_name                          AS decision_maker_name,
  se.decision_maker_title                         AS decision_maker_title,
  se.instagram_handle                             AS instagram_handle,
  se.instagram_followers                          AS instagram_followers,
  COALESCE(lg.pitch_line, e.pitch_line, s.pitch_line) AS pitch_line,
  lg.talking_points                               AS talking_points,
  e.markdown_summary                              AS markdown_summary,
  COALESCE(e.enrichment_ok, false)                AS enrichment_ok,
  e.enrichment_method                             AS enrichment_method,
  e.extracted_at                                  AS enriched_at
FROM lead_assignments la
LEFT JOIN leads_global      lg ON lg.id = la.lead_id
LEFT JOIN enrichment        e  ON e.lead_id = la.lead_id
LEFT JOIN scores            s  ON s.lead_id = la.lead_id
LEFT JOIN social_enrichment se ON se.lead_id = la.lead_id
LEFT JOIN pipeline_stages   ps ON ps.id = la.stage_id
                              AND ps.tenant_id = la.tenant_id;

COMMENT ON VIEW crm_lead_cards IS
  'Denormalized CRM lead card: lead_assignments + leads_global + enrichment + '
  'scores + social_enrichment + pipeline_stages. Read by /crm dashboard, '
  'leads list/detail, pipeline board, reports and CSV export. Plain view '
  '(not materialized) so portal writes are immediately visible.';

-- Tenant isolation: by default a view runs as its OWNER, which would BYPASS
-- the RLS policies on lead_assignments and leak other tenants' leads to any
-- authenticated caller. security_invoker makes the view evaluate the caller's
-- RLS instead (Postgres 15+ / current Supabase). Wrapped in a DO block so
-- this file still applies on an older server — but on a pre-15 server the
-- view must only ever be read by the service role.
DO $$
BEGIN
  EXECUTE 'ALTER VIEW crm_lead_cards SET (security_invoker = true)';
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'crm_lead_cards: security_invoker unsupported on this server — restrict this view to service_role';
END $$;

GRANT SELECT ON crm_lead_cards TO authenticated, service_role;

