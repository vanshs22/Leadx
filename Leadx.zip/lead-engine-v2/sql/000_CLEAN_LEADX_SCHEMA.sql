-- LeadX clean-install reset (DATA LOSS)
-- Use only for a Supabase project dedicated to LeadX.
-- Removes all objects owned by LeadX from public without touching auth.users.
-- Recommended: run this once, verify success, then run 000_ALL_IN_ONE_migration.sql.

DO $$
DECLARE r record;
BEGIN
  -- Drop views/materialized views first.
  FOR r IN SELECT schemaname, viewname FROM pg_views WHERE schemaname = 'public' LOOP
    EXECUTE format('DROP VIEW IF EXISTS %I.%I CASCADE', r.schemaname, r.viewname);
  END LOOP;
  FOR r IN SELECT schemaname, matviewname FROM pg_matviews WHERE schemaname = 'public' LOOP
    EXECUTE format('DROP MATERIALIZED VIEW IF EXISTS %I.%I CASCADE', r.schemaname, r.matviewname);
  END LOOP;

  -- Drop all public tables, including worker/control-plane tables left by partial runs.
  FOR r IN SELECT schemaname, tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('DROP TABLE IF EXISTS %I.%I CASCADE', r.schemaname, r.tablename);
  END LOOP;

  -- Drop public sequences that are not owned by a remaining table.
  FOR r IN SELECT sequence_schema, sequence_name FROM information_schema.sequences WHERE sequence_schema = 'public' LOOP
    EXECUTE format('DROP SEQUENCE IF EXISTS %I.%I CASCADE', r.sequence_schema, r.sequence_name);
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';
