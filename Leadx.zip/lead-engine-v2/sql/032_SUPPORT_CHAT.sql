-- LeadX Support Copilot + Human Escalation
CREATE TABLE IF NOT EXISTS support_faq (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  question text NOT NULL,
  answer text NOT NULL,
  keywords text[] NOT NULL DEFAULT '{}',
  priority int NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_faq_active ON support_faq(active, priority DESC);

CREATE TABLE IF NOT EXISTS support_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id uuid,
  user_email text,
  subject text NOT NULL DEFAULT 'LeadX Support',
  status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','bot','escalated','human','resolved','closed')),
  needs_human boolean NOT NULL DEFAULT false,
  assigned_admin text,
  last_message_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_conv_tenant ON support_conversations(tenant_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_support_conv_escalated ON support_conversations(needs_human,updated_at DESC);

CREATE TABLE IF NOT EXISTS support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES support_conversations(id) ON DELETE CASCADE,
  sender_type text NOT NULL CHECK(sender_type IN ('user','bot','admin','system')),
  sender_id text,
  body text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_messages_conv ON support_messages(conversation_id,created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_support_faq_category_question ON support_faq(category,question);

INSERT INTO support_faq(category,question,answer,keywords,priority) VALUES
('Getting started','What is LeadX?','LeadX is a prospecting, opportunity-intelligence and CRM workspace. It can discover businesses, enrich records, identify opportunities, organize leads and help manage outreach and pipeline.','{leadx,overview,what,platform}',20),
('Discovery','How do I find leads?','Open Search / Find Opportunities and describe the industry, geography, problem, offer and optional signals you want. Client discovery requests are submitted for admin approval before discovery runs.','{find,search,discover,leads,prospecting}',20),
('Discovery','Can I search an entire state?','Yes. State-level discovery expands into cities, towns and municipalities and uses multiple discovery partitions. LeadX does not impose an artificial 100- or 500-lead ceiling on exhaustive discovery; provider coverage and rate limits still apply.','{state,texas,city,geography,exhaustive}',18),
('Approval','Why is my lead request waiting for approval?','Client discovery requests use a durable approval workflow. Your request can remain pending while an admin reviews the requested volume and available monthly capacity. You do not need to keep the page open.','{approval,pending,request,admin,waiting}',20),
('Quota','How does my monthly lead limit work?','Your plan has a monthly qualified-lead allowance. Approved delivery is constrained by that allowance, including concurrent reservations, so LeadX cannot intentionally over-allocate your plan.','{quota,limit,monthly,plan,allowance}',20),
('Leads','Why did I receive this lead?','LeadX uses fit, opportunity, intent, contactability and evidence to qualify opportunities. Lead details can include supporting website, review, technology, booking, social and business signals.','{score,quality,why,lead,evidence}',18),
('Enrichment','Can LeadX find emails and decision makers?','LeadX can enrich company and contact data from multiple sources and retain source provenance and verification state. Coverage depends on the business and available sources.','{email,contact,owner,decision,person,enrichment}',18),
('CRM','What can I do in the CRM?','The CRM supports companies, contacts, leads, deals, pipeline stages, tasks, activities, notes, assignments, saved views, notifications, sequences and reporting.','{crm,company,contact,deal,pipeline,task,note}',20),
('Sequences','How do email sequences work?','Sequences are durable multi-step workflows. A step advances only after the provider accepts the send. Replies, opt-outs and other configured stop conditions prevent inappropriate future touches.','{sequence,followup,email,steps}',20),
('Email','Why did an email stop?','A sequence can stop because a recipient replied, opted out, bounced, complained, reached a stop condition, or the sending policy/provider limits prevented a safe send.','{email,stopped,bounce,complaint,reply}',18),
('Opt out','How do I stop emails?','Reply with a clear opt-out request such as “please stop emailing me,” or use the unsubscribe mechanism provided in the message. LeadX records the suppression and stops future sequence contact.','{unsubscribe,optout,stop,remove,suppression}',25),
('Replies','How are replies handled?','Incoming SES email is parsed, quoted history is removed, and replies are classified into categories such as positive, negative, question and opt-out. Appropriate sequence and suppression actions then run.','{reply,incoming,email,classification,question}',20),
('Reports','Where can I see performance?','Reports and the dashboard summarize leads, pipeline, activities, conversion and usage. Admin reporting additionally includes provider, discovery, cost and operational health.','{reports,analytics,performance,stats}',16),
('Billing','Where can I see usage and billing?','Your workspace dashboard shows relevant usage and quota information. Billing and plan administration are controlled by the LeadX admin.','{billing,usage,invoice,plan,payment}',16),
('Team','Can I add team members?','Workspace team management can invite members and assign appropriate roles. Access is tenant-scoped and permissions should be granted according to each person’s responsibility.','{team,user,member,invite,role,permission}',16),
('Security','Is my workspace isolated?','LeadX verifies the authenticated user and tenant membership on CRM requests. Tenant-scoped records are accessed through the authenticated workspace context, while operator endpoints are separately protected.','{security,privacy,tenant,access,isolated}',18),
('Imports','Can I import my own leads?','The portal includes lead import workflows. Imported records are normalized and can enter the CRM/quality process according to the configured workflow.','{import,csv,upload,existing,leads}',15),
('Admin','Can I get a human to help?','Yes. Ask the support copilot. If it cannot confidently answer from the product knowledge base, it escalates the conversation to the LeadX admin team. An admin can then take over and reply in the same chat.','{human,support,admin,help,agent}',30),
('Autonomous','What is autonomous growth?','Autonomous Growth is an admin-only capability for running ICP-driven prospecting and outbound campaigns with controlled daily lead and email budgets. It is not exposed as an autonomous sender to normal client users.','{autonomous,automation,campaign,admin,icp}',14),
('AI','How does the AI decide what to say?','LeadX can use verified company/contact context, opportunity evidence and the configured offer to generate copy. AI output is a copy layer; durable CRM, suppression and sequence state remain governed by system rules.','{ai,personalization,copy,chatgpt,generation}',15),
('Data','Can the same lead be reused for other clients?','LeadX maintains a global lead universe with deduplication and tenant-specific assignment rules. Whether a lead can be delivered to another client depends on exclusivity, suppression, recency and other assignment policies.','{global,database,dedup,duplicate,shared,inventory}',18),
('Support','How do I contact support?','Use the LeadX Help button in the portal. You can ask the support copilot any product question. If it cannot answer confidently, it escalates to an admin who can continue the conversation with you.','{support,help,chat,contact}',25)
ON CONFLICT DO NOTHING;

NOTIFY pgrst, 'reload schema';
