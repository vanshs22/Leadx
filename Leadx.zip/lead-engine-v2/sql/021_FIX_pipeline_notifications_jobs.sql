-- ============================================================================
-- 021_FIX_pipeline_notifications_jobs.sql
--
-- Safe, idempotent migration. Run in Supabase SQL Editor (once or many times).
-- Fixes the errors from 2026-09-07 logs:
--   1. pipeline_runs_status_check rejects status='queued'
--   2. public.notifications table missing (PGRST205)
--   3. jobs / pipeline_run_leads / saved_views gaps on partial DBs
--
-- Does NOT drop data. Safe on production.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1) pipeline_runs — allow all statuses the app actually writes
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF to_regclass('public.pipeline_runs') IS NULL THEN
    CREATE TABLE public.pipeline_runs (
      id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      tenant_id       uuid,
      icp_id          uuid,
      status          text NOT NULL DEFAULT 'queued',
      discovered      int  NOT NULL DEFAULT 0,
      stored          int  NOT NULL DEFAULT 0,
      enriched        int  NOT NULL DEFAULT 0,
      gated_ok        int  NOT NULL DEFAULT 0,
      assigned        int  NOT NULL DEFAULT 0,
      delivered       int  NOT NULL DEFAULT 0,
      error_message   text,
      meta            jsonb NOT NULL DEFAULT '{}'::jsonb,
      started_at      timestamptz NOT NULL DEFAULT now(),
      finished_at     timestamptz,
      updated_at      timestamptz DEFAULT now()
    );
  END IF;
END $$;

ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS tenant_id     uuid;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS icp_id        uuid;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS status        text NOT NULL DEFAULT 'queued';
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS discovered    int  NOT NULL DEFAULT 0;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS stored        int  NOT NULL DEFAULT 0;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS enriched      int  NOT NULL DEFAULT 0;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS gated_ok      int  NOT NULL DEFAULT 0;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS assigned      int  NOT NULL DEFAULT 0;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS delivered     int  NOT NULL DEFAULT 0;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS error_message text;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS meta          jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS started_at    timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS finished_at   timestamptz;
ALTER TABLE public.pipeline_runs ADD COLUMN IF NOT EXISTS updated_at    timestamptz DEFAULT now();

-- Drop old narrow check, add the full set used by the app
ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS pipeline_runs_status_check;

ALTER TABLE public.pipeline_runs
  ADD CONSTRAINT pipeline_runs_status_check
  CHECK (status IN (
    'queued',
    'pending',
    'started',
    'running',
    'discovering',
    'enriching',
    'scoring',
    'assigning',
    'delivering',
    'completed',
    'partial',
    'failed',
    'cancelled'
  ));

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_tenant
  ON public.pipeline_runs (tenant_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_status
  ON public.pipeline_runs (status) WHERE status IN ('queued', 'running', 'pending');

-- ---------------------------------------------------------------------------
-- 2) notifications — in-app feed (admin + tenant bells)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.notifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope       text NOT NULL DEFAULT 'tenant'
                CHECK (scope IN ('tenant', 'admin')),
  tenant_id   uuid,
  kind        text NOT NULL,
  severity    text NOT NULL DEFAULT 'info'
                CHECK (severity IN ('info', 'warning', 'critical')),
  title       text NOT NULL,
  body        text NOT NULL DEFAULT '',
  link        text,
  meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notifications_scope_created
  ON public.notifications (scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_tenant_unread
  ON public.notifications (tenant_id, created_at DESC)
  WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_notifications_admin_unread
  ON public.notifications (scope, created_at DESC)
  WHERE scope = 'admin' AND read_at IS NULL;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "service_all_notifications" ON public.notifications;
CREATE POLICY "service_all_notifications"
  ON public.notifications
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ---------------------------------------------------------------------------
-- 3) jobs — Postgres work queue (required by app.worker)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.jobs (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid,
  kind         text        NOT NULL,
  payload      jsonb       NOT NULL DEFAULT '{}'::jsonb,
  status       text        NOT NULL DEFAULT 'queued',
  priority     int         NOT NULL DEFAULT 0,
  attempts     int         NOT NULL DEFAULT 0,
  max_attempts int         NOT NULL DEFAULT 3,
  run_after    timestamptz NOT NULL DEFAULT now(),
  created_by   text                 DEFAULT 'api',
  locked_by    text,
  locked_at    timestamptz,
  started_at   timestamptz,
  finished_at  timestamptz,
  result       jsonb,
  error        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS tenant_id    uuid;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS payload      jsonb       NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS status       text        NOT NULL DEFAULT 'queued';
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS priority     int         NOT NULL DEFAULT 0;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS attempts     int         NOT NULL DEFAULT 0;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS max_attempts int         NOT NULL DEFAULT 3;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS run_after    timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS created_by   text                 DEFAULT 'api';
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS locked_by    text;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS locked_at    timestamptz;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS started_at   timestamptz;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS finished_at  timestamptz;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS result       jsonb;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS error        text;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS created_at   timestamptz NOT NULL DEFAULT now();

-- Drop old jobs status check if present, then allow full set
ALTER TABLE public.jobs DROP CONSTRAINT IF EXISTS jobs_status_check;
DO $$
BEGIN
  ALTER TABLE public.jobs
    ADD CONSTRAINT jobs_status_check
    CHECK (status IN ('queued', 'running', 'done', 'failed', 'cancelled'));
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_jobs_claim
  ON public.jobs (priority DESC, created_at)
  WHERE status = 'queued';
CREATE INDEX IF NOT EXISTS idx_jobs_kind_status
  ON public.jobs (kind, status);
CREATE INDEX IF NOT EXISTS idx_jobs_stale
  ON public.jobs (locked_at)
  WHERE status = 'running';
CREATE INDEX IF NOT EXISTS idx_jobs_created
  ON public.jobs (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_tenant
  ON public.jobs (tenant_id, created_at DESC);

-- No RLS on jobs: worker uses service role only. Enabling RLS without
-- a policy would silently stop claim_next().

-- ---------------------------------------------------------------------------
-- 4) pipeline_run_leads — Run Board / lead rows per run
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.pipeline_run_leads (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id     uuid NOT NULL,
  lead_id    uuid NOT NULL,
  tenant_id  uuid,
  stage      text NOT NULL DEFAULT 'discovered',
  tier       text,
  included   boolean NOT NULL DEFAULT true,
  score      int,
  source     text,
  name       text,
  phone      text,
  website    text,
  city       text,
  position   int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (run_id, lead_id)
);

-- Add FKs only if parent tables exist (avoids errors on partial DBs)
DO $$
BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pipeline_run_leads_run_id_fkey'
     ) THEN
    ALTER TABLE public.pipeline_run_leads
      ADD CONSTRAINT pipeline_run_leads_run_id_fkey
      FOREIGN KEY (run_id) REFERENCES public.pipeline_runs(id) ON DELETE CASCADE;
  END IF;

  IF to_regclass('public.leads_global') IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM pg_constraint
       WHERE conname = 'pipeline_run_leads_lead_id_fkey'
     ) THEN
    ALTER TABLE public.pipeline_run_leads
      ADD CONSTRAINT pipeline_run_leads_lead_id_fkey
      FOREIGN KEY (lead_id) REFERENCES public.leads_global(id) ON DELETE CASCADE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_prl_run    ON public.pipeline_run_leads (run_id);
CREATE INDEX IF NOT EXISTS idx_prl_tenant ON public.pipeline_run_leads (tenant_id);
CREATE INDEX IF NOT EXISTS idx_prl_stage  ON public.pipeline_run_leads (run_id, stage);

ALTER TABLE public.pipeline_run_leads ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_all_pipeline_run_leads" ON public.pipeline_run_leads;
CREATE POLICY "service_all_pipeline_run_leads"
  ON public.pipeline_run_leads
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ---------------------------------------------------------------------------
-- 5) saved_views — CRM filter presets
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.saved_views (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id  uuid NOT NULL,
  entity     text NOT NULL DEFAULT 'leads',
  name       text NOT NULL,
  filters    jsonb NOT NULL DEFAULT '{}'::jsonb,
  user_id    text,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_saved_views_tenant_entity
  ON public.saved_views (tenant_id, entity);

ALTER TABLE public.saved_views ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_all_saved_views" ON public.saved_views;
CREATE POLICY "service_all_saved_views"
  ON public.saved_views
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ---------------------------------------------------------------------------
-- 6) Soft heal: any stuck pipeline_runs with invalid status → failed
-- ---------------------------------------------------------------------------
UPDATE public.pipeline_runs
SET status = 'failed',
    error_message = COALESCE(error_message, 'healed: previous status not in allowed set'),
    finished_at = COALESCE(finished_at, now())
WHERE status IS NULL
   OR status NOT IN (
     'queued','pending','started','running','discovering','enriching',
     'scoring','assigning','delivering','completed','partial','failed','cancelled'
   );

-- ---------------------------------------------------------------------------
-- 7) Reload PostgREST schema cache so new tables appear immediately
-- ---------------------------------------------------------------------------
NOTIFY pgrst, 'reload schema';

-- Done.
-- After running:
--   1. Restart API (uvicorn) if already running
--   2. Ensure worker is up:
--        cd lead-engine-v2 && source .venv/bin/activate
--        export PYTHONPATH=.
--        WORKER_INTERNAL_CRON=true python -m app.worker --concurrency 3
--   3. Start a new pipeline run from /admin/pipeline
