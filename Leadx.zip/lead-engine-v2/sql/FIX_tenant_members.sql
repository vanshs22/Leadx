-- FIX_tenant_members.sql
-- Run once in Supabase SQL Editor if client portal login create fails on full_name

ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS role text DEFAULT 'member';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS invited_at timestamptz;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS joined_at timestamptz;

-- Unique for upsert by email (safe if already exists)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'tenant_members_tenant_id_email_key'
  ) THEN
    BEGIN
      ALTER TABLE public.tenant_members ADD CONSTRAINT tenant_members_tenant_id_email_key UNIQUE (tenant_id, email);
    EXCEPTION WHEN others THEN
      NULL; -- ignore if duplicate emails exist
    END;
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';
