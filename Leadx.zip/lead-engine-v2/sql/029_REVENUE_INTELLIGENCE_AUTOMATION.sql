-- LeadX 2026: Revenue intelligence + autonomous operator automation foundation.
-- Idempotent. Apply after 028_DISCOVERY_REQUESTS_GLOBAL_COVERAGE.sql.

-- 1) Evidence ledger: every important claim can point back to a source.
CREATE TABLE IF NOT EXISTS lead_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  value jsonb NOT NULL DEFAULT '{}',
  source text NOT NULL,
  source_url text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  confidence numeric(5,4) CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
  method text,
  is_current boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- LeadX schema compatibility repair: older installations may already have these
-- tables without the historical observed_at column. CREATE TABLE IF NOT EXISTS
-- does not reconcile an existing table, so repair the column before indexes.
DO $$
BEGIN
  ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_lead_evidence_lead_field ON lead_evidence(lead_id, field_name, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_evidence_tenant ON lead_evidence(tenant_id, created_at DESC);

-- 2) Historical observations/freshness instead of destructive overwrites.
CREATE TABLE IF NOT EXISTS lead_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  old_value jsonb,
  new_value jsonb,
  source text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_observations_lead ON lead_observations(lead_id, observed_at DESC);

-- 3) Versioned scoring decisions for explainability and rollback.
CREATE TABLE IF NOT EXISTS lead_score_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  model_version text NOT NULL,
  fit_score int,
  opportunity_score int,
  intent_score int,
  contactability_score int,
  total_score int,
  tier text,
  reasoning jsonb NOT NULL DEFAULT '{}',
  evidence_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_score_versions_lead ON lead_score_versions(lead_id, created_at DESC);

-- 4) Lead refresh queue/state.
CREATE TABLE IF NOT EXISTS lead_refresh_state (
  lead_id uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  last_refreshed_at timestamptz,
  next_refresh_at timestamptz,
  refresh_priority int NOT NULL DEFAULT 50,
  refresh_reason text,
  stale_fields text[] NOT NULL DEFAULT '{}',
  last_result jsonb NOT NULL DEFAULT '{}',
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_refresh_due ON lead_refresh_state(next_refresh_at, refresh_priority DESC);

-- 5) Saved natural-language / structured prospecting searches.
CREATE TABLE IF NOT EXISTS saved_searches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  query text,
  filters jsonb NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  continuous boolean NOT NULL DEFAULT false,
  alert_on_new boolean NOT NULL DEFAULT true,
  last_run_at timestamptz,
  last_match_count int NOT NULL DEFAULT 0,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_saved_searches_tenant ON saved_searches(tenant_id, active, created_at DESC);

-- 6) Generic workflow rules/actions for CRM and prospecting automation.
CREATE TABLE IF NOT EXISTS workflow_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  trigger_type text NOT NULL,
  conditions jsonb NOT NULL DEFAULT '{}',
  actions jsonb NOT NULL DEFAULT '[]',
  active boolean NOT NULL DEFAULT true,
  priority int NOT NULL DEFAULT 100,
  last_run_at timestamptz,
  run_count int NOT NULL DEFAULT 0,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_workflow_rules_tenant ON workflow_rules(tenant_id, active, priority);

CREATE TABLE IF NOT EXISTS workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL REFERENCES workflow_rules(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  entity_type text,
  entity_id uuid,
  status text NOT NULL DEFAULT 'queued',
  result jsonb NOT NULL DEFAULT '{}',
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_workflow_runs_workflow ON workflow_runs(workflow_id, created_at DESC);

-- 7) Provider telemetry / unit economics.
CREATE TABLE IF NOT EXISTS provider_usage_daily (
  day date NOT NULL,
  provider text NOT NULL,
  operation text NOT NULL,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  calls int NOT NULL DEFAULT 0,
  successes int NOT NULL DEFAULT 0,
  failures int NOT NULL DEFAULT 0,
  estimated_cost numeric(14,6) NOT NULL DEFAULT 0,
  latency_ms_total bigint NOT NULL DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}',
  PRIMARY KEY(day, provider, operation, tenant_id)
);
CREATE INDEX IF NOT EXISTS idx_provider_usage_day ON provider_usage_daily(day DESC, provider, operation);

-- 8) Campaigns: admin-owned autonomous prospecting + outreach. Client workflows
-- continue using their existing discovery request flow and sequences.
CREATE TABLE IF NOT EXISTS autonomous_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  icp_id uuid,
  sequence_id uuid REFERENCES email_sequences(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','active','paused','completed','error')),
  locations jsonb NOT NULL DEFAULT '[]',
  queries jsonb NOT NULL DEFAULT '[]',
  offer text,
  goal text,
  daily_new_lead_limit int NOT NULL DEFAULT 25 CHECK (daily_new_lead_limit >= 1),
  daily_email_limit int NOT NULL DEFAULT 25 CHECK (daily_email_limit >= 1),
  max_active_enrollments int NOT NULL DEFAULT 5000 CHECK (max_active_enrollments >= 1),
  send_window_start time NOT NULL DEFAULT '09:00',
  send_window_end time NOT NULL DEFAULT '17:00',
  timezone text NOT NULL DEFAULT 'America/New_York',
  generate_ai_copy boolean NOT NULL DEFAULT true,
  auto_followup boolean NOT NULL DEFAULT true,
  stop_on_reply boolean NOT NULL DEFAULT true,
  stop_on_optout boolean NOT NULL DEFAULT true,
  require_verified_email boolean NOT NULL DEFAULT true,
  score_threshold int NOT NULL DEFAULT 70,
  schedule_hours int NOT NULL DEFAULT 24 CHECK (schedule_hours >= 1),
  next_discovery_at timestamptz,
  last_discovery_at timestamptz,
  last_discovery_result jsonb NOT NULL DEFAULT '{}',
  created_by text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_tenant ON autonomous_campaigns(tenant_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_due ON autonomous_campaigns(next_discovery_at) WHERE status = 'active';

-- 9) Daily campaign budget ledger. Reservations make concurrent workers safe.
CREATE TABLE IF NOT EXISTS autonomous_campaign_daily (
  campaign_id uuid NOT NULL REFERENCES autonomous_campaigns(id) ON DELETE CASCADE,
  day date NOT NULL,
  leads_discovered int NOT NULL DEFAULT 0,
  emails_sent int NOT NULL DEFAULT 0,
  emails_reserved int NOT NULL DEFAULT 0,
  replies int NOT NULL DEFAULT 0,
  positive_replies int NOT NULL DEFAULT 0,
  meetings int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(campaign_id, day)
);

-- 10) Tie a sequence enrollment/send to an autonomous campaign when applicable.
ALTER TABLE email_sequence_enrollments ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES autonomous_campaigns(id) ON DELETE SET NULL;
ALTER TABLE email_sequence_enrollments ADD COLUMN IF NOT EXISTS ai_copy_enabled boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_sequence_enrollments_campaign ON email_sequence_enrollments(campaign_id, status, next_send_at);
ALTER TABLE email_sequence_sends ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES autonomous_campaigns(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_sequence_sends_campaign ON email_sequence_sends(campaign_id, created_at DESC);
ALTER TABLE email_sends ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES autonomous_campaigns(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_email_sends_campaign ON email_sends(campaign_id, created_at DESC);

-- 11) Per-lead AI copy cache; never regenerate the same step unnecessarily.
CREATE TABLE IF NOT EXISTS campaign_email_copies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES autonomous_campaigns(id) ON DELETE CASCADE,
  enrollment_id uuid REFERENCES email_sequence_enrollments(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL,
  step_number int NOT NULL,
  subject text NOT NULL,
  body_html text NOT NULL,
  body_text text,
  provider text,
  evidence jsonb NOT NULL DEFAULT '{}',
  approved boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(campaign_id, assignment_id, step_number)
);
CREATE INDEX IF NOT EXISTS idx_campaign_email_copies_assignment ON campaign_email_copies(assignment_id, step_number);

-- 12) Campaign outcome/QA feedback.
CREATE TABLE IF NOT EXISTS lead_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  outcome text NOT NULL,
  reason text,
  value numeric(14,2),
  metadata jsonb NOT NULL DEFAULT '{}',
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_feedback_tenant ON lead_feedback(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_feedback_lead ON lead_feedback(lead_id, created_at DESC);

-- 13) Atomic campaign email budget reservation. Returns {ok, reserved}.
CREATE OR REPLACE FUNCTION reserve_campaign_email_slot(p_campaign_id uuid, p_requested int DEFAULT 1)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  c int;
  used int;
  reserved int;
  available int;
  take_n int;
BEGIN
  SELECT daily_email_limit INTO c FROM autonomous_campaigns WHERE id = p_campaign_id AND status = 'active' FOR UPDATE;
  IF c IS NULL THEN RETURN jsonb_build_object('ok', false, 'reserved', 0, 'reason', 'campaign_inactive'); END IF;
  INSERT INTO autonomous_campaign_daily(campaign_id, day) VALUES(p_campaign_id, current_date)
    ON CONFLICT(campaign_id, day) DO NOTHING;
  SELECT emails_sent, emails_reserved INTO used, reserved
    FROM autonomous_campaign_daily WHERE campaign_id = p_campaign_id AND day = current_date FOR UPDATE;
  available := GREATEST(c - used - reserved, 0);
  take_n := LEAST(GREATEST(p_requested, 0), available);
  IF take_n <= 0 THEN RETURN jsonb_build_object('ok', false, 'reserved', 0, 'reason', 'daily_email_limit_reached'); END IF;
  UPDATE autonomous_campaign_daily SET emails_reserved = emails_reserved + take_n, updated_at = now()
    WHERE campaign_id = p_campaign_id AND day = current_date;
  RETURN jsonb_build_object('ok', true, 'reserved', take_n);
END;
$$;

CREATE OR REPLACE FUNCTION consume_campaign_email_slot(p_campaign_id uuid, p_count int DEFAULT 1)
RETURNS jsonb LANGUAGE plpgsql AS $$
BEGIN
  UPDATE autonomous_campaign_daily
     SET emails_reserved = GREATEST(emails_reserved - GREATEST(p_count,0),0),
         emails_sent = emails_sent + GREATEST(p_count,0), updated_at = now()
   WHERE campaign_id = p_campaign_id AND day = current_date;
  RETURN jsonb_build_object('ok', true);
END;
$$;

CREATE OR REPLACE FUNCTION release_campaign_email_slot(p_campaign_id uuid, p_count int DEFAULT 1)
RETURNS jsonb LANGUAGE plpgsql AS $$
BEGIN
  UPDATE autonomous_campaign_daily
     SET emails_reserved = GREATEST(emails_reserved - GREATEST(p_count,0),0), updated_at = now()
   WHERE campaign_id = p_campaign_id AND day = current_date;
  RETURN jsonb_build_object('ok', true);
END;
$$;

NOTIFY pgrst, 'reload schema';
