-- LeadX CRM realtime hardening.
-- Run after the CRM tables exist. Realtime is cache invalidation; API/RLS remain authoritative.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'companies','contacts','deal_stages','deals','activities','tasks','notes','pipeline_stages',
    'lead_assignments','lead_activities','lead_tasks','notifications','discovery_requests'
  ] LOOP
    BEGIN
      EXECUTE format('ALTER TABLE public.%I REPLICA IDENTITY FULL', t);
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL;
    WHEN undefined_table THEN NULL;
    WHEN undefined_object THEN NULL;
    END;
  END LOOP;
END $$;
