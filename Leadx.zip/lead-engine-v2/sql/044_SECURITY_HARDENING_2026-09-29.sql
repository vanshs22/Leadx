-- LeadX production security hardening. Apply after the current schema/RLS migrations.
REVOKE ALL ON public.crm_lead_cards FROM anon, authenticated;
GRANT SELECT ON public.crm_lead_cards TO service_role;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'tenants','icp_profiles','lead_assignments','leads_global','enrichment',
    'scores','usage_log','pipeline_runs','pipeline_stages','lead_activities',
    'lead_tasks','lead_tags','tenant_members','lead_segments','crm_audit_log',
    'enrichment_failures','api_key_pool'
  ] LOOP
    BEGIN
      EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t);
    EXCEPTION WHEN undefined_table THEN
      NULL;
    END;
  END LOOP;
END $$;
