-- LeadX production-scale control plane
CREATE TABLE IF NOT EXISTS worker_heartbeats (
  worker_id text PRIMARY KEY,
  kinds text[] NOT NULL DEFAULT '{}',
  capacity integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'healthy',
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  observed_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS active_jobs integer NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS idx_worker_heartbeats_seen ON worker_heartbeats(last_seen_at DESC);

CREATE TABLE IF NOT EXISTS operation_idempotency (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key text NOT NULL,
  operation text NOT NULL,
  tenant_id uuid,
  status text NOT NULL DEFAULT 'completed',
  response jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(idempotency_key, operation)
);
CREATE INDEX IF NOT EXISTS idx_operation_idempotency_tenant ON operation_idempotency(tenant_id,created_at DESC);

CREATE TABLE IF NOT EXISTS delivery_outbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  event_type text NOT NULL,
  aggregate_type text,
  aggregate_id text,
  payload jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','delivered','failed')),
  attempts integer NOT NULL DEFAULT 0,
  available_at timestamptz NOT NULL DEFAULT now(),
  delivered_at timestamptz,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_delivery_outbox_ready ON delivery_outbox(status,available_at);
