"""
Lead Engine — managed service entrypoint.
  uvicorn app.app_service:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging
import os
from pathlib import Path as _Path

# Load lead-engine-v2/.env before anything else reads os.environ
try:
    from dotenv import load_dotenv
    _env_file = _Path(__file__).resolve().parents[1] / ".env"
    if _env_file.is_file():
        load_dotenv(_env_file, override=True)
    else:
        load_dotenv(override=True)
except ImportError:
    pass

from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
import uuid
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from app.middleware.rate_limit import check_rate_limit, client_ip

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("lead_engine.service")

app = FastAPI(
    title="Automiqo Lead Service",
    version="3.0.2",
    description="Managed lead generation — operator API + client CRM",
)

# Development: allow all origins (Codespaces / local). Production: set CORS_ORIGINS.
_env = os.getenv("ENVIRONMENT", "development").lower()
_cors = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
if _env not in ("production", "prod", "staging") or not _cors:
    _cors = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors,
    allow_credentials=(_cors != ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(GZipMiddleware, minimum_size=1000)


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex
    request.state.request_id = request_id
    try:
        # Protect public HTTP surfaces against accidental polling loops and
        # abusive bursts. Expensive pipeline/key endpoints have tighter,
        # endpoint-specific limits below; this is only the general API guard.
        if request.url.path.startswith(("/crm/", "/leads/v2")) and request.method != "OPTIONS":
            auth = request.headers.get("authorization", "")
            import hashlib
            identity = client_ip(request) + ":" + hashlib.sha256(auth.encode()).hexdigest()[:16]
            check_rate_limit(identity, "api", int(os.getenv("RATE_LIMIT_API_PER_MINUTE", "180")), 60)
        response = await call_next(request)
    except HTTPException as exc:
        response = JSONResponse(
            status_code=exc.status_code,
            content={"ok": False, "error": str(exc.detail), "request_id": request_id},
            headers=dict(exc.headers or {}),
        )
    except Exception:
        logger.exception("Unhandled request error request_id=%s method=%s path=%s", request_id, request.method, request.url.path)
        response = JSONResponse(
            status_code=500,
            content={"ok": False, "error": "Internal server error", "request_id": request_id},
        )
    response.headers["x-request-id"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if os.getenv("ENVIRONMENT", "development").lower() in ("production", "prod", "staging"):
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    request_id = getattr(request.state, "request_id", uuid.uuid4().hex)
    return JSONResponse(
        status_code=400,
        content={
            "ok": False,
            "error": "Invalid request",
            "details": exc.errors(),
            "request_id": request_id,
        },
        headers={"x-request-id": request_id},
    )


@app.exception_handler(StarletteHTTPException)
async def http_error_handler(request: Request, exc: StarletteHTTPException):
    request_id = getattr(request.state, "request_id", uuid.uuid4().hex)
    detail = exc.detail if isinstance(exc.detail, (str, int, float, bool, list, dict)) else str(exc.detail)
    return JSONResponse(
        status_code=exc.status_code,
        content={"ok": False, "error": detail, "request_id": request_id},
        headers={"x-request-id": request_id},
    )


@app.on_event("startup")
async def startup():
    # Supabase's Python client is synchronous. FastAPI routes that use it are
    # moved through anyio's threadpool; increase the default limiter so one
    # slow DB call cannot serialize dozens of unrelated client requests.
    try:
        import anyio.to_thread
        anyio.to_thread.current_default_thread_limiter().total_tokens = int(os.getenv("SYNC_DB_THREAD_TOKENS", "64"))
    except Exception as e:
        logger.warning("Could not tune sync DB threadpool: %s", e)

    env = os.getenv("ENVIRONMENT", "dev").lower()
    missing = [k for k in ("SUPABASE_URL",) if not os.getenv(k)]
    if not (
        os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_KEY")
    ):
        missing.append("SUPABASE_SERVICE_KEY")
    if missing:
        logger.warning("Missing env (DB calls will fail): %s", missing)
    if env in ("production", "prod"):
        sk = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
        if len(sk) < 16:
            logger.error("LEAD_ENGINE_SERVICE_KEY required (≥16 chars) in production")
        if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
            logger.error("LEAD_ENGINE_DEV_AUTH_BYPASS must be false in production")
        if not os.getenv("DELIVERY_CONFIG_KEY"):
            logger.warning("DELIVERY_CONFIG_KEY unset — delivery secrets may be plaintext")
    logger.info("Lead service started env=%s version=3.0.2", env)


@app.get("/health")
async def health():
    checks = {
        "api": True,
        "db": None,
        "service_key": bool(os.getenv("LEAD_ENGINE_SERVICE_KEY")),
    }
    try:
        from app.memory.supabase_client import get_supabase
        sb = get_supabase()
        sb.table("tenants").select("id").limit(1).execute()
        checks["db"] = True
    except Exception as e:
        checks["db"] = False
        checks["db_error"] = str(e)[:200]
    try:
        from app.integrations.prod.scale_control import scale_health
        checks["scale"] = scale_health()
    except Exception as e:
        checks["scale"] = {"ok": False, "error": str(e)[:160]}
    route_paths = {getattr(r, "path", "") for r in app.routes}
    checks["crm_routes"] = {
        "me": "/crm/me" in route_paths,
        "dashboard": "/crm/{tenant_id}/dashboard" in route_paths,
        "leads": "/crm/{tenant_id}/leads" in route_paths,
        "pipeline": "/crm/{tenant_id}/pipeline" in route_paths,
        "reports": "/crm/{tenant_id}/reports/summary" in route_paths,
        "deal_reports": "/crm/{tenant_id}/reports/deals" in route_paths,
        "support_ask": "/support/ask" in route_paths,
    }
    checks["crm_route_contract_ok"] = all(checks["crm_routes"].values())
    ok = checks["api"] and checks["db"] is True and checks["crm_route_contract_ok"]
    return {
        "ok": ok,
        "service": "lead-engine",
        "mode": "managed_service",
        "version": "3.0.2",
        "checks": checks,
    }


@app.get("/")
async def root():
    return {
        "service": "Automiqo Lead Service",
        "docs": "/docs",
        "health": "/health",
        "operator_api": "/leads/v2",
        "crm_api": "/crm",
    }




# Runtime auth bootstrap endpoint. Keep this directly on the application as a
# hard guarantee for the client portal: even if an optional CRM router fails to
# import during startup, the workspace bootstrap endpoint remains registered.
# The same verified tenant resolver is used, so this does NOT weaken auth.
try:
    from app.middleware.auth import require_tenant, TenantContext

    @app.get("/crm/me", tags=["crm-portal-bootstrap"])
    async def runtime_crm_me(ctx: TenantContext = Depends(require_tenant)):
        return {"tenant_id": ctx.tenant_id, "role": ctx.role, "email": ctx.email}
except Exception as e:
    logger.exception("Failed to mount runtime /crm/me bootstrap: %s", e)



try:
    from app.api.prod.leads_api import router as leads_router
    app.include_router(leads_router)
    logger.info("Mounted /leads/v2")
except Exception as e:
    logger.exception("Failed to mount leads_api: %s", e)

try:
    # Single CRM router, JWT-protected via require_tenant (crm_api.py
    # docstring has the detail). crm_public_router carries /team/accept,
    # which needs a lighter auth check since accepting an invite happens
    # before someone has tenant membership yet.
    from app.crm.crm_api import router as crm_router, crm_public_router
    app.include_router(crm_router)
    app.include_router(crm_public_router)
    logger.info("Mounted /crm (require_tenant) + /crm public (team/accept)")
except Exception as e:
    logger.exception("Failed to mount CRM router: %s", e)

try:
    # Was written but never mounted — every companies/contacts/deals/
    # activities/notes route was a 404. Mounted after crm_api so that
    # router keeps precedence on any shared prefix.
    from app.crm.crm_entities_api import router as crm_entities_router
    app.include_router(crm_entities_router)
    logger.info("Mounted /crm entities (companies/contacts/deals)")
except Exception as e:
    logger.exception("Failed to mount CRM entities router: %s", e)

try:
    from app.crm.crm_extras_api import router as crm_extras_router, public_router as crm_extras_public
    app.include_router(crm_extras_router)
    app.include_router(crm_extras_public)
    logger.info("Mounted /crm extras (notifications/views/import/reports)")
except Exception as e:
    logger.exception("Failed to mount CRM extras router: %s", e)

try:
    from app.api.prod.ops_api import router as ops_router
    app.include_router(ops_router)
    logger.info("Mounted /leads/v2 ops (jobs/notifications/prospecting)")
except Exception as e:
    logger.exception("Failed to mount ops_api: %s", e)

try:
    from app.api.prod.intelligence_api import router as intelligence_router
    app.include_router(intelligence_router)
    logger.info("Mounted /crm intelligence (AI briefs/revenue funnel/learning)")
except Exception as e:
    logger.exception("Failed to mount intelligence_api: %s", e)

try:
    from app.api.prod.support_api import client_router as support_client_router, admin_router as support_admin_router
    app.include_router(support_client_router)
    app.include_router(support_admin_router)
    logger.info("Mounted /support + /support/admin")
except Exception as e:
    logger.exception("Failed to mount support_api: %s", e)

# Runtime safety nets for individual lead operations. These are deliberately
# installed only when the primary CRM router did not mount the corresponding
# route. This prevents an import/deployment mismatch from turning every lead
# click or pipeline drag into a misleading 404.
try:
    from uuid import UUID as _LeadUUID
    from fastapi import HTTPException as _LeadHTTPException
    from app.middleware.auth import require_tenant as _lead_require_tenant, TenantContext as _LeadTenantContext

    _crm_route_paths = {getattr(r, "path", "") for r in app.routes}

    if "/crm/{tenant_id}/leads/{assignment_id}" not in _crm_route_paths:
        @app.get("/crm/{tenant_id}/leads/{assignment_id}", tags=["crm-portal-runtime"])
        async def runtime_crm_lead_detail(
            tenant_id: _LeadUUID, assignment_id: _LeadUUID,
            ctx: _LeadTenantContext = Depends(_lead_require_tenant),
        ):
            if str(tenant_id) != ctx.tenant_id:
                raise _LeadHTTPException(403, "Tenant mismatch")
            from app.memory.supabase_client import get_supabase
            import asyncio as _lead_asyncio
            tid, aid = str(tenant_id), str(assignment_id)

            def _read():
                sb = get_supabase()
                rows = sb.table("lead_assignments").select("*").eq("tenant_id", tid).eq("id", aid).limit(1).execute().data or []
                if not rows:
                    raise _LeadHTTPException(404, "Lead not found")
                a = rows[0]
                lead_id = a.get("lead_id")
                g = {}
                if lead_id:
                    g_rows = sb.table("leads_global").select("*").eq("id", str(lead_id)).limit(1).execute().data or []
                    g = g_rows[0] if g_rows else {}
                e = {}
                if lead_id:
                    try:
                        e_rows = sb.table("enrichment").select("*").eq("lead_id", str(lead_id)).order("extracted_at", desc=True).limit(1).execute().data or []
                        e = e_rows[0] if e_rows else {}
                    except Exception:
                        pass
                activities = sb.table("lead_activities").select("*").eq("tenant_id", tid).eq("assignment_id", aid).order("created_at", desc=True).limit(100).execute().data or []
                tasks = sb.table("lead_tasks").select("*").eq("tenant_id", tid).eq("assignment_id", aid).order("created_at", desc=True).limit(100).execute().data or []
                lead = {**g, **e, **a, "assignment_id": aid, "lead_id": lead_id, "tenant_id": tid,
                        "company_name": g.get("name") or g.get("company_name") or "Lead",
                        "name": g.get("name") or g.get("company_name") or "Lead",
                        "total_score": a.get("score") or 0, "tier": a.get("tier") or "C",
                        "stage_id": a.get("stage_id"), "stage_slug": a.get("stage_slug") or "new",
                        "assignment_status": a.get("status") or "active"}
                return {"lead": lead, "activities": activities, "tasks": tasks, "why_this_lead": None}
            return await _lead_asyncio.to_thread(_read)

        logger.warning("CRM lead detail route missing; installed protected runtime fallback")

    _crm_route_paths = {getattr(r, "path", "") for r in app.routes}
    if "/crm/{tenant_id}/leads/{assignment_id}/stage" not in _crm_route_paths:
        @app.post("/crm/{tenant_id}/leads/{assignment_id}/stage", tags=["crm-portal-runtime"])
        async def runtime_crm_change_stage(
            tenant_id: _LeadUUID, assignment_id: _LeadUUID,
            body: dict,
            ctx: _LeadTenantContext = Depends(_lead_require_tenant),
        ):
            if str(tenant_id) != ctx.tenant_id:
                raise _LeadHTTPException(403, "Tenant mismatch")
            from app.memory.supabase_client import get_supabase
            import asyncio as _stage_asyncio
            tid, aid, stage_id = str(tenant_id), str(assignment_id), str(body.get("stage_id") or "")
            if not stage_id:
                raise _LeadHTTPException(400, "stage_id is required")
            def _write():
                sb = get_supabase()
                current = sb.table("lead_assignments").select("lead_id,stage_id,status").eq("tenant_id", tid).eq("id", aid).limit(1).execute().data or []
                if not current:
                    raise _LeadHTTPException(404, "Lead not found")
                stages = sb.table("pipeline_stages").select("id,tenant_id,name,slug,color,position,is_won,is_lost").eq("tenant_id", tid).eq("id", stage_id).limit(1).execute().data or []
                if not stages:
                    raise _LeadHTTPException(404, "Pipeline stage not found")
                stage = stages[0]
                status = "won" if stage.get("is_won") else ("rejected" if stage.get("is_lost") else "new")
                if stage.get("slug") in ("contacted", "qualified", "proposal", "negotiation"):
                    status = "contacted"
                updated = sb.table("lead_assignments").update({"stage_id": stage_id, "stage_slug": stage.get("slug"), "status": status}).eq("tenant_id", tid).eq("id", aid).execute()
                if not getattr(updated, "data", None):
                    raise _LeadHTTPException(409, "Lead stage update was not persisted")
                return {"ok": True, "stage": stage, "assignment_id": aid}
            return await _stage_asyncio.to_thread(_write)
        logger.warning("CRM stage route missing; installed protected runtime fallback")
except Exception as e:
    logger.exception("Failed to install lead/stage runtime fallbacks: %s", e)

# Runtime safety net for the client home screen. The normal CRM router owns
# this path when mounted. If an optional CRM import ever fails, do not expose a
# 404 to the portal — keep the protected dashboard contract available.
try:
    from uuid import UUID as _UUID
    import asyncio as _asyncio
    from datetime import datetime as _datetime, timezone as _timezone, timedelta as _timedelta

    _dashboard_path_exists = any(getattr(r, "path", "") == "/crm/{tenant_id}/dashboard" for r in app.routes)
    if not _dashboard_path_exists:
        @app.get("/crm/{tenant_id}/dashboard", tags=["crm-portal-runtime"])
        async def runtime_crm_dashboard(tenant_id: _UUID, ctx: TenantContext = Depends(require_tenant)):
            if str(tenant_id) != ctx.tenant_id:
                from fastapi import HTTPException
                raise HTTPException(403, "Tenant mismatch")
            tid = str(tenant_id)
            since = (_datetime.now(_timezone.utc) - _timedelta(days=6)).date()
            period = _datetime.now(_timezone.utc).replace(day=1).date().isoformat()
            def _read():
                from app.memory.supabase_client import get_supabase
                sb = get_supabase()
                def q(table, columns="*", limit=None):
                    try:
                        x = sb.table(table).select(columns).eq("tenant_id", tid)
                        if limit: x = x.limit(limit)
                        return x.execute().data or []
                    except Exception:
                        return []
                stages = q("pipeline_stages", "id,name,slug,color,position,is_won,is_lost")
                cards = q("crm_lead_cards", "assignment_id,stage_slug,tier,total_score,assignment_status")
                if not cards:
                    assignments = q("lead_assignments", "id,stage_id,stage_slug,tier,score,status,created_at,delivered_at", 1000)
                    cards = [{"assignment_id": a.get("id"), "stage_id": a.get("stage_id"), "stage_slug": a.get("stage_slug") or "new", "tier": a.get("tier") or "C", "total_score": a.get("score") or 0, "assignment_status": a.get("status") or "active"} for a in assignments]
                if not stages:
                    defaults = [("New","new",0,"#94a3b8",False,False),("Contacted","contacted",1,"#3b82f6",False,False),("Qualified","qualified",2,"#8b5cf6",False,False),("Proposal","proposal",3,"#f59e0b",False,False),("Negotiation","negotiation",4,"#f97316",False,False),("Won","won",5,"#22c55e",True,False),("Lost","lost",6,"#ef4444",False,True)]
                    stages = [{"id":f"runtime-{slug}","name":name,"slug":slug,"color":color,"position":pos,"is_won":won,"is_lost":lost} for name,slug,pos,color,won,lost in defaults]
                tasks = q("lead_tasks", "id,title,due_at,priority,assignment_id", 10)
                activities = q("lead_activities", "id,activity_type,title,body,created_at,assignment_id", 15)
                usage = q("usage_log", "*", 1)
                tenant = q("tenants", "name,plan,leads_per_month_limit,delivery_channel", 1)
                try:
                    delivered = sb.table("lead_assignments").select("delivered_at").eq("tenant_id", tid).gte("delivered_at", since.isoformat()).execute().data or []
                except Exception:
                    delivered = []
                by_stage, by_tier = {}, {"A":0,"B":0,"C":0}
                for c in cards:
                    slug=c.get("stage_slug") or "new"; by_stage[slug]=by_stage.get(slug,0)+1
                    tier=c.get("tier") or "C"; by_tier[tier]=by_tier.get(tier,0)+1
                won, lost = by_stage.get("won",0), by_stage.get("lost",0)
                closed=won+lost
                trend=[]
                for i in range(7):
                    day=(since+_timedelta(days=i)).isoformat()
                    trend.append({"date":day,"count":sum(1 for r in delivered if str(r.get("delivered_at") or "")[:10]==day)})
                return {"tenant":tenant[0] if tenant else None,"kpis":{"total_leads":len(cards),"tier_a":by_tier.get("A",0),"tier_b":by_tier.get("B",0),"tier_c":by_tier.get("C",0),"new":by_stage.get("new",0),"in_pipeline":len(cards)-won-lost,"won":won,"lost":lost,"win_rate_pct":round(100*won/closed,1) if closed else 0},"funnel":[{"stage":x.get("name"),"slug":x.get("slug"),"color":x.get("color"),"count":by_stage.get(x.get("slug") or "",0)} for x in stages],"usage":usage[0] if usage else None,"quota_limit":tenant[0].get("leads_per_month_limit") if tenant else None,"tasks_due":tasks,"recent_activity":activities,"trend":trend}
            return await _asyncio.to_thread(_read)

        logger.warning("CRM router did not mount dashboard; installed protected runtime fallback /crm/{tenant_id}/dashboard")
except Exception as e:
    logger.exception("Failed to install runtime CRM dashboard fallback: %s", e)

# Runtime safety nets for the two primary client work surfaces. If an optional
# CRM module fails to import during a deployment, keep the client contract
# alive instead of returning a misleading 404 from FastAPI.
try:
    from uuid import UUID as _UUID2
    import asyncio as _asyncio2
    import time as _time2
    from fastapi import HTTPException as _HTTPException2
    from app.middleware.auth import require_tenant as _require_tenant2, TenantContext as _TenantContext2

    _crm_paths = {getattr(r, "path", "") for r in app.routes}

    if "/crm/{tenant_id}/leads" not in _crm_paths:
        @app.get("/crm/{tenant_id}/leads", tags=["crm-portal-runtime"])
        async def runtime_crm_leads(tenant_id: _UUID2, limit: int = 50, offset: int = 0, stage: str | None = None, tier: str | None = None, search: str | None = None, ctx: _TenantContext2 = Depends(_require_tenant2)):
            if str(tenant_id) != ctx.tenant_id:
                raise _HTTPException2(403, "Tenant mismatch")
            tid = str(tenant_id)
            limit = max(1, min(int(limit), 200)); offset = max(0, int(offset))
            def _read():
                from app.memory.supabase_client import get_supabase
                sb = get_supabase()
                try:
                    q = sb.table("crm_lead_cards").select("*", count="exact").eq("tenant_id", tid)
                    if stage: q = q.eq("stage_slug", stage)
                    if tier: q = q.eq("tier", tier.upper())
                    if search: q = q.ilike("company_name", f"%{search}%")
                    r = q.order("delivered_at", desc=True).range(offset, offset + limit - 1).execute()
                    return {"total": r.count if getattr(r, "count", None) is not None else len(r.data or []), "limit": limit, "offset": offset, "leads": r.data or []}
                except Exception:
                    q = sb.table("lead_assignments").select("id,tenant_id,lead_id,status,tier,score,created_at,delivered_at,stage_id,stage_slug,icp_id").eq("tenant_id", tid)
                    if tier: q = q.eq("tier", tier.upper())
                    rows = q.order("created_at", desc=True).range(offset, offset + limit - 1).execute().data or []
                    ids = [x.get("lead_id") for x in rows if x.get("lead_id")]
                    by_id = {}
                    if ids:
                        try: by_id = {x["id"]: x for x in (sb.table("leads_global").select("id,name,phone,phone_normalized,email,website,city,state,address,category").in_("id", ids).execute().data or [])}
                        except Exception: pass
                    leads = [{"assignment_id": x.get("id"), "tenant_id": tid, "lead_id": x.get("lead_id"), "company_name": (by_id.get(x.get("lead_id")) or {}).get("name") or "Unknown", "phone": (by_id.get(x.get("lead_id")) or {}).get("phone") or (by_id.get(x.get("lead_id")) or {}).get("phone_normalized"), "email": (by_id.get(x.get("lead_id")) or {}).get("email"), "website": (by_id.get(x.get("lead_id")) or {}).get("website"), "city": (by_id.get(x.get("lead_id")) or {}).get("city"), "state": (by_id.get(x.get("lead_id")) or {}).get("state"), "tier": x.get("tier"), "total_score": x.get("score"), "stage_slug": x.get("stage_slug") or "new", "assignment_status": x.get("status") or "active", "delivered_at": x.get("delivered_at") or x.get("created_at")} for x in rows]
                    return {"total": len(leads), "limit": limit, "offset": offset, "leads": leads}
            return await _asyncio2.to_thread(_read)

    if "/crm/{tenant_id}/pipeline" not in _crm_paths:
        @app.get("/crm/{tenant_id}/pipeline", tags=["crm-portal-runtime"])
        async def runtime_crm_pipeline(tenant_id: _UUID2, ctx: _TenantContext2 = Depends(_require_tenant2)):
            if str(tenant_id) != ctx.tenant_id:
                raise _HTTPException2(403, "Tenant mismatch")
            tid = str(tenant_id)
            def _read():
                from app.memory.supabase_client import get_supabase
                sb = get_supabase()
                stages = sb.table("pipeline_stages").select("id,tenant_id,name,slug,color,position,is_won,is_lost").eq("tenant_id", tid).order("position").execute().data or []
                try:
                    cards = sb.table("crm_lead_cards").select("*").eq("tenant_id", tid).order("total_score", desc=True).execute().data or []
                except Exception:
                    cards = []
                if not cards:
                    try:
                        assignments = (sb.table("lead_assignments")
                            .select("id,lead_id,stage_id,stage_slug,tier,score,status,created_at,delivered_at")
                            .eq("tenant_id", tid).order("created_at", desc=True).limit(1000).execute().data or [])
                        ids = [a.get("lead_id") for a in assignments if a.get("lead_id")]
                        by_lead = {}
                        if ids:
                            try:
                                gl = (sb.table("leads_global").select("id,name,phone_normalized,phone_e164,email,city,state,website")
                                      .in_("id", ids).execute().data or [])
                                by_lead = {str(x.get("id")): x for x in gl}
                            except Exception:
                                pass
                        cards = [{
                            "assignment_id": a.get("id"), "lead_id": a.get("lead_id"),
                            "stage_id": a.get("stage_id"), "stage_slug": a.get("stage_slug") or "new",
                            "tier": a.get("tier") or "C", "total_score": a.get("score") or 0,
                            "assignment_status": a.get("status") or "active",
                            "company_name": (by_lead.get(str(a.get("lead_id"))) or {}).get("name") or "Lead",
                            "phone_normalized": (by_lead.get(str(a.get("lead_id"))) or {}).get("phone_normalized"),
                            "phone_e164": (by_lead.get(str(a.get("lead_id"))) or {}).get("phone_e164"),
                            "email": (by_lead.get(str(a.get("lead_id"))) or {}).get("email"),
                            "city": (by_lead.get(str(a.get("lead_id"))) or {}).get("city"),
                            "state": (by_lead.get(str(a.get("lead_id"))) or {}).get("state"),
                            "website": (by_lead.get(str(a.get("lead_id"))) or {}).get("website"),
                        } for a in assignments]
                    except Exception:
                        cards = []
                if not stages:
                    defaults = [("New","new",0,"#94a3b8",False,False),("Contacted","contacted",1,"#3b82f6",False,False),("Qualified","qualified",2,"#8b5cf6",False,False),("Proposal","proposal",3,"#f59e0b",False,False),("Negotiation","negotiation",4,"#f97316",False,False),("Won","won",5,"#22c55e",True,False),("Lost","lost",6,"#ef4444",False,True)]
                    stages = [{"id":f"runtime-{slug}","tenant_id":tid,"name":name,"slug":slug,"color":color,"position":pos,"is_won":won,"is_lost":lost} for name,slug,pos,color,won,lost in defaults]
                by_stage = {x.get("id"): [] for x in stages if x.get("id")}; by_slug = {x.get("slug"): x.get("id") for x in stages if x.get("slug")}; unstaged = []
                for card in cards:
                    target = card.get("stage_id") if card.get("stage_id") in by_stage else by_slug.get(card.get("stage_slug") or "new")
                    if target in by_stage: by_stage[target].append(card)
                    else: unstaged.append(card)
                return {"stages": [{**x, "leads": by_stage.get(x.get("id"), [])} for x in stages], "unstaged": unstaged, "needs_seed": False}
            return await _asyncio2.to_thread(_read)

    # Reports are part of the client CRM route contract. These fallbacks keep
    # a stale/partially mounted Codespaces backend from turning Reports into
    # a misleading 404. They are tenant-scoped and intentionally defensive.
    if "/crm/{tenant_id}/reports/summary" not in _crm_paths:
        @app.get("/crm/{tenant_id}/reports/summary", tags=["crm-portal-runtime"])
        async def runtime_crm_reports_summary(tenant_id: _UUID2, ctx: _TenantContext2 = Depends(_require_tenant2)):
            if str(tenant_id) != ctx.tenant_id:
                raise _HTTPException2(403, "Tenant mismatch")
            tid = str(tenant_id)
            def _read():
                from app.memory.supabase_client import get_supabase
                sb = get_supabase()
                cards = []
                try:
                    cards = (sb.table("crm_lead_cards")
                             .select("assignment_id,lead_id,tier,stage_slug,total_score,email")
                             .eq("tenant_id", tid).limit(1000).execute().data or [])
                except Exception:
                    cards = []
                if not cards:
                    try:
                        asg = (sb.table("lead_assignments")
                               .select("id,lead_id,tier,score,stage_slug")
                               .eq("tenant_id", tid).limit(1000).execute().data or [])
                        ids = [str(a.get("lead_id")) for a in asg if a.get("lead_id")]
                        by_lead = {}
                        if ids:
                            try:
                                gl = (sb.table("leads_global").select("id,email")
                                      .in_("id", ids).execute().data or [])
                                by_lead = {str(x.get("id")): x for x in gl}
                            except Exception:
                                pass
                        cards = [{
                            "assignment_id": a.get("id"), "lead_id": a.get("lead_id"),
                            "tier": a.get("tier"), "stage_slug": a.get("stage_slug") or "new",
                            "total_score": a.get("score"),
                            "email": (by_lead.get(str(a.get("lead_id"))) or {}).get("email"),
                        } for a in asg]
                    except Exception:
                        cards = []
                total = len(cards)
                with_email = sum(1 for c in cards if c.get("email"))
                by_tier = {"A": 0, "B": 0, "C": 0}
                by_stage = {}
                for c in cards:
                    tier = str(c.get("tier") or "C").upper()
                    if tier not in by_tier:
                        tier = "C"
                    by_tier[tier] += 1
                    stage = c.get("stage_slug") or "new"
                    by_stage[stage] = by_stage.get(stage, 0) + 1
                scores = [float(c.get("total_score") or 0) for c in cards]
                return {
                    "total": total,
                    "with_email": with_email,
                    "with_email_pct": round(100 * with_email / total, 1) if total else 0,
                    "with_booking": 0,
                    "by_tier": by_tier,
                    "by_stage": by_stage,
                    "avg_score": round(sum(scores) / len(scores), 1) if scores else 0,
                }
            return await _asyncio2.to_thread(_read)

    if "/crm/{tenant_id}/reports/deals" not in _crm_paths:
        @app.get("/crm/{tenant_id}/reports/deals", tags=["crm-portal-runtime"])
        async def runtime_crm_deal_reports(tenant_id: _UUID2, days: int = 365, ctx: _TenantContext2 = Depends(_require_tenant2)):
            if str(tenant_id) != ctx.tenant_id:
                raise _HTTPException2(403, "Tenant mismatch")
            days = max(7, min(int(days), 1095))
            tid = str(tenant_id)
            try:
                from app.integrations.prod.crm_reports import deal_report as _deal_report
                return await _asyncio2.to_thread(_deal_report, tid, days)
            except Exception as report_error:
                logger.warning("deal report fallback tenant=%s: %s", tid, report_error)
                return {
                    "ok": True, "window_days": days, "revenue_won": 0, "deals_won": 0,
                    "avg_deal_value": 0, "win_rate": 0, "avg_cycle_days": None,
                    "open_deals": 0, "open_value": 0, "forecast_weighted": 0,
                    "revenue_from_delivered_leads": 0, "attribution_pct": 0,
                    "by_stage": [], "monthly_revenue": [], "currency": "USD",
                    "degraded": True,
                }

    _final_paths = {getattr(r, "path", "") for r in app.routes}
    logger.info(
        "CRM route contract: leads=%s pipeline=%s dashboard=%s reports=%s deal_reports=%s",
        "/crm/{tenant_id}/leads" in _final_paths,
        "/crm/{tenant_id}/pipeline" in _final_paths,
        "/crm/{tenant_id}/dashboard" in _final_paths,
        "/crm/{tenant_id}/reports/summary" in _final_paths,
        "/crm/{tenant_id}/reports/deals" in _final_paths,
    )

except Exception as e:
    logger.exception("Failed to mount platform_api: %s", e)

try:
    # Import for the side effect of populating jobs.HANDLERS, so an API
    # process can validate a job kind before enqueuing it.
    # NOTE: must be `from ... import`, NOT `import app.integrations...` —
    # a dotted import would rebind the name `app` here to the package
    # module, clobbering the FastAPI instance above.
    from app.integrations.prod import job_handlers  # noqa: F401
except Exception as e:
    logger.exception("Failed to register job handlers: %s", e)
