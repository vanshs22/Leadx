"""
Lead Engine — managed service entrypoint.
  uvicorn app.app_service:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging
import os
from pathlib import Path as _Path

# Load lead-engine-v2/.env before anything else reads os.environ
try:
    from dotenv import load_dotenv
    _env_file = _Path(__file__).resolve().parents[1] / ".env"
    if _env_file.is_file():
        load_dotenv(_env_file, override=True)
    else:
        load_dotenv(override=True)
except ImportError:
    pass

from fastapi import FastAPI, Request, Depends
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
import uuid
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("lead_engine.service")

app = FastAPI(
    title="Automiqo Lead Service",
    version="3.0.0",
    description="Managed lead generation — operator API + client CRM",
)

# Development: allow all origins (Codespaces / local). Production: set CORS_ORIGINS.
_env = os.getenv("ENVIRONMENT", "development").lower()
_cors = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
if _env not in ("production", "prod", "staging") or not _cors:
    _cors = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors,
    allow_credentials=(_cors != ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(GZipMiddleware, minimum_size=1000)


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex
    request.state.request_id = request_id
    try:
        response = await call_next(request)
    except Exception:
        logger.exception("Unhandled request error request_id=%s method=%s path=%s", request_id, request.method, request.url.path)
        response = JSONResponse(
            status_code=500,
            content={"ok": False, "error": "Internal server error", "request_id": request_id},
        )
    response.headers["x-request-id"] = request_id
    return response


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    request_id = getattr(request.state, "request_id", uuid.uuid4().hex)
    return JSONResponse(
        status_code=400,
        content={
            "ok": False,
            "error": "Invalid request",
            "details": exc.errors(),
            "request_id": request_id,
        },
        headers={"x-request-id": request_id},
    )


@app.exception_handler(StarletteHTTPException)
async def http_error_handler(request: Request, exc: StarletteHTTPException):
    request_id = getattr(request.state, "request_id", uuid.uuid4().hex)
    detail = exc.detail if isinstance(exc.detail, (str, int, float, bool, list, dict)) else str(exc.detail)
    return JSONResponse(
        status_code=exc.status_code,
        content={"ok": False, "error": detail, "request_id": request_id},
        headers={"x-request-id": request_id},
    )


@app.on_event("startup")
async def startup():
    # Supabase's Python client is synchronous. FastAPI routes that use it are
    # moved through anyio's threadpool; increase the default limiter so one
    # slow DB call cannot serialize dozens of unrelated client requests.
    try:
        import anyio.to_thread
        anyio.to_thread.current_default_thread_limiter().total_tokens = int(os.getenv("SYNC_DB_THREAD_TOKENS", "64"))
    except Exception as e:
        logger.warning("Could not tune sync DB threadpool: %s", e)

    env = os.getenv("ENVIRONMENT", "dev").lower()
    missing = [k for k in ("SUPABASE_URL",) if not os.getenv(k)]
    if not (
        os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_KEY")
    ):
        missing.append("SUPABASE_SERVICE_KEY")
    if missing:
        logger.warning("Missing env (DB calls will fail): %s", missing)
    if env in ("production", "prod"):
        sk = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
        if len(sk) < 16:
            logger.error("LEAD_ENGINE_SERVICE_KEY required (≥16 chars) in production")
        if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
            logger.error("LEAD_ENGINE_DEV_AUTH_BYPASS must be false in production")
        if not os.getenv("DELIVERY_CONFIG_KEY"):
            logger.warning("DELIVERY_CONFIG_KEY unset — delivery secrets may be plaintext")
    logger.info("Lead service started env=%s version=3.0.0", env)


@app.get("/health")
async def health():
    checks = {
        "api": True,
        "db": None,
        "service_key": bool(os.getenv("LEAD_ENGINE_SERVICE_KEY")),
    }
    try:
        from app.memory.supabase_client import get_supabase
        sb = get_supabase()
        sb.table("tenants").select("id").limit(1).execute()
        checks["db"] = True
    except Exception as e:
        checks["db"] = False
        checks["db_error"] = str(e)[:200]
    try:
        from app.integrations.prod.scale_control import scale_health
        checks["scale"] = scale_health()
    except Exception as e:
        checks["scale"] = {"ok": False, "error": str(e)[:160]}
    ok = checks["api"] and checks["db"] is True
    return {
        "ok": ok,
        "service": "lead-engine",
        "mode": "managed_service",
        "version": "3.0.0",
        "checks": checks,
    }


@app.get("/")
async def root():
    return {
        "service": "Automiqo Lead Service",
        "docs": "/docs",
        "health": "/health",
        "operator_api": "/leads/v2",
        "crm_api": "/crm",
    }




# Runtime auth bootstrap endpoint. Keep this directly on the application as a
# hard guarantee for the client portal: even if an optional CRM router fails to
# import during startup, the workspace bootstrap endpoint remains registered.
# The same verified tenant resolver is used, so this does NOT weaken auth.
try:
    from app.middleware.auth import require_tenant, TenantContext

    @app.get("/crm/me", tags=["crm-portal-bootstrap"])
    async def runtime_crm_me(ctx: TenantContext = Depends(require_tenant)):
        return {"tenant_id": ctx.tenant_id, "role": ctx.role, "email": ctx.email}
except Exception as e:
    logger.exception("Failed to mount runtime /crm/me bootstrap: %s", e)



try:
    from app.api.prod.leads_api import router as leads_router
    app.include_router(leads_router)
    logger.info("Mounted /leads/v2")
except Exception as e:
    logger.exception("Failed to mount leads_api: %s", e)

try:
    # Single CRM router, JWT-protected via require_tenant (crm_api.py
    # docstring has the detail). crm_public_router carries /team/accept,
    # which needs a lighter auth check since accepting an invite happens
    # before someone has tenant membership yet.
    from app.crm.crm_api import router as crm_router, crm_public_router
    app.include_router(crm_router)
    app.include_router(crm_public_router)
    logger.info("Mounted /crm (require_tenant) + /crm public (team/accept)")
except Exception as e:
    logger.exception("Failed to mount CRM router: %s", e)

try:
    # Was written but never mounted — every companies/contacts/deals/
    # activities/notes route was a 404. Mounted after crm_api so that
    # router keeps precedence on any shared prefix.
    from app.crm.crm_entities_api import router as crm_entities_router
    app.include_router(crm_entities_router)
    logger.info("Mounted /crm entities (companies/contacts/deals)")
except Exception as e:
    logger.exception("Failed to mount CRM entities router: %s", e)

try:
    from app.crm.crm_extras_api import router as crm_extras_router, public_router as crm_extras_public
    app.include_router(crm_extras_router)
    app.include_router(crm_extras_public)
    logger.info("Mounted /crm extras (notifications/views/import/reports)")
except Exception as e:
    logger.exception("Failed to mount CRM extras router: %s", e)

try:
    from app.api.prod.ops_api import router as ops_router
    app.include_router(ops_router)
    logger.info("Mounted /leads/v2 ops (jobs/notifications/prospecting)")
except Exception as e:
    logger.exception("Failed to mount ops_api: %s", e)

try:
    from app.api.prod.intelligence_api import router as intelligence_router
    app.include_router(intelligence_router)
    logger.info("Mounted /crm intelligence (AI briefs/revenue funnel/learning)")
except Exception as e:
    logger.exception("Failed to mount intelligence_api: %s", e)

try:
    from app.api.prod.support_api import client_router as support_client_router, admin_router as support_admin_router
    app.include_router(support_client_router)
    app.include_router(support_admin_router)
    logger.info("Mounted /support + /support/admin")
except Exception as e:
    logger.exception("Failed to mount support_api: %s", e)

# Runtime safety net for the client home screen. The normal CRM router owns
# this path when mounted. If an optional CRM import ever fails, do not expose a
# 404 to the portal — keep the protected dashboard contract available.
try:
    from uuid import UUID as _UUID
    import asyncio as _asyncio
    from datetime import datetime as _datetime, timezone as _timezone, timedelta as _timedelta

    _dashboard_path_exists = any(getattr(r, "path", "") == "/crm/{tenant_id}/dashboard" for r in app.routes)
    if not _dashboard_path_exists:
        @app.get("/crm/{tenant_id}/dashboard", tags=["crm-portal-runtime"])
        async def runtime_crm_dashboard(tenant_id: _UUID, ctx: TenantContext = Depends(require_tenant)):
            if str(tenant_id) != ctx.tenant_id:
                from fastapi import HTTPException
                raise HTTPException(403, "Tenant mismatch")
            tid = str(tenant_id)
            since = (_datetime.now(_timezone.utc) - _timedelta(days=6)).date()
            period = _datetime.now(_timezone.utc).replace(day=1).date().isoformat()
            def _read():
                from app.memory.supabase_client import get_supabase
                sb = get_supabase()
                def q(table, columns="*", limit=None):
                    try:
                        x = sb.table(table).select(columns).eq("tenant_id", tid)
                        if limit: x = x.limit(limit)
                        return x.execute().data or []
                    except Exception:
                        return []
                stages = q("pipeline_stages", "id,name,slug,color,position,is_won,is_lost")
                cards = q("crm_lead_cards", "assignment_id,stage_slug,tier,total_score,assignment_status")
                tasks = q("lead_tasks", "id,title,due_at,priority,assignment_id", 10)
                activities = q("lead_activities", "id,activity_type,title,body,created_at,assignment_id", 15)
                usage = q("usage_log", "*", 1)
                tenant = q("tenants", "name,plan,leads_per_month_limit,delivery_channel", 1)
                try:
                    delivered = sb.table("lead_assignments").select("delivered_at").eq("tenant_id", tid).gte("delivered_at", since.isoformat()).execute().data or []
                except Exception:
                    delivered = []
                by_stage, by_tier = {}, {"A":0,"B":0,"C":0}
                for c in cards:
                    slug=c.get("stage_slug") or "new"; by_stage[slug]=by_stage.get(slug,0)+1
                    tier=c.get("tier") or "C"; by_tier[tier]=by_tier.get(tier,0)+1
                won, lost = by_stage.get("won",0), by_stage.get("lost",0)
                closed=won+lost
                trend=[]
                for i in range(7):
                    day=(since+_timedelta(days=i)).isoformat()
                    trend.append({"date":day,"count":sum(1 for r in delivered if str(r.get("delivered_at") or "")[:10]==day)})
                return {"tenant":tenant[0] if tenant else None,"kpis":{"total_leads":len(cards),"tier_a":by_tier.get("A",0),"tier_b":by_tier.get("B",0),"tier_c":by_tier.get("C",0),"new":by_stage.get("new",0),"in_pipeline":len(cards)-won-lost,"won":won,"lost":lost,"win_rate_pct":round(100*won/closed,1) if closed else 0},"funnel":[{"stage":x.get("name"),"slug":x.get("slug"),"color":x.get("color"),"count":by_stage.get(x.get("slug") or "",0)} for x in stages],"usage":usage[0] if usage else None,"quota_limit":tenant[0].get("leads_per_month_limit") if tenant else None,"tasks_due":tasks,"recent_activity":activities,"trend":trend}
            return await _asyncio.to_thread(_read)

        logger.warning("CRM router did not mount dashboard; installed protected runtime fallback /crm/{tenant_id}/dashboard")
except Exception as e:
    logger.exception("Failed to install runtime CRM dashboard fallback: %s", e)

try:
    from app.api.prod.platform_api import router as platform_router
    app.include_router(platform_router)
    logger.info("Mounted /platform admin control plane")
except Exception as e:
    logger.exception("Failed to mount platform_api: %s", e)

try:
    # Import for the side effect of populating jobs.HANDLERS, so an API
    # process can validate a job kind before enqueuing it.
    # NOTE: must be `from ... import`, NOT `import app.integrations...` —
    # a dotted import would rebind the name `app` here to the package
    # module, clobbering the FastAPI instance above.
    from app.integrations.prod import job_handlers  # noqa: F401
except Exception as e:
    logger.exception("Failed to register job handlers: %s", e)
