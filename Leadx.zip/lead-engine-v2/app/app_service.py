"""
Lead Engine — managed service entrypoint.
  uvicorn app.app_service:app --host 0.0.0.0 --port 8000 --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging
import os
from pathlib import Path as _Path

# Load lead-engine-v2/.env before anything else reads os.environ
try:
    from dotenv import load_dotenv
    _env_file = _Path(__file__).resolve().parents[1] / ".env"
    if _env_file.is_file():
        load_dotenv(_env_file, override=True)
    else:
        load_dotenv(override=True)
except ImportError:
    pass

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("lead_engine.service")

app = FastAPI(
    title="Automiqo Lead Service",
    version="3.0.0",
    description="Managed lead generation — operator API + client CRM",
)

# Development: allow all origins (Codespaces / local). Production: set CORS_ORIGINS.
_env = os.getenv("ENVIRONMENT", "development").lower()
_cors = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
if _env not in ("production", "prod", "staging") or not _cors:
    _cors = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors,
    allow_credentials=(_cors != ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    env = os.getenv("ENVIRONMENT", "dev").lower()
    missing = [k for k in ("SUPABASE_URL",) if not os.getenv(k)]
    if not (
        os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_KEY")
    ):
        missing.append("SUPABASE_SERVICE_KEY")
    if missing:
        logger.warning("Missing env (DB calls will fail): %s", missing)
    if env in ("production", "prod"):
        sk = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
        if len(sk) < 16:
            logger.error("LEAD_ENGINE_SERVICE_KEY required (≥16 chars) in production")
        if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
            logger.error("LEAD_ENGINE_DEV_AUTH_BYPASS must be false in production")
        if not os.getenv("DELIVERY_CONFIG_KEY"):
            logger.warning("DELIVERY_CONFIG_KEY unset — delivery secrets may be plaintext")
    logger.info("Lead service started env=%s version=3.0.0", env)


@app.get("/health")
async def health():
    checks = {
        "api": True,
        "db": None,
        "service_key": bool(os.getenv("LEAD_ENGINE_SERVICE_KEY")),
    }
    try:
        from app.memory.supabase_client import get_supabase
        sb = get_supabase()
        sb.table("tenants").select("id").limit(1).execute()
        checks["db"] = True
    except Exception as e:
        checks["db"] = False
        checks["db_error"] = str(e)[:200]
    try:
        from app.integrations.prod.scale_control import scale_health
        checks["scale"] = scale_health()
    except Exception as e:
        checks["scale"] = {"ok": False, "error": str(e)[:160]}
    ok = checks["api"] and checks["db"] is True
    return {
        "ok": ok,
        "service": "lead-engine",
        "mode": "managed_service",
        "version": "3.0.0",
        "checks": checks,
    }


@app.get("/")
async def root():
    return {
        "service": "Automiqo Lead Service",
        "docs": "/docs",
        "health": "/health",
        "operator_api": "/leads/v2",
        "crm_api": "/crm",
    }


try:
    from app.api.prod.leads_api import router as leads_router
    app.include_router(leads_router)
    logger.info("Mounted /leads/v2")
except Exception as e:
    logger.exception("Failed to mount leads_api: %s", e)

try:
    # Single CRM router, JWT-protected via require_tenant (crm_api.py
    # docstring has the detail). crm_public_router carries /team/accept,
    # which needs a lighter auth check since accepting an invite happens
    # before someone has tenant membership yet.
    from app.crm.crm_api import router as crm_router, crm_public_router
    app.include_router(crm_router)
    app.include_router(crm_public_router)
    logger.info("Mounted /crm (require_tenant) + /crm public (team/accept)")
except Exception as e:
    logger.exception("Failed to mount CRM router: %s", e)

try:
    # Was written but never mounted — every companies/contacts/deals/
    # activities/notes route was a 404. Mounted after crm_api so that
    # router keeps precedence on any shared prefix.
    from app.crm.crm_entities_api import router as crm_entities_router
    app.include_router(crm_entities_router)
    logger.info("Mounted /crm entities (companies/contacts/deals)")
except Exception as e:
    logger.exception("Failed to mount CRM entities router: %s", e)

try:
    from app.crm.crm_extras_api import router as crm_extras_router, public_router as crm_extras_public
    app.include_router(crm_extras_router)
    app.include_router(crm_extras_public)
    logger.info("Mounted /crm extras (notifications/views/import/reports)")
except Exception as e:
    logger.exception("Failed to mount CRM extras router: %s", e)

try:
    from app.api.prod.ops_api import router as ops_router
    app.include_router(ops_router)
    logger.info("Mounted /leads/v2 ops (jobs/notifications/prospecting)")
except Exception as e:
    logger.exception("Failed to mount ops_api: %s", e)

try:
    from app.api.prod.intelligence_api import router as intelligence_router
    app.include_router(intelligence_router)
    logger.info("Mounted /crm intelligence (AI briefs/revenue funnel/learning)")
except Exception as e:
    logger.exception("Failed to mount intelligence_api: %s", e)

try:
    from app.api.prod.support_api import client_router as support_client_router, admin_router as support_admin_router
    app.include_router(support_client_router)
    app.include_router(support_admin_router)
    logger.info("Mounted /support + /support/admin")
except Exception as e:
    logger.exception("Failed to mount support_api: %s", e)

try:
    from app.api.prod.platform_api import router as platform_router
    app.include_router(platform_router)
    logger.info("Mounted /platform admin control plane")
except Exception as e:
    logger.exception("Failed to mount platform_api: %s", e)

try:
    # Import for the side effect of populating jobs.HANDLERS, so an API
    # process can validate a job kind before enqueuing it.
    # NOTE: must be `from ... import`, NOT `import app.integrations...` —
    # a dotted import would rebind the name `app` here to the package
    # module, clobbering the FastAPI instance above.
    from app.integrations.prod import job_handlers  # noqa: F401
except Exception as e:
    logger.exception("Failed to register job handlers: %s", e)
