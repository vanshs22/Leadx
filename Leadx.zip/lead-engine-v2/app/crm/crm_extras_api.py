"""
Client CRM extras — notifications, saved views, CSV import, deal reports.

Split out of crm_api.py to keep that file navigable; identical auth
(require_tenant on the router, assert_tenant_match per handler) and the
same /crm prefix, so it's one API from the frontend's perspective.

The SES event webhook lives here too, on the public router, next to the
existing inbound-reply webhook it mirrors.
"""
from __future__ import annotations

import logging
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from app.middleware.auth import TenantContext, assert_tenant_match, require_tenant

logger = logging.getLogger("lead_engine.crm_extras")

router = APIRouter(prefix="/crm", tags=["crm-extras"], dependencies=[Depends(require_tenant)])
public_router = APIRouter(prefix="/crm", tags=["crm-extras-public"])


# ---------------------------------------------------------------- notifications


@router.get("/{tenant_id}/notifications")
async def list_notifications(
    tenant_id: UUID,
    unread_only: bool = False,
    limit: int = Query(50, ge=1, le=200),
    ctx: TenantContext = Depends(require_tenant),
):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.notifications import (
        list_notifications as _list,
        unread_count,
    )

    tid = str(tenant_id)
    return {
        "ok": True,
        "unread": unread_count(scope="tenant", tenant_id=tid),
        "notifications": _list(
            scope="tenant", tenant_id=tid, unread_only=unread_only, limit=limit
        ),
    }


class MarkReadRequest(BaseModel):
    ids: list[str] = Field(default_factory=list)
    all: bool = False


@router.post("/{tenant_id}/notifications/read")
async def mark_notifications_read(
    tenant_id: UUID, req: MarkReadRequest, ctx: TenantContext = Depends(require_tenant)
):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.notifications import mark_all_read, mark_read

    tid = str(tenant_id)
    n = (
        mark_all_read(scope="tenant", tenant_id=tid)
        if req.all
        else mark_read(req.ids, scope="tenant", tenant_id=tid)
    )
    return {"ok": True, "marked": n}


# ---------------------------------------------------------------- saved views


class SavedViewCreate(BaseModel):
    name: str
    filters: dict = Field(default_factory=dict)
    entity: str = "leads"
    shared: bool = True
    is_default: bool = False


class SavedViewUpdate(BaseModel):
    name: Optional[str] = None
    filters: Optional[dict] = None
    is_default: Optional[bool] = None


@router.get("/{tenant_id}/views")
async def get_views(
    tenant_id: UUID, entity: str = "leads", ctx: TenantContext = Depends(require_tenant)
):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_reports import list_views

    return {"ok": True, "views": list_views(str(tenant_id), entity, ctx.user_id)}


@router.post("/{tenant_id}/views")
async def post_view(
    tenant_id: UUID, req: SavedViewCreate, ctx: TenantContext = Depends(require_tenant)
):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_reports import create_view

    return create_view(
        str(tenant_id),
        req.name,
        req.filters,
        entity=req.entity,
        user_id=ctx.user_id,
        shared=req.shared,
        is_default=req.is_default,
    )


@router.patch("/{tenant_id}/views/{view_id}")
async def patch_view(
    tenant_id: UUID,
    view_id: str,
    req: SavedViewUpdate,
    ctx: TenantContext = Depends(require_tenant),
):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_reports import update_view

    patch = {k: v for k, v in req.model_dump().items() if v is not None}
    return update_view(str(tenant_id), view_id, patch)


@router.delete("/{tenant_id}/views/{view_id}")
async def remove_view(
    tenant_id: UUID, view_id: str, ctx: TenantContext = Depends(require_tenant)
):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.audit_log import record
    from app.integrations.prod.crm_reports import delete_view

    res = delete_view(str(tenant_id), view_id)
    record(
        str(tenant_id),
        ctx.email or ctx.user_id,
        "view.delete",
        target_type="saved_view",
        target_id=view_id,
    )
    return res


# ---------------------------------------------------------------- CSV import


class ImportPreviewRequest(BaseModel):
    csv_text: str
    entity: str = "companies"


class ImportRunRequest(BaseModel):
    csv_text: str
    entity: str = "companies"


@router.post("/{tenant_id}/import/preview")
async def import_preview(
    tenant_id: UUID, req: ImportPreviewRequest, ctx: TenantContext = Depends(require_tenant)
):
    """Column mapping + sample rows, so a mis-mapped file is caught before
    3000 rows land in the CRM."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.csv_import import preview

    if not (req.csv_text or "").strip():
        raise HTTPException(400, "csv_text is empty")
    if req.entity not in ("companies", "contacts"):
        raise HTTPException(400, "entity must be 'companies' or 'contacts'")
    return preview(req.csv_text, req.entity)


@router.post("/{tenant_id}/import/run")
async def import_run(
    tenant_id: UUID, req: ImportRunRequest, ctx: TenantContext = Depends(require_tenant)
):
    """Parses here (so a malformed file fails fast with a clear error)
    then queues the insert work so a 5000-row file doesn't hold the
    request open."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import jobs
    from app.integrations.prod.csv_import import parse_csv
    import app.integrations.prod.job_handlers  # noqa: F401

    if req.entity not in ("companies", "contacts"):
        raise HTTPException(400, "entity must be 'companies' or 'contacts'")
    rows, headers = parse_csv(req.csv_text or "")
    if not rows:
        raise HTTPException(400, "no data rows found — check the file has a header row")

    jid = jobs.enqueue(
        "csv.import",
        {
            "tenant_id": str(tenant_id),
            "rows": rows,
            "entity": req.entity,
            "created_by": ctx.email or ctx.user_id,
        },
        tenant_id=str(tenant_id),
        priority=1,  # short and user-visible: ahead of pipeline runs
        created_by=ctx.email or "client",
    )
    from app.integrations.prod.audit_log import record

    record(
        str(tenant_id),
        ctx.email or ctx.user_id,
        "import.run",
        target_type="job",
        target_id=jid,
        meta={"entity": req.entity, "rows": len(rows)},
    )
    return {"ok": True, "job_id": jid, "rows": len(rows), "headers": headers, "status": "queued"}


# ---------------------------------------------------------------- deal reports


@router.get("/{tenant_id}/reports/deals")
async def deal_reports(
    tenant_id: UUID,
    days: int = Query(365, ge=7, le=1095),
    ctx: TenantContext = Depends(require_tenant),
):
    """Revenue attribution + weighted forecast. `attribution_pct` is the
    share of won revenue traceable to a delivered lead."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_reports import deal_report

    return deal_report(str(tenant_id), days)


# ---------------------------------------------------------------- deliverability (client view)


@router.get("/{tenant_id}/email/health")
async def email_health(tenant_id: UUID, ctx: TenantContext = Depends(require_tenant)):
    """What the client sees on their email settings page: today's cap,
    how much of it is used, and warm-up progress."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.email_outreach import tenant_from_email
    from app.integrations.prod.send_policy import (
        domain_under_cap,
        sending_domain,
        warmup_status,
    )
    from app.integrations.prod.ses_events import bounce_stats

    tid = str(tenant_id)
    domain = sending_domain(tenant_from_email(tid))
    allowed, sent, cap = domain_under_cap(tid, domain)
    return {
        "ok": True,
        "domain": domain,
        "sent_today": sent,
        "daily_cap": cap,
        "remaining_today": max(0, cap - sent),
        "can_send_now": allowed,
        "warmup": warmup_status(tid),
        "reputation": bounce_stats(tid),
    }


# ---------------------------------------------------------------- copy library (A/B)


@router.get("/{tenant_id}/copy/categories")
async def copy_categories(tenant_id: UUID, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import email_copy_library as lib

    return {"categories": lib.categories(), "merge_tags": lib.MERGE_TAGS}


@router.get("/{tenant_id}/copy/{category}")
async def copy_variants(tenant_id: UUID, category: str, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import email_copy_library as lib

    if category not in lib.LIBRARY:
        raise HTTPException(404, f"unknown category — try one of {', '.join(lib.categories())}")
    tid = str(tenant_id)
    return {
        "category": category,
        "variants": lib.variants(category),
        "recommended": lib.best_variant(category, tid),
        "merge_tags": lib.MERGE_TAGS,
        "min_sends_for_confidence": lib.MIN_SENDS_FOR_CONFIDENCE,
    }


class VariantEventRequest(BaseModel):
    category: str
    variant_key: str
    event: str = Field("sent", description="sent | opened | replied | positive")
    count: int = Field(1, ge=1, le=10_000)


@router.post("/{tenant_id}/copy/track")
async def copy_track(
    tenant_id: UUID, req: VariantEventRequest, ctx: TenantContext = Depends(require_tenant)
):
    """Record an A/B event. Written to both the tenant's own row and the
    global row: the tenant row optimises this client, the global row is what
    a brand-new client inherits on day one."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import email_copy_library as lib

    if req.event not in ("sent", "opened", "replied", "positive"):
        raise HTTPException(400, "event must be sent, opened, replied or positive")
    kw = {req.event: req.count}
    lib.record(req.category, req.variant_key, tenant_id=str(tenant_id), **kw)
    lib.record(req.category, req.variant_key, tenant_id=None, **kw)
    return {"ok": True}


# ---------------------------------------------------------------- email composer


class LintRequest(BaseModel):
    subject: str = ""
    body_html: str = ""


@router.post("/{tenant_id}/email/lint")
async def email_lint(tenant_id: UUID, req: LintRequest, ctx: TenantContext = Depends(require_tenant)):
    """Rule-based subject + body check. No LLM, so the editor can call this
    on every pause in typing without cost or latency."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import email_composer as ec
    from app.integrations.prod.email_copy_library import MERGE_TAGS

    known = MERGE_TAGS + ["amount", "due_date", "invoice_number", "unsubscribe_url"]
    return {
        "subject": ec.check_subject(req.subject) if req.subject is not None else None,
        "body": ec.check_body(req.body_html, known_tags=known) if req.body_html else None,
    }


class RewriteRequest(BaseModel):
    subject: str = ""
    body_html: str = ""
    tone: Optional[str] = None
    mode: Optional[str] = None
    instruction: Optional[str] = None


@router.post("/{tenant_id}/email/rewrite")
async def email_rewrite(tenant_id: UUID, req: RewriteRequest, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import email_composer as ec

    res = await ec.rewrite(
        subject=req.subject,
        body=req.body_html,
        tone=req.tone,
        mode=req.mode,
        instruction=req.instruction,
    )
    if not res.get("ok"):
        raise HTTPException(400, res.get("error") or "rewrite failed")
    return res


@router.get("/{tenant_id}/email/tones")
async def email_tones(tenant_id: UUID, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod import email_composer as ec

    return {
        "tones": [{"key": k, "instruction": v} for k, v in ec.TONES.items()],
        "modes": [{"key": k, "instruction": v} for k, v in ec.MODES.items()],
    }


# ---------------------------------------------------------------- SES events webhook


@public_router.post("/webhooks/ses-events")
async def ses_events(request: Request, secret: Optional[str] = None):
    """SES → SNS bounce/complaint/delivery feed. Same shared-secret guard
    as the inbound-reply webhook (SNS can't send a Bearer token).

    Hard bounces and complaints are suppressed globally the moment they
    arrive — waiting for a human to read a bounce report is how a sending
    domain gets blacklisted."""
    import os

    expected = os.getenv("WEBHOOK_SECRET")
    if expected and secret != expected:
        raise HTTPException(403, "invalid webhook secret")
    from app.integrations.prod.audit_log import is_duplicate_webhook
    from app.integrations.prod.ses_events import handle_ses_event

    body = await request.json()
    if is_duplicate_webhook("ses-events", body):
        return {"ok": True, "duplicate": True}
    return await handle_ses_event(body)


# ---------------------------------------------------------------- data rights (GDPR)


@router.get("/{tenant_id}/data/export")
async def data_export(tenant_id: UUID, ctx: TenantContext = Depends(require_tenant)):
    """Subject-access / portability dump of everything this tenant owns."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.data_rights import export_tenant

    return {"ok": True, "export": export_tenant(str(tenant_id))}


class ErasureRequest(BaseModel):
    email: str
    reason: Optional[str] = None


@router.post("/{tenant_id}/data/erase-contact")
async def data_erase_contact(
    tenant_id: UUID, req: ErasureRequest, ctx: TenantContext = Depends(require_tenant)
):
    """Right-to-erasure: anonymise the person across the CRM and add them to
    the global opt-out. Irreversible — hence the audit row."""
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.audit_log import record
    from app.integrations.prod.data_rights import delete_contact_pii

    if not (req.email or "").strip():
        raise HTTPException(400, "email is required")
    res = await delete_contact_pii(str(tenant_id), req.email)
    record(
        str(tenant_id),
        ctx.email or ctx.user_id,
        "data.erase_contact",
        target_type="contact",
        target_id=req.email.strip().lower(),
        meta={"reason": req.reason, "result": res},
    )
    if not res.get("ok"):
        raise HTTPException(500, res.get("error") or "erasure failed")
    return res

# ---------------------------------------------------------------- revenue intelligence / prospect audits

@router.get("/{tenant_id}/intelligence/tasks")
async def intelligence_tasks(tenant_id: UUID, limit: int = Query(100, ge=1, le=500), ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_intelligence import task_queue
    return {"ok": True, **task_queue(str(tenant_id), limit)}


@router.get("/{tenant_id}/intelligence/pipeline")
async def intelligence_pipeline(tenant_id: UUID, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_intelligence import pipeline_health
    return {"ok": True, **pipeline_health(str(tenant_id))}


@router.get("/{tenant_id}/intelligence/attribution")
async def intelligence_attribution(tenant_id: UUID, days: int = Query(365, ge=7, le=1095), ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_intelligence import attribution
    return {"ok": True, **attribution(str(tenant_id), days)}


class ProspectAuditCreate(BaseModel):
    lead_id: Optional[str] = None
    company_id: Optional[str] = None
    title: str = "Prospect audit"
    sections: dict = Field(default_factory=dict)


@router.post("/{tenant_id}/audits")
async def create_prospect_audit(tenant_id: UUID, req: ProspectAuditCreate, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    from app.integrations.prod.crm_intelligence import create_audit
    row=create_audit(str(tenant_id), lead_id=req.lead_id, company_id=req.company_id, title=req.title, sections=req.sections, created_by=ctx.email or ctx.user_id)
    return {"ok": True, "audit": row, "share_url": f"/audit/{row.get('public_token')}"}


@public_router.get("/public/audits/{token}")
async def public_prospect_audit(token: str):
    from app.integrations.prod.crm_intelligence import public_audit
    row=public_audit(token)
    if not row: raise HTTPException(404, "audit not found or expired")
    return {"ok": True, "audit": row}

# ---------------------------------------------------------------- integrations / outbound webhooks

class WebhookCreate(BaseModel):
    name: str
    endpoint_url: str
    events: list[str] = Field(default_factory=list)
    retry_limit: int = Field(default=6, ge=1, le=20)


@router.get("/{tenant_id}/integrations/webhooks")
async def list_webhooks(tenant_id: UUID, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    rows = _sb().table("outbound_webhooks").select("id,name,endpoint_url,events,active,retry_limit,created_at,updated_at").eq("tenant_id",str(tenant_id)).order("created_at",desc=True).execute().data or []
    return {"ok":True,"webhooks":rows}


@router.post("/{tenant_id}/integrations/webhooks")
async def create_webhook(tenant_id: UUID, req: WebhookCreate, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    row={"tenant_id":str(tenant_id),**req.model_dump()}
    rows=_sb().table("outbound_webhooks").insert(row).execute().data or []
    return {"ok":True,"webhook":rows[0] if rows else row}


@router.delete("/{tenant_id}/integrations/webhooks/{webhook_id}")
async def delete_webhook(tenant_id: UUID, webhook_id: str, ctx: TenantContext = Depends(require_tenant)):
    assert_tenant_match(ctx, tenant_id)
    _sb().table("outbound_webhooks").delete().eq("id",webhook_id).eq("tenant_id",str(tenant_id)).execute()
    return {"ok":True}


def _sb():
    from app.memory.supabase_client import get_supabase
    return get_supabase()
