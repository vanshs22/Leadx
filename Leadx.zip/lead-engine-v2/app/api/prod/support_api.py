from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.middleware.auth import require_tenant, TenantContext
from app.middleware.service_auth import require_service_key
from app.integrations.prod.support_chat import answer_customer, conversation_messages
from app.memory.supabase_client import get_supabase

client_router = APIRouter(prefix="/support", tags=["support-client"], dependencies=[Depends(require_tenant)])
admin_router = APIRouter(prefix="/support/admin", tags=["support-admin"], dependencies=[Depends(require_service_key)])


def _sb(): return get_supabase()

class MessageIn(BaseModel):
    body: str = Field(min_length=1, max_length=8000)

class AdminReply(BaseModel):
    body: str = Field(min_length=1, max_length=12000)

class StatusIn(BaseModel):
    status: str

@client_router.get("/conversations")
async def client_conversations(ctx: TenantContext = Depends(require_tenant)):
    rows = _sb().table("support_conversations").select("*").eq("tenant_id", ctx.tenant_id).order("updated_at", desc=True).limit(30).execute().data or []
    return {"ok": True, "conversations": rows}

@client_router.post("/conversations")
async def create_conversation(ctx: TenantContext = Depends(require_tenant)):
    row = _sb().table("support_conversations").insert({
        "tenant_id": ctx.tenant_id,
        "user_id": ctx.user_id,
        "user_email": ctx.email,
        "subject": "LeadX Support",
        "status": "open",
        "needs_human": False,
    }).execute().data
    return {"ok": True, "conversation": (row or [None])[0]}

@client_router.get("/conversations/{conversation_id}/messages")
async def client_messages(conversation_id: str, ctx: TenantContext = Depends(require_tenant)):
    return {"ok": True, "messages": conversation_messages(conversation_id, ctx.tenant_id)}

@client_router.post("/conversations/{conversation_id}/messages")
async def client_message(conversation_id: str, payload: MessageIn, ctx: TenantContext = Depends(require_tenant)):
    conv = _sb().table("support_conversations").select("id,status").eq("id", conversation_id).eq("tenant_id", ctx.tenant_id).limit(1).execute().data or []
    if not conv: raise HTTPException(404, "Conversation not found")
    if conv[0].get("status") == "closed": raise HTTPException(409, "Conversation is closed")
    result = await answer_customer(conversation_id=conversation_id, tenant_id=ctx.tenant_id, user_id=ctx.user_id, message=payload.body)
    return {"ok": True, **result}

@admin_router.get("/conversations")
async def admin_conversations(status: Optional[str] = None, needs_human: Optional[bool] = None, limit: int = 100):
    q = _sb().table("support_conversations").select("*").order("updated_at", desc=True).limit(min(limit, 200))
    if status: q = q.eq("status", status)
    if needs_human is not None: q = q.eq("needs_human", needs_human)
    rows = q.execute().data or []
    return {"ok": True, "conversations": rows}

@admin_router.get("/conversations/{conversation_id}/messages")
async def admin_messages(conversation_id: str):
    return {"ok": True, "messages": conversation_messages(conversation_id)}

@admin_router.post("/conversations/{conversation_id}/reply")
async def admin_reply(conversation_id: str, payload: AdminReply):
    conv = _sb().table("support_conversations").select("id").eq("id", conversation_id).limit(1).execute().data or []
    if not conv: raise HTTPException(404, "Conversation not found")
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    _sb().table("support_messages").insert({
        "conversation_id": conversation_id,
        "sender_type": "admin",
        "sender_id": "admin",
        "body": payload.body.strip(),
        "created_at": now,
    }).execute()
    _sb().table("support_conversations").update({
        "status": "human",
        "needs_human": False,
        "last_message_at": now,
        "updated_at": now,
    }).eq("id", conversation_id).execute()
    return {"ok": True}

@admin_router.patch("/conversations/{conversation_id}")
async def admin_status(conversation_id: str, payload: StatusIn):
    allowed = {"open", "human", "escalated", "resolved", "closed"}
    if payload.status not in allowed: raise HTTPException(400, "Invalid status")
    _sb().table("support_conversations").update({"status": payload.status, "needs_human": payload.status == "escalated"}).eq("id", conversation_id).execute()
    return {"ok": True}

@admin_router.get("/faq")
async def admin_faq():
    rows = _sb().table("support_faq").select("*").order("category").order("priority", desc=True).execute().data or []
    return {"ok": True, "faq": rows}
