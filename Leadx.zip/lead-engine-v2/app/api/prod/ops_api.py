"""
Operator API — job monitor, notifications, own prospecting, deliverability.

Separate router from leads_api.py purely to keep that file from growing
another 600 lines; same service-key auth, same /leads/v2 prefix, so it's
one API surface from the frontend's point of view.
"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.middleware.service_auth import require_service_key

router = APIRouter(
    prefix="/leads/v2",
    tags=["ops-v2"],
    dependencies=[Depends(require_service_key)],
)


# ---------------------------------------------------------------- jobs


@router.get("/admin/jobs")
async def list_jobs(
    status: Optional[str] = None,
    kind: Optional[str] = None,
    tenant_id: Optional[str] = None,
    limit: int = Query(100, ge=1, le=500),
):
    """Running/queued/failed jobs across all tenants — the "why is this
    client's pipeline stuck" page."""
    from app.integrations.prod import jobs
    import app.integrations.prod.job_handlers  # noqa: F401  populate HANDLERS

    return {
        "ok": True,
        "stats": jobs.queue_stats(),
        "jobs": jobs.list_jobs(status=status, kind=kind, tenant_id=tenant_id, limit=limit),
    }


@router.get("/admin/jobs/{job_id}")
async def get_job(job_id: str):
    from app.integrations.prod.jobs import get_job as _get

    job = _get(job_id)
    if not job:
        raise HTTPException(404, "job not found")
    return {"ok": True, "job": job}


@router.post("/admin/jobs/{job_id}/retry")
async def retry_job(job_id: str):
    from app.integrations.prod.jobs import retry_job as _retry

    return _retry(job_id)


@router.post("/admin/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    from app.integrations.prod.jobs import cancel_job as _cancel

    return _cancel(job_id)


@router.post("/admin/jobs/reap")
async def reap_jobs():
    """Return jobs whose worker died back to the queue. The worker does
    this on a timer; this is the manual button for when you've just
    restarted workers and don't want to wait."""
    from app.integrations.prod.jobs import reap_stale

    return {"ok": True, "reaped": reap_stale()}


class EnqueueRequest(BaseModel):
    kind: str
    payload: dict = Field(default_factory=dict)
    tenant_id: Optional[str] = None
    priority: int = 0
    delay_seconds: int = 0


@router.post("/admin/jobs/enqueue")
async def enqueue_job(req: EnqueueRequest):
    """Escape hatch: queue any registered kind by hand. Useful for
    re-running a one-off maintenance pass without a deploy."""
    from app.integrations.prod import jobs
    import app.integrations.prod.job_handlers  # noqa: F401

    if req.kind not in jobs.HANDLERS:
        raise HTTPException(400, f"unknown job kind '{req.kind}'. Known: {sorted(jobs.HANDLERS)}")
    jid = jobs.enqueue(
        req.kind,
        req.payload,
        tenant_id=req.tenant_id,
        priority=req.priority,
        delay_seconds=req.delay_seconds,
        created_by="admin",
    )
    return {"ok": True, "job_id": jid, "kind": req.kind}


# ---------------------------------------------------------------- production scale / learning

@router.get("/admin/scale-health")
async def scale_health():
    from app.integrations.prod.scale_control import scale_health as _health
    return {"ok": True, "health": _health()}

@router.post("/admin/workers/heartbeat")
async def worker_heartbeat(worker_id: str, capacity: int = 1):
    from app.integrations.prod.scale_control import worker_heartbeat as _beat
    return {"ok": True, "worker": _beat(worker_id, capacity=capacity)}

# ---------------------------------------------------------------- notifications


@router.get("/admin/notifications")
async def admin_notifications(
    unread_only: bool = False,
    tenant_id: Optional[str] = None,
    limit: int = Query(50, ge=1, le=200),
):
    from app.integrations.prod.notifications import list_notifications, unread_count

    return {
        "ok": True,
        "unread": unread_count(scope="admin"),
        "notifications": list_notifications(
            scope="admin", tenant_id=tenant_id, unread_only=unread_only, limit=limit
        ),
    }


class MarkReadRequest(BaseModel):
    ids: list[str] = Field(default_factory=list)
    all: bool = False


@router.post("/admin/notifications/read")
async def admin_mark_read(req: MarkReadRequest):
    from app.integrations.prod.notifications import mark_all_read, mark_read

    n = mark_all_read(scope="admin") if req.all else mark_read(req.ids, scope="admin")
    return {"ok": True, "marked": n}


# ---------------------------------------------------------------- admin replies


@router.get("/admin/replies")
async def admin_replies(
    tenant_id: Optional[str] = None,
    category: Optional[str] = None,
    operator_only: bool = False,
    limit: int = Query(100, ge=1, le=300),
):
    """The replies inbox, operator-scoped. operator_only=true shows
    replies to our *own* outbound (the internal tenant); otherwise it's
    every tenant's replies in one triage list."""
    from app.memory.supabase_client import get_supabase

    sb = get_supabase()
    if operator_only:
        from app.integrations.prod.operator_pipeline import get_operator_tenant

        t = get_operator_tenant()
        if not t:
            return {"ok": True, "replies": [], "note": "operator_tenant_not_created"}
        tenant_id = t["id"]

    try:
        q = sb.table("email_replies").select("*")
        if tenant_id:
            q = q.eq("tenant_id", tenant_id)
        if category:
            q = q.eq("category", category)
        replies = q.order("received_at", desc=True).limit(limit).execute().data or []
    except Exception as e:
        raise HTTPException(500, f"replies query failed: {e}") from e

    # Attach tenant names so the operator list is readable without
    # cross-referencing uuids by hand.
    names: dict[str, str] = {}
    ids = list({r.get("tenant_id") for r in replies if r.get("tenant_id")})
    if ids:
        try:
            for t in sb.table("tenants").select("id, name").in_("id", ids).execute().data or []:
                names[t["id"]] = t["name"]
        except Exception:
            pass
    for r in replies:
        r["tenant_name"] = names.get(r.get("tenant_id") or "", "")
    return {"ok": True, "count": len(replies), "replies": replies}


# ---------------------------------------------------------------- own prospecting


class OperatorProspectRequest(BaseModel):
    locations: list[str] = Field(default_factory=list)
    queries: list[str] = Field(default_factory=list)
    limit_per_location: int = Field(default=40, ge=1, le=200)
    target_new_leads: int = Field(default=0, ge=0, le=20000)
    skip_enrichment: bool = False


@router.get("/admin/prospecting")
async def prospecting_summary():
    from app.integrations.prod.operator_pipeline import operator_summary

    return operator_summary()


@router.post("/admin/prospecting/setup")
async def prospecting_setup():
    """Creates the internal tenant + agency ICP + our own deal stages."""
    from app.integrations.prod.operator_pipeline import ensure_operator_tenant

    tenant = ensure_operator_tenant()
    return {"ok": True, "tenant_id": tenant["id"], "tenant_name": tenant["name"]}


@router.post("/admin/prospecting/run")
async def prospecting_run(req: OperatorProspectRequest):
    """Queued, not inline — our own prospecting is a full pipeline run and
    must not tie up a web worker."""
    from app.integrations.prod import jobs
    import app.integrations.prod.job_handlers  # noqa: F401
    from app.integrations.prod.operator_pipeline import ensure_operator_tenant

    tenant = ensure_operator_tenant()
    jid = jobs.enqueue(
        "operator.prospect",
        req.model_dump(),
        tenant_id=tenant["id"],
        priority=-1,  # client work outranks our own prospecting
        created_by="admin",
    )
    return {"ok": True, "job_id": jid, "tenant_id": tenant["id"], "status": "queued"}


# ---------------------------------------------------------------- deliverability


@router.get("/admin/deliverability")
async def deliverability(tenant_id: Optional[str] = None):
    """Bounce/complaint rates + warm-up state. SES starts throttling
    above 5% bounce or 0.1% complaint, so `healthy` is the flag to watch."""
    from app.integrations.prod.ses_events import bounce_stats
    from app.integrations.prod.send_policy import warmup_status

    out = {"ok": True, "stats": bounce_stats(tenant_id)}
    if tenant_id:
        out["warmup"] = warmup_status(tenant_id)
    return out


class WarmupRequest(BaseModel):
    tenant_id: str
    domain: str
    start_cap: int = Field(default=20, ge=1, le=5000)
    full_cap: int = Field(default=500, ge=1, le=100000)
    ramp_days: int = Field(default=21, ge=1, le=120)


@router.post("/admin/deliverability/warmup")
async def start_warmup(req: WarmupRequest):
    from app.integrations.prod.send_policy import start_warmup as _start

    return _start(
        req.tenant_id,
        req.domain.lower().strip(),
        start_cap=req.start_cap,
        full_cap=req.full_cap,
        ramp_days=req.ramp_days,
    )


@router.get("/admin/cron-audit")
async def cron_audit():
    """Which cron-dependent features have actually run recently.

    Every feature here fails silently when its trigger is misconfigured
    (the alerts-cron URL mismatch was exactly this), so "last ran N hours
    ago" is the only honest way to tell whether it's live."""
    from datetime import datetime, timezone

    from app.memory.supabase_client import get_supabase

    sb = get_supabase()
    now = datetime.now(timezone.utc)

    def _age_hours(ts: Optional[str]) -> Optional[float]:
        if not ts:
            return None
        try:
            dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
            return round((now - dt).total_seconds() / 3600, 1)
        except Exception:
            return None

    def _last(table: str, ts_col: str, **eq) -> Optional[str]:
        try:
            q = sb.table(table).select(ts_col)
            for k, v in eq.items():
                q = q.eq(k, v)
            rows = q.order(ts_col, desc=True).limit(1).execute().data or []
            return rows[0][ts_col] if rows else None
        except Exception:
            return None

    checks = [
        {
            "feature": "sequence sending",
            "expected_every_hours": 1,
            "last_run": _last("jobs", "finished_at", kind="sequences.process_due", status="done"),
        },
        {
            "feature": "alert checks",
            "expected_every_hours": 6,
            "last_run": _last("jobs", "finished_at", kind="alerts.run", status="done"),
        },
        {
            "feature": "lead re-verification",
            "expected_every_hours": 24,
            "last_run": _last("jobs", "finished_at", kind="leads.reverify", status="done"),
        },
        {
            "feature": "review mining",
            "expected_every_hours": 24,
            "last_run": _last("jobs", "finished_at", kind="reviews.mine", status="done"),
        },
        {
            "feature": "scoring feedback loop",
            "expected_every_hours": 168,
            "last_run": _last("vertical_priors", "updated_at"),
        },
        {
            "feature": "ops metrics rollup",
            "expected_every_hours": 24,
            "last_run": _last("ops_metrics_daily", "created_at"),
        },
        {
            "feature": "autonomous admin campaigns",
            "expected_every_hours": 1,
            "last_run": _last("jobs", "finished_at", kind="autonomous.campaign_tick", status="done"),
        },
    ]
    for c in checks:
        age = _age_hours(c["last_run"])
        c["age_hours"] = age
        # Two missed windows = stale. One is normal jitter.
        c["healthy"] = age is not None and age <= c["expected_every_hours"] * 2
        c["status"] = "never_run" if age is None else ("ok" if c["healthy"] else "stale")
    return {
        "ok": True,
        "checked_at": now.isoformat(),
        "all_healthy": all(c["healthy"] for c in checks),
        "checks": checks,
    }


# ---------------------------------------------------------------- automation
#
# Recurring discovery. The operator sets a schedule once and the worker's
# schedules.tick enqueues the pipeline runs; auto_enroll_sequence_id closes the
# loop into outreach so no human step sits between "lead found" and "email sent".


class ScheduleRequest(BaseModel):
    tenant_id: str
    name: str = Field(min_length=1, max_length=120)
    icp_id: Optional[str] = None
    industry: Optional[str] = None
    locations: list[str] = Field(default_factory=list)
    queries: list[str] = Field(default_factory=list)
    params: dict = Field(default_factory=dict)
    target_new_leads: int = Field(default=25, ge=1, le=5000)
    # Floor of 1h and ceiling of 30 days: below an hour the 5-minute tick makes
    # the cadence a lie, and anything longer is better modelled as "off".
    interval_hours: int = Field(default=24, ge=1, le=720)
    auto_enroll_sequence_id: Optional[str] = None
    active: bool = True


class ScheduleUpdate(BaseModel):
    name: Optional[str] = None
    icp_id: Optional[str] = None
    industry: Optional[str] = None
    locations: Optional[list[str]] = None
    queries: Optional[list[str]] = None
    params: Optional[dict] = None
    target_new_leads: Optional[int] = Field(default=None, ge=1, le=5000)
    interval_hours: Optional[int] = Field(default=None, ge=1, le=720)
    auto_enroll_sequence_id: Optional[str] = None
    active: Optional[bool] = None


@router.get("/admin/schedules")
async def list_schedules(tenant_id: Optional[str] = None):
    from app.integrations.prod.schedules import list_schedules as _list

    return {"ok": True, "rows": _list(tenant_id)}


@router.post("/admin/schedules")
async def create_schedule(req: ScheduleRequest):
    from app.integrations.prod.schedules import create_schedule as _create

    if not (req.icp_id or req.industry):
        raise HTTPException(
            400, "either icp_id or industry is required — the run needs something to search for"
        )
    try:
        row = _create(**req.model_dump())
    except Exception as e:
        raise HTTPException(500, f"could not create schedule: {e}") from e
    return {"ok": True, "schedule": row}


@router.patch("/admin/schedules/{schedule_id}")
async def update_schedule(schedule_id: str, req: ScheduleUpdate):
    from app.integrations.prod.schedules import update_schedule as _update

    row = _update(schedule_id, **req.model_dump())
    if not row:
        raise HTTPException(404, "schedule not found")
    return {"ok": True, "schedule": row}


@router.delete("/admin/schedules/{schedule_id}")
async def delete_schedule(schedule_id: str):
    from app.integrations.prod.schedules import delete_schedule as _delete

    _delete(schedule_id)
    return {"ok": True}


@router.post("/admin/schedules/{schedule_id}/run-now")
async def run_schedule_now(schedule_id: str):
    """Fire this schedule immediately without waiting for its next window.
    Does not disturb the cadence — next_run_at is still advanced by the tick."""
    from app.integrations.prod import jobs
    from app.integrations.prod.schedules import _pipeline_payload, get_schedule
    import app.integrations.prod.job_handlers  # noqa: F401

    s = get_schedule(schedule_id)
    if not s:
        raise HTTPException(404, "schedule not found")
    jid = jobs.enqueue_unique(
        "pipeline.run",
        _pipeline_payload(s),
        tenant_id=s["tenant_id"],
        created_by=f"admin_run_now:{schedule_id}",
    )
    if not jid:
        return {"ok": False, "error": "a run for this client is already in flight"}
    return {"ok": True, "job_id": jid, "status": "queued"}


@router.post("/admin/schedules/tick")
async def schedules_tick_now():
    """Manual tick, for checking automation without waiting up to 5 minutes."""
    from app.integrations.prod.schedules import tick

    return await tick()


# ---------------------------------------------------------------- workspace access
#
# The operator API (service key) and the client CRM API (Supabase JWT +
# tenant_members) are separate auth systems with no bridge: there is no "operator
# JWT that is admin everywhere". So the way to give an admin a real CRM — their
# own, or a client's, for support — is to give their Supabase user a membership
# row. That reuses the entire portal unchanged instead of rebuilding contacts,
# companies, deals and sequences behind the admin router.


class GrantRequest(BaseModel):
    email: str = Field(min_length=3, max_length=254)
    # None → the internal operator tenant, i.e. "give me my own workspace".
    tenant_id: Optional[str] = None
    role: str = Field(default="owner", pattern="^(owner|admin|member|viewer)$")


@router.post("/admin/workspace/grant")
async def grant_workspace(req: GrantRequest):
    """Give a Supabase user membership of a tenant so they can open it in the
    client portal. Audit-logged: this hands somebody a client's whole CRM."""
    from app.memory.supabase_client import get_supabase
    from app.integrations.prod.operator_pipeline import ensure_operator_tenant

    email = req.email.strip().lower()
    sb = get_supabase()

    if req.tenant_id:
        tenant_id = req.tenant_id
        rows = sb.table("tenants").select("id, name").eq("id", tenant_id).limit(1).execute().data or []
        if not rows:
            raise HTTPException(404, "tenant not found")
        tenant_name = rows[0]["name"]
    else:
        tenant = ensure_operator_tenant()
        tenant_id, tenant_name = tenant["id"], tenant["name"]

    # Resolve the auth user. Without an auth_user_id the row is an invite that
    # require_tenant cannot match, so the grant would look successful and then
    # fail at login — worth surfacing as an error instead.
    auth_user_id = None
    try:
        listed = sb.auth.admin.list_users()
        users = getattr(listed, "users", listed) or []
        for u in users:
            if (getattr(u, "email", "") or "").lower() == email:
                auth_user_id = str(getattr(u, "id", "") or "")
                break
    except Exception:
        raise HTTPException(
            502, "could not query Supabase auth users — check the service role key"
        ) from None
    if not auth_user_id:
        raise HTTPException(
            404,
            f"no Supabase auth user for {email} — create the login first "
            "(admin → client detail → provision login), then grant access",
        )

    try:
        sb.table("tenant_members").upsert(
            {
                "tenant_id": tenant_id,
                "auth_user_id": auth_user_id,
                "email": email,
                "role": req.role,
                "status": "active",
            },
            on_conflict="tenant_id,auth_user_id",
        ).execute()
    except Exception as e:
        raise HTTPException(500, f"could not grant membership: {e}") from e

    try:
        from app.integrations.prod.audit_log import record

        record(
            tenant_id=tenant_id,
            actor="operator",
            action="workspace.grant",
            target_type="tenant_members",
            target_id=auth_user_id,
            meta={"email": email, "role": req.role},
        )
    except Exception:
        pass

    return {
        "ok": True,
        "tenant_id": tenant_id,
        "tenant_name": tenant_name,
        "email": email,
        "role": req.role,
    }


@router.get("/admin/workspace/mine")
async def my_workspace():
    """The internal tenant, created on first call. This is the admin's own CRM —
    same tables, same routes, same UI as a client's, scoped to a tenant flagged
    is_operator so it stays out of client listings."""
    from app.integrations.prod.operator_pipeline import ensure_operator_tenant, operator_summary

    tenant = ensure_operator_tenant()
    return {"ok": True, "tenant_id": tenant["id"], "tenant_name": tenant["name"], **operator_summary()}


# ---------------------------------------------------------------- lead assignment


class AssignRequest(BaseModel):
    tenant_id: str
    lead_ids: list[str] = Field(min_length=1, max_length=500)
    icp_id: Optional[str] = None
    vertical: str = "manual"
    geo: list[str] = Field(default_factory=list)
    tier: str = Field(default="A", pattern="^(A|B|C)$")
    # Hand-picked leads are usually an exception to the plan cap, but the caller
    # decides — silently ignoring quota is how a client ends up over-delivered.
    ignore_quota: bool = False
    auto_enroll_sequence_id: Optional[str] = None


@router.post("/admin/leads/assign")
async def assign_leads_to_tenant(req: AssignRequest):
    """Hand specific leads from the global pool to a client.

    Discovery already assigns leads as a side effect of a pipeline run; this is
    the manual path for the cases a run can't express — a lead the operator
    sourced by hand, or moving inventory to the client who actually wants it.
    Reuses quality.assign_lead so quota, exclusivity and the 90-day recency rule
    are enforced identically.
    """
    from app.memory.supabase_client import get_supabase
    from app.integrations.prod.quality import assign_lead

    sb = get_supabase()
    trow = sb.table("tenants").select("id, delivery_channel").eq("id", req.tenant_id).limit(1).execute().data or []
    if not trow:
        raise HTTPException(404, "tenant not found")
    channel = trow[0].get("delivery_channel") or "portal"

    assigned, rejected = [], []
    for lead_id in req.lead_ids:
        try:
            res = await assign_lead(
                lead_id=lead_id,
                tenant_id=req.tenant_id,
                icp_id=req.icp_id,
                vertical=req.vertical,
                geo=req.geo,
                delivery_channel=channel,
                tier=req.tier,
            )
        except Exception as e:
            rejected.append({"lead_id": lead_id, "reason": f"error: {e}"})
            continue
        if res.get("assigned"):
            assigned.append(lead_id)
        else:
            rejected.append({"lead_id": lead_id, "reason": res.get("reason") or "rejected"})

    # Enrol what actually landed, so a partial assignment still starts outreach.
    enrolled = 0
    if assigned and req.auto_enroll_sequence_id:
        try:
            from app.integrations.prod.sequences import enroll_leads

            aids = [
                r["id"]
                for r in (
                    sb.table("lead_assignments")
                    .select("id")
                    .eq("tenant_id", req.tenant_id)
                    .in_("lead_id", assigned)
                    .execute()
                    .data
                    or []
                )
            ]
            if aids:
                enrolled = int(
                    (await enroll_leads(req.tenant_id, req.auto_enroll_sequence_id, aids)).get(
                        "enrolled", 0
                    )
                )
        except Exception:
            pass

    return {
        "ok": True,
        "assigned": len(assigned),
        "rejected": len(rejected),
        "enrolled": enrolled,
        "rejections": rejected[:50],
    }


@router.post("/admin/leads/unassign")
async def unassign_lead(assignment_id: str = Query(...)):
    """Remove an assignment, returning the lead to the global pool. Does not
    refund the tenant's monthly usage counter — that is a billing decision, not
    an inventory one."""
    from app.memory.supabase_client import get_supabase

    sb = get_supabase()
    rows = sb.table("lead_assignments").delete().eq("id", assignment_id).execute().data or []
    if not rows:
        raise HTTPException(404, "assignment not found")
    return {"ok": True, "removed": len(rows)}


# ---------------------------------------------------------------- operator sequences
#
# Sequence CRUD lived only on the tenant router (/crm, JWT). The operator had no
# way to build the cadence a schedule is supposed to enrol into, which made
# "automated lead finding + sending" impossible to set up from the admin side.


class OperatorSequenceRequest(BaseModel):
    tenant_id: str
    name: str = Field(min_length=1, max_length=140)
    steps: list[dict] = Field(min_length=1, max_length=20)


@router.get("/admin/sequences")
async def admin_list_sequences(tenant_id: str = Query(...)):
    from app.memory.supabase_client import get_supabase

    sb = get_supabase()
    seqs = (
        sb.table("email_sequences")
        .select("*")
        .eq("tenant_id", tenant_id)
        .order("created_at", desc=True)
        .execute()
        .data
        or []
    )
    if seqs:
        steps = (
            sb.table("email_sequence_steps")
            .select("*")
            .in_("sequence_id", [s["id"] for s in seqs])
            .order("step_number")
            .execute()
            .data
            or []
        )
        by_seq: dict[str, list] = {}
        for st in steps:
            by_seq.setdefault(st["sequence_id"], []).append(st)
        for s in seqs:
            s["steps"] = by_seq.get(s["id"], [])
    return {"ok": True, "rows": seqs}


@router.post("/admin/sequences")
async def admin_create_sequence(req: OperatorSequenceRequest):
    from app.integrations.prod.sequences import create_sequence

    res = await create_sequence(req.tenant_id, req.name, req.steps)
    if not res.get("ok", True):
        raise HTTPException(400, res.get("error") or "could not create sequence")
    return res

# ---------------------------------------------------------------- autonomous admin campaigns
# Admin-only: this is deliberately separate from the client discovery-request
# flow. It gives the operator a "set it and watch" engine for LeadX's own ICP.

class AutonomousCampaignRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    icp_id: Optional[str] = None
    sequence_id: Optional[str] = None
    locations: list[str] = Field(default_factory=list)
    queries: list[str] = Field(default_factory=list)
    offer: str = ""
    goal: str = "Book a qualified sales conversation"
    daily_new_lead_limit: int = Field(default=25, ge=1, le=5000)
    daily_email_limit: int = Field(default=25, ge=1, le=5000)
    max_active_enrollments: int = Field(default=5000, ge=1, le=100000)
    schedule_hours: int = Field(default=24, ge=1, le=720)
    timezone: str = "America/New_York"
    generate_ai_copy: bool = True
    auto_followup: bool = True
    stop_on_reply: bool = True
    stop_on_optout: bool = True
    require_verified_email: bool = True
    score_threshold: int = Field(default=70, ge=0, le=100)


class AutonomousCampaignUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    icp_id: Optional[str] = None
    sequence_id: Optional[str] = None
    locations: Optional[list[str]] = None
    queries: Optional[list[str]] = None
    offer: Optional[str] = None
    goal: Optional[str] = None
    daily_new_lead_limit: Optional[int] = Field(default=None, ge=1, le=5000)
    daily_email_limit: Optional[int] = Field(default=None, ge=1, le=5000)
    max_active_enrollments: Optional[int] = Field(default=None, ge=1, le=100000)
    schedule_hours: Optional[int] = Field(default=None, ge=1, le=720)
    timezone: Optional[str] = None
    generate_ai_copy: Optional[bool] = None
    auto_followup: Optional[bool] = None
    stop_on_reply: Optional[bool] = None
    stop_on_optout: Optional[bool] = None
    require_verified_email: Optional[bool] = None
    score_threshold: Optional[int] = Field(default=None, ge=0, le=100)
    status: Optional[str] = None


@router.get("/admin/autonomous-campaigns")
async def autonomous_campaigns(status: Optional[str] = None):
    from app.integrations.prod.autonomous_campaigns import list_campaigns
    rows = list_campaigns(status)
    from app.integrations.prod.operator_pipeline import ensure_operator_tenant
    operator = ensure_operator_tenant()
    stats = {}
    for c in rows:
        try:
            from app.integrations.prod.autonomous_campaigns import daily_stats
            stats[c["id"]] = daily_stats(c["id"])
        except Exception:
            stats[c["id"]] = {}
    return {"ok": True, "campaigns": rows, "daily": stats, "operator_tenant_id": (operator or {}).get("id")}


@router.post("/admin/autonomous-campaigns")
async def create_autonomous_campaign(req: AutonomousCampaignRequest):
    from app.integrations.prod.operator_pipeline import ensure_operator_tenant
    from app.integrations.prod.autonomous_campaigns import create_campaign
    tenant = ensure_operator_tenant()
    payload = req.model_dump()
    payload["tenant_id"] = tenant["id"]
    if payload.get("status") not in (None, "draft"):
        payload.pop("status", None)
    try:
        row = create_campaign(**payload)
        return {"ok": True, "campaign": row}
    except Exception as e:
        raise HTTPException(500, f"could not create autonomous campaign: {e}") from e


@router.patch("/admin/autonomous-campaigns/{campaign_id}")
async def update_autonomous_campaign(campaign_id: str, req: AutonomousCampaignUpdate):
    from app.integrations.prod.autonomous_campaigns import update_campaign
    payload = {k: v for k, v in req.model_dump().items() if v is not None}
    if payload.get("status") and payload["status"] not in {"draft","active","paused","completed","error"}:
        raise HTTPException(400, "invalid campaign status")
    row = update_campaign(campaign_id, **payload)
    if not row:
        raise HTTPException(404, "campaign not found")
    return {"ok": True, "campaign": row}


@router.post("/admin/autonomous-campaigns/{campaign_id}/run-now")
async def run_autonomous_campaign_now(campaign_id: str):
    from app.integrations.prod.autonomous_campaigns import get_campaign
    from app.integrations.prod import jobs
    import app.integrations.prod.job_handlers  # noqa: F401
    c = get_campaign(campaign_id)
    if not c:
        raise HTTPException(404, "campaign not found")
    if c.get("status") != "active":
        raise HTTPException(409, "campaign must be active")
    jid = jobs.enqueue_unique("autonomous.campaign_run", {"campaign_id": campaign_id}, tenant_id=c["tenant_id"], priority=-1, created_by="admin")
    return {"ok": bool(jid), "job_id": jid, "status": "queued" if jid else "already_in_flight"}


@router.post("/admin/autonomous-campaigns/tick")
async def autonomous_campaign_tick():
    from app.integrations.prod.autonomous_campaigns import tick
    return await tick()


@router.get("/admin/autonomous-campaigns/{campaign_id}/stats")
async def autonomous_campaign_stats(campaign_id: str):
    from app.integrations.prod.autonomous_campaigns import get_campaign, daily_stats
    c = get_campaign(campaign_id)
    if not c: raise HTTPException(404, "campaign not found")
    return {"ok": True, "campaign": c, "daily": daily_stats(campaign_id)}

# ---------------------------------------------------------------- LeadX 3.0 control-plane telemetry

@router.get('/admin/platform-summary')
async def admin_platform_summary():
    from app.integrations.prod.platform_control import platform_summary
    return {'ok': True, **platform_summary()}

@router.get('/admin/audit-log')
async def admin_audit_log(limit:int=100, tenant_id:Optional[str]=None):
    from app.memory.supabase_client import get_supabase
    q=get_supabase().table('audit_log').select('*').order('created_at',desc=True).limit(min(max(limit,1),500))
    if tenant_id:q=q.eq('tenant_id',tenant_id)
    return {'ok':True,'events':q.execute().data or []}

@router.get('/admin/security-events')
async def admin_security_events(limit:int=100, severity:Optional[str]=None):
    from app.memory.supabase_client import get_supabase
    q=get_supabase().table('security_events').select('*').order('created_at',desc=True).limit(min(max(limit,1),500))
    if severity:q=q.eq('severity',severity)
    return {'ok':True,'events':q.execute().data or []}

@router.get('/admin/provider-health')
async def admin_provider_health():
    from app.memory.supabase_client import get_supabase
    return {'ok':True,'providers':get_supabase().table('provider_health').select('*').order('observed_at',desc=True).execute().data or []}

@router.get('/admin/queue-metrics')
async def admin_queue_metrics(limit:int=100):
    from app.memory.supabase_client import get_supabase
    return {'ok':True,'metrics':get_supabase().table('queue_metrics').select('*').order('captured_at',desc=True).limit(min(max(limit,1),500)).execute().data or []}
