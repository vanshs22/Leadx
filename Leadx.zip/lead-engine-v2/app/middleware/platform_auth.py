"""Platform-admin JWT authentication.

Service-key auth remains available for internal workers/backward compatibility,
but browser-facing admin sessions can use Supabase Auth + platform_admins.
"""
from __future__ import annotations
from dataclasses import dataclass
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from app.middleware.auth import _verify_supabase_jwt
from app.memory.supabase_client import get_supabase

bearer=HTTPBearer(auto_error=False)
@dataclass
class PlatformAdmin:
    user_id:str
    email:str|None
    role:str

def _sb(): return get_supabase()

async def require_platform_admin(request:Request, creds:HTTPAuthorizationCredentials|None=Depends(bearer))->PlatformAdmin:
    if not creds or not creds.credentials:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED,'Missing admin bearer token',headers={'WWW-Authenticate':'Bearer'})
    payload=await _verify_supabase_jwt(creds.credentials)
    uid=payload.get('sub')
    if not uid: raise HTTPException(status.HTTP_401_UNAUTHORIZED,'Invalid admin token')
    try:
        rows=_sb().table('platform_admins').select('user_id,email,role,active').eq('user_id',uid).eq('active',True).limit(1).execute().data or []
    except Exception:
        rows=[]
    if not rows:
        from app.integrations.prod.platform_control import security_event
        security_event('platform_admin_denied','warning',actor_id=str(uid),ip=request.client.host if request.client else None)
        raise HTTPException(status.HTTP_403_FORBIDDEN,'Platform admin access required')
    a=rows[0]; request.state.platform_admin=a
    return PlatformAdmin(user_id=str(a['user_id']),email=a.get('email') or payload.get('email'),role=a.get('role') or 'admin')
