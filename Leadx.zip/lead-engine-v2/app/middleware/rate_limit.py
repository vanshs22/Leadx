"""
Simple in-memory + Redis rate limiter for expensive endpoints.
Protects /pipeline/run, /keys/add, enrichment triggers from abuse.
"""
from __future__ import annotations

import logging
import os
import time
from collections import defaultdict
from threading import Lock
from typing import Optional

from fastapi import HTTPException, Request, status

logger = logging.getLogger("lead_engine.rate_limit")

# defaults
PIPELINE_LIMIT = int(os.getenv("RATE_LIMIT_PIPELINE_PER_HOUR", "20"))
KEYS_LIMIT = int(os.getenv("RATE_LIMIT_KEYS_PER_HOUR", "10"))
API_LIMIT = int(os.getenv("RATE_LIMIT_API_PER_MINUTE", "120"))


class _MemoryWindow:
    def __init__(self):
        self._hits: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()

    def hit(self, key: str, limit: int, window_seconds: int) -> tuple[bool, int]:
        now = time.time()
        cutoff = now - window_seconds
        with self._lock:
            bucket = [t for t in self._hits[key] if t > cutoff]
            if len(bucket) >= limit:
                self._hits[key] = bucket
                return False, 0
            bucket.append(now)
            self._hits[key] = bucket
            return True, limit - len(bucket)


_memory = _MemoryWindow()
_REDIS = None
_REDIS_FAILED_UNTIL = 0.0


def _redis_client():
    global _REDIS, _REDIS_FAILED_UNTIL
    try:
        import redis
        url = os.getenv("REDIS_URL")
        if not url:
            return None
        now = time.monotonic()
        if now < _REDIS_FAILED_UNTIL:
            return None
        if _REDIS is not None:
            return _REDIS
        _REDIS = redis.from_url(
            url, decode_responses=True, socket_connect_timeout=0.5, socket_timeout=0.8,
            health_check_interval=30, max_connections=32,
        )
        return _REDIS
    except Exception:
        _REDIS_FAILED_UNTIL = time.monotonic() + 30
        return None


def check_rate_limit(
    identity: str,
    action: str,
    limit: int,
    window_seconds: int,
) -> None:
    """
    Raises 429 if over limit.
    identity: user_id or tenant_id or IP
    """
    key = f"rl:{action}:{identity}"

    r = _redis_client()
    if r:
        try:
            pipe = r.pipeline()
            pipe.incr(key)
            pipe.ttl(key)
            count, ttl = pipe.execute()
            if ttl == -1:
                r.expire(key, window_seconds)
            if int(count) > limit:
                raise HTTPException(
                    status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Rate limit exceeded for {action}. Try again later.",
                    headers={"Retry-After": str(max(ttl, 1))},
                )
            return
        except HTTPException:
            raise
        except Exception as e:
            logger.debug("Redis rate limit fallback to memory: %s", e)

    ok, remaining = _memory.hit(key, limit, window_seconds)
    if not ok:
        raise HTTPException(
            status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Rate limit exceeded for {action}. Try again later.",
            headers={"Retry-After": str(window_seconds)},
        )


def rate_limit_pipeline(identity: str) -> None:
    check_rate_limit(identity, "pipeline_run", PIPELINE_LIMIT, 3600)


def rate_limit_keys(identity: str) -> None:
    check_rate_limit(identity, "keys_add", KEYS_LIMIT, 3600)


def rate_limit_api(identity: str) -> None:
    check_rate_limit(identity, "api", API_LIMIT, 60)


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
