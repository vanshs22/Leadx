"""Durable outbound webhook delivery with retries and event fan-out."""
from __future__ import annotations
import asyncio
import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone
import os
import httpx
from app.memory.supabase_client import get_supabase


def _sb(): return get_supabase()

def _now(): return datetime.now(timezone.utc)


def emit(tenant_id: str, event_type: str, payload: dict, event_id: str | None = None) -> int:
    hooks = _sb().table("outbound_webhooks").select("id").eq("tenant_id",tenant_id).eq("active",True).contains("events",[event_type]).execute().data or []
    n=0
    for h in hooks:
        try:
            _sb().table("webhook_deliveries").insert({"webhook_id":h["id"],"tenant_id":tenant_id,"event_type":event_type,"event_id":event_id,"payload":payload,"status":"queued","next_attempt_at":_now().isoformat()}).execute(); n+=1
        except Exception: pass
    return n


async def deliver_due(limit: int = 100) -> dict:
    rows=_sb().table("webhook_deliveries").select("*").eq("status","queued").lte("next_attempt_at",_now().isoformat()).order("created_at").limit(limit).execute().data or []
    sent=failed=0
    for d in rows:
        hook=_sb().table("outbound_webhooks").select("*").eq("id",d["webhook_id"]).limit(1).execute().data or []
        if not hook or not hook[0].get("active"):
            _sb().table("webhook_deliveries").update({"status":"cancelled"}).eq("id",d["id"]).execute(); continue
        h=hook[0]
        body=json.dumps({"id":d["id"],"event":d["event_type"],"data":d["payload"]},separators=(",",":"),default=str)
        headers={"content-type":"application/json","x-leadx-event":d["event_type"]}
        secret=(os.getenv("WEBHOOK_SIGNING_SECRET") or "").encode()
        if secret: headers["x-leadx-signature"]=hmac.new(secret,body.encode(),hashlib.sha256).hexdigest()
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                r=await client.post(h["endpoint_url"],content=body,headers=headers)
            if 200 <= r.status_code < 300:
                _sb().table("webhook_deliveries").update({"status":"delivered","response_status":r.status_code,"response_body":r.text[:2000],"delivered_at":_now().isoformat(),"attempts":int(d.get("attempts") or 0)+1}).eq("id",d["id"]).execute(); sent+=1
            else:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
        except Exception as e:
            attempts=int(d.get("attempts") or 0)+1
            if attempts >= int(h.get("retry_limit") or 6):
                status="failed"
            else:
                status="queued"
            _sb().table("webhook_deliveries").update({"status":status,"attempts":attempts,"last_error":str(e)[:1000],"next_attempt_at":(_now()+timedelta(minutes=min(60,2**min(attempts,6)))).isoformat()}).eq("id",d["id"]).execute(); failed+=1
    return {"processed":len(rows),"sent":sent,"failed":failed}
