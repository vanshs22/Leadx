"""
Freshness re-verification pass — stops stale leads shipping as fresh.

freshness.py already knows *whether* a lead needs re-verifying and
verify.py knows *how*; nothing scheduled the sweep. A lead scored three
months ago can be closed, moved, or have a dead phone by the time it's
delivered, and the client blames the data, not the calendar.

Runs as the `leads.reverify` job. Pre-delivery use: call
reverify_before_delivery() with the assignment ids a run is about to
deliver, so the check happens at delivery time — not only at discovery.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Optional

from app.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.reverify")

# Statuses that mean "do not deliver this".
DEAD_STATUSES = ("CLOSED", "TEMPORARILY_CLOSED")


def _sb():
    return get_supabase()


async def _reverify_one(lead: dict[str, Any]) -> dict:
    from app.integrations.prod.freshness import mark_verified, reverify_lead_light

    lead_id = lead["id"]
    try:
        updated = await reverify_lead_light(lead)
    except Exception as e:
        logger.warning("reverify_lead_light failed for %s: %s", lead_id, e)
        return {"lead_id": lead_id, "ok": False, "error": str(e)[:200]}

    patch: dict[str, Any] = {}
    for col in ("business_status", "phone_e164", "phone_normalized", "website"):
        new = updated.get(col)
        if new and new != lead.get(col):
            patch[col] = new
    if updated.get("email_valid") is False:
        # Don't null the email — record the failure so scoring can
        # discount it and the client sees why the address is flagged.
        patch["raw_data"] = {**(lead.get("raw_data") or {}), "email_valid": False}

    if patch:
        patch["updated_at"] = datetime.now(timezone.utc).isoformat()
        try:
            _sb().table("leads_global").update(patch).eq("id", lead_id).execute()
        except Exception:
            logger.warning("reverify update failed for %s", lead_id, exc_info=True)

    await mark_verified(lead_id, (lead.get("verify_tier") or "A"))
    dead = (patch.get("business_status") or lead.get("business_status") or "") in DEAD_STATUSES
    return {"lead_id": lead_id, "ok": True, "changed": bool(patch), "dead": dead}


async def reverify_stale(
    tenant_id: Optional[str] = None, limit: int = 100, concurrency: int = 5
) -> dict:
    """Sweep leads whose last_verified_at is past their tier's policy."""
    from app.integrations.prod.freshness import needs_reverify

    sb = _sb()
    try:
        if tenant_id:
            ids = [
                r["lead_id"]
                for r in (
                    sb.table("lead_assignments")
                    .select("lead_id")
                    .eq("tenant_id", tenant_id)
                    .order("assigned_at", desc=True)
                    .limit(limit * 3)
                    .execute()
                    .data
                    or []
                )
            ]
            if not ids:
                return {"ok": True, "checked": 0, "reverified": 0}
            rows = (
                sb.table("leads_global")
                .select("*")
                .in_("id", ids[:300])
                .limit(limit * 3)
                .execute()
                .data
                or []
            )
        else:
            rows = (
                sb.table("leads_global")
                .select("*")
                .order("updated_at")
                .limit(limit * 3)
                .execute()
                .data
                or []
            )
    except Exception:
        logger.warning("reverify_stale fetch failed", exc_info=True)
        return {"ok": False, "error": "fetch_failed"}

    stale = [r for r in rows if needs_reverify(r, r.get("verify_tier"))][:limit]
    if not stale:
        return {"ok": True, "checked": len(rows), "reverified": 0, "dead": 0}

    sem = asyncio.Semaphore(max(1, concurrency))

    async def _guarded(lead):
        async with sem:
            return await _reverify_one(lead)

    results = await asyncio.gather(*(_guarded(l) for l in stale), return_exceptions=True)
    ok = [r for r in results if isinstance(r, dict) and r.get("ok")]
    dead = [r for r in ok if r.get("dead")]

    if dead:
        try:
            from app.integrations.prod.notifications import notify_sync

            notify_sync(
                scope="admin",
                tenant_id=tenant_id,
                kind="stale_leads_dead",
                title=f"{len(dead)} lead(s) found closed on re-verify",
                body="They were removed from delivery eligibility. Consider crediting affected clients.",
                severity="warning",
                link="/admin/leads",
            )
        except Exception:
            pass

    return {
        "ok": True,
        "checked": len(rows),
        "reverified": len(ok),
        "changed": sum(1 for r in ok if r.get("changed")),
        "dead": len(dead),
    }


async def reverify_before_delivery(assignment_ids: list[str]) -> dict:
    """Delivery-time gate: returns the assignment ids that are still
    good, and holds back any whose business is now closed."""
    if not assignment_ids:
        return {"ok": True, "keep": [], "held": []}
    sb = _sb()
    try:
        assigns = (
            sb.table("lead_assignments")
            .select("id, lead_id")
            .in_("id", assignment_ids)
            .execute()
            .data
            or []
        )
        by_lead = {a["lead_id"]: a["id"] for a in assigns if a.get("lead_id")}
        leads = (
            sb.table("leads_global").select("*").in_("id", list(by_lead)).execute().data or []
        )
    except Exception:
        logger.warning("reverify_before_delivery fetch failed", exc_info=True)
        return {"ok": True, "keep": assignment_ids, "held": []}

    from app.integrations.prod.freshness import needs_reverify

    keep, held = [], []
    for lead in leads:
        aid = by_lead.get(lead["id"])
        res = (
            await _reverify_one(lead)
            if needs_reverify(lead, lead.get("verify_tier"))
            else {"dead": (lead.get("business_status") or "") in DEAD_STATUSES}
        )
        (held if res.get("dead") else keep).append(aid)
    return {"ok": True, "keep": [a for a in keep if a], "held": [a for a in held if a]}
