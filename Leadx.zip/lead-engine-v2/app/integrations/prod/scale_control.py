"""Production-scale control plane: worker leases, queue health and atomic idempotency."""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
import os
from app.memory.supabase_client import get_supabase

def _sb(): return get_supabase()
def _now(): return datetime.now(timezone.utc).isoformat()

def worker_heartbeat(worker_id:str, *, kinds:list[str]|None=None, capacity:int=1, status:str='healthy', active_jobs:int=0)->dict:
    row={'worker_id':worker_id,'kinds':kinds or [],'capacity':max(1,capacity),'status':status,'active_jobs':max(0,active_jobs),'last_seen_at':_now(),'updated_at':_now()}
    try:return (_sb().table('worker_heartbeats').upsert(row,on_conflict='worker_id').execute().data or [row])[0]
    except Exception:return row

def scale_health()->dict:
    sb=_sb(); now=datetime.now(timezone.utc); cutoff=(now-timedelta(seconds=120)).isoformat()
    try: workers=sb.table('worker_heartbeats').select('*').gte('last_seen_at',cutoff).execute().data or []
    except Exception: workers=[]
    try: jobs=sb.table('jobs').select('status,created_at,started_at').in_('status',['queued','running','failed']).limit(5000).execute().data or []
    except Exception: jobs=[]
    counts={k:sum(1 for j in jobs if j.get('status')==k) for k in ('queued','running','failed')}
    oldest=None
    for j in jobs:
        if j.get('status')=='queued' and j.get('created_at') and (oldest is None or j['created_at']<oldest):oldest=j['created_at']
    age=0
    if oldest:
        try:age=max(0,int((now-datetime.fromisoformat(oldest.replace('Z','+00:00'))).total_seconds()))
        except Exception:pass
    return {'ok':bool(workers) and age<int(os.getenv('QUEUE_ALERT_SECONDS','900')),'workers':workers,'queue':{**counts,'oldest_queued_seconds':age},'worker_count':len(workers)}

def claim_idempotency(key:str,operation:str,*,tenant_id:str|None=None,response:dict|None=None)->tuple[bool,dict|None]:
    sb=_sb()
    try:
        r=sb.rpc('claim_operation_idempotency',{'p_key':key,'p_operation':operation,'p_tenant_id':tenant_id}).execute().data or []
        row=r[0] if isinstance(r,list) and r else r if isinstance(r,dict) else {}
        acquired=bool(row.get('acquired'))
        return acquired, row.get('existing_response')
    except Exception:
        # Safe fallback: unique constraint still prevents duplicate insertion.
        try:
            ins=sb.table('operation_idempotency').insert({'idempotency_key':key,'operation':operation,'tenant_id':tenant_id,'status':'processing','response':{}}).execute().data or []
            return bool(ins), None
        except Exception:
            existing=sb.table('operation_idempotency').select('response').eq('idempotency_key',key).eq('operation',operation).limit(1).execute().data or []
            return False, existing[0].get('response') if existing else None

def finish_idempotency(key:str,operation:str,response:dict,status:str='completed'):
    try:return _sb().rpc('finish_operation_idempotency',{'p_key':key,'p_operation':operation,'p_response':response or {},'p_status':status}).execute()
    except Exception:return _sb().table('operation_idempotency').update({'response':response or {},'status':status}).eq('idempotency_key',key).eq('operation',operation).execute()
