"""Closed-loop learning: turn outcomes into explainable tenant guidance, never blind self-modification."""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from app.memory.supabase_client import get_supabase
from app.integrations.prod.feedback import tenant_score_weights, lookalike_queries

async def learning_snapshot(tenant_id: str) -> dict:
    weights = await tenant_score_weights(tenant_id)
    queries = await lookalike_queries(tenant_id, 8)
    sb = get_supabase()
    try:
        outcomes = sb.table("lead_outcomes").select("outcome").eq("tenant_id", tenant_id).limit(2000).execute().data or []
    except Exception: outcomes = []
    won = sum(1 for x in outcomes if x.get("outcome") == "won"); lost = sum(1 for x in outcomes if x.get("outcome") == "lost")
    snapshot = {"tenant_id":tenant_id,"outcomes":len(outcomes),"won":won,"lost":lost,"win_rate_pct":round(won/(won+lost)*100,2) if won+lost else 0,"weights":weights,"lookalike_queries":queries,"model_version":"leadx-learning-v1","created_at":datetime.now(timezone.utc).isoformat()}
    try: sb.table("learning_snapshots").insert(snapshot).execute()
    except Exception: pass
    return snapshot
