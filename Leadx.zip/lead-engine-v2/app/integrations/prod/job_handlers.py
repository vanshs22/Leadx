"""
Job handlers — the actual work the worker runs.

Every long operation registers here under a `kind`. Adding a handler is
the only change needed to make a new operation queueable; the API side
just calls jobs.enqueue(kind, payload).

Handlers must be idempotent enough to survive one retry: the queue
retries on exception, and a half-finished pipeline run re-running is
better than a lost one (upserts make the overlap harmless).
"""
from __future__ import annotations

import logging
from typing import Any

from app.integrations.prod.jobs import register

logger = logging.getLogger("lead_engine.job_handlers")


@register("pipeline.run")
async def _pipeline_run(payload: dict) -> dict:
    from app.integrations.prod.pipeline import run_pipeline

    # Automation keys, not pipeline arguments. run_pipeline has a fixed keyword
    # signature (no **kwargs), so anything extra must be popped here or the job
    # TypeErrors and burns all three retries.
    payload = dict(payload)
    sequence_id = payload.pop("auto_enroll_sequence_id", None)
    schedule_id = payload.pop("schedule_id", None)

    result = await run_pipeline(**payload)
    if not isinstance(result, dict):
        return {"ok": True}

    # The automation link: discovery → outreach. Without this a scheduled run
    # just piles leads into the CRM and still waits for a human to start
    # emailing. Enrolment is best-effort — a failure here must not fail the run
    # and lose the leads that were already assigned.
    if sequence_id:
        aids = result.get("assignment_ids") or []
        if aids:
            try:
                from app.integrations.prod.sequences import enroll_leads

                enr = await enroll_leads(payload["tenant_id"], sequence_id, aids)
                result["auto_enrolled"] = enr.get("enrolled", 0)
            except Exception:
                logger.exception("auto-enroll failed for sequence %s", sequence_id)
                result["auto_enrolled"] = 0

    if schedule_id:
        try:
            from app.integrations.prod.schedules import record_result

            record_result(schedule_id, "completed", result)
        except Exception:
            logger.warning("could not record schedule result", exc_info=True)
    return result


@register("schedules.tick")
async def _schedules_tick(payload: dict) -> dict:
    from app.integrations.prod.schedules import tick

    return await tick(limit=int(payload.get("limit") or 25))


@register("pipeline.run_all_icps")
async def _pipeline_run_all(payload: dict) -> dict:
    from app.integrations.prod.pipeline import run_all_active_icps

    return await run_all_active_icps(**payload) or {"ok": True}


@register("email.bulk")
async def _email_bulk(payload: dict) -> dict:
    from app.integrations.prod.email_outreach import send_bulk

    res = await send_bulk(
        payload["tenant_id"],
        payload.get("assignment_ids") or [],
        payload.get("subject") or "",
        payload.get("body_html") or "",
        payload.get("body_text") or "",
        reply_to=payload.get("reply_to"),
    )
    try:
        from app.integrations.prod.notifications import notify_sync

        notify_sync(
            scope="tenant",
            tenant_id=payload["tenant_id"],
            kind="bulk_send_done",
            title=f"Bulk send finished — {res.get('sent', 0)} sent",
            body=f"{res.get('failed', 0)} failed, {res.get('skipped', 0)} skipped.",
            link="/leads",
        )
    except Exception:
        pass
    return res


@register("email.bulk_filtered")
async def _email_bulk_filtered(payload: dict) -> dict:
    """"Send all matching" — the recipient set is resolved inside the
    worker, so it reflects the moment of sending rather than the moment
    the button was clicked."""
    from app.integrations.prod.email_outreach import send_bulk_filtered

    res = await send_bulk_filtered(
        payload["tenant_id"],
        payload.get("subject") or "",
        payload.get("body_html") or "",
        payload.get("body_text") or "",
        tier=payload.get("tier"),
        stage=payload.get("stage"),
        limit=int(payload.get("limit") or 100),
        reply_to=payload.get("reply_to"),
    )
    try:
        from app.integrations.prod.notifications import notify_sync

        notify_sync(
            scope="tenant",
            tenant_id=payload["tenant_id"],
            kind="bulk_send_done",
            title=f"Bulk send finished — {res.get('sent', 0)} sent",
            body=f"{res.get('failed', 0)} failed, {res.get('skipped', 0)} skipped.",
            link="/leads",
        )
    except Exception:
        pass
    return res


@register("sequences.process_due")
async def _sequences_process_due(payload: dict) -> dict:
    from app.integrations.prod.sequences import process_due_sends

    return await process_due_sends(limit=int(payload.get("limit") or 200))


@register("alerts.run")
async def _alerts_run(payload: dict) -> dict:
    from app.integrations.prod.alerts import run_alert_checks

    return await run_alert_checks()


@register("csv.import")
async def _csv_import(payload: dict) -> dict:
    from app.integrations.prod.csv_import import import_rows

    return await import_rows(
        payload["tenant_id"],
        payload.get("rows") or [],
        entity=payload.get("entity") or "companies",
        created_by=payload.get("created_by") or "import",
    )


@register("leads.reverify")
async def _leads_reverify(payload: dict) -> dict:
    """Freshness pass: re-check business_status / phone / email on leads
    scored long enough ago that delivery would be shipping stale data."""
    from app.integrations.prod.reverify import reverify_stale

    return await reverify_stale(
        tenant_id=payload.get("tenant_id"),
        limit=int(payload.get("limit") or 100),
    )


@register("operator.prospect")
async def _operator_prospect(payload: dict) -> dict:
    from app.integrations.prod.operator_pipeline import run_operator_prospecting

    return await run_operator_prospecting(**payload)


@register("reviews.mine")
async def _reviews_mine(payload: dict) -> dict:
    """Review-sentiment pass over already-discovered leads — pitch
    material that list vendors don't ship."""
    from app.integrations.prod.review_mining import mine_for_tenant

    return await mine_for_tenant(
        payload.get("tenant_id"), limit=int(payload.get("limit") or 50)
    )


def registered_kinds() -> list[str]:
    from app.integrations.prod.jobs import HANDLERS

    return sorted(HANDLERS)

@register("autonomous.campaign_tick")
async def _autonomous_campaign_tick(payload: dict) -> dict:
    from app.integrations.prod.autonomous_campaigns import tick
    return await tick(limit=int(payload.get("limit") or 10))


@register("autonomous.campaign_run")
async def _autonomous_campaign_run(payload: dict) -> dict:
    from app.integrations.prod.autonomous_campaigns import run
    return await run(payload["campaign_id"])

@register("webhooks.deliver")
async def _webhooks_deliver(payload: dict) -> dict:
    from app.integrations.prod.webhooks import deliver_due
    return await deliver_due(limit=int(payload.get("limit") or 100))
