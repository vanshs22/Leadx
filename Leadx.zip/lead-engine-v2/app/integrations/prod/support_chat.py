"""LeadX support copilot + human escalation.

The bot is deliberately retrieval-first: it can only present product guidance
from the tenant-safe FAQ knowledge base. When confidence is insufficient, the
conversation is escalated to an operator instead of inventing an answer.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

from app.memory.supabase_client import get_supabase


def _sb():
    return get_supabase()


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", (s or "").lower()).strip()


def _tokens(s: str) -> set[str]:
    return {x for x in _norm(s).split() if len(x) > 2}


def _rank(message: str, rows: list[dict]) -> list[tuple[int, dict]]:
    mt = _tokens(message)
    ranked: list[tuple[int, dict]] = []
    for row in rows:
        hay = " ".join([
            str(row.get("question") or ""),
            str(row.get("answer") or ""),
            " ".join(row.get("keywords") or []),
            str(row.get("category") or ""),
        ])
        rt = _tokens(hay)
        score = len(mt & rt)
        if _norm(message) in _norm(row.get("question") or ""):
            score += 6
        ranked.append((score, row))
    return sorted(ranked, key=lambda x: x[0], reverse=True)


def search_faq(message: str, limit: int = 4) -> list[dict]:
    rows = _sb().table("support_faq").select(
        "id,category,question,answer,keywords,priority"
    ).eq("active", True).order("priority", desc=True).limit(500).execute().data or []
    return [r for score, r in _rank(message, rows)[:limit] if score > 0]


def _needs_escalation(message: str, matches: list[dict]) -> bool:
    if not matches:
        return True
    ranked = _rank(message, matches)
    if not ranked:
        return True
    # At least two meaningful shared tokens or an exact-ish question match.
    return ranked[0][0] < 2


async def answer_customer(*, conversation_id: str, tenant_id: str, user_id: str, message: str) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    sb = _sb()
    sb.table("support_messages").insert({
        "conversation_id": conversation_id,
        "sender_type": "user",
        "sender_id": user_id,
        "body": message.strip(),
        "created_at": now,
    }).execute()

    matches = search_faq(message)
    escalate = _needs_escalation(message, matches)

    if escalate:
        answer = (
            "I’m not confident I can answer that from the LeadX help knowledge base. "
            "I’ve sent this conversation to the LeadX support team so an admin can respond here."
        )
        status = "escalated"
        source_ids: list[str] = []
    else:
        # Keep the default path deterministic and grounded. If an LLM is configured,
        # it may rewrite the grounded answer but cannot add unsupported product claims.
        best = matches[0]
        answer = best["answer"]
        status = "bot"
        source_ids = [str(x["id"]) for x in matches]
        try:
            from app.integrations.prod.llm_copy import complete
            context = "\n\n".join(
                f"FAQ {i+1}: {x['question']}\nAnswer: {x['answer']}"
                for i, x in enumerate(matches)
            )
            prompt = (
                "Answer the customer using ONLY the FAQ answers below. Do not invent features, "
                "limits, pricing, policies, or implementation details. If the FAQ does not support "
                "the answer, respond exactly ESCALATE. Keep it concise and helpful.\n\n"
                f"Customer question: {message}\n\n{context}"
            )
            llm = await complete(prompt)
            if llm.get("ok") and llm.get("text") and llm["text"].strip().upper() != "ESCALATE":
                answer = llm["text"].strip()
        except Exception:
            pass

    sb.table("support_messages").insert({
        "conversation_id": conversation_id,
        "sender_type": "bot",
        "sender_id": None,
        "body": answer,
        "metadata": {"faq_ids": source_ids, "escalated": escalate},
        "created_at": now,
    }).execute()
    sb.table("support_conversations").update({
        "status": status,
        "needs_human": escalate,
        "last_message_at": now,
        "updated_at": now,
    }).eq("id", conversation_id).eq("tenant_id", tenant_id).execute()
    return {"answer": answer, "escalated": escalate, "faq_ids": source_ids}


def conversation_messages(conversation_id: str, tenant_id: str | None = None) -> list[dict]:
    q = _sb().table("support_messages").select("*").eq("conversation_id", conversation_id)
    rows = q.order("created_at").execute().data or []
    if tenant_id:
        c = _sb().table("support_conversations").select("id").eq("id", conversation_id).eq("tenant_id", tenant_id).limit(1).execute().data or []
        if not c:
            return []
    return rows
