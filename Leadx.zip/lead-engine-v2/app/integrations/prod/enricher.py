"""
Production Enricher cascade:
  1. Scrapling (primary, anti-bot)
  2. Crawl4AI (markdown, parallel)
  3. Firecrawl (last resort, key-pooled)
  4. Structured extraction (regex + optional ScrapeGraphAI)
"""
from __future__ import annotations

import asyncio
import logging
import re
from typing import Optional
from urllib.parse import urljoin, urlparse

from app.integrations.prod.key_pool import with_key_rotation, KeyPoolExhausted
from app.integrations.prod.utils import (
    extract_emails, extract_phones, is_valid_email, normalize_phone, extract_domain,
)

logger = logging.getLogger("lead_engine.enricher")

BOOKING_PLATFORMS = [
    ("mindbody", "Mindbody"), ("vagaro", "Vagaro"), ("fresha", "Fresha"),
    ("booksy", "Booksy"), ("acuityscheduling", "Acuity"), ("calendly", "Calendly"),
    ("cal.com", "Cal.com"), ("square.site", "Square"), ("squareup", "Square"),
    ("zenoti", "Zenoti"), ("boulevard", "Boulevard"), ("booker", "Booker"),
    ("glofox", "Glofox"), ("schedulicity", "Schedulicity"), ("setmore", "Setmore"),
    ("simplybook", "SimplyBook"), ("styleseat", "StyleSeat"), ("treatwell", "Treatwell"),
]

INSTAGRAM_RE = re.compile(r"instagram\.com/([a-zA-Z0-9._]+)")
FACEBOOK_RE = re.compile(r"facebook\.com/([a-zA-Z0-9.]+)")
LINKEDIN_RE = re.compile(r"linkedin\.com/company/([a-zA-Z0-9\-]+)")

CONTACT_PATHS = (
    "/contact", "/contact-us", "/about", "/about-us", "/team", "/staff",
    "/our-team", "/meet-the-team", "/services", "/locations", "/book", "/booking",
    "/appointments", "/get-started",
)
SECONDARY_HINTS = re.compile(r"(contact|about|team|staff|owner|founder|manager|service|location|book|appointment|career)", re.I)


def _detect_booking(html: str) -> tuple[bool, Optional[str]]:
    lower = (html or "").lower()
    for kw, name in BOOKING_PLATFORMS:
        if kw in lower:
            return True, name
    return False, None


def _extract_social(html: str) -> dict:
    social = {}
    ig = INSTAGRAM_RE.search(html or "")
    if ig and ig.group(1) not in ("p", "reel", "stories", "explore", "accounts"):
        social["instagram"] = ig.group(1)
    fb = FACEBOOK_RE.search(html or "")
    if fb:
        social["facebook"] = fb.group(1)
    li = LINKEDIN_RE.search(html or "")
    if li:
        social["linkedin"] = li.group(1)
    return social


# ---------------------------------------------------------------------------
# Fetch layers
# ---------------------------------------------------------------------------
async def fetch_scrapling(url: str, timeout: int = 20) -> dict:
    out = {"html": "", "text": "", "method": "scrapling", "ok": False, "error": None}
    try:
        from scrapling import AsyncFetcher
        fetcher = AsyncFetcher(auto_match=False)
        page = await fetcher.get(url, timeout=timeout)
        html = str(getattr(page, "html", "") or "")
        text = ""
        if hasattr(page, "get_all_text"):
            try:
                text = page.get_all_text(separator=" ") or ""
            except Exception:
                text = html
        out.update(html=html, text=text or html, ok=bool(html))
    except ImportError:
        try:
            import httpx
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                r = await client.get(url, headers={"User-Agent": "Mozilla/5.0 (compatible; LeadBot/2.0)"})
                out.update(html=r.text, text=r.text, ok=True, method="httpx")
        except Exception as e:
            out["error"] = str(e)
    except Exception as e:
        out["error"] = str(e)
        logger.debug("scrapling fail %s: %s", url, e)
    return out


async def fetch_crawl4ai(url: str) -> dict:
    out = {"markdown": "", "method": "crawl4ai", "ok": False, "error": None}
    try:
        from crawl4ai import AsyncWebCrawler
        async with AsyncWebCrawler(verbose=False) as crawler:
            res = await crawler.arun(url=url)
            md = getattr(res, "markdown", None) or getattr(res, "cleaned_html", "") or ""
            out.update(markdown=str(md)[:20000], ok=bool(md))
    except Exception as e:
        out["error"] = str(e)
        logger.debug("crawl4ai fail %s: %s", url, e)
    return out


async def fetch_firecrawl(url: str) -> dict:
    out = {"html": "", "markdown": "", "method": "firecrawl", "ok": False, "error": None}

    async def _call(api_key: str):
        import httpx
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                "https://api.firecrawl.dev/v1/scrape",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"url": url, "formats": ["markdown", "html"]},
            )
            if resp.status_code in (402, 429):
                raise Exception(f"Firecrawl quota: {resp.status_code}")
            resp.raise_for_status()
            data = resp.json().get("data") or {}
            return data.get("html") or "", data.get("markdown") or ""

    try:
        html, md = await with_key_rotation("firecrawl", _call)
        out.update(html=html, markdown=md, ok=bool(html or md))
    except (KeyPoolExhausted, Exception) as e:
        out["error"] = str(e)
        logger.debug("firecrawl fail %s: %s", url, e)
    return out


def _parse_content(content: str) -> dict:
    emails = extract_emails(content)
    phones = extract_phones(content)
    has_booking, platform = _detect_booking(content)
    social = _extract_social(content)
    return {
        "emails": emails,
        "email": emails[0] if emails else None,
        "email_valid": is_valid_email(emails[0]) if emails else None,
        "phone_from_web": phones[0] if phones else None,
        "has_booking": has_booking,
        "booking_platform": platform,
        "social_links": social,
        "services": [],  # filled by optional LLM/ScrapeGraphAI
        "owner_name": None,
    }


def _same_domain(url: str, base: str) -> bool:
    try:
        return urlparse(url).netloc.lower().replace('www.', '') == urlparse(base).netloc.lower().replace('www.', '')
    except Exception:
        return False


def _secondary_urls(base_url: str, html: str) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()
    limit = int(__import__('os').getenv('ENRICH_SECONDARY_PAGES', '12'))
    def add(url: str) -> None:
        if len(found) >= limit or not url.startswith(('http://', 'https://')) or not _same_domain(url, base_url):
            return
        clean = url.split('#', 1)[0].rstrip('/')
        if clean == base_url.rstrip('/') or clean in seen:
            return
        seen.add(clean); found.append(clean)
    for path in CONTACT_PATHS:
        add(urljoin(base_url.rstrip('/') + '/', path.lstrip('/')))
    for href in re.findall(r"(?:href|data-href)\s*=\s*[\"']([^\"']+)[\"']", html or '', re.I):
        if SECONDARY_HINTS.search(href):
            add(urljoin(base_url, href))
    return found


async def _fetch_secondary_pages(base_url: str, html: str) -> tuple[str, list[str]]:
    urls = _secondary_urls(base_url, html)
    if not urls:
        return '', []
    sem = asyncio.Semaphore(4)
    async def one(url: str):
        async with sem:
            page = await fetch_scrapling(url, timeout=12)
            return url, (page.get('html') or page.get('text') or '') if page.get('ok') else ''
    rows = await asyncio.gather(*(one(u) for u in urls), return_exceptions=True)
    chunks, used = [], []
    for row in rows:
        if isinstance(row, Exception):
            continue
        url, content = row
        if content:
            chunks.append(content[:12000]); used.append(url)
    return '\n'.join(chunks), used


async def _serper_contact_fallback(name: str, city: Optional[str], domain: Optional[str]) -> dict:
    if not name:
        return {}
    try:
        from app.integrations.prod.key_pool import with_key_rotation
        import httpx
        loc = f' {city}' if city else ''
        queries = []
        if domain:
            queries += [f'site:{domain} (contact OR email OR owner OR founder OR manager)', f'site:{domain} (team OR staff OR about)']
        queries += [f'"{name}"{loc} owner founder manager', f'"{name}"{loc} email contact', f'"{name}"{loc} site:linkedin.com/in']
        emails, owners, social = [], [], {}
        for q in queries[:5]:
            async def call(key: str):
                async with httpx.AsyncClient(timeout=20) as client:
                    r = await client.post('https://google.serper.dev/search', headers={'X-API-KEY': key, 'Content-Type': 'application/json'}, json={'q': q, 'num': 10})
                    r.raise_for_status(); return (r.json() or {}).get('organic') or []
            rows = await with_key_rotation('serper', call)
            for item in rows:
                blob = ' '.join(str(item.get(k) or '') for k in ('title','snippet','link'))
                for email in extract_emails(blob):
                    if email not in emails: emails.append(email)
                link = item.get('link') or ''
                if 'linkedin.com/in/' in link and len(owners) < 5:
                    title = item.get('title') or ''
                    owners.append({'name': title.split('-')[0].split('|')[0].strip()[:120], 'title': title[:200], 'linkedin_url': link.split('?')[0]})
                if 'instagram.com/' in link and 'instagram' not in social: social['instagram'] = link.split('?')[0]
                if 'facebook.com/' in link and 'facebook' not in social: social['facebook'] = link.split('?')[0]
        return {'emails': emails[:10], 'decision_makers': owners[:5], 'social_links': social}
    except Exception as e:
        logger.debug('Serper contact fallback failed for %s: %s', name, e)
        return {}


async def _try_contact_pages(base_url: str, already_emails: list) -> dict:
    if already_emails:
        return {}
    combined, used = await _fetch_secondary_pages(base_url, '')
    if not combined:
        return {}
    parsed = _parse_content(combined)
    parsed['secondary_pages'] = used
    return parsed


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
async def enrich_one(website: str, use_crawl4ai: bool = True, use_firecrawl: bool = True, company_name: Optional[str] = None, city: Optional[str] = None) -> dict:
    """
    Full enrichment cascade for one URL.
    Returns dict ready for enrichment table upsert.
    """
    empty = {
        "website": website,
        "email": None, "email_valid": None, "emails": [],
        "phone_from_web": None, "has_booking": False, "booking_platform": None,
        "services": [], "social_links": {}, "owner_name": None,
        "markdown_summary": None, "raw_extraction": {},
        "enrichment_method": None, "enrichment_ok": False, "error": None,
    }
    if not website or not str(website).startswith("http"):
        empty["error"] = "invalid_url"
        return empty

    # 1. Scrapling primary
    scrap = await fetch_scrapling(website)
    html = scrap.get("html") or ""
    text = scrap.get("text") or ""
    method = scrap.get("method") or "scrapling"

    # 2. Crawl4AI parallel (best-effort)
    md = ""
    if use_crawl4ai:
        try:
            c4 = await asyncio.wait_for(fetch_crawl4ai(website), timeout=35)
            md = c4.get("markdown") or ""
        except Exception as e:
            logger.debug("crawl4ai timeout/fail: %s", e)

    content = md or html or text

    # 3. Firecrawl last resort
    if not content and use_firecrawl:
        fc = await fetch_firecrawl(website)
        content = fc.get("markdown") or fc.get("html") or ""
        method = "firecrawl"
        if fc.get("markdown"):
            md = fc["markdown"]

    if not content:
        empty["error"] = scrap.get("error") or "all_fetchers_failed"
        return empty

    parsed = _parse_content(content)

    # Crawl high-value internal pages (contact/about/team/services/locations) so
    # enrichment is domain-deep instead of homepage-only.
    try:
        secondary_html, secondary_urls = await _fetch_secondary_pages(website, html or content)
        if secondary_html:
            secondary = _parse_content(secondary_html)
            parsed['emails'] = list(dict.fromkeys((parsed.get('emails') or []) + (secondary.get('emails') or [])))[:20]
            parsed['email'] = parsed['emails'][0] if parsed['emails'] else parsed.get('email')
            parsed['email_valid'] = is_valid_email(parsed['email']) if parsed.get('email') else None
            parsed['phone_from_web'] = parsed.get('phone_from_web') or secondary.get('phone_from_web')
            parsed['has_booking'] = parsed.get('has_booking') or secondary.get('has_booking')
            parsed['booking_platform'] = parsed.get('booking_platform') or secondary.get('booking_platform')
            parsed['social_links'] = {**(parsed.get('social_links') or {}), **(secondary.get('social_links') or {})}
            parsed['secondary_pages'] = secondary_urls
    except Exception as e:
        logger.debug('secondary enrichment crawl failed: %s', e)

    # Contact page follow-up if no email
    if not parsed.get("emails"):
        extra = await _try_contact_pages(website, parsed.get("emails") or [])
        if extra.get("emails"):
            parsed.update({k: v for k, v in extra.items() if v})
            method = f"{method}+contact"

    # Public-search waterfall for missing contact/decision-maker fields. Uses only
    # indexed public results and can be disabled to conserve Serper quota.
    if __import__('os').getenv('ENRICH_SEARCH_FALLBACK', '1') == '1' and (not parsed.get('email') or not parsed.get('owner_name')):
        try:
            host = urlparse(website).netloc
            brand = (company_name or '').strip() or host.split('.')[0].replace('-', ' ')
            fallback = await _serper_contact_fallback(brand, city, host)
            if fallback.get('emails'):
                parsed['emails'] = list(dict.fromkeys((parsed.get('emails') or []) + fallback['emails']))[:20]
                parsed['email'] = parsed['emails'][0]
                parsed['email_valid'] = is_valid_email(parsed['email'])
            if fallback.get('decision_makers'):
                parsed['decision_makers'] = fallback['decision_makers']
                if not parsed.get('owner_name'):
                    parsed['owner_name'] = fallback['decision_makers'][0].get('name')
            parsed['social_links'] = {**(parsed.get('social_links') or {}), **(fallback.get('social_links') or {})}
        except Exception:
            pass

    ok = bool(
        parsed.get("email")
        or parsed.get("has_booking")
        or parsed.get("services")
        or parsed.get("phone_from_web")
        or parsed.get("social_links")
    )

    return {
        "website": website,
        "email": parsed.get("email"),
        "email_valid": parsed.get("email_valid"),
        "emails": parsed.get("emails") or [],
        "phone_from_web": parsed.get("phone_from_web"),
        "has_booking": parsed.get("has_booking") or False,
        "booking_platform": parsed.get("booking_platform"),
        "services": parsed.get("services") or [],
        "social_links": parsed.get("social_links") or {},
        "owner_name": parsed.get("owner_name"),
        "decision_makers": parsed.get("decision_makers") or [],
        "markdown_summary": (md or "")[:4000] or None,
        "raw_extraction": parsed,
        "enrichment_method": method,
        "enrichment_ok": ok,
        "error": None if ok else "sparse_extraction",
    }



async def _resolve_website(name: str, city: Optional[str] = None) -> Optional[str]:
    """Find official website for a business name via Serper (social-origin leads)."""
    if not name or len(name) < 2:
        return None
    q = f"{name} official website"
    if city:
        q = f"{name} {city} official website"
    try:
        from app.integrations.prod.key_pool import with_key_rotation, KeyPoolExhausted

        async def _call(api_key: str):
            async with httpx.AsyncClient(timeout=15) as client:
                r = await client.post(
                    "https://google.serper.dev/search",
                    headers={"X-API-KEY": api_key, "Content-Type": "application/json"},
                    json={"q": q, "num": 5},
                )
                r.raise_for_status()
                return (r.json() or {}).get("organic") or []

        results = await with_key_rotation("serper", _call)
    except Exception:
        return None
    skip = ("linkedin.com", "instagram.com", "facebook.com", "yelp.com", "yellowpages", "wikipedia")
    for item in results or []:
        link = item.get("link") or ""
        if not link.startswith("http"):
            continue
        if any(s in link.lower() for s in skip):
            continue
        return link.split("?")[0]
    return None


async def enrich_batch(
    leads: list[dict],
    max_concurrent: int = 6,
    use_crawl4ai: bool = True,
    use_firecrawl: bool = True,
) -> list[dict]:
    sem = asyncio.Semaphore(max_concurrent)

    async def _one(lead: dict) -> dict:
        url = lead.get("website")
        # Social-discovered leads often lack website — resolve via Serper
        if not url and lead.get("name"):
            try:
                url = await _resolve_website(lead.get("name"), lead.get("city"))
                if url:
                    lead["website"] = url
                    lead["website_domain"] = extract_domain(url)
            except Exception:
                pass
        if not url:
            # Still mark partial OK if we already have LinkedIn/IG decision maker
            if lead.get("linkedin_url") or lead.get("instagram_handle") or lead.get("owner_name"):
                lead["enrichment_ok"] = True
                lead["enrichment_method"] = lead.get("source") or "social_only"
            else:
                lead["enrichment_ok"] = False
            return lead
        async with sem:
            try:
                info = await enrich_one(url, use_crawl4ai=use_crawl4ai, use_firecrawl=use_firecrawl, company_name=lead.get("name") or lead.get("company_name"), city=lead.get("city"))
            except Exception as e:
                logger.exception("enrich_one crashed for %s", url)
                lead["enrichment_ok"] = False
                lead["enrichment_error"] = str(e)
                return lead

            if info.get("enrichment_ok"):
                lead["email"] = info.get("email") or lead.get("email")
                lead["email_valid"] = info.get("email_valid")
                lead["emails"] = info.get("emails") or []
                if info.get("phone_from_web") and not lead.get("phone_normalized"):
                    lead["phone"] = info["phone_from_web"]
                    lead["phone_normalized"] = normalize_phone(info["phone_from_web"])
                lead["has_booking"] = info.get("has_booking", False)
                lead["booking_platform"] = info.get("booking_platform")
                lead["services"] = info.get("services") or []
                lead["social_links"] = info.get("social_links") or {}
                lead["owner_name"] = info.get("owner_name") or lead.get("owner_name")
                lead["decision_makers"] = info.get("decision_makers") or lead.get("decision_makers") or []
                lead["markdown_summary"] = info.get("markdown_summary")
                lead["enrichment_method"] = info.get("enrichment_method")
                lead["enrichment_ok"] = True
                lead["raw_extraction"] = info.get("raw_extraction") or {}
            else:
                lead["enrichment_ok"] = False
                lead["enrichment_error"] = info.get("error")
            return lead

    results = await asyncio.gather(*[_one(l) for l in leads], return_exceptions=False)
    ok_n = sum(1 for l in results if l.get("enrichment_ok"))
    logger.info("enrich_batch done: %s/%s ok", ok_n, len(results))
    return results
