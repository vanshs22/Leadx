# CRM Runtime Route Fix — 2026-09-29

## Symptoms
- Clicking a client lead showed “CRM API route is not available on the active backend”.
- Pipeline drag/drop could report a missing route even though the current source contains the CRM routes.

## Fixes
1. Added protected runtime fallbacks for individual lead detail and stage-move routes if the main CRM router fails to mount those routes.
2. Updated the browser API client to fail over from the same-origin `/backend` proxy to the Codespaces forwarded `:8000` API for definitive 404/405 responses on writes. This prevents a stale Next proxy from breaking pipeline drag/drop.
3. Existing tenant authentication remains mandatory on all fallbacks; URL tenant IDs are checked against the verified membership context.

## Required deployment action
Restart/redeploy the FastAPI service from this package so the runtime route fallbacks and current CRM routes are actually loaded. If using Codespaces, run the API on `0.0.0.0:8000` and the portal on `0.0.0.0:3000`.
