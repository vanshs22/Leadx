# LeadX SQL Migration Fix — 2026-09-27

## Fixed Supabase error

The all-in-one migration could fail on:

`ERROR: 42703: column "resource_type" does not exist`

Cause: older LeadX/HARDENING installations can already contain an `audit_log` table using the legacy columns `actor`, `target_type`, `target_id`, and `meta`. PostgreSQL `CREATE TABLE IF NOT EXISTS` does not change the shape of an existing table, so the 3.0 migration then tried to create an index on the new `resource_type/resource_id` columns before adding them.

## Repair

The migration now performs idempotent `ALTER TABLE ... ADD COLUMN IF NOT EXISTS` repairs for the 3.0 audit columns before creating the indexes. The repair is safe for both fresh and existing databases and preserves legacy audit columns/data.

The standalone `HARDENING.sql` was also made compatible.

The legacy audit writer was updated to write the 3.0 audit schema and retains a fallback for older installations.

## Files updated

- `sql/000_ALL_IN_ONE_migration.sql`
- `sql/038_LEADX_3_0_CORE.sql`
- `SUPABASE_FULL_MIGRATION.sql`
- `HARDENING.sql`
- `app/integrations/prod/audit_log.py`

## Verification

- Python compilation: PASS
- Backend tests: 52/52 PASS
- SQL migration is ordered so audit compatibility repair occurs before the affected index creation.
