# Frontend runtime fix — 2026-09-27

## Fixed
The admin overview page called `admin.cronAudit()` even though `cronAudit()` is exported by `adminExtras` in `frontend/lib/admin.ts`.

This caused the Next.js runtime error:

`TypeError: _lib_admin_WEBPACK_IMPORTED_MODULE_3__.admin.cronAudit is not a function`

The call is now:

`adminExtras.cronAudit()`

## Verification
- Backend Python compilation: PASS
- Backend pytest: 52/52 PASS
- Static frontend admin/adminExtras method-reference audit: PASS
- No missing admin/adminExtras method references detected

Frontend dependencies are intentionally not bundled in the release ZIP; run `npm ci` in `lead-crm-portal/frontend` before `npm run dev` or `npm run build`.


Additional hardening: `cronAudit()` is now exposed on both `admin` and `adminExtras` as a compatibility alias; the admin overview uses `admin.cronAudit()`. Frontend release caches (`.next` and `tsconfig.tsbuildinfo`) are excluded, and `npm run clean` removes them before dev/build.
