# Systemize pass — security, realtime, enrichment, UI (2026-09-29)

Scope: additive hardening. No routes, tables or response shapes were removed.

## Security (backend)
| Issue found | Fix |
|---|---|
| **SSRF**: enrichment fetched any lead website incl. `localhost`, private ranges, cloud metadata, and followed redirects blindly | New `integrations/prod/net_safety.py`. Every hop is validated public-only (scheme, creds, DNS-resolved IPs, IPv4-mapped IPv6, decimal/hex IP tricks). Wired into Scrapling, httpx fallback, Crawl4AI, Firecrawl |
| Outbound webhooks / delivery webhooks posted to any tenant-set URL | Same guard, redirects disabled |
| SNS `SubscribeURL` fetched from an unauthenticated body | Must be `https://sns.<region>.amazonaws.com` |
| SES/SNS webhooks **failed open** when `WEBHOOK_SECRET` unset; non-constant-time compare | Fail-closed (503) in production, `hmac.compare_digest` |
| CORS fell back to `*` in production when `CORS_ORIGINS` empty | No wildcard in production; explicit methods/headers |
| `X-Forwarded-For` trusted blindly → rate-limit bypass | Only honoured with `TRUST_PROXY_HEADERS=1` (uses trusted hop depth) |
| In-memory rate limiter grew unbounded | Periodic purge |
| Client-supplied `x-request-id` reflected unvalidated | Sanitised (`[A-Za-z0-9._-]{8,64}`) |
| API responses cacheable | `Cache-Control: no-store`, CORP header |
| Container ran as root | Runs as unprivileged `leadx` user |

## Security (frontend)
CSP no longer allows browser calls to OpenAI/Resend; COOP + DNS-prefetch headers; `upgrade-insecure-requests` only in production (dev on http keeps working); signing out of admin also clears any legacy persisted admin key.

## Realtime (no refresh needed)
* Supabase `postgres_changes` remains the push channel (unchanged).
* **Removed the admin `window.location.reload()`**. `AdminLiveRefresh` now soft-refreshes the current screen in place and waits while you are typing.
* All pollers (`setInterval`) are now visibility-aware via `lib/live.ts`: zero traffic in background tabs, instant refresh on return.
* Notification bell updates instantly on `notifications` table changes; poll is only a 90s safety net.

## Discovery / enrichment
* `contact_quality.py`: candidate emails are ranked (own-domain, personal, owner-name match up; no-reply/abuse/freemail down), primary email is the best one, and `raw_extraction.contact_confidence` (0–100) is emitted. Never blocks enrichment if it errors.

## UI
Additive polish layer at the end of `globals.css`: page-enter motion, focus rings, sticky table headers, KPI accent, `row-flash` and `live-dot` for realtime feedback, reduced-motion support. Existing classes/layout untouched.

## Verify
```bash
cd lead-engine-v2 && pip install -r requirements.txt pytest && pytest -q
cd ../lead-crm-portal/frontend && npm i && npm run build
```
New tests: `tests/test_net_safety.py`, `tests/test_contact_quality.py`.

## Production checklist
`ENVIRONMENT=production`, strong `LEAD_ENGINE_SERVICE_KEY`, `CORS_ORIGINS`, `WEBHOOK_SECRET`, `REDIS_URL`; keep `TRUST_PROXY_HEADERS=1` only behind your proxy. Also block egress to `169.254.169.254` at the network level (defence in depth vs DNS rebinding).
