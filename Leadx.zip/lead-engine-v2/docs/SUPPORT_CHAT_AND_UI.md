# LeadX Support Copilot + Product UI

## Client experience
Every authenticated client portal page exposes a floating **LeadX Help** control. It opens a compact support workspace with FAQ suggestions, conversation history and human escalation. The user can ask product questions without leaving their workflow.

The copilot is retrieval-first. It searches the versioned `support_faq` knowledge base and may rewrite grounded answers with the configured AI provider. If confidence is insufficient, it explicitly escalates instead of inventing product behavior.

## Human escalation
Escalated conversations are stored in `support_conversations` and `support_messages`. The operator uses **Admin → Support inbox** to see the tenant, user email, status, conversation history, reply directly, and resolve/reopen the thread.

The client chat polls for new messages so an admin reply appears without a page refresh.

## FAQ coverage
The seed knowledge base covers onboarding, discovery, statewide discovery, approvals, monthly quotas, lead quality, enrichment, CRM, sequences, email, replies, opt-out, reports, billing, teams, security, imports, autonomous admin campaigns, AI copy, global inventory and support.

Add/edit knowledge through the database or a future FAQ editor. Keep answers factual and product-specific.

## UI shell
Client and admin shells now include:
- sticky utility bars
- stronger card hierarchy
- quick actions
- workspace/system status
- support access from every page
- dedicated admin support control room
- responsive layouts and existing dark/light support
