# LeadX Batch 1 + Batch 2 Upgrade — 2026-09-29

## Batch 1 — Security / isolation

- Added production HTTP security headers to FastAPI: `nosniff`, clickjacking protection, strict referrer policy, permissions policy and HSTS in production/staging.
- Added tenant-aware general API rate limiting on CRM/lead HTTP surfaces with Redis-backed shared limiting and in-process fallback.
- Reworked Redis client creation into a pooled/reused client instead of opening a new connection per request.
- Added frontend security headers/CSP and disabled the Next.js `X-Powered-By` header.
- Frontend build config now reads only the two public Supabase values from the backend `.env` fallback; backend service secrets are not loaded wholesale by Next.
- Browser session snapshots are now scoped by both tenant and user, preventing stale dashboard/leads/pipeline snapshots from crossing accounts after logout/login.
- Hardened the CRM denormalized view so `anon`/`authenticated` cannot query it directly; the intended browser path is the authenticated FastAPI API. Added `FORCE ROW LEVEL SECURITY` for tenant tables.

## Batch 2 — Performance / data pipeline / UX

- Added optional Redis shared JSON cache for CRM dashboard, leads and pipeline snapshots. The existing local cache remains as a fallback.
- Cache invalidation now clears both local and shared caches after CRM mutations.
- Supabase realtime events invalidate the browser API cache before refreshing, preventing a realtime event from returning an old 10-second cached snapshot.
- Browser GET cache uses the authenticated user ID rather than token suffixes as its cache namespace.
- Added hot-path database indexes for assignments, stages, activities, tasks, tenant-seen fingerprints and enrichment timestamps.
- Added a pre-enrichment entity-resolution/dedupe boundary. Duplicate/global-inventory records are collapsed before Scrapling/Crawl4AI/Firecrawl work.
- Added fresh enrichment reuse (default 14 days). Fresh successful enrichment is reused; stale/failed records are re-enriched. This reduces scraping/API spend without sacrificing refreshes for stale records.
- Exhaustive discovery now actually executes the LinkedIn, Instagram, web, Yelp and Facebook lanes in addition to Maps/Google Places/OSM/Foursquare. Previously the exhaustive orchestrator accepted those flags but only executed Maps + selected location sources + one web lane.
- Configured Google Places/Foursquare are automatically enabled when their API keys exist; no second feature flag is required.
- If the bounded multi-source orchestrator itself fails, the fallback is now another multi-source/exhaustive path rather than silently degrading to Maps-only.
- Pipeline run summaries now include source coverage counts.
- Pipeline UI received a safer drag/drop interaction: explicit drop-target highlighting, optimistic movement, persistence confirmation, rollback on failure, loading skeletons, and clearer status states.
- Removed a duplicate Revenue Health/SLA dashboard section and tightened the visual card hierarchy.
- Added restrained skeleton/shimmer and card-hover primitives.

## Important runtime settings

- `REDIS_URL=redis://redis:6379/0` enables shared cache/rate-limit state in the included Docker Compose stack. Redis remains optional.
- `ENRICHMENT_REUSE_DAYS=14` controls fresh-enrichment reuse.
- `GOOGLE_PLACES_API_KEY` and/or `FOURSQUARE_API_KEY` automatically activate those discovery lanes.
- `ENABLE_GOOGLE_PLACES=1` / `ENABLE_FOURSQUARE=1` remain supported as explicit overrides.

## Verification

- Backend test suite: **63 passed**.
- Python compile check: **passed**.
- `next.config.js` syntax check: **passed**.
- Full Next.js production build could not be completed in the sandbox because the npm dependency install timed out and the environment has no cached copy of one required package. No application build error was observed; the remaining check should be `npm ci && npm run build` in the deployment environment.

## SQL migrations

Apply:

1. `sql/044_SECURITY_HARDENING_2026-09-29.sql`
2. `sql/045_PERFORMANCE_INDEXES_2026-09-29.sql`

These migrations are idempotent/non-destructive.

## Batch 3 — Streaming target execution (2026-09-29)

Target runs are now streaming instead of `discover -> enrich everything -> gate -> assign`.

- `target_new_leads > 0` is a hard assignment target. Example: `50` means stop when 50 assignments are confirmed (subject to tenant quota and available qualified leads).
- Discovery, enrichment, scoring/gating, and assignment overlap through bounded async queues.
- Each discovered lead is persisted/deduplicated and queued for enrichment immediately.
- Enrichment workers run concurrently (`TARGET_ENRICH_WORKERS`, defaulting from `max_enrich_concurrent`).
- Assignment workers run concurrently (`TARGET_ASSIGN_WORKERS`, default `4`) with slot reservation so successful assignments can never exceed the requested target.
- Once the target is reached, discovery stops, queued work is drained/cancelled without starting additional enrichment, and the assigned set is delivered to the client.
- If discovery is exhausted before the target is reached, the run finishes partial/failed rather than continuing indefinitely.
- `target_new_leads == 0` remains the non-target/exhaustive path, so `0` means no assignment target/early-stop target.
- Optional tuning: `TARGET_DISCOVERY_MULTIPLIER` (default `2`) controls the candidate buffer relative to remaining assignment slots.
