# LeadX final runtime fix — 2026-09-28

## Fixed
- Dashboard no longer trusts an all-zero snapshot when the tenant has actual assignments; it falls back to authoritative CRM data.
- Dashboard snapshot SQL now reads the `crm_lead_cards` source used by the client CRM.
- Leads fallback no longer requests the legacy/nonexistent `stage` column; it uses `stage_slug`/`stage_id`.
- Pipeline fallback is bounded, tenant-scoped, and can reconstruct cards from `lead_assignments` + `leads_global` when the CRM view is unavailable.
- Runtime CRM route safety net remains active for Dashboard, Leads, and Pipeline.
- `/health` now exposes the live CRM route contract and backend version `3.0.1`.
- Help has a stateless `/support/ask` fallback. A simple greeting never depends on FAQ/database/LLM availability.
- Help persistence/provider failures no longer turn a valid answer into an opaque server error.
- Leads and Pipeline persist their latest default dataset in tab-scoped session cache and refresh in the background.
- API GET memory cache increased to 30 seconds; in-flight request deduplication remains.
- Codespaces API routing now retries a 404 across the forwarded backend target before reporting a missing route.

## Validation
- Python compilation: PASS.
- Full backend pytest suite: PASS.
- Frontend dependency installation/build was not completed in the packaging environment because registry installation timed out; no frontend build pass is claimed.

## Deployment
Run `../leadx-runtime-fix-2026-09-28.sh` from the extracted package (or run the commands in it). It deliberately stops stale Uvicorn/Next processes, starts the packaged source, and refuses to proceed if the live CRM route contract is missing.
