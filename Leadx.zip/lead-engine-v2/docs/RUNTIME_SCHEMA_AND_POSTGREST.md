# Runtime schema and PostgREST hardening

The consolidated installers now include the canonical migrations for notifications, jobs, saved views, CRM revenue graph, business integrations, and support chat.

## Why this matters

Individual migrations can exist in `sql/` while an older consolidated SQL file omits them. The application then starts normally but a page fails with PostgREST `PGRST205` (table not found in schema cache).

The single-run installers now include those objects and finish with a PostgREST schema reload.

## Runtime diagnostic

`GET /leads/v2/admin/runtime-health` checks the runtime objects used by the application.
