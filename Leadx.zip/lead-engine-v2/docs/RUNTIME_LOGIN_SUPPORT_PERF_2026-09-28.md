# LeadX Runtime / Login / Support / Multi-user Hardening — 2026-09-28

## Fixed

- Removed the duplicate `/crm/me` registration. The guaranteed bootstrap endpoint in `app/app_service.py` is the single `/crm/me` route.
- Added membership-cache stampede protection: concurrent requests for the same user/tenant share one membership lookup.
- Increased default membership cache from 15s to 30s (`AUTH_MEMBERSHIP_CACHE_SECONDS` remains configurable).
- Tuned AnyIO's sync-DB threadpool to 64 workers per FastAPI process by default (`SYNC_DB_THREAD_TOKENS`). This is important because the current Supabase Python client is synchronous.
- Support FAQ retrieval is cached for 60s and support DB calls run off the FastAPI event loop.
- Support failures now return a specific 503 message instead of an opaque 500, while the server request-id middleware still records the traceback.
- CRM browser GET requests now use a short 5s in-memory cache plus concurrent-request deduplication. Mutations invalidate the cache.
- First-login bootstrap can use a trusted tenant id in Supabase `app_metadata`/`user_metadata` when provisioning supplies one; protected API requests still verify membership server-side.
- Removed 1-second tenant polling from the realtime status component.
- Realtime now has one manager/channel per tenant and one change handler, avoiding callback-registration races.
- Docker defaults remain 4 API workers and now expose configurable Uvicorn keep-alive and concurrency limits.

## Important Codespaces rule

A 404 on `GET /crm/me` means port 8000 is serving an old/different process. Source changes cannot modify an already-running process. Stop every old Uvicorn process, then start exactly:

```bash
cd /workspaces/LeadX/lead-engine-v2
pkill -f 'uvicorn.*8000' || true
python -m py_compile app/app_service.py
uvicorn app.app_service:app --host 0.0.0.0 --port 8000 --reload
```

Then:

```bash
curl -i http://127.0.0.1:8000/crm/me
```

Without a bearer token the expected result is **401**, not 404.

## Support migration

The database must contain `support_faq`, `support_conversations`, and `support_messages`. Apply `sql/032_SUPPORT_CHAT.sql` once if `/support/health` reports storage unavailable.

## Production

Do not use `--reload` in production. Use Docker or a process manager with multiple workers. Tune `WEB_CONCURRENCY`, `SYNC_DB_THREAD_TOKENS`, `UVICORN_LIMIT_CONCURRENCY`, and `UVICORN_KEEPALIVE` for the actual VPS size.
