-- LeadX FULL MIGRATION (ordered: tables/columns → functions → views → seed)
-- Safe patterns: IF NOT EXISTS, ADD COLUMN IF NOT EXISTS, DROP VIEW/FUNCTION before replace
-- Re-run after wipe: use the project reset script first, then this file once.

-- =============================================================================
-- LeadX SUPABASE_FULL_MIGRATION.sql
-- Single run: all tables, indexes, views, RLS helpers.
-- Safe to re-run (IF NOT EXISTS / ADD COLUMN IF NOT EXISTS).
-- Includes pipeline_run_leads, CRM tables, continuous discovery, etc.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;


-- ##### 002 production core #####

-- =============================================================================
-- Automiqo Lead Engine v2 — PRODUCTION Multi-Tenant Schema
-- Idempotent. Run in Supabase SQL Editor after 001 if present.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- 1. API Key Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_key_pool (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider       text NOT NULL CHECK (provider IN (
                   'serper','firecrawl','anthropic','gemini','groq','openai','resend','linkedin_scraper','linkedin','instagram','twilio','vapi'
                 )),
  key_value      text NOT NULL,
  label          text,
  status         text NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active','exhausted','disabled','cooling')),
  credits_used   int  NOT NULL DEFAULT 0,
  credits_limit  int,
  error_count    int  NOT NULL DEFAULT 0,
  last_error     text,
  last_used_at   timestamptz,
  cooldown_until timestamptz,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, key_value)
);

CREATE INDEX IF NOT EXISTS idx_api_key_pool_live
  ON api_key_pool (provider, status, last_used_at NULLS FIRST)
  WHERE status IN ('active','cooling');

-- ---------------------------------------------------------------------------
-- 2. Tenants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenants (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  text NOT NULL,
  slug                  text UNIQUE,
  plan                  text NOT NULL DEFAULT 'starter'
                          CHECK (plan IN ('starter','growth','premium','enterprise')),
  leads_per_month_limit int  NOT NULL DEFAULT 100,
  allow_tier_b          boolean NOT NULL DEFAULT false,
  delivery_channel      text NOT NULL DEFAULT 'telegram'
                          CHECK (delivery_channel IN ('telegram','webhook','email','portal','csv')),
  delivery_config       jsonb NOT NULL DEFAULT '{}',
  status                text NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','paused','churned')),
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants (status) WHERE status = 'active';

-- ---------------------------------------------------------------------------
-- 3. ICP Profiles
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS icp_profiles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL DEFAULT 'default',
  vertical      text NOT NULL,
  geo           jsonb NOT NULL DEFAULT '[]',
  keywords      jsonb NOT NULL DEFAULT '[]',
  weights       jsonb NOT NULL DEFAULT '{}',
  exclusivity   text NOT NULL DEFAULT 'exclusive'
                  CHECK (exclusivity IN ('exclusive','shared')),
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_icp_tenant_active ON icp_profiles (tenant_id) WHERE active = true;
CREATE INDEX IF NOT EXISTS idx_icp_vertical ON icp_profiles (vertical);

-- ---------------------------------------------------------------------------
-- 4. Global Leads Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads_global (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint       text NOT NULL UNIQUE,
  phone_normalized  text,
  phone_e164        text,
  name              text NOT NULL,
  name_normalized   text,
  address           text,
  city              text,
  state             text,
  website           text,
  website_domain    text,
  category          text,
  business_status   text NOT NULL DEFAULT 'OPERATIONAL'
                      CHECK (business_status IN ('OPERATIONAL','CLOSED','TEMPORARILY_CLOSED','UNKNOWN')),
  google_rating     numeric(2,1),
  review_count      int NOT NULL DEFAULT 0,
  google_place_id   text,
  source            text NOT NULL DEFAULT 'google_maps_serper',
  source_url        text,
  raw_data          jsonb NOT NULL DEFAULT '{}',
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_global_phone
  ON leads_global (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_domain
  ON leads_global (website_domain) WHERE website_domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_name_trgm
  ON leads_global USING gin (name_normalized gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_leads_global_status ON leads_global (business_status);

-- ---------------------------------------------------------------------------
-- 5. Enrichment
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrichment (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id           uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  email             text,
  email_valid       boolean,
  emails            text[] NOT NULL DEFAULT '{}',
  phone_from_web    text,
  has_booking       boolean NOT NULL DEFAULT false,
  booking_platform  text,
  services          text[] NOT NULL DEFAULT '{}',
  social_links      jsonb NOT NULL DEFAULT '{}',
  tech_stack        text[] NOT NULL DEFAULT '{}',
  owner_name        text,
  markdown_summary  text,
  raw_extraction    jsonb NOT NULL DEFAULT '{}',
  enrichment_method text,
  enrichment_ok     boolean NOT NULL DEFAULT false,
  error             text,
  extracted_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_enrichment_email ON enrichment (email) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_enrichment_ok ON enrichment (enrichment_ok) WHERE enrichment_ok = true;

-- ---------------------------------------------------------------------------
-- 6. Scores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scores (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id             uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  deterministic_score int  NOT NULL DEFAULT 0,
  llm_score           int,
  total_score         int  NOT NULL DEFAULT 0,
  tier                text NOT NULL DEFAULT 'C' CHECK (tier IN ('A','B','C')),
  reasoning           text,
  scored_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);

CREATE INDEX IF NOT EXISTS idx_scores_tier_score ON scores (tier, total_score DESC);

-- ---------------------------------------------------------------------------
-- 7. Lead Assignments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_assignments (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id          uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id           uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  vertical         text NOT NULL,
  geo_tags         text[] NOT NULL DEFAULT '{}',
  delivered_at     timestamptz,
  delivery_channel text,
  delivery_status  text NOT NULL DEFAULT 'pending'
                     CHECK (delivery_status IN ('pending','sent','failed','skipped')),
  delivery_error   text,
  status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','contacted','won','rejected','expired')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id, tenant_id)
);

CREATE INDEX IF NOT EXISTS idx_assignments_tenant_status ON lead_assignments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_exclusivity
  ON lead_assignments (vertical, lead_id) WHERE status NOT IN ('rejected','expired');

CREATE INDEX IF NOT EXISTS idx_assignments_delivered ON lead_assignments (tenant_id, delivered_at DESC);

-- Ensure CRM columns exist BEFORE any view references them
ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS offer_category text,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to text,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}'::text[],
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS delivery_channel text,
  ADD COLUMN IF NOT EXISTS delivery_error text;


-- ---------------------------------------------------------------------------
-- 8. Usage Log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  period          date NOT NULL,
  leads_delivered int  NOT NULL DEFAULT 0,
  tier_a_count    int  NOT NULL DEFAULT 0,
  tier_b_count    int  NOT NULL DEFAULT 0,
  tier_c_count    int  NOT NULL DEFAULT 0,
  leads_rejected  int  NOT NULL DEFAULT 0,
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, period)
);

-- ---------------------------------------------------------------------------
-- 9. Pipeline runs + dead-letter
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid REFERENCES tenants(id) ON DELETE SET NULL,
  icp_id          uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  status          text NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running','completed','failed','partial')),
  discovered      int NOT NULL DEFAULT 0,
  stored          int NOT NULL DEFAULT 0,
  enriched        int NOT NULL DEFAULT 0,
  gated_ok        int NOT NULL DEFAULT 0,
  assigned        int NOT NULL DEFAULT 0,
  delivered       int NOT NULL DEFAULT 0,
  error_message   text,
  meta            jsonb NOT NULL DEFAULT '{}',
  started_at      timestamptz NOT NULL DEFAULT now(),
  finished_at     timestamptz
);

CREATE TABLE IF NOT EXISTS enrichment_failures (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id      uuid REFERENCES leads_global(id) ON DELETE CASCADE,
  website      text,
  error        text,
  attempts     int NOT NULL DEFAULT 1,
  last_attempt timestamptz NOT NULL DEFAULT now(),
  resolved     boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_enrich_fail_unresolved
  ON enrichment_failures (resolved, last_attempt) WHERE resolved = false;

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION normalize_phone(p text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    CASE
      WHEN length(d) = 11 AND left(d,1) = '1' THEN substring(d from 2)
      WHEN length(d) = 10 THEN d
      ELSE d
    END,
    ''
  )
  FROM (SELECT regexp_replace(COALESCE(p, ''), '[^0-9]', '', 'g') AS d) s
  WHERE length(d) >= 10;
$$;

CREATE OR REPLACE FUNCTION extract_domain(url text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    lower(regexp_replace(
      regexp_replace(COALESCE(url,''), '^https?://(www\.)?', '', 'i'),
      '/.*$', ''
    )),
    ''
  );
$$;

CREATE OR REPLACE FUNCTION lead_fingerprint(p_name text, p_phone text, p_website text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT md5(
    lower(trim(COALESCE(p_name, ''))) || '|' ||
    COALESCE(normalize_phone(p_phone), '') || '|' ||
    COALESCE(extract_domain(p_website), '')
  );
$$;

CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[]
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected','expired')
      AND icp.exclusivity = 'exclusive'
      AND lower(icp.vertical) = lower(p_vertical)
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;
  RETURN conflict_exists;
END;
$$;

CREATE OR REPLACE FUNCTION bump_usage(p_tenant_id uuid, p_tier text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
BEGIN
  INSERT INTO usage_log (tenant_id, period, leads_delivered, tier_a_count, tier_b_count, tier_c_count)
  VALUES (
    p_tenant_id, p, 1,
    CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END
  )
  ON CONFLICT (tenant_id, period) DO UPDATE SET
    leads_delivered = usage_log.leads_delivered + 1,
    tier_a_count = usage_log.tier_a_count + CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    tier_b_count = usage_log.tier_b_count + CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    tier_c_count = usage_log.tier_c_count + CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END,
    updated_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE
  lim int;
  used int;
  p date := date_trunc('month', now())::date;
BEGIN
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id;
  IF lim IS NULL THEN RETURN 0; END IF;
  SELECT COALESCE(leads_delivered, 0) INTO used
  FROM usage_log WHERE tenant_id = p_tenant_id AND period = p;
  RETURN GREATEST(lim - COALESCE(used, 0), 0);
END;
$$;

DROP VIEW IF EXISTS deliverable_leads CASCADE;
CREATE OR REPLACE VIEW deliverable_leads AS
SELECT
  lg.id AS lead_id, lg.name, lg.phone_normalized, lg.phone_e164, lg.website,
  lg.address, lg.city, lg.state, lg.business_status, lg.google_rating, lg.review_count,
  e.email, e.email_valid, e.has_booking, e.booking_platform, e.services,
  e.social_links, e.owner_name, s.total_score, s.tier, s.reasoning
FROM leads_global lg
JOIN enrichment e ON e.lead_id = lg.id AND e.enrichment_ok = true
JOIN scores s ON s.lead_id = lg.id
WHERE lg.business_status IS DISTINCT FROM 'CLOSED'
  AND s.tier IN ('A', 'B')
  AND lg.phone_normalized IS NOT NULL
  AND lg.website IS NOT NULL
  AND (
    (e.email IS NOT NULL AND e.email_valid IS NOT FALSE)::int +
    (e.has_booking)::int +
    (COALESCE(array_length(e.services, 1), 0) > 0)::int +
    (e.social_links IS NOT NULL AND e.social_links != '{}'::jsonb)::int +
    (e.owner_name IS NOT NULL)::int
  ) >= 2;


-- ##### CRM portal core (required before RLS) #####
CREATE TABLE IF NOT EXISTS tenant_members (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  auth_user_id  uuid,
  email         text,
  role          text NOT NULL DEFAULT 'member'
                  CHECK (role IN ('owner','admin','member','viewer')),
  status        text NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','invited','disabled')),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, auth_user_id)
);
CREATE INDEX IF NOT EXISTS idx_tenant_members_user ON tenant_members (auth_user_id) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_tenant_members_tenant ON tenant_members (tenant_id, status);

CREATE TABLE IF NOT EXISTS pipeline_stages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  slug          text NOT NULL,
  position      int NOT NULL DEFAULT 0,
  color         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE TABLE IF NOT EXISTS lead_activities (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  activity_type text NOT NULL DEFAULT 'note',
  title         text,
  body          text,
  meta          jsonb DEFAULT '{}',
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_activities_assignment ON lead_activities (assignment_id, created_at DESC);

CREATE TABLE IF NOT EXISTS lead_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  title         text NOT NULL,
  status        text NOT NULL DEFAULT 'open',
  priority      text DEFAULT 'medium',
  due_at        timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  completed_at  timestamptz
);

CREATE TABLE IF NOT EXISTS lead_tags (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  tag           text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS lead_segments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  filters       jsonb NOT NULL DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS crm_audit_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE SET NULL,
  actor_id      uuid,
  action        text NOT NULL,
  entity        text,
  entity_id     text,
  meta          jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);


-- ##### Column repair (partial DB safety) #####
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS plan text DEFAULT 'starter';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS leads_per_month_limit int DEFAULT 100;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS allow_tier_b boolean DEFAULT false;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS delivery_channel text DEFAULT 'telegram';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS delivery_config jsonb DEFAULT '{}';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS brand_name text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS stripe_customer_id text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_normalized text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS name_normalized text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS fingerprint text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_e164 text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS business_status text DEFAULT 'OPERATIONAL';
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS talking_points text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS email text;

ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS status text DEFAULT 'new';
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS delivery_status text DEFAULT 'pending';
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS vertical text;

ALTER TABLE icp_profiles ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE icp_profiles ADD COLUMN IF NOT EXISTS active boolean DEFAULT true;

UPDATE tenants SET status = COALESCE(status, 'active') WHERE status IS NULL;
UPDATE tenants SET name = COALESCE(NULLIF(trim(name), ''), 'Tenant') WHERE name IS NULL;


-- ##### 004 RLS #####

-- =============================================================================
-- Row-Level Security + auth helpers for multi-tenant isolation
-- Run AFTER 002 (lead engine) and 003 (CRM portal) schemas.
-- =============================================================================

-- Map auth.uid() → tenant_id via tenant_members
CREATE OR REPLACE FUNCTION public.current_tenant_ids()
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT tenant_id
  FROM tenant_members
  WHERE auth_user_id = auth.uid()
    AND status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_member(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_admin(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
      AND role IN ('owner', 'admin')
  );
$$;

-- Service role bypasses RLS; anon/authenticated are restricted.
-- Enable RLS on all tenant-scoped tables.

DO $$ BEGIN
  IF to_regclass('public.tenants') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenants ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.icp_profiles') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE icp_profiles ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_assignments') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_assignments ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.enrichment') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE enrichment ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.scores') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE scores ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.usage_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE usage_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE pipeline_runs ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.pipeline_stages') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_activities') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_activities ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_tasks') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_tasks ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_tags') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_tags ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.tenant_members') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenant_members ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_segments') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_segments ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.crm_audit_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE crm_audit_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.enrichment_failures') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE enrichment_failures ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- leads_global is SHARED pool — members can SELECT only leads assigned to them
DO $$ BEGIN
  IF to_regclass('public.leads_global') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE leads_global ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- Drop existing policies if re-running
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT policyname, tablename FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN (
        'tenants','icp_profiles','lead_assignments','leads_global',
        'enrichment','scores','usage_log','pipeline_runs','pipeline_stages',
        'lead_activities','lead_tasks','lead_tags','tenant_members',
        'lead_segments','crm_audit_log','enrichment_failures'
      )
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- TENANTS: members see only their tenants
CREATE POLICY tenants_select ON tenants FOR SELECT
  USING (id IN (SELECT public.current_tenant_ids()));
CREATE POLICY tenants_update ON tenants FOR UPDATE
  USING (public.is_tenant_admin(id));

-- ICP
CREATE POLICY icp_select ON icp_profiles FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY icp_write ON icp_profiles FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- ASSIGNMENTS (core isolation)
CREATE POLICY assignments_select ON lead_assignments FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_insert ON lead_assignments FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_update ON lead_assignments FOR UPDATE
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_delete ON lead_assignments FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- leads_global: only if assigned to one of user's tenants
CREATE POLICY leads_global_select ON leads_global FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = leads_global.id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
-- Writes only via service role (backend pipeline)

-- enrichment / scores: via assigned leads
CREATE POLICY enrichment_select ON enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
CREATE POLICY scores_select ON scores FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = scores.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- usage_log
CREATE POLICY usage_select ON usage_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- pipeline_runs
CREATE POLICY runs_select ON pipeline_runs FOR SELECT
  USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id));

-- CRM tables
CREATE POLICY stages_all ON pipeline_stages FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY activities_all ON lead_activities FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tasks_all ON lead_tasks FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tags_all ON lead_tags FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY segments_all ON lead_segments FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY audit_select ON crm_audit_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_select ON tenant_members FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_admin ON tenant_members FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- api_key_pool: NEVER exposed to clients (service role only)
DO $$ BEGIN
  IF to_regclass('public.api_key_pool') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE api_key_pool ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
-- no policies for authenticated → only service_role can access

COMMENT ON FUNCTION public.current_tenant_ids IS 'Tenants the JWT user belongs to';
COMMENT ON FUNCTION public.is_tenant_member IS 'True if auth.uid() is active member of tenant';


-- ##### 005_outcomes_feedback.sql #####

-- Win/loss feedback storage for adaptive scoring + lookalikes

CREATE TABLE IF NOT EXISTS lead_outcomes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  outcome       text NOT NULL CHECK (outcome IN ('won', 'lost')),
  reason        text,
  features      jsonb NOT NULL DEFAULT '{}',
  recorded_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (assignment_id)
);

CREATE INDEX IF NOT EXISTS idx_outcomes_tenant ON lead_outcomes (tenant_id, outcome);
CREATE INDEX IF NOT EXISTS idx_outcomes_features ON lead_outcomes USING gin (features);

DO $$ BEGIN
  IF to_regclass('public.lead_outcomes') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_outcomes ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

DROP POLICY IF EXISTS outcomes_select ON lead_outcomes;
CREATE POLICY outcomes_select ON lead_outcomes FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS outcomes_insert ON lead_outcomes;
CREATE POLICY outcomes_insert ON lead_outcomes FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));

-- Optional: store last verification timestamps on enrichment
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_mx_ok boolean,
  ADD COLUMN IF NOT EXISTS phone_verified boolean,
  ADD COLUMN IF NOT EXISTS phone_line_type text,
  ADD COLUMN IF NOT EXISTS verified_at timestamptz;

-- Freshness: track when score was last computed
ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS stale boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS refresh_after timestamptz;


-- ##### 006_next_tier.sql #####

-- =============================================================================
-- Next-tier: suppression, global opt-out, signals, sentiment, auto-credits
-- =============================================================================

-- Client suppression lists (tenant CRM exports — never resell these)
CREATE TABLE IF NOT EXISTS suppression_list (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  fingerprint text,                          -- same fingerprint as leads_global
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  source      text DEFAULT 'upload',         -- upload | manual | crm_sync
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_supp_tenant_fp ON suppression_list (tenant_id, fingerprint);
CREATE INDEX IF NOT EXISTS idx_supp_tenant_phone ON suppression_list (tenant_id, phone_normalized)
  WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_email ON suppression_list (tenant_id, email)
  WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_domain ON suppression_list (tenant_id, domain)
  WHERE domain IS NOT NULL;

-- Global opt-out registry (one removal = never for ANY tenant)
CREATE TABLE IF NOT EXISTS global_opt_out (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint text,
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  reason      text,
  requested_by text,                         -- email or 'admin'
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_phone
  ON global_opt_out (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_email
  ON global_opt_out (email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_domain
  ON global_opt_out (domain) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_optout_fp ON global_opt_out (fingerprint)
  WHERE fingerprint IS NOT NULL;

-- Why-now / trigger signals per lead
CREATE TABLE IF NOT EXISTS lead_signals (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id     uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  signal_type text NOT NULL CHECK (signal_type IN (
    'review_velocity_up', 'review_velocity_down',
    'site_redesign', 'new_hire', 'tech_change',
    'complaint_cluster', 'other'
  )),
  strength    numeric(4,2) DEFAULT 1.0,      -- 0–1 relative strength
  detail      jsonb DEFAULT '{}',
  detected_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_signals_lead ON lead_signals (lead_id, signal_type);

-- Review sentiment summary (one row per lead, refreshed)
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS review_sentiment jsonb,   -- {pos, neg, themes: [...], pitch_hooks: [...]}
  ADD COLUMN IF NOT EXISTS tech_stack jsonb,         -- {booking, crm, chat, analytics, ...}
  ADD COLUMN IF NOT EXISTS why_now text[],           -- short human labels
  ADD COLUMN IF NOT EXISTS last_signal_at timestamptz;

-- Auto-credit / refund log
CREATE TABLE IF NOT EXISTS lead_credits (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  lead_id       uuid,
  credit_type   text NOT NULL CHECK (credit_type IN (
    'dead_phone', 'dead_email', 'bounce', 'closed_business', 'duplicate', 'manual'
  )),
  amount        int NOT NULL DEFAULT 1,              -- leads credited back
  period        date NOT NULL,                       -- usage_log period
  detail        jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_credits_tenant ON lead_credits (tenant_id, period);

-- Cross-tenant vertical priors (aggregated win rates per feature)
CREATE TABLE IF NOT EXISTS vertical_priors (
  vertical    text NOT NULL,
  feature     text NOT NULL,                         -- email, booking, reviews, owner, rating_high
  win_rate    numeric(6,4) NOT NULL DEFAULT 0.5,
  lose_rate   numeric(6,4) NOT NULL DEFAULT 0.5,
  sample_size int NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (vertical, feature)
);

-- Encrypted delivery config column (app encrypts JSON → store here)
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS delivery_config_enc text;  -- base64 AES ciphertext

-- RLS for new tables
DO $$ BEGIN
  IF to_regclass('public.suppression_list') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE suppression_list ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_signals') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_signals ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_credits') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_credits ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

DROP POLICY IF EXISTS supp_tenant ON suppression_list;
CREATE POLICY supp_tenant ON suppression_list FOR ALL
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS signals_via_assignment ON lead_signals;
CREATE POLICY signals_via_assignment ON lead_signals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = lead_signals.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS credits_tenant ON lead_credits;
CREATE POLICY credits_tenant ON lead_credits FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- global_opt_out + vertical_priors: service role only (no client policies)

-- Helper: is suppressed for tenant?
CREATE OR REPLACE FUNCTION is_suppressed(
  p_tenant_id uuid,
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM suppression_list s
    WHERE s.tenant_id = p_tenant_id
      AND (
        (p_fingerprint IS NOT NULL AND s.fingerprint = p_fingerprint)
        OR (p_phone IS NOT NULL AND s.phone_normalized = p_phone)
        OR (p_email IS NOT NULL AND lower(s.email) = lower(p_email))
        OR (p_domain IS NOT NULL AND s.domain = p_domain)
      )
  );
$$;

-- Helper: globally opted out?
CREATE OR REPLACE FUNCTION is_opted_out(
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM global_opt_out g
    WHERE
      (p_fingerprint IS NOT NULL AND g.fingerprint = p_fingerprint)
      OR (p_phone IS NOT NULL AND g.phone_normalized = p_phone)
      OR (p_email IS NOT NULL AND lower(g.email) = lower(p_email))
      OR (p_domain IS NOT NULL AND g.domain = p_domain)
  );
$$;

-- Auto-credit: decrement usage_log.leads_delivered for period
CREATE OR REPLACE FUNCTION credit_tenant_usage(
  p_tenant_id uuid,
  p_period date,
  p_amount int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE usage_log
  SET leads_delivered = GREATEST(0, leads_delivered - p_amount)
  WHERE tenant_id = p_tenant_id AND period = p_period;
END;
$$;


-- ##### 007_team_branding_ops.sql #####

-- Team invites, white-label branding, ops metrics

-- Invite tokens for tenant_members
CREATE TABLE IF NOT EXISTS tenant_invites (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  token       text NOT NULL UNIQUE,
  invited_by  uuid,
  expires_at  timestamptz NOT NULL,
  accepted_at timestamptz,
  status      text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','accepted','expired','revoked')),
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invites_token ON tenant_invites (token) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_invites_tenant ON tenant_invites (tenant_id, status);

DO $$ BEGIN
  IF to_regclass('public.tenant_invites') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenant_invites ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DROP POLICY IF EXISTS invites_admin ON tenant_invites;
CREATE POLICY invites_admin ON tenant_invites FOR ALL
  USING (public.is_tenant_admin(tenant_id));
DROP POLICY IF EXISTS invites_select_member ON tenant_invites;
CREATE POLICY invites_select_member ON tenant_invites FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- White-label branding on tenants
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS brand_name text,
  ADD COLUMN IF NOT EXISTS brand_logo_url text,
  ADD COLUMN IF NOT EXISTS brand_primary_color text DEFAULT '#6366f1',
  ADD COLUMN IF NOT EXISTS brand_accent_color text DEFAULT '#22c55e',
  ADD COLUMN IF NOT EXISTS brand_favicon_url text,
  ADD COLUMN IF NOT EXISTS custom_domain text,
  ADD COLUMN IF NOT EXISTS support_email text;

-- LinkedIn enrichment fields
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS linkedin_url text,
  ADD COLUMN IF NOT EXISTS linkedin_company_id text,
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS linkedin_fetched_at timestamptz;

-- Ops metrics daily rollup (pipeline health over time)
CREATE TABLE IF NOT EXISTS ops_metrics_daily (
  day               date NOT NULL,
  tenant_id         uuid,                          -- null = global/system
  pipeline_runs     int NOT NULL DEFAULT 0,
  leads_discovered  int NOT NULL DEFAULT 0,
  leads_enriched_ok int NOT NULL DEFAULT 0,
  leads_enriched_fail int NOT NULL DEFAULT 0,
  leads_gated       int NOT NULL DEFAULT 0,
  leads_assigned    int NOT NULL DEFAULT 0,
  suppression_hits  int NOT NULL DEFAULT 0,
  opt_out_hits      int NOT NULL DEFAULT 0,
  credits_issued    int NOT NULL DEFAULT 0,
  serper_calls      int NOT NULL DEFAULT 0,
  firecrawl_calls   int NOT NULL DEFAULT 0,
  avg_enrich_ms     int,
  error_samples     jsonb DEFAULT '[]',
  PRIMARY KEY (day, tenant_id)
);

-- Allow null tenant for global: use sentinel
-- Postgres UNIQUE treats NULLs as distinct — use coalesce in app or:
CREATE UNIQUE INDEX IF NOT EXISTS idx_ops_metrics_global
  ON ops_metrics_daily (day) WHERE tenant_id IS NULL;

CREATE OR REPLACE FUNCTION bump_ops_metric(
  p_day date,
  p_tenant_id uuid,
  p_field text,
  p_delta int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO ops_metrics_daily (day, tenant_id)
  VALUES (p_day, p_tenant_id)
  ON CONFLICT (day, tenant_id) DO NOTHING;

  EXECUTE format(
    'UPDATE ops_metrics_daily SET %I = COALESCE(%I, 0) + $1 WHERE day = $2 AND tenant_id IS NOT DISTINCT FROM $3',
    p_field, p_field
  ) USING p_delta, p_day, p_tenant_id;
EXCEPTION WHEN OTHERS THEN
  -- soft fail — never break pipeline for metrics
  NULL;
END;
$$;


-- ##### 008_stripe_billing.sql #####

-- Stripe billing fields + usage_log report tracking

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS stripe_customer_id text,
  ADD COLUMN IF NOT EXISTS stripe_subscription_item_id text,
  ADD COLUMN IF NOT EXISTS stripe_price_id text;

CREATE INDEX IF NOT EXISTS idx_tenants_stripe
  ON tenants (stripe_customer_id) WHERE stripe_customer_id IS NOT NULL;

ALTER TABLE usage_log
  ADD COLUMN IF NOT EXISTS stripe_reported_at timestamptz,
  ADD COLUMN IF NOT EXISTS stripe_reported_qty int;


-- ##### 009_social_enrich.sql #####

-- Social enrichment (LinkedIn via microservice + Instagram via instaloader)
-- Runs only on quality-gated leads before assign.

CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,              -- serper | drissbri | site_html
  source_instagram        text,              -- instaloader
  enriched_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS social_enrichment_failures (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id    uuid,
  source     text NOT NULL,                  -- linkedin | instagram
  error      text,
  failed_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_social_fail_at ON social_enrichment_failures (failed_at DESC);

DO $$ BEGIN
  IF to_regclass('public.social_enrichment') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE social_enrichment ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.social_enrichment_failures') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE social_enrichment_failures ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

DROP POLICY IF EXISTS social_enrich_select ON social_enrichment;
CREATE POLICY social_enrich_select ON social_enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS social_fail_select ON social_enrichment_failures;
CREATE POLICY social_fail_select ON social_enrichment_failures FOR SELECT
  USING (
    lead_id IS NULL OR EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment_failures.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- Mirror key fields onto enrichment for CRM views
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS instagram_handle text,
  ADD COLUMN IF NOT EXISTS instagram_followers int,
  ADD COLUMN IF NOT EXISTS instagram_last_post_at timestamptz,
  ADD COLUMN IF NOT EXISTS instagram_stale boolean;


-- ##### 010_beat_zoominfo_layer.sql #####

-- Layer that closes gaps vs ZoomInfo/Apollo for LOCAL B2B:
-- contacts (people), intent score, pitch lines, QA feedback, sample packs, sequences.

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]';

ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS pitch_line text;

-- Named decision-makers / people (Apollo-style contacts, local-first)
CREATE TABLE IF NOT EXISTS lead_contacts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  full_name       text,
  title           text,
  email           text,
  phone           text,
  linkedin_url    text,
  is_decision_maker boolean DEFAULT false,
  source          text, -- linkedin | website | serper | manual
  confidence      int DEFAULT 50,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_contacts_lead ON lead_contacts (lead_id);

-- Operator QA (accuracy proof vs ZoomInfo brand trust)
CREATE TABLE IF NOT EXISTS lead_qa (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id   uuid,
  tenant_id       uuid,
  phone_ok        boolean,
  email_ok        boolean,
  business_open   boolean,
  notes           text,
  reviewed_by     text DEFAULT 'ops',
  reviewed_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_qa_tenant ON lead_qa (tenant_id, reviewed_at DESC);

-- Sample packs for sales (beat Apollo free credits narrative)
CREATE TABLE IF NOT EXISTS sample_packs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  vertical        text,
  geo             text,
  lead_ids        uuid[] DEFAULT '{}',
  meta            jsonb DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- Territory exclusivity board (ZoomInfo has territories; we make them real)
CREATE TABLE IF NOT EXISTS territories (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  vertical        text NOT NULL,
  geo_key         text NOT NULL, -- normalized city/region key
  exclusive_until date,
  status          text NOT NULL DEFAULT 'active', -- active | expired | released
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (vertical, geo_key)  -- one exclusive owner per vertical+geo
);

-- Client "report bad lead" requests
CREATE TABLE IF NOT EXISTS bad_lead_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL,
  assignment_id   uuid NOT NULL,
  lead_id         uuid,
  reason          text NOT NULL, -- wrong_number | email_bounce | closed | duplicate | other
  detail          text,
  status          text NOT NULL DEFAULT 'open', -- open | credited | rejected
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);

DO $$ BEGIN
  IF to_regclass('public.lead_contacts') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_contacts ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_qa') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_qa ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.bad_lead_reports') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE bad_lead_reports ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.territories') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE territories ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;


-- ##### 010_pipeline_run_leads.sql #####

-- 010_pipeline_run_leads.sql
-- Per-run lead board: stage + tier + include for operator drag-drop review

create table if not exists public.pipeline_run_leads (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.pipeline_runs(id) on delete cascade,
  lead_id uuid not null references public.leads_global(id) on delete cascade,
  tenant_id uuid references public.tenants(id) on delete set null,
  stage text not null default 'discovered',  -- discovered | enriched | gated | assigned | excluded
  tier text,                                 -- A | B | C
  included boolean not null default true,
  score int,
  source text,
  name text,
  phone text,
  website text,
  city text,
  position int default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (run_id, lead_id)
);

create index if not exists idx_prl_run on public.pipeline_run_leads(run_id);
create index if not exists idx_prl_tenant on public.pipeline_run_leads(tenant_id);
create index if not exists idx_prl_stage on public.pipeline_run_leads(run_id, stage);

-- Optional: allow service role full access (RLS policies as needed)
alter table public.pipeline_run_leads enable row level security;
drop policy if exists "service_all_pipeline_run_leads" on public.pipeline_run_leads;
create policy "service_all_pipeline_run_leads" on public.pipeline_run_leads
  for all using (true) with check (true);


-- ##### 011_continuous_discovery.sql #####

-- Continuous supply: track what each ICP has already covered so runs explore NEW space.

CREATE TABLE IF NOT EXISTS discovery_coverage (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  icp_id          uuid,
  vertical        text NOT NULL,
  source          text NOT NULL,          -- maps | linkedin | instagram | web | yelp | facebook
  location_key    text NOT NULL,          -- normalized geo cell
  query_key       text NOT NULL DEFAULT '',
  page_reached    int NOT NULL DEFAULT 0,
  leads_found     int NOT NULL DEFAULT 0,
  last_run_at     timestamptz NOT NULL DEFAULT now(),
  exhausted       boolean NOT NULL DEFAULT false,  -- true when source returns 0 new
  meta            jsonb DEFAULT '{}',
  UNIQUE (icp_id, source, location_key, query_key)
);

CREATE INDEX IF NOT EXISTS idx_coverage_icp ON discovery_coverage (icp_id, exhausted, last_run_at);
CREATE INDEX IF NOT EXISTS idx_coverage_vertical ON discovery_coverage (vertical, location_key);

-- Fingerprints already delivered to a tenant (fast skip at discovery)
CREATE TABLE IF NOT EXISTS tenant_seen_leads (
  tenant_id       uuid NOT NULL,
  fingerprint     text NOT NULL,
  lead_id         uuid,
  first_seen_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_tenant_seen_fp ON tenant_seen_leads (fingerprint);

-- ICP geo expansion cells (zip / neighborhood / adjacent city)
CREATE TABLE IF NOT EXISTS icp_geo_cells (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  icp_id          uuid NOT NULL,
  cell_key        text NOT NULL,           -- "hoboken-nj" | "07030" | "jersey-city-nj"
  cell_label      text NOT NULL,          -- human label for Serper queries
  priority        int NOT NULL DEFAULT 100,
  times_scanned   int NOT NULL DEFAULT 0,
  last_scanned_at timestamptz,
  active          boolean NOT NULL DEFAULT true,
  UNIQUE (icp_id, cell_key)
);

CREATE INDEX IF NOT EXISTS idx_geo_cells_scan ON icp_geo_cells (icp_id, active, times_scanned, last_scanned_at);


-- ##### 012_offer_category_exclusivity.sql #####

-- Competitive exclusivity: lock only against same offer_category (seller type),
-- not against every ICP that targets the same vertical/geo.
--
-- Example: hair-dryer seller + hair-cream seller both target NJ salons → BOTH OK.
--          two SEO agencies targeting NJ salons → CONFLICT if exclusive.

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_category text;

-- Human label for UI
ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_label text;

COMMENT ON COLUMN icp_profiles.offer_category IS
  'Competitive lock key. Same category + overlapping geo + exclusive = conflict. Different categories share the lead.';

COMMENT ON COLUMN icp_profiles.vertical IS
  'Target industry of the LEAD (salon, medspa). NOT the exclusivity lock.';

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS offer_category text;

CREATE INDEX IF NOT EXISTS idx_icp_offer_category
  ON icp_profiles (lower(offer_category)) WHERE active = true;

CREATE INDEX IF NOT EXISTS idx_assignments_offer_cat
  ON lead_assignments (lead_id, lower(offer_category))
  WHERE status NOT IN ('rejected', 'expired');

-- Backfill: if offer_category null, use vertical as conservative default
-- (operator should set real categories for multi-ICP same-vertical sharing)
UPDATE icp_profiles
SET offer_category = lower(regexp_replace(vertical, '\s+', '_', 'g'))
WHERE offer_category IS NULL OR offer_category = '';

UPDATE lead_assignments la
SET offer_category = icp.offer_category
FROM icp_profiles icp
WHERE la.icp_id = icp.id
  AND (la.offer_category IS NULL OR la.offer_category = '');

-- New exclusivity function: compete on offer_category, not vertical alone
CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[],
  p_offer_category text DEFAULT NULL
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
  v_offer text;
BEGIN
  -- Prefer explicit offer category; fall back to vertical (legacy)
  v_offer := lower(nullif(trim(p_offer_category), ''));
  IF v_offer IS NULL THEN
    v_offer := lower(nullif(trim(p_vertical), ''));
  END IF;

  IF v_offer IS NULL THEN
    RETURN false; -- cannot lock without a category
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    LEFT JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected', 'expired')
      AND COALESCE(icp.exclusivity, 'exclusive') = 'exclusive'
      -- SAME competitive set only
      AND lower(COALESCE(nullif(la.offer_category, ''), nullif(icp.offer_category, ''), icp.vertical, la.vertical, ''))
          = v_offer
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR p_geo IS NULL
        OR cardinality(p_geo) = 0
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;

  RETURN conflict_exists;
END;
$$;


-- ##### 013_differentiators.sql #####

-- Differentiators: talking points, outreach, docs, recycle, freshness, territories

ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS first_touch_meta jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS recycled_from_assignment_id uuid,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz;

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS auto_first_touch boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS first_touch_channel text DEFAULT 'sms',
  ADD COLUMN IF NOT EXISTS first_touch_script text,
  ADD COLUMN IF NOT EXISTS vapi_assistant_id text,
  ADD COLUMN IF NOT EXISTS twilio_from_number text,
  ADD COLUMN IF NOT EXISTS whatsapp_from text,
  ADD COLUMN IF NOT EXISTS onboarding_defaults jsonb DEFAULT '{}';

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS client_weight_overrides jsonb DEFAULT '{}';

-- Document templates library
CREATE TABLE IF NOT EXISTS doc_templates (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE CASCADE, -- null = global
  category      text NOT NULL,  -- contract, nda, invoice, proposal, onboarding
  name          text NOT NULL,
  description   text,
  body_html     text NOT NULL,
  body_text     text,
  variables     jsonb NOT NULL DEFAULT '[]', -- ["client_name","amount",...]
  channel_hint  text DEFAULT 'email', -- email, whatsapp, both
  active        boolean DEFAULT true,
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doc_templates_cat ON doc_templates (category) WHERE active;

-- Generated docs / sends log
CREATE TABLE IF NOT EXISTS doc_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  template_id   uuid REFERENCES doc_templates(id) ON DELETE SET NULL,
  category      text,
  to_email      text,
  to_phone      text,
  channel       text NOT NULL, -- email, whatsapp
  subject       text,
  body_html     text,
  body_text     text,
  variables     jsonb DEFAULT '{}',
  status        text DEFAULT 'queued',
  provider_id   text,
  error         text,
  created_at    timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doc_sends_tenant ON doc_sends (tenant_id, created_at DESC);

-- Outreach log
CREATE TABLE IF NOT EXISTS first_touch_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  channel       text NOT NULL,
  status        text NOT NULL,
  provider      text,
  provider_id   text,
  payload       jsonb DEFAULT '{}',
  error         text,
  created_at    timestamptz DEFAULT now()
);

-- Freshness schedule config (global defaults)
CREATE TABLE IF NOT EXISTS freshness_policy (
  tier          text PRIMARY KEY,
  reverify_days int NOT NULL
);

INSERT INTO freshness_policy (tier, reverify_days) VALUES
  ('A', 7), ('B', 21), ('C', 60)
ON CONFLICT (tier) DO NOTHING;

-- Seed a starter global template pack (short, editable)
INSERT INTO doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint)
SELECT NULL, x.category, x.name, x.description, x.body_html, x.body_text, x.variables::jsonb, x.channel_hint
FROM (VALUES
  ('contract', 'Service Agreement (simple)', '1-page services agreement',
   '<h2>Service Agreement</h2><p>This agreement is between <b>{{provider_name}}</b> and <b>{{client_name}}</b>.</p><p>Scope: {{scope}}</p><p>Fee: {{amount}} {{currency}}</p><p>Term: {{term}}</p><p>Signed: ________________</p>',
   'Service Agreement between {{provider_name}} and {{client_name}}. Scope: {{scope}}. Fee: {{amount}} {{currency}}. Term: {{term}}.',
   '["provider_name","client_name","scope","amount","currency","term"]', 'email'),
  ('nda', 'Mutual NDA', 'Short mutual confidentiality',
   '<h2>Mutual NDA</h2><p>{{party_a}} and {{party_b}} agree to keep confidential information private for {{term}}.</p>',
   'Mutual NDA between {{party_a}} and {{party_b}} for {{term}}.',
   '["party_a","party_b","term"]', 'email'),
  ('invoice', 'Standard Invoice', 'Simple invoice',
   '<h2>Invoice {{invoice_number}}</h2><p>Bill to: {{client_name}}</p><p>Amount due: <b>{{amount}} {{currency}}</b></p><p>Due: {{due_date}}</p><p>{{line_items}}</p>',
   'Invoice {{invoice_number}} to {{client_name}} for {{amount}} {{currency}}, due {{due_date}}.',
   '["invoice_number","client_name","amount","currency","due_date","line_items"]', 'both'),
  ('proposal', 'Lead Package Proposal', 'Proposal for exclusive leads',
   '<h2>Proposal</h2><p>Hi {{client_name}},</p><p>We will deliver {{lead_count}} Tier A {{vertical}} leads in {{geo}}.</p><p>Investment: {{amount}}/mo. Exclusivity: {{offer_category}} in {{geo}}.</p>',
   'Proposal for {{client_name}}: {{lead_count}} Tier A {{vertical}} leads in {{geo}} at {{amount}}/mo.',
   '["client_name","lead_count","vertical","geo","amount","offer_category"]', 'email'),
  ('onboarding', 'Client Onboarding Checklist', 'Kickoff email',
   '<h2>Welcome, {{client_name}}</h2><ol><li>Confirm ICP: {{vertical}} in {{geo}}</li><li>CRM login</li><li>Sample pack review</li><li>First pipeline run</li></ol>',
   'Welcome {{client_name}}. Confirm ICP {{vertical}} / {{geo}}, CRM login, sample pack, first run.',
   '["client_name","vertical","geo"]', 'both')
) AS x(category, name, description, body_html, body_text, variables, channel_hint)
WHERE NOT EXISTS (SELECT 1 FROM doc_templates WHERE name = x.name AND tenant_id IS NULL);


-- ##### 014_email_outreach.sql #####

CREATE TABLE IF NOT EXISTS email_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  to_email      text NOT NULL,
  subject       text,
  status        text NOT NULL DEFAULT 'queued',
  provider      text,
  provider_id   text,
  error         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_sends_tenant ON email_sends (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_sends_assignment ON email_sends (assignment_id);


-- ##### 015_crm_missing_objects.sql #####

-- =============================================================================
-- 015 — CRM missing objects (runtime-breaking gap repair)
--
-- Fixes three verified gaps that make the CRM portal return HTTP 500:
--   (a) view  crm_lead_cards      — queried by 5 endpoints, defined nowhere
--   (b) func  seed_default_stages — called via sb.rpc(), defined nowhere
--   (c) note  email_outreach.py writes to a table named `activities`
--
-- Idempotent / re-runnable. Does NOT drop or redefine any existing table;
-- only ADD COLUMN IF NOT EXISTS (the same additive "column repair" pattern
-- already used in SUPABASE_FULL_MIGRATION.sql around line 466).
-- =============================================================================


-- ---------------------------------------------------------------------------
-- 0. Column repair — columns the CRM code reads/writes that were never created
--
-- These are NOT cosmetic. Every one of them is referenced by
-- backend/crm/crm_api.py today:
--   lead_assignments.stage_id          crm_api.py:410,439,573 (change_stage, pipeline_board)
--   lead_assignments.priority          crm_api.py:262,271,688 (filter, sort, export)
--   lead_assignments.assigned_to       crm_api.py:260          (filter)
--   lead_assignments.next_action_at    crm_api.py:271          (sort)
--   lead_assignments.value_estimate    crm_api.py:55           (LeadUpdate PATCH)
--   lead_assignments.custom_fields     crm_api.py:57           (LeadUpdate PATCH)
--   lead_assignments.tags              crm_api.py:264          (contains filter)
--   lead_assignments.last_contacted_at crm_api.py:441,496      (write on activity)
--   lead_assignments.assigned_at       crm_api.py:787, leads_api.py:1030,1184
--   pipeline_stages.is_won/is_lost     crm_api.py:130,614-615
--   lead_activities.lead_id/actor_id   crm_api.py:96-97,486
--   lead_tasks.lead_id/description/assigned_to  crm_api.py:521-526
-- Without them the view below cannot be built and the PATCH/stage/task
-- endpoints fail on insert.
-- ---------------------------------------------------------------------------

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id          uuid,
  ADD COLUMN IF NOT EXISTS stage_slug        text,
  ADD COLUMN IF NOT EXISTS priority          text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to       text,
  ADD COLUMN IF NOT EXISTS next_action_at    timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate    numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields     jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags              text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at       timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes             text;

-- stage_id -> pipeline_stages(id), added separately so a re-run is safe
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'lead_assignments_stage_id_fkey'
  ) THEN
    ALTER TABLE lead_assignments
      ADD CONSTRAINT lead_assignments_stage_id_fkey
      FOREIGN KEY (stage_id) REFERENCES pipeline_stages(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Backfill assigned_at from created_at for rows that predate the column
UPDATE lead_assignments
SET assigned_at = created_at
WHERE assigned_at IS NULL AND created_at IS NOT NULL;

ALTER TABLE pipeline_stages
  ADD COLUMN IF NOT EXISTS is_won     boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_lost    boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE lead_activities
  ADD COLUMN IF NOT EXISTS lead_id  uuid,
  ADD COLUMN IF NOT EXISTS actor_id uuid;

ALTER TABLE lead_tasks
  ADD COLUMN IF NOT EXISTS lead_id     uuid,
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS assigned_to text;

-- Partial-DB safety: these exist in SUPABASE_FULL_MIGRATION.sql's CREATE TABLE
-- but NOT in the older sql/001 definitions, so a DB built from 001 lacks them
-- and the view below would fail to compile. Additive, no-op when present.
ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS google_place_id text,
  ADD COLUMN IF NOT EXISTS source_url      text,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier     text;

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_valid boolean;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS geo_tags            text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS delivery_status     text DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS delivery_error      text,
  ADD COLUMN IF NOT EXISTS exclusive_until     timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_status  text,
  ADD COLUMN IF NOT EXISTS first_touch_at      timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text;

-- social_enrichment is created by sql/009_social_enrich.sql and is a hard
-- dependency of the view. Guarded here so 015 can be applied to a DB where
-- 009 has not been run yet (IF NOT EXISTS — never alters an existing table).
CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,
  source_instagram        text,
  enriched_at             timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_lead_assignments_stage
  ON lead_assignments (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_priority
  ON lead_assignments (tenant_id, priority);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_assigned_to
  ON lead_assignments (tenant_id, assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_assignments_next_action
  ON lead_assignments (tenant_id, next_action_at) WHERE next_action_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tags
  ON lead_assignments USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_lead_activities_lead
  ON lead_activities (lead_id) WHERE lead_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_tasks_lead
  ON lead_tasks (lead_id) WHERE lead_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- (a) crm_lead_cards — the denormalized lead card the CRM portal reads
--
-- Consumed by:
--   crm_api.py:138  dashboard      -> assignment_id, stage_slug, tier,
--                                     total_score, assignment_status
--   crm_api.py:251  list_leads     -> select *, filters on stage_slug, tier,
--                                     assignment_status, assigned_to, priority,
--                                     tags (contains), company_name (ilike);
--                                     orders by delivered_at | total_score |
--                                     company_name | next_action_at | priority
--   crm_api.py:291  lead_detail    -> select *, needs lead_id
--   crm_api.py:563  pipeline_board -> select *, needs stage_id, orders total_score
--   crm_api.py:637  reports_summary-> tier, stage_slug, total_score,
--                                     delivered_at, has_booking, email
--   crm_api.py:679  export_csv     -> company_name, phone_e164,
--                                     phone_normalized, email, website, city,
--                                     tier, total_score, stage_name,
--                                     booking_platform, priority, delivered_at
--   app_service.py:144 healthcheck -> assignment_id
--
-- Plain (non-materialized) view so the CRM is always fresh — the portal
-- writes to lead_assignments and immediately re-reads this view.
-- LEFT JOINs throughout: a lead with no enrichment / score / stage must still
-- appear on the board, otherwise freshly-assigned leads vanish from the UI.
-- ---------------------------------------------------------------------------

-- DROP first: CREATE OR REPLACE VIEW cannot change or reorder existing
-- columns, so a re-run after any edit to the column list below would fail
-- with "cannot change name of view column". Dropping a view is non-
-- destructive (no data lives in it) and it is recreated immediately.

-- ========== Pre-view column safety (all refs used by crm_lead_cards) ==========
ALTER TABLE public.leads_global
  ADD COLUMN IF NOT EXISTS phone_normalized text,
  ADD COLUMN IF NOT EXISTS phone_e164 text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS website_domain text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS business_status text,
  ADD COLUMN IF NOT EXISTS google_rating numeric,
  ADD COLUMN IF NOT EXISTS review_count int,
  ADD COLUMN IF NOT EXISTS google_place_id text,
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS source_url text,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text,
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS pitch_line text;

ALTER TABLE public.enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS has_booking boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS booking_platform text,
  ADD COLUMN IF NOT EXISTS services text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS owner_name text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS email_valid boolean,
  ADD COLUMN IF NOT EXISTS enrichment_ok boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS enrichment_method text,
  ADD COLUMN IF NOT EXISTS extracted_at timestamptz,
  ADD COLUMN IF NOT EXISTS markdown_summary text;

ALTER TABLE public.scores
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_score numeric,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS reasoning text;

ALTER TABLE public.lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to text,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS offer_category text,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS geo_tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS icp_id uuid,
  ADD COLUMN IF NOT EXISTS delivery_channel text,
  ADD COLUMN IF NOT EXISTS delivery_error text;

ALTER TABLE public.pipeline_stages
  ADD COLUMN IF NOT EXISTS is_won boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_lost boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS color text,
  ADD COLUMN IF NOT EXISTS position int DEFAULT 0;

-- social_enrichment optional cols
DO $$ BEGIN
  IF to_regclass('public.social_enrichment') IS NOT NULL THEN
    ALTER TABLE public.social_enrichment
      ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
      ADD COLUMN IF NOT EXISTS decision_maker_name text,
      ADD COLUMN IF NOT EXISTS decision_maker_title text,
      ADD COLUMN IF NOT EXISTS instagram_handle text,
      ADD COLUMN IF NOT EXISTS instagram_followers int;
  END IF;
END $$;
-- ========== end pre-view safety ==========

DROP VIEW IF EXISTS crm_lead_cards;

DROP VIEW IF EXISTS crm_lead_cards CASCADE;
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  -- ── identity / tenancy ──────────────────────────────────────────────────
  la.tenant_id                                    AS tenant_id,
  la.id                                           AS assignment_id,
  la.lead_id                                      AS lead_id,

  -- ── company / display ───────────────────────────────────────────────────
  lg.name                                         AS company_name,
  lg.name                                         AS name,
  lg.category                                     AS category,
  lg.category                                     AS industry,
  la.vertical                                     AS vertical,
  la.offer_category                               AS offer_category,

  -- ── pipeline position ───────────────────────────────────────────────────
  la.stage_id                                     AS stage_id,
  COALESCE(ps.slug, la.stage_slug, 'new')         AS stage_slug,
  COALESCE(ps.name, initcap(COALESCE(la.stage_slug, 'New'))) AS stage_name,
  ps.color                                        AS stage_color,
  ps.position                                     AS stage_position,
  COALESCE(ps.is_won,  false)                     AS stage_is_won,
  COALESCE(ps.is_lost, false)                     AS stage_is_lost,

  -- ── assignment state (note the aliases the API filters on) ──────────────
  la.status                                       AS assignment_status,
  la.status                                       AS status,
  la.priority                                     AS priority,
  la.assigned_to                                  AS assigned_to,
  la.assigned_at                                  AS assigned_at,
  la.delivered_at                                 AS delivered_at,
  la.delivery_channel                             AS delivery_channel,
  la.delivery_status                              AS delivery_status,
  la.delivery_error                               AS delivery_error,
  la.next_action_at                               AS next_action_at,
  la.last_contacted_at                            AS last_contacted_at,
  la.value_estimate                               AS value_estimate,
  COALESCE(la.custom_fields, '{}'::jsonb)         AS custom_fields,
  COALESCE(la.tags, '{}'::text[])                 AS tags,
  la.notes                                        AS notes,
  la.icp_id                                       AS icp_id,
  la.geo_tags                                     AS geo_tags,
  la.exclusive_until                              AS exclusive_until,
  la.first_touch_status                           AS first_touch_status,
  la.first_touch_at                               AS first_touch_at,
  la.first_touch_channel                          AS first_touch_channel,
  la.created_at                                   AS created_at,

  -- ── scoring (score/tier prefer the scores table, fall back to assignment)
  COALESCE(s.total_score, 0)                      AS total_score,
  COALESCE(s.total_score, 0)                      AS score,
  s.deterministic_score                           AS deterministic_score,
  s.llm_score                                     AS llm_score,
  COALESCE(s.tier, la.tier, 'C')                  AS tier,
  s.reasoning                                     AS score_reasoning,
  s.scored_at                                     AS scored_at,
  COALESCE(s.intent_score, e.intent_score, 0)     AS intent_score,

  -- ── contact channels ────────────────────────────────────────────────────
  -- leads_global has NO plain `phone` column (only phone_normalized /
  -- phone_e164). The frontend reads lead.phone, so it is synthesized here.
  COALESCE(lg.phone_e164, lg.phone_normalized, e.phone_from_web) AS phone,
  lg.phone_normalized                             AS phone_normalized,
  lg.phone_e164                                   AS phone_e164,
  e.phone_from_web                                AS phone_from_web,
  COALESCE(e.email, lg.email)                     AS email,
  e.email_valid                                   AS email_valid,
  COALESCE(e.emails, '{}'::text[])                AS emails,
  lg.website                                      AS website,
  lg.website_domain                               AS website_domain,
  lg.website_domain                               AS domain,
  lg.address                                      AS address,
  lg.city                                         AS city,
  lg.state                                        AS state,

  -- ── quality / provenance signals ────────────────────────────────────────
  lg.business_status                              AS business_status,
  lg.google_rating                                AS google_rating,
  lg.review_count                                 AS review_count,
  lg.google_place_id                              AS google_place_id,
  lg.source                                       AS source,
  lg.source_url                                   AS source_url,
  -- entity_resolution.py joins multi-source hits into `source` as "a+b+c";
  -- split it back out so the UI's lead.sources_hit array works.
  string_to_array(COALESCE(lg.source, ''), '+')   AS sources_hit,
  lg.last_verified_at                             AS last_verified_at,
  lg.verify_tier                                  AS verify_tier,

  -- ── enrichment / sales-enablement ───────────────────────────────────────
  COALESCE(e.has_booking, false)                  AS has_booking,
  e.booking_platform                              AS booking_platform,
  COALESCE(e.services, '{}'::text[])              AS services,
  COALESCE(e.tech_stack, '{}'::text[])            AS tech_stack,
  COALESCE(e.social_links, '{}'::jsonb)           AS social_links,
  e.owner_name                                    AS owner_name,
  COALESCE(e.linkedin_url, se.linkedin_url)       AS linkedin_url,
  COALESCE(e.decision_makers, se.decision_makers, '[]'::jsonb) AS decision_makers,
  se.decision_maker_name                          AS decision_maker_name,
  se.decision_maker_title                         AS decision_maker_title,
  se.instagram_handle                             AS instagram_handle,
  se.instagram_followers                          AS instagram_followers,
  COALESCE(e.pitch_line, s.pitch_line) AS pitch_line,
  lg.talking_points                               AS talking_points,
  e.markdown_summary                              AS markdown_summary,
  COALESCE(e.enrichment_ok, false)                AS enrichment_ok,
  e.enrichment_method                             AS enrichment_method,
  e.extracted_at                                  AS enriched_at
FROM lead_assignments la
LEFT JOIN leads_global      lg ON lg.id = la.lead_id
LEFT JOIN enrichment        e  ON e.lead_id = la.lead_id
LEFT JOIN scores            s  ON s.lead_id = la.lead_id
LEFT JOIN social_enrichment se ON se.lead_id = la.lead_id
LEFT JOIN pipeline_stages   ps ON ps.id = la.stage_id
                              AND ps.tenant_id = la.tenant_id;

COMMENT ON VIEW crm_lead_cards IS
  'Denormalized CRM lead card: lead_assignments + leads_global + enrichment + '
  'scores + social_enrichment + pipeline_stages. Read by /crm dashboard, '
  'leads list/detail, pipeline board, reports and CSV export. Plain view '
  '(not materialized) so portal writes are immediately visible.';

-- Tenant isolation: by default a view runs as its OWNER, which would BYPASS
-- the RLS policies on lead_assignments and leak other tenants' leads to any
-- authenticated caller. security_invoker makes the view evaluate the caller's
-- RLS instead (Postgres 15+ / current Supabase). Wrapped in a DO block so
-- this file still applies on an older server — but on a pre-15 server the
-- view must only ever be read by the service role.
DO $$
BEGIN
  EXECUTE 'ALTER VIEW crm_lead_cards SET (security_invoker = true)';
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'crm_lead_cards: security_invoker unsupported on this server — restrict this view to service_role';
END $$;

GRANT SELECT ON crm_lead_cards TO authenticated, service_role;


-- ---------------------------------------------------------------------------
-- (b) seed_default_stages(p_tenant_id uuid)
--
-- Called via sb.rpc("seed_default_stages", {"p_tenant_id": ...}) at
-- crm_api.py:605 (POST /crm/{tenant_id}/stages/seed and /setup).
-- Idempotent twice over: it returns early if the tenant already has any
-- stage, and the INSERT still carries ON CONFLICT DO NOTHING against the
-- existing UNIQUE (tenant_id, slug).
--
-- Slugs/colors/order match the Python fallback list in crm_api.py:608-616 so
-- the RPC path and the fallback path produce identical pipelines.
-- ---------------------------------------------------------------------------

DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);

CREATE OR REPLACE FUNCTION public.seed_default_stages(p_tenant_id uuid)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted int := 0;
BEGIN
  IF p_tenant_id IS NULL THEN
    RETURN 0;
  END IF;

  -- Already configured (possibly customized) — never overwrite operator setup.
  IF EXISTS (SELECT 1 FROM pipeline_stages WHERE tenant_id = p_tenant_id) THEN
    RETURN 0;
  END IF;

  INSERT INTO pipeline_stages (tenant_id, name, slug, position, color, is_won, is_lost)
  VALUES
    (p_tenant_id, 'New',         'new',         1, '#94a3b8', false, false),
    (p_tenant_id, 'Contacted',   'contacted',   2, '#3b82f6', false, false),
    (p_tenant_id, 'Qualified',   'qualified',   3, '#8b5cf6', false, false),
    (p_tenant_id, 'Proposal',    'proposal',    4, '#f59e0b', false, false),
    (p_tenant_id, 'Negotiation', 'negotiation', 5, '#f97316', false, false),
    (p_tenant_id, 'Won',         'won',         6, '#22c55e', true,  false),
    (p_tenant_id, 'Lost',        'lost',        7, '#ef4444', false, true)
  ON CONFLICT (tenant_id, slug) DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted;
END;
$$;

COMMENT ON FUNCTION public.seed_default_stages(uuid) IS
  'Seed the default 7-stage pipeline for a tenant. No-op if the tenant '
  'already has stages. Called by POST /crm/{tenant_id}/stages/seed.';

GRANT EXECUTE ON FUNCTION public.seed_default_stages(uuid) TO authenticated, service_role;


-- ---------------------------------------------------------------------------
-- (c) NOTE — the `activities` table referenced by email_outreach.py
--
-- backend/integrations/prod/email_outreach.py:206 inserts into a table named
-- `activities`. Historically no such table existed: the lead-engine timeline
-- table is `lead_activities` (tenant_id, assignment_id, activity_type, title,
-- body, meta, created_by, created_at). That insert was silently swallowed by
-- its surrounding try/except, so email sends were never timelined.
--
-- Deliberately NOT creating an `activities` shim here. Two things resolve it:
--   1. The Python fix (in progress) writes to `lead_activities` first.
--   2. sql/016_crm_full.sql introduces a genuinely NEW, richer `activities`
--      table for the company/contact/deal CRM — with DIFFERENT columns
--      (subject + occurred_at + direction, not title). email_outreach.py's
--      fallback branch already targets that shape.
-- Do not "fix" this by aliasing activities -> lead_activities; the two tables
-- have different grains (lead assignment vs. account/contact/deal) and
-- different column names.
-- ---------------------------------------------------------------------------


-- ##### 016_crm_full.sql #####

-- =============================================================================
-- 016 — Full CRM / customer database
--
-- The lead engine's own tables (leads_global, lead_assignments, enrichment,
-- scores) model SCRAPED PROSPECTS. This file adds the layer above them: the
-- accounts, people, opportunities and timeline a user actually works after a
-- prospect converts — companies, contacts, deal_stages, deals, activities,
-- tasks, notes, custom_field_defs, email_log, call_log.
--
-- Relationship to the lead engine:
--   leads_global.id  ──► companies.source_lead_id   (provenance on convert)
--   lead_assignments.id ──► deals.source_assignment_id
--                       ──► activities.assignment_id / email_log / call_log
-- Nothing here modifies or drops an existing table.
--
-- Idempotent / re-runnable throughout.
-- Tags: this schema uses `tags text[]` columns (matching lead_assignments.tags
-- and the GIN-indexed pattern already used elsewhere). There is deliberately
-- NO separate tags/taggings join table — see the note at the end of the file.
-- =============================================================================

-- pg_trgm backs the fuzzy company-name search index below. Already created by
-- sql/001, repeated here so 016 can be applied standalone.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------------------
-- Shared updated_at trigger helper
--
-- Checked first: the existing schema (sql/001..014, SUPABASE_FULL_MIGRATION)
-- has NO trigger function at all — every updated_at is set by the application.
-- So this helper is new, and is named distinctly to avoid colliding with any
-- future Supabase-provided function. Reused by every table below.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.crm_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION public.crm_set_updated_at IS
  'BEFORE UPDATE trigger: stamps updated_at = now(). Shared by all 016 CRM tables.';


-- ---------------------------------------------------------------------------
-- 1. companies — the customer / account record
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS companies (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name            text NOT NULL,
  domain          text,
  website         text,
  phone           text,
  address         text,
  city            text,
  state           text,
  country         text,
  postal_code     text,
  industry        text,
  employee_count  int,
  annual_revenue  numeric(16,2),
  description     text,
  owner           text,                   -- tenant_members.email / free text,
                                          -- matching lead_assignments.assigned_to
  status          text NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','prospect','customer','churned','archived')),
  tags            text[] NOT NULL DEFAULT '{}',
  custom_fields   jsonb  NOT NULL DEFAULT '{}',
  source          text,
  source_lead_id  uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

-- One account per domain per tenant (case-insensitive); NULL domain unconstrained
CREATE UNIQUE INDEX IF NOT EXISTS idx_companies_tenant_domain
  ON companies (tenant_id, lower(domain)) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_tenant_status
  ON companies (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_companies_tenant_owner
  ON companies (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_tenant_name
  ON companies (tenant_id, lower(name));
CREATE INDEX IF NOT EXISTS idx_companies_name_trgm
  ON companies USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_companies_tags
  ON companies USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_companies_source_lead
  ON companies (source_lead_id) WHERE source_lead_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_companies_updated_at ON companies;
CREATE TRIGGER trg_companies_updated_at BEFORE UPDATE ON companies
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE companies IS
  'Customer/account record. source_lead_id preserves provenance when an '
  'account is converted from a scraped leads_global row.';


-- ---------------------------------------------------------------------------
-- 2. contacts — people at an account
--
-- Distinct from lead_contacts (which hangs off leads_global and holds
-- scraped, unverified decision-makers). contacts are the tenant's own
-- curated people records.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contacts (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id        uuid REFERENCES companies(id) ON DELETE CASCADE,
  full_name         text,
  first_name        text,
  last_name         text,
  title             text,
  email             text,
  phone             text,
  mobile            text,
  linkedin_url      text,
  is_primary        boolean NOT NULL DEFAULT false,
  is_decision_maker boolean NOT NULL DEFAULT false,
  owner             text,
  status            text NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','unqualified','bounced','archived')),
  tags              text[] NOT NULL DEFAULT '{}',
  custom_fields     jsonb  NOT NULL DEFAULT '{}',
  do_not_contact    boolean NOT NULL DEFAULT false,
  source            text,
  source_lead_id    uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_by        uuid,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_contacts_tenant_email
  ON contacts (tenant_id, lower(email));
CREATE INDEX IF NOT EXISTS idx_contacts_company
  ON contacts (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_status
  ON contacts (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_owner
  ON contacts (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_contacts_tags
  ON contacts USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_contacts_dnc
  ON contacts (tenant_id) WHERE do_not_contact = true;
-- At most one primary contact per company
CREATE UNIQUE INDEX IF NOT EXISTS idx_contacts_one_primary
  ON contacts (company_id) WHERE is_primary = true AND company_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_contacts_updated_at ON contacts;
CREATE TRIGGER trg_contacts_updated_at BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE contacts IS
  'Tenant-curated people. Distinct from lead_contacts (scraped decision-makers '
  'attached to leads_global). do_not_contact must be honoured by all outreach.';

-- ---------------------------------------------------------------------------
-- 3. deal_stages — per-tenant configurable deal pipeline
--
-- Separate from pipeline_stages (which stages LEAD ASSIGNMENTS in the lead
-- engine). Deals move through their own stages with win probabilities.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deal_stages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  slug          text NOT NULL,
  position      int  NOT NULL DEFAULT 0,
  color         text,
  probability   int  NOT NULL DEFAULT 0 CHECK (probability BETWEEN 0 AND 100),
  is_won        boolean NOT NULL DEFAULT false,
  is_lost       boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_deal_stages_tenant_position
  ON deal_stages (tenant_id, position);

DROP TRIGGER IF EXISTS trg_deal_stages_updated_at ON deal_stages;
CREATE TRIGGER trg_deal_stages_updated_at BEFORE UPDATE ON deal_stages
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE deal_stages IS
  'Deal pipeline stages per tenant. Distinct from pipeline_stages, which '
  'stages lead_assignments in the lead engine.';


-- ---------------------------------------------------------------------------
-- 4. deals — opportunities
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deals (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id           uuid REFERENCES companies(id) ON DELETE CASCADE,
  primary_contact_id   uuid REFERENCES contacts(id) ON DELETE SET NULL,
  title                text NOT NULL,
  description          text,
  value                numeric(14,2),
  currency             text NOT NULL DEFAULT 'USD',
  stage_id             uuid REFERENCES deal_stages(id) ON DELETE SET NULL,
  probability          int CHECK (probability IS NULL OR probability BETWEEN 0 AND 100),
  expected_close_date  date,
  actual_close_date    date,
  status               text NOT NULL DEFAULT 'open'
                         CHECK (status IN ('open','won','lost')),
  lost_reason          text,
  owner                text,
  source               text,
  source_assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  tags                 text[] NOT NULL DEFAULT '{}',
  custom_fields        jsonb  NOT NULL DEFAULT '{}',
  created_by           uuid,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_deals_tenant_status
  ON deals (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_stage
  ON deals (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_deals_company
  ON deals (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_contact
  ON deals (primary_contact_id) WHERE primary_contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_tenant_owner
  ON deals (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_expected_close
  ON deals (tenant_id, expected_close_date) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_deals_tags
  ON deals USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_deals_source_assignment
  ON deals (source_assignment_id) WHERE source_assignment_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_deals_updated_at ON deals;
CREATE TRIGGER trg_deals_updated_at BEFORE UPDATE ON deals
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE deals IS
  'Opportunities. source_assignment_id ties a deal back to the lead engine '
  'assignment it originated from, for closed-loop attribution.';


-- ---------------------------------------------------------------------------
-- 5. activities — unified polymorphic timeline
--
-- NEW TABLE, distinct from the existing lead_activities. Do not conflate:
--   lead_activities : keyed to a lead_assignment only; columns title/created_at.
--                     Written by /crm/{t}/leads/{a}/activities and kept as-is.
--   activities      : account/contact/deal grain; columns subject/occurred_at/
--                     direction/duration_minutes/outcome. Can ALSO reference an
--                     assignment_id, so a lead-era event can be carried forward
--                     onto the account timeline after conversion.
-- Both remain live. lead_activities is untouched by this migration.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activities (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  activity_type    text NOT NULL DEFAULT 'note'
                     CHECK (activity_type IN
                       ('call','email','meeting','note','task','stage_change','system')),
  subject          text,
  body             text,
  direction        text CHECK (direction IS NULL OR direction IN ('inbound','outbound')),
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  duration_minutes int,
  outcome          text,
  company_id       uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id       uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id          uuid REFERENCES deals(id) ON DELETE CASCADE,
  assignment_id    uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  created_by       uuid,
  meta             jsonb NOT NULL DEFAULT '{}',
  created_at       timestamptz NOT NULL DEFAULT now()
);

-- Primary timeline query
CREATE INDEX IF NOT EXISTS idx_activities_tenant_occurred
  ON activities (tenant_id, occurred_at DESC);
-- Per-entity timelines
CREATE INDEX IF NOT EXISTS idx_activities_company
  ON activities (company_id, occurred_at DESC) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_contact
  ON activities (contact_id, occurred_at DESC) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_deal
  ON activities (deal_id, occurred_at DESC) WHERE deal_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_assignment
  ON activities (assignment_id, occurred_at DESC) WHERE assignment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_tenant_type
  ON activities (tenant_id, activity_type, occurred_at DESC);

COMMENT ON TABLE activities IS
  'Unified CRM timeline across companies/contacts/deals (and optionally a lead '
  'assignment). NEW and separate from lead_activities, which stays the lead-'
  'assignment-only timeline with its own title/created_at columns.';


-- ---------------------------------------------------------------------------
-- 6. tasks — CRM to-dos (distinct from lead_tasks, which is assignment-scoped)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  title         text NOT NULL,
  description   text,
  due_at        timestamptz,
  completed_at  timestamptz,
  status        text NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open','done','cancelled')),
  priority      text NOT NULL DEFAULT 'medium'
                  CHECK (priority IN ('low','medium','high','urgent')),
  assigned_to   text,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id    uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id       uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tasks_tenant_status_due
  ON tasks (tenant_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_tasks_tenant_assigned
  ON tasks (tenant_id, assigned_to) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_tasks_company
  ON tasks (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tasks_contact
  ON tasks (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tasks_deal
  ON tasks (deal_id) WHERE deal_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_tasks_updated_at ON tasks;
CREATE TRIGGER trg_tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE tasks IS
  'CRM tasks against companies/contacts/deals. Separate from lead_tasks, '
  'which is scoped to a lead_assignment.';


-- ---------------------------------------------------------------------------
-- 7. notes
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  body          text NOT NULL,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id    uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id       uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notes_tenant_created
  ON notes (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_company
  ON notes (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notes_contact
  ON notes (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notes_deal
  ON notes (deal_id) WHERE deal_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_notes_updated_at ON notes;
CREATE TRIGGER trg_notes_updated_at BEFORE UPDATE ON notes
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();


-- ---------------------------------------------------------------------------
-- 8. custom_field_defs — schema for the custom_fields jsonb on each entity
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS custom_field_defs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  entity_type   text NOT NULL CHECK (entity_type IN ('company','contact','deal')),
  field_key     text NOT NULL,
  label         text NOT NULL,
  field_type    text NOT NULL DEFAULT 'text'
                  CHECK (field_type IN ('text','number','date','select','bool')),
  options       jsonb NOT NULL DEFAULT '[]',   -- choices when field_type = 'select'
  position      int   NOT NULL DEFAULT 0,
  required      boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, entity_type, field_key)
);

CREATE INDEX IF NOT EXISTS idx_custom_field_defs_tenant_entity
  ON custom_field_defs (tenant_id, entity_type, position);

DROP TRIGGER IF EXISTS trg_custom_field_defs_updated_at ON custom_field_defs;
CREATE TRIGGER trg_custom_field_defs_updated_at BEFORE UPDATE ON custom_field_defs
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE custom_field_defs IS
  'Declares the keys allowed in companies/contacts/deals.custom_fields jsonb, '
  'and how the UI should render them.';


-- ---------------------------------------------------------------------------
-- 9. email_log
--
-- Complements email_sends (sql/014), which is the lead-engine outreach ledger
-- keyed by assignment/lead. email_log is the CRM-side record keyed by
-- contact/deal. Both are kept; neither is modified.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS email_log (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  to_email            text NOT NULL,
  from_email          text,
  subject             text,
  body_preview        text,
  status              text NOT NULL DEFAULT 'queued'
                        CHECK (status IN ('queued','sent','failed','bounced','opened','replied')),
  provider            text,
  provider_message_id text,
  error               text,
  contact_id          uuid REFERENCES contacts(id) ON DELETE SET NULL,
  deal_id             uuid REFERENCES deals(id) ON DELETE SET NULL,
  assignment_id       uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  sent_at             timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_log_tenant_sent
  ON email_log (tenant_id, sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_log_tenant_status
  ON email_log (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_email_log_contact
  ON email_log (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_deal
  ON email_log (deal_id) WHERE deal_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_assignment
  ON email_log (assignment_id) WHERE assignment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_provider_msg
  ON email_log (provider_message_id) WHERE provider_message_id IS NOT NULL;


-- ---------------------------------------------------------------------------
-- 10. call_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS call_log (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id       uuid REFERENCES contacts(id) ON DELETE SET NULL,
  deal_id          uuid REFERENCES deals(id) ON DELETE SET NULL,
  assignment_id    uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  direction        text CHECK (direction IS NULL OR direction IN ('inbound','outbound')),
  duration_minutes int,
  outcome          text,
  notes            text,
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  created_by       uuid,
  created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_call_log_tenant_occurred
  ON call_log (tenant_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_log_contact
  ON call_log (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_call_log_deal
  ON call_log (deal_id) WHERE deal_id IS NOT NULL;

-- =============================================================================
-- Row-Level Security
--
-- Exact pattern from sql/004_rls_and_auth.sql: membership is gated through
-- tenant_members via public.is_tenant_member() / public.is_tenant_admin().
-- Service role bypasses RLS (that is how the backend pipeline writes).
-- Every policy is dropped before create so this file is re-runnable.
--
-- Reads + writes are member-scoped; DELETE is admin-only on the four
-- durable record types (companies, contacts, deals, deal_stages) and on
-- custom_field_defs, matching how 004 restricts assignments_delete.
-- =============================================================================

DO $$ BEGIN
  IF to_regclass('public.companies') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE companies ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.contacts') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE contacts ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.deal_stages') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE deal_stages ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.deals') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE deals ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.activities') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE activities ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.tasks') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tasks ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.notes') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE notes ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.custom_field_defs') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE custom_field_defs ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.email_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE email_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.call_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE call_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- companies
DROP POLICY IF EXISTS companies_select ON companies;
CREATE POLICY companies_select ON companies FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_insert ON companies;
CREATE POLICY companies_insert ON companies FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_update ON companies;
CREATE POLICY companies_update ON companies FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_delete ON companies;
CREATE POLICY companies_delete ON companies FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- contacts
DROP POLICY IF EXISTS contacts_select ON contacts;
CREATE POLICY contacts_select ON contacts FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_insert ON contacts;
CREATE POLICY contacts_insert ON contacts FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_update ON contacts;
CREATE POLICY contacts_update ON contacts FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_delete ON contacts;
CREATE POLICY contacts_delete ON contacts FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- deal_stages: everyone reads, admins reshape the pipeline
DROP POLICY IF EXISTS deal_stages_select ON deal_stages;
CREATE POLICY deal_stages_select ON deal_stages FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deal_stages_write ON deal_stages;
CREATE POLICY deal_stages_write ON deal_stages FOR ALL
  USING (public.is_tenant_admin(tenant_id))
  WITH CHECK (public.is_tenant_admin(tenant_id));

-- deals
DROP POLICY IF EXISTS deals_select ON deals;
CREATE POLICY deals_select ON deals FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_insert ON deals;
CREATE POLICY deals_insert ON deals FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_update ON deals;
CREATE POLICY deals_update ON deals FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_delete ON deals;
CREATE POLICY deals_delete ON deals FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- activities / tasks / notes: full member access (matches 004's *_all pattern)
DROP POLICY IF EXISTS activities_all ON activities;
CREATE POLICY activities_all ON activities FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS crm_tasks_all ON tasks;
CREATE POLICY crm_tasks_all ON tasks FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS notes_all ON notes;
CREATE POLICY notes_all ON notes FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

-- custom_field_defs: members read the schema, admins change it
DROP POLICY IF EXISTS custom_field_defs_select ON custom_field_defs;
CREATE POLICY custom_field_defs_select ON custom_field_defs FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS custom_field_defs_write ON custom_field_defs;
CREATE POLICY custom_field_defs_write ON custom_field_defs FOR ALL
  USING (public.is_tenant_admin(tenant_id))
  WITH CHECK (public.is_tenant_admin(tenant_id));

-- email_log / call_log: read-only to members; writes come from the backend
-- (service role) so no INSERT policy is granted to authenticated clients.
DROP POLICY IF EXISTS email_log_select ON email_log;
CREATE POLICY email_log_select ON email_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS call_log_select ON call_log;
CREATE POLICY call_log_select ON call_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
-- Manual call logging from the UI is a member action, so allow inserts there.
DROP POLICY IF EXISTS call_log_insert ON call_log;
CREATE POLICY call_log_insert ON call_log FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));


-- =============================================================================
-- Tags: decision recorded
--
-- Tags in this schema are the `tags text[]` columns on companies, contacts and
-- deals, GIN-indexed for `@>` / Supabase `.contains()` lookups. This matches
-- the pattern already used by lead_assignments.tags (sql/015) and keeps
-- filtering to a single index-backed predicate with no join.
--
-- Consequences accepted: no rename-in-one-place, no per-tag colour or usage
-- count. If those become requirements, add tags + taggings later and backfill
-- from these arrays — do NOT run both models at once.
--
-- The existing lead_tags table is a different thing (one row per tag per lead
-- ASSIGNMENT, in the lead engine) and is left untouched.
-- =============================================================================

COMMENT ON COLUMN companies.tags IS 'Free-form tags; GIN-indexed. Canonical tag store for this entity — there is no separate tags table.';
COMMENT ON COLUMN contacts.tags  IS 'Free-form tags; GIN-indexed.';
COMMENT ON COLUMN deals.tags     IS 'Free-form tags; GIN-indexed.';


-- ##### 017_crm_seed.sql #####

-- =============================================================================
-- 017 — CRM demo seed
--
-- Gives a fresh install a populated UI instead of empty states: one demo
-- tenant on a fixed well-known UUID, its lead pipeline stages, its deal
-- stages, and a handful of companies / contacts / deals / activities /
-- tasks / notes.
--
-- Safe to run repeatedly: every INSERT is either ON CONFLICT DO NOTHING on a
-- real unique constraint, or guarded by NOT EXISTS. Re-running changes nothing.
--
-- Run AFTER sql/015_crm_missing_objects.sql and sql/016_crm_full.sql.
--
-- The demo tenant UUID is deterministic so the frontend, tests and fixtures
-- can hardcode it:
--     00000000-0000-0000-0000-00000000d300   ("demo")
-- Delete the tenant to remove everything below — all seeded rows cascade.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. Demo tenant
-- ---------------------------------------------------------------------------
INSERT INTO tenants (id, name, slug, plan, leads_per_month_limit, delivery_channel, status)
VALUES (
  '00000000-0000-0000-0000-00000000d300',
  'Demo Agency',
  'demo-agency',
  'growth',
  500,
  'portal',
  'active'
)
ON CONFLICT (id) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 2. Lead pipeline stages (lead engine) — reuse the function from 015 so the
--    demo tenant gets exactly the same pipeline a real tenant gets.
-- ---------------------------------------------------------------------------
SELECT public.seed_default_stages('00000000-0000-0000-0000-00000000d300'::uuid);


-- ---------------------------------------------------------------------------
-- 3. Deal stages (CRM) — UNIQUE (tenant_id, slug) makes this idempotent
-- ---------------------------------------------------------------------------
INSERT INTO deal_stages (tenant_id, name, slug, position, color, probability, is_won, is_lost)
VALUES
  ('00000000-0000-0000-0000-00000000d300', 'Discovery',   'discovery',   1, '#94a3b8',  10, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Qualified',   'qualified',   2, '#3b82f6',  25, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Proposal',    'proposal',    3, '#8b5cf6',  50, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Negotiation', 'negotiation', 4, '#f59e0b',  75, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Closed Won',  'closed-won',  5, '#22c55e', 100, true,  false),
  ('00000000-0000-0000-0000-00000000d300', 'Closed Lost', 'closed-lost', 6, '#ef4444',   0, false, true)
ON CONFLICT (tenant_id, slug) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 4. Custom field definitions
-- ---------------------------------------------------------------------------
INSERT INTO custom_field_defs (tenant_id, entity_type, field_key, label, field_type, options, position, required)
VALUES
  ('00000000-0000-0000-0000-00000000d300', 'company', 'locations',      'Locations',        'number', '[]', 1, false),
  ('00000000-0000-0000-0000-00000000d300', 'company', 'booking_system', 'Booking System',   'select',
     '["Mindbody","Square","Vagaro","Boulevard","None"]', 2, false),
  ('00000000-0000-0000-0000-00000000d300', 'contact', 'best_time',      'Best Time to Call','select',
     '["Morning","Afternoon","Evening"]', 1, false),
  ('00000000-0000-0000-0000-00000000d300', 'deal',    'contract_months','Contract (months)','number', '[]', 1, false)
ON CONFLICT (tenant_id, entity_type, field_key) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 5. Companies
--
-- Idempotent via idx_companies_tenant_domain — the partial unique index on
-- (tenant_id, lower(domain)). ON CONFLICT cannot name a partial index
-- directly, so each row is guarded with NOT EXISTS instead. Fixed UUIDs let
-- the contacts/deals below reference them without a lookup.
-- ---------------------------------------------------------------------------
INSERT INTO companies (
  id, tenant_id, name, domain, website, phone, address, city, state, country,
  industry, employee_count, annual_revenue, description, owner, status, tags, custom_fields
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Lumen Medspa', 'lumenmedspa.com', 'https://lumenmedspa.com', '2015550142',
   '412 Washington St', 'Hoboken', 'NJ', 'US',
   'medspa', 14, 1850000.00,
   'Three-location medspa group. Injectables and laser. Actively hiring.',
   'sales@demo-agency.test', 'customer',
   ARRAY['medspa','multi-location','priority'], '{"locations": 3, "booking_system": "Boulevard"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Ironline Fitness', 'ironlinefit.com', 'https://ironlinefit.com', '2015550188',
   '77 Hudson Pl', 'Jersey City', 'NJ', 'US',
   'gym', 22, 2400000.00,
   'Strength-focused gym. No online booking — strong automation fit.',
   'sales@demo-agency.test', 'prospect',
   ARRAY['gym','inbound'], '{"locations": 1, "booking_system": "None"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Bright Smile Dental', 'brightsmiledental.com', 'https://brightsmiledental.com', '2015550204',
   '1200 Bloomfield St', 'Hoboken', 'NJ', 'US',
   'dental', 9, 1200000.00,
   'Family dental practice. Two chairs idle midweek.',
   'ae2@demo-agency.test', 'prospect',
   ARRAY['dental'], '{"locations": 1, "booking_system": "Square"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Coastal Hair Studio', 'coastalhairstudio.com', 'https://coastalhairstudio.com', '2015550311',
   '58 Newark St', 'Hoboken', 'NJ', 'US',
   'salon', 6, 480000.00,
   'Boutique salon. Owner-operated, books by phone only.',
   'ae2@demo-agency.test', 'active',
   ARRAY['salon','small'], '{"locations": 1}'::jsonb),

  ('00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Verity Legal Group', 'veritylegal.com', 'https://veritylegal.com', '2015550377',
   '30 Montgomery St', 'Jersey City', 'NJ', 'US',
   'legal', 31, 5600000.00,
   'Mid-size firm. Intake handled by an answering service today.',
   'sales@demo-agency.test', 'churned',
   ARRAY['legal','enterprise'], '{}'::jsonb)
) AS v(id, tenant_id, name, domain, website, phone, address, city, state, country,
       industry, employee_count, annual_revenue, description, owner, status, tags, custom_fields)
WHERE NOT EXISTS (SELECT 1 FROM companies c WHERE c.id = v.id);

-- ---------------------------------------------------------------------------
-- 6. Contacts
--
-- Note idx_contacts_one_primary: at most one is_primary contact per company,
-- so the second contact at Lumen is deliberately not primary.
-- ---------------------------------------------------------------------------
INSERT INTO contacts (
  id, tenant_id, company_id, full_name, first_name, last_name, title,
  email, phone, mobile, linkedin_url, is_primary, is_decision_maker,
  owner, status, tags, custom_fields, do_not_contact
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   'Dana Reyes', 'Dana', 'Reyes', 'Owner',
   'dana@lumenmedspa.com', '2015550142', '2015550143',
   'https://www.linkedin.com/in/dana-reyes-demo', true, true,
   'sales@demo-agency.test', 'active', ARRAY['decision-maker'],
   '{"best_time": "Morning"}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   'Priya Shah', 'Priya', 'Shah', 'Operations Manager',
   'priya@lumenmedspa.com', '2015550144', NULL,
   NULL, false, false,
   'sales@demo-agency.test', 'active', ARRAY['influencer'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c002'::uuid,
   'Marcus Hale', 'Marcus', 'Hale', 'Founder',
   'marcus@ironlinefit.com', '2015550188', '2015550189',
   'https://www.linkedin.com/in/marcus-hale-demo', true, true,
   'sales@demo-agency.test', 'active', ARRAY['decision-maker','warm'],
   '{"best_time": "Evening"}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   'Dr. Alan Whitfield', 'Alan', 'Whitfield', 'Practice Owner',
   'alan@brightsmiledental.com', '2015550204', NULL,
   NULL, true, true,
   'ae2@demo-agency.test', 'active', ARRAY['decision-maker'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c004'::uuid,
   'Nina Alvarez', 'Nina', 'Alvarez', 'Owner / Stylist',
   'nina@coastalhairstudio.com', '2015550311', NULL,
   NULL, true, true,
   'ae2@demo-agency.test', 'active', ARRAY['decision-maker'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a006'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c005'::uuid,
   'Grant Okafor', 'Grant', 'Okafor', 'Managing Partner',
   'grant@veritylegal.com', '2015550377', NULL,
   NULL, true, true,
   'sales@demo-agency.test', 'unqualified', ARRAY['do-not-call'],
   '{}'::jsonb, true)
) AS v(id, tenant_id, company_id, full_name, first_name, last_name, title,
       email, phone, mobile, linkedin_url, is_primary, is_decision_maker,
       owner, status, tags, custom_fields, do_not_contact)
WHERE NOT EXISTS (SELECT 1 FROM contacts c WHERE c.id = v.id);


-- ---------------------------------------------------------------------------
-- 7. Deals — stage_id resolved by slug so this survives stage re-ordering
-- ---------------------------------------------------------------------------
INSERT INTO deals (
  id, tenant_id, company_id, primary_contact_id, title, description,
  value, currency, stage_id, probability, expected_close_date,
  actual_close_date, status, lost_reason, owner, source, tags, custom_fields
)
SELECT
  v.id, v.tenant_id, v.company_id, v.primary_contact_id, v.title, v.description,
  v.value, v.currency,
  (SELECT ds.id FROM deal_stages ds
    WHERE ds.tenant_id = v.tenant_id AND ds.slug = v.stage_slug),
  v.probability, v.expected_close_date, v.actual_close_date, v.status,
  v.lost_reason, v.owner, v.source, v.tags, v.custom_fields
FROM (VALUES
  ('00000000-0000-0000-0000-0000000dd001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   'Lumen Medspa — 3-location automation rollout',
   'Booking automation plus reactivation campaign across all three locations.',
   36000.00, 'USD', 'negotiation', 75,
   (CURRENT_DATE + 21), NULL, 'open', NULL,
   'sales@demo-agency.test', 'referral',
   ARRAY['expansion'], '{"contract_months": 12}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   'Ironline Fitness — inbound booking build',
   'No online booking today. Replace phone-only intake.',
   14400.00, 'USD', 'proposal', 50,
   (CURRENT_DATE + 30), NULL, 'open', NULL,
   'sales@demo-agency.test', 'lead_engine',
   ARRAY['new-logo'], '{"contract_months": 6}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000a004'::uuid,
   'Bright Smile Dental — midweek fill campaign',
   'Fill idle midweek chair time with a recall campaign.',
   9600.00, 'USD', 'qualified', 25,
   (CURRENT_DATE + 45), NULL, 'open', NULL,
   'ae2@demo-agency.test', 'lead_engine',
   ARRAY['new-logo'], '{"contract_months": 6}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000a005'::uuid,
   'Coastal Hair Studio — starter retainer',
   'Single-location starter package. Signed after one call.',
   4800.00, 'USD', 'closed-won', 100,
   (CURRENT_DATE - 12), (CURRENT_DATE - 12), 'won', NULL,
   'ae2@demo-agency.test', 'referral',
   ARRAY['won'], '{"contract_months": 12}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   'Verity Legal Group — intake automation',
   'Lost to an incumbent answering service on price.',
   28000.00, 'USD', 'closed-lost', 0,
   (CURRENT_DATE - 30), (CURRENT_DATE - 25), 'lost', 'Price — incumbent undercut',
   'sales@demo-agency.test', 'outbound',
   ARRAY['lost'], '{}'::jsonb)
) AS v(id, tenant_id, company_id, primary_contact_id, title, description,
       value, currency, stage_slug, probability, expected_close_date,
       actual_close_date, status, lost_reason, owner, source, tags, custom_fields)
WHERE NOT EXISTS (SELECT 1 FROM deals d WHERE d.id = v.id);


-- ---------------------------------------------------------------------------
-- 8. Activities — the timeline the UI renders
-- ---------------------------------------------------------------------------
INSERT INTO activities (
  id, tenant_id, activity_type, subject, body, direction,
  occurred_at, duration_minutes, outcome, company_id, contact_id, deal_id, meta
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000a0001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'call', 'Discovery call — Dana Reyes',
   'Walked through the three-location booking gap. Wants a rollout plan.',
   'outbound', (now() - interval '9 days'), 28, 'connected',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'email', 'Sent proposal v2',
   'Revised pricing for 12 months across 3 locations.',
   'outbound', (now() - interval '4 days'), NULL, 'sent',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid, '{"attachment": "proposal-v2.pdf"}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'meeting', 'On-site demo at Ironline',
   'Demoed booking flow on the front-desk tablet.',
   'outbound', (now() - interval '6 days'), 45, 'positive',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'note', 'Budget cycle note', 'Dental budget resets next quarter — time the close.',
   NULL, (now() - interval '2 days'), NULL, NULL,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000a004'::uuid,
   '00000000-0000-0000-0000-0000000dd003'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'stage_change', 'Moved to Closed Won', 'Contract signed, 12 months.',
   NULL, (now() - interval '12 days'), NULL, 'won',
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000a005'::uuid,
   '00000000-0000-0000-0000-0000000dd004'::uuid,
   '{"from": "negotiation", "to": "closed-won"}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0006'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'call', 'Inbound — Verity Legal declined',
   'Chose to keep their answering service. Revisit in 6 months.',
   'inbound', (now() - interval '25 days'), 11, 'lost',
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   '00000000-0000-0000-0000-0000000dd005'::uuid, '{}'::jsonb)
) AS v(id, tenant_id, activity_type, subject, body, direction,
       occurred_at, duration_minutes, outcome, company_id, contact_id, deal_id, meta)
WHERE NOT EXISTS (SELECT 1 FROM activities a WHERE a.id = v.id);


-- ---------------------------------------------------------------------------
-- 9. Tasks
-- ---------------------------------------------------------------------------
INSERT INTO tasks (
  id, tenant_id, title, description, due_at, completed_at, status,
  priority, assigned_to, company_id, contact_id, deal_id
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-000000000001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Follow up on Lumen proposal v2',
   'Chase Dana for a decision on the 12-month term.',
   (now() + interval '1 day'), NULL, 'open', 'high',
   'sales@demo-agency.test',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid),

  ('00000000-0000-0000-0000-000000000002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Send Ironline the security questionnaire', NULL,
   (now() + interval '3 days'), NULL, 'open', 'medium',
   'sales@demo-agency.test',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid),

  ('00000000-0000-0000-0000-000000000003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Book Bright Smile technical review', NULL,
   (now() + interval '7 days'), NULL, 'open', 'low',
   'ae2@demo-agency.test',
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000a004'::uuid,
   '00000000-0000-0000-0000-0000000dd003'::uuid),

  ('00000000-0000-0000-0000-000000000004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Kick off Coastal Hair onboarding', 'Signed — hand to delivery.',
   (now() - interval '10 days'), (now() - interval '9 days'), 'done', 'high',
   'ae2@demo-agency.test',
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000a005'::uuid,
   '00000000-0000-0000-0000-0000000dd004'::uuid)
) AS v(id, tenant_id, title, description, due_at, completed_at, status,
       priority, assigned_to, company_id, contact_id, deal_id)
WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.id = v.id);


-- ---------------------------------------------------------------------------
-- 10. Notes
-- ---------------------------------------------------------------------------
INSERT INTO notes (id, tenant_id, body, company_id, contact_id, deal_id)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-000000000001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Dana prefers morning calls. Priya handles scheduling day to day.',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   NULL::uuid),

  ('00000000-0000-0000-0000-000000000002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Marcus is price sensitive but moves fast once convinced.',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid),

  ('00000000-0000-0000-0000-000000000003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Verity: do not call — contact flagged do_not_contact. Email only, after Q3.',
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   NULL::uuid)
) AS v(id, tenant_id, body, company_id, contact_id, deal_id)
WHERE NOT EXISTS (SELECT 1 FROM notes n WHERE n.id = v.id);


-- ---------------------------------------------------------------------------
-- 11. Email + call logs
-- ---------------------------------------------------------------------------
INSERT INTO email_log (
  id, tenant_id, to_email, from_email, subject, body_preview,
  status, provider, provider_message_id, contact_id, deal_id, sent_at
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000e0001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'dana@lumenmedspa.com', 'sales@demo-agency.test',
   'Revised proposal — Lumen Medspa',
   'Hi Dana, attached is v2 with the 12-month pricing we discussed...',
   'opened', 'resend', 'demo-msg-0001',
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid,
   (now() - interval '4 days')),

  ('00000000-0000-0000-0000-0000000e0002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'marcus@ironlinefit.com', 'sales@demo-agency.test',
   'Recap + next steps',
   'Great meeting you both — here is the booking flow we demoed...',
   'replied', 'resend', 'demo-msg-0002',
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid,
   (now() - interval '5 days'))
) AS v(id, tenant_id, to_email, from_email, subject, body_preview,
       status, provider, provider_message_id, contact_id, deal_id, sent_at)
WHERE NOT EXISTS (SELECT 1 FROM email_log el WHERE el.id = v.id);

INSERT INTO call_log (
  id, tenant_id, contact_id, deal_id, direction,
  duration_minutes, outcome, notes, occurred_at
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-000000000001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid,
   'outbound', 28, 'connected',
   'Discovery. Confirmed budget owner is Dana.',
   (now() - interval '9 days')),

  ('00000000-0000-0000-0000-000000000002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   '00000000-0000-0000-0000-0000000dd005'::uuid,
   'inbound', 11, 'lost',
   'Declined. Revisit in 6 months.',
   (now() - interval '25 days'))
) AS v(id, tenant_id, contact_id, deal_id, direction,
       duration_minutes, outcome, notes, occurred_at)
WHERE NOT EXISTS (SELECT 1 FROM call_log cl WHERE cl.id = v.id);


-- ---------------------------------------------------------------------------
-- Done. To wipe the demo data entirely (everything above cascades):
--   DELETE FROM tenants WHERE id = '00000000-0000-0000-0000-00000000d300';
--
-- NOTE: no tenant_members row is seeded, because membership must bind to a
-- real Supabase auth.users id. To log into the demo tenant, create the auth
-- user first, then:
--   INSERT INTO tenant_members (tenant_id, auth_user_id, email, role, status)
--   VALUES ('00000000-0000-0000-0000-00000000d300', '<auth uid>',
--           '<email>', 'owner', 'active')
--   ON CONFLICT (tenant_id, auth_user_id) DO NOTHING;
-- Until then the seeded rows are only visible to the service role, since RLS
-- gates every table on tenant_members.
-- ---------------------------------------------------------------------------


-- ##### lead-crm-portal/sql/003_crm_portal_schema.sql #####

-- =============================================================================
-- Client CRM Portal — extends Lead Engine v2
-- Pipeline stages, activities, notes, tasks, tags, team, audit
-- =============================================================================

-- Pipeline stages (per tenant, customizable)
CREATE TABLE IF NOT EXISTS pipeline_stages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,                 -- New, Contacted, Qualified, Proposal, Won, Lost
  slug        text NOT NULL,                 -- new, contacted, qualified, proposal, won, lost
  position    int  NOT NULL DEFAULT 0,
  color       text NOT NULL DEFAULT '#6366f1',
  is_won      boolean NOT NULL DEFAULT false,
  is_lost     boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_stages_tenant ON pipeline_stages (tenant_id, position);

-- Default stages helper already defined above as public.seed_default_stages RETURNS int.
-- Second void copy removed to avoid: cannot change return type of existing function.
-- DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);  -- only if you need to recreate


-- Extend lead_assignments with CRM fields
ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id       uuid REFERENCES pipeline_stages(id),
  ADD COLUMN IF NOT EXISTS assigned_to    uuid,          -- team member user id
  ADD COLUMN IF NOT EXISTS priority       text DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','urgent')),
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(12,2),
  ADD COLUMN IF NOT EXISTS source_campaign text,
  ADD COLUMN IF NOT EXISTS custom_fields  jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags           text[] DEFAULT '{}';

CREATE INDEX IF NOT EXISTS idx_assignments_stage ON lead_assignments (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_assignments_assignee ON lead_assignments (tenant_id, assigned_to);
CREATE INDEX IF NOT EXISTS idx_assignments_next_action ON lead_assignments (tenant_id, next_action_at)
  WHERE next_action_at IS NOT NULL;

-- Activities (calls, emails, notes, status changes, system events)
CREATE TABLE IF NOT EXISTS lead_activities (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  actor_id      uuid,                          -- team member who did it (null = system)
  activity_type text NOT NULL CHECK (activity_type IN (
    'note','call','email','sms','meeting','stage_change','status_change',
    'task_created','task_completed','enrichment','system','other'
  )),
  title         text,
  body          text,
  meta          jsonb DEFAULT '{}',            -- duration, outcome, from_stage, to_stage, etc.
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_activities_assignment ON lead_activities (assignment_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activities_tenant ON lead_activities (tenant_id, created_at DESC);

-- Tasks / follow-ups
CREATE TABLE IF NOT EXISTS lead_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assigned_to   uuid,
  created_by    uuid,
  title         text NOT NULL,
  description   text,
  due_at        timestamptz,
  completed_at  timestamptz,
  status        text NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','done','cancelled')),
  priority      text NOT NULL DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','urgent')),
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tasks_open ON lead_tasks (tenant_id, status, due_at)
  WHERE status = 'open';

-- Tags dictionary (per tenant)
CREATE TABLE IF NOT EXISTS lead_tags (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id  uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name       text NOT NULL,
  color      text DEFAULT '#64748b',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name)
);

-- Team members (portal users for a tenant)
CREATE TABLE IF NOT EXISTS tenant_members (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  full_name   text,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  auth_user_id uuid,                           -- Supabase auth.users id
  avatar_url  text,
  last_login_at timestamptz,
  status      text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','invited','disabled')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_members_tenant ON tenant_members (tenant_id, status);

-- Saved filters / segments
CREATE TABLE IF NOT EXISTS lead_segments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
  filters     jsonb NOT NULL DEFAULT '{}',    -- { tier: ['A'], stage: ['qualified'], tags: [...] }
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Audit log
CREATE TABLE IF NOT EXISTS crm_audit_log (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  actor_id    uuid,
  action      text NOT NULL,                  -- lead.stage_change, lead.export, settings.update
  entity_type text,
  entity_id   uuid,
  before      jsonb,
  after       jsonb,
  ip          text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_tenant ON crm_audit_log (tenant_id, created_at DESC);

-- Client portal sessions helper view: assignment + lead + enrichment + score + stage
DROP VIEW IF EXISTS crm_lead_cards CASCADE;
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  la.id AS assignment_id,
  la.tenant_id,
  la.lead_id,
  la.status AS assignment_status,
  la.delivery_status,
  la.delivered_at,
  la.priority,
  la.next_action_at,
  la.last_contacted_at,
  la.value_estimate,
  la.tags,
  la.custom_fields,
  la.assigned_to,
  la.stage_id,
  ps.name AS stage_name,
  ps.slug AS stage_slug,
  ps.color AS stage_color,
  ps.position AS stage_position,
  lg.name AS company_name,
  lg.phone_normalized,
  lg.phone_e164,
  lg.website,
  lg.address,
  lg.city,
  lg.state,
  lg.business_status,
  lg.google_rating,
  lg.review_count,
  lg.category,
  e.email,
  e.email_valid,
  e.has_booking,
  e.booking_platform,
  e.services,
  e.social_links,
  e.owner_name,
  e.enrichment_ok,
  s.total_score,
  s.tier,
  s.reasoning AS score_reasoning
FROM lead_assignments la
JOIN leads_global lg ON lg.id = la.lead_id
LEFT JOIN enrichment e ON e.lead_id = lg.id
LEFT JOIN scores s ON s.lead_id = lg.id
LEFT JOIN pipeline_stages ps ON ps.id = la.stage_id;


-- ##### FINAL ensure pipeline_run_leads (run board) #####
CREATE TABLE IF NOT EXISTS public.pipeline_run_leads (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.pipeline_runs(id) on delete cascade,
  lead_id uuid not null references public.leads_global(id) on delete cascade,
  tenant_id uuid references public.tenants(id) on delete set null,
  stage text not null default 'discovered',
  tier text,
  included boolean not null default true,
  score int,
  source text,
  name text,
  phone text,
  website text,
  city text,
  position int default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (run_id, lead_id)
);
CREATE INDEX IF NOT EXISTS idx_prl_run ON public.pipeline_run_leads(run_id);
CREATE INDEX IF NOT EXISTS idx_prl_tenant ON public.pipeline_run_leads(tenant_id);
CREATE INDEX IF NOT EXISTS idx_prl_stage ON public.pipeline_run_leads(run_id, stage);
-- Allow LinkedIn li_at cookies (and related providers) in api_key_pool
-- Error fixed: violates check constraint "api_key_pool_provider_check"

ALTER TABLE public.api_key_pool
  DROP CONSTRAINT IF EXISTS api_key_pool_provider_check;

ALTER TABLE public.api_key_pool
  ADD CONSTRAINT api_key_pool_provider_check
  CHECK (provider IN (
    'serper',
    'firecrawl',
    'anthropic',
    'gemini',
    'groq',
    'openai',
    'resend',
    'linkedin_scraper',
    'linkedin',
    'instagram',
    'twilio',
    'vapi',
    'scrapingbee',
    'bright_data'
  ));
