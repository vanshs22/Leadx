# LeadX Exhaustive Discovery

LeadX discovery is now **exhaustive by default** for pipeline runs.

## What changed

`limit_per_location` is no longer a discovery ceiling when `exhaustive_discovery=true` (the default). The engine collects from multiple independent sources and partitions the search space instead of stopping at 100/500 records.

### Discovery layers

1. **Google/Serper Maps** — deep page iteration for every expanded query.
2. **Google Places API (optional)** — direct API adapter with page-token traversal when `GOOGLE_MAPS_API_KEY` or `GOOGLE_PLACES_API_KEY` is configured.
3. **OpenStreetMap/Overpass** — geographic tiling across the complete geocoded area. This is an independent POI database and can surface businesses absent from Maps/search.
4. **Foursquare Places (optional)** — geographic tiling with up to 50 results per request when `FOURSQUARE_API_KEY` or `FSQ_API_KEY` is configured.
5. **Organic web/search** — multiple query families and search pages for official sites, directories, Yelp, Facebook and long-tail discovery.
6. Existing LinkedIn/Instagram discovery remains available through the broader discovery stack.

## No artificial 100/500 cap

The engine stops because a source/partition is exhausted, not because a fixed location quota was reached. Query expansion and geographic cells are used to reach additional businesses.

This is still bounded by the actual coverage and API/rate limits of third-party providers. No external API can truthfully guarantee every business in a geographic area.

## Enrichment

Every discovered canonical entity continues into the existing enrichment pipeline. Website enrichment runs in chunks so large runs do not create one giant asyncio task graph. Social enrichment is no longer silently limited to the first 40 leads during exhaustive runs.

Enrichment can extract:

- official website/domain
- email(s) and email validity
- phone from website
- booking platform / online booking
- services
- social links
- owner/manager name where available
- crawl/markdown summary
- raw extraction evidence

## Optional providers

Set these in runtime configuration:

- `GOOGLE_MAPS_API_KEY` or `GOOGLE_PLACES_API_KEY`
- `FOURSQUARE_API_KEY` or `FSQ_API_KEY`
- `OVERPASS_URL` (optional override)
- `NOMINATIM_URL` (optional override)
- `SERPER_MAX_PAGES` (default 100)
- `SERPER_WEB_MAX_PAGES` (default 20)
- `OSM_MAX_CELLS` (default 64)
- `ENRICH_BATCH_SIZE` (default 100)
- `DISCOVERY_PAGE_DELAY` (default 0.35 seconds)

## Important operational behavior

An exhaustive run may produce thousands or tens of thousands of raw entities for a large geography. Use the durable worker/queue in production, keep provider concurrency/rate limits conservative, and monitor provider spend. The database remains the system of record and entity resolution deduplicates records across sources before enrichment/storage.
