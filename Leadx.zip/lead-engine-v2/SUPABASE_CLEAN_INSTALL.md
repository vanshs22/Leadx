# LeadX 3.0 clean Supabase install

If this Supabase project is dedicated to LeadX and you want a completely clean schema:

1. Run `sql/000_CLEAN_LEADX_SCHEMA.sql` once.
2. Confirm it finishes without an error.
3. Run `sql/000_ALL_IN_ONE_migration.sql` once, from top to bottom.
4. Do **not** also run `SUPABASE_FULL_MIGRATION.sql` on the same fresh database.
5. The migration is idempotent and also contains compatibility repairs for older partial schemas, including the `observed_at` error.

This reset does **not** delete `auth.users`; it only removes objects in the `public` schema.

If the project contains anything unrelated to LeadX, do not run the clean reset.
