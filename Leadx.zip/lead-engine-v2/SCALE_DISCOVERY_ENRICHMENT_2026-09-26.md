# LeadX — High-Volume Discovery & Enrichment Upgrade

## Objective

Remove artificial 1k–2k ICP ceilings and build a multi-source, waterfall prospecting path capable of accumulating tens of thousands of canonical businesses when the underlying sources contain that many records.

## Architecture

```text
ICP
  ↓
Geo expansion / coverage frontier
  ↓
Query matrix
  ├─ Google/Serper Maps
  ├─ Organic Google/Serper
  │   ├─ Yelp
  │   ├─ Yellow Pages
  │   ├─ BBB
  │   ├─ Manta
  │   ├─ Superpages
  │   ├─ MapQuest
  │   ├─ Chamber of Commerce
  │   ├─ Foursquare
  │   ├─ TripAdvisor
  │   └─ other indexed directories
  ├─ LinkedIn public indexed pages
  ├─ Instagram public indexed pages
  ├─ Facebook public indexed pages
  └─ OpenStreetMap / Overpass
  ↓
Saturation pagination
  ↓
Canonical fingerprint/entity resolution
  ↓
Durable leads_global inventory
  ↓
Enrichment waterfall
  ├─ Scrapling
  ├─ Crawl4AI
  ├─ internal contact/about/team/services/location pages
  ├─ Firecrawl last resort
  └─ public Serper contact/decision-maker search
  ↓
MX verification + phone normalization
  ↓
LinkedIn + signals + intent + opportunity intelligence
  ↓
Quality gate / CRM / delivery
```

## Why this scales

A single search query cannot represent an entire market. Google Places Text Search itself documents a maximum of 60 results across pages for one query. LeadX therefore partitions the search space by:

- business terminology
- service/subcategory terminology
- location
- directory domain
- social domain
- independent POI database
- repeated provider pages until saturation

This makes the result count a property of source coverage, geography, terminology and provider quotas—not a hard LeadX 100/500/1000/2000 cap.

## Free/public default

Default discovery requires only:

- Serper free-tier/key pool
- OpenStreetMap/Overpass
- public indexed web pages
- Scrapling
- optional Crawl4AI
- Firecrawl free-tier/key pool for fallback

Google Places and Foursquare direct APIs are disabled by default and are opt-in adapters.

## Enrichment waterfall

The website crawler no longer treats the homepage as the whole company. It checks high-value internal pages such as contact, about, team, staff, services, locations, booking and appointments, plus relevant navigation links.

Missing contact/decision-maker data can then be recovered from indexed public search results.

Email quality is subsequently checked through the existing syntax + MX verification path; SMTP probing is intentionally avoided.

## Durable scale behavior

Exhaustive runs now persist raw discoveries to `leads_global` in batches before expensive enrichment. If enrichment or an external provider fails halfway through a 50k run, the discovered inventory remains durable and can be enriched later.

Enrichment is chunked using `ENRICH_BATCH_SIZE` rather than constructing one giant asyncio task graph.

## Important limitation

No free/public source can truthfully guarantee every business in a geographic market. Search engines and directories have their own indexes, coverage gaps and rate limits. “Exhaustive” therefore means exhaustive across the enabled source partitions until those sources saturate. Repeated runs accumulate the persistent LeadX global universe.
