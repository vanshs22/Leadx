# LeadX Autonomous Admin Campaigns

LeadX now has a separate operator-only autonomous outbound engine. The existing client discovery-request and client portal flows are unchanged.

## Flow

`Admin ICP -> discovery -> global inventory -> enrichment -> score/quality gate -> assignment -> AI per-lead copy -> email sequence -> follow-ups -> reply/opt-out stop -> attribution`

## Controls

Each campaign has:

- ICP and/or search locations/queries
- daily new-lead limit
- daily email limit (initial touches + follow-ups share the same campaign budget)
- maximum active enrollments
- score threshold
- discovery cadence
- recipient-local business-hour and domain warm-up gates
- AI copy toggle
- automatic follow-up
- automatic reply/opt-out stop
- per-campaign daily counters
- durable sequence state and idempotency
- per-lead AI copy cache so a step is not regenerated unnecessarily

## Safety

The existing outbound safety layers remain authoritative:

- tenant/global suppression and opt-out
- MX/deliverability checks
- recipient-local sending windows
- minimum touch gap
- domain warm-up and daily domain caps
- SES provider limits
- durable sequence claims and idempotency
- reply classification and stop behavior

Opt-out handling remains fail-safe and is not weakened by campaign configuration.

## Admin UX

`Admin -> Autonomous growth` provides a card-based control room with:

- campaign creation
- ICP selection
- daily limits
- offer/goal
- drag-and-drop sequence steps
- activation/pause
- run-now
- live daily counters
- reply/opt-out state visibility

The client portal continues to use the existing request -> admin approval -> delivery workflow.
