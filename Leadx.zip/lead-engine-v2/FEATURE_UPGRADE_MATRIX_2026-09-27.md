# LeadX Feature Upgrade Matrix — 2026-09-27

## Batch 1 — Intelligence/data foundation

1. Evidence ledger
2. Historical lead observations
3. Versioned scoring decisions
4. Lead freshness state
5. Refresh priority/reason
6. Saved structured/natural-language searches
7. Continuous-search metadata
8. Workflow rule storage
9. Workflow execution ledger
10. Provider usage telemetry
11. Estimated provider cost tracking
12. Autonomous campaign state
13. Campaign daily lead budget
14. Campaign daily email budget
15. Atomic email-budget reservations
16. Campaign email-copy cache
17. Lead outcome/QA feedback ledger
18. Active-enrollment capacity
19. Campaign/source attribution on assignments
20. Score threshold support in pipeline
21. Evidence snapshot after enrichment/scoring
22. Automatic high-score refresh scheduling

## Batch 2 — Autonomous operator revenue engine

23. Operator-only campaign UI
24. ICP-driven discovery
25. Multi-location/query discovery
26. Daily discovery automation
27. Daily new-lead cap
28. Daily outbound-email cap
29. AI personalized first touch
30. AI personalized follow-ups
31. Durable sequence enrollment
32. Drag-and-drop sequence ordering
33. Automatic follow-up timing
34. Reply-based sequence stop
35. Opt-out suppression/sequence stop
36. Per-lead copy caching
37. Recipient-local send policy
38. Domain warm-up protection
39. Campaign run-now
40. Campaign pause/resume
41. Admin control-room counters
42. Campaign lifecycle/error state
43. Campaign reply attribution
44. Campaign lead/contact lifecycle attribution

## Batch 3 — CRM/revenue graph

45. Parent/child account hierarchy
46. Multi-location company records
47. Contact personas
48. Contact influence score
49. Contact buying authority roles
50. Contact verification timestamp
51. Deal health score
52. Deal risk flags
53. Deal next-action timestamp
54. Deal competitor field
55. SLA due dates
56. Task reminders
57. Task snoozing
58. Recurring task rule
59. Lead lifecycle stage
60. Lead owner/routing metadata
61. Last-contacted/replied timestamps
62. Revenue attribution records
63. Forecast snapshots
64. Prospect audit artifacts
65. Shareable audit token
66. Client revenue-health dashboard
67. Client SLA dashboard

## Batch 4 — Business integrations/revenue operations

68. Integration connection registry
69. Outbound webhook subscriptions
70. Durable webhook delivery queue
71. Webhook retry/backoff
72. Event signatures
73. Lead-assigned event emission
74. Routing rules
75. Calendar/meeting records
76. Meeting status/outcome
77. Phone-call intelligence records
78. Call transcript/summary storage
79. Pain-point/objection/next-step extraction storage
80. Omnichannel message threads
81. SMS/message ledger
82. Native lead forms
83. Form submission records
84. Proposal/quote records
85. Customer-success health records
86. Renewal/churn-risk fields
87. Expansion-opportunity fields
88. Revenue event ledger
89. Webhook worker automation
90. Admin autonomous-growth navigation

## Existing systems intentionally retained

- Client discovery approval workflow
- Monthly client lead caps/reservations
- Global lead inventory and reuse
- Global dedupe/exhaustion ledger
- SES sequences
- Incoming email parsing/classification
- Opt-out/suppression
- CRM companies/contacts/deals/tasks/activities
- Realtime cache invalidation
- Admin QA, provider/key health, jobs and billing controls
