# LeadX — Runtime Error Hardening Pass

This build addresses the runtime failures observed in the admin Control Plane:

- `/leads/v2/admin/autonomous-campaigns` 500s caused by incomplete/older automation schema.
- `/leads/v2/admin/schedules` 500s caused by incomplete/older schedule schema.
- `/leads/v2/admin/replies` PostgREST `PGRST205` caused by missing `email_replies` in older installs.
- Worker/scale schema compatibility for older `worker_heartbeats` rows/tables, including `observed_at` and `active_jobs`.
- PostgREST schema-cache reload after repair DDL.
- Static backend table-reference audit now reports zero missing tables/views.

## Required database action

For an existing Supabase database, run **once**:

`sql/039_RUNTIME_SCHEMA_REPAIR.sql`

It is idempotent. The same repair is appended to the all-in-one migration and
`SUPABASE_FULL_MIGRATION.sql`.

## Clean frontend start

```bash
cd lead-crm-portal/frontend
npm install
npm run clean
npm run dev
```

For production:

```bash
npm run clean
npm run build
npm run start
```

Do not keep an older Next.js process running while testing the new build.
