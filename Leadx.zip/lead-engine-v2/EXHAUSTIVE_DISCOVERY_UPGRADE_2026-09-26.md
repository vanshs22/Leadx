
## 2026-09-26 Scale/Waterfall Upgrade

The first exhaustive implementation still had practical ceilings inside individual source lanes. This pass removes those product-level ceilings from the exhaustive path.

### Discovery architecture

`ICP -> geo/query coverage frontier -> source partitions -> saturation pagination -> canonical entity resolution -> durable global inventory -> enrichment waterfall -> verification -> intelligence -> delivery`

### Free/public discovery lanes enabled by default

- Serper Maps deep pagination
- Serper organic web search with query-family partitioning
- Public indexed Yelp, Yellow Pages, BBB, Manta, Superpages, MapQuest, Chamber of Commerce, Foursquare, TripAdvisor, Alignable, Angi and Thumbtack discovery via search-engine partitions
- Public LinkedIn company/person discovery via indexed search
- Public Instagram/Facebook discovery via indexed search
- OpenStreetMap/Overpass geographic tiling
- Scrapling is the primary self-hosted website fetcher
- Crawl4AI is an optional self-hosted browser/markdown layer
- Firecrawl remains a last-resort free-tier/provider-keyed fallback

Direct Google Places and Foursquare API adapters remain available but are **opt-in**, so the default LeadX path does not require a paid API.

### No fixed lead ceiling in exhaustive mode

The exhaustive source loops stop on provider exhaustion, repeated pages, or query saturation. They do not stop because LeadX has reached 100, 500, 1,000 or 2,000 records.

The important scale technique is partitioning: Google documents a maximum of 60 Text Search results for one query, so LeadX expands by query intent, geography, directory, social domain and independent POI databases rather than pretending one Google query can enumerate a market.

### Durable global inventory

Exhaustive discoveries are now batch-persisted to `leads_global` before expensive enrichment. A large crawl therefore creates a durable LeadX data universe even if later browser/LLM/provider enrichment fails. Enrichment then runs in bounded chunks.

### Enrichment waterfall

1. Scrapling homepage fetch
2. Crawl4AI parallel render/markdown where enabled
3. Secondary same-domain pages: contact, about, team, staff, services, locations, booking and related navigation links
4. Firecrawl last resort
5. Structured email/phone/booking/social extraction
6. Serper public-search fallback for missing contact/decision-maker fields
7. Existing MX verification, LinkedIn lookup, signals, intent, pitch and opportunity intelligence

### Honest completeness boundary

No free/public source can guarantee every business in existence. Google, Yelp and search engines each expose only their own indexed/returned subset. LeadX therefore defines exhaustive as exhaustive across the enabled public source partitions until those sources are saturated, with the global database accumulating coverage over repeated runs.
