"""
Inbound replies via SES receiving -> SNS -> this webhook. Uses "plus
addressing" for routing: outbound emails set reply_to to
replies+{tenant_id}@REPLY_DOMAIN, so an inbound reply's "To" header
carries the tenant_id directly -- no fragile cross-tenant email matching
needed. The "From" address is then matched against that tenant's leads
to find which specific lead/assignment replied.

AWS-side setup (not something this code can do for you): SES receipt
rule on REPLY_DOMAIN -> SNS topic -> HTTPS subscription pointed at
POST /webhooks/ses-inbound. This module handles the SNS subscription
handshake automatically on first message.
"""
from __future__ import annotations

import email
import json
import logging
import re
from email.header import decode_header
from typing import Optional

import httpx

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.inbound_email")

_PLUS_TAG = re.compile(r"replies\+([0-9a-fA-F-]{36})@", re.I)

_OPTOUT_WORDS = {"unsubscribe", "stop", "remove me", "opt out", "opt-out", "take me off"}
_POSITIVE_WORDS = {
    "interested", "sounds good", "let's talk", "lets talk", "call me", "sure",
    "yes please", "tell me more", "schedule", "book a", "when can we", "sign me up",
}
_NEGATIVE_WORDS = {"not interested", "no thanks", "no thank you", "remove", "stop contacting", "not a fit"}


def _decode(s: Optional[str]) -> str:
    if not s:
        return ""
    parts = decode_header(s)
    return "".join(p.decode(enc or "utf-8", errors="ignore") if isinstance(p, bytes) else p for p, enc in parts)


def _extract_text(msg: email.message.Message) -> str:
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                try:
                    return part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", errors="ignore")
                except Exception:
                    continue
        return ""
    try:
        return msg.get_payload(decode=True).decode(msg.get_content_charset() or "utf-8", errors="ignore")
    except Exception:
        return ""


def keyword_category(body: str) -> Optional[str]:
    """Fast, free, deterministic pre-filter. Returns None if ambiguous --
    caller falls back to an LLM classification only when this can't decide,
    keeping the common/obvious cases at zero marginal cost."""
    low = body.lower()
    if any(w in low for w in _OPTOUT_WORDS):
        return "opt_out"
    if any(w in low for w in _NEGATIVE_WORDS):
        return "negative"
    if any(w in low for w in _POSITIVE_WORDS):
        return "positive"
    return None


async def llm_category(body: str) -> str:
    """Cheap Haiku classification for replies the keyword filter can't
    place -- same cost-conscious pattern as the LLM scoring layer."""
    try:
        import anthropic
        client = anthropic.AsyncAnthropic()
        resp = await client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=10,
            messages=[{
                "role": "user",
                "content": (
                    "Classify this email reply as exactly one word: positive, negative, "
                    f"opt_out, or question.\n\nReply:\n{body[:800]}"
                ),
            }],
        )
        text = resp.content[0].text.strip().lower()
        return text if text in ("positive", "negative", "opt_out", "question") else "unclassified"
    except Exception:
        logger.warning("LLM reply classification failed, leaving unclassified", exc_info=True)
        return "unclassified"


async def _find_assignment(tenant_id: str, from_email: str) -> Optional[str]:
    sb = get_supabase()
    leads = sb.table("leads_global").select("id").eq("email", from_email.strip().lower()).execute().data or []
    if not leads:
        return None
    lead_ids = [l["id"] for l in leads]
    rows = (
        sb.table("lead_assignments")
        .select("id")
        .eq("tenant_id", tenant_id)
        .in_("lead_id", lead_ids)
        .limit(1)
        .execute()
        .data
    )
    return rows[0]["id"] if rows else None


async def handle_reply(raw_mime: str) -> dict:
    sb = get_supabase()
    msg = email.message_from_string(raw_mime)
    to_header = _decode(msg.get("To", ""))
    from_header = _decode(msg.get("From", ""))
    subject = _decode(msg.get("Subject", ""))
    body = _extract_text(msg).strip()

    m = _PLUS_TAG.search(to_header)
    tenant_id = m.group(1) if m else None
    from_email_m = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", from_header)
    from_email = from_email_m.group(0) if from_email_m else from_header

    if not tenant_id:
        logger.warning("inbound reply with no tenant plus-tag in To: %s", to_header)
        return {"ok": False, "error": "no_tenant_tag_in_to_address"}

    category = keyword_category(body) or await llm_category(body)
    assignment_id = await _find_assignment(tenant_id, from_email)

    sb.table("email_replies").insert({
        "tenant_id": tenant_id,
        "assignment_id": assignment_id,
        "from_email": from_email,
        "subject": subject,
        "body_text": body[:5000],
        "category": category,
    }).execute()

    if category == "opt_out":
        from backend.integrations.prod.unsubscribe import process_unsubscribe
        await process_unsubscribe(tenant_id, from_email)
    elif category == "positive" and assignment_id:
        sb.table("email_sequence_enrollments").update({"status": "stopped_reply"}).eq(
            "assignment_id", assignment_id
        ).eq("status", "active").execute()
        sb.table("lead_assignments").update({"status": "replied_positive"}).eq("id", assignment_id).execute()
        from backend.integrations.prod.unsubscribe import notify_tenant
        await notify_tenant(tenant_id, f"Reply from {from_email}: positive -- check your replies tab.")
    elif assignment_id:
        sb.table("email_sequence_enrollments").update({"status": "stopped_reply"}).eq(
            "assignment_id", assignment_id
        ).eq("status", "active").execute()

    return {"ok": True, "tenant_id": tenant_id, "assignment_id": assignment_id, "category": category}


async def handle_sns_payload(body: dict) -> dict:
    """SNS wraps SES-received mail (or handles the subscription handshake)."""
    msg_type = body.get("Type")
    if msg_type == "SubscriptionConfirmation":
        url = body.get("SubscribeURL")
        if url:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.get(url)
        return {"ok": True, "confirmed": True}

    if msg_type != "Notification":
        return {"ok": False, "error": f"unhandled_sns_type_{msg_type}"}

    message = body.get("Message")
    if isinstance(message, str):
        try:
            message = json.loads(message)
        except Exception:
            return {"ok": False, "error": "unparseable_sns_message"}

    raw_mime = (message or {}).get("content") or (message or {}).get("mail", {}).get("content")
    if not raw_mime:
        return {"ok": False, "error": "no_email_content_in_sns_message: check your SES receipt rule action is set to SNS with raw email included"}

    return await handle_reply(raw_mime)
