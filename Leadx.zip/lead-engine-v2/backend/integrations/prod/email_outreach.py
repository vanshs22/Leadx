"""
Lead email outreach — Resend or SMTP.
Single send + bulk send with merge fields and rate limiting.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timezone
from typing import Any, Optional

import httpx

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.email_outreach")

_VAR = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")

# Safety caps
MAX_BULK = int(os.getenv("EMAIL_BULK_MAX", "100"))
BULK_DELAY_SEC = float(os.getenv("EMAIL_BULK_DELAY_SEC", "0.4"))


def _sb():
    return get_supabase()


def render_merge(text: str, lead: dict[str, Any], extra: Optional[dict] = None) -> str:
    data = {
        "name": lead.get("name") or lead.get("company_name") or "there",
        "company": lead.get("name") or lead.get("company_name") or "",
        "city": lead.get("city") or "",
        "owner": lead.get("decision_maker_name") or lead.get("owner_name") or "",
        "email": lead.get("email") or "",
        "phone": lead.get("phone_e164") or lead.get("phone") or "",
        "website": lead.get("website") or "",
        "pitch": lead.get("pitch_line") or lead.get("talking_points") or "",
        "tier": lead.get("tier") or "",
    }
    if extra:
        data.update({k: str(v) for k, v in extra.items() if v is not None})

    def repl(m):
        return str(data.get(m.group(1), m.group(0)))

    return _VAR.sub(repl, text or "")


async def send_via_resend(
    to: str,
    subject: str,
    html: str,
    text: str = "",
    from_addr: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> dict:
    key = os.getenv("RESEND_API_KEY")
    from_addr = from_addr or os.getenv("RESEND_FROM") or os.getenv("EMAIL_FROM")
    if not key or not from_addr:
        return {"ok": False, "error": "resend_not_configured", "provider": "resend"}
    payload: dict[str, Any] = {
        "from": from_addr,
        "to": [to],
        "subject": subject,
        "html": html,
    }
    if text:
        payload["text"] = text
    if reply_to:
        payload["reply_to"] = reply_to
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json=payload,
            )
            if r.status_code >= 300:
                return {"ok": False, "error": r.text[:400], "provider": "resend"}
            return {"ok": True, "provider": "resend", "provider_id": r.json().get("id")}
    except Exception as e:
        return {"ok": False, "error": str(e), "provider": "resend"}


def send_via_smtp_sync(
    to: str,
    subject: str,
    html: str,
    text: str = "",
    from_addr: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> dict:
    host = os.getenv("SMTP_HOST")
    port = int(os.getenv("SMTP_PORT", "587"))
    user = os.getenv("SMTP_USER")
    password = os.getenv("SMTP_PASSWORD")
    from_addr = from_addr or os.getenv("EMAIL_FROM") or user
    use_tls = os.getenv("SMTP_TLS", "1") not in ("0", "false", "no")
    if not (host and from_addr):
        return {"ok": False, "error": "smtp_not_configured", "provider": "smtp"}
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = from_addr
    msg["To"] = to
    if reply_to:
        msg["Reply-To"] = reply_to
    if text:
        msg.attach(MIMEText(text, "plain", "utf-8"))
    msg.attach(MIMEText(html or text or "", "html", "utf-8"))
    try:
        if use_tls:
            with smtplib.SMTP(host, port, timeout=30) as s:
                s.ehlo()
                s.starttls()
                if user and password:
                    s.login(user, password)
                s.sendmail(from_addr, [to], msg.as_string())
        else:
            with smtplib.SMTP_SSL(host, port, timeout=30) as s:
                if user and password:
                    s.login(user, password)
                s.sendmail(from_addr, [to], msg.as_string())
        return {"ok": True, "provider": "smtp", "provider_id": None}
    except Exception as e:
        return {"ok": False, "error": str(e), "provider": "smtp"}



async def send_via_brevo(
    to: str,
    subject: str,
    html: str,
    text: str = "",
    from_addr: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> dict:
    """Brevo (Sendinblue) transactional API — free tier ~300 emails/day."""
    key = os.getenv("BREVO_API_KEY") or os.getenv("SENDINBLUE_API_KEY")
    from_addr = from_addr or os.getenv("BREVO_FROM") or os.getenv("EMAIL_FROM") or os.getenv("RESEND_FROM")
    if not key or not from_addr:
        return {"ok": False, "error": "brevo_not_configured", "provider": "brevo"}
    # Parse "Name <email@x.com>" or plain email
    from_name = None
    from_email = from_addr
    if "<" in from_addr and ">" in from_addr:
        from_name = from_addr.split("<")[0].strip().strip('"')
        from_email = from_addr.split("<")[1].split(">")[0].strip()
    payload: dict[str, Any] = {
        "sender": {"email": from_email},
        "to": [{"email": to}],
        "subject": subject,
        "htmlContent": html,
    }
    if from_name:
        payload["sender"]["name"] = from_name
    if text:
        payload["textContent"] = text
    if reply_to:
        payload["replyTo"] = {"email": reply_to}
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            r = await client.post(
                "https://api.brevo.com/v3/smtp/email",
                headers={
                    "api-key": key,
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                json=payload,
            )
            if r.status_code in (200, 201, 202):
                data = r.json() if r.content else {}
                return {
                    "ok": True,
                    "provider": "brevo",
                    "provider_id": str(data.get("messageId") or data.get("message_id") or ""),
                }
            return {
                "ok": False,
                "error": f"brevo_{r.status_code}: {(r.text or '')[:200]}",
                "provider": "brevo",
            }
    except Exception as e:
        return {"ok": False, "error": str(e)[:300], "provider": "brevo"}


async def send_email(
    to: str,
    subject: str,
    html: str,
    text: str = "",
    from_addr: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> dict:
    """Prefer Resend; fall back to SMTP if Resend missing or fails config."""
    provider = (os.getenv("EMAIL_PROVIDER") or "auto").lower()
    # Explicit provider first
    if provider == "resend":
        return await send_via_resend(to, subject, html, text, from_addr, reply_to)
    if provider in ("brevo", "sendinblue"):
        return await send_via_brevo(to, subject, html, text, from_addr, reply_to)
    if provider == "smtp":
        return await asyncio.to_thread(
            send_via_smtp_sync, to, subject, html, text, from_addr, reply_to
        )
    # auto: try Resend → Brevo → SMTP
    if provider == "auto":
        r = await send_via_resend(to, subject, html, text, from_addr, reply_to)
        if r.get("ok"):
            return r
        r2 = await send_via_brevo(to, subject, html, text, from_addr, reply_to)
        if r2.get("ok"):
            return r2
        r3 = await asyncio.to_thread(
            send_via_smtp_sync, to, subject, html, text, from_addr, reply_to
        )
        if r3.get("ok"):
            return r3
        # return last meaningful error
        for cand in (r3, r2, r):
            if cand and cand.get("error") and cand.get("error") not in (
                "resend_not_configured", "brevo_not_configured", "smtp_not_configured"
            ):
                return cand
        return r3 if r3 else (r2 if r2 else r)
    return {"ok": False, "error": "no_email_provider_configured"}


async def _log_send(
    tenant_id: str,
    assignment_id: Optional[str],
    lead_id: Optional[str],
    to_email: str,
    subject: str,
    status: str,
    provider: str = "",
    provider_id: Optional[str] = None,
    error: str = "",
) -> None:
    try:
        _sb().table("email_sends").insert({
            "tenant_id": tenant_id,
            "assignment_id": assignment_id,
            "lead_id": lead_id,
            "to_email": to_email,
            "subject": subject[:300],
            "status": status,
            "provider": provider or None,
            "provider_id": provider_id,
            "error": (error or "")[:500] or None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }).execute()
    except Exception as e:
        # table may not exist yet — soft fail
        logger.warning("email_sends log: %s", e)


async def _activity(
    tenant_id: str,
    assignment_id: Optional[str],
    subject: str,
    to_email: str,
    ok: bool,
) -> None:
    if not assignment_id:
        return
    try:
        _sb().table("lead_activities").insert({
            "tenant_id": tenant_id,
            "assignment_id": assignment_id,
            "activity_type": "email",
            "title": f"Email: {subject[:80]}",
            "body": f"To: {to_email} — {'sent' if ok else 'failed'}",
            "meta": {"to": to_email, "ok": ok},
        }).execute()
    except Exception:
        try:
            _sb().table("activities").insert({
                "tenant_id": tenant_id,
                "assignment_id": assignment_id,
                "activity_type": "email",
                "title": f"Email: {subject[:80]}",
                "body": f"To: {to_email}",
            }).execute()
        except Exception as e:
            logger.warning("activity log: %s", e)


async def send_to_lead(
    tenant_id: str,
    assignment_id: str,
    subject: str,
    body_html: str,
    body_text: str = "",
    reply_to: Optional[str] = None,
) -> dict:
    sb = _sb()
    rows = (
        sb.table("lead_assignments")
        .select("id, lead_id, tenant_id")
        .eq("id", assignment_id)
        .eq("tenant_id", tenant_id)
        .limit(1)
        .execute()
        .data
        or []
    )
    if not rows:
        return {"ok": False, "error": "assignment_not_found"}
    a = rows[0]
    leads = (
        sb.table("leads_global")
        .select("*")
        .eq("id", a["lead_id"])
        .limit(1)
        .execute()
        .data
        or []
    )
    if not leads:
        return {"ok": False, "error": "lead_not_found"}
    lead = leads[0]
    # enrichment email fallback
    if not lead.get("email"):
        try:
            en = (
                sb.table("enrichment")
                .select("email, pitch_line, owner_name")
                .eq("lead_id", a["lead_id"])
                .limit(1)
                .execute()
                .data
                or []
            )
            if en:
                lead["email"] = lead.get("email") or en[0].get("email")
                lead["pitch_line"] = lead.get("pitch_line") or en[0].get("pitch_line")
                lead["owner_name"] = lead.get("owner_name") or en[0].get("owner_name")
        except Exception:
            pass

    to = (lead.get("email") or "").strip()
    if not to or "@" not in to:
        return {"ok": False, "error": "no_email_on_lead"}

    subj = render_merge(subject, lead)
    html = render_merge(body_html, lead)
    text = render_merge(body_text or re.sub(r"<[^>]+>", " ", body_html), lead)

    result = await send_email(to, subj, html, text, reply_to=reply_to)
    status = "sent" if result.get("ok") else "failed"
    await _log_send(
        tenant_id, assignment_id, a["lead_id"], to, subj, status,
        provider=result.get("provider") or "",
        provider_id=result.get("provider_id"),
        error=result.get("error") or "",
    )
    await _activity(tenant_id, assignment_id, subj, to, bool(result.get("ok")))
    return {**result, "to": to, "subject": subj}


async def send_bulk(
    tenant_id: str,
    assignment_ids: list[str],
    subject: str,
    body_html: str,
    body_text: str = "",
    reply_to: Optional[str] = None,
) -> dict:
    ids = list(dict.fromkeys(assignment_ids))[:MAX_BULK]
    sent = 0
    failed = 0
    skipped = 0
    details: list[dict] = []

    for aid in ids:
        r = await send_to_lead(tenant_id, aid, subject, body_html, body_text, reply_to)
        if r.get("ok"):
            sent += 1
        elif r.get("error") == "no_email_on_lead":
            skipped += 1
        else:
            failed += 1
        details.append({"assignment_id": aid, **{k: r.get(k) for k in ("ok", "error", "to", "provider")}})
        if BULK_DELAY_SEC > 0:
            await asyncio.sleep(BULK_DELAY_SEC)

    return {
        "ok": True,
        "sent": sent,
        "failed": failed,
        "skipped_no_email": skipped,
        "total": len(ids),
        "details": details[:50],
    }


async def send_bulk_filtered(
    tenant_id: str,
    subject: str,
    body_html: str,
    body_text: str = "",
    tier: Optional[str] = None,
    stage: Optional[str] = None,
    only_with_email: bool = True,
    limit: int = 100,
    reply_to: Optional[str] = None,
) -> dict:
    """Send to all assignments matching filters (Send all on list)."""
    sb = _sb()
    q = (
        sb.table("lead_assignments")
        .select("id, lead_id, tier, status")
        .eq("tenant_id", tenant_id)
        .not_.in_("status", ["rejected", "expired"])
        .limit(min(limit, MAX_BULK))
    )
    if tier:
        q = q.eq("tier", tier.upper())
    rows = q.execute().data or []
    # optional stage filter via join-less post filter if stage on assignment
    if stage:
        rows = [r for r in rows if (r.get("status") or "").lower() == stage.lower() or (r.get("stage_slug") or "") == stage]

    ids = [r["id"] for r in rows]
    if only_with_email and ids:
        # filter to those with email
        lead_ids = [r["lead_id"] for r in rows]
        leads = (
            sb.table("leads_global")
            .select("id, email")
            .in_("id", lead_ids)
            .execute()
            .data
            or []
        )
        with_email = {x["id"] for x in leads if x.get("email")}
        ids = [r["id"] for r in rows if r["lead_id"] in with_email]

    return await send_bulk(tenant_id, ids, subject, body_html, body_text, reply_to)
