"""
Continuous high-volume discovery — never "run out" of the same 50 Maps results.

Strategy:
  1. Expand one ICP city into many GEO CELLS (zips, neighborhoods, adjacent cities)
  2. Expand queries into long-tail variants
  3. Track coverage (icp + source + cell + query) — next run picks LEAST scanned cells
  4. Skip fingerprints already seen by this tenant
  5. Deep pagination per cell until budget filled or cell exhausted
  6. Rotate sources so LinkedIn/IG/Web keep feeding when Maps plateaus

Target: 1,000–10,000+ unique leads per ICP over successive runs, always net-new.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Any, Optional

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.continuous")

# Query expansions by vertical — long-tail = more unique Maps/web results
QUERY_EXPANSIONS: dict[str, list[str]] = {
    "medspa": [
        "med spa", "medical spa", "aesthetics clinic", "botox clinic",
        "laser hair removal", "dermal filler", "hydrafacial", "coolsculpting",
        "microneedling clinic", "skin clinic", "cosmetic clinic",
        "anti aging clinic", "body contouring", "IV therapy lounge",
    ],
    "salon": [
        "hair salon", "beauty salon", "nail salon", "barbershop",
        "blow dry bar", "balayage salon", "keratin salon", "spa salon",
    ],
    "dental": [
        "dentist", "dental clinic", "cosmetic dentist", "orthodontist",
        "teeth whitening", "dental implants", "family dentist", "invisalign",
    ],
    "gym": [
        "gym", "fitness center", "crossfit", "yoga studio", "pilates studio",
        "personal training", "boxing gym", "spin studio",
    ],
    "wellness": [
        "wellness center", "chiropractor", "massage therapy", "acupuncture",
        "physical therapy", "holistic health",
    ],
}

# Adjacent / granular cells for common US metros (extend via icp_geo_cells table)
GEO_EXPANSIONS: dict[str, list[str]] = {
    "hoboken": ["Hoboken NJ", "07030", "Weehawken NJ", "Union City NJ", "Jersey City NJ waterfront"],
    "jersey city": ["Jersey City NJ", "07302", "07310", "07304", "Hoboken NJ", "Bayonne NJ"],
    "new york": [
        "Manhattan NY", "Brooklyn NY", "Queens NY", "Bronx NY",
        "Upper East Side NY", "SoHo NY", "Williamsburg Brooklyn",
        "Astoria NY", "Park Slope Brooklyn",
    ],
    "miami": ["Miami FL", "Miami Beach FL", "Brickell FL", "Coral Gables FL", "Aventura FL"],
    "los angeles": ["Los Angeles CA", "Santa Monica CA", "Beverly Hills CA", "Pasadena CA", "Culver City CA"],
    "chicago": ["Chicago IL", "Lincoln Park Chicago", "River North Chicago", "Evanston IL"],
    "austin": ["Austin TX", "78701", "78704", "Round Rock TX", "Cedar Park TX"],
    "dallas": ["Dallas TX", "Plano TX", "Frisco TX", "Arlington TX"],
    "houston": ["Houston TX", "Sugar Land TX", "The Woodlands TX"],
    "phoenix": ["Phoenix AZ", "Scottsdale AZ", "Tempe AZ", "Mesa AZ"],
    "denver": ["Denver CO", "Boulder CO", "Aurora CO"],
    "seattle": ["Seattle WA", "Bellevue WA", "Tacoma WA"],
    "boston": ["Boston MA", "Cambridge MA", "Somerville MA", "Brookline MA"],
    "atlanta": ["Atlanta GA", "Buckhead GA", "Decatur GA", "Marietta GA"],
    "san francisco": ["San Francisco CA", "Oakland CA", "Palo Alto CA", "San Jose CA"],
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _cell_key(label: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", label.lower()).strip("-")[:64]


def expand_queries(industry: str, base: Optional[list[str]] = None) -> list[str]:
    key = industry.lower().replace(" ", "")
    # try exact and fuzzy
    expanded = list(QUERY_EXPANSIONS.get(industry.lower(), []) or QUERY_EXPANSIONS.get(key, []))
    if not expanded:
        expanded = [industry, f"{industry} near me", f"best {industry}", f"{industry} clinic"]
    if base:
        for q in base:
            if q not in expanded:
                expanded.insert(0, q)
    # de-dupe preserve order
    seen = set()
    out = []
    for q in expanded:
        ql = q.lower().strip()
        if ql and ql not in seen:
            seen.add(ql)
            out.append(q)
    return out


def expand_geo_labels(locations: list[str], strict: bool = True) -> list[str]:
    """Build searchable location cells.

    strict=True (default): ONLY the locations provided — no nearby-city expansion.
    Set strict=False only for intentional statewide grid expansion.
    """
    cleaned = [loc.strip() for loc in (locations or []) if loc and str(loc).strip()]
    if not cleaned:
        return []

    if strict:
        labels: list[str] = []
        seen: set[str] = set()
        for loc in cleaned:
            if loc.lower() not in seen:
                labels.append(loc)
                seen.add(loc.lower())
        return labels

    try:
        from backend.integrations.prod.geo_grids import expand_state_grid, is_state_level_icp
        if is_state_level_icp(cleaned) or any(
            x.lower().strip() in ("new jersey", "nj", "new york", "ny", "california", "ca", "texas", "tx", "florida", "fl")
            for x in cleaned
        ):
            return expand_state_grid(cleaned)
    except Exception:
        pass

    labels = []
    seen = set()
    for loc in cleaned:
        if loc.lower() not in seen:
            labels.append(loc)
            seen.add(loc.lower())
        loc_l = loc.lower()
        for key, cells in GEO_EXPANSIONS.items():
            if key in loc_l or loc_l in key:
                for c in cells:
                    if c.lower() not in seen:
                        labels.append(c)
                        seen.add(c.lower())
    return labels


async def ensure_geo_cells(icp_id: str, locations: list[str]) -> list[dict]:
    """Persist expanded cells for ICP; return ordered by least scanned."""
    sb = get_supabase()
    labels = expand_geo_labels(locations, strict=True)
    for i, label in enumerate(labels):
        key = _cell_key(label)
        try:
            sb.table("icp_geo_cells").upsert({
                "icp_id": icp_id,
                "cell_key": key,
                "cell_label": label,
                "priority": 100 + i,
                "active": True,
            }, on_conflict="icp_id,cell_key").execute()
        except Exception as e:
            logger.debug("geo cell upsert: %s", e)

    rows = (
        sb.table("icp_geo_cells")
        .select("*")
        .eq("icp_id", icp_id)
        .eq("active", True)
        .order("times_scanned")
        .order("last_scanned_at")
        .limit(200)
        .execute()
        .data
        or []
    )
    if not rows:
        # table may not exist yet — return labels only
        return [{"cell_key": _cell_key(l), "cell_label": l, "times_scanned": 0} for l in labels]
    return rows


async def load_tenant_seen(tenant_id: str) -> set[str]:
    """Fingerprints already known to this tenant — skip at discovery."""
    sb = get_supabase()
    try:
        rows = (
            sb.table("tenant_seen_leads")
            .select("fingerprint")
            .eq("tenant_id", tenant_id)
            .limit(50000)
            .execute()
            .data
            or []
        )
        return {r["fingerprint"] for r in rows if r.get("fingerprint")}
    except Exception:
        # fallback: from assignments
        try:
            assigns = (
                sb.table("lead_assignments")
                .select("lead_id")
                .eq("tenant_id", tenant_id)
                .limit(20000)
                .execute()
                .data
                or []
            )
            fps: set[str] = set()
            for a in assigns[:5000]:
                lid = a.get("lead_id")
                if not lid:
                    continue
                g = (
                    sb.table("leads_global")
                    .select("fingerprint")
                    .eq("id", lid)
                    .limit(1)
                    .execute()
                    .data
                    or []
                )
                if g and g[0].get("fingerprint"):
                    fps.add(g[0]["fingerprint"])
            return fps
        except Exception:
            return set()


async def mark_tenant_seen(tenant_id: str, leads: list[dict]) -> None:
    sb = get_supabase()
    batch = []
    for lead in leads:
        fp = lead.get("fingerprint")
        if not fp:
            continue
        batch.append({
            "tenant_id": tenant_id,
            "fingerprint": fp,
            "lead_id": lead.get("id"),
            "first_seen_at": _now(),
        })
        if len(batch) >= 200:
            try:
                sb.table("tenant_seen_leads").upsert(batch, on_conflict="tenant_id,fingerprint").execute()
            except Exception as e:
                logger.debug("tenant_seen batch: %s", e)
            batch = []
    if batch:
        try:
            sb.table("tenant_seen_leads").upsert(batch, on_conflict="tenant_id,fingerprint").execute()
        except Exception as e:
            logger.debug("tenant_seen final: %s", e)


async def record_coverage(
    *,
    tenant_id: Optional[str],
    icp_id: Optional[str],
    vertical: str,
    source: str,
    location_key: str,
    query_key: str,
    page_reached: int,
    leads_found: int,
) -> None:
    sb = get_supabase()
    exhausted = leads_found == 0
    try:
        existing = (
            sb.table("discovery_coverage")
            .select("id, leads_found, page_reached")
            .eq("icp_id", icp_id or "00000000-0000-0000-0000-000000000000")
            .eq("source", source)
            .eq("location_key", location_key)
            .eq("query_key", query_key)
            .limit(1)
            .execute()
            .data
            or []
        )
        payload = {
            "tenant_id": tenant_id,
            "icp_id": icp_id,
            "vertical": vertical,
            "source": source,
            "location_key": location_key,
            "query_key": query_key,
            "page_reached": page_reached,
            "leads_found": (existing[0]["leads_found"] if existing else 0) + leads_found,
            "last_run_at": _now(),
            "exhausted": exhausted and page_reached > 0,
        }
        if existing:
            sb.table("discovery_coverage").update(payload).eq("id", existing[0]["id"]).execute()
        else:
            sb.table("discovery_coverage").insert(payload).execute()
    except Exception as e:
        logger.debug("coverage record: %s", e)


async def bump_cell_scanned(icp_id: str, cell_key: str) -> None:
    sb = get_supabase()
    try:
        rows = (
            sb.table("icp_geo_cells")
            .select("id, times_scanned")
            .eq("icp_id", icp_id)
            .eq("cell_key", cell_key)
            .limit(1)
            .execute()
            .data
            or []
        )
        if rows:
            sb.table("icp_geo_cells").update({
                "times_scanned": (rows[0].get("times_scanned") or 0) + 1,
                "last_scanned_at": _now(),
            }).eq("id", rows[0]["id"]).execute()
    except Exception:
        pass


async def discover_continuous(
    *,
    industry: str,
    locations: list[str],
    tenant_id: Optional[str] = None,
    icp_id: Optional[str] = None,
    queries: Optional[list[str]] = None,
    target_new_leads: int = 500,
    max_cells_per_run: int = 25,
    sources: Optional[dict[str, bool]] = None,
    social_limit_per_source: int = 20,
    limit_per_location: int = 30,
) -> list[dict]:
    """
    Fill up to target_new_leads of net-new (not seen by tenant) leads.

    Rotates geo cells least-scanned-first so each run explores fresh territory.
    """
    from backend.integrations.prod.multi_source_discovery import discover_multi_source

    qlist = expand_queries(industry, queries)
    seen_tenant = await load_tenant_seen(tenant_id) if tenant_id else set()
    logger.info(
        "continuous discovery target=%s tenant_seen=%s queries=%s",
        target_new_leads, len(seen_tenant), len(qlist),
    )

    # Geo cells: least scanned first
    if icp_id:
        cells = await ensure_geo_cells(icp_id, locations)
    else:
        labels = expand_geo_labels(locations, strict=True)
        cells = [{"cell_key": _cell_key(l), "cell_label": l, "times_scanned": 0} for l in labels]

    try:
        from backend.integrations.prod.geo_grids import recommend_cells_for_target
        auto_cells = recommend_cells_for_target(target_new_leads, len(cells))
        max_cells_per_run = max(max_cells_per_run, auto_cells)
    except Exception:
        pass
    cells = cells[:max_cells_per_run]
    collected: list[dict] = []
    seen_fp: set[str] = set(seen_tenant)

    # Round-robin cells until target
    for cell in cells:
        if len(collected) >= target_new_leads:
            break
        label = cell.get("cell_label") or cell.get("cell_key")
        remaining = target_new_leads - len(collected)
        # Prefer user limit_per_location as per-cell cap; scale up slightly when total is large
        per_cell = max(10, int(limit_per_location or 30))
        cell_budget = min(
            remaining,
            max(per_cell, min(per_cell * 2, target_new_leads // max(1, min(10, len(cells))))),
        )

        budget = {
            "maps": min(cell_budget, max(per_cell, 40)),
            "linkedin": min(max(social_limit_per_source, 10), 30),
            "instagram": min(max(social_limit_per_source, 5), 20) if (sources or {}).get("instagram", False) else 0,
            "web": min(40, max(10, cell_budget // 2)),
            "yelp": min(15, per_cell),
            "facebook": min(15, per_cell),
        }
        enabled = sources or {
            "maps": True, "linkedin": True, "instagram": True,
            "web": True, "yelp": True, "facebook": True,
        }

        try:
            batch = await discover_multi_source(
                industry=industry,
                locations=[label],
                queries=qlist[:12] if target_new_leads >= 1000 else qlist[:8],
                sources=enabled,
                budget=budget,
                min_quality=50,
            )
        except Exception as e:
            logger.warning("cell %s failed: %s", label, e)
            batch = []

        new_in_cell = 0
        for lead in batch:
            fp = lead.get("fingerprint")
            if not fp or fp in seen_fp:
                continue
            seen_fp.add(fp)
            collected.append(lead)
            new_in_cell += 1
            if len(collected) >= target_new_leads:
                break

        if icp_id:
            await bump_cell_scanned(icp_id, cell.get("cell_key") or _cell_key(label))
            await record_coverage(
                tenant_id=tenant_id,
                icp_id=icp_id,
                vertical=industry,
                source="multi",
                location_key=cell.get("cell_key") or _cell_key(label),
                query_key=",".join(qlist[:3]),
                page_reached=1,
                leads_found=new_in_cell,
            )

        logger.info(
            "cell=%s new=%s total_collected=%s",
            label, new_in_cell, len(collected),
        )

    # If still short, second pass with remaining query tails + all locations coarse
    if len(collected) < target_new_leads // 2 and locations:
        extra_needed = target_new_leads - len(collected)
        try:
            batch = await discover_multi_source(
                industry=industry,
                locations=locations,
                queries=qlist[8:] or qlist,
                sources=sources,
                budget={
                    "maps": min(extra_needed, 100),
                    "linkedin": 30,
                    "instagram": 25,
                    "web": 40,
                    "yelp": 20,
                    "facebook": 20,
                },
                min_quality=48,
            )
            for lead in batch:
                fp = lead.get("fingerprint")
                if not fp or fp in seen_fp:
                    continue
                seen_fp.add(fp)
                collected.append(lead)
                if len(collected) >= target_new_leads:
                    break
        except Exception as e:
            logger.warning("second pass failed: %s", e)

    if tenant_id:
        await mark_tenant_seen(tenant_id, collected)

    logger.info(
        "continuous discovery done: %s net-new leads (target %s)",
        len(collected), target_new_leads,
    )
    return collected
