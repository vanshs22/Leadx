"""
Admin-provisioned client logins.

Model: the operator (admin panel) creates a tenant AND sets that client's
first login (email + password) in the same flow — the client never signs
themselves up. This calls the Supabase Admin API directly (requires the
service-role client already used everywhere else in this backend), creates
the auth user pre-confirmed (no confirmation email needed), and binds it
into tenant_members.

Kept alongside, not instead of, the existing invite-token flow
(team_invites.py) — that still covers a tenant owner adding *additional*
teammates later. This module only covers how a tenant's first/primary
login gets created.
"""
from __future__ import annotations

import logging
import secrets
import string
from typing import Optional

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.tenant_users")


def generate_password(length: int = 14) -> str:
    """Strong random password the admin can hand to the client, or override."""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(length))
        if (
            any(c.islower() for c in pw)
            and any(c.isupper() for c in pw)
            and any(c.isdigit() for c in pw)
        ):
            return pw


async def create_tenant_user(
    tenant_id: str,
    email: str,
    password: Optional[str] = None,
    full_name: Optional[str] = None,
    role: str = "owner",
) -> dict:
    """
    Create (or attach) a login for this tenant. Returns the password used
    so the caller can display it once — it is never stored in plaintext.
    """
    sb = get_supabase()
    email = email.strip().lower()
    password = password or generate_password()

    auth_user_id: Optional[str] = None
    try:
        created = sb.auth.admin.create_user(
            {
                "email": email,
                "password": password,
                "email_confirm": True,  # no confirmation email needed — admin-provisioned
                "user_metadata": {"full_name": full_name} if full_name else {},
            }
        )
        auth_user_id = created.user.id
    except Exception as e:
        msg = str(e).lower()
        if "already registered" in msg or "already exists" in msg or "duplicate" in msg:
            # Email already has a Supabase Auth account (e.g. member of another
            # tenant already) — attach membership instead of failing. Password
            # is NOT changed in this path; use reset_tenant_user_password for that.
            existing = sb.auth.admin.list_users()
            match = next((u for u in existing if (u.email or "").lower() == email), None)
            if not match:
                raise RuntimeError(f"Email exists in Auth but could not be looked up: {e}")
            auth_user_id = match.id
            logger.info("Attaching existing auth user %s to tenant %s", email, tenant_id)
        else:
            raise

    sb.table("tenant_members").upsert(
        {
            "tenant_id": tenant_id,
            "email": email,
            "auth_user_id": auth_user_id,
            "full_name": full_name,
            "role": role,
            "status": "active",
        },
        on_conflict="tenant_id,email",
    ).execute()

    return {"ok": True, "auth_user_id": auth_user_id, "email": email, "password": password}


async def reset_tenant_user_password(auth_user_id: str, new_password: Optional[str] = None) -> dict:
    """Admin-triggered password reset — for when a client forgets theirs."""
    sb = get_supabase()
    new_password = new_password or generate_password()
    sb.auth.admin.update_user_by_id(auth_user_id, {"password": new_password})
    return {"ok": True, "password": new_password}
