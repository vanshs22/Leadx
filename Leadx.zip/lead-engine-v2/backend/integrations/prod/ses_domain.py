"""Amazon SES send helpers (boto3). Used by send_for_tenant when AWS keys are set."""
from __future__ import annotations

import logging
import os
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

logger = logging.getLogger("lead_engine.ses")


def ses_configured() -> bool:
    return bool(
        (os.getenv("AWS_ACCESS_KEY_ID") or "").strip()
        and (os.getenv("AWS_SECRET_ACCESS_KEY") or "").strip()
    )


def _region() -> str:
    return (os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1").strip()


def _client():
    import boto3
    return boto3.client(
        "ses",
        region_name=_region(),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID") or None,
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY") or None,
    )


def _parse_from(from_addr: str) -> tuple[str, Optional[str]]:
    """Return (email, optional display name)."""
    from_addr = (from_addr or "").strip()
    m = re.match(r"^(.+?)\s*<([^>]+)>$", from_addr)
    if m:
        return m.group(2).strip(), m.group(1).strip().strip('"')
    return from_addr, None


async def send_via_ses(
    to: str,
    subject: str,
    html: str,
    text: str = "",
    from_addr: Optional[str] = None,
    reply_to: Optional[str] = None,
) -> dict:
    """Send one email via SES. Prefer SendEmail; use raw if needed for headers."""
    if not ses_configured():
        return {"ok": False, "error": "ses_not_configured", "provider": "ses"}

    default_from = (
        (from_addr or "").strip()
        or (os.getenv("SES_FROM") or os.getenv("EMAIL_FROM") or os.getenv("RESEND_FROM") or "").strip()
    )
    if not default_from:
        return {"ok": False, "error": "ses_from_missing", "provider": "ses", "hint": "Set SES_FROM=admin@yourdomain.com"}

    email_addr, _name = _parse_from(default_from)
    if not email_addr or "@" not in email_addr:
        return {"ok": False, "error": "ses_from_invalid", "provider": "ses"}

    to = (to or "").strip()
    if not to or "@" not in to:
        return {"ok": False, "error": "invalid_to", "provider": "ses"}

    try:
        import asyncio
        from concurrent.futures import ThreadPoolExecutor

        def _send():
            client = _client()
            dest = {"ToAddresses": [to]}
            body = {}
            if text:
                body["Text"] = {"Data": text, "Charset": "UTF-8"}
            if html:
                body["Html"] = {"Data": html, "Charset": "UTF-8"}
            if not body:
                body["Text"] = {"Data": subject or "(no content)", "Charset": "UTF-8"}

            kwargs = {
                "Source": default_from if "<" in default_from else default_from,
                "Destination": dest,
                "Message": {
                    "Subject": {"Data": subject or "(no subject)", "Charset": "UTF-8"},
                    "Body": body,
                },
            }
            if reply_to:
                kwargs["ReplyToAddresses"] = [reply_to.strip()]
            return client.send_email(**kwargs)

        loop = asyncio.get_event_loop()
        resp = await loop.run_in_executor(None, _send)
        mid = (resp or {}).get("MessageId")
        return {"ok": True, "provider": "ses", "provider_id": mid, "message_id": mid}
    except Exception as e:
        err = str(e)
        logger.warning("SES send failed: %s", err)
        return {"ok": False, "error": err, "provider": "ses"}
