
"""
Amazon SES (SESv2): automate domain identities on OUR account.
Client only adds DNS at their registrar; we never need the SES console per client.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Optional

logger = logging.getLogger("lead_engine.ses_domain")


def _client():
    try:
        import boto3
    except ImportError as e:
        raise RuntimeError("boto3 not installed — pip install boto3") from e
    region = os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION") or "us-east-1"
    kwargs: dict[str, Any] = {"region_name": region}
    key = os.getenv("AWS_ACCESS_KEY_ID")
    secret = os.getenv("AWS_SECRET_ACCESS_KEY")
    if key and secret:
        kwargs["aws_access_key_id"] = key
        kwargs["aws_secret_access_key"] = secret
    return boto3.client("sesv2", **kwargs)


def ses_configured() -> bool:
    return bool(os.getenv("AWS_ACCESS_KEY_ID") and os.getenv("AWS_SECRET_ACCESS_KEY"))


def create_domain_identity(domain: str) -> dict[str, Any]:
    """Register domain on our SES account; return DKIM CNAME records for the client."""
    domain = (domain or "").strip().lower().removeprefix("http://").removeprefix("https://").split("/")[0]
    if not domain or "." not in domain:
        return {"ok": False, "error": "invalid_domain"}
    if not ses_configured():
        return {"ok": False, "error": "ses_not_configured", "hint": "Set AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION"}

    try:
        c = _client()
        try:
            c.create_email_identity(EmailIdentity=domain)
        except c.exceptions.AlreadyExistsException:
            pass
        except Exception as e:
            if "AlreadyExists" not in str(e) and "already exists" not in str(e).lower():
                # continue to get attributes anyway
                logger.info("create_email_identity: %s", e)

        info = c.get_email_identity(EmailIdentity=domain)
        dkim = info.get("DkimAttributes") or {}
        tokens = dkim.get("Tokens") or []
        records = []
        for t in tokens:
            records.append({
                "type": "CNAME",
                "name": f"{t}._domainkey.{domain}",
                "value": f"{t}.dkim.amazonses.com",
            })
        verified = bool(info.get("VerifiedForSendingStatus"))
        dkim_status = dkim.get("Status") or dkim.get("SigningStatus") or ""
        return {
            "ok": True,
            "domain": domain,
            "verified": verified,
            "dkim_status": dkim_status,
            "dns_records": records,
            "identity": domain,
        }
    except Exception as e:
        logger.exception("SES create_domain_identity")
        return {"ok": False, "error": str(e)[:400]}


def get_domain_status(domain: str) -> dict[str, Any]:
    domain = (domain or "").strip().lower()
    if not domain:
        return {"ok": False, "error": "invalid_domain"}
    if not ses_configured():
        return {"ok": False, "error": "ses_not_configured"}
    try:
        c = _client()
        info = c.get_email_identity(EmailIdentity=domain)
        dkim = info.get("DkimAttributes") or {}
        tokens = dkim.get("Tokens") or []
        records = [
            {
                "type": "CNAME",
                "name": f"{t}._domainkey.{domain}",
                "value": f"{t}.dkim.amazonses.com",
            }
            for t in tokens
        ]
        verified = bool(info.get("VerifiedForSendingStatus"))
        return {
            "ok": True,
            "domain": domain,
            "verified": verified,
            "dkim_status": dkim.get("Status") or dkim.get("SigningStatus") or "",
            "dns_records": records,
        }
    except Exception as e:
        logger.exception("SES get_domain_status")
        return {"ok": False, "error": str(e)[:400]}


async def send_via_ses(
    to: str,
    subject: str,
    html: str,
    text: str = "",
    from_addr: str = "",
    reply_to: Optional[str] = None,
) -> dict:
    """Send one email via OUR SES account (From must be on a verified identity)."""
    if not ses_configured():
        return {"ok": False, "error": "ses_not_configured", "provider": "ses"}
    from_addr = (from_addr or os.getenv("SES_FROM") or os.getenv("EMAIL_FROM") or "").strip()
    if not from_addr or not to:
        return {"ok": False, "error": "missing_from_or_to", "provider": "ses"}
    try:
        c = _client()
        dest: dict[str, Any] = {"ToAddresses": [to]}
        body: dict[str, Any] = {"Html": {"Data": html or text or "", "Charset": "UTF-8"}}
        if text:
            body["Text"] = {"Data": text, "Charset": "UTF-8"}
        msg: dict[str, Any] = {
            "Subject": {"Data": subject or "(no subject)", "Charset": "UTF-8"},
            "Body": body,
        }
        kwargs: dict[str, Any] = {
            "FromEmailAddress": from_addr,
            "Destination": dest,
            "Content": {"Simple": msg},
        }
        if reply_to:
            kwargs["ReplyToAddresses"] = [reply_to]
        resp = c.send_email(**kwargs)
        return {"ok": True, "provider": "ses", "id": resp.get("MessageId")}
    except Exception as e:
        logger.warning("SES send: %s", e)
        return {"ok": False, "error": str(e)[:400], "provider": "ses"}
