"""
Production scoring, quality gate, exclusivity, quota.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.quality")

INDUSTRY_KEYWORDS = {
    "medspa": ["botox", "filler", "laser", "facial", "aesthetics", "microneedling", "hydrafacial", "coolsculpting"],
    "salon": ["hair", "color", "cut", "blowout", "keratin", "nails", "balayage", "highlights"],
    "gym": ["training", "yoga", "pilates", "crossfit", "fitness", "spin", "boxing"],
    "dental": ["dental", "teeth", "whitening", "implant", "orthodont", "veneer"],
    "wellness": ["massage", "chiropractic", "acupuncture", "wellness", "therapy"],
}


def score_lead(lead: dict, industry: str = "medspa", weights: dict | None = None) -> tuple[int, str, str]:
    """Prefer scoring.v3 (MX, weights, freshness); fall back to legacy if import fails."""
    try:
        from backend.integrations.prod.scoring import score_lead_v3
        s, t, r, _ = score_lead_v3(lead, industry=industry, weights=weights or {})
        return s, t, r
    except Exception:
        pass
    score = 0
    reasons: list[str] = []

    status = (lead.get("business_status") or "OPERATIONAL").upper()
    if status == "CLOSED":
        return 0, "C", "CLOSED — rejected"
    if status == "TEMPORARILY_CLOSED":
        score -= 15
        reasons.append("-15 temporarily closed")

    if lead.get("website") or lead.get("has_website"):
        score += 12
        reasons.append("+12 website")
    else:
        reasons.append("0 no website")

    if lead.get("phone_normalized") or lead.get("phone"):
        score += 12
        reasons.append("+12 phone")
    else:
        reasons.append("0 no phone")

    if lead.get("email") and lead.get("email_valid") is not False:
        score += 22
        reasons.append("+22 valid email")
    elif lead.get("email"):
        score += 8
        reasons.append("+8 email (unverified)")
    else:
        reasons.append("0 no email")

    if lead.get("has_booking") or lead.get("has_online_booking"):
        score += 14
        reasons.append(f"+14 booking ({lead.get('booking_platform') or 'yes'})")
    else:
        score += 4
        reasons.append("+4 no booking (opportunity)")

    rating = float(lead.get("google_rating") or 0)
    reviews = int(lead.get("review_count") or 0)
    if rating >= 4.5 and reviews >= 50:
        score += 14
        reasons.append(f"+14 strong reviews ({rating}★/{reviews})")
    elif rating >= 4.0 and reviews >= 15:
        score += 9
        reasons.append(f"+9 good reviews ({rating}★/{reviews})")
    elif reviews > 0:
        score += 4
        reasons.append(f"+4 some reviews ({reviews})")

    services = [str(s).lower() for s in (lead.get("services") or [])]
    kws = INDUSTRY_KEYWORDS.get(industry.lower().replace(" ", ""), [])
    blob = " ".join(services)
    if any(k in blob for k in kws):
        score += 10
        reasons.append("+10 service fit")

    if lead.get("owner_name"):
        score += 6
        reasons.append("+6 owner name")

    if lead.get("social_links"):
        score += 4
        reasons.append("+4 social")

    score = min(100, max(0, score))
    if score >= 72:
        tier = "A"
    elif score >= 48:
        tier = "B"
    else:
        tier = "C"
    return score, tier, "; ".join(reasons)


def passes_quality_gate(
    lead: dict,
    allow_tier_b: bool = False,
    min_enrichment_fields: int = 1,
    require_contact: str = "phone_or_email",
) -> tuple[bool, str]:
    """
    High-quality gate: contactable + tier + not closed + some enrichment signal.
    Website alone is no longer mandatory (LinkedIn/IG-origin leads allowed if contactable).
    """
    tier = lead.get("tier") or "C"
    allowed = {"A", "B"} if allow_tier_b else {"A"}
    if tier not in allowed:
        return False, f"tier={tier}"

    if (lead.get("business_status") or "").upper() == "CLOSED":
        return False, "closed"

    has_phone = bool(lead.get("phone_normalized") or lead.get("phone") or lead.get("phone_e164"))
    has_email = bool(lead.get("email") and lead.get("email_valid") is not False)
    if require_contact == "phone" and not has_phone:
        return False, "no_phone"
    elif require_contact == "email" and not has_email:
        return False, "no_email"
    elif require_contact == "phone_and_email" and not (has_phone and has_email):
        return False, "need_phone_and_email"
    elif require_contact == "phone_or_email" and not (has_phone or has_email):
        return False, "not_contactable"

    # Need a real presence signal (site or social or maps address)
    has_presence = bool(
        lead.get("website")
        or lead.get("linkedin_url")
        or lead.get("instagram_handle")
        or lead.get("address")
        or (lead.get("social_links") or {})
    )
    if not has_presence:
        return False, "no_presence"

    fields = 0
    if has_email:
        fields += 1
    if lead.get("has_booking") or lead.get("has_online_booking") or lead.get("booking_platform"):
        fields += 1
    if lead.get("services"):
        fields += 1
    if lead.get("social_links") or lead.get("linkedin_url") or lead.get("instagram_handle"):
        fields += 1
    if lead.get("owner_name") or lead.get("decision_maker_name"):
        fields += 1
    if len(lead.get("sources_hit") or []) >= 2:
        fields += 1
    if fields < min_enrichment_fields:
        return False, f"enrichment_fields={fields}"

    return True, "ok"


def _norm_offer(value: Optional[str], fallback: Optional[str] = None) -> str:
    """Normalize competitive lock key."""
    v = (value or fallback or "").strip().lower().replace(" ", "_")
    return v


async def check_exclusivity_conflict(
    lead_id: str,
    tenant_id: str,
    vertical: str,
    geo: list[str],
    offer_category: Optional[str] = None,
) -> bool:
    """
    True if another *competing* exclusive tenant already holds this lead.

    Lock key = offer_category (seller product type), NOT target vertical alone.

    Example:
      - Tenant A: offer=hair_dryers, target vertical=salon, geo=NJ
      - Tenant B: offer=hair_cream,  target vertical=salon, geo=NJ
      → NO conflict (different products; both can get the same salon)

      - Tenant A: offer=seo_agency, target=salon, geo=NJ
      - Tenant B: offer=seo_agency, target=salon, geo=NJ
      → CONFLICT (same seller type)
    """
    sb = get_supabase()
    my_offer = _norm_offer(offer_category, vertical)
    if not my_offer:
        return False

    try:
        r = sb.rpc("check_exclusivity", {
            "p_lead_id": lead_id,
            "p_tenant_id": tenant_id,
            "p_vertical": vertical,
            "p_geo": geo or [],
            "p_offer_category": my_offer,
        }).execute()
        if r.data is not None:
            return bool(r.data)
    except Exception:
        pass

    # Fallback: same offer_category + exclusive + geo overlap
    try:
        assigns = (
            sb.table("lead_assignments")
            .select("tenant_id, icp_id, vertical, offer_category")
            .eq("lead_id", lead_id)
            .neq("tenant_id", tenant_id)
            .not_.in_("status", ["rejected", "expired"])
            .execute()
            .data or []
        )
        for a in assigns:
            other_offer = _norm_offer(a.get("offer_category"), a.get("vertical"))
            icp_id = a.get("icp_id")
            exclusivity = "exclusive"
            other_geo: set = set()
            if icp_id:
                icp_rows = (
                    sb.table("icp_profiles")
                    .select("vertical, geo, exclusivity, offer_category")
                    .eq("id", icp_id)
                    .limit(1)
                    .execute()
                    .data or []
                )
                if not icp_rows:
                    continue
                icp = icp_rows[0]
                exclusivity = icp.get("exclusivity") or "exclusive"
                other_offer = _norm_offer(
                    icp.get("offer_category") or a.get("offer_category"),
                    icp.get("vertical") or a.get("vertical"),
                )
                other_geo = set(icp.get("geo") or [])
            if exclusivity != "exclusive":
                continue
            if other_offer != my_offer:
                continue  # different product/seller type → share OK
            my_geo = set(geo or [])
            if not other_geo or not my_geo or (other_geo & my_geo):
                return True
    except Exception as e:
        logger.warning("exclusivity check failed (fail-open): %s", e)
        return False
    return False


async def quota_remaining(tenant_id: str) -> int:
    sb = get_supabase()
    try:
        r = sb.rpc("tenant_quota_remaining", {"p_tenant_id": tenant_id}).execute()
        if r.data is not None:
            return int(r.data)
    except Exception:
        pass
    try:
        t = sb.table("tenants").select("leads_per_month_limit").eq("id", tenant_id).limit(1).execute().data
        lim = (t[0]["leads_per_month_limit"] if t else 100) or 100
        period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
        u = (
            sb.table("usage_log")
            .select("leads_delivered")
            .eq("tenant_id", tenant_id)
            .eq("period", period)
            .limit(1)
            .execute()
            .data
        )
        used = u[0]["leads_delivered"] if u else 0
        return max(lim - used, 0)
    except Exception:
        return 0


async def assign_lead(
    lead_id: str,
    tenant_id: str,
    icp_id: Optional[str],
    vertical: str,
    geo: list[str],
    delivery_channel: str = "telegram",
    tier: str = "A",
    offer_category: Optional[str] = None,
) -> dict:
    """
    Quota + exclusivity + 90-day recency → insert assignment → bump usage.
    Returns {"assigned": bool, "reason": str}.
    """
    sb = get_supabase()

    remaining = await quota_remaining(tenant_id)
    if remaining <= 0:
        return {"assigned": False, "reason": "quota_exhausted"}

    # 90-day recency
    try:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        recent = (
            sb.table("lead_assignments")
            .select("id")
            .eq("lead_id", lead_id)
            .eq("tenant_id", tenant_id)
            .gte("delivered_at", cutoff)
            .limit(1)
            .execute()
            .data
        )
        if recent:
            return {"assigned": False, "reason": "already_delivered_90d"}
    except Exception:
        pass

    # Resolve offer_category from ICP when not passed
    resolved_offer = _norm_offer(offer_category, None)
    if not resolved_offer and icp_id:
        try:
            rows = (
                sb.table("icp_profiles")
                .select("offer_category, vertical")
                .eq("id", icp_id)
                .limit(1)
                .execute()
                .data or []
            )
            if rows:
                resolved_offer = _norm_offer(rows[0].get("offer_category"), rows[0].get("vertical"))
        except Exception:
            pass
    if not resolved_offer:
        resolved_offer = _norm_offer(vertical)

    if await check_exclusivity_conflict(
        lead_id, tenant_id, vertical, geo, offer_category=resolved_offer
    ):
        return {"assigned": False, "reason": "exclusivity_conflict"}

    try:
        # Every tenant gets pipeline_stages seeded (seed_default_stages / the
        # tenant setup flow) — resolve their "new" stage so an assigned lead
        # actually lands in the New column instead of the unstaged bucket.
        # Without this, stage_id stays NULL and the kanban board (which
        # groups strictly by stage_id) shows every column empty even though
        # leads were delivered.
        new_stage_id = None
        try:
            stage_rows = (
                sb.table("pipeline_stages")
                .select("id")
                .eq("tenant_id", tenant_id)
                .eq("slug", "new")
                .limit(1)
                .execute()
                .data
            )
            if stage_rows:
                new_stage_id = stage_rows[0]["id"]
            else:
                # Tenant has no stages yet — seed the defaults, same path
                # the "Seed default stages" button on the pipeline page uses.
                sb.rpc("seed_default_stages", {"p_tenant_id": tenant_id}).execute()
                stage_rows = (
                    sb.table("pipeline_stages")
                    .select("id")
                    .eq("tenant_id", tenant_id)
                    .eq("slug", "new")
                    .limit(1)
                    .execute()
                    .data
                )
                new_stage_id = stage_rows[0]["id"] if stage_rows else None
        except Exception:
            logger.warning("could not resolve New stage for tenant %s", tenant_id, exc_info=True)

        sb.table("lead_assignments").upsert({
            "lead_id": lead_id,
            "tenant_id": tenant_id,
            "icp_id": icp_id,
            "vertical": vertical,
            "offer_category": resolved_offer,
            "geo_tags": geo or [],
            "tier": (tier or "C").upper() if tier else "C",
            "delivered_at": datetime.now(timezone.utc).isoformat(),
            "delivery_channel": delivery_channel,
            "delivery_status": "pending",
            "status": "new",
            "stage_id": new_stage_id,
        }, on_conflict="lead_id,tenant_id").execute()
    except Exception as e:
        logger.exception("assign upsert failed")
        return {"assigned": False, "reason": str(e)}

    # Bump usage
    try:
        sb.rpc("bump_usage", {"p_tenant_id": tenant_id, "p_tier": tier}).execute()
    except Exception:
        # Fallback
        try:
            from backend.integrations.prod.quality import _bump_usage_fallback
            await _bump_usage_fallback(tenant_id, tier)
        except Exception:
            pass


    # Put lead on client CRM pipeline board (stage "new")
    try:
        stages = (
            sb.table("pipeline_stages")
            .select("id, slug")
            .eq("tenant_id", tenant_id)
            .order("position")
            .limit(20)
            .execute()
            .data
            or []
        )
        if not stages:
            try:
                sb.rpc("seed_default_stages", {"p_tenant_id": tenant_id}).execute()
            except Exception:
                pass
            stages = (
                sb.table("pipeline_stages")
                .select("id, slug")
                .eq("tenant_id", tenant_id)
                .order("position")
                .limit(20)
                .execute()
                .data
                or []
            )
        new_stage = next((s for s in stages if (s.get("slug") or "").lower() in ("new", "lead", "inbox")), None)
        if not new_stage and stages:
            new_stage = stages[0]
        if new_stage:
            sb.table("lead_assignments").update({
                "stage_id": new_stage["id"],
                "stage_slug": new_stage.get("slug") or "new",
            }).eq("lead_id", lead_id).eq("tenant_id", tenant_id).execute()
    except Exception as e:
        logger.debug("CRM stage seed skipped: %s", e)

    return {"assigned": True, "reason": "ok"}



async def _bump_usage_fallback(tenant_id: str, tier: str) -> None:
    sb = get_supabase()
    period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
    existing = (
        sb.table("usage_log")
        .select("id, leads_delivered, tier_a_count, tier_b_count, tier_c_count")
        .eq("tenant_id", tenant_id)
        .eq("period", period)
        .limit(1)
        .execute()
        .data
    )
    if existing:
        row = existing[0]
        upd = {
            "leads_delivered": (row.get("leads_delivered") or 0) + 1,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        key = f"tier_{tier.lower()}_count"
        if key in ("tier_a_count", "tier_b_count", "tier_c_count"):
            upd[key] = (row.get(key) or 0) + 1
        sb.table("usage_log").update(upd).eq("id", row["id"]).execute()
    else:
        sb.table("usage_log").insert({
            "tenant_id": tenant_id,
            "period": period,
            "leads_delivered": 1,
            "tier_a_count": 1 if tier == "A" else 0,
            "tier_b_count": 1 if tier == "B" else 0,
            "tier_c_count": 1 if tier == "C" else 0,
        }).execute()
