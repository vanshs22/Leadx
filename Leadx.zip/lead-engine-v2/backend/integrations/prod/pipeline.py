from __future__ import annotations

import time
"""
Production Lead Pipeline Orchestrator
Discover → Enrich → Score → Store → Gate → Assign → Deliver
Tracks pipeline_runs + enrichment_failures for ops.
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from backend.memory.supabase_client import get_supabase
from backend.integrations.prod.discovery import discover_leads
from backend.integrations.prod.enricher import enrich_batch
from backend.integrations.prod.quality import (
    score_lead, passes_quality_gate, assign_lead, quota_remaining,
)
from backend.integrations.prod.utils import setup_logging
from backend.services.delivery import deliver_batch

logger = logging.getLogger("lead_engine.pipeline")




async def _record_run_lead(
    run_id: str,
    lead: dict,
    *,
    tenant_id: Optional[str] = None,
    stage: str = "discovered",
    tier: Optional[str] = None,
    included: bool = True,
) -> None:
    """Upsert a row on the per-run lead board (soft-fail if table missing)."""
    lead_id = lead.get("id")
    if not run_id or not lead_id:
        return
    try:
        sb = get_supabase()
        payload = {
            "run_id": run_id,
            "lead_id": lead_id,
            "tenant_id": tenant_id,
            "stage": stage,
            "tier": (tier or lead.get("tier") or "").upper() or None,
            "included": included,
            "score": lead.get("score"),
            "source": lead.get("source"),
            "name": lead.get("name") or lead.get("company_name"),
            "phone": lead.get("phone_e164") or lead.get("phone") or lead.get("phone_normalized"),
            "website": lead.get("website"),
            "city": lead.get("city") or (lead.get("address") or "")[:80],
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        sb.table("pipeline_run_leads").upsert(payload, on_conflict="run_id,lead_id").execute()
    except Exception as e:
        logger.debug("pipeline_run_leads upsert: %s", e)

async def _record_run_leads_bulk(
    run_id: str,
    leads: list[dict],
    *,
    tenant_id: Optional[str] = None,
    stage: str = "discovered",
    stage_fn=None,
) -> None:
    """
    Batch version of _record_run_lead. The per-lead loop issued one HTTP upsert
    per lead (2 full passes over every discovered lead), which dominated runtime
    on large runs. One upsert per 500 rows instead.
    """
    if not run_id or not leads:
        return
    now = datetime.now(timezone.utc).isoformat()
    rows = []
    for lead in leads:
        lead_id = lead.get("id")
        if not lead_id:
            continue
        rows.append({
            "run_id": run_id,
            "lead_id": lead_id,
            "tenant_id": tenant_id,
            "stage": stage_fn(lead) if stage_fn else stage,
            "tier": (lead.get("tier") or "").upper() or None,
            "included": True,
            "score": lead.get("score"),
            "source": lead.get("source"),
            "name": lead.get("name") or lead.get("company_name"),
            "phone": lead.get("phone_e164") or lead.get("phone") or lead.get("phone_normalized"),
            "website": lead.get("website"),
            "city": lead.get("city") or (lead.get("address") or "")[:80],
            "updated_at": now,
        })
    if not rows:
        return
    sb = get_supabase()
    for i in range(0, len(rows), 500):
        try:
            sb.table("pipeline_run_leads").upsert(
                rows[i:i + 500], on_conflict="run_id,lead_id"
            ).execute()
        except Exception as e:
            logger.debug("pipeline_run_leads bulk upsert: %s", e)


async def _progress(run_id: str, stage: str, **counts) -> None:
    """Update pipeline_runs so UI can show live progress."""
    try:
        sb = get_supabase()
        payload = {
            "status": "running",
            "meta": {"stage": stage, **{k: v for k, v in counts.items() if v is not None}},
        }
        for k in ("discovered", "enriched", "gated_ok", "assigned", "delivered"):
            if k in counts and counts[k] is not None:
                payload[k] = counts[k]
        sb.table("pipeline_runs").update(payload).eq("id", run_id).execute()
    except Exception:
        pass

async def _upsert_global(lead: dict) -> Optional[str]:
    sb = get_supabase()
    fp = lead.get("fingerprint")
    phone = lead.get("phone_normalized")
    payload = {
        "fingerprint": fp,
        "phone_normalized": phone,
        "phone_e164": lead.get("phone_e164"),
        "name": lead.get("name") or lead.get("company_name") or "",
        "name_normalized": (lead.get("name") or "").lower().strip(),
        "address": lead.get("address"),
        "city": lead.get("city"),
        "state": lead.get("state"),
        "website": lead.get("website"),
        "website_domain": lead.get("website_domain"),
        "category": lead.get("category") or lead.get("industry"),
        "business_status": (lead.get("business_status") or "OPERATIONAL").upper(),
        "google_rating": lead.get("google_rating"),
        "review_count": lead.get("review_count") or 0,
        "google_place_id": lead.get("google_place_id"),
        "source": lead.get("source", "google_maps_serper"),
        "raw_data": lead.get("raw_data") or {},
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        if fp:
            ex = sb.table("leads_global").select("id").eq("fingerprint", fp).limit(1).execute().data
            if ex:
                sb.table("leads_global").update(payload).eq("id", ex[0]["id"]).execute()
                return ex[0]["id"]
        if phone:
            ex = sb.table("leads_global").select("id").eq("phone_normalized", phone).limit(1).execute().data
            if ex:
                sb.table("leads_global").update(payload).eq("id", ex[0]["id"]).execute()
                return ex[0]["id"]
        r = sb.table("leads_global").insert(payload).execute()
        return r.data[0]["id"] if r.data else None
    except Exception as e:
        logger.warning("upsert_global failed name=%s fp=%s: %s", payload.get("name"), fp, e)
        return None


async def _upsert_enrichment(lead_id: str, lead: dict) -> None:
    sb = get_supabase()
    try:
        sb.table("enrichment").upsert({
            "lead_id": lead_id,
            "email": lead.get("email"),
            "email_valid": lead.get("email_valid"),
            "emails": lead.get("emails") or [],
            "phone_from_web": lead.get("phone_from_web"),
            "has_booking": lead.get("has_booking") or False,
            "booking_platform": lead.get("booking_platform"),
            "services": lead.get("services") or [],
            "social_links": lead.get("social_links") or {},
            "owner_name": lead.get("owner_name"),
            "markdown_summary": (lead.get("markdown_summary") or "")[:4000] or None,
            "raw_extraction": lead.get("raw_extraction") or {},
            "enrichment_method": lead.get("enrichment_method"),
            "enrichment_ok": bool(lead.get("enrichment_ok")),
            "error": lead.get("enrichment_error"),
            "extracted_at": datetime.now(timezone.utc).isoformat(),
        }, on_conflict="lead_id").execute()
    except Exception as e:
        logger.warning("upsert_enrichment failed: %s", e)


async def _upsert_score(lead_id: str, score: int, tier: str, reasoning: str) -> None:
    sb = get_supabase()
    try:
        sb.table("scores").upsert({
            "lead_id": lead_id,
            "deterministic_score": score,
            "total_score": score,
            "tier": tier,
            "reasoning": reasoning,
            "scored_at": datetime.now(timezone.utc).isoformat(),
        }, on_conflict="lead_id").execute()
    except Exception as e:
        logger.warning("upsert_score failed: %s", e)


async def _record_enrich_failure(lead_id: Optional[str], website: str, error: str) -> None:
    sb = get_supabase()
    try:
        sb.table("enrichment_failures").insert({
            "lead_id": lead_id,
            "website": website,
            "error": str(error)[:500],
            "attempts": 1,
            "last_attempt": datetime.now(timezone.utc).isoformat(),
            "resolved": False,
        }).execute()
    except Exception:
        pass


async def run_pipeline(
    tenant_id: str,
    icp_id: Optional[str] = None,
    industry: str = "medspa",
    locations: Optional[list[str]] = None,
    queries: Optional[list[str]] = None,
    limit_per_location: int = 50,
    skip_enrichment: bool = False,
    allow_tier_b: bool = False,
    max_enrich_concurrent: int = 3,
    deliver: bool = True,
    use_crawl4ai: bool = True,
    use_firecrawl: bool = True,
    include_linkedin: bool = True,
    include_instagram: bool = True,
    social_limit_per_source: int = 10,
    include_maps: bool = True,
    include_web: bool = True,
    include_yelp: bool = True,
    include_facebook: bool = True,
    target_new_leads: int = 0,
    max_cells_per_run: int = 25,
) -> dict:
    """
    Full production pipeline for one tenant/ICP.
    """
    setup_logging()
    sb = get_supabase()
    t0 = time.perf_counter()
    run_id = str(uuid4())
    started = datetime.now(timezone.utc)

    # Create run record
    try:
        sb.table("pipeline_runs").insert({
            "id": run_id,
            "tenant_id": tenant_id,
            "icp_id": icp_id,
            "status": "running",
            "started_at": started.isoformat(),
            "meta": {"stage": "starting"},
        }).execute()
    except Exception:
        pass

    await _progress(run_id, "starting")

    vertical = industry
    offer_category = None
    geo = locations or []
    delivery_channel = "telegram"
    delivery_config: dict = {}

    # Resolve ICP + tenant
    try:
        if icp_id:
            icp_rows = sb.table("icp_profiles").select("*").eq("id", icp_id).limit(1).execute().data or []
            if icp_rows:
                icp = icp_rows[0]
                vertical = icp.get("vertical") or industry
                offer_category = icp.get("offer_category") or icp.get("offer_label") or None
                # Prefer locations from the API request (admin form) over ICP statewide geo
                icp_geo = icp.get("geo") or []
                if isinstance(icp_geo, str):
                    icp_geo = [x.strip() for x in icp_geo.split(",") if x.strip()]
                geo = locations or icp_geo or []
                if not queries:
                    queries = icp.get("keywords") or None
        t_rows = sb.table("tenants").select("*").eq("id", tenant_id).limit(1).execute().data or []
        if t_rows:
            t = t_rows[0]
            if t.get("status") != "active":
                return {"error": "tenant_not_active", "tenant_id": tenant_id}
            delivery_channel = t.get("delivery_channel") or "telegram"
            try:
                from backend.integrations.prod.crypto_config import load_delivery_config
                delivery_config = load_delivery_config(t)
            except Exception:
                delivery_config = t.get("delivery_config") or {}
            if t.get("allow_tier_b") or t.get("plan") in ("growth", "premium", "enterprise"):
                allow_tier_b = True
    except Exception as e:
        logger.warning("tenant/icp resolve: %s", e)

    if isinstance(geo, str):
        geo = [x.strip() for x in geo.split(",") if x.strip()]
    geo = [g for g in (geo or []) if g]
    if not geo:
        geo = ["New Jersey"]

    # Quota pre-check
    remaining = await quota_remaining(tenant_id)
    if remaining <= 0:
        result = {
            "pipeline": "lead_engine_v2",
            "run_id": run_id,
            "error": "quota_exhausted",
            "tenant_id": tenant_id,
        }
        await _finish_run(run_id, "failed", result, "quota_exhausted")
        return result

    # ---------- Stage 1: Discover (continuous / high-volume when target set) ----------
    logger.info(
        "[%s] Discover %s in %s limit=%s target_new=%s",
        run_id[:8], vertical, geo, limit_per_location, target_new_leads,
    )
    try:
        src_flags = {
            "maps": include_maps,
            "linkedin": include_linkedin,
            "instagram": include_instagram,
            "web": include_web,
            "yelp": include_yelp,
            "facebook": include_facebook,
        }
        # Continuous mode ONLY when caller explicitly sets target_new_leads > 0.
        # Auto-recommending 5000 for statewide ICPs caused multi-minute runs,
        # HTTP timeouts, and UI "Internal Server Error" while status stayed "running".
        # Classic discover_leads respects limit_per_location and finishes quickly.
        if target_new_leads and target_new_leads > 0:
            from backend.integrations.prod.continuous_discovery import discover_continuous
            # Ensure enough cells to hit total (e.g. 100 total / 30 per loc ≈ 4+ cells)
            need_cells = max(
                max_cells_per_run,
                min(40, (target_new_leads // max(1, limit_per_location)) + 3),
            )
            max_cells_per_run = need_cells
            raw = await discover_continuous(
                industry=vertical,
                locations=geo,
                tenant_id=tenant_id,
                icp_id=icp_id,
                queries=queries,
                target_new_leads=target_new_leads,
                max_cells_per_run=max_cells_per_run,
                sources=src_flags,
                social_limit_per_source=social_limit_per_source,
                limit_per_location=limit_per_location,
            )
        else:
            raw = await discover_leads(
                industry=vertical,
                locations=geo,
                queries=queries,
                limit_per_location=limit_per_location,
                include_linkedin=include_linkedin,
                include_instagram=include_instagram,
                social_limit_per_source=social_limit_per_source,
                include_maps=include_maps,
                include_web=include_web,
                include_yelp=include_yelp,
                include_facebook=include_facebook,
            )
            # Still skip tenant-seen on normal runs
            if tenant_id and raw:
                try:
                    from backend.integrations.prod.continuous_discovery import load_tenant_seen, mark_tenant_seen
                    seen = await load_tenant_seen(tenant_id)
                    before = len(raw)
                    raw = [l for l in raw if l.get("fingerprint") not in seen]
                    await mark_tenant_seen(tenant_id, raw)
                    logger.info("[%s] tenant-seen filter %s → %s", run_id[:8], before, len(raw))
                except Exception as e:
                    logger.debug("tenant-seen filter: %s", e)
    except Exception as e:
        logger.exception("discovery failed")
        await _finish_run(run_id, "failed", {}, str(e))
        return {"error": "discovery_failed", "detail": str(e), "run_id": run_id}

    logger.info("[%s] Discovered %s", run_id[:8], len(raw))
    try:
        sb.table("pipeline_runs").update({
            "discovered": len(raw),
        }).eq("id", run_id).execute()
    except Exception:
        pass

    # ---------- Stage 1a: Persist discovered leads IMMEDIATELY ----------
    # So Supabase leads_global shows all Found leads even if enrichment is slow/hangs.
    # Bounded concurrency: _upsert_global does 1-3 sequential round trips each, so
    # a serial loop over a few thousand discovered leads took minutes on its own.
    early_stored = 0
    _store_sem = asyncio.Semaphore(8)

    async def _early_store(lead: dict) -> bool:
        async with _store_sem:
            try:
                lid = await _upsert_global(lead)
            except Exception as e:
                logger.debug("early upsert: %s", e)
                return False
        if lid:
            lead["id"] = lid
            return True
        return False

    early_stored = sum(
        1 for ok in await asyncio.gather(*[_early_store(l) for l in raw]) if ok
    )
    logger.info("[%s] Early store → leads_global: %s / %s", run_id[:8], early_stored, len(raw))
    await _record_run_leads_bulk(run_id, raw, tenant_id=tenant_id, stage="discovered")
    await _progress(run_id, "discovered", discovered=len(raw))

    # ---------- Stage 1b: Suppression / opt-out BEFORE enrichment (save crawl cost) ----------
    suppressed_n = opt_out_n = 0
    if raw and tenant_id:
        try:
            from backend.integrations.prod.suppression import filter_blocked_leads
            before = len(raw)
            raw, suppressed_n, opt_out_n = await filter_blocked_leads(tenant_id, raw)
            logger.info(
                "[%s] Pre-enrich filter: %s kept, %s suppressed, %s opt-out (from %s)",
                run_id[:8], len(raw), suppressed_n, opt_out_n, before,
            )
            try:
                from backend.integrations.prod.ops_metrics import bump
                if suppressed_n:
                    await bump("suppression_hits", suppressed_n, tenant_id)
                if opt_out_n:
                    await bump("opt_out_hits", opt_out_n, tenant_id)
            except Exception:
                pass
        except Exception as e:
            logger.warning("pre-enrich suppression filter failed: %s", e)

    # ---------- Stage 2: Enrich (time-boxed so pipeline always reaches assign) ----------
    if not skip_enrichment and raw:
        # Cap concurrency — high concurrency + crawl4ai/firecrawl hangs Codespaces
        # Full enrichment (scrapling / crawl4ai / firecrawl). Cap concurrency so
        # Codespaces doesn't hang; overall stage time-boxed so assign always runs.
        conc = max(1, min(int(max_enrich_concurrent or 3), 4))
        enrich_timeout = int(__import__("os").environ.get("ENRICH_TIMEOUT_SEC", "180"))
        await _progress(run_id, "enriching", discovered=len(raw))
        logger.info(
            "[%s] Enriching n=%s concurrency=%s timeout=%ss crawl4ai=%s firecrawl=%s",
            run_id[:8], len(raw), conc, enrich_timeout, use_crawl4ai, use_firecrawl,
        )
        try:
            raw = await asyncio.wait_for(
                enrich_batch(
                    raw,
                    max_concurrent=conc,
                    use_crawl4ai=use_crawl4ai,
                    use_firecrawl=use_firecrawl,
                ),
                timeout=enrich_timeout,
            )
        except asyncio.TimeoutError:
            logger.warning(
                "[%s] enrichment timed out after %ss — continuing with partial/unenriched leads",
                run_id[:8], enrich_timeout,
            )
            # ensure every lead has enrichment flags so later stages don't crash
            for lead in raw:
                if "enrichment_ok" not in lead:
                    lead["enrichment_ok"] = False
                    lead["enrichment_error"] = "timeout"
        except Exception as e:
            logger.exception("[%s] enrichment failed: %s — continuing", run_id[:8], e)
            for lead in raw:
                if "enrichment_ok" not in lead:
                    lead["enrichment_ok"] = False
                    lead["enrichment_error"] = str(e)[:200]
        for lead in raw:
            if not lead.get("enrichment_ok") and lead.get("website"):
                try:
                    await _record_enrich_failure(
                        lead.get("id"), lead.get("website"), lead.get("enrichment_error") or "unknown"
                    )
                except Exception:
                    pass

    enriched_n = sum(1 for l in raw if l.get("enrichment_ok"))
    await _record_run_leads_bulk(
        run_id, raw, tenant_id=tenant_id,
        stage_fn=lambda l: "enriched" if l.get("enrichment_ok") else "discovered",
    )
    await _progress(run_id, "enriched", discovered=len(raw), enriched=enriched_n)
    try:
        from backend.integrations.prod.ops_metrics import bump
        await bump("leads_discovered", len(raw), tenant_id)
        await bump("leads_enriched_ok", enriched_n, tenant_id)
        fail_n = len(raw) - enriched_n
        if fail_n > 0:
            await bump("leads_enriched_fail", fail_n, tenant_id)
        await bump("pipeline_runs", 1, tenant_id)
    except Exception:
        pass

    # ---------- Stage 2b: Verify + signals + priors + score v3 ----------
    if raw:
        from backend.integrations.prod.pipeline_hooks import post_enrich_prepare
        prepared = []
        for lead in raw:
            if lead.get("_blocked"):
                prepared.append(lead)
                continue
            try:
                lead = await post_enrich_prepare(
                    lead,
                    tenant_id=tenant_id,
                    industry=vertical,
                    html=lead.get("_html") or "",
                    reviews_text=lead.get("_reviews") or None,
                    do_linkedin=False,  # post-gate social_enrich handles LinkedIn
                )
            except Exception as e:
                logger.warning("post_enrich_prepare: %s", e)
                s, t, r = score_lead(lead, vertical)
                lead["score"], lead["tier"], lead["score_reason"] = s, t, r
            prepared.append(lead)
        raw = prepared

    # ---------- Stage 3–6: Store, gate, social, assign ----------
    stored = gated = assigned = 0
    social_budget = int(__import__('os').environ.get('SOCIAL_ENRICH_MAX_PER_RUN', '25'))
    to_deliver: list[dict] = []
    assignment_ids: list[str] = []
    top: list[dict] = []
    candidates: list[dict] = []

    for lead in raw:
        # Never store/assign suppressed or opted-out leads
        if lead.get("_blocked"):
            continue

        score = int(lead.get("score") or 0)
        tier = lead.get("tier") or "C"
        reasoning = lead.get("score_reason") or ""
        if not lead.get("score") and not lead.get("_blocked"):
            score, tier, reasoning = score_lead(lead, vertical)
            lead["score"], lead["tier"], lead["score_reason"] = score, tier, reasoning

        # Stage 1a already upserted every discovered lead. Only re-upsert when
        # enrichment actually changed the row, otherwise reuse the existing id —
        # this halved leads_global writes per run.
        lead_id = lead.get("id")
        if not lead_id or lead.get("enrichment_ok"):
            lead_id = await _upsert_global(lead)
        if not lead_id:
            continue
        lead["id"] = lead_id
        stored += 1

        if lead.get("enrichment_ok"):
            await _upsert_enrichment(lead_id, lead)
        await _upsert_score(lead_id, score, tier, reasoning)

        ok, reason = passes_quality_gate(lead, allow_tier_b=allow_tier_b)
        if not ok:
            continue
        gated += 1

        # Post-gate social enrich (LinkedIn + Instagram) — always attempted when
        # budget remains; soft-skip if keys/login missing or slow (never block assign).
        if social_budget > 0 and (lead.get("tier") or "").upper() in ("A", "B"):
            try:
                from backend.integrations.prod.social_enrich import social_enrich_lead
                await asyncio.wait_for(social_enrich_lead(lead), timeout=12)
                social_budget -= 1
                if lead.get("owner_name") and "owner" not in (lead.get("score_reason") or ""):
                    try:
                        from backend.integrations.prod.scoring import score_lead_v3
                        s2, t2, r2, _ = score_lead_v3(lead, industry=vertical)
                        lead["score"], lead["tier"], lead["score_reason"] = s2, t2, r2
                        score, tier, reasoning = s2, t2, r2
                        await _upsert_score(lead_id, score, tier, reasoning)
                    except Exception:
                        pass
            except asyncio.TimeoutError:
                logger.debug("[%s] social enrich timeout lead=%s", run_id[:8], lead.get("name"))
            except Exception as e:
                logger.debug("social enrich skipped (no key/login or error): %s", e)

        candidates.append(lead)
        await _record_run_lead(
            run_id, lead, tenant_id=tenant_id, stage="gated", tier=lead.get("tier")
        )

    await _progress(run_id, "gating", discovered=len(raw), enriched=enriched_n, gated_ok=gated)

    # ---------- Stage 6b: Rank — high quality, contactable, non-redundant ----------
    if candidates:
        try:
            from backend.integrations.prod.delivery_ranker import rank_for_delivery, diversity_cap
            ranked = rank_for_delivery(
                candidates,
                allow_tier_b=allow_tier_b,
                require_contact="phone_or_email",
                min_composite=40,
                max_deliver=len(candidates),
                prefer_multi_source=True,
            )
            ranked = diversity_cap(ranked, max_per_domain=2, max_per_name_prefix=3)
            logger.info(
                "[%s] ranker: %s gated → %s ranked (contactable + diverse)",
                run_id[:8], len(candidates), len(ranked),
            )
            # If ranker wiped everyone, fall back so Admin Leads still gets data
            # Fallback must respect quota: max(remaining, 50) let a tenant with
            # 5 credits left through with 50 candidates.
            if not ranked and candidates:
                ranked = candidates[:remaining]
                logger.warning("[%s] ranker empty — fallback %s candidates", run_id[:8], len(ranked))
        except Exception as e:
            logger.warning("ranker failed, using gated order: %s", e)
            ranked = candidates[:remaining]
    else:
        ranked = []

    # Always assign ranked leads to the client so Admin → Leads shows them.
    # "Deliver" only controls outbound Telegram/email, not assignment.
    for lead in ranked[:25]:
        top.append({
            "name": lead.get("name"),
            "score": lead.get("score"),
            "tier": lead.get("tier"),
            "composite": lead.get("composite_quality"),
            "sources": lead.get("sources_hit"),
            "phone": lead.get("phone_e164") or lead.get("phone"),
            "email": lead.get("email"),
            "pitch": lead.get("pitch_line"),
            "reason": lead.get("score_reason"),
        })
    for lead in ranked:
        if assigned >= remaining:
            break
        lead_id = lead.get("id")
        tier = lead.get("tier") or "B"
        score = lead.get("score") or 0
        reasoning = lead.get("score_reason") or ""
        result = await assign_lead(
            lead_id=lead_id,
            tenant_id=tenant_id,
            icp_id=icp_id,
            vertical=vertical,
            geo=geo,
            delivery_channel=delivery_channel,
            tier=tier,
            offer_category=offer_category,
        )
        if result.get("assigned"):
            assigned += 1
            await _record_run_lead(
                run_id, lead, tenant_id=tenant_id, stage="assigned", tier=lead.get("tier") or tier
            )
            if deliver:
                to_deliver.append(lead)
            # First-touch is MANUAL only (CRM toggle / API) — never auto on every assign
            try:
                from backend.integrations.prod.ops_metrics import bump
                await bump("leads_assigned", 1, tenant_id)
                await bump("leads_gated", 1, tenant_id)
            except Exception:
                pass
            try:
                arows = (
                    sb.table("lead_assignments")
                    .select("id")
                    .eq("lead_id", lead_id)
                    .eq("tenant_id", tenant_id)
                    .limit(1)
                    .execute()
                    .data or []
                )
                if arows:
                    assignment_ids.append(arows[0]["id"])
            except Exception:
                pass
            if len(top) < 25:
                top.append({
                    "name": lead.get("name"),
                    "score": score,
                    "tier": tier,
                    "composite": lead.get("composite_quality"),
                    "sources": lead.get("sources_hit"),
                    "phone": lead.get("phone_e164") or lead.get("phone"),
                    "email": lead.get("email"),
                    "website": lead.get("website"),
                    "booking_platform": lead.get("booking_platform"),
                    "pitch": lead.get("pitch_line"),
                    "reason": reasoning,
                })

        await _progress(run_id, "assigning", discovered=len(raw), enriched=enriched_n, gated_ok=gated, assigned=assigned)

    # ---------- Stage 7: Deliver ----------
    delivered_n = 0
    delivery_result = None
    if deliver and to_deliver:
        delivery_result = await deliver_batch(
            to_deliver, delivery_channel, delivery_config, assignment_ids
        )
        if delivery_result.get("ok"):
            delivered_n = delivery_result.get("count") or len(to_deliver)

    elapsed = round((datetime.now(timezone.utc) - started).total_seconds(), 1)
    summary = {
        "pipeline": "lead_engine_v2",
        "run_id": run_id,
        "tenant_id": tenant_id,
        "icp_id": icp_id,
        "industry": vertical,
        "locations": geo,
        "discovered": len(raw),
        "stored_global": stored,
        "enriched": enriched_n,
        "passed_quality_gate": gated,
        "assigned_to_tenant": assigned,
        "delivered": delivered_n,
        "delivery": delivery_result,
        "elapsed_seconds": elapsed,
        "top_leads": top,
        "quota_remaining_after": await quota_remaining(tenant_id),
    }

    status = "completed"
    if stored == 0 and len(raw) == 0:
        status = "failed"
    elif assigned < gated and deliver:
        status = "partial"

    # Soft Stripe meter after successful assigns
    if assigned > 0:
        try:
            from backend.integrations.prod.billing_stripe import report_usage_for_period
            await report_usage_for_period(tenant_id)
        except Exception as be:
            logger.warning("stripe usage report skipped: %s", be)

    await _finish_run(run_id, status, summary)
    logger.info("[%s] done status=%s assigned=%s delivered=%s in %ss",
                run_id[:8], status, assigned, delivered_n, elapsed)
    summary["duration_ms"] = int((time.perf_counter() - t0) * 1000)
    summary["duration_sec"] = round(summary["duration_ms"] / 1000, 1)
    return summary


async def _finish_run(run_id: str, status: str, summary: dict, error: str = "") -> None:
    sb = get_supabase()
    try:
        sb.table("pipeline_runs").update({
            "status": status,
            "discovered": summary.get("discovered", 0),
            "stored": summary.get("stored_global", 0),
            "enriched": summary.get("enriched", 0),
            "gated_ok": summary.get("passed_quality_gate", 0),
            "assigned": summary.get("assigned_to_tenant", 0),
            "delivered": summary.get("delivered", 0),
            "error_message": error or None,
            "meta": {k: summary.get(k) for k in ("industry", "locations", "top_leads") if k in summary},
            "finished_at": datetime.now(timezone.utc).isoformat(),
        }).eq("id", run_id).execute()
    except Exception:
        pass


async def run_all_active_icps(
    limit_per_location: int = 40,
    skip_enrichment: bool = False,
    max_enrich_concurrent: int = 3,
) -> list[dict]:
    """Cron entry: every active ICP for every active tenant."""
    sb = get_supabase()
    icps = (
        sb.table("icp_profiles")
        .select("id, tenant_id, vertical, geo, keywords, tenants!inner(status)")
        .eq("active", True)
        .execute()
        .data or []
    )
    # Filter active tenants
    active = []
    for icp in icps:
        t = icp.get("tenants") or {}
        if isinstance(t, dict) and t.get("status") == "active":
            active.append(icp)
        elif not t:
            # join may not expand — check separately
            active.append(icp)

    results = []
    for icp in active:
        try:
            r = await run_pipeline(
                tenant_id=icp["tenant_id"],
                icp_id=icp["id"],
                industry=icp.get("vertical") or "medspa",
                locations=icp.get("geo") or [],
                queries=icp.get("keywords") or None,
                limit_per_location=limit_per_location,
                skip_enrichment=skip_enrichment,
                max_enrich_concurrent=max_enrich_concurrent,
            )
            results.append(r)
        except Exception as e:
            logger.exception("ICP %s failed", icp.get("id"))
            results.append({"icp_id": icp.get("id"), "error": str(e)})
        await asyncio.sleep(1.5)

    # Auto-refresh vertical priors so new tenants inherit improved weights
    try:
        from backend.integrations.prod.priors import refresh_vertical_priors
        verticals = {((icp.get("vertical") or "medspa").lower()) for icp in active}
        for v in verticals:
            await refresh_vertical_priors(v)
            logger.info("Refreshed vertical priors for %s", v)
    except Exception as e:
        logger.warning("prior refresh on cron failed: %s", e)

    return results
