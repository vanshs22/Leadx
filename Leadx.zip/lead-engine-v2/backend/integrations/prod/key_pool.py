"""
Production API Key Pool — rotation, cooldown, error tracking, env fallback.
"""
from __future__ import annotations

import logging
import os
import re
from datetime import datetime, timezone, timedelta
from typing import Callable, Awaitable, TypeVar

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.key_pool")
T = TypeVar("T")

ENV_FALLBACK = {
    "serper": "SERPER_API_KEY",
    "firecrawl": "FIRECRAWL_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GOOGLE_API_KEY",
    "groq": "GROQ_API_KEY",
    "openai": "OPENAI_API_KEY",
    "resend": "RESEND_API_KEY",
    "linkedin_scraper": "LINKEDIN_LI_AT",
}

# Bare "402"/"credit"/"exceeded" appear in plenty of unrelated messages (scraped page
# text, "402 Main Street", "/credit-cards"). Require real quota context so a healthy key
# is not cooled for 30 minutes by a coincidental substring.
STRONG_MARKERS = (
    "quota", "rate limit", "rate_limit", "too many requests",
    "insufficient", "payment required", "out of credit",
    "credit limit", "credits exhausted", "limit exceeded",
)

# A status code counts only with an HTTP-ish token next to it, or at the very
# start of the message — which is how httpx/our raisers format these errors.
QUOTA_STATUS_RE = re.compile(
    r"(?:^\s*['\"]?(?:40[23]|429)\b)"
    r"|(?:\b(?:status|status_code|code|http|error|err)\b[^0-9a-z]{0,12}(?:40[23]|429)\b)"
    r"|(?:\b(?:40[23]|429)\b[^0-9a-z]{0,3}(?:client|server)?\s*error\b)",
    re.I,
)


class KeyPoolExhausted(Exception):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def get_active_key(provider: str) -> tuple[str, str | None]:
    """Return (key_value, key_id). Reactivates cooled keys. Env fallback."""
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "active",
            "updated_at": _now().isoformat(),
        }).eq("provider", provider).eq("status", "cooling").lte(
            "cooldown_until", _now().isoformat()
        ).execute()

        r = (
            sb.table("api_key_pool")
            .select("id, key_value")
            .eq("provider", provider)
            .eq("status", "active")
            .order("last_used_at", desc=False, nullsfirst=True)
            .limit(1)
            .execute()
        )
        if r.data:
            row = r.data[0]
            sb.table("api_key_pool").update({
                "last_used_at": _now().isoformat(),
            }).eq("id", row["id"]).execute()
            return row["key_value"], row["id"]
    except Exception as e:
        logger.warning("key_pool query failed for %s: %s", provider, e)

    env_name = ENV_FALLBACK.get(provider, "")
    env_key = os.getenv(env_name, "") if env_name else ""
    if env_key:
        return env_key, None
    raise KeyPoolExhausted(f"No active keys for provider={provider}")


async def mark_quota_error(provider: str, key_value: str, error: str, cooldown_minutes: int = 30) -> None:
    sb = get_supabase()
    try:
        rows = (
            sb.table("api_key_pool")
            .select("id, error_count")
            .eq("provider", provider)
            .eq("key_value", key_value)
            .limit(1)
            .execute()
            .data or []
        )
        payload = {
            "status": "cooling",
            "cooldown_until": (_now() + timedelta(minutes=cooldown_minutes)).isoformat(),
            "last_error": str(error)[:500],
            "updated_at": _now().isoformat(),
        }
        if rows:
            payload["error_count"] = (rows[0].get("error_count") or 0) + 1
            # After many errors, mark exhausted permanently
            if payload["error_count"] >= 10:
                payload["status"] = "exhausted"
            sb.table("api_key_pool").update(payload).eq("id", rows[0]["id"]).execute()
        else:
            sb.table("api_key_pool").update(payload).eq("provider", provider).eq("key_value", key_value).execute()
    except Exception as e:
        logger.warning("mark_quota_error failed: %s", e)


async def mark_exhausted(provider: str, key_value: str, error: str = "") -> None:
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "exhausted",
            "last_error": str(error)[:500],
            "updated_at": _now().isoformat(),
        }).eq("provider", provider).eq("key_value", key_value).execute()
    except Exception as e:
        logger.warning("mark_exhausted failed: %s", e)


async def mark_provider_exhausted(provider: str, error: str = "") -> None:
    """Mark all active keys for a provider exhausted (e.g. LinkedIn cookie expiry)."""
    sb = get_supabase()
    try:
        sb.table("api_key_pool").update({
            "status": "exhausted",
            "last_error": str(error)[:500],
            "updated_at": _now().isoformat(),
        }).eq("provider", provider).eq("status", "active").execute()
    except Exception as e:
        logger.warning("mark_provider_exhausted failed: %s", e)


async def increment_usage(provider: str, key_value: str, amount: int = 1) -> None:
    sb = get_supabase()
    try:
        rows = (
            sb.table("api_key_pool")
            .select("id, credits_used, credits_limit")
            .eq("provider", provider)
            .eq("key_value", key_value)
            .limit(1)
            .execute()
            .data or []
        )
        if not rows:
            return
        row = rows[0]
        used = (row.get("credits_used") or 0) + amount
        updates: dict = {"credits_used": used, "last_used_at": _now().isoformat()}
        limit = row.get("credits_limit")
        if limit and used >= limit:
            updates["status"] = "exhausted"
            logger.info("Key %s/%s hit credits_limit=%s", provider, key_value[:8], limit)
        sb.table("api_key_pool").update(updates).eq("id", row["id"]).execute()
    except Exception as e:
        logger.warning("increment_usage failed: %s", e)


def _is_quota_error(exc: Exception) -> bool:
    """True only for real quota/rate-limit failures, not incidental substrings."""
    s = str(exc).lower()
    if any(m in s for m in STRONG_MARKERS):
        return True
    # Status codes only count near the front, where the raiser puts them — not
    # deep inside a scraped response body.
    return bool(QUOTA_STATUS_RE.search(s[:200]))


async def with_key_rotation(
    provider: str,
    call_fn: Callable[[str], Awaitable[T]],
    max_retries: int = 6,
    cooldown_minutes: int = 30,
) -> T:
    tried: set[str] = set()
    last_err: Exception | None = None

    for attempt in range(max_retries):
        try:
            key, _ = await get_active_key(provider)
        except KeyPoolExhausted as e:
            last_err = e
            break

        if key in tried:
            break
        tried.add(key)

        try:
            result = await call_fn(key)
            await increment_usage(provider, key)
            return result
        except Exception as e:
            last_err = e
            if _is_quota_error(e):
                logger.warning("Quota on %s key=%s… attempt=%s: %s", provider, key[:8], attempt + 1, e)
                await mark_quota_error(provider, key, str(e), cooldown_minutes)
                continue
            raise

    raise KeyPoolExhausted(f"All keys exhausted for {provider} after {len(tried)} tries: {last_err}")


async def pool_health() -> dict:
    """Summary of key pool status for admin UI."""
    sb = get_supabase()
    try:
        r = (
            sb.table("api_key_pool")
            .select(
                "id, provider, label, status, credits_used, credits_limit, "
                "last_error, last_used_at, cooldown_until"
            )
            .order("provider")
            .execute()
        )
        rows = r.data or []
    except Exception as e:
        logger.warning("pool_health query failed: %s", e)
        rows = []

    by_provider: dict[str, list] = {}
    for row in rows:
        by_provider.setdefault(row.get("provider") or "unknown", []).append(row)

    env_fallbacks = {
        provider: bool(os.getenv(env_name))
        for provider, env_name in ENV_FALLBACK.items()
    }

    return {
        "keys": rows,
        "by_provider": by_provider,
        "env_fallbacks": env_fallbacks,
        "total": len(rows),
        "active": sum(1 for r in rows if r.get("status") == "active"),
    }
