"""
Post-gate social enrichment — LinkedIn (HTTP microservice) + Instagram (instaloader).
Only runs on leads that already passed the quality gate (Tier A/B).
Hard-capped per run to protect LinkedIn session.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from datetime import datetime, timezone, timedelta
from typing import Any, Optional
from urllib.parse import quote

import httpx

from backend.integrations.prod.key_pool import with_linkedin_cookie, KeyPoolExhausted, mark_provider_exhausted
from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.social")

try:
    import instaloader as _instaloader_mod
    INSTALOADER_OK = True
except ImportError:
    _instaloader_mod = None
    INSTALOADER_OK = False
    logger.info("instaloader not installed — Instagram enrich disabled until: pip install instaloader")


LINKEDIN_SERVICE_URL = os.getenv("LINKEDIN_SCRAPER_URL", "http://linkedin-scraper:8001").rstrip("/")
SOCIAL_MAX_PER_RUN = int(os.getenv("SOCIAL_ENRICH_MAX_PER_RUN", "25"))
INSTAGRAM_STALE_DAYS = int(os.getenv("INSTAGRAM_STALE_DAYS", "90"))

LINKEDIN_COMPANY_RE = re.compile(
    r"linkedin\.com/company/([a-zA-Z0-9\-_%]+)", re.I
)
IG_HANDLE_RE = re.compile(
    r"(?:instagram\.com/|@)([A-Za-z0-9._]{2,30})", re.I
)


def _sb():
    return get_supabase()


async def _record_failure(lead_id: Optional[str], source: str, error: str) -> None:
    try:
        _sb().table("social_enrichment_failures").insert({
            "lead_id": lead_id,
            "source": source,
            "error": (error or "")[:500],
        }).execute()
    except Exception:
        pass


# ─── LinkedIn via drissbri-style FastAPI+Selenium service ────────────────────

async def enrich_linkedin(
    company_name: str,
    city: Optional[str] = None,
    linkedin_id_or_url: Optional[str] = None,
) -> dict[str, Any]:
    """
    Call LinkedIn scraper microservice.
    Auth: li_at cookie from api_key_pool provider=linkedin_scraper.
    """
    out: dict[str, Any] = {
        "linkedin_url": None,
        "linkedin_employee_range": None,
        "decision_maker_name": None,
        "decision_maker_title": None,
        "decision_makers": [],
        "source_linkedin": None,
    }

    slug = None
    if linkedin_id_or_url:
        m = LINKEDIN_COMPANY_RE.search(linkedin_id_or_url)
        slug = m.group(1) if m else linkedin_id_or_url.strip("/").split("/")[-1]

    async def _call(api_key: str) -> dict:
        """api_key here is the li_at cookie value."""
        headers = {
            "X-Li-At": api_key,
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        async with httpx.AsyncClient(timeout=60) as client:
            if slug:
                r = await client.get(
                    f"{LINKEDIN_SERVICE_URL}/company-data/{quote(slug)}",
                    headers=headers,
                )
            else:
                # Search-by-name endpoint if service supports it
                r = await client.post(
                    f"{LINKEDIN_SERVICE_URL}/company-search",
                    headers=headers,
                    json={"name": company_name, "location": city or ""},
                )
            if r.status_code in (401, 403):
                # Cookie expired — mark pool key exhausted
                raise PermissionError("linkedin_cookie_expired")
            if r.status_code == 404:
                return {}
            r.raise_for_status()
            return r.json() if r.content else {}

    try:
        data = await with_linkedin_cookie(_call)
    except PermissionError:
        logger.warning("LinkedIn cookie expired — mark exhausted + alert")
        try:
            await mark_provider_exhausted("linkedin_scraper", error="cookie_expired")
        except Exception:
            pass
        await _telegram_cookie_alert()
        return out
    except KeyPoolExhausted:
        logger.info("LinkedIn: no active li_at cookie in api_key_pool (provider=linkedin_scraper) — skip deep scrape")
        return out
    except Exception as e:
        logger.warning("LinkedIn service call failed: %s", e)
        raise

    if not data:
        return out

    out["source_linkedin"] = "drissbri"
    out["linkedin_url"] = data.get("url") or data.get("linkedin_url") or (
        f"https://www.linkedin.com/company/{slug}" if slug else None
    )
    out["linkedin_employee_range"] = (
        data.get("employee_range")
        or data.get("staff_count_range")
        or data.get("company_size")
    )

    # Decision makers from employees / people list
    people = data.get("employees") or data.get("people") or data.get("decision_makers") or []
    dms = []
    for p in people[:8]:
        if not isinstance(p, dict):
            continue
        title = p.get("title") or p.get("headline") or ""
        name = p.get("name") or p.get("full_name") or ""
        if not name:
            continue
        dms.append({
            "name": name,
            "title": title,
            "linkedin_url": p.get("profile_url") or p.get("url"),
        })
    out["decision_makers"] = dms
    # Prefer owner/founder/director
    for dm in dms:
        t = (dm.get("title") or "").lower()
        if any(k in t for k in ("owner", "founder", "ceo", "president", "director", "manager")):
            out["decision_maker_name"] = dm["name"]
            out["decision_maker_title"] = dm.get("title")
            break
    if not out["decision_maker_name"] and dms:
        out["decision_maker_name"] = dms[0]["name"]
        out["decision_maker_title"] = dms[0].get("title")

    return out


async def _telegram_cookie_alert() -> None:
    """Notify ops that LinkedIn li_at needs manual refresh."""
    token = os.getenv("OPS_TELEGRAM_BOT_TOKEN") or os.getenv("TELEGRAM_BOT_TOKEN")
    chat = os.getenv("OPS_TELEGRAM_CHAT_ID") or os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat:
        return
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={
                    "chat_id": chat,
                    "text": "⚠️ LinkedIn scraper cookie (li_at) expired or pool exhausted. "
                            "Refresh the cookie: update LINKEDIN_LI_AT_COOKIE and redeploy "
                            "(or, if not set, add via /leads/v2/keys/add provider=linkedin_scraper)",
                },
            )
    except Exception:
        pass


# ─── Instagram via instaloader (no login for public profiles) ────────────────

def _instagram_sync(handle: str) -> dict[str, Any]:
    import instaloader
    L = instaloader.Instaloader(
        download_pictures=False,
        download_videos=False,
        download_video_thumbnails=False,
        download_geotags=False,
        download_comments=False,
        save_metadata=False,
        quiet=True,
    )
    profile = instaloader.Profile.from_username(L.context, handle)
    last_post_at = None
    try:
        posts = profile.get_posts()
        first = next(posts, None)
        if first is not None:
            last_post_at = first.date_utc.replace(tzinfo=timezone.utc)
    except Exception:
        pass

    stale = False
    if last_post_at:
        age = datetime.now(timezone.utc) - last_post_at
        stale = age > timedelta(days=INSTAGRAM_STALE_DAYS)
    else:
        stale = True  # no posts visible → treat as stale

    return {
        "instagram_handle": profile.username,
        "instagram_followers": profile.followers,
        "instagram_bio": (profile.biography or "")[:500],
        "instagram_last_post_at": last_post_at.isoformat() if last_post_at else None,
        "instagram_stale": stale,
        "source_instagram": "instaloader",
    }


async def enrich_instagram(handle_or_website: str) -> dict[str, Any]:
    handle = None
    m = IG_HANDLE_RE.search(handle_or_website or "")
    if m:
        handle = m.group(1).rstrip("/")
    elif handle_or_website and not handle_or_website.startswith("http"):
        handle = handle_or_website.lstrip("@")
    if not handle or handle.lower() in ("p", "reel", "stories", "explore"):
        return {}
    try:
        return await asyncio.to_thread(_instagram_sync, handle)
    except Exception as e:
        logger.debug("Instagram enrich failed for %s: %s", handle, e)
        raise


def extract_ig_handle(lead: dict) -> Optional[str]:
    social = lead.get("social_links") or {}
    if isinstance(social, dict):
        ig = social.get("instagram") or social.get("ig")
        if ig:
            m = IG_HANDLE_RE.search(str(ig))
            return m.group(1) if m else str(ig).lstrip("@")
    for field in ("website", "html_snippet", "name"):
        val = lead.get(field)
        if val and "instagram" in str(val).lower():
            m = IG_HANDLE_RE.search(str(val))
            if m:
                return m.group(1)
    return None


# ─── Orchestrate for gated leads ─────────────────────────────────────────────

async def social_enrich_lead(lead: dict) -> dict:
    """Enrich one gated lead. Never raises — failures recorded."""
    lead_id = lead.get("id") or lead.get("lead_id")
    name = lead.get("name") or lead.get("company_name") or ""
    result: dict[str, Any] = {}

    # LinkedIn
    try:
        existing = None
        if isinstance(lead.get("social_links"), dict):
            existing = lead["social_links"].get("linkedin")
        existing = existing or lead.get("linkedin_url")
        li = await enrich_linkedin(
            company_name=name,
            city=lead.get("city"),
            linkedin_id_or_url=existing,
        )
        result.update({k: v for k, v in li.items() if v is not None})
        if li.get("decision_maker_name") and not lead.get("owner_name"):
            lead["owner_name"] = li["decision_maker_name"]
        if li.get("linkedin_url"):
            lead["linkedin_url"] = li["linkedin_url"]
            social = lead.get("social_links") if isinstance(lead.get("social_links"), dict) else {}
            social["linkedin"] = li["linkedin_url"]
            lead["social_links"] = social
        if li.get("decision_makers"):
            lead["decision_makers"] = li["decision_makers"]
    except Exception as e:
        await _record_failure(lead_id, "linkedin", str(e))
        logger.debug("social linkedin fail lead=%s: %s", lead_id, e)

    # Instagram
    try:
        handle = extract_ig_handle(lead)
        if handle:
            ig = await enrich_instagram(handle)
            result.update({k: v for k, v in ig.items() if v is not None})
            lead["instagram_handle"] = ig.get("instagram_handle")
            lead["instagram_followers"] = ig.get("instagram_followers")
            lead["instagram_last_post_at"] = ig.get("instagram_last_post_at")
            lead["instagram_stale"] = ig.get("instagram_stale")
            if ig.get("instagram_stale"):
                why = list(lead.get("why_now") or [])
                why.append("Instagram stale (90+ days) — marketing opportunity")
                lead["why_now"] = why
    except Exception as e:
        await _record_failure(lead_id, "instagram", str(e))
        logger.debug("social instagram fail lead=%s: %s", lead_id, e)

    # Persist
    if lead_id and result:
        try:
            row = {
                "lead_id": lead_id,
                "linkedin_url": result.get("linkedin_url") or lead.get("linkedin_url"),
                "linkedin_employee_range": result.get("linkedin_employee_range"),
                "decision_maker_name": result.get("decision_maker_name"),
                "decision_maker_title": result.get("decision_maker_title"),
                "decision_makers": result.get("decision_makers") or [],
                "instagram_handle": result.get("instagram_handle"),
                "instagram_followers": result.get("instagram_followers"),
                "instagram_bio": result.get("instagram_bio"),
                "instagram_last_post_at": result.get("instagram_last_post_at"),
                "instagram_stale": result.get("instagram_stale"),
                "source_linkedin": result.get("source_linkedin"),
                "source_instagram": result.get("source_instagram"),
                "enriched_at": datetime.now(timezone.utc).isoformat(),
            }
            _sb().table("social_enrichment").upsert(row, on_conflict="lead_id").execute()
        except Exception as e:
            logger.warning("social_enrichment upsert: %s", e)

    return lead


async def social_enrich_batch(
    leads: list[dict],
    max_per_run: int = SOCIAL_MAX_PER_RUN,
) -> list[dict]:
    """
    Only Tier A/B (already gated). Cap volume to protect LinkedIn account.
    """
    candidates = [
        l for l in leads
        if (l.get("tier") or "").upper() in ("A", "B")
    ][:max_per_run]

    if not candidates:
        return leads

    logger.info("Social enrich %s leads (cap=%s)", len(candidates), max_per_run)
    # Sequential for LinkedIn session safety (avoid parallel browser sessions)
    for lead in candidates:
        try:
            await social_enrich_lead(lead)
        except Exception as e:
            logger.warning("social_enrich_lead: %s", e)
        await asyncio.sleep(1.2)  # gentle throttle

    return leads
