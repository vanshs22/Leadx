"""
Invite teammate flow: create token, optional email via Resend, accept → tenant_members.
"""
from __future__ import annotations

import logging
import os
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.invites")

INVITE_TTL_DAYS = int(os.getenv("INVITE_TTL_DAYS", "7"))
PORTAL_BASE_URL = os.getenv("PORTAL_BASE_URL", "http://localhost:3000")


def _sb():
    return get_supabase()


async def create_invite(
    tenant_id: str,
    email: str,
    role: str = "member",
    invited_by: Optional[str] = None,
    send_email: bool = True,
) -> dict:
    email = email.strip().lower()
    if role not in ("owner", "admin", "member", "viewer"):
        raise ValueError("invalid role")
    if role == "owner":
        raise ValueError("cannot invite as owner")

    sb = _sb()
    # Already a member?
    existing = (
        sb.table("tenant_members")
        .select("id, status")
        .eq("tenant_id", tenant_id)
        .eq("email", email)
        .limit(1)
        .execute()
        .data or []
    )
    if existing and existing[0].get("status") == "active":
        return {"ok": False, "error": "already_member"}

    token = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(days=INVITE_TTL_DAYS)

    # Revoke prior pending invites for same email
    try:
        sb.table("tenant_invites").update({"status": "revoked"}).eq(
            "tenant_id", tenant_id
        ).eq("email", email).eq("status", "pending").execute()
    except Exception:
        pass

    row = {
        "tenant_id": tenant_id,
        "email": email,
        "role": role,
        "token": token,
        "invited_by": invited_by,
        "expires_at": expires.isoformat(),
        "status": "pending",
    }
    try:
        r = sb.table("tenant_invites").insert(row).execute()
        invite = (r.data or [row])[0]
    except Exception as e:
        logger.exception("tenant_invites insert failed")
        # Still return a usable link even if table missing — operator can share manually
        invite = {**row, "id": None}
        invite_url = f"{PORTAL_BASE_URL}/accept-invite?token={token}"
        return {
            "ok": True,
            "invite_id": None,
            "token": token,
            "invite_url": invite_url,
            "expires_at": expires.isoformat(),
            "email_sent": False,
            "warning": f"Invite created in-memory only (DB: {e}). Share invite_url manually.",
        }
    invite_url = f"{PORTAL_BASE_URL}/accept-invite?token={token}"

    # Ensure member row in invited state (no ON CONFLICT dependency)
    try:
        existing = (
            sb.table("tenant_members")
            .select("id")
            .eq("tenant_id", tenant_id)
            .eq("email", email)
            .limit(1)
            .execute()
            .data
            or []
        )
        if existing:
            sb.table("tenant_members").update({
                "role": role, "status": "invited"
            }).eq("id", existing[0]["id"]).execute()
        else:
            sb.table("tenant_members").insert({
                "tenant_id": tenant_id,
                "email": email,
                "role": role,
                "status": "invited",
            }).execute()
    except Exception as e:
        logger.debug("member upsert: %s", e)

    email_sent = False
    if send_email:
        email_sent = await _send_invite_email(tenant_id, email, role, invite_url)

    return {
        "ok": True,
        "invite_id": invite.get("id"),
        "token": token,
        "invite_url": invite_url,
        "expires_at": expires.isoformat(),
        "email_sent": email_sent,
    }


async def _send_invite_email(tenant_id: str, email: str, role: str, invite_url: str) -> bool:
    """Send invite via unified email stack (Resend / Brevo / SMTP)."""
    sb = _sb()
    tenant = (
        sb.table("tenants")
        .select("name, brand_name, brand_primary_color, support_email")
        .eq("id", tenant_id)
        .limit(1)
        .execute()
        .data or []
    )
    t = tenant[0] if tenant else {}
    brand = t.get("brand_name") or t.get("name") or "Lead CRM"
    color = t.get("brand_primary_color") or "#6366f1"
    html = f"""
    <div style="font-family:sans-serif;max-width:480px">
      <h2 style="color:{color}">You&apos;re invited to {brand}</h2>
      <p>You&apos;ve been invited as <strong>{role}</strong>.</p>
      <p><a href="{invite_url}" style="background:{color};color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none">Accept invite</a></p>
      <p style="color:#64748b;font-size:12px">Link expires in {INVITE_TTL_DAYS} days. Or open: {invite_url}</p>
    </div>
    """
    try:
        from backend.integrations.prod.email_outreach import send_email
        r = await send_email(email, f"Invite to {brand}", html, f"Accept invite: {invite_url}")
        if r.get("ok"):
            return True
        logger.info("invite email not sent (%s) — share URL: %s", r.get("error"), invite_url)
        return False
    except Exception as e:
        logger.warning("invite email failed: %s — URL: %s", e, invite_url)
        return False


async def accept_invite(token: str, auth_user_id: str, full_name: Optional[str] = None) -> dict:
    """Accept invite after user signs up / logs in with matching email."""
    sb = _sb()
    rows = (
        sb.table("tenant_invites")
        .select("*")
        .eq("token", token)
        .eq("status", "pending")
        .limit(1)
        .execute()
        .data or []
    )
    if not rows:
        return {"ok": False, "error": "invalid_or_used_token"}
    inv = rows[0]
    exp = inv.get("expires_at")
    if exp:
        exp_dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
        if exp_dt < datetime.now(timezone.utc):
            sb.table("tenant_invites").update({"status": "expired"}).eq("id", inv["id"]).execute()
            return {"ok": False, "error": "expired"}

    sb.table("tenant_members").upsert({
        "tenant_id": inv["tenant_id"],
        "email": inv["email"],
        "role": inv["role"],
        "auth_user_id": auth_user_id,
        "full_name": full_name,
        "status": "active",
        "last_login_at": datetime.now(timezone.utc).isoformat(),
    }, on_conflict="tenant_id,email").execute()

    sb.table("tenant_invites").update({
        "status": "accepted",
        "accepted_at": datetime.now(timezone.utc).isoformat(),
    }).eq("id", inv["id"]).execute()

    return {
        "ok": True,
        "tenant_id": inv["tenant_id"],
        "role": inv["role"],
        "email": inv["email"],
    }


async def list_members(tenant_id: str) -> list:
    return (
        _sb()
        .table("tenant_members")
        .select("id, email, full_name, role, status, last_login_at, created_at")
        .eq("tenant_id", tenant_id)
        .order("created_at")
        .execute()
        .data or []
    )


async def list_invites(tenant_id: str) -> list:
    return (
        _sb()
        .table("tenant_invites")
        .select("id, email, role, status, expires_at, created_at")
        .eq("tenant_id", tenant_id)
        .order("created_at", desc=True)
        .limit(50)
        .execute()
        .data or []
    )
