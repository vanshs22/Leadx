"""
Production Enricher cascade:
  1. Scrapling (primary, anti-bot)
  2. Crawl4AI (markdown, parallel)
  3. Firecrawl (last resort, key-pooled)
  4. Structured extraction (regex + optional ScrapeGraphAI)
"""
from __future__ import annotations

import asyncio
import logging
import re
from typing import Optional

from backend.integrations.prod.key_pool import with_key_rotation, KeyPoolExhausted
from backend.integrations.prod.utils import (
    extract_emails, extract_phones, is_valid_email, normalize_phone, extract_domain,
)

logger = logging.getLogger("lead_engine.enricher")

BOOKING_PLATFORMS = [
    ("mindbody", "Mindbody"), ("vagaro", "Vagaro"), ("fresha", "Fresha"),
    ("booksy", "Booksy"), ("acuityscheduling", "Acuity"), ("calendly", "Calendly"),
    ("cal.com", "Cal.com"), ("square.site", "Square"), ("squareup", "Square"),
    ("zenoti", "Zenoti"), ("boulevard", "Boulevard"), ("booker", "Booker"),
    ("glofox", "Glofox"), ("schedulicity", "Schedulicity"), ("setmore", "Setmore"),
    ("simplybook", "SimplyBook"), ("styleseat", "StyleSeat"), ("treatwell", "Treatwell"),
]

INSTAGRAM_RE = re.compile(r"instagram\.com/([a-zA-Z0-9._]+)")
FACEBOOK_RE = re.compile(r"facebook\.com/([a-zA-Z0-9.]+)")
LINKEDIN_RE = re.compile(r"linkedin\.com/company/([a-zA-Z0-9\-]+)")

CONTACT_PATHS = ("/contact", "/contact-us", "/about", "/about-us", "/book", "/booking")


def _detect_booking(html: str) -> tuple[bool, Optional[str]]:
    lower = (html or "").lower()
    for kw, name in BOOKING_PLATFORMS:
        if kw in lower:
            return True, name
    return False, None


def _extract_social(html: str) -> dict:
    social = {}
    ig = INSTAGRAM_RE.search(html or "")
    if ig and ig.group(1) not in ("p", "reel", "stories", "explore", "accounts"):
        social["instagram"] = ig.group(1)
    fb = FACEBOOK_RE.search(html or "")
    if fb:
        social["facebook"] = fb.group(1)
    li = LINKEDIN_RE.search(html or "")
    if li:
        social["linkedin"] = li.group(1)
    return social


# ---------------------------------------------------------------------------
# Fetch layers
# ---------------------------------------------------------------------------
async def fetch_scrapling(url: str, timeout: int = 20) -> dict:
    out = {"html": "", "text": "", "method": "scrapling", "ok": False, "error": None}
    try:
        from scrapling import AsyncFetcher
        fetcher = AsyncFetcher(auto_match=False)
        page = await fetcher.get(url, timeout=timeout)
        html = str(getattr(page, "html", "") or "")
        text = ""
        if hasattr(page, "get_all_text"):
            try:
                text = page.get_all_text(separator=" ") or ""
            except Exception:
                text = html
        out.update(html=html, text=text or html, ok=bool(html))
    except ImportError:
        try:
            import httpx
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
                r = await client.get(url, headers={"User-Agent": "Mozilla/5.0 (compatible; LeadBot/2.0)"})
                out.update(html=r.text, text=r.text, ok=True, method="httpx")
        except Exception as e:
            out["error"] = str(e)
    except Exception as e:
        out["error"] = str(e)
        logger.debug("scrapling fail %s: %s", url, e)
    return out


async def fetch_crawl4ai(url: str) -> dict:
    out = {"markdown": "", "method": "crawl4ai", "ok": False, "error": None}
    try:
        from crawl4ai import AsyncWebCrawler
        async with AsyncWebCrawler(verbose=False) as crawler:
            res = await crawler.arun(url=url)
            md = getattr(res, "markdown", None) or getattr(res, "cleaned_html", "") or ""
            out.update(markdown=str(md)[:20000], ok=bool(md))
    except Exception as e:
        out["error"] = str(e)
        logger.debug("crawl4ai fail %s: %s", url, e)
    return out


async def fetch_firecrawl(url: str) -> dict:
    out = {"html": "", "markdown": "", "method": "firecrawl", "ok": False, "error": None}

    async def _call(api_key: str):
        import httpx
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(
                "https://api.firecrawl.dev/v1/scrape",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"url": url, "formats": ["markdown", "html"]},
            )
            if resp.status_code in (402, 429):
                raise Exception(f"Firecrawl quota: {resp.status_code}")
            resp.raise_for_status()
            data = resp.json().get("data") or {}
            return data.get("html") or "", data.get("markdown") or ""

    try:
        html, md = await with_key_rotation("firecrawl", _call)
        out.update(html=html, markdown=md, ok=bool(html or md))
    except Exception as e:  # KeyPoolExhausted is an Exception; the tuple was redundant
        out["error"] = str(e)
        logger.debug("firecrawl fail %s: %s", url, e)
    return out


def _parse_content(content: str) -> dict:
    emails = extract_emails(content)
    phones = extract_phones(content)
    has_booking, platform = _detect_booking(content)
    social = _extract_social(content)
    return {
        "emails": emails,
        "email": emails[0] if emails else None,
        "email_valid": is_valid_email(emails[0]) if emails else None,
        "phone_from_web": phones[0] if phones else None,
        "has_booking": has_booking,
        "booking_platform": platform,
        "social_links": social,
        "services": [],  # filled by optional LLM/ScrapeGraphAI
        "owner_name": None,
    }


async def _try_contact_pages(base_url: str, already_emails: list) -> dict:
    """If homepage had no email, try /contact paths with Scrapling."""
    if already_emails:
        return {}
    base = base_url.rstrip("/")
    for path in CONTACT_PATHS[:3]:
        try:
            page = await fetch_scrapling(base + path, timeout=12)
            if not page.get("ok"):
                continue
            parsed = _parse_content(page.get("html") or "")
            if parsed.get("emails"):
                return parsed
        except Exception:
            continue
    return {}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
async def enrich_one(website: str, use_crawl4ai: bool = True, use_firecrawl: bool = True) -> dict:
    """
    Full enrichment cascade for one URL.
    Returns dict ready for enrichment table upsert.
    """
    empty = {
        "website": website,
        "email": None, "email_valid": None, "emails": [],
        "phone_from_web": None, "has_booking": False, "booking_platform": None,
        "services": [], "social_links": {}, "owner_name": None,
        "markdown_summary": None, "raw_extraction": {},
        "enrichment_method": None, "enrichment_ok": False, "error": None,
    }
    if not website or not str(website).startswith("http"):
        empty["error"] = "invalid_url"
        return empty

    # 1. Scrapling primary
    scrap = await fetch_scrapling(website)
    html = scrap.get("html") or ""
    text = scrap.get("text") or ""
    method = scrap.get("method") or "scrapling"

    # 2. Crawl4AI parallel (best-effort)
    md = ""
    if use_crawl4ai:
        try:
            c4 = await asyncio.wait_for(fetch_crawl4ai(website), timeout=35)
            md = c4.get("markdown") or ""
        except Exception as e:
            logger.debug("crawl4ai timeout/fail: %s", e)

    content = md or html or text

    # 3. Firecrawl last resort
    if not content and use_firecrawl:
        fc = await fetch_firecrawl(website)
        content = fc.get("markdown") or fc.get("html") or ""
        method = "firecrawl"
        if fc.get("markdown"):
            md = fc["markdown"]

    if not content:
        empty["error"] = scrap.get("error") or "all_fetchers_failed"
        return empty

    parsed = _parse_content(content)

    # Contact page follow-up if no email
    if not parsed.get("emails"):
        extra = await _try_contact_pages(website, parsed.get("emails") or [])
        if extra.get("emails"):
            parsed.update({k: v for k, v in extra.items() if v})
            method = f"{method}+contact"

    # Optional ScrapeGraphAI (best-effort, never blocks)
    try:
        from scrapegraphai.graphs import SmartScraperGraph
        graph_config = {
            "llm": {"model": "gemini-1.5-flash", "temperature": 0},
            "verbose": False,
        }
        graph = SmartScraperGraph(
            prompt=(
                "Extract JSON: primary_email, phone, services (list), "
                "has_online_booking (bool), booking_platform, owner_or_manager_name."
            ),
            source=(md or content)[:12000],
            config=graph_config,
        )
        out = graph.run()
        if isinstance(out, dict):
            if out.get("primary_email") and is_valid_email(out["primary_email"]):
                parsed["email"] = out["primary_email"]
                parsed["emails"] = list(dict.fromkeys([out["primary_email"]] + (parsed.get("emails") or [])))
                parsed["email_valid"] = True
            if out.get("services"):
                svcs = out["services"] if isinstance(out["services"], list) else [out["services"]]
                parsed["services"] = [str(s) for s in svcs][:15]
            if out.get("owner_or_manager_name"):
                parsed["owner_name"] = str(out["owner_or_manager_name"])[:120]
            if out.get("has_online_booking") and not parsed.get("has_booking"):
                parsed["has_booking"] = bool(out["has_online_booking"])
                parsed["booking_platform"] = out.get("booking_platform")
    except Exception:
        pass

    ok = bool(
        parsed.get("email")
        or parsed.get("has_booking")
        or parsed.get("services")
        or parsed.get("phone_from_web")
        or parsed.get("social_links")
    )

    return {
        "website": website,
        "email": parsed.get("email"),
        "email_valid": parsed.get("email_valid"),
        "emails": parsed.get("emails") or [],
        "phone_from_web": parsed.get("phone_from_web"),
        "has_booking": parsed.get("has_booking") or False,
        "booking_platform": parsed.get("booking_platform"),
        "services": parsed.get("services") or [],
        "social_links": parsed.get("social_links") or {},
        "owner_name": parsed.get("owner_name"),
        "markdown_summary": (md or "")[:4000] or None,
        "raw_extraction": parsed,
        "enrichment_method": method,
        "enrichment_ok": ok,
        "error": None if ok else "sparse_extraction",
    }



async def _resolve_website(name: str, city: Optional[str] = None) -> Optional[str]:
    """Find official website for a business name via Serper (social-origin leads)."""
    if not name or len(name) < 2:
        return None
    q = f"{name} official website"
    if city:
        q = f"{name} {city} official website"
    try:
        from backend.integrations.prod.key_pool import with_key_rotation, KeyPoolExhausted

        async def _call(api_key: str):
            async with httpx.AsyncClient(timeout=15) as client:
                r = await client.post(
                    "https://google.serper.dev/search",
                    headers={"X-API-KEY": api_key, "Content-Type": "application/json"},
                    json={"q": q, "num": 5},
                )
                r.raise_for_status()
                return (r.json() or {}).get("organic") or []

        results = await with_key_rotation("serper", _call)
    except Exception:
        return None
    skip = ("linkedin.com", "instagram.com", "facebook.com", "yelp.com", "yellowpages", "wikipedia")
    for item in results or []:
        link = item.get("link") or ""
        if not link.startswith("http"):
            continue
        if any(s in link.lower() for s in skip):
            continue
        return link.split("?")[0]
    return None


async def enrich_batch(
    leads: list[dict],
    max_concurrent: int = 6,
    use_crawl4ai: bool = True,
    use_firecrawl: bool = True,
) -> list[dict]:
    sem = asyncio.Semaphore(max_concurrent)

    async def _one(lead: dict) -> dict:
        url = lead.get("website")
        # Social-discovered leads often lack website — resolve via Serper
        if not url and lead.get("name"):
            try:
                url = await _resolve_website(lead.get("name"), lead.get("city"))
                if url:
                    lead["website"] = url
                    lead["website_domain"] = extract_domain(url)
            except Exception:
                pass
        if not url:
            # Still mark partial OK if we already have LinkedIn/IG decision maker
            if lead.get("linkedin_url") or lead.get("instagram_handle") or lead.get("owner_name"):
                lead["enrichment_ok"] = True
                lead["enrichment_method"] = lead.get("source") or "social_only"
            else:
                lead["enrichment_ok"] = False
            return lead
        async with sem:
            try:
                info = await enrich_one(url, use_crawl4ai=use_crawl4ai, use_firecrawl=use_firecrawl)
            except Exception as e:
                logger.exception("enrich_one crashed for %s", url)
                lead["enrichment_ok"] = False
                lead["enrichment_error"] = str(e)
                return lead

            if info.get("enrichment_ok"):
                lead["email"] = info.get("email") or lead.get("email")
                lead["email_valid"] = info.get("email_valid")
                lead["emails"] = info.get("emails") or []
                if info.get("phone_from_web") and not lead.get("phone_normalized"):
                    lead["phone"] = info["phone_from_web"]
                    lead["phone_normalized"] = normalize_phone(info["phone_from_web"])
                lead["has_booking"] = info.get("has_booking", False)
                lead["booking_platform"] = info.get("booking_platform")
                lead["services"] = info.get("services") or []
                lead["social_links"] = info.get("social_links") or {}
                lead["owner_name"] = info.get("owner_name")
                lead["markdown_summary"] = info.get("markdown_summary")
                lead["enrichment_method"] = info.get("enrichment_method")
                lead["enrichment_ok"] = True
                lead["raw_extraction"] = info.get("raw_extraction") or {}
            else:
                lead["enrichment_ok"] = False
                lead["enrichment_error"] = info.get("error")
            return lead

    results = await asyncio.gather(*[_one(l) for l in leads], return_exceptions=False)
    ok_n = sum(1 for l in results if l.get("enrichment_ok"))
    logger.info("enrich_batch done: %s/%s ok", ok_n, len(results))
    return results
