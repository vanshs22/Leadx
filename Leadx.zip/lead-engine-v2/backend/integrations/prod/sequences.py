"""
Follow-up sequences: define N steps (subject/body/day-offset), enroll
selected or all leads, and a cron-callable process_due_sends() that
advances every active enrollment whose next_send_at has passed. Stops
automatically on unsubscribe (checked in email_outreach.send_to_lead) or
on a positive/negative reply (checked here before each step).
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from backend.memory.supabase_client import get_supabase

logger = logging.getLogger("lead_engine.sequences")


def _sb():
    return get_supabase()


async def create_sequence(tenant_id: str, name: str, steps: list[dict]) -> dict:
    """steps: [{subject, body_html, body_text?, delay_days}, ...] — step 1 delay_days is
    days after enrollment; later steps are days after the previous step sent."""
    sb = _sb()
    seq = sb.table("email_sequences").insert({"tenant_id": tenant_id, "name": name}).execute().data[0]
    rows = [
        {
            "sequence_id": seq["id"],
            "step_number": i + 1,
            "delay_days": s.get("delay_days", 0 if i == 0 else 3),
            "subject": s["subject"],
            "body_html": s["body_html"],
            "body_text": s.get("body_text", ""),
        }
        for i, s in enumerate(steps)
    ]
    if rows:
        sb.table("email_sequence_steps").insert(rows).execute()
    return seq


async def enroll_leads(tenant_id: str, sequence_id: str, assignment_ids: list[str]) -> dict:
    sb = _sb()
    steps = (
        sb.table("email_sequence_steps")
        .select("step_number, delay_days")
        .eq("sequence_id", sequence_id)
        .order("step_number")
        .execute()
        .data
        or []
    )
    if not steps:
        return {"ok": False, "error": "sequence_has_no_steps"}
    first_delay = steps[0]["delay_days"]
    next_send = (datetime.now(timezone.utc) + timedelta(days=first_delay)).isoformat()

    enrolled, skipped = 0, 0
    for aid in assignment_ids:
        try:
            sb.table("email_sequence_enrollments").upsert(
                {
                    "tenant_id": tenant_id,
                    "sequence_id": sequence_id,
                    "assignment_id": aid,
                    "current_step": 0,
                    "status": "active",
                    "next_send_at": next_send,
                },
                on_conflict="sequence_id,assignment_id",
            ).execute()
            enrolled += 1
        except Exception:
            logger.warning("enroll failed for assignment %s", aid, exc_info=True)
            skipped += 1
    return {"ok": True, "enrolled": enrolled, "skipped": skipped}


async def _has_disqualifying_reply(tenant_id: str, assignment_id: str) -> bool:
    rows = (
        _sb()
        .table("email_replies")
        .select("category")
        .eq("assignment_id", assignment_id)
        .in_("category", ["positive", "negative", "opt_out"])
        .limit(1)
        .execute()
        .data
    )
    return bool(rows)


async def process_due_sends(limit: int = 200) -> dict:
    """Cron-callable (mirrors alerts.py's run_alert_checks pattern)."""
    from backend.integrations.prod.email_outreach import send_to_lead

    sb = _sb()
    now = datetime.now(timezone.utc).isoformat()
    due = (
        sb.table("email_sequence_enrollments")
        .select("id, tenant_id, sequence_id, assignment_id, current_step")
        .eq("status", "active")
        .lte("next_send_at", now)
        .limit(limit)
        .execute()
        .data
        or []
    )

    sent, stopped, errors = 0, 0, 0
    for enr in due:
        try:
            if await _has_disqualifying_reply(enr["tenant_id"], enr["assignment_id"]):
                sb.table("email_sequence_enrollments").update({"status": "stopped_reply"}).eq("id", enr["id"]).execute()
                stopped += 1
                continue

            steps = (
                sb.table("email_sequence_steps")
                .select("*")
                .eq("sequence_id", enr["sequence_id"])
                .order("step_number")
                .execute()
                .data
                or []
            )
            next_step_num = enr["current_step"] + 1
            step = next((s for s in steps if s["step_number"] == next_step_num), None)
            if not step:
                sb.table("email_sequence_enrollments").update({"status": "completed"}).eq("id", enr["id"]).execute()
                continue

            result = await send_to_lead(
                enr["tenant_id"], enr["assignment_id"], step["subject"], step["body_html"], step.get("body_text") or ""
            )
            if not result.get("ok"):
                errors += 1
                # Don't retry forever on a hard failure (bad address etc.) — stop, don't loop.
                if result.get("error") in ("no_email_on_lead", "recipient_opted_out"):
                    sb.table("email_sequence_enrollments").update({"status": "stopped_optout"}).eq("id", enr["id"]).execute()
                    continue

            sent += 1
            following = next((s for s in steps if s["step_number"] == next_step_num + 1), None)
            update = {"current_step": next_step_num, "updated_at": datetime.now(timezone.utc).isoformat()}
            if following:
                update["next_send_at"] = (
                    datetime.now(timezone.utc) + timedelta(days=following["delay_days"])
                ).isoformat()
                update["status"] = "active"
            else:
                update["status"] = "completed"
                update["next_send_at"] = None
            sb.table("email_sequence_enrollments").update(update).eq("id", enr["id"]).execute()
        except Exception:
            logger.warning("process_due_sends failed for enrollment %s", enr.get("id"), exc_info=True)
            errors += 1

    return {"processed": len(due), "sent": sent, "stopped": stopped, "errors": errors}
