"""
Secured CRM API — tenant resolved from JWT, not trusted URL param alone.
Drop-in replacement pattern for crm_api.py routes.

Register:
  from backend.middleware.auth import require_tenant, TenantContext, assert_tenant_match
  from backend.middleware.rate_limit import rate_limit_api, client_ip
"""
from __future__ import annotations

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel

from backend.middleware.auth import TenantContext, require_tenant, require_admin, assert_tenant_match
from backend.middleware.rate_limit import rate_limit_api, rate_limit_pipeline, client_ip

# Re-use handlers from original crm_api where possible
from backend.crm.crm_api import (  # type: ignore
    dashboard as _dashboard,
    list_leads as _list_leads,
    lead_detail as _lead_detail,
    update_lead as _update_lead,
    change_stage as _change_stage,
    add_activity as _add_activity,
    create_task as _create_task,
    pipeline_board as _pipeline,
    reports_summary as _reports,
    export_csv as _export,
    seed_stages as _seed,
    report_bad_lead as _report_bad,
    crm_get_branding as _get_branding,
    crm_update_branding as _update_branding,
    crm_team_members as _team_members,
    crm_team_invite as _team_invite,
    BrandingBody,
    CrmInviteBody,
    client_export_instantly as _export_instantly,
    StageChangeRequest,
    LeadUpdate,
    ActivityCreate,
    TaskCreate,
    BadLeadReport,
)

router = APIRouter(prefix="/crm", tags=["crm-portal-secured"])


def _rl(request: Request, ctx: TenantContext):
    rate_limit_api(ctx.user_id or client_ip(request))


@router.get("/dashboard")
async def dashboard(
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _dashboard(UUID(ctx.tenant_id))


@router.get("/leads")
async def list_leads(
    request: Request,
    stage: Optional[str] = None,
    tier: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _list_leads(
        UUID(ctx.tenant_id),
        stage=stage, tier=tier, status=status, search=search,
        limit=limit, offset=offset,
    )


@router.get("/leads/{assignment_id}")
async def lead_detail(
    assignment_id: UUID,
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _lead_detail(UUID(ctx.tenant_id), assignment_id)


@router.patch("/leads/{assignment_id}")
async def update_lead(
    assignment_id: UUID,
    body: LeadUpdate,
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _update_lead(UUID(ctx.tenant_id), assignment_id, body)


@router.post("/leads/{assignment_id}/stage")
async def change_stage(
    assignment_id: UUID,
    body: StageChangeRequest,
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    """Stage change + win/loss feedback loop."""
    _rl(request, ctx)
    result = await _change_stage(UUID(ctx.tenant_id), assignment_id, body)

    # Feedback: if moved to won/lost, record outcome for adaptive scoring
    try:
        stage = result.get("stage") or {}
        if stage.get("is_won"):
            from backend.integrations.prod.feedback import record_outcome
            await record_outcome(ctx.tenant_id, str(assignment_id), "won")
        elif stage.get("is_lost"):
            from backend.integrations.prod.feedback import record_outcome
            await record_outcome(ctx.tenant_id, str(assignment_id), "lost", reason=body.note)
    except Exception:
        pass

    return result


@router.post("/leads/{assignment_id}/activities")
async def add_activity(
    assignment_id: UUID,
    body: ActivityCreate,
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _add_activity(UUID(ctx.tenant_id), assignment_id, body)


@router.post("/leads/{assignment_id}/tasks")
async def create_task(
    assignment_id: UUID,
    body: TaskCreate,
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _create_task(UUID(ctx.tenant_id), assignment_id, body)


@router.get("/pipeline")
async def pipeline(
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _pipeline(UUID(ctx.tenant_id))


@router.get("/reports/summary")
async def reports(
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _reports(UUID(ctx.tenant_id))


@router.get("/export/csv")
async def export_csv(
    request: Request,
    stage: Optional[str] = None,
    tier: Optional[str] = None,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _export(UUID(ctx.tenant_id), stage=stage, tier=tier)


@router.post("/setup")
async def setup(
    request: Request,
    ctx: TenantContext = Depends(require_admin),
):
    _rl(request, ctx)
    return await _seed(UUID(ctx.tenant_id))




@router.post("/leads/{assignment_id}/bad-lead")
async def report_bad(
    assignment_id: UUID,
    body: BadLeadReport,
    request: Request,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _report_bad(UUID(ctx.tenant_id), assignment_id, body)


@router.get("/export/instantly")
async def export_instantly(
    request: Request,
    limit: int = 200,
    ctx: TenantContext = Depends(require_tenant),
):
    _rl(request, ctx)
    return await _export_instantly(UUID(ctx.tenant_id), limit=limit)



@router.get("/branding")
async def branding_get(request: Request, ctx: TenantContext = Depends(require_tenant)):
    _rl(request, ctx)
    return await _get_branding(UUID(ctx.tenant_id))


@router.patch("/branding")
async def branding_patch(body: BrandingBody, request: Request, ctx: TenantContext = Depends(require_tenant)):
    _rl(request, ctx)
    return await _update_branding(UUID(ctx.tenant_id), body)


@router.get("/team/members")
async def team_list(request: Request, ctx: TenantContext = Depends(require_tenant)):
    _rl(request, ctx)
    return await _team_members(UUID(ctx.tenant_id))


@router.post("/team/invite")
async def team_invite_route(body: CrmInviteBody, request: Request, ctx: TenantContext = Depends(require_tenant)):
    _rl(request, ctx)
    return await _team_invite(UUID(ctx.tenant_id), body)

# ─── Secured pipeline run (expensive) ───────────────────────────────────────

class PipelineRunBody(BaseModel):
    icp_id: Optional[str] = None
    industry: str = "medspa"
    locations: list[str] = []
    queries: list[str] = []
    limit_per_location: int = 50
    skip_enrichment: bool = False
    deliver: bool = True
    allow_tier_b: bool = False
    include_linkedin: bool = True
    include_instagram: bool = True
    include_maps: bool = True
    include_web: bool = True
    include_yelp: bool = True
    include_facebook: bool = True
    target_new_leads: int = 0
    max_cells_per_run: int = 25


@router.post("/pipeline/run")
async def run_pipeline_secured(
    body: PipelineRunBody,
    request: Request,
    ctx: TenantContext = Depends(require_admin),
):
    """Only admins can trigger scrapes; rate limited per tenant."""
    rate_limit_pipeline(ctx.tenant_id)

    from backend.integrations.prod.pipeline import run_pipeline
    from backend.integrations.prod.feedback import lookalike_queries

    queries = list(body.queries or [])
    # Lookalike expansion from past wins
    try:
        extra = await lookalike_queries(ctx.tenant_id)
        for q in extra:
            if q not in queries:
                queries.append(q)
    except Exception:
        pass

    return await run_pipeline(
        tenant_id=ctx.tenant_id,
        icp_id=body.icp_id,
        industry=body.industry,
        locations=body.locations or None,
        queries=queries or None,
        limit_per_location=min(body.limit_per_location, 200),
        skip_enrichment=body.skip_enrichment,
        deliver=body.deliver,
        allow_tier_b=body.allow_tier_b,
        include_linkedin=body.include_linkedin,
        include_instagram=body.include_instagram,
        include_maps=body.include_maps,
        include_web=body.include_web,
        include_yelp=body.include_yelp,
        include_facebook=body.include_facebook,
        target_new_leads=body.target_new_leads,
        max_cells_per_run=body.max_cells_per_run,
    )
