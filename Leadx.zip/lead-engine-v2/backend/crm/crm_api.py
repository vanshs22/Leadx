"""
Client CRM Portal API — multi-tenant lead CRM for agencies & businesses.

SECURITY: every route below is gated by require_tenant (verified Supabase
JWT + active tenant_members row). The {tenant_id} in each path is only a
hint — require_tenant re-verifies membership and rejects any mismatch with
a 403 before the handler body ever runs, so it's safe for handlers to keep
using the path tenant_id directly for queries.

/team/accept is intentionally on a separate, lighter-auth router
(crm_public_router) because a user accepting an invite is not yet a member
of the tenant — it only needs a valid logged-in user, not tenant membership.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Any, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from backend.middleware.auth import require_tenant, require_auth_only, TenantContext, AuthedUser

logger = logging.getLogger("lead_engine.crm_api")

router = APIRouter(prefix="/crm", tags=["crm-portal"], dependencies=[Depends(require_tenant)])
crm_public_router = APIRouter(prefix="/crm", tags=["crm-portal-public"])


# ─── Request models ─────────────────────────────────────────────────────────

class StageChangeRequest(BaseModel):
    stage_id: str
    note: Optional[str] = None


class ActivityCreate(BaseModel):
    activity_type: str = "note"
    title: Optional[str] = None
    body: Optional[str] = None
    meta: dict = Field(default_factory=dict)


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    due_at: Optional[str] = None
    priority: str = "medium"
    assigned_to: Optional[str] = None


class LeadUpdate(BaseModel):
    priority: Optional[str] = None
    assigned_to: Optional[str] = None
    next_action_at: Optional[str] = None
    value_estimate: Optional[float] = None
    tags: Optional[list[str]] = None
    custom_fields: Optional[dict] = None
    status: Optional[str] = None


class BulkStageRequest(BaseModel):
    assignment_ids: list[str]
    stage_id: str


class SegmentCreate(BaseModel):
    name: str
    filters: dict = Field(default_factory=dict)


# ─── Helpers ────────────────────────────────────────────────────────────────

def _sb():
    from backend.memory.supabase_client import get_supabase
    return get_supabase()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def _log_activity(
    tenant_id: str,
    assignment_id: str,
    lead_id: str,
    activity_type: str,
    title: str = None,
    body: str = None,
    meta: dict = None,
    actor_id: str = None,
):
    try:
        _sb().table("lead_activities").insert({
            "tenant_id": tenant_id,
            "assignment_id": assignment_id,
            "lead_id": lead_id,
            "actor_id": actor_id,
            "activity_type": activity_type,
            "title": title,
            "body": body,
            "meta": meta or {},
        }).execute()
    except Exception:
        pass


# ─── Dashboard ──────────────────────────────────────────────────────────────

@router.get("/me")
async def crm_me(ctx: TenantContext = Depends(require_tenant)):
    """
    Resolve the logged-in user's tenant from their verified JWT alone
    (no tenant_id in this path, so require_tenant falls back to their
    first active membership). Frontend calls this once after login to
    learn which tenant_id to use for every other /crm/{tenant_id}/... call
    — it never lets the browser pick or enumerate tenants itself.
    """
    return {"tenant_id": ctx.tenant_id, "role": ctx.role, "email": ctx.email}


@router.get("/{tenant_id}/dashboard")
async def dashboard(tenant_id: UUID):
    """KPIs + funnel + recent activity for the home screen."""
    sb = _sb()
    tid = str(tenant_id)

    # Counts by stage
    stages = (
        sb.table("pipeline_stages")
        .select("id, name, slug, color, position, is_won, is_lost")
        .eq("tenant_id", tid)
        .order("position")
        .execute()
        .data or []
    )

    cards = (
        sb.table("crm_lead_cards")
        .select("assignment_id, stage_slug, tier, total_score, assignment_status")
        .eq("tenant_id", tid)
        .execute()
        .data or []
    )

    by_stage: dict[str, int] = {}
    by_tier: dict[str, int] = {"A": 0, "B": 0, "C": 0}
    total = len(cards)
    for c in cards:
        slug = c.get("stage_slug") or "new"
        by_stage[slug] = by_stage.get(slug, 0) + 1
        t = c.get("tier") or "C"
        by_tier[t] = by_tier.get(t, 0) + 1

    # Open tasks due soon
    tasks = (
        sb.table("lead_tasks")
        .select("id, title, due_at, priority, assignment_id")
        .eq("tenant_id", tid)
        .eq("status", "open")
        .order("due_at")
        .limit(10)
        .execute()
        .data or []
    )

    # Recent activities
    activities = (
        sb.table("lead_activities")
        .select("id, activity_type, title, body, created_at, assignment_id")
        .eq("tenant_id", tid)
        .order("created_at", desc=True)
        .limit(15)
        .execute()
        .data or []
    )

    # Usage / quota
    period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
    usage = (
        sb.table("usage_log")
        .select("*")
        .eq("tenant_id", tid)
        .eq("period", period)
        .limit(1)
        .execute()
        .data
    )
    tenant = (
        sb.table("tenants")
        .select("name, plan, leads_per_month_limit, delivery_channel")
        .eq("id", tid)
        .limit(1)
        .execute()
        .data
    )

    won = by_stage.get("won", 0)
    lost = by_stage.get("lost", 0)
    closed = won + lost
    win_rate = round(100 * won / closed, 1) if closed else 0

    # 7-day delivery trend, for the dashboard sparkline/line chart.
    from collections import defaultdict
    since = (datetime.now(timezone.utc) - timedelta(days=6)).date()
    delivered = (
        sb.table("lead_assignments")
        .select("delivered_at")
        .eq("tenant_id", tid)
        .gte("delivered_at", since.isoformat())
        .execute()
        .data or []
    )
    by_day: dict[str, int] = defaultdict(int)
    for row in delivered:
        d = row.get("delivered_at")
        if d:
            by_day[d[:10]] += 1
    trend = [
        {"date": (since + timedelta(days=i)).isoformat(), "count": by_day.get((since + timedelta(days=i)).isoformat(), 0)}
        for i in range(7)
    ]

    return {
        "tenant": tenant[0] if tenant else None,
        "kpis": {
            "total_leads": total,
            "tier_a": by_tier.get("A", 0),
            "tier_b": by_tier.get("B", 0),
            "tier_c": by_tier.get("C", 0),
            "new": by_stage.get("new", 0),
            "in_pipeline": total - won - lost,
            "won": won,
            "lost": lost,
            "win_rate_pct": win_rate,
        },
        "funnel": [
            {
                "stage": s["name"],
                "slug": s["slug"],
                "color": s["color"],
                "count": by_stage.get(s["slug"], 0),
            }
            for s in stages
        ],
        "usage": usage[0] if usage else None,
        "quota_limit": (tenant[0].get("leads_per_month_limit") if tenant else None),
        "tasks_due": tasks,
        "recent_activity": activities,
        "trend": trend,
    }


# ─── Leads list & detail ────────────────────────────────────────────────────

@router.get("/{tenant_id}/leads")
async def list_leads(
    tenant_id: UUID,
    stage: Optional[str] = None,
    tier: Optional[str] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    tag: Optional[str] = None,
    assigned_to: Optional[str] = None,
    priority: Optional[str] = None,
    sort: str = "delivered_at",
    order: str = "desc",
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    """Paginated, filterable lead list for the CRM table view."""
    sb = _sb()
    tid = str(tenant_id)

    q = sb.table("crm_lead_cards").select("*", count="exact").eq("tenant_id", tid)

    if stage:
        q = q.eq("stage_slug", stage)
    if tier:
        q = q.eq("tier", tier.upper())
    if status:
        q = q.eq("assignment_status", status)
    if assigned_to:
        q = q.eq("assigned_to", assigned_to)
    if priority:
        q = q.eq("priority", priority)
    if tag:
        q = q.contains("tags", [tag])
    if search:
        # Simple ilike on company name — for production add full-text
        q = q.ilike("company_name", f"%{search}%")

    desc = order.lower() != "asc"
    q = q.order(sort if sort in (
        "delivered_at", "total_score", "company_name", "next_action_at", "priority"
    ) else "delivered_at", desc=desc)

    q = q.range(offset, offset + limit - 1)
    r = q.execute()
    return {
        "total": r.count if hasattr(r, "count") else len(r.data or []),
        "limit": limit,
        "offset": offset,
        "leads": r.data or [],
    }


@router.get("/{tenant_id}/leads/{assignment_id}")
async def lead_detail(tenant_id: UUID, assignment_id: UUID):
    """Full lead card + timeline + tasks + score transparency (why this lead)."""
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)

    cards = (
        sb.table("crm_lead_cards")
        .select("*")
        .eq("tenant_id", tid)
        .eq("assignment_id", aid)
        .limit(1)
        .execute()
        .data or []
    )
    if not cards:
        raise HTTPException(404, "Lead not found")

    card = cards[0]
    activities = (
        sb.table("lead_activities")
        .select("*")
        .eq("assignment_id", aid)
        .order("created_at", desc=True)
        .limit(100)
        .execute()
        .data or []
    )
    tasks = (
        sb.table("lead_tasks")
        .select("*")
        .eq("assignment_id", aid)
        .order("created_at", desc=True)
        .execute()
        .data or []
    )

    # Score transparency — "Why this lead" panel data
    why_this_lead = None
    lead_id = card.get("lead_id")
    if not lead_id:
        # Fallback: assignment row always has lead_id even if the view omits it
        try:
            arows = (
                sb.table("lead_assignments")
                .select("lead_id")
                .eq("id", aid)
                .eq("tenant_id", tid)
                .limit(1)
                .execute()
                .data or []
            )
            if arows:
                lead_id = arows[0].get("lead_id")
        except Exception:
            pass
    if lead_id:
        try:
            score_rows = (
                sb.table("scores")
                .select("total_score, tier, reasoning, deterministic_score, scored_at")
                .eq("lead_id", lead_id)
                .order("scored_at", desc=True)
                .limit(1)
                .execute()
                .data or []
            )
            if score_rows:
                s = score_rows[0]
                reasoning = s.get("reasoning") or ""
                bullets = [r.strip() for r in reasoning.split(";") if r.strip()]
                why_this_lead = {
                    "total_score": s.get("total_score"),
                    "tier": s.get("tier"),
                    "reasoning": reasoning,
                    "bullets": bullets,
                    "scored_at": s.get("scored_at"),
                }
        except Exception:
            why_this_lead = None

    return {
        "lead": card,
        "activities": activities,
        "tasks": tasks,
        "why_this_lead": why_this_lead,
    }


@router.patch("/{tenant_id}/leads/{assignment_id}")
async def update_lead(tenant_id: UUID, assignment_id: UUID, body: LeadUpdate):
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    payload = {k: v for k, v in body.model_dump().items() if v is not None}
    if not payload:
        raise HTTPException(400, "No fields to update")

    # Fetch lead_id for activity
    row = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        raise HTTPException(404, "Lead not found")

    sb.table("lead_assignments").update(payload).eq("id", aid).eq("tenant_id", tid).execute()
    await _log_activity(
        tid, aid, row[0]["lead_id"], "system",
        title="Lead updated", meta=payload,
    )
    return {"ok": True, "updated": list(payload.keys())}


@router.post("/{tenant_id}/leads/{assignment_id}/stage")
async def change_stage(tenant_id: UUID, assignment_id: UUID, body: StageChangeRequest):
    """Move lead to a pipeline stage + log activity."""
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)

    current = (
        sb.table("lead_assignments")
        .select("lead_id, stage_id, status")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not current:
        raise HTTPException(404, "Lead not found")

    stage = (
        sb.table("pipeline_stages")
        .select("*")
        .eq("id", body.stage_id)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not stage:
        raise HTTPException(400, "Invalid stage")

    stage = stage[0]
    new_status = "won" if stage.get("is_won") else ("rejected" if stage.get("is_lost") else "new")
    # Keep contacted/etc. semantics loose — status mirrors stage outcome
    if stage["slug"] in ("contacted", "qualified", "proposal", "negotiation"):
        new_status = "contacted"

    sb.table("lead_assignments").update({
        "stage_id": body.stage_id,
        "stage_slug": stage.get("slug"),
        "status": new_status,
        "last_contacted_at": _now() if stage["slug"] != "new" else None,
    }).eq("id", aid).execute()

    await _log_activity(
        tid, aid, current[0]["lead_id"], "stage_change",
        title=f"Moved to {stage['name']}",
        body=body.note,
        meta={"from_stage_id": current[0].get("stage_id"), "to_stage_id": body.stage_id, "to_slug": stage["slug"]},
    )
    return {"ok": True, "stage": stage}


@router.post("/{tenant_id}/leads/bulk-stage")
async def bulk_stage(tenant_id: UUID, body: BulkStageRequest):
    results = []
    for aid in body.assignment_ids:
        try:
            r = await change_stage(tenant_id, UUID(aid), StageChangeRequest(stage_id=body.stage_id))
            results.append({"id": aid, "ok": True})
        except Exception as e:
            results.append({"id": aid, "ok": False, "error": str(e)})
    return {"results": results}


# ─── Activities & tasks ─────────────────────────────────────────────────────

@router.post("/{tenant_id}/leads/{assignment_id}/activities")
async def add_activity(tenant_id: UUID, assignment_id: UUID, body: ActivityCreate):
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    row = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        raise HTTPException(404, "Lead not found")

    r = sb.table("lead_activities").insert({
        "tenant_id": tid,
        "assignment_id": aid,
        "lead_id": row[0]["lead_id"],
        "activity_type": body.activity_type,
        "title": body.title,
        "body": body.body,
        "meta": body.meta,
    }).execute()

    # Touch last_contacted for call/email/sms
    if body.activity_type in ("call", "email", "sms", "meeting"):
        sb.table("lead_assignments").update({
            "last_contacted_at": _now(),
        }).eq("id", aid).execute()

    return r.data[0] if r.data else {"ok": True}


@router.post("/{tenant_id}/leads/{assignment_id}/tasks")
async def create_task(tenant_id: UUID, assignment_id: UUID, body: TaskCreate):
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    row = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
    )
    if not row:
        raise HTTPException(404, "Lead not found")

    r = sb.table("lead_tasks").insert({
        "tenant_id": tid,
        "assignment_id": aid,
        "lead_id": row[0]["lead_id"],
        "title": body.title,
        "description": body.description,
        "due_at": body.due_at,
        "priority": body.priority,
        "assigned_to": body.assigned_to,
        "status": "open",
    }).execute()

    await _log_activity(
        tid, aid, row[0]["lead_id"], "task_created",
        title=body.title, meta={"due_at": body.due_at},
    )
    return r.data[0] if r.data else {"ok": True}


@router.post("/{tenant_id}/tasks/{task_id}/complete")
async def complete_task(tenant_id: UUID, task_id: UUID):
    sb = _sb()
    sb.table("lead_tasks").update({
        "status": "done",
        "completed_at": _now(),
    }).eq("id", str(task_id)).eq("tenant_id", str(tenant_id)).execute()
    return {"ok": True}


# ─── Pipeline (Kanban) ──────────────────────────────────────────────────────

@router.get("/{tenant_id}/pipeline")
async def pipeline_board(tenant_id: UUID):
    """All stages with leads nested — for Kanban UI."""
    sb = _sb()
    tid = str(tenant_id)
    stages = (
        sb.table("pipeline_stages")
        .select("*")
        .eq("tenant_id", tid)
        .order("position")
        .execute()
        .data or []
    )
    cards = (
        sb.table("crm_lead_cards")
        .select("*")
        .eq("tenant_id", tid)
        .order("total_score", desc=True)
        .execute()
        .data or []
    )
    by_stage: dict[str, list] = {s["id"]: [] for s in stages}
    unstaged = []
    for c in cards:
        sid = c.get("stage_id")
        if sid and sid in by_stage:
            by_stage[sid].append(c)
        else:
            unstaged.append(c)

    return {
        "stages": [
            {**s, "leads": by_stage.get(s["id"], [])}
            for s in stages
        ],
        "unstaged": unstaged,
    }


@router.get("/{tenant_id}/stages")
async def list_stages(tenant_id: UUID):
    sb = _sb()
    return (
        sb.table("pipeline_stages")
        .select("*")
        .eq("tenant_id", str(tenant_id))
        .order("position")
        .execute()
        .data or []
    )


@router.post("/{tenant_id}/stages/seed")
async def seed_stages(tenant_id: UUID):
    sb = _sb()
    try:
        sb.rpc("seed_default_stages", {"p_tenant_id": str(tenant_id)}).execute()
    except Exception:
        # Fallback insert if RPC missing
        defaults = [
            ("New", "new", 0, "#94a3b8", False, False),
            ("Contacted", "contacted", 1, "#3b82f6", False, False),
            ("Qualified", "qualified", 2, "#8b5cf6", False, False),
            ("Proposal", "proposal", 3, "#f59e0b", False, False),
            ("Negotiation", "negotiation", 4, "#f97316", False, False),
            ("Won", "won", 5, "#22c55e", True, False),
            ("Lost", "lost", 6, "#ef4444", False, True),
        ]
        for name, slug, pos, color, won, lost in defaults:
            try:
                sb.table("pipeline_stages").upsert({
                    "tenant_id": str(tenant_id),
                    "name": name, "slug": slug, "position": pos,
                    "color": color, "is_won": won, "is_lost": lost,
                }, on_conflict="tenant_id,slug").execute()
            except Exception:
                pass
    return await list_stages(tenant_id)


# ─── Reports ────────────────────────────────────────────────────────────────

@router.get("/{tenant_id}/reports/summary")
async def reports_summary(tenant_id: UUID):
    """Conversion, tier mix, delivery stats for Reports page."""
    sb = _sb()
    tid = str(tenant_id)
    cards = (
        sb.table("crm_lead_cards")
        .select("tier, stage_slug, total_score, delivered_at, has_booking, email")
        .eq("tenant_id", tid)
        .execute()
        .data or []
    )
    total = len(cards)
    with_email = sum(1 for c in cards if c.get("email"))
    with_booking = sum(1 for c in cards if c.get("has_booking"))
    by_tier = {"A": 0, "B": 0, "C": 0}
    by_stage: dict = {}
    for c in cards:
        by_tier[c.get("tier") or "C"] = by_tier.get(c.get("tier") or "C", 0) + 1
        s = c.get("stage_slug") or "unknown"
        by_stage[s] = by_stage.get(s, 0) + 1

    return {
        "total": total,
        "with_email": with_email,
        "with_email_pct": round(100 * with_email / total, 1) if total else 0,
        "with_booking": with_booking,
        "by_tier": by_tier,
        "by_stage": by_stage,
        "avg_score": round(sum(c.get("total_score") or 0 for c in cards) / total, 1) if total else 0,
    }


# ─── Export ─────────────────────────────────────────────────────────────────

@router.get("/{tenant_id}/export/csv")
async def export_csv(
    tenant_id: UUID,
    stage: Optional[str] = None,
    tier: Optional[str] = None,
):
    """Return lead rows as JSON (frontend turns into CSV download)."""
    data = await list_leads(
        tenant_id, stage=stage, tier=tier, limit=500, offset=0
    )
    rows = []
    for l in data.get("leads") or []:
        rows.append({
            "company": l.get("company_name"),
            "phone": l.get("phone_e164") or l.get("phone_normalized"),
            "email": l.get("email"),
            "website": l.get("website"),
            "city": l.get("city"),
            "tier": l.get("tier"),
            "score": l.get("total_score"),
            "stage": l.get("stage_name"),
            "booking": l.get("booking_platform"),
            "priority": l.get("priority"),
            "delivered_at": l.get("delivered_at"),
        })
    return {"filename": f"leads-{tenant_id}-{datetime.now(timezone.utc).date()}.csv", "rows": rows}


# ─── Onboarding helper ──────────────────────────────────────────────────────

@router.post("/{tenant_id}/setup")
async def setup_tenant_crm(tenant_id: UUID):
    """
    Provision a new tenant portal: lead pipeline stages AND the CRM deal
    pipeline. Both are idempotent, so this is safe to call repeatedly.

    Deal stages are seeded here because sql/017_crm_seed.sql only ever covered
    the demo tenant — every real tenant otherwise landed on an empty deals
    board with no in-app way to populate it.
    """
    stages = await seed_stages(tenant_id)

    deal_stages: list = []
    try:
        from backend.crm.crm_entities_api import _seed_deal_stages
        deal_stages = _seed_deal_stages(str(tenant_id))
    except Exception as e:  # CRM tables not migrated yet — don't fail onboarding
        logger.warning("deal stage seeding skipped for %s: %s", tenant_id, e)

    return {"ok": True, "stages": stages, "deal_stages": deal_stages}


class BadLeadReport(BaseModel):
    reason: str = "wrong_number"
    detail: str = ""


@router.post("/{tenant_id}/leads/{assignment_id}/bad-lead")
async def report_bad_lead(tenant_id: UUID, assignment_id: UUID, body: BadLeadReport):
    """
    Client reports dead/wrong lead — opens ops ticket and applies SLA credit
    immediately (idempotent). Response always includes a clear credit status
    so the UI can show "Credited: 1 lead" instead of a silent backend action.
    """
    from backend.integrations.prod.qa import report_bad_lead as _report
    from backend.integrations.prod.credits import credit_dead_contact
    sb = _sb()
    tid, aid = str(tenant_id), str(assignment_id)
    rows = (
        sb.table("lead_assignments")
        .select("id, lead_id")
        .eq("id", aid)
        .eq("tenant_id", tid)
        .limit(1)
        .execute()
        .data
        or []
    )
    if not rows:
        raise HTTPException(404, "assignment not found")

    report = await _report(
        tid,
        aid,
        body.reason,
        body.detail,
        lead_id=rows[0].get("lead_id"),
    )

    # Map client reason → credit_type (idempotent inside credit_dead_contact)
    reason_map = {
        "wrong_number": "dead_phone",
        "dead_phone": "dead_phone",
        "dead_email": "dead_email",
        "email_bounce": "bounce",
        "bounce": "bounce",
        "closed": "closed_business",
        "closed_business": "closed_business",
        "duplicate": "duplicate",
        "other": "manual",
    }
    credit_type = reason_map.get((body.reason or "").lower(), "manual")
    credit_result = {"ok": False, "credited": 0}
    try:
        credit_result = await credit_dead_contact(
            tid, aid, credit_type, {"report_id": report.get("id"), "source": "client_report"}
        )
    except Exception:
        credit_result = {"ok": False, "credited": 0, "error": "credit_failed"}

    credited = bool(credit_result.get("credited") or credit_result.get("already_credited"))
    return {
        "ok": True,
        "report": report,
        "credit": {
            "applied": credited,
            "already_credited": bool(credit_result.get("already_credited")),
            "credit_type": credit_type,
            "message": (
                "Already credited earlier for this lead."
                if credit_result.get("already_credited")
                else ("1 lead credited to your quota." if credited else "Report received — credit pending review.")
            ),
        },
    }


@router.get("/{tenant_id}/export/instantly")
async def client_export_instantly(tenant_id: UUID, limit: int = 200):
    from backend.integrations.prod.sequence_export import leads_to_instantly_csv
    from fastapi.responses import PlainTextResponse
    sb = _sb()
    assigns = (
        sb.table("lead_assignments")
        .select("lead_id")
        .eq("tenant_id", str(tenant_id))
        .order("assigned_at", desc=True)
        .limit(min(limit, 500))
        .execute()
        .data
        or []
    )
    leads = []
    lead_ids = [a.get("lead_id") for a in assigns if a.get("lead_id")]
    if lead_ids:
        # Batched instead of 3 queries per lead (was up to 1,500 sequential
        # round-trips for a 500-lead export, tying up a worker the whole
        # time — same class of issue as the single-worker fix, just at the
        # query level instead of the process level).
        g_rows = sb.table("leads_global").select("*").in_("id", lead_ids).execute().data or []
        e_rows = sb.table("enrichment").select("lead_id, email, booking_platform, pitch_line, intent_score, owner_name").in_("lead_id", lead_ids).execute().data or []
        s_rows = sb.table("scores").select("lead_id, total_score, tier, pitch_line").in_("lead_id", lead_ids).execute().data or []
        g_by_id = {g["id"]: g for g in g_rows}
        e_by_id = {e["lead_id"]: e for e in e_rows}
        s_by_id = {s["lead_id"]: s for s in s_rows}
        for lid in lead_ids:
            g = g_by_id.get(lid)
            if not g:
                continue
            row = {**g}
            e = e_by_id.get(lid)
            s = s_by_id.get(lid)
            if e:
                row.update(e)
            if s:
                row["score"] = s.get("total_score")
                row["tier"] = s.get("tier")
                row["pitch_line"] = row.get("pitch_line") or s.get("pitch_line")
            leads.append(row)
    return PlainTextResponse(leads_to_instantly_csv(leads), media_type="text/csv")


# ─── Branding (tenant-facing — no service key) ───────────────────────────────

class BrandingBody(BaseModel):
    brand_name: Optional[str] = None
    brand_logo_url: Optional[str] = None
    brand_primary_color: Optional[str] = None
    brand_accent_color: Optional[str] = None
    brand_favicon_url: Optional[str] = None
    custom_domain: Optional[str] = None
    support_email: Optional[str] = None


@router.get("/{tenant_id}/branding")
async def crm_get_branding(tenant_id: UUID):
    """Public to tenant portal — white-label CSS vars. No operator key."""
    from backend.memory.supabase_client import get_supabase
    rows = (
        get_supabase().table("tenants")
        .select(
            "id, name, brand_name, brand_logo_url, brand_primary_color, "
            "brand_accent_color, brand_favicon_url, custom_domain, support_email"
        )
        .eq("id", str(tenant_id))
        .limit(1)
        .execute()
        .data
        or []
    )
    if not rows:
        return {"id": str(tenant_id), "name": "Workspace"}
    return rows[0]


@router.patch("/{tenant_id}/branding")
async def crm_update_branding(tenant_id: UUID, body: BrandingBody):
    """Tenant admin updates their own brand. Secured layer enforces JWT."""
    from backend.memory.supabase_client import get_supabase
    payload = {k: v for k, v in body.model_dump().items() if v is not None}
    if not payload:
        return {"ok": False, "error": "no fields"}
    get_supabase().table("tenants").update(payload).eq("id", str(tenant_id)).execute()
    return {"ok": True, "updated": list(payload.keys())}


# ─── Team (tenant-facing) ────────────────────────────────────────────────────

class CrmInviteBody(BaseModel):
    email: str
    role: str = "member"
    invited_by: Optional[str] = None
    send_email: bool = True


@router.get("/{tenant_id}/team/members")
async def crm_team_members(tenant_id: UUID):
    from backend.integrations.prod.team_invites import list_members, list_invites
    return {
        "members": await list_members(str(tenant_id)),
        "invites": await list_invites(str(tenant_id)),
    }


@router.post("/{tenant_id}/team/invite")
async def crm_team_invite(tenant_id: UUID, body: CrmInviteBody):
    from backend.integrations.prod.team_invites import create_invite
    try:
        return await create_invite(
            str(tenant_id), body.email, body.role, body.invited_by, body.send_email
        )
    except ValueError as e:
        from fastapi import HTTPException
        raise HTTPException(400, str(e))


class CrmAcceptInviteBody(BaseModel):
    token: str
    full_name: Optional[str] = None


@crm_public_router.post("/team/accept")
async def crm_team_accept(body: CrmAcceptInviteBody, user: AuthedUser = Depends(require_auth_only)):
    """
    Accept invite by token. auth_user_id comes from the verified JWT
    (require_auth_only), never from the request body — a client-supplied
    user id here would let anyone bind someone else's invite to their own
    account.
    """
    from backend.integrations.prod.team_invites import accept_invite
    return await accept_invite(body.token, user.user_id, body.full_name)


@router.get("/{tenant_id}/docs/templates")
async def crm_docs_templates(tenant_id: UUID, category: Optional[str] = None):
    from backend.integrations.prod.doc_templates import list_templates
    return {"templates": await list_templates(str(tenant_id), category)}


class CrmDocSend(BaseModel):
    template_id: str
    variables: dict = {}
    channel: str = "email"
    to_email: Optional[str] = None
    to_phone: Optional[str] = None


@router.post("/{tenant_id}/docs/send")
async def crm_docs_send(tenant_id: UUID, body: CrmDocSend):
    from backend.integrations.prod.doc_templates import generate_and_send
    try:
        return await generate_and_send(
            str(tenant_id), body.template_id, body.variables or {},
            channel=body.channel, to_email=body.to_email, to_phone=body.to_phone,
        )
    except ValueError as e:
        from fastapi import HTTPException
        raise HTTPException(400, str(e))


class CrmWeightsBody(BaseModel):
    icp_id: str
    weights: dict


@router.patch("/{tenant_id}/icp/weights")
async def crm_icp_weights(tenant_id: UUID, body: CrmWeightsBody):
    from backend.memory.supabase_client import get_supabase
    sb = get_supabase()
    rows = sb.table("icp_profiles").select("id, tenant_id, weights").eq("id", body.icp_id).limit(1).execute().data or []
    if not rows or rows[0]["tenant_id"] != str(tenant_id):
        from fastapi import HTTPException
        raise HTTPException(404, "icp not found")
    base = rows[0].get("weights") or {}
    base.update(body.weights or {})
    sb.table("icp_profiles").update({"weights": base, "client_weight_overrides": body.weights}).eq("id", body.icp_id).execute()
    return {"ok": True, "weights": base}


class FirstTouchBody(BaseModel):
    channel: Optional[str] = None  # sms | voice


@router.post("/{tenant_id}/leads/{assignment_id}/first-touch")
async def crm_first_touch(tenant_id: UUID, assignment_id: UUID, body: FirstTouchBody = FirstTouchBody()):
    """
    Manual one-shot first touch — user toggles send in CRM.
    Not fired automatically on pipeline assign.
    """
    from backend.memory.supabase_client import get_supabase
    from backend.integrations.prod.first_touch import send_first_touch_manual
    sb = get_supabase()
    rows = (
        sb.table("lead_assignments")
        .select("id, lead_id, tenant_id, first_touch_status")
        .eq("id", str(assignment_id))
        .eq("tenant_id", str(tenant_id))
        .limit(1)
        .execute()
        .data
        or []
    )
    if not rows:
        from fastapi import HTTPException
        raise HTTPException(404, "assignment not found")
    a = rows[0]
    # Idempotent: already sent successfully → do not re-fire unless forced later
    if a.get("first_touch_status") == "sent":
        return {"ok": False, "skipped": "already_sent", "status": "sent"}
    lead_rows = (
        sb.table("leads_global")
        .select("*")
        .eq("id", a["lead_id"])
        .limit(1)
        .execute()
        .data
        or []
    )
    if not lead_rows:
        from fastapi import HTTPException
        raise HTTPException(404, "lead not found")
    lead = lead_rows[0]
    return await send_first_touch_manual(
        str(tenant_id), lead, assignment_id=str(assignment_id), channel=body.channel
    )


# ─── Email outreach (Resend / SMTP) ─────────────────────────────────────────

class EmailSendBody(BaseModel):
    subject: str
    body_html: str
    body_text: Optional[str] = None
    reply_to: Optional[str] = None


class EmailBulkBody(BaseModel):
    subject: str
    body_html: str
    body_text: Optional[str] = None
    reply_to: Optional[str] = None
    assignment_ids: Optional[list[str]] = None  # if empty → filtered send-all
    tier: Optional[str] = None
    stage: Optional[str] = None
    limit: int = 100


@router.post("/{tenant_id}/leads/{assignment_id}/email")
async def crm_email_send(tenant_id: UUID, assignment_id: UUID, body: EmailSendBody):
    """Send one custom email to a lead (Resend or SMTP)."""
    from backend.integrations.prod.email_outreach import send_to_lead
    if not (body.subject or "").strip() or not (body.body_html or "").strip():
        from fastapi import HTTPException
        raise HTTPException(400, "subject and body_html required")
    return await send_to_lead(
        str(tenant_id),
        str(assignment_id),
        body.subject,
        body.body_html,
        body.body_text or "",
        reply_to=body.reply_to,
    )


@router.post("/{tenant_id}/email/bulk")
async def crm_email_bulk(tenant_id: UUID, body: EmailBulkBody):
    """Send custom email to selected leads, or all matching filters (Send all)."""
    from backend.integrations.prod.email_outreach import send_bulk, send_bulk_filtered
    if not (body.subject or "").strip() or not (body.body_html or "").strip():
        from fastapi import HTTPException
        raise HTTPException(400, "subject and body_html required")
    if body.assignment_ids:
        return await send_bulk(
            str(tenant_id),
            body.assignment_ids,
            body.subject,
            body.body_html,
            body.body_text or "",
            reply_to=body.reply_to,
        )
    return await send_bulk_filtered(
        str(tenant_id),
        body.subject,
        body.body_html,
        body.body_text or "",
        tier=body.tier,
        stage=body.stage,
        limit=body.limit or 100,
        reply_to=body.reply_to,
    )

# ─── One-page Search → leads (web UI) ────────────────────────────────────────

class SearchRunBody(BaseModel):
    vertical: str
    geo: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    offer_category: Optional[str] = None
    name: Optional[str] = None
    limit_per_location: int = Field(default=12, ge=1, le=50)
    target_new_leads: Optional[int] = Field(default=None, ge=1, le=5000)
    allow_tier_b: bool = True
    deliver: bool = True
    save_icp: bool = True


@router.post("/{tenant_id}/search-run")
async def crm_search_run(tenant_id: UUID, body: SearchRunBody):
    """Type ICP → run pipeline → return lead cards for the web Search tab."""
    import time
    from backend.memory.supabase_client import get_supabase
    from backend.integrations.prod.pipeline import run_pipeline as _run
    from fastapi import HTTPException

    t0 = time.perf_counter()
    sb = get_supabase()
    tid = str(tenant_id)
    vertical = (body.vertical or "").strip()
    if not vertical:
        raise HTTPException(400, "vertical required")

    geos = body.geo or []
    if isinstance(geos, str):
        geos = [g.strip() for g in geos.split(",") if g.strip()]
    keywords = body.keywords or []
    if isinstance(keywords, str):
        keywords = [k.strip() for k in keywords.split(",") if k.strip()]

    offer = (body.offer_category or "lead_gen_service").strip().lower().replace(" ", "_")
    icp_id = None

    if body.save_icp:
        icp_name = body.name or f"{vertical} — {', '.join(geos[:2]) or 'search'}"
        existing = (
            sb.table("icp_profiles")
            .select("id, name, geo, offer_category")
            .eq("tenant_id", tid)
            .eq("vertical", vertical)
            .eq("active", True)
            .limit(20)
            .execute()
            .data
            or []
        )
        for e in existing:
            eg = e.get("geo") or []
            if (e.get("offer_category") or "").lower() == offer and set(eg) == set(geos):
                icp_id = e["id"]
                break
        if not icp_id:
            row = {
                "tenant_id": tid,
                "name": icp_name,
                "vertical": vertical,
                "geo": geos,
                "keywords": keywords,
                "offer_category": offer,
                "exclusivity": "exclusive",
                "active": True,
            }
            ins = sb.table("icp_profiles").insert(row).execute().data or []
            if ins:
                icp_id = ins[0]["id"]

    run = await _run(
        tenant_id=tid,
        icp_id=icp_id,
        industry=vertical,
        locations=geos or None,
        queries=keywords or None,
        limit_per_location=min(body.limit_per_location, 30),
        allow_tier_b=body.allow_tier_b,
        deliver=body.deliver,
        target_new_leads=body.target_new_leads,
        max_enrich_concurrent=3,
        social_limit_per_source=10,
        include_linkedin=True,
        include_instagram=True,
    )

    cards = []
    try:
        assigns = (
            sb.table("lead_assignments")
            .select("id, lead_id, tier, status, delivered_at, offer_category")
            .eq("tenant_id", tid)
            .not_.in_("status", ["rejected", "expired"])
            .order("delivered_at", desc=True)
            .limit(100)
            .execute()
            .data
            or []
        )
        lead_ids = [a["lead_id"] for a in assigns if a.get("lead_id")]
        leads_by_id = {}
        en_by = {}
        if lead_ids:
            leads = (
                sb.table("leads_global")
                .select(
                    "id, name, phone_e164, phone, email, website, city, state, "
                    "google_rating, review_count, pitch_line, talking_points, tier"
                )
                .in_("id", lead_ids)
                .execute()
                .data
                or []
            )
            leads_by_id = {x["id"]: x for x in leads}
            try:
                enr = (
                    sb.table("enrichment")
                    .select("lead_id, email, pitch_line, owner_name, intent_score")
                    .in_("lead_id", lead_ids)
                    .execute()
                    .data
                    or []
                )
                en_by = {e["lead_id"]: e for e in enr}
            except Exception:
                pass
        for a in assigns:
            L = leads_by_id.get(a["lead_id"]) or {}
            E = en_by.get(a["lead_id"]) or {}
            cards.append({
                "assignment_id": a["id"],
                "lead_id": a["lead_id"],
                "name": L.get("name"),
                "tier": a.get("tier") or L.get("tier"),
                "phone": L.get("phone_e164") or L.get("phone"),
                "email": L.get("email") or E.get("email"),
                "website": L.get("website"),
                "city": L.get("city"),
                "state": L.get("state"),
                "rating": L.get("google_rating"),
                "reviews": L.get("review_count"),
                "pitch_line": L.get("pitch_line") or E.get("pitch_line"),
                "talking_points": L.get("talking_points"),
                "owner_name": E.get("owner_name"),
                "intent_score": E.get("intent_score"),
                "status": a.get("status"),
                "delivered_at": a.get("delivered_at"),
            })
    except Exception as e:
        if not isinstance(run, dict):
            run = {"result": run}
        run = {**run, "leads_fetch_error": str(e)}

    duration_ms = int((time.perf_counter() - t0) * 1000)
    run_dict = run if isinstance(run, dict) else {"result": run}
    with_email = sum(1 for c in cards if c.get("email"))
    with_phone = sum(1 for c in cards if c.get("phone"))
    tiers = {}
    sources = {}
    for c in cards:
        t = (c.get("tier") or "?").upper()
        tiers[t] = tiers.get(t, 0) + 1
    # source counts from run summary if present
    src = run_dict.get("sources") or run_dict.get("source_counts") or {}

    # Quota is derived from pipeline_runs (started by run_pipeline).
    # No separate usage_log event row — usage_log is a monthly aggregate table.

    return {
        "ok": True,
        "icp_id": icp_id,
        "run": run_dict,
        "leads": cards,
        "count": len(cards),
        "with_email": with_email,
        "with_phone": with_phone,
        "tiers": tiers,
        "sources": src,
        "duration_ms": duration_ms,
        "duration_sec": round(duration_ms / 1000, 1),
    }


# ─── Sample pack (sales tool) ───────────────────────────────────────────────

class SamplePackBody(BaseModel):
    vertical: str
    geo: str = ""
    limit: int = 10
    min_score: int = 60


@router.post("/{tenant_id}/sample-pack")
async def crm_sample_pack(tenant_id: UUID, body: SamplePackBody):
    """
    Get a free sample of high-quality leads for a vertical+geo.
    Does not consume exclusivity or billing quota — sales demo tool.
    """
    from backend.integrations.prod.sample_pack import build_sample_pack
    result = await build_sample_pack(
        vertical=body.vertical,
        geo=body.geo,
        limit=min(max(body.limit, 5), 20),
        tenant_id=str(tenant_id),
        min_score=body.min_score,
    )
    return result


@crm_public_router.post("/sample-pack/public")
async def public_sample_pack(body: SamplePackBody, request: Request):
    """
    Unauthenticated sample pack for marketing / 'get 10 free leads' landing page.
    Capped harder than the authenticated version, and IP-rate-limited since
    there's no tenant/user identity to key on — without this, repeated calls
    across vertical/geo combinations could be scripted to approximate the
    whole leads_global inventory even though individual responses are
    PII-stripped.
    """
    from backend.middleware.rate_limit import check_rate_limit, client_ip
    ip = client_ip(request)
    check_rate_limit(ip, "sample_pack_public", limit=5, window_seconds=3600)

    from backend.integrations.prod.sample_pack import build_sample_pack
    result = await build_sample_pack(
        vertical=body.vertical,
        geo=body.geo,
        limit=min(max(body.limit, 5), 10),
        tenant_id=None,
        min_score=max(body.min_score, 65),
    )
    # Strip sensitive fields for public response
    leads = result.get("leads") or result.get("samples") or []
    public_leads = []
    for l in leads[:10]:
        public_leads.append({
            "name": l.get("name"),
            "city": l.get("city"),
            "state": l.get("state"),
            "category": l.get("category"),
            "google_rating": l.get("google_rating"),
            "review_count": l.get("review_count"),
            "score": l.get("score"),
            "tier": l.get("tier"),
            "has_website": bool(l.get("website")),
            "has_phone": bool(l.get("phone_e164") or l.get("phone_normalized")),
        })
    return {"ok": True, "leads": public_leads, "count": len(public_leads), "vertical": body.vertical, "geo": body.geo}


# ─── Territory availability (admin + sales) ─────────────────────────────────

@router.get("/{tenant_id}/territory")
async def crm_territory(
    tenant_id: UUID,
    vertical: Optional[str] = None,
    geo: Optional[str] = None,
):
    """
    Which vertical+geo+offer_category combos are locked by exclusive ICPs.
    Useful during sales calls: "Newark's taken, Jersey City's open."
    """
    from backend.integrations.prod.territory import territory_availability
    return await territory_availability(vertical=vertical, geo=geo)


# ─── Search-run quota indicator ─────────────────────────────────────────────

@router.get("/{tenant_id}/search-quota")
async def crm_search_quota(tenant_id: UUID):
    """
    Remaining on-demand search-runs for the current billing period.
    Counts pipeline_runs this month (search-run creates a pipeline run).
    """
    sb = _sb()
    tid = str(tenant_id)
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    period_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()

    used = 0
    try:
        used_rows = (
            sb.table("pipeline_runs")
            .select("id", count="exact")
            .eq("tenant_id", tid)
            .gte("started_at", period_start)
            .execute()
        )
        used = used_rows.count if used_rows.count is not None else len(used_rows.data or [])
    except Exception:
        used = 0

    # tenants has no settings column — use plan defaults + delivery_config jsonb if present
    tenant = (
        sb.table("tenants")
        .select("id, plan, delivery_config, leads_per_month_limit")
        .eq("id", tid)
        .limit(1)
        .execute()
        .data or []
    )
    cfg = (tenant[0].get("delivery_config") or {}) if tenant else {}
    if not isinstance(cfg, dict):
        cfg = {}
    plan = (tenant[0].get("plan") if tenant else None) or "starter"
    plan_defaults = {"starter": 30, "growth": 80, "premium": 200, "enterprise": 9999}
    limit = int(
        cfg.get("search_run_limit")
        or cfg.get("monthly_search_limit")
        or plan_defaults.get(plan, 50)
    )
    remaining = max(0, limit - used)
    return {
        "ok": True,
        "period_start": period_start,
        "used": used,
        "limit": limit,
        "remaining": remaining,
        "unlimited": limit >= 9999,
    }

# ----- Tenant email / SES domain (client) -----
@router.get("/{tenant_id}/email-settings")
async def get_email_settings(tenant_id: str, ctx: TenantContext = Depends(require_tenant)):
    from backend.middleware.auth import assert_tenant_match
    from backend.integrations.prod.ses_domain import ses_status
    assert_tenant_match(ctx, tenant_id)
    tid = str(ctx.tenant_id)
    st = ses_status()
    try:
        sb = _sb()
        r = sb.table("tenant_email_settings").select("*").eq("tenant_id", tid).limit(1).execute()
        row = (r.data or [None])[0]
        if not row:
            return {
                "ok": True,
                "configured": False,
                "ses_account_ready": bool(st.get("ready")),
                "ses_status": st,
            }
        return {
            "ok": True,
            "configured": True,
            "ses_account_ready": bool(st.get("ready")),
            "ses_status": st,
            "settings": {
                "domain": row.get("domain"),
                "from_email": row.get("from_email"),
                "from_name": row.get("from_name"),
                "reply_to": row.get("reply_to"),
                "domain_verified": bool(row.get("domain_verified")),
                "dkim_status": row.get("dkim_status"),
                "dns_records": row.get("dns_records") or [],
                "provider": row.get("provider") or "ses",
            },
        }
    except Exception as e:
        return {"ok": False, "error": str(e)[:300], "ses_status": st}


@router.post("/{tenant_id}/email-settings/domain")
async def connect_email_domain(tenant_id: str, body: dict, ctx: TenantContext = Depends(require_tenant)):
    """Create SES identity on OUR account; return DNS records for the client."""
    from backend.middleware.auth import assert_tenant_match
    from backend.integrations.prod.ses_domain import create_domain_identity, ses_status
    assert_tenant_match(ctx, tenant_id)
    tid = str(ctx.tenant_id)
    domain = (body.get("domain") or "").strip().lower()
    from_email = (body.get("from_email") or "").strip()
    from_name = (body.get("from_name") or "").strip()
    reply_to = (body.get("reply_to") or "").strip() or None
    if not domain:
        raise HTTPException(400, "domain required")
    st = ses_status()
    if not st.get("ready"):
        raise HTTPException(503, st.get("message") or "SES not ready on server")
    result = create_domain_identity(domain)
    if not result.get("ok"):
        raise HTTPException(400, result.get("error") or result.get("hint") or "ses_failed")
    row = {
        "tenant_id": tid,
        "provider": "ses",
        "domain": domain,
        "from_email": from_email or f"leads@{domain}",
        "from_name": from_name or domain,
        "reply_to": reply_to,
        "domain_verified": bool(result.get("verified")),
        "dkim_status": result.get("dkim_status"),
        "dns_records": result.get("dns_records") or [],
        "status": "active",
    }
    try:
        _sb().table("tenant_email_settings").upsert(row, on_conflict="tenant_id").execute()
    except Exception as e:
        raise HTTPException(500, f"db: {e}")
    return {"ok": True, **result, "from_email": row["from_email"], "from_name": row["from_name"]}


@router.post("/{tenant_id}/email-settings/check")
async def check_email_domain(tenant_id: str, ctx: TenantContext = Depends(require_tenant)):
    from backend.middleware.auth import assert_tenant_match
    from backend.integrations.prod.ses_domain import get_domain_status
    assert_tenant_match(ctx, tenant_id)
    tid = str(ctx.tenant_id)
    sb = _sb()
    r = sb.table("tenant_email_settings").select("*").eq("tenant_id", tid).limit(1).execute()
    row = (r.data or [None])[0]
    if not row or not row.get("domain"):
        raise HTTPException(400, "no domain connected")
    st = get_domain_status(row["domain"])
    if not st.get("ok"):
        raise HTTPException(400, st.get("error") or st.get("hint") or "check_failed")
    try:
        sb.table("tenant_email_settings").update({
            "domain_verified": bool(st.get("verified")),
            "dkim_status": st.get("dkim_status"),
            "dns_records": st.get("dns_records") or row.get("dns_records"),
        }).eq("tenant_id", tid).execute()
    except Exception:
        pass
    return {"ok": True, **st}


