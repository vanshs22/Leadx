"""
Rate limiter for expensive endpoints.
Protects /pipeline/run, /keys/add, enrichment triggers from abuse.

Two backends:
  * Redis (used automatically when REDIS_URL is set) — shared across all
    uvicorn workers / containers, so the configured limit is the real limit.
  * In-memory (fallback) — counters live in a single process. With more than
    one worker the effective limit becomes N_workers x configured limit, so
    this backend is only appropriate for local development and tests.

Redis failures fail open onto the in-memory backend and are logged: a Redis
outage degrades rate limiting, it must never take the API down.
"""
from __future__ import annotations

import logging
import os
import time
from collections import defaultdict
from threading import Lock
from typing import Optional

from fastapi import HTTPException, Request, status

logger = logging.getLogger("lead_engine.rate_limit")

# defaults
PIPELINE_LIMIT = int(os.getenv("RATE_LIMIT_PIPELINE_PER_HOUR", "20"))
KEYS_LIMIT = int(os.getenv("RATE_LIMIT_KEYS_PER_HOUR", "10"))
API_LIMIT = int(os.getenv("RATE_LIMIT_API_PER_MINUTE", "120"))

# How often (seconds) to re-log a sustained Redis outage.
_ERROR_LOG_INTERVAL = 60.0
# How long to stop trying Redis after a failure, so every request does not pay
# the connect timeout while Redis is down.
_CIRCUIT_OPEN_SECONDS = 10.0

# Fixed-window counter. INCR + EXPIRE must be atomic: doing them as two
# round-trips lets concurrent requests both observe a missing TTL and both
# reset it, which slides the window forward forever and defeats the limit.
_WINDOW_LUA = """
local current = redis.call('INCR', KEYS[1])
if current == 1 then
  redis.call('EXPIRE', KEYS[1], ARGV[1])
end
local ttl = redis.call('TTL', KEYS[1])
if ttl < 0 then
  redis.call('EXPIRE', KEYS[1], ARGV[1])
  ttl = tonumber(ARGV[1])
end
return {current, ttl}
"""


class _MemoryWindow:
    """Sliding-window counter. Per-process only."""

    def __init__(self):
        self._hits: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()

    def hit(self, key: str, limit: int, window_seconds: int) -> tuple[bool, int]:
        now = time.time()
        cutoff = now - window_seconds
        with self._lock:
            bucket = [t for t in self._hits[key] if t > cutoff]
            if len(bucket) >= limit:
                self._hits[key] = bucket
                return False, 0
            bucket.append(now)
            self._hits[key] = bucket
            return True, limit - len(bucket)


class _RedisWindow:
    """
    Fixed-window counter in Redis, shared by every worker.

    The client is created once and reused (redis-py keeps an internal
    connection pool). On failure the circuit opens briefly so callers fall
    back to memory without paying the connect timeout on every request.
    """

    def __init__(self, url: str):
        self._url = url
        self._client = None
        self._script = None
        self._lock = Lock()
        self._circuit_open_until = 0.0
        self._last_error_log = 0.0

    def _connect(self):
        if self._client is not None:
            return self._client
        with self._lock:
            if self._client is None:
                import redis  # pinned in requirements.txt

                client = redis.from_url(
                    self._url,
                    decode_responses=True,
                    socket_connect_timeout=1,
                    socket_timeout=1,
                    health_check_interval=30,
                )
                self._script = client.register_script(_WINDOW_LUA)
                self._client = client
        return self._client

    def _note_failure(self, exc: Exception) -> None:
        now = time.time()
        self._circuit_open_until = now + _CIRCUIT_OPEN_SECONDS
        if now - self._last_error_log >= _ERROR_LOG_INTERVAL:
            self._last_error_log = now
            logger.warning(
                "Redis rate limiter unavailable (%s: %s) - failing open to "
                "per-process in-memory counters for up to %.0fs. Limits are "
                "NOT shared across workers while this persists.",
                type(exc).__name__,
                exc,
                _CIRCUIT_OPEN_SECONDS,
            )

    def hit(
        self, key: str, limit: int, window_seconds: int
    ) -> Optional[tuple[bool, int]]:
        """
        Returns (allowed, retry_after) or None when Redis is unusable and the
        caller should fall back to the in-memory backend.
        """
        if time.time() < self._circuit_open_until:
            return None
        try:
            client = self._connect()
            if client is None:
                return None
            count, ttl = self._script(keys=[key], args=[window_seconds])
            count = int(count)
            ttl = int(ttl)
            if ttl < 0:
                ttl = window_seconds
            if count > limit:
                return False, max(ttl, 1)
            return True, max(ttl, 1)
        except Exception as e:
            self._note_failure(e)
            self._client = None
            self._script = None
            return None


_memory = _MemoryWindow()

_redis_url = os.getenv("REDIS_URL") or ""
_redis: Optional[_RedisWindow] = _RedisWindow(_redis_url) if _redis_url.strip() else None


def _warn_if_memory_only() -> None:
    """
    Loud warning when a shared-state deployment is running per-process limits.
    In production/staging this means the effective limit is
    (number of workers) x (configured limit) — it fails open under exactly the
    load rate limiting exists to control.
    """
    if _redis is not None:
        logger.info("Rate limiter backend: Redis (shared across workers).")
        return
    env = (os.getenv("ENVIRONMENT") or "").strip().lower()
    if env in {"production", "prod", "staging", "stage"}:
        logger.warning(
            "RATE LIMITER IS IN-MEMORY IN %s. Counters are per-process: with "
            "N uvicorn workers the effective limit is N x the configured "
            "limit, and limits reset on every restart/redeploy. Set REDIS_URL "
            "to enable the shared Redis backend.",
            env.upper(),
        )
    else:
        logger.info(
            "Rate limiter backend: in-memory (per-process). Set REDIS_URL for "
            "shared limits across workers."
        )


_warn_if_memory_only()


def _too_many(action: str, retry_after: int) -> HTTPException:
    return HTTPException(
        status.HTTP_429_TOO_MANY_REQUESTS,
        detail=f"Rate limit exceeded for {action}. Try again later.",
        headers={"Retry-After": str(max(int(retry_after), 1))},
    )


def check_rate_limit(
    identity: str,
    action: str,
    limit: int,
    window_seconds: int,
) -> None:
    """
    Raises 429 if over limit.
    identity: user_id or tenant_id or IP

    Uses Redis when REDIS_URL is set (shared across workers), otherwise
    per-process in-memory counters.
    """
    key = f"rl:{action}:{identity}"

    if _redis is not None:
        result = _redis.hit(key, limit, window_seconds)
        if result is not None:
            allowed, retry_after = result
            if not allowed:
                raise _too_many(action, retry_after)
            return
        # result is None -> Redis unusable, fall through to memory (fail open)

    ok, _remaining = _memory.hit(key, limit, window_seconds)
    if not ok:
        raise _too_many(action, window_seconds)


def rate_limit_pipeline(identity: str) -> None:
    check_rate_limit(identity, "pipeline_run", PIPELINE_LIMIT, 3600)


def rate_limit_keys(identity: str) -> None:
    check_rate_limit(identity, "keys_add", KEYS_LIMIT, 3600)


def rate_limit_api(identity: str) -> None:
    check_rate_limit(identity, "api", API_LIMIT, 60)


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
