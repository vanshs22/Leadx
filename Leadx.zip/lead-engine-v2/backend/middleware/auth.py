"""
JWT auth middleware for Lead Engine + CRM.
Resolves tenant from verified token — NEVER trust tenant_id from the URL alone.

Usage:
  from backend.middleware.auth import require_tenant, TenantContext

  @router.get("/crm/dashboard")
  async def dashboard(ctx: TenantContext = Depends(require_tenant)):
      tid = ctx.tenant_id  # verified membership
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Optional
from uuid import UUID

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

logger = logging.getLogger("lead_engine.auth")
_bearer = HTTPBearer(auto_error=False)

# Dev bypass only when explicitly enabled AND not running in production.
#
# This flag grants owner-role access to ANY tenant on an unauthenticated request
# carrying an X-Tenant-Id header — a complete tenant-isolation bypass. start.sh
# writes it into .env by default, so relying on operators to unset it before
# deploying is not a safety model. It is now hard-disabled whenever
# ENVIRONMENT is production/staging, regardless of how the flag is set.
_ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()
_IS_PRODUCTION = _ENVIRONMENT in ("production", "prod", "staging")
_BYPASS_REQUESTED = os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes")
ALLOW_DEV_BYPASS = _BYPASS_REQUESTED and not _IS_PRODUCTION

if _BYPASS_REQUESTED and _IS_PRODUCTION:
    logger.critical(
        "LEAD_ENGINE_DEV_AUTH_BYPASS is set but ENVIRONMENT=%s — bypass FORCE-DISABLED. "
        "Remove the flag from your environment.",
        _ENVIRONMENT,
    )
elif ALLOW_DEV_BYPASS:
    logger.warning(
        "LEAD_ENGINE_DEV_AUTH_BYPASS enabled (env=%s) — unauthenticated requests with "
        "an X-Tenant-Id header get owner access. NEVER use this outside local dev.",
        _ENVIRONMENT,
    )


@dataclass
class TenantContext:
    tenant_id: str
    user_id: str
    role: str  # owner | admin | member | viewer
    email: Optional[str] = None


def _sb():
    from backend.memory.supabase_client import get_supabase
    return get_supabase()


async def _verify_supabase_jwt(token: str) -> dict:
    """
    Validate JWT via Supabase Auth (JWKS / user endpoint).
    Returns payload with 'sub' = auth user id.
    """
    import httpx

    supabase_url = os.getenv("SUPABASE_URL", "").rstrip("/")
    anon_key = os.getenv("SUPABASE_ANON_KEY", "")
    if not supabase_url:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Auth not configured")

    # Prefer local JWT verify if secret available
    jwt_secret = os.getenv("SUPABASE_JWT_SECRET") or os.getenv("JWT_SECRET")
    if jwt_secret:
        try:
            from jose import jwt as jose_jwt, JWTError
            payload = jose_jwt.decode(
                token,
                jwt_secret,
                algorithms=["HS256"],
                audience="authenticated",
                options={"verify_aud": False},  # Supabase aud can vary
            )
            if not payload.get("sub"):
                raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token: no sub")
            return payload
        except Exception as e:
            logger.debug("Local JWT decode failed, trying Auth API: %s", e)

    # Fallback: call Supabase Auth getUser
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            f"{supabase_url}/auth/v1/user",
            headers={
                "Authorization": f"Bearer {token}",
                "apikey": anon_key,
            },
        )
        if r.status_code != 200:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
        data = r.json()
        return {"sub": data.get("id"), "email": data.get("email"), **data}


async def _resolve_membership(user_id: str, tenant_id: Optional[str] = None) -> TenantContext:
    """
    Look up tenant_members for this auth user.
    If tenant_id provided, must be a member of that tenant.
    If not, use the first active membership (single-tenant portals).
    """
    sb = _sb()
    q = (
        sb.table("tenant_members")
        .select("tenant_id, role, email, status")
        .eq("auth_user_id", user_id)
        .eq("status", "active")
    )
    if tenant_id:
        q = q.eq("tenant_id", tenant_id)
    rows = q.limit(5).execute().data or []
    if not rows:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Not a member of this workspace",
        )
    row = rows[0]
    return TenantContext(
        tenant_id=row["tenant_id"],
        user_id=user_id,
        role=row.get("role") or "member",
        email=row.get("email"),
    )


async def require_tenant(
    request: Request,
    creds: Optional[HTTPAuthorizationCredentials] = Depends(_bearer),
) -> TenantContext:
    """
    Primary dependency: valid JWT + active tenant membership.
    Optional header X-Tenant-Id when user belongs to multiple tenants.
    """
    # Dev bypass — NEVER in production
    if ALLOW_DEV_BYPASS and not creds:
        dev_tenant = request.headers.get("X-Tenant-Id") or request.path_params.get("tenant_id")
        if dev_tenant:
            logger.warning("DEV AUTH BYPASS active for tenant %s", dev_tenant)
            return TenantContext(tenant_id=str(dev_tenant), user_id="dev", role="owner")

    if not creds or not creds.credentials:
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Missing Authorization Bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = await _verify_supabase_jwt(creds.credentials)
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")

    # Prefer explicit tenant header; else path param; else first membership
    header_tenant = request.headers.get("X-Tenant-Id")
    path_tenant = request.path_params.get("tenant_id")
    preferred = header_tenant or path_tenant

    # SECURITY: path tenant_id is only a HINT — membership is verified
    ctx = await _resolve_membership(user_id, preferred if preferred else None)

    # If path claimed a different tenant, reject
    if path_tenant and str(path_tenant) != ctx.tenant_id:
        # User might be member of path tenant — re-resolve
        try:
            ctx = await _resolve_membership(user_id, str(path_tenant))
        except HTTPException:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Access denied to this tenant")

    # Attach for downstream logging
    request.state.tenant = ctx
    return ctx


@dataclass
class AuthedUser:
    user_id: str
    email: Optional[str] = None


async def require_auth_only(
    creds: Optional[HTTPAuthorizationCredentials] = Depends(_bearer),
) -> AuthedUser:
    """
    Lightweight dependency: valid Supabase JWT, no tenant-membership check.
    Use only for pre-membership actions (e.g. accepting a team invite) —
    everything else should use require_tenant.
    """
    if ALLOW_DEV_BYPASS and not creds:
        logger.warning("DEV AUTH BYPASS active for require_auth_only")
        return AuthedUser(user_id="dev", email="dev@local")
    if not creds or not creds.credentials:
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Missing Authorization Bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    payload = await _verify_supabase_jwt(creds.credentials)
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")
    return AuthedUser(user_id=user_id, email=payload.get("email"))


async def require_admin(ctx: TenantContext = Depends(require_tenant)) -> TenantContext:
    if ctx.role not in ("owner", "admin"):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Admin role required")
    return ctx


def assert_tenant_match(ctx: TenantContext, tenant_id: str | UUID) -> None:
    """Call inside handlers that still accept tenant_id in path for URL design."""
    if str(tenant_id) != ctx.tenant_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Tenant mismatch")
