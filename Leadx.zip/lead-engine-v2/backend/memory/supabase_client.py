def get_supabase():
    raise RuntimeError("supabase not configured in test")
