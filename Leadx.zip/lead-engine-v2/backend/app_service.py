from __future__ import annotations

from pathlib import Path
try:
    from dotenv import load_dotenv
    # Load .env from lead-engine-v2 root (cwd when running uvicorn)
    load_dotenv()
    load_dotenv(Path(__file__).resolve().parents[1] / ".env")
except ImportError:
    pass  # python-dotenv optional; use exported env vars

"""
Lead Engine — managed service entrypoint.
  uvicorn backend.app_service:app --host 0.0.0.0 --port 8000
"""

import logging
import os

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("lead_engine.service")

app = FastAPI(
    title="Automiqo Lead Service",
    version="2.2.0",
    description="Managed lead generation — operator API + client CRM",
)

IS_PRODUCTION = os.getenv("ENVIRONMENT", "development").lower() in (
    "production", "prod", "staging",
)

# LEADX_MODE=local swaps Supabase for a JSON-backed in-memory store so the app
# runs with zero external accounts. It is a dev/demo affordance only.
LOCAL_MODE = os.getenv("LEADX_MODE", "").strip().lower() == "local"
if LOCAL_MODE and IS_PRODUCTION:
    raise RuntimeError(
        "LEADX_MODE=local cannot be used with ENVIRONMENT=production/staging — "
        "it stores data in local JSON files, not a database."
    )

# Development: allow all origins (Codespaces / local). Production: CORS_ORIGINS required.
_env = os.getenv("ENVIRONMENT", "development").lower()
_cors = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
if IS_PRODUCTION and not _cors:
    # Previously fell through to ["*"] whenever CORS_ORIGINS was unset — including
    # in production/staging — so any origin could call the API with a user's token.
    raise RuntimeError(
        "CORS_ORIGINS must be set when ENVIRONMENT=production/staging. "
        "Set it to your portal origin(s), e.g. "
        "CORS_ORIGINS=https://app.example.com,https://admin.example.com"
    )
if not _cors:
    _cors = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors,
    allow_credentials=(_cors != ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    env = os.getenv("ENVIRONMENT", "dev").lower()
    missing = [k for k in ("SUPABASE_URL",) if not os.getenv(k)]
    if not (
        os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_KEY")
    ):
        missing.append("SUPABASE_SERVICE_KEY")
    if missing:
        logger.warning("Missing env (DB calls will fail): %s", missing)
    if env in ("production", "prod"):
        sk = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
        if len(sk) < 16:
            logger.error("LEAD_ENGINE_SERVICE_KEY required (≥16 chars) in production")
        if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
            logger.error("LEAD_ENGINE_DEV_AUTH_BYPASS must be false in production")
        if not os.getenv("DELIVERY_CONFIG_KEY"):
            logger.warning("DELIVERY_CONFIG_KEY unset — delivery secrets may be plaintext")
    logger.info("Lead service started env=%s version=2.2.0", env)


@app.get("/health")
async def health():
    checks = {
        "api": True,
        "db": None,
        "service_key": bool(os.getenv("LEAD_ENGINE_SERVICE_KEY")),
    }
    try:
        from backend.memory.supabase_client import get_supabase
        sb = get_supabase()
        sb.table("tenants").select("id").limit(1).execute()
        checks["db"] = True
    except Exception as e:
        checks["db"] = False
        checks["db_error"] = str(e)[:200]
    ok = checks["api"] and checks["db"] is True
    return {
        "ok": ok,
        "service": "lead-engine",
        "mode": "managed_service",
        "version": "2.2.0",
        "checks": checks,
    }


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """
    Catch-all so unexpected errors return a clean JSON body instead of leaking
    a stack trace / driver message to the client. Full detail still goes to logs.
    """
    logger.exception("Unhandled error on %s %s", request.method, request.url.path)
    detail = "Internal server error"
    if not IS_PRODUCTION:
        detail = f"{type(exc).__name__}: {exc}"
    return JSONResponse(status_code=500, content={"detail": detail})


@app.get("/ready")
async def ready():
    """
    Readiness: verifies the dependencies the app cannot serve traffic without.
    Returns 503 when not ready, so load balancers hold traffic back.
    """
    problems: list[str] = []
    if _MOUNT_FAILURES:
        problems.append(f"routers failed to mount: {', '.join(_MOUNT_FAILURES)}")

    try:
        from backend.memory.supabase_client import get_supabase
        sb = get_supabase()
        sb.table("tenants").select("id").limit(1).execute()
    except Exception as e:
        problems.append(f"database unreachable: {str(e)[:150]}")
    else:
        # The CRM's core endpoints read this view; it was missing from every
        # migration, which made dashboard/leads/pipeline return 500 on a fresh
        # install. Surface that here instead of at first user request.
        # (Skipped in local mode, where there is no view layer at all.)
        if not LOCAL_MODE:
            try:
                sb.table("crm_lead_cards").select("assignment_id").limit(1).execute()
            except Exception as e:
                problems.append(
                    f"view crm_lead_cards missing/broken (run sql/015_crm_missing_objects.sql): {str(e)[:120]}"
                )

    if problems:
        return JSONResponse(status_code=503, content={"ready": False, "problems": problems})
    return {"ready": True}


@app.get("/")
async def root():
    return {
        "service": "Automiqo Lead Service",
        "docs": "/docs",
        "health": "/health",
        "operator_api": "/leads/v2",
        "crm_api": "/crm",
    }


_MOUNT_FAILURES: list[str] = []


def _mount(import_path: str, label: str, *attrs: str) -> None:
    """
    Mount a router, failing loudly in production.

    These mounts used to swallow every exception, so a typo or bad import
    produced a *running* API with zero routes and one line in the log —
    every request 404'd and health still reported ok. In production a
    failed mount is now fatal; in development it warns so you can keep
    iterating on the other half of the app.
    """
    try:
        module = __import__(import_path, fromlist=list(attrs))
        for attr in attrs:
            app.include_router(getattr(module, attr))
    except Exception as e:
        if IS_PRODUCTION:
            logger.critical("Failed to mount %s — refusing to start: %s", label, e)
            raise RuntimeError(f"Router mount failed for {label}: {e}") from e
        logger.exception("Failed to mount %s (dev — continuing): %s", label, e)
        _MOUNT_FAILURES.append(label)
        return
    logger.info("Mounted %s", label)


_mount("backend.api.prod.leads_api", "/leads/v2", "router")

# Tenant-in-path CRM, JWT-protected (require_tenant re-verifies the path
# tenant_id against real membership — see crm_api.py docstring).
# crm_api_secured.py has been retired: keeping two parallel CRM routers was
# exactly how the unauthenticated router stayed mounted in production for
# several releases. There is now exactly one.
_mount("backend.crm.crm_api", "/crm (require_tenant) + /crm public", "router", "crm_public_router")
_mount("backend.crm.crm_entities_api", "/crm entities", "router")
