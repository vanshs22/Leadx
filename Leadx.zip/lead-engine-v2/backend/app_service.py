"""
Lead Engine — managed service entrypoint.
  uvicorn backend.app_service:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
logger = logging.getLogger("lead_engine.service")

app = FastAPI(
    title="Automiqo Lead Service",
    version="2.2.0",
    description="Managed lead generation — operator API + client CRM",
)

# Development: allow all origins (Codespaces / local). Production: set CORS_ORIGINS.
_env = os.getenv("ENVIRONMENT", "development").lower()
_cors = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
if _env not in ("production", "prod", "staging") or not _cors:
    _cors = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors,
    allow_credentials=(_cors != ["*"]),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    env = os.getenv("ENVIRONMENT", "dev").lower()
    missing = [k for k in ("SUPABASE_URL",) if not os.getenv(k)]
    if not (
        os.getenv("SUPABASE_SERVICE_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or os.getenv("SUPABASE_KEY")
    ):
        missing.append("SUPABASE_SERVICE_KEY")
    if missing:
        logger.warning("Missing env (DB calls will fail): %s", missing)
    if env in ("production", "prod"):
        sk = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")
        if len(sk) < 16:
            logger.error("LEAD_ENGINE_SERVICE_KEY required (≥16 chars) in production")
        if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
            logger.error("LEAD_ENGINE_DEV_AUTH_BYPASS must be false in production")
        if not os.getenv("DELIVERY_CONFIG_KEY"):
            logger.warning("DELIVERY_CONFIG_KEY unset — delivery secrets may be plaintext")
    logger.info("Lead service started env=%s version=2.2.0", env)


@app.get("/health")
async def health():
    checks = {
        "api": True,
        "db": None,
        "service_key": bool(os.getenv("LEAD_ENGINE_SERVICE_KEY")),
    }
    try:
        from backend.memory.supabase_client import get_supabase
        sb = get_supabase()
        sb.table("tenants").select("id").limit(1).execute()
        checks["db"] = True
    except Exception as e:
        checks["db"] = False
        checks["db_error"] = str(e)[:200]
    ok = checks["api"] and checks["db"] is True
    return {
        "ok": ok,
        "service": "lead-engine",
        "mode": "managed_service",
        "version": "2.2.0",
        "checks": checks,
    }


@app.get("/")
async def root():
    return {
        "service": "Automiqo Lead Service",
        "docs": "/docs",
        "health": "/health",
        "operator_api": "/leads/v2",
        "crm_api": "/crm",
    }


try:
    from backend.api.prod.leads_api import router as leads_router
    app.include_router(leads_router)
    logger.info("Mounted /leads/v2")
except Exception as e:
    logger.exception("Failed to mount leads_api: %s", e)

try:
    # Single CRM router, JWT-protected via require_tenant (crm_api.py
    # docstring has the detail). crm_public_router carries /team/accept,
    # which needs a lighter auth check since accepting an invite happens
    # before someone has tenant membership yet.
    from backend.crm.crm_api import router as crm_router, crm_public_router
    app.include_router(crm_router)
    app.include_router(crm_public_router)
    logger.info("Mounted /crm (require_tenant) + /crm public (team/accept)")
except Exception as e:
    logger.exception("Failed to mount CRM router: %s", e)
