# LeadX Runtime Schema Repair — 2026-09-27

This release fixes the class of runtime failures where an admin/client page reaches
FastAPI successfully but Supabase returns a missing-table/schema-cache error.

## Run this before starting LeadX

In Supabase SQL Editor, run:

`sql/039_RUNTIME_SCHEMA_REPAIR.sql`

It is idempotent and safe to run against an existing LeadX database. It repairs:

- `email_replies`
- `email_optouts`
- `lead_touches`
- `template_variant_stats`
- `webhook_events`
- `campaign_schedules` compatibility columns
- `autonomous_campaigns` compatibility columns
- `tenants.is_operator`
- PostgREST schema cache (`NOTIFY pgrst, 'reload schema'`)

The same repair is already appended to:

- `sql/000_ALL_IN_ONE_migration.sql`
- `SUPABASE_FULL_MIGRATION.sql`

## Why this was necessary

The application referenced five runtime tables that were absent from the checked-in
migration chain. The Replies page exposed this as PostgREST `PGRST205`.

A static audit now reports **zero backend table/view references missing from the
migration set**.

## Frontend clean start

```bash
cd lead-crm-portal/frontend
npm install
npm run clean
npm run dev
```

For production:

```bash
npm run build
npm run start
```
