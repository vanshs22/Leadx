# Leadx — quick start

```bash
chmod +x setup.sh
./setup.sh
```

That will:
1. Create `lead-engine-v2/.venv` and `pip install -r requirements.txt` (includes **uvicorn**)
2. `npm install` for the frontend
3. Create `.env` / `.env.local` from examples if missing
4. Start **API :8000** + **Next.js :3000**

## First time

Edit `lead-engine-v2/.env`:

```
SUPABASE_URL=https://YOUR.supabase.co
SUPABASE_SERVICE_KEY=eyJ...
SUPABASE_ANON_KEY=eyJ...
SERPER_API_KEY=...
LEAD_ENGINE_SERVICE_KEY=dev-local-service-key-16
LEAD_ENGINE_DEV_AUTH_BYPASS=1
ENVIRONMENT=development
```

And `lead-crm-portal/frontend/.env.local`:

```
API_UPSTREAM=http://127.0.0.1:8000
NEXT_PUBLIC_SUPABASE_URL=https://YOUR.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
```

## Options

```bash
./setup.sh --install-only   # deps only
./setup.sh --api-only       # backend only
./setup.sh --web-only       # frontend only
```

## Manual

```bash
cd lead-engine-v2 && source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.app_service:app --host 0.0.0.0 --port 8000 --reload

cd lead-crm-portal/frontend && npm install && npm run dev
```
