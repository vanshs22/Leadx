# Sequences, opt-out, SES inbound — what to set

Claude’s outreach layer is in this package. Code is ready; **AWS + env + SQL** must be done once.

## 1) SQL (existing Supabase project)

Run **once** in SQL Editor (do not need full wipe):

- `FIX_SEQUENCES_OPTOUTS.sql`  
  or `lead-engine-v2/sql/021_sequences_optouts_replies.sql`  
  or the end section of `SUPABASE_FULL_MIGRATION.sql` (email_optouts / sequences / replies)

Tables created:

- `email_optouts`
- `email_sequences`
- `email_sequence_steps`
- `email_sequence_enrollments`
- `email_replies`

## 2) Environment (`lead-engine-v2/.env`)

```bash
PUBLIC_APP_URL=https://YOUR_PUBLIC_API_OR_APP
REPLY_DOMAIN=replies.yourdomain.com
WEBHOOK_SECRET=long-random-string
UNSUBSCRIBE_SECRET=long-random-string   # or leave blank to use SUPABASE_JWT_SECRET
ANTHROPIC_API_KEY=                      # optional, reply classification

EMAIL_PROVIDER=auto
RESEND_API_KEY=
RESEND_FROM=
BREVO_API_KEY=
BREVO_FROM=
```

`PUBLIC_APP_URL` must be reachable from the public internet so unsubscribe links work.

## 3) AWS SES receiving (manual console — not code)

1. Verify domain for **sending** (SPF/DKIM) in SES.
2. Enable **receiving** on `REPLY_DOMAIN` (SES region that supports receiving, often us-east-1).
3. Create **SNS topic** for inbound.
4. SES **receipt rule**: mail to `REPLY_DOMAIN` → publish to that SNS topic.
5. SNS **HTTPS subscription** to:

   `https://YOUR_PUBLIC_API/crm/webhooks/ses-inbound?secret=WEBHOOK_SECRET`

6. Confirm the subscription (SNS sends a subscribe URL once).

Inbound routing uses plus-addressing:

`replies+{tenant_id}@REPLY_DOMAIN`

Outbound sets `Reply-To` to that address automatically when `REPLY_DOMAIN` is set.

## 4) n8n crons

Import from `lead-engine-v2/n8n/`:

| File | URL (fixed) |
|------|-------------|
| `lead_engine_sequences_cron.json` | `POST {BACKEND_URL}/leads/v2/admin/sequences/process-due` |
| `lead_engine_alerts_cron.json` | `POST {BACKEND_URL}/leads/v2/admin/alerts/run` |

Set `BACKEND_URL` and operator auth header (`Authorization: Bearer LEAD_ENGINE_SERVICE_KEY`) in n8n.

Sequences cron: **hourly** is enough.

## Product UI

- **Sequences** — create steps, enroll from Leads bulk select  
- **Replies** — inbound inbox  
- Every send: opt-out check + unsubscribe footer  
- Reply / opt-out stops active enrollments  

## Quick verify

```bash
# health
curl -s $API/health

# process due sequence steps (operator key)
curl -s -X POST $API/leads/v2/admin/sequences/process-due \
  -H "Authorization: Bearer $LEAD_ENGINE_SERVICE_KEY"
```
