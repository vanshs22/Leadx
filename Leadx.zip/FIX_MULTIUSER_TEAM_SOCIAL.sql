-- LeadX: multi-user + team CRM + LinkedIn key pool (safe to re-run)

-- tenant_members columns used by portal login + invites
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS avatar_url text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS role text DEFAULT 'member';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS uq_tenant_members_tenant_email
  ON public.tenant_members (tenant_id, email)
  WHERE email IS NOT NULL AND email <> '';

CREATE INDEX IF NOT EXISTS idx_tenant_members_auth
  ON public.tenant_members (auth_user_id)
  WHERE auth_user_id IS NOT NULL;

-- Invites table for team CRM
CREATE TABLE IF NOT EXISTS public.tenant_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'member',
  token text NOT NULL UNIQUE,
  invited_by text,
  status text NOT NULL DEFAULT 'pending',
  expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  accepted_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_tenant_invites_token ON public.tenant_invites(token);
CREATE INDEX IF NOT EXISTS idx_tenant_invites_tenant ON public.tenant_invites(tenant_id);

-- api_key_pool providers including linkedin / instagram
ALTER TABLE public.api_key_pool DROP CONSTRAINT IF EXISTS api_key_pool_provider_check;
ALTER TABLE public.api_key_pool
  ADD CONSTRAINT api_key_pool_provider_check
  CHECK (provider IN (
    'serper','firecrawl','anthropic','gemini','groq','openai','resend',
    'linkedin_scraper','linkedin','instagram','twilio','vapi','brevo'
  ));

-- delivery_status allow portal/sent
ALTER TABLE public.lead_assignments DROP CONSTRAINT IF EXISTS lead_assignments_delivery_status_check;
ALTER TABLE public.lead_assignments
  ADD CONSTRAINT lead_assignments_delivery_status_check
  CHECK (delivery_status IS NULL OR delivery_status IN (
    'pending','sent','failed','skipped','portal','delivered'
  ));

ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS stage_id uuid;
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS stage_slug text;
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS tier text;

NOTIFY pgrst, 'reload schema';
