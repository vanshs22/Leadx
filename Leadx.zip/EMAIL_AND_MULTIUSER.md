# Email providers + multi-user

## Cascade (free daily limits)

Set in `lead-engine-v2/.env`:

```bash
EMAIL_PROVIDER=cascade   # or auto — tries Resend → Brevo → SMTP

RESEND_API_KEY=
RESEND_FROM="You <leads@domain.com>"
RESEND_DAILY_LIMIT=100

BREVO_API_KEY=
BREVO_FROM="You <leads@domain.com>"
BREVO_DAILY_LIMIT=300

SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_TLS=1
EMAIL_FROM=leads@domain.com
SMTP_DAILY_LIMIT=200
```

When a provider hits its daily count (or returns 429/quota), the next provider is used automatically.

Table `email_provider_daily` tracks usage (created by full migration).

## Migration

Full file ends with multi-user / team / LinkedIn pool block (from FIX_MULTIUSER_TEAM_SOCIAL.sql).
Safe to re-run (IF NOT EXISTS / ADD COLUMN IF NOT EXISTS).
