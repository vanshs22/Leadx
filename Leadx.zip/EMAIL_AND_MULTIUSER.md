# Email volume + multi-user

## Free / low-cost email for ~500–1000/day

| Provider | Free-ish volume | Notes |
|----------|-----------------|--------|
| **Brevo** (recommended free-ish) | **~300 emails/day** free | Best free daily cap among easy APIs. Wire: `BREVO_API_KEY` + `EMAIL_PROVIDER=brevo` |
| **Resend Free** | 100/day, 3k/mo | Good for product/transactional only |
| **Amazon SES** | Very cheap (~$0.10/1k); free tier if on AWS EC2 historically | Best **cost** for 500–1000/day sustained; not always “free forever” |
| **SMTP (Google Workspace)** | ~100–500/day practical | Not for cold bulk; easy blocks |
| **Mailjet / Elastic Email** | Often 100–200/day free | OK secondary |

**Honest answer:** almost no reputable provider gives a permanent **free 1000/day** cold-email quota. For **500–1000/day**:

1. Short term: **Brevo free (300/day)** + don’t send full list daily  
2. Production volume: **Amazon SES** or **Resend Pro** / Brevo paid  
3. Code supports: `resend` | `brevo` | `smtp` | `auto` (tries Resend → Brevo → SMTP)

### Env
```bash
EMAIL_PROVIDER=brevo
BREVO_API_KEY=xkeysib-...
BREVO_FROM="You <leads@yourdomain.com>"
# verify domain in Brevo dashboard
```

## Multi-user model

| Role | How |
|------|-----|
| **Operator** | `/admin/login` + `LEAD_ENGINE_SERVICE_KEY` |
| **Client org** | One `tenants` row |
| **Client users** | Supabase Auth user + `tenant_members` (admin “Client portal login” or Team invite) |
| **Team roles** | owner / admin / member / viewer via invites |

Run `FIX_MULTIUSER_TEAM_SOCIAL.sql` once on Supabase.

## LinkedIn + Instagram

| Mode | Need |
|------|------|
| Discovery | Serper (`SERPER_API_KEY`) — always |
| IG enrich/scrape | `instaloader` (setup installs it); optional `INSTAGRAM_USERNAME`/`PASSWORD` |
| LinkedIn deep | Docker scraper on `:8001` + `li_at` in api_key_pool provider `linkedin_scraper` OR `LINKEDIN_LI_AT` in `.env` |
