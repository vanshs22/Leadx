# Amazon SES only (no Resend / Brevo / SMTP)

Leave these **empty** in `.env`:
```bash
RESEND_API_KEY=
RESEND_FROM=
BREVO_API_KEY=
BREVO_FROM=
EMAIL_PROVIDER=  # leave empty or omit — SES path uses tenant email settings / AWS keys
```

## A) Sending mail (required for sequences & proposals)

1. Open **AWS Console → SES** (prefer **us-east-1** if you also want inbound).
2. **Verified identities → Create domain** → your domain (e.g. `yourdomain.com`).
3. Add the **DKIM / SPF / MX** DNS records SES shows. Wait until status = **Verified**.
4. If still in **Sandbox**: Request production access (SES → Account dashboard → Request production access), or only send to verified recipient emails while testing.
5. Create an **IAM user** (or use existing) with permission `ses:SendEmail` and `ses:SendRawEmail`.
6. Create access keys for that user.

**`.env` (backend):**
```bash
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1

# App URLs / secrets for sequences + opt-out
PUBLIC_APP_URL=https://YOUR_PUBLIC_API_HOST
REPLY_DOMAIN=replies.yourdomain.com
WEBHOOK_SECRET=pick-a-long-random-string
UNSUBSCRIBE_SECRET=pick-another-long-random-string

# Keep empty when SES-only:
RESEND_API_KEY=
BREVO_API_KEY=
```

In the **client portal → Settings → Email**, connect the verified domain (your app’s SES domain UI) so sends use that from-address.

## B) Receiving replies (inbound) — simple path

Goal: when a lead replies, SES catches the email and POSTs it to your API.

1. Same SES region that supports **email receiving** (commonly **us-east-1**).
2. Domain for replies: e.g. `replies.yourdomain.com` (or the same root domain).
3. In DNS, set the **MX** record SES gives you for receiving (points to Amazon SES).
4. **SNS**: create a topic, e.g. `leadx-inbound-email`.
5. **SES → Email receiving → Rule sets → Create rule**:
   - Recipient: your reply domain (or `replies+*@…` if supported; often whole domain).
   - Action: **Publish to Amazon SNS topic** → select that topic.
6. **SNS → topic → Create subscription**:
   - Protocol: **HTTPS**
   - Endpoint:  
     `https://YOUR_PUBLIC_API_HOST/crm/webhooks/ses-inbound?secret=WEBHOOK_SECRET`  
     (same secret as in `.env`)
7. Confirm the subscription (AWS emails/POSTs a SubscribeURL once — open it or auto-confirm if your webhook handles `SubscriptionConfirmation`).

Your app sets **Reply-To** to:
`replies+{tenant_id}@REPLY_DOMAIN`  
so replies route back to the right client.

## C) SQL once

Run `FIX_SEQUENCES_OPTOUTS.sql` **or** full `SUPABASE_FULL_MIGRATION.sql` (sequences block is at the **end**).

## D) Sequences cron (optional)

n8n hourly → `POST /leads/v2/admin/sequences/process-due`  
Header: `Authorization: Bearer LEAD_ENGINE_SERVICE_KEY`

## Checklist

| Step | Done |
|------|------|
| Domain verified in SES (send) | |
| AWS keys in `.env` | |
| `PUBLIC_APP_URL`, `REPLY_DOMAIN`, secrets | |
| SQL sequences tables | |
| MX + receipt rule + SNS → webhook (for replies) | |
| Sandbox off (for real volume) | |
