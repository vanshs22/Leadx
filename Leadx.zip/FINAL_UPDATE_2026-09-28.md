# LeadX — Runtime, Login, Realtime & Branding Final Update

## What changed

- Fixed the client workspace bootstrap path by keeping a protected runtime `GET /crm/me` route in FastAPI.
- Removed the duplicate Supabase Realtime channel race: there is now one tenant-scoped browser channel with orderly reconnects.
- Removed global page reloads on every realtime event to avoid multi-user reload storms.
- Browser API routing still races same-origin `/backend` and the Codespaces forwarded `:8000` fallback for recoverable proxy failures.
- Cached access-token reads for 30 seconds in the browser to reduce repeated local session calls.
- Increased the backend pooled async HTTP capacity to 500 connections / 250 keepalive per worker.
- Production Docker runs 4 FastAPI workers by default; tune with `WEB_CONCURRENCY`.
- Codespaces `npm run dev` now uses Turbopack for faster cold compilation.
- Replaced the generic Aurora direction with **LeadX Deep Teal / Tangerine** branding.

## Important

The screenshots showing `GET /crm/me 404` are from an older FastAPI process. After replacing the source, **stop that process and restart it**. A hot reload that is still attached to the old `/workspaces/...` source tree cannot make the missing route appear.

Expected unauthenticated check:

```text
GET /crm/me -> 401/403
```

A 404 means the wrong/stale API process is still serving port 8000.

## Validation

- Backend Python compile: PASS
- Backend test suite: PASS (56 tests)
- `/crm/me` route exists: PASS
- `/crm/me` without auth returns 401: PASS
- JS config syntax checks: PASS
- Frontend dependency installation/build could not be completed in the packaging environment because npm registry access timed out. `node_modules` is not included in the delivery.
