# LeadX — Login, Codespaces & Brand Final Update

## Login / workspace bootstrap
- Client password login now has a 12-second hard timeout instead of potentially hanging indefinitely.
- Session restoration has a 5-second bound.
- Removed the serial `/health` request from client login bootstrap.
- Workspace bootstrap now calls `/crm/me` directly and retries against the GitHub Codespaces forwarded port when the Next `/backend` proxy returns 404/502/503.
- Workspace resolution now happens once per authenticated browser session instead of on every portal pathname change.
- Cached tenant ID/name is reused for fast navigation.
- Clear, actionable retry/sign-out UI replaces the previous raw backend error wall.

## Codespaces API routing
- Primary browser API path remains same-origin `/backend`.
- On remote hosts, if the app is served on `-3000` and the API is forwarded on `-8000`, the browser can derive the forwarded API host and retry automatically.
- No browser-facing hardcoded localhost API dependency remains in the portal source.

## White-label branding
- Protected branding endpoint now sends the user's Supabase Bearer token.
- Branding fetch uses the same API fallback strategy.

## Visual identity
- Replaced the generic Aurora/indigo/cyan palette with LeadX Cobalt / Saffron.
- Cobalt = product identity / primary actions.
- Saffron = live opportunity / signal state.
- Ink-first typography and surfaces for higher contrast.
- Login and workspace-recovery screens use the new brand system.

## Verification
- Python compileall: PASS
- Backend pytest: 56/56 PASS
- Next/Tailwind/clean script syntax checks: PASS
- Legacy Aurora/indigo/cyan source scan: CLEAN
- Full `npm ci`/Next production build could not be completed in the build environment because package download timed out; no claim of a frontend production build pass is made.
