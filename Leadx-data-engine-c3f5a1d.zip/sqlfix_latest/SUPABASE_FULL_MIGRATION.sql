-- LeadX 15.8 FULL DATABASE MIGRATION
-- Single executable canonical chain. Generated from supabase/migrations/*.sql in lexical order.
-- Historical docs/archive/sql/*.sql files are provenance only and are not executable chain inputs.
-- This file contains every canonical migration exactly once.

BEGIN;

-- ============================================================================
-- CANONICAL MIGRATION 01: 20260930000000_leadx_baseline.sql
-- ============================================================================

-- LeadX FULL MIGRATION (ordered: tables/columns → functions → views → seed)
-- Safe patterns: IF NOT EXISTS, ADD COLUMN IF NOT EXISTS, DROP VIEW/FUNCTION before replace
-- Re-run after wipe: use the project reset script first, then this file once.

-- =============================================================================
-- LeadX SUPABASE_FULL_MIGRATION.sql
-- Single run: all tables, indexes, views, RLS helpers.
-- Safe to re-run (IF NOT EXISTS / ADD COLUMN IF NOT EXISTS).
-- Includes pipeline_run_leads, CRM tables, continuous discovery, etc.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;


-- ##### 002 production core #####

-- =============================================================================
-- Automiqo Lead Engine v2 — PRODUCTION Multi-Tenant Schema
-- Idempotent. Run in Supabase SQL Editor after 001 if present.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- 1. API Key Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_key_pool (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider       text NOT NULL CHECK (provider IN (
                   'serper','firecrawl','anthropic','gemini','groq','openai','resend','linkedin_scraper','linkedin','instagram','twilio','vapi'
                 )),
  key_value      text NOT NULL,
  label          text,
  status         text NOT NULL DEFAULT 'active'
                   CHECK (status IN ('active','exhausted','disabled','cooling')),
  credits_used   int  NOT NULL DEFAULT 0,
  credits_limit  int,
  error_count    int  NOT NULL DEFAULT 0,
  last_error     text,
  last_used_at   timestamptz,
  cooldown_until timestamptz,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, key_value)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS key_value text;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS label text;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS credits_used int;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS credits_limit int;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS error_count int;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS last_used_at timestamptz;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS cooldown_until timestamptz;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.api_key_pool ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_api_key_pool_live
  ON api_key_pool (provider, status, last_used_at NULLS FIRST)
  WHERE status IN ('active','cooling');

-- ---------------------------------------------------------------------------
-- 2. Tenants
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenants (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  text NOT NULL,
  slug                  text UNIQUE,
  plan                  text NOT NULL DEFAULT 'starter'
                          CHECK (plan IN ('starter','growth','premium','enterprise')),
  leads_per_month_limit int  NOT NULL DEFAULT 100,
  allow_tier_b          boolean NOT NULL DEFAULT false,
  delivery_channel      text NOT NULL DEFAULT 'telegram'
                          CHECK (delivery_channel IN ('telegram','webhook','email','portal','csv')),
  delivery_config       jsonb NOT NULL DEFAULT '{}',
  status                text NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','paused','churned')),
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS slug text;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS plan text;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS leads_per_month_limit int;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS allow_tier_b boolean;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS delivery_channel text;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS delivery_config jsonb;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.tenants ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants (status) WHERE status = 'active';

-- ---------------------------------------------------------------------------
-- 3. ICP Profiles
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS icp_profiles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL DEFAULT 'default',
  vertical      text NOT NULL,
  geo           jsonb NOT NULL DEFAULT '[]',
  keywords      jsonb NOT NULL DEFAULT '[]',
  weights       jsonb NOT NULL DEFAULT '{}',
  exclusivity   text NOT NULL DEFAULT 'exclusive'
                  CHECK (exclusivity IN ('exclusive','shared')),
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS geo jsonb;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS keywords jsonb;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS weights jsonb;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS exclusivity text;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS active boolean;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.icp_profiles ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_icp_tenant_active ON icp_profiles (tenant_id) WHERE active = true;
CREATE INDEX IF NOT EXISTS idx_icp_vertical ON icp_profiles (vertical);

-- ---------------------------------------------------------------------------
-- 4. Global Leads Pool
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS leads_global (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint       text NOT NULL UNIQUE,
  phone_normalized  text,
  phone_e164        text,
  name              text NOT NULL,
  name_normalized   text,
  address           text,
  city              text,
  state             text,
  website           text,
  website_domain    text,
  category          text,
  business_status   text NOT NULL DEFAULT 'OPERATIONAL'
                      CHECK (business_status IN ('OPERATIONAL','CLOSED','TEMPORARILY_CLOSED','UNKNOWN')),
  google_rating     numeric(2,1),
  review_count      int NOT NULL DEFAULT 0,
  google_place_id   text,
  source            text NOT NULL DEFAULT 'google_maps_serper',
  source_url        text,
  raw_data          jsonb NOT NULL DEFAULT '{}',
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS fingerprint text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS phone_normalized text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS phone_e164 text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS name_normalized text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS address text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS website_domain text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS business_status text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS google_rating numeric(2,1);
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS review_count int;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS google_place_id text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS source_url text;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS raw_data jsonb;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.leads_global ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_global_phone
  ON leads_global (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_domain
  ON leads_global (website_domain) WHERE website_domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_leads_global_name_trgm
  ON leads_global USING gin (name_normalized gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_leads_global_status ON leads_global (business_status);

-- ---------------------------------------------------------------------------
-- 5. Enrichment
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrichment (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id           uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  email             text,
  email_valid       boolean,
  emails            text[] NOT NULL DEFAULT '{}',
  phone_from_web    text,
  has_booking       boolean NOT NULL DEFAULT false,
  booking_platform  text,
  services          text[] NOT NULL DEFAULT '{}',
  social_links      jsonb NOT NULL DEFAULT '{}',
  tech_stack        text[] NOT NULL DEFAULT '{}',
  owner_name        text,
  markdown_summary  text,
  raw_extraction    jsonb NOT NULL DEFAULT '{}',
  enrichment_method text,
  enrichment_ok     boolean NOT NULL DEFAULT false,
  error             text,
  extracted_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS email_valid boolean;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS emails text[];
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS phone_from_web text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS has_booking boolean;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS booking_platform text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS services text[];
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS social_links jsonb;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS tech_stack text[];
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS owner_name text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS markdown_summary text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS raw_extraction jsonb;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS enrichment_method text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS enrichment_ok boolean;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.enrichment ADD COLUMN IF NOT EXISTS extracted_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_enrichment_email ON enrichment (email) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_enrichment_ok ON enrichment (enrichment_ok) WHERE enrichment_ok = true;

-- ---------------------------------------------------------------------------
-- 6. Scores
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS scores (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id             uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  deterministic_score int  NOT NULL DEFAULT 0,
  llm_score           int,
  total_score         int  NOT NULL DEFAULT 0,
  tier                text NOT NULL DEFAULT 'C' CHECK (tier IN ('A','B','C')),
  reasoning           text,
  scored_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS deterministic_score int;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS llm_score int;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS total_score int;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS reasoning text;
ALTER TABLE IF EXISTS public.scores ADD COLUMN IF NOT EXISTS scored_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_scores_tier_score ON scores (tier, total_score DESC);

-- ---------------------------------------------------------------------------
-- 7. Lead Assignments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lead_assignments (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id          uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id           uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  vertical         text NOT NULL,
  geo_tags         text[] NOT NULL DEFAULT '{}',
  delivered_at     timestamptz,
  delivery_channel text,
  delivery_status  text NOT NULL DEFAULT 'pending'
                     CHECK (delivery_status IN ('pending','sent','failed','skipped','portal','delivered')),
  delivery_error   text,
  status           text NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','contacted','won','rejected','expired')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id, tenant_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS geo_tags text[];
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS delivered_at timestamptz;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS delivery_channel text;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS delivery_status text;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS delivery_error text;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.lead_assignments ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_assignments_tenant_status ON lead_assignments (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_exclusivity
  ON lead_assignments (vertical, lead_id) WHERE status NOT IN ('rejected','expired');

CREATE INDEX IF NOT EXISTS idx_assignments_delivered ON lead_assignments (tenant_id, delivered_at DESC);

-- Ensure CRM columns exist BEFORE any view references them
ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS offer_category text,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to text,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}'::text[],
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS delivery_channel text,
  ADD COLUMN IF NOT EXISTS delivery_error text;


-- ---------------------------------------------------------------------------
-- 8. Usage Log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  period          date NOT NULL,
  leads_delivered int  NOT NULL DEFAULT 0,
  tier_a_count    int  NOT NULL DEFAULT 0,
  tier_b_count    int  NOT NULL DEFAULT 0,
  tier_c_count    int  NOT NULL DEFAULT 0,
  leads_rejected  int  NOT NULL DEFAULT 0,
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, period)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS period date;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS leads_delivered int;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS tier_a_count int;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS tier_b_count int;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS tier_c_count int;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS leads_rejected int;
ALTER TABLE IF EXISTS public.usage_log ADD COLUMN IF NOT EXISTS updated_at timestamptz;


-- ---------------------------------------------------------------------------
-- 9. Pipeline runs + dead-letter
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_runs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid REFERENCES tenants(id) ON DELETE SET NULL,
  icp_id          uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  status          text NOT NULL DEFAULT 'running'
                    CHECK (status IN ('queued','running','completed','failed','partial')),
  discovered      int NOT NULL DEFAULT 0,
  stored          int NOT NULL DEFAULT 0,
  enriched        int NOT NULL DEFAULT 0,
  gated_ok        int NOT NULL DEFAULT 0,
  assigned        int NOT NULL DEFAULT 0,
  delivered       int NOT NULL DEFAULT 0,
  error_message   text,
  meta            jsonb NOT NULL DEFAULT '{}',
  started_at      timestamptz NOT NULL DEFAULT now(),
  finished_at     timestamptz
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS discovered int;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS stored int;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS enriched int;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS gated_ok int;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS assigned int;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS delivered int;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS error_message text;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE IF EXISTS public.pipeline_runs ADD COLUMN IF NOT EXISTS finished_at timestamptz;

-- Pipeline runs are durable before the worker starts. Older installs used a
-- status CHECK that omitted `queued`, which caused the API's pre-create INSERT
-- to fail and then (historically) be swallowed. Reconcile that legacy constraint
-- here so both fresh and existing databases accept the real run lifecycle.
DO $$
DECLARE
  c record;
BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    FOR c IN
      SELECT conname
      FROM pg_constraint
      WHERE conrelid = 'public.pipeline_runs'::regclass
        AND contype = 'c'
        AND pg_get_constraintdef(oid) ILIKE '%status%'
        AND pg_get_constraintdef(oid) ILIKE '%running%'
        AND pg_get_constraintdef(oid) ILIKE '%completed%'
    LOOP
      EXECUTE format('ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS %I', c.conname);
    END LOOP;
    ALTER TABLE public.pipeline_runs
      ADD CONSTRAINT pipeline_runs_status_check
      CHECK (status IN ('queued','running','completed','failed','partial'));
  END IF;
END $$;


CREATE TABLE IF NOT EXISTS enrichment_failures (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id      uuid REFERENCES leads_global(id) ON DELETE CASCADE,
  website      text,
  error        text,
  attempts     int NOT NULL DEFAULT 1,
  last_attempt timestamptz NOT NULL DEFAULT now(),
  resolved     boolean NOT NULL DEFAULT false
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS attempts int;
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS last_attempt timestamptz;
ALTER TABLE IF EXISTS public.enrichment_failures ADD COLUMN IF NOT EXISTS resolved boolean;


CREATE INDEX IF NOT EXISTS idx_enrich_fail_unresolved
  ON enrichment_failures (resolved, last_attempt) WHERE resolved = false;

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION normalize_phone(p text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    CASE
      WHEN length(d) = 11 AND left(d,1) = '1' THEN substring(d from 2)
      WHEN length(d) = 10 THEN d
      ELSE d
    END,
    ''
  )
  FROM (SELECT regexp_replace(COALESCE(p, ''), '[^0-9]', '', 'g') AS d) s
  WHERE length(d) >= 10;
$$;

CREATE OR REPLACE FUNCTION extract_domain(url text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT NULLIF(
    lower(regexp_replace(
      regexp_replace(COALESCE(url,''), '^https?://(www\.)?', '', 'i'),
      '/.*$', ''
    )),
    ''
  );
$$;

CREATE OR REPLACE FUNCTION lead_fingerprint(p_name text, p_phone text, p_website text)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT md5(
    lower(trim(COALESCE(p_name, ''))) || '|' ||
    COALESCE(normalize_phone(p_phone), '') || '|' ||
    COALESCE(extract_domain(p_website), '')
  );
$$;

CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[]
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected','expired')
      AND icp.exclusivity = 'exclusive'
      AND lower(icp.vertical) = lower(p_vertical)
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;
  RETURN conflict_exists;
END;
$$;

CREATE OR REPLACE FUNCTION bump_usage(p_tenant_id uuid, p_tier text)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
BEGIN
  INSERT INTO usage_log (tenant_id, period, leads_delivered, tier_a_count, tier_b_count, tier_c_count)
  VALUES (
    p_tenant_id, p, 1,
    CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END
  )
  ON CONFLICT (tenant_id, period) DO UPDATE SET
    leads_delivered = usage_log.leads_delivered + 1,
    tier_a_count = usage_log.tier_a_count + CASE WHEN p_tier = 'A' THEN 1 ELSE 0 END,
    tier_b_count = usage_log.tier_b_count + CASE WHEN p_tier = 'B' THEN 1 ELSE 0 END,
    tier_c_count = usage_log.tier_c_count + CASE WHEN p_tier = 'C' THEN 1 ELSE 0 END,
    updated_at = now();
END;
$$;

CREATE OR REPLACE FUNCTION tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE
  lim int;
  used int;
  p date := date_trunc('month', now())::date;
BEGIN
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id;
  IF lim IS NULL THEN RETURN 0; END IF;
  SELECT COALESCE(leads_delivered, 0) INTO used
  FROM usage_log WHERE tenant_id = p_tenant_id AND period = p;
  RETURN GREATEST(lim - COALESCE(used, 0), 0);
END;
$$;

DROP VIEW IF EXISTS deliverable_leads CASCADE;
CREATE OR REPLACE VIEW deliverable_leads AS
SELECT
  lg.id AS lead_id, lg.name, lg.phone_normalized, lg.phone_e164, lg.website,
  lg.address, lg.city, lg.state, lg.business_status, lg.google_rating, lg.review_count,
  e.email, e.email_valid, e.has_booking, e.booking_platform, e.services,
  e.social_links, e.owner_name, s.total_score, s.tier, s.reasoning
FROM leads_global lg
JOIN enrichment e ON e.lead_id = lg.id AND e.enrichment_ok = true
JOIN scores s ON s.lead_id = lg.id
WHERE lg.business_status IS DISTINCT FROM 'CLOSED'
  AND s.tier IN ('A', 'B')
  AND lg.phone_normalized IS NOT NULL
  AND lg.website IS NOT NULL
  AND (
    (e.email IS NOT NULL AND e.email_valid IS NOT FALSE)::int +
    (e.has_booking)::int +
    (COALESCE(array_length(e.services, 1), 0) > 0)::int +
    (e.social_links IS NOT NULL AND e.social_links != '{}'::jsonb)::int +
    (e.owner_name IS NOT NULL)::int
  ) >= 2;


-- ##### CRM portal core (required before RLS) #####
CREATE TABLE IF NOT EXISTS tenant_members (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  auth_user_id  uuid,
  email         text,
  role          text NOT NULL DEFAULT 'member'
                  CHECK (role IN ('owner','admin','member','viewer')),
  status        text NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','invited','disabled')),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, auth_user_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS role text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_tenant_members_user ON tenant_members (auth_user_id) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_tenant_members_tenant ON tenant_members (tenant_id, status);

CREATE TABLE IF NOT EXISTS pipeline_stages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  slug          text NOT NULL,
  position      int NOT NULL DEFAULT 0,
  color         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS slug text;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS position int;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS color text;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS lead_activities (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  activity_type text NOT NULL DEFAULT 'note',
  title         text,
  body          text,
  meta          jsonb DEFAULT '{}',
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS activity_type text;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS body text;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_activities_assignment ON lead_activities (assignment_id, created_at DESC);

CREATE TABLE IF NOT EXISTS lead_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  title         text NOT NULL,
  status        text NOT NULL DEFAULT 'open',
  priority      text DEFAULT 'medium',
  due_at        timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  completed_at  timestamptz
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS priority text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS due_at timestamptz;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS completed_at timestamptz;


CREATE TABLE IF NOT EXISTS lead_tags (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  tag           text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS tag text;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS lead_segments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  filters       jsonb NOT NULL DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS filters jsonb;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS crm_audit_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE SET NULL,
  actor_id      uuid,
  action        text NOT NULL,
  entity        text,
  entity_id     text,
  meta          jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS actor_id uuid;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS action text;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS entity text;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS entity_id text;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.crm_audit_log ADD COLUMN IF NOT EXISTS created_at timestamptz;



-- ##### Column repair (partial DB safety) #####
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS plan text DEFAULT 'starter';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS leads_per_month_limit int DEFAULT 100;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS allow_tier_b boolean DEFAULT false;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS delivery_channel text DEFAULT 'telegram';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS delivery_config jsonb DEFAULT '{}';
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS brand_name text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS stripe_customer_id text;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_normalized text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS name_normalized text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS fingerprint text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_e164 text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS business_status text DEFAULT 'OPERATIONAL';
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS talking_points text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS email text;

ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS status text DEFAULT 'new';
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS delivery_status text DEFAULT 'pending';
ALTER TABLE lead_assignments ADD COLUMN IF NOT EXISTS vertical text;

ALTER TABLE icp_profiles ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE icp_profiles ADD COLUMN IF NOT EXISTS active boolean DEFAULT true;

UPDATE tenants SET status = COALESCE(status, 'active') WHERE status IS NULL;
UPDATE tenants SET name = COALESCE(NULLIF(trim(name), ''), 'Tenant') WHERE name IS NULL;


-- ##### 004 RLS #####

-- =============================================================================
-- Row-Level Security + auth helpers for multi-tenant isolation
-- Run AFTER 002 (lead engine) and 003 (CRM portal) schemas.
-- =============================================================================

-- Map auth.uid() → tenant_id via tenant_members
CREATE OR REPLACE FUNCTION public.current_tenant_ids()
RETURNS SETOF uuid
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT tenant_id
  FROM tenant_members
  WHERE auth_user_id = auth.uid()
    AND status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_member(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_tenant_admin(p_tenant_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM tenant_members
    WHERE tenant_id = p_tenant_id
      AND auth_user_id = auth.uid()
      AND status = 'active'
      AND role IN ('owner', 'admin')
  );
$$;

-- Service role bypasses RLS; anon/authenticated are restricted.
-- Enable RLS on all tenant-scoped tables.

DO $$ BEGIN
  IF to_regclass('public.tenants') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenants ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.icp_profiles') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE icp_profiles ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_assignments') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_assignments ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.enrichment') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE enrichment ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.scores') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE scores ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.usage_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE usage_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE pipeline_runs ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.pipeline_stages') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE pipeline_stages ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_activities') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_activities ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_tasks') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_tasks ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_tags') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_tags ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.tenant_members') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenant_members ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_segments') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_segments ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.crm_audit_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE crm_audit_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.enrichment_failures') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE enrichment_failures ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- leads_global is SHARED pool — members can SELECT only leads assigned to them
DO $$ BEGIN
  IF to_regclass('public.leads_global') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE leads_global ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- Drop existing policies if re-running
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT policyname, tablename FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN (
        'tenants','icp_profiles','lead_assignments','leads_global',
        'enrichment','scores','usage_log','pipeline_runs','pipeline_stages',
        'lead_activities','lead_tasks','lead_tags','tenant_members',
        'lead_segments','crm_audit_log','enrichment_failures'
      )
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- TENANTS: members see only their tenants
CREATE POLICY tenants_select ON tenants FOR SELECT
  USING (id IN (SELECT public.current_tenant_ids()));
CREATE POLICY tenants_update ON tenants FOR UPDATE
  USING (public.is_tenant_admin(id));

-- ICP
CREATE POLICY icp_select ON icp_profiles FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY icp_write ON icp_profiles FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- ASSIGNMENTS (core isolation)
CREATE POLICY assignments_select ON lead_assignments FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_insert ON lead_assignments FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_update ON lead_assignments FOR UPDATE
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY assignments_delete ON lead_assignments FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- leads_global: only if assigned to one of user's tenants
CREATE POLICY leads_global_select ON leads_global FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = leads_global.id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
-- Writes only via service role (backend pipeline)

-- enrichment / scores: via assigned leads
CREATE POLICY enrichment_select ON enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );
CREATE POLICY scores_select ON scores FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = scores.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- usage_log
CREATE POLICY usage_select ON usage_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- pipeline_runs
CREATE POLICY runs_select ON pipeline_runs FOR SELECT
  USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id));

-- CRM tables
CREATE POLICY stages_all ON pipeline_stages FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY activities_all ON lead_activities FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tasks_all ON lead_tasks FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY tags_all ON lead_tags FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY segments_all ON lead_segments FOR ALL
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY audit_select ON crm_audit_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_select ON tenant_members FOR SELECT
  USING (public.is_tenant_member(tenant_id));
CREATE POLICY members_admin ON tenant_members FOR ALL
  USING (public.is_tenant_admin(tenant_id));

-- api_key_pool: NEVER exposed to clients (service role only)
DO $$ BEGIN
  IF to_regclass('public.api_key_pool') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE api_key_pool ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
-- no policies for authenticated → only service_role can access

COMMENT ON FUNCTION public.current_tenant_ids IS 'Tenants the JWT user belongs to';
COMMENT ON FUNCTION public.is_tenant_member IS 'True if auth.uid() is active member of tenant';


-- ##### 005_outcomes_feedback.sql #####

-- Win/loss feedback storage for adaptive scoring + lookalikes

CREATE TABLE IF NOT EXISTS lead_outcomes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  outcome       text NOT NULL CHECK (outcome IN ('won', 'lost')),
  reason        text,
  features      jsonb NOT NULL DEFAULT '{}',
  recorded_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (assignment_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS outcome text;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS features jsonb;
ALTER TABLE IF EXISTS public.lead_outcomes ADD COLUMN IF NOT EXISTS recorded_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_outcomes_tenant ON lead_outcomes (tenant_id, outcome);
CREATE INDEX IF NOT EXISTS idx_outcomes_features ON lead_outcomes USING gin (features);

DO $$ BEGIN
  IF to_regclass('public.lead_outcomes') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_outcomes ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

DROP POLICY IF EXISTS outcomes_select ON lead_outcomes;
CREATE POLICY outcomes_select ON lead_outcomes FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS outcomes_insert ON lead_outcomes;
CREATE POLICY outcomes_insert ON lead_outcomes FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));

-- Optional: store last verification timestamps on enrichment
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_mx_ok boolean,
  ADD COLUMN IF NOT EXISTS phone_verified boolean,
  ADD COLUMN IF NOT EXISTS phone_line_type text,
  ADD COLUMN IF NOT EXISTS verified_at timestamptz;

-- Freshness: track when score was last computed
ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS stale boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS refresh_after timestamptz;


-- ##### 006_next_tier.sql #####

-- =============================================================================
-- Next-tier: suppression, global opt-out, signals, sentiment, auto-credits
-- =============================================================================

-- Client suppression lists (tenant CRM exports — never resell these)
CREATE TABLE IF NOT EXISTS suppression_list (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  fingerprint text,
-- same fingerprint as leads_global
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  source      text DEFAULT 'upload',
-- upload | manual | crm_sync
  created_at  timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS fingerprint text;
-- same fingerprint as leads_global;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS phone_normalized text;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS company_name text;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.suppression_list ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_supp_tenant_fp ON suppression_list (tenant_id, fingerprint);
CREATE INDEX IF NOT EXISTS idx_supp_tenant_phone ON suppression_list (tenant_id, phone_normalized)
  WHERE phone_normalized IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_email ON suppression_list (tenant_id, email)
  WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_supp_tenant_domain ON suppression_list (tenant_id, domain)
  WHERE domain IS NOT NULL;

-- Global opt-out registry (one removal = never for ANY tenant)
CREATE TABLE IF NOT EXISTS global_opt_out (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint text,
  phone_normalized text,
  email       text,
  domain      text,
  company_name text,
  reason      text,
  requested_by text,
-- email or 'admin'
  created_at  timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS fingerprint text;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS phone_normalized text;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS company_name text;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS requested_by text;
-- email or 'admin';
ALTER TABLE IF EXISTS public.global_opt_out ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_phone
  ON global_opt_out (phone_normalized) WHERE phone_normalized IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_email
  ON global_opt_out (email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_optout_domain
  ON global_opt_out (domain) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_optout_fp ON global_opt_out (fingerprint)
  WHERE fingerprint IS NOT NULL;

-- Why-now / trigger signals per lead
CREATE TABLE IF NOT EXISTS lead_signals (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id     uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  signal_type text NOT NULL CHECK (signal_type IN (
    'review_velocity_up', 'review_velocity_down',
    'site_redesign', 'new_hire', 'tech_change',
    'complaint_cluster', 'other'
  )),
  strength    numeric(4,2) DEFAULT 1.0,
-- 0–1 relative strength
  detail      jsonb DEFAULT '{}',
  detected_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS signal_type text;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS strength numeric(4,2);
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS detail jsonb;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS detected_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_signals_lead ON lead_signals (lead_id, signal_type);

-- Review sentiment summary (one row per lead, refreshed)
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS review_sentiment jsonb,
-- {pos, neg, themes: [...], pitch_hooks: [...]}
  ADD COLUMN IF NOT EXISTS tech_stack jsonb,
-- {booking, crm, chat, analytics, ...}
  ADD COLUMN IF NOT EXISTS why_now text[],
-- short human labels
  ADD COLUMN IF NOT EXISTS last_signal_at timestamptz;

-- Auto-credit / refund log
CREATE TABLE IF NOT EXISTS lead_credits (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  lead_id       uuid,
  credit_type   text NOT NULL CHECK (credit_type IN (
    'dead_phone', 'dead_email', 'bounce', 'closed_business', 'duplicate', 'manual'
  )),
  amount        int NOT NULL DEFAULT 1,
-- leads credited back
  period        date NOT NULL,
-- usage_log period
  detail        jsonb DEFAULT '{}',
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS credit_type text;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS amount int;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS period date;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS detail jsonb;
ALTER TABLE IF EXISTS public.lead_credits ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_credits_tenant ON lead_credits (tenant_id, period);

-- Cross-tenant vertical priors (aggregated win rates per feature)
CREATE TABLE IF NOT EXISTS vertical_priors (
  vertical    text NOT NULL,
  feature     text NOT NULL,
-- email, booking, reviews, owner, rating_high
  win_rate    numeric(6,4) NOT NULL DEFAULT 0.5,
  lose_rate   numeric(6,4) NOT NULL DEFAULT 0.5,
  sample_size int NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (vertical, feature)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.vertical_priors ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.vertical_priors ADD COLUMN IF NOT EXISTS feature text;
ALTER TABLE IF EXISTS public.vertical_priors ADD COLUMN IF NOT EXISTS win_rate numeric(6,4);
ALTER TABLE IF EXISTS public.vertical_priors ADD COLUMN IF NOT EXISTS lose_rate numeric(6,4);
ALTER TABLE IF EXISTS public.vertical_priors ADD COLUMN IF NOT EXISTS sample_size int;
ALTER TABLE IF EXISTS public.vertical_priors ADD COLUMN IF NOT EXISTS updated_at timestamptz;


-- Encrypted delivery config column (app encrypts JSON → store here)
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS delivery_config_enc text;
-- base64 AES ciphertext

-- RLS for new tables
DO $$ BEGIN
  IF to_regclass('public.suppression_list') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE suppression_list ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_signals') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_signals ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_credits') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_credits ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

DROP POLICY IF EXISTS supp_tenant ON suppression_list;
CREATE POLICY supp_tenant ON suppression_list FOR ALL
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS signals_via_assignment ON lead_signals;
CREATE POLICY signals_via_assignment ON lead_signals FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = lead_signals.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS credits_tenant ON lead_credits;
CREATE POLICY credits_tenant ON lead_credits FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- global_opt_out + vertical_priors: service role only (no client policies)

-- Helper: is suppressed for tenant?
CREATE OR REPLACE FUNCTION is_suppressed(
  p_tenant_id uuid,
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM suppression_list s
    WHERE s.tenant_id = p_tenant_id
      AND (
        (p_fingerprint IS NOT NULL AND s.fingerprint = p_fingerprint)
        OR (p_phone IS NOT NULL AND s.phone_normalized = p_phone)
        OR (p_email IS NOT NULL AND lower(s.email) = lower(p_email))
        OR (p_domain IS NOT NULL AND s.domain = p_domain)
      )
  );
$$;

-- Helper: globally opted out?
CREATE OR REPLACE FUNCTION is_opted_out(
  p_fingerprint text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_email text DEFAULT NULL,
  p_domain text DEFAULT NULL
) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM global_opt_out g
    WHERE
      (p_fingerprint IS NOT NULL AND g.fingerprint = p_fingerprint)
      OR (p_phone IS NOT NULL AND g.phone_normalized = p_phone)
      OR (p_email IS NOT NULL AND lower(g.email) = lower(p_email))
      OR (p_domain IS NOT NULL AND g.domain = p_domain)
  );
$$;

-- Auto-credit: decrement usage_log.leads_delivered for period
CREATE OR REPLACE FUNCTION credit_tenant_usage(
  p_tenant_id uuid,
  p_period date,
  p_amount int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE usage_log
  SET leads_delivered = GREATEST(0, leads_delivered - p_amount)
  WHERE tenant_id = p_tenant_id AND period = p_period;
END;
$$;


-- ##### 007_team_branding_ops.sql #####

-- Team invites, white-label branding, ops metrics

-- Invite tokens for tenant_members
CREATE TABLE IF NOT EXISTS tenant_invites (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  token       text NOT NULL UNIQUE,
  invited_by  uuid,
  expires_at  timestamptz NOT NULL,
  accepted_at timestamptz,
  status      text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','accepted','expired','revoked')),
  created_at  timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS role text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS token text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS invited_by uuid;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS expires_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS accepted_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_invites_token ON tenant_invites (token) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_invites_tenant ON tenant_invites (tenant_id, status);

DO $$ BEGIN
  IF to_regclass('public.tenant_invites') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tenant_invites ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DROP POLICY IF EXISTS invites_admin ON tenant_invites;
CREATE POLICY invites_admin ON tenant_invites FOR ALL
  USING (public.is_tenant_admin(tenant_id));
DROP POLICY IF EXISTS invites_select_member ON tenant_invites;
CREATE POLICY invites_select_member ON tenant_invites FOR SELECT
  USING (public.is_tenant_member(tenant_id));

-- White-label branding on tenants
ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS brand_name text,
  ADD COLUMN IF NOT EXISTS brand_logo_url text,
  ADD COLUMN IF NOT EXISTS brand_primary_color text DEFAULT '#6366f1',
  ADD COLUMN IF NOT EXISTS brand_accent_color text DEFAULT '#22c55e',
  ADD COLUMN IF NOT EXISTS brand_favicon_url text,
  ADD COLUMN IF NOT EXISTS custom_domain text,
  ADD COLUMN IF NOT EXISTS support_email text;

-- LinkedIn enrichment fields
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS linkedin_url text,
  ADD COLUMN IF NOT EXISTS linkedin_company_id text,
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS linkedin_fetched_at timestamptz;

-- Ops metrics daily rollup (pipeline health over time)
CREATE TABLE IF NOT EXISTS ops_metrics_daily (
  day               date NOT NULL,
  tenant_id         uuid,
-- null = global/system
  pipeline_runs     int NOT NULL DEFAULT 0,
  leads_discovered  int NOT NULL DEFAULT 0,
  leads_enriched_ok int NOT NULL DEFAULT 0,
  leads_enriched_fail int NOT NULL DEFAULT 0,
  leads_gated       int NOT NULL DEFAULT 0,
  leads_assigned    int NOT NULL DEFAULT 0,
  suppression_hits  int NOT NULL DEFAULT 0,
  opt_out_hits      int NOT NULL DEFAULT 0,
  credits_issued    int NOT NULL DEFAULT 0,
  serper_calls      int NOT NULL DEFAULT 0,
  firecrawl_calls   int NOT NULL DEFAULT 0,
  avg_enrich_ms     int,
  error_samples     jsonb DEFAULT '[]',
  PRIMARY KEY (day, tenant_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS day date;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS tenant_id uuid;
-- null = global/system;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS pipeline_runs int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS leads_discovered int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS leads_enriched_ok int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS leads_enriched_fail int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS leads_gated int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS leads_assigned int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS suppression_hits int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS opt_out_hits int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS credits_issued int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS serper_calls int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS firecrawl_calls int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS avg_enrich_ms int;
ALTER TABLE IF EXISTS public.ops_metrics_daily ADD COLUMN IF NOT EXISTS error_samples jsonb;


-- Allow null tenant for global: use sentinel
-- Postgres UNIQUE treats NULLs as distinct — use coalesce in app or:
CREATE UNIQUE INDEX IF NOT EXISTS idx_ops_metrics_global
  ON ops_metrics_daily (day) WHERE tenant_id IS NULL;

CREATE OR REPLACE FUNCTION bump_ops_metric(
  p_day date,
  p_tenant_id uuid,
  p_field text,
  p_delta int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO ops_metrics_daily (day, tenant_id)
  VALUES (p_day, p_tenant_id)
  ON CONFLICT (day, tenant_id) DO NOTHING;

  EXECUTE format(
    'UPDATE ops_metrics_daily SET %I = COALESCE(%I, 0) + $1 WHERE day = $2 AND tenant_id IS NOT DISTINCT FROM $3',
    p_field, p_field
  ) USING p_delta, p_day, p_tenant_id;
EXCEPTION WHEN OTHERS THEN
  -- soft fail — never break pipeline for metrics
  NULL;
END;
$$;


-- ##### 008_stripe_billing.sql #####

-- Stripe billing fields + usage_log report tracking

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS stripe_customer_id text,
  ADD COLUMN IF NOT EXISTS stripe_subscription_item_id text,
  ADD COLUMN IF NOT EXISTS stripe_price_id text;

CREATE INDEX IF NOT EXISTS idx_tenants_stripe
  ON tenants (stripe_customer_id) WHERE stripe_customer_id IS NOT NULL;

ALTER TABLE usage_log
  ADD COLUMN IF NOT EXISTS stripe_reported_at timestamptz,
  ADD COLUMN IF NOT EXISTS stripe_reported_qty int;


-- ##### 009_social_enrich.sql #####

-- Social enrichment (LinkedIn via microservice + Instagram via instaloader)
-- Runs only on quality-gated leads before assign.

CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,
-- serper | drissbri | site_html
  source_instagram        text,
-- instaloader
  enriched_at             timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS linkedin_url text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS linkedin_employee_range text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS decision_maker_name text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS decision_maker_title text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS decision_makers jsonb;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_handle text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_followers int;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_bio text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_last_post_at timestamptz;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_stale boolean;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS source_linkedin text;
-- serper | drissbri | site_html;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS source_instagram text;
-- instaloader;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS enriched_at timestamptz;


CREATE TABLE IF NOT EXISTS social_enrichment_failures (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id    uuid,
  source     text NOT NULL,
-- linkedin | instagram
  error      text,
  failed_at  timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.social_enrichment_failures ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.social_enrichment_failures ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.social_enrichment_failures ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.social_enrichment_failures ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.social_enrichment_failures ADD COLUMN IF NOT EXISTS failed_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_social_fail_at ON social_enrichment_failures (failed_at DESC);

DO $$ BEGIN
  IF to_regclass('public.social_enrichment') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE social_enrichment ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.social_enrichment_failures') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE social_enrichment_failures ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

DROP POLICY IF EXISTS social_enrich_select ON social_enrichment;
CREATE POLICY social_enrich_select ON social_enrichment FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

DROP POLICY IF EXISTS social_fail_select ON social_enrichment_failures;
CREATE POLICY social_fail_select ON social_enrichment_failures FOR SELECT
  USING (
    lead_id IS NULL OR EXISTS (
      SELECT 1 FROM lead_assignments la
      WHERE la.lead_id = social_enrichment_failures.lead_id
        AND public.is_tenant_member(la.tenant_id)
    )
  );

-- Mirror key fields onto enrichment for CRM views
ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS instagram_handle text,
  ADD COLUMN IF NOT EXISTS instagram_followers int,
  ADD COLUMN IF NOT EXISTS instagram_last_post_at timestamptz,
  ADD COLUMN IF NOT EXISTS instagram_stale boolean;


-- ##### 010_beat_zoominfo_layer.sql #####

-- Layer that closes gaps vs ZoomInfo/Apollo for LOCAL B2B:
-- contacts (people), intent score, pitch lines, QA feedback, sample packs, sequences.

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]';

ALTER TABLE scores
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS pitch_line text;

-- Named decision-makers / people (Apollo-style contacts, local-first)
CREATE TABLE IF NOT EXISTS lead_contacts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  full_name       text,
  title           text,
  email           text,
  phone           text,
  linkedin_url    text,
  is_decision_maker boolean DEFAULT false,
  source          text,
-- linkedin | website | serper | manual
  confidence      int DEFAULT 50,
  created_at      timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS linkedin_url text;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS is_decision_maker boolean;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS source text;
-- linkedin | website | serper | manual;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS confidence int;
ALTER TABLE IF EXISTS public.lead_contacts ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_contacts_lead ON lead_contacts (lead_id);

-- Operator QA (accuracy proof vs ZoomInfo brand trust)
CREATE TABLE IF NOT EXISTS lead_qa (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id         uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id   uuid,
  tenant_id       uuid,
  phone_ok        boolean,
  email_ok        boolean,
  business_open   boolean,
  notes           text,
  reviewed_by     text DEFAULT 'ops',
  reviewed_at     timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS phone_ok boolean;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS email_ok boolean;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS business_open boolean;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS reviewed_by text;
ALTER TABLE IF EXISTS public.lead_qa ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_qa_tenant ON lead_qa (tenant_id, reviewed_at DESC);

-- Sample packs for sales (beat Apollo free credits narrative)
CREATE TABLE IF NOT EXISTS sample_packs (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  vertical        text,
  geo             text,
  lead_ids        uuid[] DEFAULT '{}',
  meta            jsonb DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS geo text;
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS lead_ids uuid[];
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.sample_packs ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Territory exclusivity board (ZoomInfo has territories; we make them real)
CREATE TABLE IF NOT EXISTS territories (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  vertical        text NOT NULL,
  geo_key         text NOT NULL,
-- normalized city/region key
  exclusive_until date,
  status          text NOT NULL DEFAULT 'active',
-- active | expired | released
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (vertical, geo_key)
-- one exclusive owner per vertical+geo
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS geo_key text;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS exclusive_until date;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE IF EXISTS public.territories ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Client "report bad lead" requests
CREATE TABLE IF NOT EXISTS bad_lead_reports (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL,
  assignment_id   uuid NOT NULL,
  lead_id         uuid,
  reason          text NOT NULL,
-- wrong_number | email_bounce | closed | duplicate | other
  detail          text,
  status          text NOT NULL DEFAULT 'open',
-- open | credited | rejected
  created_at      timestamptz NOT NULL DEFAULT now(),
  resolved_at     timestamptz
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS detail text;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.bad_lead_reports ADD COLUMN IF NOT EXISTS resolved_at timestamptz;


DO $$ BEGIN
  IF to_regclass('public.lead_contacts') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_contacts ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.lead_qa') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE lead_qa ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.bad_lead_reports') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE bad_lead_reports ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.territories') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE territories ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;


-- ##### 010_pipeline_run_leads.sql #####

-- 010_pipeline_run_leads.sql
-- Per-run lead board: stage + tier + include for operator drag-drop review

create table if not exists public.pipeline_run_leads (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.pipeline_runs(id) on delete cascade,
  lead_id uuid not null references public.leads_global(id) on delete cascade,
  tenant_id uuid references public.tenants(id) on delete set null,
  stage text not null default 'discovered',
-- discovered | enriched | gated | assigned | excluded
  tier text,
-- A | B | C
  included boolean not null default true,
  score int,
  source text,
  name text,
  phone text,
  website text,
  city text,
  position int default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (run_id, lead_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS run_id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS stage text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS tier text;
-- A | B | C;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS included boolean;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS score int;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS position int;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS updated_at timestamptz;


create index if not exists idx_prl_run on public.pipeline_run_leads(run_id);
create index if not exists idx_prl_tenant on public.pipeline_run_leads(tenant_id);
create index if not exists idx_prl_stage on public.pipeline_run_leads(run_id, stage);

-- Optional: allow service role full access (RLS policies as needed)
alter table public.pipeline_run_leads enable row level security;
drop policy if exists "service_all_pipeline_run_leads" on public.pipeline_run_leads;
create policy "service_all_pipeline_run_leads" on public.pipeline_run_leads
  for all to service_role using (true) with check (true);


-- ##### 011_continuous_discovery.sql #####

-- Continuous supply: track what each ICP has already covered so runs explore NEW space.

CREATE TABLE IF NOT EXISTS discovery_coverage (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid,
  icp_id          uuid,
  vertical        text NOT NULL,
  source          text NOT NULL,
-- maps | linkedin | instagram | web | yelp | facebook
  location_key    text NOT NULL,
-- normalized geo cell
  query_key       text NOT NULL DEFAULT '',
  page_reached    int NOT NULL DEFAULT 0,
  leads_found     int NOT NULL DEFAULT 0,
  last_run_at     timestamptz NOT NULL DEFAULT now(),
  exhausted       boolean NOT NULL DEFAULT false,
-- true when source returns 0 new
  meta            jsonb DEFAULT '{}',
  UNIQUE (icp_id, source, location_key, query_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS location_key text;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS query_key text;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS page_reached int;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS leads_found int;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS exhausted boolean;
ALTER TABLE IF EXISTS public.discovery_coverage ADD COLUMN IF NOT EXISTS meta jsonb;


CREATE INDEX IF NOT EXISTS idx_coverage_icp ON discovery_coverage (icp_id, exhausted, last_run_at);
CREATE INDEX IF NOT EXISTS idx_coverage_vertical ON discovery_coverage (vertical, location_key);

-- Fingerprints already delivered to a tenant (fast skip at discovery)
CREATE TABLE IF NOT EXISTS tenant_seen_leads (
  tenant_id       uuid NOT NULL,
  fingerprint     text NOT NULL,
  lead_id         uuid,
  first_seen_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, fingerprint)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_seen_leads ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tenant_seen_leads ADD COLUMN IF NOT EXISTS fingerprint text;
ALTER TABLE IF EXISTS public.tenant_seen_leads ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.tenant_seen_leads ADD COLUMN IF NOT EXISTS first_seen_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_tenant_seen_fp ON tenant_seen_leads (fingerprint);

-- ICP geo expansion cells (zip / neighborhood / adjacent city)
CREATE TABLE IF NOT EXISTS icp_geo_cells (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  icp_id          uuid NOT NULL,
  cell_key        text NOT NULL,
-- "hoboken-nj" | "07030" | "jersey-city-nj"
  cell_label      text NOT NULL,
-- human label for Serper queries
  priority        int NOT NULL DEFAULT 100,
  times_scanned   int NOT NULL DEFAULT 0,
  last_scanned_at timestamptz,
  active          boolean NOT NULL DEFAULT true,
  UNIQUE (icp_id, cell_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS cell_key text;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS cell_label text;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS priority int;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS times_scanned int;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS last_scanned_at timestamptz;
ALTER TABLE IF EXISTS public.icp_geo_cells ADD COLUMN IF NOT EXISTS active boolean;


CREATE INDEX IF NOT EXISTS idx_geo_cells_scan ON icp_geo_cells (icp_id, active, times_scanned, last_scanned_at);


-- ##### 012_offer_category_exclusivity.sql #####

-- Competitive exclusivity: lock only against same offer_category (seller type)
-- not against every ICP that targets the same vertical/geo.
--
-- Example: hair-dryer seller + hair-cream seller both target NJ salons → BOTH OK.
--          two SEO agencies targeting NJ salons → CONFLICT if exclusive.

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_category text;

-- Human label for UI
ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS offer_label text;

COMMENT ON COLUMN icp_profiles.offer_category IS
  'Competitive lock key. Same category + overlapping geo + exclusive = conflict. Different categories share the lead.';

COMMENT ON COLUMN icp_profiles.vertical IS
  'Target industry of the LEAD (salon, medspa). NOT the exclusivity lock.';

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS offer_category text;

CREATE INDEX IF NOT EXISTS idx_icp_offer_category
  ON icp_profiles (lower(offer_category)) WHERE active = true;

CREATE INDEX IF NOT EXISTS idx_assignments_offer_cat
  ON lead_assignments (lead_id, lower(offer_category))
  WHERE status NOT IN ('rejected', 'expired');

-- Backfill: if offer_category null, use vertical as conservative default
-- (operator should set real categories for multi-ICP same-vertical sharing)
UPDATE icp_profiles
SET offer_category = lower(regexp_replace(vertical, '\s+', '_', 'g'))
WHERE offer_category IS NULL OR offer_category = '';

UPDATE lead_assignments la
SET offer_category = icp.offer_category
FROM icp_profiles icp
WHERE la.icp_id = icp.id
  AND (la.offer_category IS NULL OR la.offer_category = '');

-- New exclusivity function: compete on offer_category, not vertical alone
CREATE OR REPLACE FUNCTION check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[],
  p_offer_category text DEFAULT NULL
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE
  conflict_exists boolean;
  v_offer text;
BEGIN
  -- Prefer explicit offer category; fall back to vertical (legacy)
  v_offer := lower(nullif(trim(p_offer_category), ''));
  IF v_offer IS NULL THEN
    v_offer := lower(nullif(trim(p_vertical), ''));
  END IF;

  IF v_offer IS NULL THEN
    RETURN false; -- cannot lock without a category
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM lead_assignments la
    LEFT JOIN icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected', 'expired')
      AND COALESCE(icp.exclusivity, 'exclusive') = 'exclusive'
      -- SAME competitive set only
      AND lower(COALESCE(nullif(la.offer_category, ''), nullif(icp.offer_category, ''), icp.vertical, la.vertical, ''))
          = v_offer
      AND (
        icp.geo IS NULL
        OR icp.geo = '[]'::jsonb
        OR p_geo IS NULL
        OR cardinality(p_geo) = 0
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE g = ANY (p_geo)
        )
      )
  ) INTO conflict_exists;

  RETURN conflict_exists;
END;
$$;


-- ##### 013_differentiators.sql #####

-- Differentiators: talking points, outreach, docs, recycle, freshness, territories

ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS first_touch_meta jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS recycled_from_assignment_id uuid,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz;

ALTER TABLE tenants
  ADD COLUMN IF NOT EXISTS auto_first_touch boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS first_touch_channel text DEFAULT 'sms',
  ADD COLUMN IF NOT EXISTS first_touch_script text,
  ADD COLUMN IF NOT EXISTS vapi_assistant_id text,
  ADD COLUMN IF NOT EXISTS twilio_from_number text,
  ADD COLUMN IF NOT EXISTS whatsapp_from text,
  ADD COLUMN IF NOT EXISTS onboarding_defaults jsonb DEFAULT '{}';

ALTER TABLE icp_profiles
  ADD COLUMN IF NOT EXISTS client_weight_overrides jsonb DEFAULT '{}';

-- Document templates library
CREATE TABLE IF NOT EXISTS doc_templates (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenants(id) ON DELETE CASCADE,
-- null = global
  category      text NOT NULL,
-- contract, nda, invoice, proposal, onboarding
  name          text NOT NULL,
  description   text,
  body_html     text NOT NULL,
  body_text     text,
  variables     jsonb NOT NULL DEFAULT '[]',
-- ["client_name","amount",...]
  channel_hint  text DEFAULT 'email',
-- email, whatsapp, both
  active        boolean DEFAULT true,
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS body_html text;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS variables jsonb;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS channel_hint text;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS active boolean;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.doc_templates ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_doc_templates_cat ON doc_templates (category) WHERE active;

-- Generated docs / sends log
CREATE TABLE IF NOT EXISTS doc_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  template_id   uuid REFERENCES doc_templates(id) ON DELETE SET NULL,
  category      text,
  to_email      text,
  to_phone      text,
  channel       text NOT NULL,
-- email, whatsapp
  subject       text,
  body_html     text,
  body_text     text,
  variables     jsonb DEFAULT '{}',
  status        text DEFAULT 'queued',
  provider_id   text,
  error         text,
  created_at    timestamptz DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS template_id uuid;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS to_email text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS to_phone text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS channel text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS body_html text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS variables jsonb;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS provider_id text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.doc_sends ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_doc_sends_tenant ON doc_sends (tenant_id, created_at DESC);

-- Outreach log
CREATE TABLE IF NOT EXISTS first_touch_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  channel       text NOT NULL,
  status        text NOT NULL,
  provider      text,
  provider_id   text,
  payload       jsonb DEFAULT '{}',
  error         text,
  created_at    timestamptz DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS channel text;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS provider_id text;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS payload jsonb;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.first_touch_log ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Freshness schedule config (global defaults)
CREATE TABLE IF NOT EXISTS freshness_policy (
  tier          text PRIMARY KEY,
  reverify_days int NOT NULL
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.freshness_policy ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE IF EXISTS public.freshness_policy ADD COLUMN IF NOT EXISTS reverify_days int;


INSERT INTO freshness_policy (tier, reverify_days) VALUES
  ('A', 7), ('B', 21), ('C', 60)
ON CONFLICT (tier) DO NOTHING;

-- Seed a starter global template pack (short, editable)
INSERT INTO doc_templates (tenant_id, category, name, description, body_html, body_text, variables, channel_hint)
SELECT NULL, x.category, x.name, x.description, x.body_html, x.body_text, x.variables::jsonb, x.channel_hint
FROM (VALUES
  ('contract', 'Service Agreement (simple)', '1-page services agreement',
   '<h2>Service Agreement</h2><p>This agreement is between <b>{{provider_name}}</b> and <b>{{client_name}}</b>.</p><p>Scope: {{scope}}</p><p>Fee: {{amount}} {{currency}}</p><p>Term: {{term}}</p><p>Signed: ________________</p>',
   'Service Agreement between {{provider_name}} and {{client_name}}. Scope: {{scope}}. Fee: {{amount}} {{currency}}. Term: {{term}}.',
   '["provider_name","client_name","scope","amount","currency","term"]', 'email'),
  ('nda', 'Mutual NDA', 'Short mutual confidentiality',
   '<h2>Mutual NDA</h2><p>{{party_a}} and {{party_b}} agree to keep confidential information private for {{term}}.</p>',
   'Mutual NDA between {{party_a}} and {{party_b}} for {{term}}.',
   '["party_a","party_b","term"]', 'email'),
  ('invoice', 'Standard Invoice', 'Simple invoice',
   '<h2>Invoice {{invoice_number}}</h2><p>Bill to: {{client_name}}</p><p>Amount due: <b>{{amount}} {{currency}}</b></p><p>Due: {{due_date}}</p><p>{{line_items}}</p>',
   'Invoice {{invoice_number}} to {{client_name}} for {{amount}} {{currency}}, due {{due_date}}.',
   '["invoice_number","client_name","amount","currency","due_date","line_items"]', 'both'),
  ('proposal', 'Lead Package Proposal', 'Proposal for exclusive leads',
   '<h2>Proposal</h2><p>Hi {{client_name}},</p><p>We will deliver {{lead_count}} Tier A {{vertical}} leads in {{geo}}.</p><p>Investment: {{amount}}/mo. Exclusivity: {{offer_category}} in {{geo}}.</p>',
   'Proposal for {{client_name}}: {{lead_count}} Tier A {{vertical}} leads in {{geo}} at {{amount}}/mo.',
   '["client_name","lead_count","vertical","geo","amount","offer_category"]', 'email'),
  ('onboarding', 'Client Onboarding Checklist', 'Kickoff email',
   '<h2>Welcome, {{client_name}}</h2><ol><li>Confirm ICP: {{vertical}} in {{geo}}</li><li>CRM login</li><li>Sample pack review</li><li>First pipeline run</li></ol>',
   'Welcome {{client_name}}. Confirm ICP {{vertical}} / {{geo}}, CRM login, sample pack, first run.',
   '["client_name","vertical","geo"]', 'both')
) AS x(category, name, description, body_html, body_text, variables, channel_hint)
WHERE NOT EXISTS (SELECT 1 FROM doc_templates WHERE name = x.name AND tenant_id IS NULL);


-- ##### 014_email_outreach.sql #####

CREATE TABLE IF NOT EXISTS email_sends (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid,
  lead_id       uuid,
  to_email      text NOT NULL,
  subject       text,
  status        text NOT NULL DEFAULT 'queued',
  provider      text,
  provider_id   text,
  error         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS to_email text;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS provider_id text;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.email_sends ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_email_sends_tenant ON email_sends (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_sends_assignment ON email_sends (assignment_id);


-- ##### 015_crm_missing_objects.sql #####

-- =============================================================================
-- 015 — CRM missing objects (runtime-breaking gap repair)
--
-- Fixes three verified gaps that make the CRM portal return HTTP 500:
--   (a) view  crm_lead_cards      — queried by 5 endpoints, defined nowhere
--   (b) func  seed_default_stages — called via sb.rpc(), defined nowhere
--   (c) note  email_outreach.py writes to a table named `activities`
--
-- Idempotent / re-runnable. Does NOT drop or redefine any existing table;
-- only ADD COLUMN IF NOT EXISTS (the same additive "column repair" pattern
-- already used in SUPABASE_FULL_MIGRATION.sql around line 466).
-- =============================================================================


-- ---------------------------------------------------------------------------
-- 0. Column repair — columns the CRM code reads/writes that were never created
--
-- These are NOT cosmetic. Every one of them is referenced by
-- backend/crm/crm_api.py today:
--   lead_assignments.stage_id          crm_api.py:410,439,573 (change_stage, pipeline_board)
--   lead_assignments.priority          crm_api.py:262,271,688 (filter, sort, export)
--   lead_assignments.assigned_to       crm_api.py:260          (filter)
--   lead_assignments.next_action_at    crm_api.py:271          (sort)
--   lead_assignments.value_estimate    crm_api.py:55           (LeadUpdate PATCH)
--   lead_assignments.custom_fields     crm_api.py:57           (LeadUpdate PATCH)
--   lead_assignments.tags              crm_api.py:264          (contains filter)
--   lead_assignments.last_contacted_at crm_api.py:441,496      (write on activity)
--   lead_assignments.assigned_at       crm_api.py:787, leads_api.py:1030,1184
--   pipeline_stages.is_won/is_lost     crm_api.py:130,614-615
--   lead_activities.lead_id/actor_id   crm_api.py:96-97,486
--   lead_tasks.lead_id/description/assigned_to  crm_api.py:521-526
-- Without them the view below cannot be built and the PATCH/stage/task
-- endpoints fail on insert.
-- ---------------------------------------------------------------------------

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id          uuid,
  ADD COLUMN IF NOT EXISTS stage_slug        text,
  ADD COLUMN IF NOT EXISTS priority          text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to       text,
  ADD COLUMN IF NOT EXISTS next_action_at    timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate    numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields     jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags              text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at       timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes             text;

-- stage_id -> pipeline_stages(id), added separately so a re-run is safe
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'lead_assignments_stage_id_fkey'
  ) THEN
    ALTER TABLE lead_assignments
      ADD CONSTRAINT lead_assignments_stage_id_fkey
      FOREIGN KEY (stage_id) REFERENCES pipeline_stages(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Backfill assigned_at from created_at for rows that predate the column
UPDATE lead_assignments
SET assigned_at = created_at
WHERE assigned_at IS NULL AND created_at IS NOT NULL;

ALTER TABLE pipeline_stages
  ADD COLUMN IF NOT EXISTS is_won     boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_lost    boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE lead_activities
  ADD COLUMN IF NOT EXISTS lead_id  uuid,
  ADD COLUMN IF NOT EXISTS actor_id uuid;

ALTER TABLE lead_tasks
  ADD COLUMN IF NOT EXISTS lead_id     uuid,
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS assigned_to text;

-- Partial-DB safety: these exist in SUPABASE_FULL_MIGRATION.sql's CREATE TABLE
-- but NOT in the older sql/001 definitions, so a DB built from 001 lacks them
-- and the view below would fail to compile. Additive, no-op when present.
ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS google_place_id text,
  ADD COLUMN IF NOT EXISTS source_url      text,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier     text;

ALTER TABLE enrichment
  ADD COLUMN IF NOT EXISTS email_valid boolean;

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS geo_tags            text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS delivery_status     text DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS delivery_error      text,
  ADD COLUMN IF NOT EXISTS exclusive_until     timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_status  text,
  ADD COLUMN IF NOT EXISTS first_touch_at      timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text;

-- social_enrichment is created by sql/009_social_enrich.sql and is a hard
-- dependency of the view. Guarded here so 015 can be applied to a DB where
-- 009 has not been run yet (IF NOT EXISTS — never alters an existing table).
CREATE TABLE IF NOT EXISTS social_enrichment (
  lead_id                 uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  linkedin_url            text,
  linkedin_employee_range text,
  decision_maker_name     text,
  decision_maker_title    text,
  decision_makers         jsonb DEFAULT '[]',
  instagram_handle        text,
  instagram_followers     int,
  instagram_bio           text,
  instagram_last_post_at  timestamptz,
  instagram_stale         boolean DEFAULT false,
  source_linkedin         text,
  source_instagram        text,
  enriched_at             timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS linkedin_url text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS linkedin_employee_range text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS decision_maker_name text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS decision_maker_title text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS decision_makers jsonb;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_handle text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_followers int;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_bio text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_last_post_at timestamptz;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS instagram_stale boolean;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS source_linkedin text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS source_instagram text;
ALTER TABLE IF EXISTS public.social_enrichment ADD COLUMN IF NOT EXISTS enriched_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_lead_assignments_stage
  ON lead_assignments (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_priority
  ON lead_assignments (tenant_id, priority);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_assigned_to
  ON lead_assignments (tenant_id, assigned_to) WHERE assigned_to IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_assignments_next_action
  ON lead_assignments (tenant_id, next_action_at) WHERE next_action_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tags
  ON lead_assignments USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_lead_activities_lead
  ON lead_activities (lead_id) WHERE lead_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_lead_tasks_lead
  ON lead_tasks (lead_id) WHERE lead_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- (a) crm_lead_cards — the denormalized lead card the CRM portal reads
--
-- Consumed by:
--   crm_api.py:138  dashboard      -> assignment_id, stage_slug, tier
--                                     total_score, assignment_status
--   crm_api.py:251  list_leads     -> select *, filters on stage_slug, tier
--                                     assignment_status, assigned_to, priority
--                                     tags (contains), company_name (ilike);
--                                     orders by delivered_at | total_score |
--                                     company_name | next_action_at | priority
--   crm_api.py:291  lead_detail    -> select *, needs lead_id
--   crm_api.py:563  pipeline_board -> select *, needs stage_id, orders total_score
--   crm_api.py:637  reports_summary-> tier, stage_slug, total_score
--                                     delivered_at, has_booking, email
--   crm_api.py:679  export_csv     -> company_name, phone_e164
--                                     phone_normalized, email, website, city
--                                     tier, total_score, stage_name
--                                     booking_platform, priority, delivered_at
--   app_service.py:144 healthcheck -> assignment_id
--
-- Plain (non-materialized) view so the CRM is always fresh — the portal
-- writes to lead_assignments and immediately re-reads this view.
-- LEFT JOINs throughout: a lead with no enrichment / score / stage must still
-- appear on the board, otherwise freshly-assigned leads vanish from the UI.
-- ---------------------------------------------------------------------------

-- DROP first: CREATE OR REPLACE VIEW cannot change or reorder existing
-- columns, so a re-run after any edit to the column list below would fail
-- with "cannot change name of view column". Dropping a view is non-
-- destructive (no data lives in it) and it is recreated immediately.

-- ========== Pre-view column safety (all refs used by crm_lead_cards) ==========
ALTER TABLE public.leads_global
  ADD COLUMN IF NOT EXISTS phone_normalized text,
  ADD COLUMN IF NOT EXISTS phone_e164 text,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS website_domain text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS address text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS business_status text,
  ADD COLUMN IF NOT EXISTS google_rating numeric,
  ADD COLUMN IF NOT EXISTS review_count int,
  ADD COLUMN IF NOT EXISTS google_place_id text,
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS source_url text,
  ADD COLUMN IF NOT EXISTS last_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS verify_tier text,
  ADD COLUMN IF NOT EXISTS talking_points text,
  ADD COLUMN IF NOT EXISTS talking_points_at timestamptz,
  ADD COLUMN IF NOT EXISTS pitch_line text;

ALTER TABLE public.enrichment
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS intent_reasons jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS technographics jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS contacts jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS has_booking boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS booking_platform text,
  ADD COLUMN IF NOT EXISTS services text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS social_links jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS owner_name text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS email_valid boolean,
  ADD COLUMN IF NOT EXISTS enrichment_ok boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS enrichment_method text,
  ADD COLUMN IF NOT EXISTS extracted_at timestamptz,
  ADD COLUMN IF NOT EXISTS markdown_summary text;

ALTER TABLE public.scores
  ADD COLUMN IF NOT EXISTS pitch_line text,
  ADD COLUMN IF NOT EXISTS intent_score int DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_score numeric,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS reasoning text;

ALTER TABLE public.lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id uuid,
  ADD COLUMN IF NOT EXISTS stage_slug text,
  ADD COLUMN IF NOT EXISTS priority text DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS assigned_to text,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(14,2),
  ADD COLUMN IF NOT EXISTS custom_fields jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS offer_category text,
  ADD COLUMN IF NOT EXISTS tier text,
  ADD COLUMN IF NOT EXISTS exclusive_until timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_status text,
  ADD COLUMN IF NOT EXISTS first_touch_at timestamptz,
  ADD COLUMN IF NOT EXISTS first_touch_channel text,
  ADD COLUMN IF NOT EXISTS geo_tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS icp_id uuid,
  ADD COLUMN IF NOT EXISTS delivery_channel text,
  ADD COLUMN IF NOT EXISTS delivery_error text;

ALTER TABLE public.pipeline_stages
  ADD COLUMN IF NOT EXISTS is_won boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_lost boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS color text,
  ADD COLUMN IF NOT EXISTS position int DEFAULT 0;

-- social_enrichment optional cols
DO $$ BEGIN
  IF to_regclass('public.social_enrichment') IS NOT NULL THEN
    ALTER TABLE public.social_enrichment
      ADD COLUMN IF NOT EXISTS decision_makers jsonb DEFAULT '[]',
      ADD COLUMN IF NOT EXISTS decision_maker_name text,
      ADD COLUMN IF NOT EXISTS decision_maker_title text,
      ADD COLUMN IF NOT EXISTS instagram_handle text,
      ADD COLUMN IF NOT EXISTS instagram_followers int;
  END IF;
END $$;
-- ========== end pre-view safety ==========

DROP VIEW IF EXISTS crm_lead_cards;

DROP VIEW IF EXISTS crm_lead_cards CASCADE;
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  -- ── identity / tenancy ──────────────────────────────────────────────────
  la.tenant_id                                    AS tenant_id,
  la.id                                           AS assignment_id,
  la.lead_id                                      AS lead_id,

  -- ── company / display ───────────────────────────────────────────────────
  lg.name                                         AS company_name,
  lg.name                                         AS name,
  lg.category                                     AS category,
  lg.category                                     AS industry,
  la.vertical                                     AS vertical,
  la.offer_category                               AS offer_category,

  -- ── pipeline position ───────────────────────────────────────────────────
  la.stage_id                                     AS stage_id,
  COALESCE(ps.slug, la.stage_slug, 'new')         AS stage_slug,
  COALESCE(ps.name, initcap(COALESCE(la.stage_slug, 'New'))) AS stage_name,
  ps.color                                        AS stage_color,
  ps.position                                     AS stage_position,
  COALESCE(ps.is_won,  false)                     AS stage_is_won,
  COALESCE(ps.is_lost, false)                     AS stage_is_lost,

  -- ── assignment state (note the aliases the API filters on) ──────────────
  la.status                                       AS assignment_status,
  la.status                                       AS status,
  la.priority                                     AS priority,
  la.assigned_to                                  AS assigned_to,
  la.assigned_at                                  AS assigned_at,
  la.delivered_at                                 AS delivered_at,
  la.delivery_channel                             AS delivery_channel,
  la.delivery_status                              AS delivery_status,
  la.delivery_error                               AS delivery_error,
  la.next_action_at                               AS next_action_at,
  la.last_contacted_at                            AS last_contacted_at,
  la.value_estimate                               AS value_estimate,
  COALESCE(la.custom_fields, '{}'::jsonb)         AS custom_fields,
  COALESCE(la.tags, '{}'::text[])                 AS tags,
  la.notes                                        AS notes,
  la.icp_id                                       AS icp_id,
  la.geo_tags                                     AS geo_tags,
  la.exclusive_until                              AS exclusive_until,
  la.first_touch_status                           AS first_touch_status,
  la.first_touch_at                               AS first_touch_at,
  la.first_touch_channel                          AS first_touch_channel,
  la.created_at                                   AS created_at,

  -- ── scoring (score/tier prefer the scores table, fall back to assignment)
  COALESCE(s.total_score, 0)                      AS total_score,
  COALESCE(s.total_score, 0)                      AS score,
  s.deterministic_score                           AS deterministic_score,
  s.llm_score                                     AS llm_score,
  COALESCE(s.tier, la.tier, 'C')                  AS tier,
  s.reasoning                                     AS score_reasoning,
  s.scored_at                                     AS scored_at,
  COALESCE(s.intent_score, e.intent_score, 0)     AS intent_score,

  -- ── contact channels ────────────────────────────────────────────────────
  -- leads_global has NO plain `phone` column (only phone_normalized /
  -- phone_e164). The frontend reads lead.phone, so it is synthesized here.
  COALESCE(lg.phone_e164, lg.phone_normalized, e.phone_from_web) AS phone,
  lg.phone_normalized                             AS phone_normalized,
  lg.phone_e164                                   AS phone_e164,
  e.phone_from_web                                AS phone_from_web,
  COALESCE(e.email, lg.email)                     AS email,
  e.email_valid                                   AS email_valid,
  COALESCE(e.emails, '{}'::text[])                AS emails,
  lg.website                                      AS website,
  lg.website_domain                               AS website_domain,
  lg.website_domain                               AS domain,
  lg.address                                      AS address,
  lg.city                                         AS city,
  lg.state                                        AS state,

  -- ── quality / provenance signals ────────────────────────────────────────
  lg.business_status                              AS business_status,
  lg.google_rating                                AS google_rating,
  lg.review_count                                 AS review_count,
  lg.google_place_id                              AS google_place_id,
  lg.source                                       AS source,
  lg.source_url                                   AS source_url,
  -- entity_resolution.py joins multi-source hits into `source` as "a+b+c";
  -- split it back out so the UI's lead.sources_hit array works.
  string_to_array(COALESCE(lg.source, ''), '+')   AS sources_hit,
  lg.last_verified_at                             AS last_verified_at,
  lg.verify_tier                                  AS verify_tier,

  -- ── enrichment / sales-enablement ───────────────────────────────────────
  COALESCE(e.has_booking, false)                  AS has_booking,
  e.booking_platform                              AS booking_platform,
  COALESCE(e.services, '{}'::text[])              AS services,
  COALESCE(e.tech_stack, '{}'::text[])            AS tech_stack,
  COALESCE(e.social_links, '{}'::jsonb)           AS social_links,
  e.owner_name                                    AS owner_name,
  COALESCE(e.linkedin_url, se.linkedin_url)       AS linkedin_url,
  COALESCE(e.decision_makers, se.decision_makers, '[]'::jsonb) AS decision_makers,
  se.decision_maker_name                          AS decision_maker_name,
  se.decision_maker_title                         AS decision_maker_title,
  se.instagram_handle                             AS instagram_handle,
  se.instagram_followers                          AS instagram_followers,
  COALESCE(e.pitch_line, s.pitch_line) AS pitch_line,
  lg.talking_points                               AS talking_points,
  e.markdown_summary                              AS markdown_summary,
  COALESCE(e.enrichment_ok, false)                AS enrichment_ok,
  e.enrichment_method                             AS enrichment_method,
  e.extracted_at                                  AS enriched_at
FROM lead_assignments la
LEFT JOIN leads_global      lg ON lg.id = la.lead_id
LEFT JOIN enrichment        e  ON e.lead_id = la.lead_id
LEFT JOIN scores            s  ON s.lead_id = la.lead_id
LEFT JOIN social_enrichment se ON se.lead_id = la.lead_id
LEFT JOIN pipeline_stages   ps ON ps.id = la.stage_id
                              AND ps.tenant_id = la.tenant_id;

COMMENT ON VIEW crm_lead_cards IS
  'Denormalized CRM lead card: lead_assignments + leads_global + enrichment + '
  'scores + social_enrichment + pipeline_stages. Read by /crm dashboard, '
  'leads list/detail, pipeline board, reports and CSV export. Plain view '
  '(not materialized) so portal writes are immediately visible.';

-- Tenant isolation: by default a view runs as its OWNER, which would BYPASS
-- the RLS policies on lead_assignments and leak other tenants' leads to any
-- authenticated caller. security_invoker makes the view evaluate the caller's
-- RLS instead (Postgres 15+ / current Supabase). Wrapped in a DO block so
-- this file still applies on an older server — but on a pre-15 server the
-- view must only ever be read by the service role.
DO $$
BEGIN
  EXECUTE 'ALTER VIEW crm_lead_cards SET (security_invoker = true)';
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'crm_lead_cards: security_invoker unsupported on this server — restrict this view to service_role';
END $$;

GRANT SELECT ON crm_lead_cards TO authenticated, service_role;


-- ---------------------------------------------------------------------------
-- (b) seed_default_stages(p_tenant_id uuid)
--
-- Called via sb.rpc("seed_default_stages", {"p_tenant_id": ...}) at
-- crm_api.py:605 (POST /crm/{tenant_id}/stages/seed and /setup).
-- Idempotent twice over: it returns early if the tenant already has any
-- stage, and the INSERT still carries ON CONFLICT DO NOTHING against the
-- existing UNIQUE (tenant_id, slug).
--
-- Slugs/colors/order match the Python fallback list in crm_api.py:608-616 so
-- the RPC path and the fallback path produce identical pipelines.
-- ---------------------------------------------------------------------------

DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);

CREATE OR REPLACE FUNCTION public.seed_default_stages(p_tenant_id uuid)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_inserted int := 0;
BEGIN
  IF p_tenant_id IS NULL THEN
    RETURN 0;
  END IF;

  -- Already configured (possibly customized) — never overwrite operator setup.
  IF EXISTS (SELECT 1 FROM pipeline_stages WHERE tenant_id = p_tenant_id) THEN
    RETURN 0;
  END IF;

  INSERT INTO pipeline_stages (tenant_id, name, slug, position, color, is_won, is_lost)
  VALUES
    (p_tenant_id, 'New',         'new',         1, '#94a3b8', false, false),
    (p_tenant_id, 'Contacted',   'contacted',   2, '#3b82f6', false, false),
    (p_tenant_id, 'Qualified',   'qualified',   3, '#8b5cf6', false, false),
    (p_tenant_id, 'Proposal',    'proposal',    4, '#f59e0b', false, false),
    (p_tenant_id, 'Negotiation', 'negotiation', 5, '#f97316', false, false),
    (p_tenant_id, 'Won',         'won',         6, '#22c55e', true,  false),
    (p_tenant_id, 'Lost',        'lost',        7, '#ef4444', false, true)
  ON CONFLICT (tenant_id, slug) DO NOTHING;

  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  RETURN v_inserted;
END;
$$;

COMMENT ON FUNCTION public.seed_default_stages(uuid) IS
  'Seed the default 7-stage pipeline for a tenant. No-op if the tenant '
  'already has stages. Called by POST /crm/{tenant_id}/stages/seed.';

GRANT EXECUTE ON FUNCTION public.seed_default_stages(uuid) TO authenticated, service_role;


-- ---------------------------------------------------------------------------
-- (c) NOTE — the `activities` table referenced by email_outreach.py
--
-- backend/integrations/prod/email_outreach.py:206 inserts into a table named
-- `activities`. Historically no such table existed: the lead-engine timeline
-- table is `lead_activities` (tenant_id, assignment_id, activity_type, title
-- body, meta, created_by, created_at). That insert was silently swallowed by
-- its surrounding try/except, so email sends were never timelined.
--
-- Deliberately NOT creating an `activities` shim here. Two things resolve it:
--   1. The Python fix (in progress) writes to `lead_activities` first.
--   2. sql/016_crm_full.sql introduces a genuinely NEW, richer `activities`
--      table for the company/contact/deal CRM — with DIFFERENT columns
--      (subject + occurred_at + direction, not title). email_outreach.py's
--      fallback branch already targets that shape.
-- Do not "fix" this by aliasing activities -> lead_activities; the two tables
-- have different grains (lead assignment vs. account/contact/deal) and
-- different column names.
-- ---------------------------------------------------------------------------


-- ##### 016_crm_full.sql #####

-- =============================================================================
-- 016 — Full CRM / customer database
--
-- The lead engine's own tables (leads_global, lead_assignments, enrichment
-- scores) model SCRAPED PROSPECTS. This file adds the layer above them: the
-- accounts, people, opportunities and timeline a user actually works after a
-- prospect converts — companies, contacts, deal_stages, deals, activities
-- tasks, notes, custom_field_defs, email_log, call_log.
--
-- Relationship to the lead engine:
--   leads_global.id  ──► companies.source_lead_id   (provenance on convert)
--   lead_assignments.id ──► deals.source_assignment_id
--                       ──► activities.assignment_id / email_log / call_log
-- Nothing here modifies or drops an existing table.
--
-- Idempotent / re-runnable throughout.
-- Tags: this schema uses `tags text[]` columns (matching lead_assignments.tags
-- and the GIN-indexed pattern already used elsewhere). There is deliberately
-- NO separate tags/taggings join table — see the note at the end of the file.
-- =============================================================================

-- pg_trgm backs the fuzzy company-name search index below. Already created by
-- sql/001, repeated here so 016 can be applied standalone.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ---------------------------------------------------------------------------
-- Shared updated_at trigger helper
--
-- Checked first: the existing schema (sql/001..014, SUPABASE_FULL_MIGRATION)
-- has NO trigger function at all — every updated_at is set by the application.
-- So this helper is new, and is named distinctly to avoid colliding with any
-- future Supabase-provided function. Reused by every table below.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.crm_set_updated_at()
RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

COMMENT ON FUNCTION public.crm_set_updated_at IS
  'BEFORE UPDATE trigger: stamps updated_at = now(). Shared by all 016 CRM tables.';


-- ---------------------------------------------------------------------------
-- 1. companies — the customer / account record
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS companies (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name            text NOT NULL,
  domain          text,
  website         text,
  phone           text,
  address         text,
  city            text,
  state           text,
  country         text,
  postal_code     text,
  industry        text,
  employee_count  int,
  annual_revenue  numeric(16,2),
  description     text,
  owner           text,
-- tenant_members.email / free text
                                          -- matching lead_assignments.assigned_to
  status          text NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','prospect','customer','churned','archived')),
  tags            text[] NOT NULL DEFAULT '{}',
  custom_fields   jsonb  NOT NULL DEFAULT '{}',
  source          text,
  source_lead_id  uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS address text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS country text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS postal_code text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS industry text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS employee_count int;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS annual_revenue numeric(16,2);
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS owner text;
-- tenant_members.email / free text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS tags text[];
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS custom_fields jsonb;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS source_lead_id uuid;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.companies ADD COLUMN IF NOT EXISTS updated_at timestamptz;


-- One account per domain per tenant (case-insensitive); NULL domain unconstrained
CREATE UNIQUE INDEX IF NOT EXISTS idx_companies_tenant_domain
  ON companies (tenant_id, lower(domain)) WHERE domain IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_tenant_status
  ON companies (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_companies_tenant_owner
  ON companies (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_companies_tenant_name
  ON companies (tenant_id, lower(name));
CREATE INDEX IF NOT EXISTS idx_companies_name_trgm
  ON companies USING gin (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_companies_tags
  ON companies USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_companies_source_lead
  ON companies (source_lead_id) WHERE source_lead_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_companies_updated_at ON companies;
CREATE TRIGGER trg_companies_updated_at BEFORE UPDATE ON companies
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE companies IS
  'Customer/account record. source_lead_id preserves provenance when an '
  'account is converted from a scraped leads_global row.';


-- ---------------------------------------------------------------------------
-- 2. contacts — people at an account
--
-- Distinct from lead_contacts (which hangs off leads_global and holds
-- scraped, unverified decision-makers). contacts are the tenant's own
-- curated people records.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contacts (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id        uuid REFERENCES companies(id) ON DELETE CASCADE,
  full_name         text,
  first_name        text,
  last_name         text,
  title             text,
  email             text,
  phone             text,
  mobile            text,
  linkedin_url      text,
  is_primary        boolean NOT NULL DEFAULT false,
  is_decision_maker boolean NOT NULL DEFAULT false,
  owner             text,
  status            text NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','unqualified','bounced','archived')),
  tags              text[] NOT NULL DEFAULT '{}',
  custom_fields     jsonb  NOT NULL DEFAULT '{}',
  do_not_contact    boolean NOT NULL DEFAULT false,
  source            text,
  source_lead_id    uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_by        uuid,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS company_id uuid;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS first_name text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS last_name text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS mobile text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS linkedin_url text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS is_primary boolean;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS is_decision_maker boolean;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS owner text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS tags text[];
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS custom_fields jsonb;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS do_not_contact boolean;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS source_lead_id uuid;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.contacts ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_contacts_tenant_email
  ON contacts (tenant_id, lower(email));
CREATE INDEX IF NOT EXISTS idx_contacts_company
  ON contacts (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_status
  ON contacts (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_owner
  ON contacts (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_contacts_tags
  ON contacts USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_contacts_dnc
  ON contacts (tenant_id) WHERE do_not_contact = true;
-- At most one primary contact per company
CREATE UNIQUE INDEX IF NOT EXISTS idx_contacts_one_primary
  ON contacts (company_id) WHERE is_primary = true AND company_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_contacts_updated_at ON contacts;
CREATE TRIGGER trg_contacts_updated_at BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE contacts IS
  'Tenant-curated people. Distinct from lead_contacts (scraped decision-makers '
  'attached to leads_global). do_not_contact must be honoured by all outreach.';

-- ---------------------------------------------------------------------------
-- 3. deal_stages — per-tenant configurable deal pipeline
--
-- Separate from pipeline_stages (which stages LEAD ASSIGNMENTS in the lead
-- engine). Deals move through their own stages with win probabilities.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deal_stages (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name          text NOT NULL,
  slug          text NOT NULL,
  position      int  NOT NULL DEFAULT 0,
  color         text,
  probability   int  NOT NULL DEFAULT 0 CHECK (probability BETWEEN 0 AND 100),
  is_won        boolean NOT NULL DEFAULT false,
  is_lost       boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS slug text;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS position int;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS color text;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS probability int;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS is_won boolean;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS is_lost boolean;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.deal_stages ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_deal_stages_tenant_position
  ON deal_stages (tenant_id, position);

DROP TRIGGER IF EXISTS trg_deal_stages_updated_at ON deal_stages;
CREATE TRIGGER trg_deal_stages_updated_at BEFORE UPDATE ON deal_stages
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE deal_stages IS
  'Deal pipeline stages per tenant. Distinct from pipeline_stages, which '
  'stages lead_assignments in the lead engine.';


-- ---------------------------------------------------------------------------
-- 4. deals — opportunities
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS deals (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id            uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  company_id           uuid REFERENCES companies(id) ON DELETE CASCADE,
  primary_contact_id   uuid REFERENCES contacts(id) ON DELETE SET NULL,
  title                text NOT NULL,
  description          text,
  value                numeric(14,2),
  currency             text NOT NULL DEFAULT 'USD',
  stage_id             uuid REFERENCES deal_stages(id) ON DELETE SET NULL,
  probability          int CHECK (probability IS NULL OR probability BETWEEN 0 AND 100),
  expected_close_date  date,
  actual_close_date    date,
  status               text NOT NULL DEFAULT 'open'
                         CHECK (status IN ('open','won','lost')),
  lost_reason          text,
  owner                text,
  source               text,
  source_assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  tags                 text[] NOT NULL DEFAULT '{}',
  custom_fields        jsonb  NOT NULL DEFAULT '{}',
  created_by           uuid,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS company_id uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS primary_contact_id uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS value numeric(14,2);
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS currency text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS stage_id uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS probability int;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS expected_close_date date;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS actual_close_date date;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS lost_reason text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS owner text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS source_assignment_id uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS tags text[];
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS custom_fields jsonb;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.deals ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_deals_tenant_status
  ON deals (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_stage
  ON deals (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_deals_company
  ON deals (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_contact
  ON deals (primary_contact_id) WHERE primary_contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_tenant_owner
  ON deals (tenant_id, owner) WHERE owner IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_deals_expected_close
  ON deals (tenant_id, expected_close_date) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_deals_tags
  ON deals USING gin (tags);
CREATE INDEX IF NOT EXISTS idx_deals_source_assignment
  ON deals (source_assignment_id) WHERE source_assignment_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_deals_updated_at ON deals;
CREATE TRIGGER trg_deals_updated_at BEFORE UPDATE ON deals
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE deals IS
  'Opportunities. source_assignment_id ties a deal back to the lead engine '
  'assignment it originated from, for closed-loop attribution.';


-- ---------------------------------------------------------------------------
-- 5. activities — unified polymorphic timeline
--
-- NEW TABLE, distinct from the existing lead_activities. Do not conflate:
--   lead_activities : keyed to a lead_assignment only; columns title/created_at.
--                     Written by /crm/{t}/leads/{a}/activities and kept as-is.
--   activities      : account/contact/deal grain; columns subject/occurred_at/
--                     direction/duration_minutes/outcome. Can ALSO reference an
--                     assignment_id, so a lead-era event can be carried forward
--                     onto the account timeline after conversion.
-- Both remain live. lead_activities is untouched by this migration.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activities (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  activity_type    text NOT NULL DEFAULT 'note'
                     CHECK (activity_type IN
                       ('call','email','meeting','note','task','stage_change','system')),
  subject          text,
  body             text,
  direction        text CHECK (direction IS NULL OR direction IN ('inbound','outbound')),
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  duration_minutes int,
  outcome          text,
  company_id       uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id       uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id          uuid REFERENCES deals(id) ON DELETE CASCADE,
  assignment_id    uuid REFERENCES lead_assignments(id) ON DELETE CASCADE,
  created_by       uuid,
  meta             jsonb NOT NULL DEFAULT '{}',
  created_at       timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS activity_type text;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS body text;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS direction text;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS occurred_at timestamptz;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS duration_minutes int;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS outcome text;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS company_id uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS contact_id uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.activities ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Compatibility hardening: an earlier LeadX CRM migration could have created
-- public.activities without the newer timeline columns. CREATE TABLE IF NOT
-- EXISTS does not reconcile an already-existing table, so explicitly add the
-- columns required by this migration before creating indexes/inserting rows.
ALTER TABLE IF EXISTS public.activities
  ADD COLUMN IF NOT EXISTS occurred_at timestamptz DEFAULT now(),
  ADD COLUMN IF NOT EXISTS subject text,
  ADD COLUMN IF NOT EXISTS body text,
  ADD COLUMN IF NOT EXISTS direction text,
  ADD COLUMN IF NOT EXISTS duration_minutes integer,
  ADD COLUMN IF NOT EXISTS outcome text,
  ADD COLUMN IF NOT EXISTS company_id uuid,
  ADD COLUMN IF NOT EXISTS contact_id uuid,
  ADD COLUMN IF NOT EXISTS deal_id uuid,
  ADD COLUMN IF NOT EXISTS assignment_id uuid,
  ADD COLUMN IF NOT EXISTS created_by uuid,
  ADD COLUMN IF NOT EXISTS meta jsonb DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

-- Primary timeline query
CREATE INDEX IF NOT EXISTS idx_activities_tenant_occurred
  ON activities (tenant_id, occurred_at DESC);
-- Per-entity timelines
CREATE INDEX IF NOT EXISTS idx_activities_company
  ON activities (company_id, occurred_at DESC) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_contact
  ON activities (contact_id, occurred_at DESC) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_deal
  ON activities (deal_id, occurred_at DESC) WHERE deal_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_assignment
  ON activities (assignment_id, occurred_at DESC) WHERE assignment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_activities_tenant_type
  ON activities (tenant_id, activity_type, occurred_at DESC);

COMMENT ON TABLE activities IS
  'Unified CRM timeline across companies/contacts/deals (and optionally a lead '
  'assignment). NEW and separate from lead_activities, which stays the lead-'
  'assignment-only timeline with its own title/created_at columns.';


-- ---------------------------------------------------------------------------
-- 6. tasks — CRM to-dos (distinct from lead_tasks, which is assignment-scoped)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  title         text NOT NULL,
  description   text,
  due_at        timestamptz,
  completed_at  timestamptz,
  status        text NOT NULL DEFAULT 'open'
                  CHECK (status IN ('open','done','cancelled')),
  priority      text NOT NULL DEFAULT 'medium'
                  CHECK (priority IN ('low','medium','high','urgent')),
  assigned_to   text,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id    uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id       uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS due_at timestamptz;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS priority text;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS assigned_to text;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS company_id uuid;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS contact_id uuid;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.tasks ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_tasks_tenant_status_due
  ON tasks (tenant_id, status, due_at);
CREATE INDEX IF NOT EXISTS idx_tasks_tenant_assigned
  ON tasks (tenant_id, assigned_to) WHERE status = 'open';
CREATE INDEX IF NOT EXISTS idx_tasks_company
  ON tasks (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tasks_contact
  ON tasks (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_tasks_deal
  ON tasks (deal_id) WHERE deal_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_tasks_updated_at ON tasks;
CREATE TRIGGER trg_tasks_updated_at BEFORE UPDATE ON tasks
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE tasks IS
  'CRM tasks against companies/contacts/deals. Separate from lead_tasks, '
  'which is scoped to a lead_assignment.';


-- ---------------------------------------------------------------------------
-- 7. notes
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  body          text NOT NULL,
  company_id    uuid REFERENCES companies(id) ON DELETE CASCADE,
  contact_id    uuid REFERENCES contacts(id) ON DELETE CASCADE,
  deal_id       uuid REFERENCES deals(id) ON DELETE CASCADE,
  created_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS body text;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS company_id uuid;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS contact_id uuid;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.notes ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_notes_tenant_created
  ON notes (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_company
  ON notes (company_id) WHERE company_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notes_contact
  ON notes (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_notes_deal
  ON notes (deal_id) WHERE deal_id IS NOT NULL;

DROP TRIGGER IF EXISTS trg_notes_updated_at ON notes;
CREATE TRIGGER trg_notes_updated_at BEFORE UPDATE ON notes
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();


-- ---------------------------------------------------------------------------
-- 8. custom_field_defs — schema for the custom_fields jsonb on each entity
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS custom_field_defs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  entity_type   text NOT NULL CHECK (entity_type IN ('company','contact','deal')),
  field_key     text NOT NULL,
  label         text NOT NULL,
  field_type    text NOT NULL DEFAULT 'text'
                  CHECK (field_type IN ('text','number','date','select','bool')),
  options       jsonb NOT NULL DEFAULT '[]',
-- choices when field_type = 'select'
  position      int   NOT NULL DEFAULT 0,
  required      boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, entity_type, field_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS field_key text;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS label text;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS field_type text;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS options jsonb;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS position int;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS required boolean;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.custom_field_defs ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_custom_field_defs_tenant_entity
  ON custom_field_defs (tenant_id, entity_type, position);

DROP TRIGGER IF EXISTS trg_custom_field_defs_updated_at ON custom_field_defs;
CREATE TRIGGER trg_custom_field_defs_updated_at BEFORE UPDATE ON custom_field_defs
  FOR EACH ROW EXECUTE FUNCTION public.crm_set_updated_at();

COMMENT ON TABLE custom_field_defs IS
  'Declares the keys allowed in companies/contacts/deals.custom_fields jsonb, '
  'and how the UI should render them.';


-- ---------------------------------------------------------------------------
-- 9. email_log
--
-- Complements email_sends (sql/014), which is the lead-engine outreach ledger
-- keyed by assignment/lead. email_log is the CRM-side record keyed by
-- contact/deal. Both are kept; neither is modified.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS email_log (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  to_email            text NOT NULL,
  from_email          text,
  subject             text,
  body_preview        text,
  status              text NOT NULL DEFAULT 'queued'
                        CHECK (status IN ('queued','sent','failed','bounced','opened','replied')),
  provider            text,
  provider_message_id text,
  error               text,
  contact_id          uuid REFERENCES contacts(id) ON DELETE SET NULL,
  deal_id             uuid REFERENCES deals(id) ON DELETE SET NULL,
  assignment_id       uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  sent_at             timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS to_email text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS from_email text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS body_preview text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS provider_message_id text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS contact_id uuid;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS sent_at timestamptz;
ALTER TABLE IF EXISTS public.email_log ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_email_log_tenant_sent
  ON email_log (tenant_id, sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_log_tenant_status
  ON email_log (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_email_log_contact
  ON email_log (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_deal
  ON email_log (deal_id) WHERE deal_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_assignment
  ON email_log (assignment_id) WHERE assignment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_email_log_provider_msg
  ON email_log (provider_message_id) WHERE provider_message_id IS NOT NULL;


-- ---------------------------------------------------------------------------
-- 10. call_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS call_log (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id       uuid REFERENCES contacts(id) ON DELETE SET NULL,
  deal_id          uuid REFERENCES deals(id) ON DELETE SET NULL,
  assignment_id    uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  direction        text CHECK (direction IS NULL OR direction IN ('inbound','outbound')),
  duration_minutes int,
  outcome          text,
  notes            text,
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  created_by       uuid,
  created_at       timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS contact_id uuid;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS direction text;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS duration_minutes int;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS outcome text;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS occurred_at timestamptz;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.call_log ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Compatibility hardening for legacy call_log definitions.
ALTER TABLE IF EXISTS public.call_log
  ADD COLUMN IF NOT EXISTS occurred_at timestamptz DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_call_log_tenant_occurred
  ON call_log (tenant_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_log_contact
  ON call_log (contact_id) WHERE contact_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_call_log_deal
  ON call_log (deal_id) WHERE deal_id IS NOT NULL;

-- =============================================================================
-- Row-Level Security
--
-- Exact pattern from sql/004_rls_and_auth.sql: membership is gated through
-- tenant_members via public.is_tenant_member() / public.is_tenant_admin().
-- Service role bypasses RLS (that is how the backend pipeline writes).
-- Every policy is dropped before create so this file is re-runnable.
--
-- Reads + writes are member-scoped; DELETE is admin-only on the four
-- durable record types (companies, contacts, deals, deal_stages) and on
-- custom_field_defs, matching how 004 restricts assignments_delete.
-- =============================================================================

DO $$ BEGIN
  IF to_regclass('public.companies') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE companies ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.contacts') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE contacts ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.deal_stages') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE deal_stages ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.deals') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE deals ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.activities') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE activities ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.tasks') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE tasks ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.notes') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE notes ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.custom_field_defs') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE custom_field_defs ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.email_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE email_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;
DO $$ BEGIN
  IF to_regclass('public.call_log') IS NOT NULL THEN
    EXECUTE 'ALTER TABLE call_log ENABLE ROW LEVEL SECURITY';
  END IF;
END $$;

-- companies
DROP POLICY IF EXISTS companies_select ON companies;
CREATE POLICY companies_select ON companies FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_insert ON companies;
CREATE POLICY companies_insert ON companies FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_update ON companies;
CREATE POLICY companies_update ON companies FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS companies_delete ON companies;
CREATE POLICY companies_delete ON companies FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- contacts
DROP POLICY IF EXISTS contacts_select ON contacts;
CREATE POLICY contacts_select ON contacts FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_insert ON contacts;
CREATE POLICY contacts_insert ON contacts FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_update ON contacts;
CREATE POLICY contacts_update ON contacts FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS contacts_delete ON contacts;
CREATE POLICY contacts_delete ON contacts FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- deal_stages: everyone reads, admins reshape the pipeline
DROP POLICY IF EXISTS deal_stages_select ON deal_stages;
CREATE POLICY deal_stages_select ON deal_stages FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deal_stages_write ON deal_stages;
CREATE POLICY deal_stages_write ON deal_stages FOR ALL
  USING (public.is_tenant_admin(tenant_id))
  WITH CHECK (public.is_tenant_admin(tenant_id));

-- deals
DROP POLICY IF EXISTS deals_select ON deals;
CREATE POLICY deals_select ON deals FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_insert ON deals;
CREATE POLICY deals_insert ON deals FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_update ON deals;
CREATE POLICY deals_update ON deals FOR UPDATE
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS deals_delete ON deals;
CREATE POLICY deals_delete ON deals FOR DELETE
  USING (public.is_tenant_admin(tenant_id));

-- activities / tasks / notes: full member access (matches 004's *_all pattern)
DROP POLICY IF EXISTS activities_all ON activities;
CREATE POLICY activities_all ON activities FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS crm_tasks_all ON tasks;
CREATE POLICY crm_tasks_all ON tasks FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS notes_all ON notes;
CREATE POLICY notes_all ON notes FOR ALL
  USING (public.is_tenant_member(tenant_id))
  WITH CHECK (public.is_tenant_member(tenant_id));

-- custom_field_defs: members read the schema, admins change it
DROP POLICY IF EXISTS custom_field_defs_select ON custom_field_defs;
CREATE POLICY custom_field_defs_select ON custom_field_defs FOR SELECT
  USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS custom_field_defs_write ON custom_field_defs;
CREATE POLICY custom_field_defs_write ON custom_field_defs FOR ALL
  USING (public.is_tenant_admin(tenant_id))
  WITH CHECK (public.is_tenant_admin(tenant_id));

-- email_log / call_log: read-only to members; writes come from the backend
-- (service role) so no INSERT policy is granted to authenticated clients.
DROP POLICY IF EXISTS email_log_select ON email_log;
CREATE POLICY email_log_select ON email_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));

DROP POLICY IF EXISTS call_log_select ON call_log;
CREATE POLICY call_log_select ON call_log FOR SELECT
  USING (public.is_tenant_member(tenant_id));
-- Manual call logging from the UI is a member action, so allow inserts there.
DROP POLICY IF EXISTS call_log_insert ON call_log;
CREATE POLICY call_log_insert ON call_log FOR INSERT
  WITH CHECK (public.is_tenant_member(tenant_id));


-- =============================================================================
-- Tags: decision recorded
--
-- Tags in this schema are the `tags text[]` columns on companies, contacts and
-- deals, GIN-indexed for `@>` / Supabase `.contains()` lookups. This matches
-- the pattern already used by lead_assignments.tags (sql/015) and keeps
-- filtering to a single index-backed predicate with no join.
--
-- Consequences accepted: no rename-in-one-place, no per-tag colour or usage
-- count. If those become requirements, add tags + taggings later and backfill
-- from these arrays — do NOT run both models at once.
--
-- The existing lead_tags table is a different thing (one row per tag per lead
-- ASSIGNMENT, in the lead engine) and is left untouched.
-- =============================================================================

COMMENT ON COLUMN companies.tags IS 'Free-form tags; GIN-indexed. Canonical tag store for this entity — there is no separate tags table.';
COMMENT ON COLUMN contacts.tags  IS 'Free-form tags; GIN-indexed.';
COMMENT ON COLUMN deals.tags     IS 'Free-form tags; GIN-indexed.';


-- ##### 017_crm_seed.sql #####

-- =============================================================================
-- 017 — CRM demo seed
--
-- Gives a fresh install a populated UI instead of empty states: one demo
-- tenant on a fixed well-known UUID, its lead pipeline stages, its deal
-- stages, and a handful of companies / contacts / deals / activities /
-- tasks / notes.
--
-- Safe to run repeatedly: every INSERT is either ON CONFLICT DO NOTHING on a
-- real unique constraint, or guarded by NOT EXISTS. Re-running changes nothing.
--
-- Run AFTER sql/015_crm_missing_objects.sql and sql/016_crm_full.sql.
--
-- The demo tenant UUID is deterministic so the frontend, tests and fixtures
-- can hardcode it:
--     00000000-0000-0000-0000-00000000d300   ("demo")
-- Delete the tenant to remove everything below — all seeded rows cascade.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. Demo tenant
-- ---------------------------------------------------------------------------
INSERT INTO tenants (id, name, slug, plan, leads_per_month_limit, delivery_channel, status)
VALUES (
  '00000000-0000-0000-0000-00000000d300',
  'Demo Agency',
  'demo-agency',
  'growth',
  500,
  'portal',
  'active'
)
ON CONFLICT (id) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 2. Lead pipeline stages (lead engine) — reuse the function from 015 so the
--    demo tenant gets exactly the same pipeline a real tenant gets.
-- ---------------------------------------------------------------------------
SELECT public.seed_default_stages('00000000-0000-0000-0000-00000000d300'::uuid);


-- ---------------------------------------------------------------------------
-- 3. Deal stages (CRM) — UNIQUE (tenant_id, slug) makes this idempotent
-- ---------------------------------------------------------------------------
INSERT INTO deal_stages (tenant_id, name, slug, position, color, probability, is_won, is_lost)
VALUES
  ('00000000-0000-0000-0000-00000000d300', 'Discovery',   'discovery',   1, '#94a3b8',  10, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Qualified',   'qualified',   2, '#3b82f6',  25, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Proposal',    'proposal',    3, '#8b5cf6',  50, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Negotiation', 'negotiation', 4, '#f59e0b',  75, false, false),
  ('00000000-0000-0000-0000-00000000d300', 'Closed Won',  'closed-won',  5, '#22c55e', 100, true,  false),
  ('00000000-0000-0000-0000-00000000d300', 'Closed Lost', 'closed-lost', 6, '#ef4444',   0, false, true)
ON CONFLICT (tenant_id, slug) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 4. Custom field definitions
-- ---------------------------------------------------------------------------
INSERT INTO custom_field_defs (tenant_id, entity_type, field_key, label, field_type, options, position, required)
VALUES
  ('00000000-0000-0000-0000-00000000d300', 'company', 'locations',      'Locations',        'number', '[]', 1, false),
  ('00000000-0000-0000-0000-00000000d300', 'company', 'booking_system', 'Booking System',   'select',
     '["Mindbody","Square","Vagaro","Boulevard","None"]', 2, false),
  ('00000000-0000-0000-0000-00000000d300', 'contact', 'best_time',      'Best Time to Call','select',
     '["Morning","Afternoon","Evening"]', 1, false),
  ('00000000-0000-0000-0000-00000000d300', 'deal',    'contract_months','Contract (months)','number', '[]', 1, false)
ON CONFLICT (tenant_id, entity_type, field_key) DO NOTHING;


-- ---------------------------------------------------------------------------
-- 5. Companies
--
-- Idempotent via idx_companies_tenant_domain — the partial unique index on
-- (tenant_id, lower(domain)). ON CONFLICT cannot name a partial index
-- directly, so each row is guarded with NOT EXISTS instead. Fixed UUIDs let
-- the contacts/deals below reference them without a lookup.
-- ---------------------------------------------------------------------------
INSERT INTO companies (
  id, tenant_id, name, domain, website, phone, address, city, state, country,
  industry, employee_count, annual_revenue, description, owner, status, tags, custom_fields
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Lumen Medspa', 'lumenmedspa.com', 'https://lumenmedspa.com', '2015550142',
   '412 Washington St', 'Hoboken', 'NJ', 'US',
   'medspa', 14, 1850000.00,
   'Three-location medspa group. Injectables and laser. Actively hiring.',
   'sales@demo-agency.test', 'customer',
   ARRAY['medspa','multi-location','priority'], '{"locations": 3, "booking_system": "Boulevard"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Ironline Fitness', 'ironlinefit.com', 'https://ironlinefit.com', '2015550188',
   '77 Hudson Pl', 'Jersey City', 'NJ', 'US',
   'gym', 22, 2400000.00,
   'Strength-focused gym. No online booking — strong automation fit.',
   'sales@demo-agency.test', 'prospect',
   ARRAY['gym','inbound'], '{"locations": 1, "booking_system": "None"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Bright Smile Dental', 'brightsmiledental.com', 'https://brightsmiledental.com', '2015550204',
   '1200 Bloomfield St', 'Hoboken', 'NJ', 'US',
   'dental', 9, 1200000.00,
   'Family dental practice. Two chairs idle midweek.',
   'ae2@demo-agency.test', 'prospect',
   ARRAY['dental'], '{"locations": 1, "booking_system": "Square"}'::jsonb),

  ('00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Coastal Hair Studio', 'coastalhairstudio.com', 'https://coastalhairstudio.com', '2015550311',
   '58 Newark St', 'Hoboken', 'NJ', 'US',
   'salon', 6, 480000.00,
   'Boutique salon. Owner-operated, books by phone only.',
   'ae2@demo-agency.test', 'active',
   ARRAY['salon','small'], '{"locations": 1}'::jsonb),

  ('00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Verity Legal Group', 'veritylegal.com', 'https://veritylegal.com', '2015550377',
   '30 Montgomery St', 'Jersey City', 'NJ', 'US',
   'legal', 31, 5600000.00,
   'Mid-size firm. Intake handled by an answering service today.',
   'sales@demo-agency.test', 'churned',
   ARRAY['legal','enterprise'], '{}'::jsonb)
) AS v(id, tenant_id, name, domain, website, phone, address, city, state, country,
       industry, employee_count, annual_revenue, description, owner, status, tags, custom_fields)
WHERE NOT EXISTS (SELECT 1 FROM companies c WHERE c.id = v.id);

-- ---------------------------------------------------------------------------
-- 6. Contacts
--
-- Note idx_contacts_one_primary: at most one is_primary contact per company
-- so the second contact at Lumen is deliberately not primary.
-- ---------------------------------------------------------------------------
INSERT INTO contacts (
  id, tenant_id, company_id, full_name, first_name, last_name, title,
  email, phone, mobile, linkedin_url, is_primary, is_decision_maker,
  owner, status, tags, custom_fields, do_not_contact
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   'Dana Reyes', 'Dana', 'Reyes', 'Owner',
   'dana@lumenmedspa.com', '2015550142', '2015550143',
   'https://www.linkedin.com/in/dana-reyes-demo', true, true,
   'sales@demo-agency.test', 'active', ARRAY['decision-maker'],
   '{"best_time": "Morning"}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   'Priya Shah', 'Priya', 'Shah', 'Operations Manager',
   'priya@lumenmedspa.com', '2015550144', NULL,
   NULL, false, false,
   'sales@demo-agency.test', 'active', ARRAY['influencer'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c002'::uuid,
   'Marcus Hale', 'Marcus', 'Hale', 'Founder',
   'marcus@ironlinefit.com', '2015550188', '2015550189',
   'https://www.linkedin.com/in/marcus-hale-demo', true, true,
   'sales@demo-agency.test', 'active', ARRAY['decision-maker','warm'],
   '{"best_time": "Evening"}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   'Dr. Alan Whitfield', 'Alan', 'Whitfield', 'Practice Owner',
   'alan@brightsmiledental.com', '2015550204', NULL,
   NULL, true, true,
   'ae2@demo-agency.test', 'active', ARRAY['decision-maker'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c004'::uuid,
   'Nina Alvarez', 'Nina', 'Alvarez', 'Owner / Stylist',
   'nina@coastalhairstudio.com', '2015550311', NULL,
   NULL, true, true,
   'ae2@demo-agency.test', 'active', ARRAY['decision-maker'], '{}'::jsonb, false),

  ('00000000-0000-0000-0000-00000000a006'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c005'::uuid,
   'Grant Okafor', 'Grant', 'Okafor', 'Managing Partner',
   'grant@veritylegal.com', '2015550377', NULL,
   NULL, true, true,
   'sales@demo-agency.test', 'unqualified', ARRAY['do-not-call'],
   '{}'::jsonb, true)
) AS v(id, tenant_id, company_id, full_name, first_name, last_name, title,
       email, phone, mobile, linkedin_url, is_primary, is_decision_maker,
       owner, status, tags, custom_fields, do_not_contact)
WHERE NOT EXISTS (SELECT 1 FROM contacts c WHERE c.id = v.id);


-- ---------------------------------------------------------------------------
-- 7. Deals — stage_id resolved by slug so this survives stage re-ordering
-- ---------------------------------------------------------------------------
INSERT INTO deals (
  id, tenant_id, company_id, primary_contact_id, title, description,
  value, currency, stage_id, probability, expected_close_date,
  actual_close_date, status, lost_reason, owner, source, tags, custom_fields
)
SELECT
  v.id, v.tenant_id, v.company_id, v.primary_contact_id, v.title, v.description,
  v.value, v.currency,
  (SELECT ds.id FROM deal_stages ds
    WHERE ds.tenant_id = v.tenant_id AND ds.slug = v.stage_slug),
  v.probability, v.expected_close_date, v.actual_close_date, v.status,
  v.lost_reason, v.owner, v.source, v.tags, v.custom_fields
FROM (VALUES
  ('00000000-0000-0000-0000-0000000dd001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   'Lumen Medspa — 3-location automation rollout',
   'Booking automation plus reactivation campaign across all three locations.',
   36000.00, 'USD', 'negotiation', 75,
   (CURRENT_DATE + 21), NULL, 'open', NULL,
   'sales@demo-agency.test', 'referral',
   ARRAY['expansion'], '{"contract_months": 12}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   'Ironline Fitness — inbound booking build',
   'No online booking today. Replace phone-only intake.',
   14400.00, 'USD', 'proposal', 50,
   (CURRENT_DATE + 30), NULL, 'open', NULL,
   'sales@demo-agency.test', 'lead_engine',
   ARRAY['new-logo'], '{"contract_months": 6}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000a004'::uuid,
   'Bright Smile Dental — midweek fill campaign',
   'Fill idle midweek chair time with a recall campaign.',
   9600.00, 'USD', 'qualified', 25,
   (CURRENT_DATE + 45), NULL, 'open', NULL,
   'ae2@demo-agency.test', 'lead_engine',
   ARRAY['new-logo'], '{"contract_months": 6}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000a005'::uuid,
   'Coastal Hair Studio — starter retainer',
   'Single-location starter package. Signed after one call.',
   4800.00, 'USD', 'closed-won', 100,
   (CURRENT_DATE - 12), (CURRENT_DATE - 12), 'won', NULL,
   'ae2@demo-agency.test', 'referral',
   ARRAY['won'], '{"contract_months": 12}'::jsonb),

  ('00000000-0000-0000-0000-0000000dd005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   'Verity Legal Group — intake automation',
   'Lost to an incumbent answering service on price.',
   28000.00, 'USD', 'closed-lost', 0,
   (CURRENT_DATE - 30), (CURRENT_DATE - 25), 'lost', 'Price — incumbent undercut',
   'sales@demo-agency.test', 'outbound',
   ARRAY['lost'], '{}'::jsonb)
) AS v(id, tenant_id, company_id, primary_contact_id, title, description,
       value, currency, stage_slug, probability, expected_close_date,
       actual_close_date, status, lost_reason, owner, source, tags, custom_fields)
WHERE NOT EXISTS (SELECT 1 FROM deals d WHERE d.id = v.id);


-- ---------------------------------------------------------------------------
-- 8. Activities — the timeline the UI renders
-- ---------------------------------------------------------------------------
INSERT INTO activities (
  id, tenant_id, activity_type, subject, body, direction,
  occurred_at, duration_minutes, outcome, company_id, contact_id, deal_id, meta
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000a0001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'call', 'Discovery call — Dana Reyes',
   'Walked through the three-location booking gap. Wants a rollout plan.',
   'outbound', (now() - interval '9 days'), 28, 'connected',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'email', 'Sent proposal v2',
   'Revised pricing for 12 months across 3 locations.',
   'outbound', (now() - interval '4 days'), NULL, 'sent',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid, '{"attachment": "proposal-v2.pdf"}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'meeting', 'On-site demo at Ironline',
   'Demoed booking flow on the front-desk tablet.',
   'outbound', (now() - interval '6 days'), 45, 'positive',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'note', 'Budget cycle note', 'Dental budget resets next quarter — time the close.',
   NULL, (now() - interval '2 days'), NULL, NULL,
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000a004'::uuid,
   '00000000-0000-0000-0000-0000000dd003'::uuid, '{}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0005'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'stage_change', 'Moved to Closed Won', 'Contract signed, 12 months.',
   NULL, (now() - interval '12 days'), NULL, 'won',
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000a005'::uuid,
   '00000000-0000-0000-0000-0000000dd004'::uuid,
   '{"from": "negotiation", "to": "closed-won"}'::jsonb),

  ('00000000-0000-0000-0000-0000000a0006'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'call', 'Inbound — Verity Legal declined',
   'Chose to keep their answering service. Revisit in 6 months.',
   'inbound', (now() - interval '25 days'), 11, 'lost',
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   '00000000-0000-0000-0000-0000000dd005'::uuid, '{}'::jsonb)
) AS v(id, tenant_id, activity_type, subject, body, direction,
       occurred_at, duration_minutes, outcome, company_id, contact_id, deal_id, meta)
WHERE NOT EXISTS (SELECT 1 FROM activities a WHERE a.id = v.id);


-- ---------------------------------------------------------------------------
-- 9. Tasks
-- ---------------------------------------------------------------------------
INSERT INTO tasks (
  id, tenant_id, title, description, due_at, completed_at, status,
  priority, assigned_to, company_id, contact_id, deal_id
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-000000000001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Follow up on Lumen proposal v2',
   'Chase Dana for a decision on the 12-month term.',
   (now() + interval '1 day'), NULL, 'open', 'high',
   'sales@demo-agency.test',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid),

  ('00000000-0000-0000-0000-000000000002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Send Ironline the security questionnaire', NULL,
   (now() + interval '3 days'), NULL, 'open', 'medium',
   'sales@demo-agency.test',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid),

  ('00000000-0000-0000-0000-000000000003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Book Bright Smile technical review', NULL,
   (now() + interval '7 days'), NULL, 'open', 'low',
   'ae2@demo-agency.test',
   '00000000-0000-0000-0000-00000000c003'::uuid,
   '00000000-0000-0000-0000-00000000a004'::uuid,
   '00000000-0000-0000-0000-0000000dd003'::uuid),

  ('00000000-0000-0000-0000-000000000004'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Kick off Coastal Hair onboarding', 'Signed — hand to delivery.',
   (now() - interval '10 days'), (now() - interval '9 days'), 'done', 'high',
   'ae2@demo-agency.test',
   '00000000-0000-0000-0000-00000000c004'::uuid,
   '00000000-0000-0000-0000-00000000a005'::uuid,
   '00000000-0000-0000-0000-0000000dd004'::uuid)
) AS v(id, tenant_id, title, description, due_at, completed_at, status,
       priority, assigned_to, company_id, contact_id, deal_id)
WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.id = v.id);


-- ---------------------------------------------------------------------------
-- 10. Notes
-- ---------------------------------------------------------------------------
INSERT INTO notes (id, tenant_id, body, company_id, contact_id, deal_id)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-000000000001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Dana prefers morning calls. Priya handles scheduling day to day.',
   '00000000-0000-0000-0000-00000000c001'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   NULL::uuid),

  ('00000000-0000-0000-0000-000000000002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Marcus is price sensitive but moves fast once convinced.',
   '00000000-0000-0000-0000-00000000c002'::uuid,
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid),

  ('00000000-0000-0000-0000-000000000003'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'Verity: do not call — contact flagged do_not_contact. Email only, after Q3.',
   '00000000-0000-0000-0000-00000000c005'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   NULL::uuid)
) AS v(id, tenant_id, body, company_id, contact_id, deal_id)
WHERE NOT EXISTS (SELECT 1 FROM notes n WHERE n.id = v.id);


-- ---------------------------------------------------------------------------
-- 11. Email + call logs
-- ---------------------------------------------------------------------------
INSERT INTO email_log (
  id, tenant_id, to_email, from_email, subject, body_preview,
  status, provider, provider_message_id, contact_id, deal_id, sent_at
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-0000000e0001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'dana@lumenmedspa.com', 'sales@demo-agency.test',
   'Revised proposal — Lumen Medspa',
   'Hi Dana, attached is v2 with the 12-month pricing we discussed...',
   'opened', 'resend', 'demo-msg-0001',
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid,
   (now() - interval '4 days')),

  ('00000000-0000-0000-0000-0000000e0002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   'marcus@ironlinefit.com', 'sales@demo-agency.test',
   'Recap + next steps',
   'Great meeting you both — here is the booking flow we demoed...',
   'replied', 'resend', 'demo-msg-0002',
   '00000000-0000-0000-0000-00000000a003'::uuid,
   '00000000-0000-0000-0000-0000000dd002'::uuid,
   (now() - interval '5 days'))
) AS v(id, tenant_id, to_email, from_email, subject, body_preview,
       status, provider, provider_message_id, contact_id, deal_id, sent_at)
WHERE NOT EXISTS (SELECT 1 FROM email_log el WHERE el.id = v.id);

INSERT INTO call_log (
  id, tenant_id, contact_id, deal_id, direction,
  duration_minutes, outcome, notes, occurred_at
)
SELECT v.* FROM (VALUES
  ('00000000-0000-0000-0000-000000000001'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000a001'::uuid,
   '00000000-0000-0000-0000-0000000dd001'::uuid,
   'outbound', 28, 'connected',
   'Discovery. Confirmed budget owner is Dana.',
   (now() - interval '9 days')),

  ('00000000-0000-0000-0000-000000000002'::uuid,
   '00000000-0000-0000-0000-00000000d300'::uuid,
   '00000000-0000-0000-0000-00000000a006'::uuid,
   '00000000-0000-0000-0000-0000000dd005'::uuid,
   'inbound', 11, 'lost',
   'Declined. Revisit in 6 months.',
   (now() - interval '25 days'))
) AS v(id, tenant_id, contact_id, deal_id, direction,
       duration_minutes, outcome, notes, occurred_at)
WHERE NOT EXISTS (SELECT 1 FROM call_log cl WHERE cl.id = v.id);


-- ---------------------------------------------------------------------------
-- Done. To wipe the demo data entirely (everything above cascades):
--   DELETE FROM tenants WHERE id = '00000000-0000-0000-0000-00000000d300';
--
-- NOTE: no tenant_members row is seeded, because membership must bind to a
-- real Supabase auth.users id. To log into the demo tenant, create the auth
-- user first, then:
--   INSERT INTO tenant_members (tenant_id, auth_user_id, email, role, status)
--   VALUES ('00000000-0000-0000-0000-00000000d300', '<auth uid>'
--           '<email>', 'owner', 'active')
--   ON CONFLICT (tenant_id, auth_user_id) DO NOTHING;
-- Until then the seeded rows are only visible to the service role, since RLS
-- gates every table on tenant_members.
-- ---------------------------------------------------------------------------


-- ##### lead-crm-portal/sql/003_crm_portal_schema.sql #####

-- =============================================================================
-- Client CRM Portal — extends Lead Engine v2
-- Pipeline stages, activities, notes, tasks, tags, team, audit
-- =============================================================================

-- Pipeline stages (per tenant, customizable)
CREATE TABLE IF NOT EXISTS pipeline_stages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
-- New, Contacted, Qualified, Proposal, Won, Lost
  slug        text NOT NULL,
-- new, contacted, qualified, proposal, won, lost
  position    int  NOT NULL DEFAULT 0,
  color       text NOT NULL DEFAULT '#6366f1',
  is_won      boolean NOT NULL DEFAULT false,
  is_lost     boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, slug)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS slug text;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS position int;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS color text;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS is_won boolean;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS is_lost boolean;
ALTER TABLE IF EXISTS public.pipeline_stages ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_stages_tenant ON pipeline_stages (tenant_id, position);

-- Default stages helper already defined above as public.seed_default_stages RETURNS int.
-- Second void copy removed to avoid: cannot change return type of existing function.
-- DROP FUNCTION IF EXISTS public.seed_default_stages(uuid);  -- only if you need to recreate


-- Extend lead_assignments with CRM fields
ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS stage_id       uuid REFERENCES pipeline_stages(id),
  ADD COLUMN IF NOT EXISTS assigned_to    uuid,
-- team member user id
  ADD COLUMN IF NOT EXISTS priority       text DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','urgent')),
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_contacted_at timestamptz,
  ADD COLUMN IF NOT EXISTS value_estimate numeric(12,2),
  ADD COLUMN IF NOT EXISTS source_campaign text,
  ADD COLUMN IF NOT EXISTS custom_fields  jsonb DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS tags           text[] DEFAULT '{}';

CREATE INDEX IF NOT EXISTS idx_assignments_stage ON lead_assignments (tenant_id, stage_id);
CREATE INDEX IF NOT EXISTS idx_assignments_assignee ON lead_assignments (tenant_id, assigned_to);
CREATE INDEX IF NOT EXISTS idx_assignments_next_action ON lead_assignments (tenant_id, next_action_at)
  WHERE next_action_at IS NOT NULL;

-- Activities (calls, emails, notes, status changes, system events)
CREATE TABLE IF NOT EXISTS lead_activities (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  actor_id      uuid,
-- team member who did it (null = system)
  activity_type text NOT NULL CHECK (activity_type IN (
    'note','call','email','sms','meeting','stage_change','status_change',
    'task_created','task_completed','enrichment','system','other'
  )),
  title         text,
  body          text,
  meta          jsonb DEFAULT '{}',
-- duration, outcome, from_stage, to_stage, etc.
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS actor_id uuid;
-- team member who did it (null = system);
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS activity_type text;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS body text;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.lead_activities ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_activities_assignment ON lead_activities (assignment_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activities_tenant ON lead_activities (tenant_id, created_at DESC);

-- Tasks / follow-ups
CREATE TABLE IF NOT EXISTS lead_tasks (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE,
  lead_id       uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assigned_to   uuid,
  created_by    uuid,
  title         text NOT NULL,
  description   text,
  due_at        timestamptz,
  completed_at  timestamptz,
  status        text NOT NULL DEFAULT 'open'
    CHECK (status IN ('open','done','cancelled')),
  priority      text NOT NULL DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','urgent')),
  created_at    timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS assigned_to uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS due_at timestamptz;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS priority text;
ALTER TABLE IF EXISTS public.lead_tasks ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_tasks_open ON lead_tasks (tenant_id, status, due_at)
  WHERE status = 'open';

-- Tags dictionary (per tenant)
CREATE TABLE IF NOT EXISTS lead_tags (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id  uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name       text NOT NULL,
  color      text DEFAULT '#64748b',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS color text;
ALTER TABLE IF EXISTS public.lead_tags ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Team members (portal users for a tenant)
CREATE TABLE IF NOT EXISTS tenant_members (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email       text NOT NULL,
  full_name   text,
  role        text NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner','admin','member','viewer')),
  auth_user_id uuid,
-- Supabase auth.users id
  avatar_url  text,
  last_login_at timestamptz,
  status      text NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','invited','disabled')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, email)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS role text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
-- Supabase auth.users id;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS avatar_url text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tenant_members ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_members_tenant ON tenant_members (tenant_id, status);

-- Saved filters / segments
CREATE TABLE IF NOT EXISTS lead_segments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        text NOT NULL,
  filters     jsonb NOT NULL DEFAULT '{}',
-- { tier: ['A'], stage: ['qualified'], tags: [...] }
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS filters jsonb;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE IF EXISTS public.lead_segments ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Audit log
--
-- REMOVED: a second `CREATE TABLE IF NOT EXISTS crm_audit_log` used to live
-- here with a *different* shape (entity_type / before / after / ip) than the
-- authoritative definition further up this file (entity / entity_id / meta).
-- Because both used IF NOT EXISTS, the earlier one always won and this block
-- was a silent no-op — anything written against these columns would have
-- failed at runtime. Kept as a comment so the mismatch isn't reintroduced.
--
-- Current audit writes go to the `audit_log` table created by HARDENING.SQL
-- (see app/integrations/prod/audit_log.py). `crm_audit_log` has no writers.

CREATE INDEX IF NOT EXISTS idx_audit_tenant ON crm_audit_log (tenant_id, created_at DESC);

-- Client portal sessions helper view: assignment + lead + enrichment + score + stage
DROP VIEW IF EXISTS crm_lead_cards CASCADE;
CREATE OR REPLACE VIEW crm_lead_cards AS
SELECT
  la.id AS assignment_id,
  la.tenant_id,
  la.lead_id,
  la.status AS assignment_status,
  la.delivery_status,
  la.delivered_at,
  la.priority,
  la.next_action_at,
  la.last_contacted_at,
  la.value_estimate,
  la.tags,
  la.custom_fields,
  la.assigned_to,
  la.stage_id,
  ps.name AS stage_name,
  ps.slug AS stage_slug,
  ps.color AS stage_color,
  ps.position AS stage_position,
  lg.name AS company_name,
  lg.phone_normalized,
  lg.phone_e164,
  lg.website,
  lg.address,
  lg.city,
  lg.state,
  lg.business_status,
  lg.google_rating,
  lg.review_count,
  lg.category,
  e.email,
  e.email_valid,
  e.has_booking,
  e.booking_platform,
  e.services,
  e.social_links,
  e.owner_name,
  e.enrichment_ok,
  s.total_score,
  s.tier,
  s.reasoning AS score_reasoning
FROM lead_assignments la
JOIN leads_global lg ON lg.id = la.lead_id
LEFT JOIN enrichment e ON e.lead_id = lg.id
LEFT JOIN scores s ON s.lead_id = lg.id
LEFT JOIN pipeline_stages ps ON ps.id = la.stage_id;


-- ##### FINAL ensure pipeline_run_leads (run board) #####
CREATE TABLE IF NOT EXISTS public.pipeline_run_leads (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references public.pipeline_runs(id) on delete cascade,
  lead_id uuid not null references public.leads_global(id) on delete cascade,
  tenant_id uuid references public.tenants(id) on delete set null,
  stage text not null default 'discovered',
  tier text,
  included boolean not null default true,
  score int,
  source text,
  name text,
  phone text,
  website text,
  city text,
  position int default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (run_id, lead_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS run_id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS stage text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS included boolean;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS score int;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS position int;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.pipeline_run_leads ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_prl_run ON public.pipeline_run_leads(run_id);
CREATE INDEX IF NOT EXISTS idx_prl_tenant ON public.pipeline_run_leads(tenant_id);
CREATE INDEX IF NOT EXISTS idx_prl_stage ON public.pipeline_run_leads(run_id, stage);
-- Allow LinkedIn li_at cookies (and related providers) in api_key_pool
-- Error fixed: violates check constraint "api_key_pool_provider_check"

ALTER TABLE public.api_key_pool
  DROP CONSTRAINT IF EXISTS api_key_pool_provider_check;

ALTER TABLE public.api_key_pool
  ADD CONSTRAINT api_key_pool_provider_check
  CHECK (provider IN (
    'serper',
    'firecrawl',
    'anthropic',
    'gemini',
    'groq',
    'openai',
    'resend',
    'linkedin_scraper',
    'linkedin',
    'instagram',
    'twilio',
    'vapi',
    'scrapingbee',
    'bright_data'
  ));

-- ##### FIX delivery_status + tenant_members columns (idempotent) #####
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS role text DEFAULT 'member';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';

DO $$ BEGIN
  ALTER TABLE public.lead_assignments DROP CONSTRAINT IF EXISTS lead_assignments_delivery_status_check;
EXCEPTION WHEN undefined_object THEN NULL;
END $$;
DO $$ BEGIN
  ALTER TABLE public.lead_assignments
    ADD CONSTRAINT lead_assignments_delivery_status_check
    CHECK (delivery_status IN ('pending','sent','failed','skipped','portal','delivered'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

-- Normalize any bad values
UPDATE public.lead_assignments
SET delivery_status = 'sent'
WHERE delivery_status IS NULL OR delivery_status NOT IN ('pending','sent','failed','skipped','portal','delivered');

NOTIFY pgrst, 'reload schema';


-- ============================================================
-- FINAL: Multi-user / team CRM / LinkedIn pool (idempotent)
-- From FIX_MULTIUSER_TEAM_SOCIAL.sql — tables already exist above
-- ============================================================

-- LeadX: multi-user + team CRM + LinkedIn key pool (safe to re-run)

-- tenant_members columns used by portal login + invites
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS avatar_url text;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS role text DEFAULT 'member';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS status text DEFAULT 'active';
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE public.tenant_members ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS uq_tenant_members_tenant_email
  ON public.tenant_members (tenant_id, email)
  WHERE email IS NOT NULL AND email <> '';

CREATE INDEX IF NOT EXISTS idx_tenant_members_auth
  ON public.tenant_members (auth_user_id)
  WHERE auth_user_id IS NOT NULL;

-- Invites table for team CRM
CREATE TABLE IF NOT EXISTS public.tenant_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'member',
  token text NOT NULL UNIQUE,
  invited_by text,
  status text NOT NULL DEFAULT 'pending',
  expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  accepted_at timestamptz
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS role text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS token text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS invited_by text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS expires_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_invites ADD COLUMN IF NOT EXISTS accepted_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_tenant_invites_token ON public.tenant_invites(token);
CREATE INDEX IF NOT EXISTS idx_tenant_invites_tenant ON public.tenant_invites(tenant_id);

-- api_key_pool providers including linkedin / instagram
ALTER TABLE public.api_key_pool DROP CONSTRAINT IF EXISTS api_key_pool_provider_check;
ALTER TABLE public.api_key_pool
  ADD CONSTRAINT api_key_pool_provider_check
  CHECK (provider IN (
    'serper','firecrawl','anthropic','gemini','groq','openai','resend',
    'linkedin_scraper','linkedin','instagram','twilio','vapi','brevo'
  ));

-- delivery_status allow portal/sent
ALTER TABLE public.lead_assignments DROP CONSTRAINT IF EXISTS lead_assignments_delivery_status_check;
ALTER TABLE public.lead_assignments
  ADD CONSTRAINT lead_assignments_delivery_status_check
  CHECK (delivery_status IS NULL OR delivery_status IN (
    'pending','sent','failed','skipped','portal','delivered'
  ));

ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS stage_id uuid;
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS stage_slug text;
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS tier text;

NOTIFY pgrst, 'reload schema';


-- email daily usage for cascade providers
CREATE TABLE IF NOT EXISTS public.email_provider_daily (
  day date NOT NULL,
  provider text NOT NULL,
  sent_count int NOT NULL DEFAULT 0,
  PRIMARY KEY (day, provider)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_provider_daily ADD COLUMN IF NOT EXISTS day date;
ALTER TABLE IF EXISTS public.email_provider_daily ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.email_provider_daily ADD COLUMN IF NOT EXISTS sent_count int;


NOTIFY pgrst, 'reload schema';

-- SES tenant email settings

-- Tenant email / SES domain (idempotent)
CREATE TABLE IF NOT EXISTS public.tenant_email_settings (
  tenant_id uuid PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'ses',
  from_name text,
  from_email text,
  reply_to text,
  domain text,
  domain_verified boolean NOT NULL DEFAULT false,
  dkim_status text,
  dns_records jsonb DEFAULT '[]'::jsonb,
  daily_limit int DEFAULT 500,
  status text DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS from_name text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS from_email text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS reply_to text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS domain_verified boolean;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS dkim_status text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS dns_records jsonb;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS daily_limit int;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.tenant_email_settings ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_tenant_email_domain
  ON public.tenant_email_settings(domain)
  WHERE domain IS NOT NULL;

NOTIFY pgrst, 'reload schema';

-- ============================================================
-- FINAL: SES-backed durable email sequences
-- Mirrors sql/027_SES_SEQUENCE_HARDENING.sql for fresh installs.
-- ============================================================
CREATE TABLE IF NOT EXISTS public.email_sequences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_sequences ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_sequences ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_sequences ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.email_sequences ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.email_sequences ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.email_sequences ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_email_sequences_tenant ON public.email_sequences(tenant_id, created_at DESC);
CREATE TABLE IF NOT EXISTS public.email_sequence_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sequence_id uuid NOT NULL REFERENCES public.email_sequences(id) ON DELETE CASCADE,
  step_number int NOT NULL CHECK (step_number > 0),
  delay_days int NOT NULL DEFAULT 0 CHECK (delay_days >= 0),
  subject text NOT NULL,
  body_html text NOT NULL,
  body_text text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(sequence_id, step_number)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS sequence_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS step_number int;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS delay_days int;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS body_html text;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE IF EXISTS public.email_sequence_steps ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_email_sequence_steps_sequence ON public.email_sequence_steps(sequence_id, step_number);
CREATE TABLE IF NOT EXISTS public.email_sequence_enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  sequence_id uuid NOT NULL REFERENCES public.email_sequences(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL,
  current_step int NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  next_send_at timestamptz,
  deferred_reason text,
  locked_at timestamptz,
  locked_by text,
  last_error text,
  last_provider_id text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(sequence_id, assignment_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS sequence_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS current_step int;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS next_send_at timestamptz;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS deferred_reason text;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS locked_at timestamptz;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS locked_by text;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS last_provider_id text;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS updated_at timestamptz;
ALTER TABLE IF EXISTS public.email_sequence_enrollments ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_email_sequence_due ON public.email_sequence_enrollments(status, next_send_at);
CREATE INDEX IF NOT EXISTS idx_email_sequence_tenant ON public.email_sequence_enrollments(tenant_id, status);
CREATE TABLE IF NOT EXISTS public.email_sequence_sends (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id uuid NOT NULL REFERENCES public.email_sequence_enrollments(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL,
  step_number int NOT NULL,
  idempotency_key text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'sending',
  provider text,
  provider_id text,
  to_email text,
  subject text,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  UNIQUE(enrollment_id, step_number)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS enrollment_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS step_number int;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS idempotency_key text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS provider_id text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS to_email text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.email_sequence_sends ADD COLUMN IF NOT EXISTS sent_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_email_sequence_sends_enrollment ON public.email_sequence_sends(enrollment_id, step_number);
CREATE INDEX IF NOT EXISTS idx_email_sequence_sends_provider_id ON public.email_sequence_sends(provider, provider_id);
CREATE TABLE IF NOT EXISTS public.email_bounces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  email text NOT NULL,
  event_type text NOT NULL,
  bounce_type text,
  sub_type text,
  diagnostic text,
  suppressed boolean NOT NULL DEFAULT false,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS event_type text;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS bounce_type text;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS sub_type text;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS diagnostic text;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS suppressed boolean;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS raw jsonb;
ALTER TABLE IF EXISTS public.email_bounces ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_email_bounces_email ON public.email_bounces(lower(email), created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_bounces_tenant ON public.email_bounces(tenant_id, created_at DESC);
CREATE TABLE IF NOT EXISTS public.email_domain_daily (
  day date NOT NULL,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  domain text NOT NULL,
  sent_count int NOT NULL DEFAULT 0,
  PRIMARY KEY(day, tenant_id, domain)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_domain_daily ADD COLUMN IF NOT EXISTS day date;
ALTER TABLE IF EXISTS public.email_domain_daily ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_domain_daily ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.email_domain_daily ADD COLUMN IF NOT EXISTS sent_count int;

CREATE TABLE IF NOT EXISTS public.domain_warmup (
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  domain text NOT NULL,
  started_on date NOT NULL DEFAULT current_date,
  start_cap int NOT NULL DEFAULT 20,
  full_cap int NOT NULL DEFAULT 500,
  ramp_days int NOT NULL DEFAULT 21,
  paused boolean NOT NULL DEFAULT false,
  PRIMARY KEY(tenant_id, domain)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS started_on date;
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS start_cap int;
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS full_cap int;
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS ramp_days int;
ALTER TABLE IF EXISTS public.domain_warmup ADD COLUMN IF NOT EXISTS paused boolean;

CREATE INDEX IF NOT EXISTS idx_email_sends_to_email ON public.email_sends(lower(to_email), created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_sends_assignment_created ON public.email_sends(assignment_id, created_at DESC);
NOTIFY pgrst, 'reload schema';


-- Legacy-plan data repair before enforcing the LeadX 15.2 plan contract.
-- LeadX 15.2 billing-plan contract repair. The 15.4 ordering fix keeps this historical contract upgrade-safe.
-- Drop the old CHECK FIRST: existing rows may contain premium/enterprise, and
-- replacing those values before dropping the old constraint makes upgrades fail.
DO $$
DECLARE c record;
BEGIN
  FOR c IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'public.tenants'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%plan%'
  LOOP
    EXECUTE format('ALTER TABLE public.tenants DROP CONSTRAINT IF EXISTS %I', c.conname);
  END LOOP;
END $$;
UPDATE public.tenants SET plan='agency' WHERE plan IN ('premium','enterprise');
ALTER TABLE public.tenants
  ADD CONSTRAINT tenants_plan_check
  CHECK (plan IN ('free','starter','growth','agency'));
ALTER TABLE public.tenants
  ALTER COLUMN plan SET DEFAULT 'free';

-- 028 discovery approval/global coverage
-- Discovery approvals, monthly reservations, and global source-coverage ledger.
-- The global coverage ledger is intentionally NOT tenant-scoped: discovery is a shared
-- LeadX data asset and should not repeat exhausted source/geo/query partitions per customer.

ALTER TABLE usage_log
  ADD COLUMN IF NOT EXISTS quota_reserved int NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS discovery_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  icp_id uuid REFERENCES icp_profiles(id) ON DELETE SET NULL,
  vertical text NOT NULL,
  locations jsonb NOT NULL DEFAULT '[]',
  keywords jsonb NOT NULL DEFAULT '[]',
  offer_category text,
  requested_leads int NOT NULL CHECK (requested_leads > 0),
  approved_leads int,
  status text NOT NULL DEFAULT 'pending_approval' CHECK (status IN ('pending_approval','approved','queued','running','completed','partially_completed','rejected','cancelled','failed')),
  admin_reason text,
  rejection_reason text,
  requested_by uuid,
  approved_by text,
  approved_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  pipeline_run_id uuid REFERENCES pipeline_runs(id) ON DELETE SET NULL,
  assigned_count int NOT NULL DEFAULT 0,
  discovered_count int NOT NULL DEFAULT 0,
  global_stored_count int NOT NULL DEFAULT 0,
  enriched_count int NOT NULL DEFAULT 0,
  exhausted_partitions int NOT NULL DEFAULT 0,
  total_partitions int NOT NULL DEFAULT 0,
  meta jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS vertical text;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS locations jsonb;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS keywords jsonb;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS offer_category text;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS requested_leads int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS approved_leads int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS admin_reason text;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS rejection_reason text;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS requested_by uuid;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS approved_by text;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS approved_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS pipeline_run_id uuid;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS assigned_count int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS discovered_count int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS global_stored_count int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS enriched_count int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS exhausted_partitions int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS total_partitions int;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_requests ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_discovery_requests_tenant_status ON discovery_requests(tenant_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_discovery_requests_status ON discovery_requests(status, created_at);
CREATE INDEX IF NOT EXISTS idx_discovery_requests_icp ON discovery_requests(icp_id, created_at DESC);

CREATE TABLE IF NOT EXISTS global_discovery_coverage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vertical_key text NOT NULL,
  source text NOT NULL,
  location_key text NOT NULL,
  query_key text NOT NULL DEFAULT '',
  page_reached int NOT NULL DEFAULT 0,
  raw_found int NOT NULL DEFAULT 0,
  unique_new_found int NOT NULL DEFAULT 0,
  runs int NOT NULL DEFAULT 0,
  exhausted boolean NOT NULL DEFAULT false,
  exhausted_at timestamptz,
  last_run_at timestamptz NOT NULL DEFAULT now(),
  last_error text,
  meta jsonb NOT NULL DEFAULT '{}',
  UNIQUE(vertical_key, source, location_key, query_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS vertical_key text;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS location_key text;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS query_key text;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS page_reached int;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS raw_found int;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS unique_new_found int;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS runs int;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS exhausted boolean;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS exhausted_at timestamptz;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE IF EXISTS public.global_discovery_coverage ADD COLUMN IF NOT EXISTS meta jsonb;

CREATE INDEX IF NOT EXISTS idx_global_coverage_frontier ON global_discovery_coverage(vertical_key, exhausted, last_run_at);
CREATE INDEX IF NOT EXISTS idx_global_coverage_location ON global_discovery_coverage(location_key, source, exhausted);

-- Reserve monthly quota at approval time. This is separate from actual delivered usage.
CREATE OR REPLACE FUNCTION public.reserve_tenant_discovery_quota(p_tenant_id uuid, p_requested int)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
  lim int;
  used int;
  reserved int;
  available int;
  granted int;
BEGIN
  IF p_requested IS NULL OR p_requested <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'granted', 0, 'reason', 'invalid_amount');
  END IF;
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id FOR UPDATE;
  IF lim IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'granted', 0, 'reason', 'tenant_not_found');
  END IF;
  INSERT INTO usage_log(tenant_id, period, leads_delivered, quota_reserved)
  VALUES(p_tenant_id, p, 0, 0)
  ON CONFLICT(tenant_id, period) DO NOTHING;
  SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0)
    INTO used, reserved
  FROM usage_log WHERE tenant_id=p_tenant_id AND period=p FOR UPDATE;
  available := GREATEST(lim - used - reserved, 0);
  granted := LEAST(p_requested, available);
  IF granted <= 0 THEN
    RETURN jsonb_build_object('ok', false, 'granted', 0, 'reason', 'quota_exhausted', 'limit', lim, 'used', used, 'reserved', reserved);
  END IF;
  UPDATE usage_log SET quota_reserved=quota_reserved+granted, updated_at=now()
   WHERE tenant_id=p_tenant_id AND period=p;
  RETURN jsonb_build_object('ok', true, 'granted', granted, 'limit', lim, 'used', used, 'reserved', reserved);
END;
$$;

-- Consume one approved request slot and one monthly reservation atomically.
CREATE OR REPLACE FUNCTION public.consume_tenant_discovery_slot(p_tenant_id uuid, p_request_id uuid, p_tier text DEFAULT 'A')
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
  req_reserved int;
BEGIN
  SELECT approved_leads - assigned_count INTO req_reserved
    FROM discovery_requests WHERE id=p_request_id AND tenant_id=p_tenant_id FOR UPDATE;
  IF COALESCE(req_reserved,0) <= 0 THEN RETURN false; END IF;
  UPDATE discovery_requests SET assigned_count=assigned_count+1, updated_at=now() WHERE id=p_request_id;
  UPDATE usage_log
  SET quota_reserved=GREATEST(quota_reserved-1,0),
      leads_delivered=leads_delivered+1,
      tier_a_count=tier_a_count+CASE WHEN upper(coalesce(p_tier,'A'))='A' THEN 1 ELSE 0 END,
      tier_b_count=tier_b_count+CASE WHEN upper(coalesce(p_tier,'A'))='B' THEN 1 ELSE 0 END,
      tier_c_count=tier_c_count+CASE WHEN upper(coalesce(p_tier,'A'))='C' THEN 1 ELSE 0 END,
      updated_at=now()
  WHERE tenant_id=p_tenant_id AND period=p;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_discovery_quota_reservation(p_tenant_id uuid, p_count int)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE p date := date_trunc('month', now())::date;
BEGIN
  UPDATE usage_log SET quota_reserved=GREATEST(quota_reserved-GREATEST(p_count,0),0), updated_at=now()
   WHERE tenant_id=p_tenant_id AND period=p;
END;
$$;

CREATE OR REPLACE FUNCTION public.tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE lim int; used int; reserved int; p date := date_trunc('month', now())::date;
BEGIN
 SELECT leads_per_month_limit INTO lim FROM tenants WHERE id=p_tenant_id;
 IF lim IS NULL THEN RETURN 0; END IF;
 SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0) INTO used,reserved FROM usage_log WHERE tenant_id=p_tenant_id AND period=p;
 RETURN GREATEST(lim-COALESCE(used,0)-COALESCE(reserved,0),0);
END;
$$;

-- Add city/state coverage metadata to global records without changing existing identity semantics.
ALTER TABLE leads_global
  ADD COLUMN IF NOT EXISTS first_discovered_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS last_discovered_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS source_provenance jsonb NOT NULL DEFAULT '{}';

ALTER TABLE lead_assignments
  ADD COLUMN IF NOT EXISTS discovery_request_id uuid REFERENCES discovery_requests(id) ON DELETE SET NULL;

ALTER TABLE discovery_coverage
  ADD COLUMN IF NOT EXISTS global_exhausted boolean NOT NULL DEFAULT false;

-- RLS for client-visible request objects.
ALTER TABLE discovery_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS discovery_requests_member_select ON discovery_requests;
CREATE POLICY discovery_requests_member_select ON discovery_requests FOR SELECT USING (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=discovery_requests.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);
DROP POLICY IF EXISTS discovery_requests_member_insert ON discovery_requests;
CREATE POLICY discovery_requests_member_insert ON discovery_requests FOR INSERT WITH CHECK (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=discovery_requests.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);

CREATE OR REPLACE FUNCTION public.release_tenant_discovery_slot(p_tenant_id uuid, p_request_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE p date := date_trunc('month', now())::date;
BEGIN
  UPDATE discovery_requests
    SET assigned_count=GREATEST(assigned_count-1,0), updated_at=now()
    WHERE id=p_request_id AND tenant_id=p_tenant_id;
  UPDATE usage_log SET quota_reserved=quota_reserved+1, updated_at=now()
    WHERE tenant_id=p_tenant_id AND period=p;
END;
$$;


-- Atomic monthly lead quota reservations.
-- Normal/direct pipeline slots cannot consume quota already reserved by approved discovery requests.
CREATE OR REPLACE FUNCTION public.reserve_tenant_lead_slot(p_tenant_id uuid, p_tier text DEFAULT 'A')
RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE
  p date := date_trunc('month', now())::date;
  lim int;
  used int;
  reserved int;
BEGIN
  SELECT leads_per_month_limit INTO lim FROM tenants WHERE id = p_tenant_id FOR UPDATE;
  IF lim IS NULL THEN RETURN false; END IF;
  INSERT INTO usage_log (tenant_id, period, leads_delivered, quota_reserved, tier_a_count, tier_b_count, tier_c_count)
  VALUES (p_tenant_id, p, 0, 0, 0, 0, 0)
  ON CONFLICT (tenant_id, period) DO NOTHING;
  SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0) INTO used, reserved
  FROM usage_log WHERE tenant_id = p_tenant_id AND period = p FOR UPDATE;
  IF used + reserved >= lim THEN RETURN false; END IF;
  UPDATE usage_log
  SET leads_delivered = leads_delivered + 1,
      tier_a_count = tier_a_count + CASE WHEN upper(coalesce(p_tier,'A')) = 'A' THEN 1 ELSE 0 END,
      tier_b_count = tier_b_count + CASE WHEN upper(coalesce(p_tier,'A')) = 'B' THEN 1 ELSE 0 END,
      tier_c_count = tier_c_count + CASE WHEN upper(coalesce(p_tier,'A')) = 'C' THEN 1 ELSE 0 END,
      updated_at = now()
  WHERE tenant_id = p_tenant_id AND period = p;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_tenant_lead_slot(p_tenant_id uuid, p_tier text DEFAULT 'A')
RETURNS void LANGUAGE plpgsql AS $$
DECLARE p date := date_trunc('month', now())::date;
BEGIN
  UPDATE usage_log
  SET leads_delivered = GREATEST(leads_delivered - 1, 0),
      tier_a_count = GREATEST(tier_a_count - CASE WHEN upper(coalesce(p_tier,'A')) = 'A' THEN 1 ELSE 0 END, 0),
      tier_b_count = GREATEST(tier_b_count - CASE WHEN upper(coalesce(p_tier,'A')) = 'B' THEN 1 ELSE 0 END, 0),
      tier_c_count = GREATEST(tier_c_count - CASE WHEN upper(coalesce(p_tier,'A')) = 'C' THEN 1 ELSE 0 END, 0),
      updated_at = now()
  WHERE tenant_id = p_tenant_id AND period = p;
END;
$$;


-- 029 Revenue intelligence + autonomous admin automation
-- Canonical source: sql/029_REVENUE_INTELLIGENCE_AUTOMATION.sql
-- LeadX 2026: Revenue intelligence + autonomous operator automation foundation.
-- Idempotent. Apply after 028_DISCOVERY_REQUESTS_GLOBAL_COVERAGE.sql.

-- 1) Evidence ledger: every important claim can point back to a source.
CREATE TABLE IF NOT EXISTS lead_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  value jsonb NOT NULL DEFAULT '{}',
  source text NOT NULL,
  source_url text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  confidence numeric(5,4) CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
  method text,
  is_current boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS field_name text;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS value jsonb;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS source_url text;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS observed_at timestamptz;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS confidence numeric(5,4);
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS method text;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS is_current boolean;
ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- LeadX schema compatibility repair: older installations may already have these
-- tables without the historical observed_at column. CREATE TABLE IF NOT EXISTS
-- does not reconcile an existing table, so repair the column before indexes.
DO $$
BEGIN
  ALTER TABLE IF EXISTS public.lead_evidence ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
  ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_lead_evidence_lead_field ON lead_evidence(lead_id, field_name, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_evidence_tenant ON lead_evidence(tenant_id, created_at DESC);

-- 2) Historical observations/freshness instead of destructive overwrites.
CREATE TABLE IF NOT EXISTS lead_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  old_value jsonb,
  new_value jsonb,
  source text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS field_name text;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS old_value jsonb;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS new_value jsonb;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS observed_at timestamptz;
ALTER TABLE IF EXISTS public.lead_observations ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_observations_lead ON lead_observations(lead_id, observed_at DESC);

-- 3) Versioned scoring decisions for explainability and rollback.
CREATE TABLE IF NOT EXISTS lead_score_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  model_version text NOT NULL,
  fit_score int,
  opportunity_score int,
  intent_score int,
  contactability_score int,
  total_score int,
  tier text,
  reasoning jsonb NOT NULL DEFAULT '{}',
  evidence_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS model_version text;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS fit_score int;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS opportunity_score int;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS intent_score int;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS contactability_score int;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS total_score int;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS tier text;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS reasoning jsonb;
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS evidence_ids uuid[];
ALTER TABLE IF EXISTS public.lead_score_versions ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_score_versions_lead ON lead_score_versions(lead_id, created_at DESC);

-- 4) Lead refresh queue/state.
CREATE TABLE IF NOT EXISTS lead_refresh_state (
  lead_id uuid PRIMARY KEY REFERENCES leads_global(id) ON DELETE CASCADE,
  last_refreshed_at timestamptz,
  next_refresh_at timestamptz,
  refresh_priority int NOT NULL DEFAULT 50,
  refresh_reason text,
  stale_fields text[] NOT NULL DEFAULT '{}',
  last_result jsonb NOT NULL DEFAULT '{}',
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS last_refreshed_at timestamptz;
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS next_refresh_at timestamptz;
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS refresh_priority int;
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS refresh_reason text;
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS stale_fields text[];
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS last_result jsonb;
ALTER TABLE IF EXISTS public.lead_refresh_state ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_refresh_due ON lead_refresh_state(next_refresh_at, refresh_priority DESC);

-- 5) Saved natural-language / structured prospecting searches.
CREATE TABLE IF NOT EXISTS saved_searches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  query text,
  filters jsonb NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true,
  continuous boolean NOT NULL DEFAULT false,
  alert_on_new boolean NOT NULL DEFAULT true,
  last_run_at timestamptz,
  last_match_count int NOT NULL DEFAULT 0,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS query text;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS filters jsonb;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS active boolean;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS continuous boolean;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS alert_on_new boolean;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS last_match_count int;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.saved_searches ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_saved_searches_tenant ON saved_searches(tenant_id, active, created_at DESC);

-- 6) Generic workflow rules/actions for CRM and prospecting automation.
CREATE TABLE IF NOT EXISTS workflow_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  trigger_type text NOT NULL,
  conditions jsonb NOT NULL DEFAULT '{}',
  actions jsonb NOT NULL DEFAULT '[]',
  active boolean NOT NULL DEFAULT true,
  priority int NOT NULL DEFAULT 100,
  last_run_at timestamptz,
  run_count int NOT NULL DEFAULT 0,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS trigger_type text;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS conditions jsonb;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS actions jsonb;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS active boolean;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS priority int;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS run_count int;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.workflow_rules ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_workflow_rules_tenant ON workflow_rules(tenant_id, active, priority);

CREATE TABLE IF NOT EXISTS workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL REFERENCES workflow_rules(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  entity_type text,
  entity_id uuid,
  status text NOT NULL DEFAULT 'queued',
  result jsonb NOT NULL DEFAULT '{}',
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS workflow_id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS entity_id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS result jsonb;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS finished_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_workflow_runs_workflow ON workflow_runs(workflow_id, created_at DESC);

-- 7) Provider telemetry / unit economics.
CREATE TABLE IF NOT EXISTS provider_usage_daily (
  day date NOT NULL,
  provider text NOT NULL,
  operation text NOT NULL,
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  calls int NOT NULL DEFAULT 0,
  successes int NOT NULL DEFAULT 0,
  failures int NOT NULL DEFAULT 0,
  estimated_cost numeric(14,6) NOT NULL DEFAULT 0,
  latency_ms_total bigint NOT NULL DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}',
  PRIMARY KEY(day, provider, operation, tenant_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS day date;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS operation text;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS calls int;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS successes int;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS failures int;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS estimated_cost numeric(14,6);
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS latency_ms_total bigint;
ALTER TABLE IF EXISTS public.provider_usage_daily ADD COLUMN IF NOT EXISTS metadata jsonb;

CREATE INDEX IF NOT EXISTS idx_provider_usage_day ON provider_usage_daily(day DESC, provider, operation);

-- 8) Campaigns: admin-owned autonomous prospecting + outreach. Client workflows
-- continue using their existing discovery request flow and sequences.
CREATE TABLE IF NOT EXISTS autonomous_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  icp_id uuid,
  sequence_id uuid REFERENCES email_sequences(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','active','paused','completed','error')),
  locations jsonb NOT NULL DEFAULT '[]',
  queries jsonb NOT NULL DEFAULT '[]',
  offer text,
  goal text,
  daily_new_lead_limit int NOT NULL DEFAULT 25 CHECK (daily_new_lead_limit >= 1),
  daily_email_limit int NOT NULL DEFAULT 25 CHECK (daily_email_limit >= 1),
  max_active_enrollments int NOT NULL DEFAULT 5000 CHECK (max_active_enrollments >= 1),
  send_window_start time NOT NULL DEFAULT '09:00',
  send_window_end time NOT NULL DEFAULT '17:00',
  timezone text NOT NULL DEFAULT 'America/New_York',
  generate_ai_copy boolean NOT NULL DEFAULT true,
  auto_followup boolean NOT NULL DEFAULT true,
  stop_on_reply boolean NOT NULL DEFAULT true,
  stop_on_optout boolean NOT NULL DEFAULT true,
  require_verified_email boolean NOT NULL DEFAULT true,
  score_threshold int NOT NULL DEFAULT 70,
  schedule_hours int NOT NULL DEFAULT 24 CHECK (schedule_hours >= 1),
  next_discovery_at timestamptz,
  last_discovery_at timestamptz,
  last_discovery_result jsonb NOT NULL DEFAULT '{}',
  created_by text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS sequence_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS locations jsonb;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS queries jsonb;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS offer text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS goal text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_new_lead_limit int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_email_limit int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS max_active_enrollments int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_start time;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_end time;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS timezone text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS generate_ai_copy boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS auto_followup boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_reply boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_optout boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS require_verified_email boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS score_threshold int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS schedule_hours int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS next_discovery_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_result jsonb;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_tenant ON autonomous_campaigns(tenant_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_due ON autonomous_campaigns(next_discovery_at) WHERE status = 'active';

-- 9) Daily campaign budget ledger. Reservations make concurrent workers safe.
CREATE TABLE IF NOT EXISTS autonomous_campaign_daily (
  campaign_id uuid NOT NULL REFERENCES autonomous_campaigns(id) ON DELETE CASCADE,
  day date NOT NULL,
  leads_discovered int NOT NULL DEFAULT 0,
  emails_sent int NOT NULL DEFAULT 0,
  emails_reserved int NOT NULL DEFAULT 0,
  replies int NOT NULL DEFAULT 0,
  positive_replies int NOT NULL DEFAULT 0,
  meetings int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(campaign_id, day)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS campaign_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS day date;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS leads_discovered int;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS emails_sent int;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS emails_reserved int;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS replies int;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS positive_replies int;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS meetings int;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaign_daily ADD COLUMN IF NOT EXISTS updated_at timestamptz;


-- 10) Tie a sequence enrollment/send to an autonomous campaign when applicable.
ALTER TABLE email_sequence_enrollments ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES autonomous_campaigns(id) ON DELETE SET NULL;
ALTER TABLE email_sequence_enrollments ADD COLUMN IF NOT EXISTS ai_copy_enabled boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_sequence_enrollments_campaign ON email_sequence_enrollments(campaign_id, status, next_send_at);
ALTER TABLE email_sequence_sends ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES autonomous_campaigns(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_sequence_sends_campaign ON email_sequence_sends(campaign_id, created_at DESC);
ALTER TABLE email_sends ADD COLUMN IF NOT EXISTS campaign_id uuid REFERENCES autonomous_campaigns(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_email_sends_campaign ON email_sends(campaign_id, created_at DESC);

-- 11) Per-lead AI copy cache; never regenerate the same step unnecessarily.
CREATE TABLE IF NOT EXISTS campaign_email_copies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES autonomous_campaigns(id) ON DELETE CASCADE,
  enrollment_id uuid REFERENCES email_sequence_enrollments(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL,
  step_number int NOT NULL,
  subject text NOT NULL,
  body_html text NOT NULL,
  body_text text,
  provider text,
  evidence jsonb NOT NULL DEFAULT '{}',
  approved boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(campaign_id, assignment_id, step_number)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS campaign_id uuid;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS enrollment_id uuid;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS step_number int;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS body_html text;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS evidence jsonb;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS approved boolean;
ALTER TABLE IF EXISTS public.campaign_email_copies ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_campaign_email_copies_assignment ON campaign_email_copies(assignment_id, step_number);

-- 12) Campaign outcome/QA feedback.
CREATE TABLE IF NOT EXISTS lead_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  outcome text NOT NULL,
  reason text,
  value numeric(14,2),
  metadata jsonb NOT NULL DEFAULT '{}',
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS outcome text;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS value numeric(14,2);
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.lead_feedback ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_feedback_tenant ON lead_feedback(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_feedback_lead ON lead_feedback(lead_id, created_at DESC);

-- 13) Atomic campaign email budget reservation. Returns {ok, reserved}.
CREATE OR REPLACE FUNCTION reserve_campaign_email_slot(p_campaign_id uuid, p_requested int DEFAULT 1)
RETURNS jsonb LANGUAGE plpgsql AS $$
DECLARE
  c int;
  used int;
  reserved int;
  available int;
  take_n int;
BEGIN
  SELECT daily_email_limit INTO c FROM autonomous_campaigns WHERE id = p_campaign_id AND status = 'active' FOR UPDATE;
  IF c IS NULL THEN RETURN jsonb_build_object('ok', false, 'reserved', 0, 'reason', 'campaign_inactive'); END IF;
  INSERT INTO autonomous_campaign_daily(campaign_id, day) VALUES(p_campaign_id, current_date)
    ON CONFLICT(campaign_id, day) DO NOTHING;
  SELECT emails_sent, emails_reserved INTO used, reserved
    FROM autonomous_campaign_daily WHERE campaign_id = p_campaign_id AND day = current_date FOR UPDATE;
  available := GREATEST(c - used - reserved, 0);
  take_n := LEAST(GREATEST(p_requested, 0), available);
  IF take_n <= 0 THEN RETURN jsonb_build_object('ok', false, 'reserved', 0, 'reason', 'daily_email_limit_reached'); END IF;
  UPDATE autonomous_campaign_daily SET emails_reserved = emails_reserved + take_n, updated_at = now()
    WHERE campaign_id = p_campaign_id AND day = current_date;
  RETURN jsonb_build_object('ok', true, 'reserved', take_n);
END;
$$;

CREATE OR REPLACE FUNCTION consume_campaign_email_slot(p_campaign_id uuid, p_count int DEFAULT 1)
RETURNS jsonb LANGUAGE plpgsql AS $$
BEGIN
  UPDATE autonomous_campaign_daily
     SET emails_reserved = GREATEST(emails_reserved - GREATEST(p_count,0),0),
         emails_sent = emails_sent + GREATEST(p_count,0), updated_at = now()
   WHERE campaign_id = p_campaign_id AND day = current_date;
  RETURN jsonb_build_object('ok', true);
END;
$$;

CREATE OR REPLACE FUNCTION release_campaign_email_slot(p_campaign_id uuid, p_count int DEFAULT 1)
RETURNS jsonb LANGUAGE plpgsql AS $$
BEGIN
  UPDATE autonomous_campaign_daily
     SET emails_reserved = GREATEST(emails_reserved - GREATEST(p_count,0),0), updated_at = now()
   WHERE campaign_id = p_campaign_id AND day = current_date;
  RETURN jsonb_build_object('ok', true);
END;
$$;

NOTIFY pgrst, 'reload schema';

-- Canonical source: sql/033_PRODUCTION_SCALE_CONTROL.sql
-- LeadX production-scale control plane
CREATE TABLE IF NOT EXISTS worker_heartbeats (
  worker_id text PRIMARY KEY,
  kinds text[] NOT NULL DEFAULT '{}',
  capacity integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'healthy',
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  observed_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS worker_id text;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS kinds text[];
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS capacity integer;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS observed_at timestamptz;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS updated_at timestamptz;

ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS active_jobs integer NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS idx_worker_heartbeats_seen ON worker_heartbeats(last_seen_at DESC);

CREATE TABLE IF NOT EXISTS operation_idempotency (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key text NOT NULL,
  operation text NOT NULL,
  tenant_id uuid,
  status text NOT NULL DEFAULT 'completed',
  response jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(idempotency_key, operation)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS idempotency_key text;
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS operation text;
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS response jsonb;
ALTER TABLE IF EXISTS public.operation_idempotency ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_operation_idempotency_tenant ON operation_idempotency(tenant_id,created_at DESC);

CREATE TABLE IF NOT EXISTS delivery_outbox (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  event_type text NOT NULL,
  aggregate_type text,
  aggregate_id text,
  payload jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','delivered','failed')),
  attempts integer NOT NULL DEFAULT 0,
  available_at timestamptz NOT NULL DEFAULT now(),
  delivered_at timestamptz,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS event_type text;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS aggregate_type text;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS aggregate_id text;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS payload jsonb;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS attempts integer;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS available_at timestamptz;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS delivered_at timestamptz;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE IF EXISTS public.delivery_outbox ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_delivery_outbox_ready ON delivery_outbox(status,available_at);

-- Canonical source: sql/034_AI_INTELLIGENCE.sql
-- Evidence-grounded AI briefs and next-best actions
CREATE TABLE IF NOT EXISTS lead_ai_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  model_version text NOT NULL,
  summary text,
  why_now jsonb NOT NULL DEFAULT '[]',
  next_best_actions jsonb NOT NULL DEFAULT '[]',
  scores jsonb NOT NULL DEFAULT '{}',
  confidence numeric(5,4),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS model_version text;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS summary text;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS why_now jsonb;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS next_best_actions jsonb;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS scores jsonb;
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS confidence numeric(5,4);
ALTER TABLE IF EXISTS public.lead_ai_briefs ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_ai_briefs_lead ON lead_ai_briefs(lead_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_ai_briefs_tenant ON lead_ai_briefs(tenant_id,created_at DESC);

CREATE TABLE IF NOT EXISTS intelligence_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid,
  signal text NOT NULL,
  feedback text NOT NULL,
  actor_id text,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS signal text;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS feedback text;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS actor_id text;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.intelligence_feedback ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_intelligence_feedback_tenant ON intelligence_feedback(tenant_id,created_at DESC);


-- Canonical source: sql/035_REVENUE_INTELLIGENCE.sql
-- Explicit revenue funnel/event ledger for attribution and auditability
CREATE TABLE IF NOT EXISTS revenue_funnel_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  lead_id uuid,
  assignment_id uuid,
  deal_id uuid,
  event_type text NOT NULL,
  source text,
  metadata jsonb NOT NULL DEFAULT '{}',
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS event_type text;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS occurred_at timestamptz;
ALTER TABLE IF EXISTS public.revenue_funnel_events ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_revenue_funnel_tenant ON revenue_funnel_events(tenant_id,occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_revenue_funnel_lead ON revenue_funnel_events(lead_id,occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_revenue_funnel_deal ON revenue_funnel_events(deal_id,occurred_at DESC);

CREATE TABLE IF NOT EXISTS revenue_attribution (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  deal_id uuid,
  lead_id uuid,
  assignment_id uuid,
  attribution_model text NOT NULL DEFAULT 'first_touch',
  revenue_amount numeric(16,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  weight numeric(8,5) NOT NULL DEFAULT 1,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS deal_id uuid;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS attribution_model text;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS revenue_amount numeric(16,2);
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS currency text;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS weight numeric(8,5);
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.revenue_attribution ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_revenue_attribution_tenant ON revenue_attribution(tenant_id,created_at DESC);


-- Canonical source: sql/036_LEARNING_LOOP.sql
-- Explainable closed-loop learning snapshots. Snapshots inform recommendations;
-- they do not silently rewrite scoring rules.
CREATE TABLE IF NOT EXISTS learning_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  model_version text NOT NULL,
  outcomes integer NOT NULL DEFAULT 0,
  won integer NOT NULL DEFAULT 0,
  lost integer NOT NULL DEFAULT 0,
  win_rate_pct numeric(7,3) NOT NULL DEFAULT 0,
  weights jsonb NOT NULL DEFAULT '{}',
  lookalike_queries jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS model_version text;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS outcomes integer;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS won integer;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS lost integer;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS win_rate_pct numeric(7,3);
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS weights jsonb;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS lookalike_queries jsonb;
ALTER TABLE IF EXISTS public.learning_snapshots ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_learning_snapshots_tenant ON learning_snapshots(tenant_id,created_at DESC);


-- Canonical source: sql/037_UI_WORKSPACE.sql
-- Workspace UI preferences and saved command-center layouts
CREATE TABLE IF NOT EXISTS workspace_preferences (
  tenant_id uuid PRIMARY KEY,
  dashboard_layout jsonb NOT NULL DEFAULT '{}',
  density text NOT NULL DEFAULT 'comfortable',
  default_view text NOT NULL DEFAULT 'command_center',
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.workspace_preferences ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.workspace_preferences ADD COLUMN IF NOT EXISTS dashboard_layout jsonb;
ALTER TABLE IF EXISTS public.workspace_preferences ADD COLUMN IF NOT EXISTS density text;
ALTER TABLE IF EXISTS public.workspace_preferences ADD COLUMN IF NOT EXISTS default_view text;
ALTER TABLE IF EXISTS public.workspace_preferences ADD COLUMN IF NOT EXISTS updated_at timestamptz;



NOTIFY pgrst, 'reload schema';
ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE IF EXISTS worker_heartbeats ADD COLUMN IF NOT EXISTS active_jobs integer NOT NULL DEFAULT 0;

-- LeadX 3.0 core: security, observability, evidence, opportunity, compliance
-- automation, learning and product analytics. Backend-owned tables use the
-- service role; tenant-facing access remains through authenticated APIs.


CREATE TABLE IF NOT EXISTS platform_admins (
  user_id uuid PRIMARY KEY,
  email text,
  role text NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin','admin','ops','support','finance','analyst')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.platform_admins ADD COLUMN IF NOT EXISTS user_id uuid;
ALTER TABLE IF EXISTS public.platform_admins ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.platform_admins ADD COLUMN IF NOT EXISTS role text;
ALTER TABLE IF EXISTS public.platform_admins ADD COLUMN IF NOT EXISTS active boolean;
ALTER TABLE IF EXISTS public.platform_admins ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.platform_admins ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id text,
  actor_type text NOT NULL DEFAULT 'system',
  tenant_id uuid,
  action text NOT NULL,
  resource_type text,
  resource_id text,
  before_state jsonb,
  after_state jsonb,
  reason text,
  ip_address inet,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS actor_id text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS actor_type text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS action text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS resource_type text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS resource_id text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS before_state jsonb;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS after_state jsonb;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS ip_address inet;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS user_agent text;
ALTER TABLE IF EXISTS public.audit_log ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Compatibility repair: older LeadX/HARDENING builds created audit_log with
-- actor/target_type/target_id/meta instead of the 3.0 control-plane columns.
-- CREATE TABLE IF NOT EXISTS does not change an existing table, so repair the
-- shape before creating 3.0 indexes. This is safe on fresh and existing DBs.
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS actor_id text;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS actor_type text DEFAULT 'system';
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS resource_type text;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS resource_id text;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS before_state jsonb;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS after_state jsonb;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS ip_address inet;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS user_agent text;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS action text;
ALTER TABLE IF EXISTS audit_log ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_audit_log_tenant_time ON audit_log(tenant_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_resource ON audit_log(resource_type,resource_id,created_at DESC);

CREATE TABLE IF NOT EXISTS security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  severity text NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','high','critical')),
  event_type text NOT NULL,
  actor_id text,
  tenant_id uuid,
  ip_address inet,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS severity text;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS event_type text;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS actor_id text;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS ip_address inet;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.security_events ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_security_events_time ON security_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity,created_at DESC);

CREATE TABLE IF NOT EXISTS queue_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  queue_name text NOT NULL,
  queued integer NOT NULL DEFAULT 0,
  running integer NOT NULL DEFAULT 0,
  failed integer NOT NULL DEFAULT 0,
  oldest_queued_seconds integer NOT NULL DEFAULT 0,
  throughput_per_minute numeric(12,2) NOT NULL DEFAULT 0,
  captured_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS queue_name text;
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS queued integer;
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS running integer;
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS failed integer;
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS oldest_queued_seconds integer;
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS throughput_per_minute numeric(12,2);
ALTER TABLE IF EXISTS public.queue_metrics ADD COLUMN IF NOT EXISTS captured_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_queue_metrics_time ON queue_metrics(queue_name,captured_at DESC);

CREATE TABLE IF NOT EXISTS provider_health (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  operation text NOT NULL DEFAULT 'default',
  status text NOT NULL DEFAULT 'healthy',
  success_count bigint NOT NULL DEFAULT 0,
  failure_count bigint NOT NULL DEFAULT 0,
  latency_ms numeric(12,2) NOT NULL DEFAULT 0,
  estimated_cost numeric(16,6) NOT NULL DEFAULT 0,
  last_error text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(provider,operation)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS operation text;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS success_count bigint;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS failure_count bigint;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS latency_ms numeric(12,2);
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS estimated_cost numeric(16,6);
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS observed_at timestamptz;


-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.provider_health ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE TABLE IF NOT EXISTS data_lineage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  field_name text,
  value_hash text,
  source text NOT NULL,
  source_url text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  confidence numeric(6,5),
  metadata jsonb NOT NULL DEFAULT '{}'
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS entity_id text;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS field_name text;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS value_hash text;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS source_url text;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS observed_at timestamptz;
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS metadata jsonb;

-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.data_lineage ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_data_lineage_entity ON data_lineage(entity_type,entity_id,observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_data_lineage_source ON data_lineage(source,observed_at DESC);

CREATE TABLE IF NOT EXISTS lead_signals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  signal_type text NOT NULL,
  strength numeric(6,3) NOT NULL DEFAULT 0,
  confidence numeric(6,5) NOT NULL DEFAULT 0.5,
  observed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  source text,
  evidence jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'active'
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS signal_type text;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS strength numeric(6,3);
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS observed_at timestamptz;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS expires_at timestamptz;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS evidence jsonb;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS status text;

-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_lead_signals_lead ON lead_signals(lead_id,observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_signals_type ON lead_signals(signal_type,strength DESC);

CREATE TABLE IF NOT EXISTS lead_opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  recipe_id text,
  opportunity_type text NOT NULL,
  fit_score numeric(6,2) NOT NULL DEFAULT 0,
  need_score numeric(6,2) NOT NULL DEFAULT 0,
  timing_score numeric(6,2) NOT NULL DEFAULT 0,
  contactability_score numeric(6,2) NOT NULL DEFAULT 0,
  evidence_score numeric(6,2) NOT NULL DEFAULT 0,
  overall_score numeric(6,2) NOT NULL DEFAULT 0,
  confidence numeric(6,5) NOT NULL DEFAULT 0.5,
  why_now jsonb NOT NULL DEFAULT '[]',
  recommended_action text,
  evidence jsonb NOT NULL DEFAULT '[]',
  model_version text NOT NULL DEFAULT 'leadx-opportunity-v1',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS recipe_id text;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS opportunity_type text;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS fit_score numeric(6,2);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS need_score numeric(6,2);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS timing_score numeric(6,2);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS contactability_score numeric(6,2);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS evidence_score numeric(6,2);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS overall_score numeric(6,2);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS why_now jsonb;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS recommended_action text;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS evidence jsonb;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS model_version text;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.lead_opportunities ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_lead_opportunities_lead ON lead_opportunities(lead_id,overall_score DESC,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_opportunities_tenant ON lead_opportunities(tenant_id,overall_score DESC);

CREATE TABLE IF NOT EXISTS contact_graph_edges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  company_id uuid,
  contact_id uuid,
  role text,
  influence numeric(6,2),
  authority numeric(6,2),
  confidence numeric(6,5) DEFAULT 0.5,
  evidence jsonb NOT NULL DEFAULT '{}',
  observed_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS company_id uuid;
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS contact_id uuid;
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS role text;
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS influence numeric(6,2);
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS authority numeric(6,2);
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS evidence jsonb;
ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS observed_at timestamptz;

-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.contact_graph_edges ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_contact_graph_company ON contact_graph_edges(company_id,observed_at DESC);

CREATE TABLE IF NOT EXISTS company_change_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid,
  event_type text NOT NULL,
  before_value jsonb,
  after_value jsonb,
  confidence numeric(6,5) DEFAULT 0.5,
  source text,
  observed_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS event_type text;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS before_value jsonb;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS after_value jsonb;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS observed_at timestamptz;

-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.company_change_events ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_company_changes_lead ON company_change_events(lead_id,observed_at DESC);

CREATE TABLE IF NOT EXISTS website_audits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  lead_id uuid NOT NULL,
  url text,
  booking_score numeric(6,2),
  conversion_score numeric(6,2),
  seo_score numeric(6,2),
  mobile_score numeric(6,2),
  speed_score numeric(6,2),
  trust_score numeric(6,2),
  technologies jsonb NOT NULL DEFAULT '[]',
  issues jsonb NOT NULL DEFAULT '[]',
  evidence jsonb NOT NULL DEFAULT '[]',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS url text;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS booking_score numeric(6,2);
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS conversion_score numeric(6,2);
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS seo_score numeric(6,2);
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS mobile_score numeric(6,2);
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS speed_score numeric(6,2);
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS trust_score numeric(6,2);
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS technologies jsonb;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS issues jsonb;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS evidence jsonb;
ALTER TABLE IF EXISTS public.website_audits ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_website_audits_lead ON website_audits(lead_id,created_at DESC);

CREATE TABLE IF NOT EXISTS technographics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  technology text NOT NULL,
  category text,
  confidence numeric(6,5) DEFAULT 0.5,
  source text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(lead_id,technology)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS technology text;
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS observed_at timestamptz;

-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.technographics ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_technographics_tech ON technographics(technology,confidence DESC);

CREATE TABLE IF NOT EXISTS lead_quality_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  assignment_id uuid NOT NULL,
  issue_type text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  evidence jsonb NOT NULL DEFAULT '{}',
  resolution text,
  replacement_assignment_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS issue_type text;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS evidence jsonb;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS resolution text;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS replacement_assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.lead_quality_reports ADD COLUMN IF NOT EXISTS resolved_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_quality_reports_tenant ON lead_quality_reports(tenant_id,status,created_at DESC);

CREATE TABLE IF NOT EXISTS lead_replacement_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  original_assignment_id uuid NOT NULL,
  replacement_assignment_id uuid,
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_replacement_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_replacement_events ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_replacement_events ADD COLUMN IF NOT EXISTS original_assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_replacement_events ADD COLUMN IF NOT EXISTS replacement_assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_replacement_events ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.lead_replacement_events ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS campaign_guardrails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  campaign_id uuid,
  max_leads_per_day integer,
  max_emails_per_day integer,
  max_cost_per_day numeric(16,2),
  max_bounce_pct numeric(6,3) DEFAULT 5,
  max_complaint_pct numeric(6,3) DEFAULT 0.2,
  max_ai_cost_per_day numeric(16,2),
  enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(campaign_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS campaign_id uuid;
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS max_leads_per_day integer;
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS max_emails_per_day integer;
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS max_cost_per_day numeric(16,2);
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS max_bounce_pct numeric(6,3);
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS max_complaint_pct numeric(6,3);
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS max_ai_cost_per_day numeric(16,2);
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS enabled boolean;
ALTER TABLE IF EXISTS public.campaign_guardrails ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE TABLE IF NOT EXISTS email_domain_health (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  domain text NOT NULL,
  spf_ok boolean,
  dkim_ok boolean,
  dmarc_ok boolean,
  mx_ok boolean,
  bounce_pct numeric(7,3) DEFAULT 0,
  complaint_pct numeric(7,3) DEFAULT 0,
  sent_count bigint DEFAULT 0,
  last_checked_at timestamptz,
  status text NOT NULL DEFAULT 'unknown',
  UNIQUE(tenant_id,domain)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS domain text;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS spf_ok boolean;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS dkim_ok boolean;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS dmarc_ok boolean;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS mx_ok boolean;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS bounce_pct numeric(7,3);
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS complaint_pct numeric(7,3);
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS sent_count bigint;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS last_checked_at timestamptz;
ALTER TABLE IF EXISTS public.email_domain_health ADD COLUMN IF NOT EXISTS status text;


CREATE TABLE IF NOT EXISTS compliance_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  subject_type text NOT NULL,
  subject_id text NOT NULL,
  event_type text NOT NULL,
  legal_basis text,
  region text,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS subject_type text;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS subject_id text;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS event_type text;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS legal_basis text;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS region text;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.compliance_events ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_compliance_subject ON compliance_events(subject_type,subject_id,created_at DESC);

CREATE TABLE IF NOT EXISTS workflow_definitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  name text NOT NULL,
  trigger_type text NOT NULL,
  graph jsonb NOT NULL DEFAULT '{}',
  enabled boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS trigger_type text;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS graph jsonb;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS enabled boolean;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS version integer;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.workflow_definitions ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE TABLE IF NOT EXISTS workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL,
  tenant_id uuid,
  status text NOT NULL DEFAULT 'queued',
  current_node text,
  context jsonb NOT NULL DEFAULT '{}',
  error text,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS workflow_id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS current_node text;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS context jsonb;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE IF EXISTS public.workflow_runs ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_workflow_runs_workflow ON workflow_runs(workflow_id,created_at DESC);

CREATE TABLE IF NOT EXISTS product_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  user_id text,
  event_name text NOT NULL,
  properties jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.product_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.product_events ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.product_events ADD COLUMN IF NOT EXISTS user_id text;
ALTER TABLE IF EXISTS public.product_events ADD COLUMN IF NOT EXISTS event_name text;
ALTER TABLE IF EXISTS public.product_events ADD COLUMN IF NOT EXISTS properties jsonb;
ALTER TABLE IF EXISTS public.product_events ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_product_events_tenant ON product_events(tenant_id,created_at DESC);

CREATE TABLE IF NOT EXISTS daily_briefs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  brief_date date NOT NULL,
  content jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,brief_date)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.daily_briefs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.daily_briefs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.daily_briefs ADD COLUMN IF NOT EXISTS brief_date date;
ALTER TABLE IF EXISTS public.daily_briefs ADD COLUMN IF NOT EXISTS content jsonb;
ALTER TABLE IF EXISTS public.daily_briefs ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS next_best_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  action text NOT NULL,
  reason text,
  priority numeric(8,3) DEFAULT 0,
  confidence numeric(6,5) DEFAULT 0.5,
  status text NOT NULL DEFAULT 'open',
  due_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS entity_id text;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS action text;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS priority numeric(8,3);
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS due_at timestamptz;
ALTER TABLE IF EXISTS public.next_best_actions ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_nba_tenant ON next_best_actions(tenant_id,status,priority DESC);

CREATE TABLE IF NOT EXISTS export_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  actor_id text,
  export_type text NOT NULL,
  row_count integer NOT NULL DEFAULT 0,
  fields text[] NOT NULL DEFAULT '{}',
  filters jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS actor_id text;
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS export_type text;
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS row_count integer;
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS fields text[];
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS filters jsonb;
ALTER TABLE IF EXISTS public.export_audit ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS data_subject_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  subject_type text NOT NULL,
  subject_value text NOT NULL,
  request_type text NOT NULL CHECK(request_type IN ('access','correct','delete','suppress','export')),
  status text NOT NULL DEFAULT 'open',
  requested_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  resolution text
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS subject_type text;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS subject_value text;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS request_type text;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS requested_at timestamptz;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS resolved_at timestamptz;
ALTER TABLE IF EXISTS public.data_subject_requests ADD COLUMN IF NOT EXISTS resolution text;


CREATE TABLE IF NOT EXISTS feature_flags (
  key text PRIMARY KEY,
  enabled boolean NOT NULL DEFAULT false,
  rollout_pct integer NOT NULL DEFAULT 100 CHECK(rollout_pct BETWEEN 0 AND 100),
  tenant_ids uuid[] NOT NULL DEFAULT '{}',
  metadata jsonb NOT NULL DEFAULT '{}',
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.feature_flags ADD COLUMN IF NOT EXISTS key text;
ALTER TABLE IF EXISTS public.feature_flags ADD COLUMN IF NOT EXISTS enabled boolean;
ALTER TABLE IF EXISTS public.feature_flags ADD COLUMN IF NOT EXISTS rollout_pct integer;
ALTER TABLE IF EXISTS public.feature_flags ADD COLUMN IF NOT EXISTS tenant_ids uuid[];
ALTER TABLE IF EXISTS public.feature_flags ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.feature_flags ADD COLUMN IF NOT EXISTS updated_at timestamptz;


CREATE TABLE IF NOT EXISTS ai_model_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_key text NOT NULL,
  provider text NOT NULL,
  version text NOT NULL,
  status text NOT NULL DEFAULT 'candidate',
  evaluation_score numeric(8,4),
  cost_per_1k numeric(16,8),
  latency_ms numeric(12,2),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(model_key,provider,version)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS model_key text;
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS provider text;
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS version text;
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS evaluation_score numeric(8,4);
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS cost_per_1k numeric(16,8);
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS latency_ms numeric(12,2);
ALTER TABLE IF EXISTS public.ai_model_versions ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS ai_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  entity_type text NOT NULL,
  entity_id text NOT NULL,
  claim text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  confidence numeric(6,5),
  model_version text,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS entity_type text;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS entity_id text;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS claim text;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS confidence numeric(6,5);
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS model_version text;
ALTER TABLE IF EXISTS public.ai_claims ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_ai_claims_entity ON ai_claims(entity_type,entity_id,created_at DESC);

CREATE TABLE IF NOT EXISTS ai_claim_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id uuid NOT NULL,
  source text,
  source_url text,
  excerpt text,
  evidence_strength numeric(6,5) DEFAULT 0.5,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS claim_id uuid;
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS source_url text;
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS excerpt text;
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS evidence_strength numeric(6,5);
ALTER TABLE IF EXISTS public.ai_claim_evidence ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS review_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL,
  source text,
  theme text NOT NULL,
  sentiment numeric(6,3),
  mention_count integer NOT NULL DEFAULT 1,
  examples jsonb NOT NULL DEFAULT '[]',
  observed_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS theme text;
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS sentiment numeric(6,3);
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS mention_count integer;
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS examples jsonb;
ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS observed_at timestamptz;

-- LeadX schema compatibility repair for older installations.
DO $$ BEGIN
  ALTER TABLE IF EXISTS public.review_insights ADD COLUMN IF NOT EXISTS observed_at timestamptz NOT NULL DEFAULT now();
END $$;

CREATE INDEX IF NOT EXISTS idx_review_insights_lead ON review_insights(lead_id,mention_count DESC);

CREATE TABLE IF NOT EXISTS discovery_frontier (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vertical_key text NOT NULL,
  source text NOT NULL,
  location_key text NOT NULL,
  query_key text NOT NULL,
  state text NOT NULL DEFAULT 'active' CHECK(state IN ('active','exhausted','blocked','failed','stale')),
  page_reached integer NOT NULL DEFAULT 0,
  raw_found bigint NOT NULL DEFAULT 0,
  unique_found bigint NOT NULL DEFAULT 0,
  last_yield bigint NOT NULL DEFAULT 0,
  last_run_at timestamptz,
  exhausted_at timestamptz,
  last_error text,
  metadata jsonb NOT NULL DEFAULT '{}',
  UNIQUE(vertical_key,source,location_key,query_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS vertical_key text;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS location_key text;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS query_key text;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS page_reached integer;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS raw_found bigint;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS unique_found bigint;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS last_yield bigint;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS exhausted_at timestamptz;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE IF EXISTS public.discovery_frontier ADD COLUMN IF NOT EXISTS metadata jsonb;

CREATE INDEX IF NOT EXISTS idx_discovery_frontier_state ON discovery_frontier(state,last_run_at);

CREATE TABLE IF NOT EXISTS inventory_freshness (
  lead_id uuid PRIMARY KEY,
  last_verified_at timestamptz,
  next_refresh_at timestamptz,
  change_probability numeric(6,5) DEFAULT 0.5,
  priority numeric(8,3) DEFAULT 0,
  status text NOT NULL DEFAULT 'fresh'
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.inventory_freshness ADD COLUMN IF NOT EXISTS lead_id uuid;
ALTER TABLE IF EXISTS public.inventory_freshness ADD COLUMN IF NOT EXISTS last_verified_at timestamptz;
ALTER TABLE IF EXISTS public.inventory_freshness ADD COLUMN IF NOT EXISTS next_refresh_at timestamptz;
ALTER TABLE IF EXISTS public.inventory_freshness ADD COLUMN IF NOT EXISTS change_probability numeric(6,5);
ALTER TABLE IF EXISTS public.inventory_freshness ADD COLUMN IF NOT EXISTS priority numeric(8,3);
ALTER TABLE IF EXISTS public.inventory_freshness ADD COLUMN IF NOT EXISTS status text;


CREATE TABLE IF NOT EXISTS unit_economics_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  period_start date NOT NULL,
  period_end date NOT NULL,
  revenue numeric(16,2) DEFAULT 0,
  provider_cost numeric(16,2) DEFAULT 0,
  ai_cost numeric(16,2) DEFAULT 0,
  email_cost numeric(16,2) DEFAULT 0,
  other_cost numeric(16,2) DEFAULT 0,
  gross_margin numeric(16,2) DEFAULT 0,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS period_start date;
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS period_end date;
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS revenue numeric(16,2);
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS provider_cost numeric(16,2);
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS ai_cost numeric(16,2);
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS email_cost numeric(16,2);
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS other_cost numeric(16,2);
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS gross_margin numeric(16,2);
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.unit_economics_snapshots ADD COLUMN IF NOT EXISTS created_at timestamptz;


-- Atomic idempotency primitive. The unique constraint is the correctness guard.
CREATE OR REPLACE FUNCTION claim_operation_idempotency(
  p_key text, p_operation text, p_tenant_id uuid DEFAULT NULL
) RETURNS TABLE(acquired boolean, existing_response jsonb)
LANGUAGE plpgsql AS $$
DECLARE r jsonb;
BEGIN
  INSERT INTO operation_idempotency(idempotency_key,operation,tenant_id,status,response)
  VALUES(p_key,p_operation,p_tenant_id,'processing','{}')
  ON CONFLICT(idempotency_key,operation) DO NOTHING;
  IF FOUND THEN RETURN QUERY SELECT true, NULL::jsonb; RETURN; END IF;
  SELECT response INTO r FROM operation_idempotency WHERE idempotency_key=p_key AND operation=p_operation LIMIT 1;
  RETURN QUERY SELECT false, r;
END; $$;

CREATE OR REPLACE FUNCTION finish_operation_idempotency(
  p_key text, p_operation text, p_response jsonb, p_status text DEFAULT 'completed'
) RETURNS void LANGUAGE sql AS $$
  UPDATE operation_idempotency SET response=COALESCE(p_response,'{}'), status=p_status
  WHERE idempotency_key=p_key AND operation=p_operation;
$$;

-- Useful secure helper for platform admin checks. The service role executes it.
CREATE OR REPLACE FUNCTION is_platform_admin(p_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE AS $$
  SELECT EXISTS(SELECT 1 FROM platform_admins WHERE user_id=p_user_id AND active=true);
$$;

-- Backend-owned data: deny direct client access by default. The service role
-- used by the FastAPI API bypasses RLS; tenant access is enforced in the API.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY[
    'platform_admins','audit_log','security_events','queue_metrics','provider_health',
    'data_lineage','lead_signals','lead_opportunities','contact_graph_edges','company_change_events',
    'website_audits','technographics','lead_quality_reports','lead_replacement_events','campaign_guardrails',
    'email_domain_health','compliance_events','workflow_definitions','workflow_runs','product_events',
    'daily_briefs','next_best_actions','export_audit','data_subject_requests','feature_flags',
    'ai_model_versions','ai_claims','ai_claim_evidence','review_insights','discovery_frontier',
    'inventory_freshness','unit_economics_snapshots'
  ] LOOP
    EXECUTE format('ALTER TABLE IF EXISTS %I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- LeadX runtime schema repair / compatibility migration.
-- Safe to run against an existing installation. This repairs runtime tables that
-- were referenced by application code but were missing from older migration
-- chains, and backfills columns on automation tables created by early builds.

-- ---------------------------------------------------------------------------
-- Replies / inbound email
CREATE TABLE IF NOT EXISTS email_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  from_email text NOT NULL,
  subject text,
  body_text text,
  category text NOT NULL DEFAULT 'unclassified',
  message_id text,
  metadata jsonb NOT NULL DEFAULT '{}',
  received_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS from_email text;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS message_id text;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS received_at timestamptz;
ALTER TABLE IF EXISTS public.email_replies ADD COLUMN IF NOT EXISTS created_at timestamptz;

ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS from_email text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS body_text text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'unclassified';
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS message_id text;
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}';
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS received_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE email_replies ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_email_replies_tenant_received ON email_replies(tenant_id, received_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_replies_assignment ON email_replies(assignment_id, received_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_replies_category ON email_replies(tenant_id, category, received_at DESC);

-- ---------------------------------------------------------------------------
-- Tenant/global opt-out ledger. The application intentionally fails closed if
-- this table cannot be read, so it must exist before email automation is used.
CREATE TABLE IF NOT EXISTS email_optouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  email text NOT NULL,
  reason text,
  source text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.email_optouts ADD COLUMN IF NOT EXISTS updated_at timestamptz;

ALTER TABLE email_optouts ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE email_optouts ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE email_optouts ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_email_optouts_tenant_email ON email_optouts(tenant_id, email);
CREATE INDEX IF NOT EXISTS idx_email_optouts_email ON email_optouts(lower(email));

-- ---------------------------------------------------------------------------
-- Lead contact/touch history used by send-policy minimum-gap protection.
CREATE TABLE IF NOT EXISTS lead_touches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  channel text NOT NULL,
  meta jsonb NOT NULL DEFAULT '{}',
  touched_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS channel text;
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS touched_at timestamptz;
ALTER TABLE IF EXISTS public.lead_touches ADD COLUMN IF NOT EXISTS created_at timestamptz;

ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS channel text;
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS meta jsonb NOT NULL DEFAULT '{}';
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS touched_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE lead_touches ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_lead_touches_assignment ON lead_touches(assignment_id, touched_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_touches_tenant ON lead_touches(tenant_id, touched_at DESC);

-- ---------------------------------------------------------------------------
-- AI email/template experiment ledger.
CREATE TABLE IF NOT EXISTS template_variant_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES tenants(id) ON DELETE CASCADE,
  category text NOT NULL,
  variant_key text NOT NULL,
  sent int NOT NULL DEFAULT 0,
  opened int NOT NULL DEFAULT 0,
  replied int NOT NULL DEFAULT 0,
  positive int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS category text;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS variant_key text;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS sent int;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS opened int;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS replied int;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS positive int;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.template_variant_stats ADD COLUMN IF NOT EXISTS updated_at timestamptz;

ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS sent int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS opened int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS replied int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS positive int NOT NULL DEFAULT 0;
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE template_variant_stats ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_template_variant_stats_tenant ON template_variant_stats(tenant_id, category, variant_key) WHERE tenant_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_template_variant_stats_global ON template_variant_stats(category, variant_key) WHERE tenant_id IS NULL;

-- ---------------------------------------------------------------------------
-- Webhook idempotency ledger.
CREATE TABLE IF NOT EXISTS webhook_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id text NOT NULL UNIQUE,
  source text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  received_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.webhook_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.webhook_events ADD COLUMN IF NOT EXISTS event_id text;
ALTER TABLE IF EXISTS public.webhook_events ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE IF EXISTS public.webhook_events ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.webhook_events ADD COLUMN IF NOT EXISTS received_at timestamptz;
ALTER TABLE IF EXISTS public.webhook_events ADD COLUMN IF NOT EXISTS created_at timestamptz;

ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}';
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS received_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE webhook_events ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS uq_webhook_events_event_id ON webhook_events(event_id);
CREATE INDEX IF NOT EXISTS idx_webhook_events_received ON webhook_events(received_at DESC);

-- ---------------------------------------------------------------------------
-- Automation compatibility backfill. Older installs may have created these
-- tables with a subset of the current columns. CREATE TABLE IF NOT EXISTS does
-- not add columns, so explicitly repair them here. The CREATE guards also make
-- this repair file safe to run by itself after a partially-applied migration.
CREATE TABLE IF NOT EXISTS campaign_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  icp_id uuid,
  industry text,
  locations jsonb NOT NULL DEFAULT '[]',
  queries jsonb NOT NULL DEFAULT '[]',
  params jsonb NOT NULL DEFAULT '{}',
  target_new_leads int NOT NULL DEFAULT 25,
  interval_hours int NOT NULL DEFAULT 24,
  auto_enroll_sequence_id uuid,
  active boolean NOT NULL DEFAULT true,
  last_run_at timestamptz,
  last_status text,
  last_result jsonb,
  next_run_at timestamptz NOT NULL DEFAULT now(),
  created_by text DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS industry text;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS locations jsonb;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS queries jsonb;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS params jsonb;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS target_new_leads int;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS interval_hours int;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS auto_enroll_sequence_id uuid;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS active boolean;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS last_status text;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS last_result jsonb;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS next_run_at timestamptz;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.campaign_schedules ADD COLUMN IF NOT EXISTS updated_at timestamptz;

ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS industry text;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS locations jsonb NOT NULL DEFAULT '[]';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS queries jsonb NOT NULL DEFAULT '[]';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS params jsonb NOT NULL DEFAULT '{}';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS target_new_leads int NOT NULL DEFAULT 25;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS interval_hours int NOT NULL DEFAULT 24;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS auto_enroll_sequence_id uuid;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS last_run_at timestamptz;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS last_status text;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS last_result jsonb;
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS next_run_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS created_by text DEFAULT 'admin';
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE campaign_schedules ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_schedules_due_runtime ON campaign_schedules(next_run_at) WHERE active;
CREATE INDEX IF NOT EXISTS idx_schedules_tenant_runtime ON campaign_schedules(tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS autonomous_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  icp_id uuid,
  sequence_id uuid,
  status text NOT NULL DEFAULT 'draft',
  locations jsonb NOT NULL DEFAULT '[]',
  queries jsonb NOT NULL DEFAULT '[]',
  offer text,
  goal text,
  daily_new_lead_limit int NOT NULL DEFAULT 25,
  daily_email_limit int NOT NULL DEFAULT 25,
  max_active_enrollments int NOT NULL DEFAULT 5000,
  send_window_start time NOT NULL DEFAULT '09:00',
  send_window_end time NOT NULL DEFAULT '17:00',
  timezone text NOT NULL DEFAULT 'America/New_York',
  generate_ai_copy boolean NOT NULL DEFAULT true,
  auto_followup boolean NOT NULL DEFAULT true,
  stop_on_reply boolean NOT NULL DEFAULT true,
  stop_on_optout boolean NOT NULL DEFAULT true,
  require_verified_email boolean NOT NULL DEFAULT true,
  score_threshold int NOT NULL DEFAULT 70,
  schedule_hours int NOT NULL DEFAULT 24,
  next_discovery_at timestamptz,
  last_discovery_at timestamptz,
  last_discovery_result jsonb NOT NULL DEFAULT '{}',
  created_by text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS sequence_id uuid;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS locations jsonb;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS queries jsonb;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS offer text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS goal text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_new_lead_limit int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_email_limit int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS max_active_enrollments int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_start time;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_end time;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS timezone text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS generate_ai_copy boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS auto_followup boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_reply boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_optout boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS require_verified_email boolean;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS score_threshold int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS schedule_hours int;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS next_discovery_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_result jsonb;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.autonomous_campaigns ADD COLUMN IF NOT EXISTS updated_at timestamptz;

ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS icp_id uuid;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS sequence_id uuid;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'draft';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS locations jsonb NOT NULL DEFAULT '[]';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS queries jsonb NOT NULL DEFAULT '[]';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS offer text;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS goal text;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_new_lead_limit int NOT NULL DEFAULT 25;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS daily_email_limit int NOT NULL DEFAULT 25;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS max_active_enrollments int NOT NULL DEFAULT 5000;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_start time NOT NULL DEFAULT '09:00';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS send_window_end time NOT NULL DEFAULT '17:00';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS timezone text NOT NULL DEFAULT 'America/New_York';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS generate_ai_copy boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS auto_followup boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_reply boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS stop_on_optout boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS require_verified_email boolean NOT NULL DEFAULT true;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS score_threshold int NOT NULL DEFAULT 70;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS schedule_hours int NOT NULL DEFAULT 24;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS next_discovery_at timestamptz;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_at timestamptz;
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS last_discovery_result jsonb NOT NULL DEFAULT '{}';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS created_by text NOT NULL DEFAULT 'admin';
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE autonomous_campaigns ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_autonomous_campaigns_due_runtime ON autonomous_campaigns(next_discovery_at) WHERE status = 'active';

-- The operator tenant flag is required by admin automation/prospecting.
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS is_operator boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS idx_tenants_single_operator_runtime ON tenants(is_operator) WHERE is_operator;

-- ---------------------------------------------------------------------------
-- Lightweight schema verification view/function for diagnostics. It does not
-- expose secrets and is safe for the service-key backend to query.
CREATE OR REPLACE FUNCTION leadx_runtime_schema_status()
RETURNS TABLE(object_name text, object_kind text, present boolean)
LANGUAGE sql STABLE AS $$
  SELECT x.name, x.kind,
    CASE WHEN x.kind = 'table' THEN to_regclass('public.' || x.name) IS NOT NULL
         WHEN x.kind = 'view' THEN to_regclass('public.' || x.name) IS NOT NULL
         ELSE false END AS present
  FROM (VALUES
    ('email_replies','table'),
    ('email_optouts','table'),
    ('lead_touches','table'),
    ('template_variant_stats','table'),
    ('webhook_events','table'),
    ('campaign_schedules','table'),
    ('autonomous_campaigns','table'),
    ('crm_lead_cards','view')
  ) AS x(name,kind);
$$;

-- Supabase/PostgREST may retain a schema cache briefly after DDL. Ask it to
-- reload so newly repaired tables are visible immediately to REST clients.
NOTIFY pgrst, 'reload schema';

-- PostgREST schema-cache refresh for runtime repair objects.
DO $$
BEGIN
  PERFORM pg_notify('pgrst', 'reload schema');
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;


-- ============================================================================
-- RUNTIME COMPATIBILITY: notifications
-- ============================================================================


-- ---------------------------------------------------------------------------
-- In-app notifications. Required by tenant/admin notification feeds and by
-- pipeline/SES/job handlers. Keep this in the runtime repair so an installation
-- that ran only the consolidated/safe migration cannot miss this table.
CREATE TABLE IF NOT EXISTS public.notifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope       text NOT NULL DEFAULT 'tenant'
              CHECK (scope IN ('tenant', 'admin')),
  tenant_id   uuid,
  kind        text NOT NULL,
  severity    text NOT NULL DEFAULT 'info'
              CHECK (severity IN ('info', 'warning', 'critical')),
  title       text NOT NULL,
  body        text NOT NULL DEFAULT '',
  link        text,
  meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS scope text;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS kind text;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS severity text;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS title text;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS body text;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS link text;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS meta jsonb;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS read_at timestamptz;
ALTER TABLE IF EXISTS public.notifications ADD COLUMN IF NOT EXISTS created_at timestamptz;

ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS scope text NOT NULL DEFAULT 'tenant';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'system';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS severity text NOT NULL DEFAULT 'info';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS title text NOT NULL DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS body text NOT NULL DEFAULT '';
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS link text;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS meta jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS read_at timestamptz;
ALTER TABLE public.notifications ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_notifications_scope_created ON public.notifications(scope, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_tenant_unread ON public.notifications(tenant_id, created_at DESC) WHERE read_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_notifications_admin_unread ON public.notifications(scope, created_at DESC) WHERE scope = 'admin' AND read_at IS NULL;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "service_all_notifications" ON public.notifications;
CREATE POLICY "service_all_notifications" ON public.notifications FOR ALL TO service_role USING (true) WITH CHECK (true);

NOTIFY pgrst, 'reload schema';
DO $$
BEGIN
  PERFORM pg_notify('pgrst', 'reload schema');
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;

-- LeadX realtime hardening (idempotent; safe after CRM tables exist)
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'companies','contacts','deals','deal_stages','activities','tasks','notes','pipeline_stages',
    'lead_assignments','lead_activities','lead_tasks','notifications','discovery_requests'
  ] LOOP
    BEGIN
      EXECUTE format('ALTER TABLE public.%I REPLICA IDENTITY FULL', t);
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    EXCEPTION WHEN duplicate_object THEN NULL;
    WHEN undefined_table THEN NULL;
    WHEN undefined_object THEN NULL;
    END;
  END LOOP;
END $$;


-- 043_FAST_DASHBOARD_SNAPSHOT.sql included
-- 043_FAST_DASHBOARD_SNAPSHOT.sql
CREATE OR REPLACE FUNCTION public.crm_dashboard_snapshot(p_tenant_id uuid)
RETURNS jsonb
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
WITH cards AS (
  SELECT
    COALESCE(cc.stage_slug, 'new') AS stage_slug,
    COALESCE(cc.tier, 'C') AS tier
  FROM public.crm_lead_cards cc
  WHERE cc.tenant_id = p_tenant_id
),
c AS (
  SELECT
    count(*)::int AS total,
    count(*) FILTER (WHERE tier = 'A')::int AS tier_a,
    count(*) FILTER (WHERE tier = 'B')::int AS tier_b,
    count(*) FILTER (WHERE tier = 'C')::int AS tier_c,
    count(*) FILTER (WHERE stage_slug = 'new')::int AS new_count,
    count(*) FILTER (WHERE stage_slug = 'won')::int AS won,
    count(*) FILTER (WHERE stage_slug = 'lost')::int AS lost
  FROM cards
),
sc AS (
  SELECT
    ps.name,
    ps.slug,
    ps.color,
    ps.position,
    COALESCE(x.cnt, 0)::int AS count
  FROM public.pipeline_stages ps
  LEFT JOIN (
    SELECT stage_slug, count(*) AS cnt
    FROM cards
    GROUP BY stage_slug
  ) x ON x.stage_slug = ps.slug
  WHERE ps.tenant_id = p_tenant_id
  ORDER BY ps.position
),
t AS (
  SELECT to_jsonb(tn) - 'id' - 'created_at' - 'updated_at' AS value
  FROM public.tenants tn
  WHERE tn.id = p_tenant_id
  LIMIT 1
),
u AS (
  SELECT to_jsonb(ul) AS value
  FROM public.usage_log ul
  WHERE ul.tenant_id = p_tenant_id
    AND ul.period = date_trunc('month', now())::date
  LIMIT 1
),
td AS (
  SELECT COALESCE(
    jsonb_agg(to_jsonb(x) ORDER BY x.due_at NULLS LAST),
    '[]'::jsonb
  ) AS value
  FROM (
    SELECT id, title, due_at, priority, assignment_id
    FROM public.lead_tasks
    WHERE tenant_id = p_tenant_id
      AND status = 'open'
    ORDER BY due_at NULLS LAST
    LIMIT 10
  ) x
),
ac AS (
  SELECT COALESCE(
    jsonb_agg(to_jsonb(x) ORDER BY x.created_at DESC),
    '[]'::jsonb
  ) AS value
  FROM (
    SELECT id, activity_type, title, body, created_at, assignment_id
    FROM public.lead_activities
    WHERE tenant_id = p_tenant_id
    ORDER BY created_at DESC
    LIMIT 15
  ) x
),
tr AS (
  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'date', gs.day::date,
        'count', COALESCE(x.cnt, 0)
      )
      ORDER BY gs.day
    ),
    '[]'::jsonb
  ) AS value
  FROM generate_series(
    current_date - 6,
    current_date,
    interval '1 day'
  ) AS gs(day)
  LEFT JOIN (
    SELECT
      delivered_at::date AS delivered_day,
      count(*) AS cnt
    FROM public.lead_assignments
    WHERE tenant_id = p_tenant_id
      AND delivered_at >= current_date - 6
    GROUP BY delivered_at::date
  ) x ON x.delivered_day = gs.day::date
)
SELECT jsonb_build_object(
  'tenant', COALESCE((SELECT value FROM t), 'null'::jsonb),
  'kpis', jsonb_build_object(
    'total_leads', c.total,
    'tier_a', c.tier_a,
    'tier_b', c.tier_b,
    'tier_c', c.tier_c,
    'new', c.new_count,
    'in_pipeline', GREATEST(c.total - c.won - c.lost, 0),
    'won', c.won,
    'lost', c.lost,
    'win_rate_pct', CASE
      WHEN c.won + c.lost = 0 THEN 0
      ELSE round(100.0 * c.won / (c.won + c.lost), 1)
    END
  ),
  'funnel', COALESCE((SELECT jsonb_agg(to_jsonb(sc) ORDER BY sc.position) FROM sc), '[]'::jsonb),
  'usage', COALESCE((SELECT value FROM u), 'null'::jsonb),
  'quota_limit', COALESCE((SELECT leads_per_month_limit FROM public.tenants WHERE id = p_tenant_id), 0),
  'tasks_due', (SELECT value FROM td),
  'recent_activity', (SELECT value FROM ac),
  'trend', (SELECT value FROM tr)
)
FROM c;
$$;
GRANT EXECUTE ON FUNCTION public.crm_dashboard_snapshot(uuid) TO service_role;


-- BEGIN competitive moat 2026-09-30
-- LeadX competitive moat release: quality guarantee, playbooks, integrations, territory locks.
CREATE INDEX IF NOT EXISTS idx_leads_global_category_city_state_score
  ON public.leads_global (category, city, state, google_rating DESC, review_count DESC);

ALTER TABLE public.lead_credits ADD COLUMN IF NOT EXISTS credited_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS quality_deadline_at timestamptz;
UPDATE public.lead_assignments SET quality_deadline_at = delivered_at + interval '14 days'
 WHERE delivered_at IS NOT NULL AND quality_deadline_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_assignments_quality_deadline ON public.lead_assignments(tenant_id, quality_deadline_at, status);

CREATE TABLE IF NOT EXISTS public.playbooks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), slug text UNIQUE NOT NULL, name text NOT NULL, vertical text NOT NULL,
 icp_defaults jsonb NOT NULL DEFAULT '{}', scoring_weights jsonb NOT NULL DEFAULT '{}', pitch_lines jsonb NOT NULL DEFAULT '[]',
 objection_handlers jsonb NOT NULL DEFAULT '[]', call_script text, sequence_steps jsonb NOT NULL DEFAULT '[]', active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.playbooks ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.playbooks ADD COLUMN IF NOT EXISTS icp_defaults jsonb;
ALTER TABLE IF EXISTS public.playbooks ADD COLUMN IF NOT EXISTS objection_handlers jsonb;
ALTER TABLE IF EXISTS public.playbooks ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE TABLE IF NOT EXISTS public.tenant_playbooks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 playbook_id uuid NOT NULL REFERENCES playbooks(id) ON DELETE CASCADE, config jsonb NOT NULL DEFAULT '{}', active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id, playbook_id)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.tenant_playbooks ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.tenant_playbooks ADD COLUMN IF NOT EXISTS playbook_id uuid;
ALTER TABLE IF EXISTS public.tenant_playbooks ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS public.territory_locks (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, vertical text NOT NULL, geo_key text NOT NULL,
 stripe_subscription_id text, status text NOT NULL DEFAULT 'active', starts_at timestamptz NOT NULL DEFAULT now(), ends_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(vertical, geo_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.territory_locks ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.territory_locks ADD COLUMN IF NOT EXISTS stripe_subscription_id text;
ALTER TABLE IF EXISTS public.territory_locks ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.territory_locks ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE TABLE IF NOT EXISTS public.integration_field_maps (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE, provider text NOT NULL,
 mapping jsonb NOT NULL DEFAULT '{}', stage_mapping jsonb NOT NULL DEFAULT '{}', auto_push boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id, provider)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.integration_field_maps ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.integration_field_maps ADD COLUMN IF NOT EXISTS mapping jsonb;
ALTER TABLE IF EXISTS public.integration_field_maps ADD COLUMN IF NOT EXISTS created_at timestamptz;


ALTER TABLE public.usage_log ADD COLUMN IF NOT EXISTS rollover_credits integer NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS idx_usage_log_tenant_period ON public.usage_log(tenant_id, period DESC);

CREATE OR REPLACE FUNCTION public.tenant_quota_remaining(p_tenant_id uuid) RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE lim int; used int; reserved int; rollover int; p date := date_trunc('month', now())::date;
BEGIN
 SELECT COALESCE(leads_per_month_limit,0) INTO lim FROM tenants WHERE id=p_tenant_id;
 SELECT COALESCE(leads_delivered,0), COALESCE(quota_reserved,0), COALESCE(rollover_credits,0) INTO used,reserved,rollover FROM usage_log WHERE tenant_id=p_tenant_id AND period=p;
 RETURN GREATEST(lim+rollover-COALESCE(used,0)-COALESCE(reserved,0),0);
END; $$;

-- Seed four launch playbooks; ON CONFLICT keeps this migration idempotent.
INSERT INTO public.playbooks(slug,name,vertical,icp_defaults,scoring_weights,pitch_lines,objection_handlers,call_script,sequence_steps) VALUES
('medspa','Med Spa Growth','medspa','{"min_reviews":40,"has_website":true}','{"reviews":0.2,"booking":0.2,"intent":0.25,"contactability":0.2}','["Your booking flow is leaking demand"]','["We already have an agency"]','Open with the strongest booking/review signal and ask one operational question.','[{"step":1,"delay_days":0},{"step":2,"delay_days":2},{"step":3,"delay_days":5},{"step":4,"delay_days":9},{"step":5,"delay_days":14}]'),
('gym','Gym Growth','gym','{"min_reviews":30,"has_website":true}','{"reviews":0.2,"booking":0.15,"intent":0.3,"contactability":0.2}','["Your lead-response gap is costing trials"]','["We are full"]','Lead with trial conversion and response-time signal.','[{"step":1,"delay_days":0},{"step":2,"delay_days":2},{"step":3,"delay_days":5},{"step":4,"delay_days":9},{"step":5,"delay_days":14}]'),
('salon','Salon Growth','salon','{"min_reviews":30,"has_website":true}','{"reviews":0.25,"booking":0.2,"intent":0.25,"contactability":0.2}','["Turn missed booking demand into appointments"]','["Instagram is enough"]','Lead with booking friction and review evidence.','[{"step":1,"delay_days":0},{"step":2,"delay_days":2},{"step":3,"delay_days":5},{"step":4,"delay_days":9},{"step":5,"delay_days":14}]'),
('dental','Dental Growth','dental','{"min_reviews":50,"has_website":true}','{"reviews":0.25,"booking":0.2,"intent":0.25,"contactability":0.2}','["Convert high-intent local searches into booked patients"]','["We get enough referrals"]','Lead with local visibility and booking-response evidence.','[{"step":1,"delay_days":0},{"step":2,"delay_days":2},{"step":3,"delay_days":5},{"step":4,"delay_days":9},{"step":5,"delay_days":14}]')
ON CONFLICT(slug) DO NOTHING;

-- END competitive moat 2026-09-30

-- competitive outcome events
CREATE TABLE IF NOT EXISTS public.lead_outcome_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
 assignment_id uuid NOT NULL REFERENCES lead_assignments(id) ON DELETE CASCADE, lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
 outcome text NOT NULL CHECK (outcome IN ('no_answer','booked','not_interested','won')), note text, recorded_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS outcome text;

CREATE INDEX IF NOT EXISTS idx_lead_outcome_events_tenant_time ON public.lead_outcome_events(tenant_id,recorded_at DESC);


-- sql/052_AGENT_OS_REPAIR_2026-09-30.sql
-- LeadX Agent OS: durable agent runs, memory and human feedback.
CREATE TABLE IF NOT EXISTS agent_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  agent_id text NOT NULL,
  task text NOT NULL DEFAULT '',
  input_data jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','done','failed','cancelled')),
  result jsonb NOT NULL DEFAULT '{}',
  error text,
  created_by text NOT NULL DEFAULT 'user',
  created_at timestamptz NOT NULL DEFAULT now(),
  started_at timestamptz,
  finished_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS agent_id text;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS task text;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS input_data jsonb;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS result jsonb;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS created_by text;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS finished_at timestamptz;
ALTER TABLE IF EXISTS public.agent_runs ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_agent_runs_tenant_time ON agent_runs(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_runs_status ON agent_runs(status, created_at DESC);

CREATE TABLE IF NOT EXISTS agent_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  agent_id text NOT NULL,
  memory_key text NOT NULL,
  memory_value jsonb NOT NULL DEFAULT '{}',
  confidence numeric(5,4) NOT NULL DEFAULT 0.5,
  source_run_id uuid,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, agent_id, memory_key)
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS agent_id text;
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS memory_key text;
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS memory_value jsonb;
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS confidence numeric(5,4);
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS source_run_id uuid;
ALTER TABLE IF EXISTS public.agent_memory ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_agent_memory_tenant ON agent_memory(tenant_id, agent_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS agent_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  agent_id text NOT NULL,
  run_id uuid,
  feedback text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS agent_id text;
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS run_id uuid;
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS feedback text;
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS metadata jsonb;
ALTER TABLE IF EXISTS public.agent_feedback ADD COLUMN IF NOT EXISTS created_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_agent_feedback_tenant ON agent_feedback(tenant_id, created_at DESC);



-- sql/053_EMAIL_VERIFICATION_REPAIR_2026-09-30.sql
-- LeadX production account verification + billing hardening.
-- Apply after the existing migrations.

CREATE TABLE IF NOT EXISTS email_verification_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  auth_user_id uuid,
  code_hash text NOT NULL,
  purpose text NOT NULL DEFAULT 'signup',
  expires_at timestamptz NOT NULL,
  attempts int NOT NULL DEFAULT 0,
  consumed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
-- LeadX compatibility sweep: reconcile legacy table shapes before downstream statements.
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS id uuid;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS auth_user_id uuid;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS code_hash text;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS purpose text;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS expires_at timestamptz;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS attempts int;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS consumed_at timestamptz;
ALTER TABLE IF EXISTS public.email_verification_codes ADD COLUMN IF NOT EXISTS created_at timestamptz;


CREATE INDEX IF NOT EXISTS idx_email_verification_codes_email
  ON email_verification_codes(lower(email), purpose, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_verification_codes_expiry
  ON email_verification_codes(expires_at);

-- Only one active code should be valid for a given address/purpose at a time.
CREATE UNIQUE INDEX IF NOT EXISTS uq_email_verification_active
  ON email_verification_codes(lower(email), purpose)
  WHERE consumed_at IS NULL;

ALTER TABLE tenants ADD COLUMN IF NOT EXISTS email_verified_at timestamptz;
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS email_verification_required boolean NOT NULL DEFAULT true;



-- Atomic OTP-attempt increment: prevents concurrent guesses from bypassing the 5-attempt cap.
CREATE OR REPLACE FUNCTION public.consume_email_verification_attempt(p_code_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.email_verification_codes
     SET attempts = attempts + 1
   WHERE id = p_code_id
     AND consumed_at IS NULL
     AND attempts < 5
  RETURNING true;
$$;

REVOKE ALL ON FUNCTION public.consume_email_verification_attempt(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.consume_email_verification_attempt(uuid) TO service_role;

-- ============================================================================
-- CANONICAL MIGRATION 02: 20260930000100_integration_deliveries.sql
-- ============================================================================

-- LeadX release repair: integration delivery idempotency/audit log.
CREATE TABLE IF NOT EXISTS public.integration_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  assignment_id uuid NOT NULL,
  provider text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  attempt integer NOT NULL DEFAULT 1,
  http_code integer,
  error text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_integration_deliveries_lookup ON public.integration_deliveries(tenant_id,assignment_id,provider,status);

-- ============================================================================
-- CANONICAL MIGRATION 03: 20260930000200_competitive_upgrade.sql
-- ============================================================================

-- LeadX competitive upgrade (2026-09-30): two-way CRM sync, agency sub-accounts,
-- white-label reports, public scoreboard snapshots, waterfall provider stats.
-- Idempotent. Service-role API access only (RLS enabled, no anon policies).

-- 1) Agency sub-accounts -------------------------------------------------------
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS parent_tenant_id uuid REFERENCES public.tenants(id) ON DELETE SET NULL;
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS report_footer text;
CREATE INDEX IF NOT EXISTS idx_tenants_parent ON public.tenants(parent_tenant_id) WHERE parent_tenant_id IS NOT NULL;

-- A tenant may not be its own parent and hierarchy is a single level.
DO $$ BEGIN
  ALTER TABLE public.tenants ADD CONSTRAINT tenants_no_self_parent CHECK (parent_tenant_id IS NULL OR parent_tenant_id <> id);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION public.enforce_single_level_tenant() RETURNS trigger AS $$
BEGIN
  IF NEW.parent_tenant_id IS NOT NULL AND EXISTS (
       SELECT 1 FROM public.tenants p WHERE p.id = NEW.parent_tenant_id AND p.parent_tenant_id IS NOT NULL) THEN
    RAISE EXCEPTION 'sub-accounts cannot have children';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_single_level_tenant ON public.tenants;
CREATE TRIGGER trg_single_level_tenant BEFORE INSERT OR UPDATE OF parent_tenant_id ON public.tenants
  FOR EACH ROW EXECUTE FUNCTION public.enforce_single_level_tenant();

-- 2) Two-way CRM sync ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.crm_sync_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider text NOT NULL,
  account_id text NOT NULL,
-- HubSpot portalId / GHL locationId: external ids are only unique per account
  external_id text NOT NULL,
  assignment_id uuid NOT NULL,
  lead_id uuid NOT NULL,
  outcome text,
  last_synced_ms bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, account_id, external_id)
);
CREATE INDEX IF NOT EXISTS idx_crm_sync_links_assignment ON public.crm_sync_links(tenant_id, assignment_id);

CREATE TABLE IF NOT EXISTS public.crm_sync_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  event_id text NOT NULL,
  status text NOT NULL,
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, event_id)
);

CREATE TABLE IF NOT EXISTS public.crm_sync_echo (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  provider text NOT NULL,
  external_id text NOT NULL,
  value_hash text NOT NULL,
  written_epoch double precision NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_crm_sync_echo_lookup ON public.crm_sync_echo(tenant_id, provider, external_id, value_hash, written_epoch DESC);

-- 3) Signals: free-form types (old installs had a closed CHECK list) ------------
ALTER TABLE IF EXISTS public.lead_signals DROP CONSTRAINT IF EXISTS lead_signals_signal_type_check;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS angle text;
ALTER TABLE IF EXISTS public.lead_signals ADD COLUMN IF NOT EXISTS text text;
DO $$ BEGIN
  CREATE UNIQUE INDEX IF NOT EXISTS uq_lead_signals_dedupe
    ON public.lead_signals(lead_id, signal_type, source, observed_at);
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'uq_lead_signals_dedupe skipped (existing duplicates): %', SQLERRM;
END $$;

-- 4) Public scoreboard snapshots ------------------------------------------------
CREATE TABLE IF NOT EXISTS public.scoreboard_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payload jsonb NOT NULL,
  integrity_hash text NOT NULL,
  generated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_scoreboard_generated ON public.scoreboard_snapshots(generated_at DESC);

-- 5) White-label client reports -------------------------------------------------
CREATE TABLE IF NOT EXISTS public.client_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  client_tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  period text NOT NULL,
  html text NOT NULL,
  metrics jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_client_reports_tenant ON public.client_reports(tenant_id, created_at DESC);

-- 6) Waterfall provider hit-rate stats -------------------------------------------
CREATE TABLE IF NOT EXISTS public.enrichment_provider_stats (
  id text PRIMARY KEY DEFAULT 'global',
  snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- RLS on, no policies: only the service role (API/worker) can touch these.
ALTER TABLE public.crm_sync_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crm_sync_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crm_sync_echo ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scoreboard_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enrichment_provider_stats ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- CANONICAL MIGRATION 04: 20260930000300_autonomous_revenue_os.sql
-- ============================================================================

-- LeadX Autonomous Revenue OS upgrade (2026-09-30)
-- Goal-driven agents, account memory, command history and durable orchestration state.
-- Idempotent; service-role application access with RLS enabled.

CREATE TABLE IF NOT EXISTS public.agent_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  agent_id text NOT NULL,
  goal_type text NOT NULL DEFAULT 'maintain_inventory',
  target jsonb NOT NULL DEFAULT '{}',
  current_state jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','completed','failed')),
  interval_minutes integer NOT NULL DEFAULT 60 CHECK (interval_minutes >= 15 AND interval_minutes <= 10080),
  next_run_at timestamptz NOT NULL DEFAULT now(),
  last_run_at timestamptz,
  last_run_id uuid,
  last_error text,
  created_by text NOT NULL DEFAULT 'user',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_goals_due ON public.agent_goals(status, next_run_at);
CREATE INDEX IF NOT EXISTS idx_agent_goals_tenant ON public.agent_goals(tenant_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS public.lead_account_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  lead_id uuid NOT NULL REFERENCES public.leads_global(id) ON DELETE CASCADE,
  memory_key text NOT NULL,
  memory_value jsonb NOT NULL DEFAULT '{}',
  confidence numeric(6,5) NOT NULL DEFAULT 0.5,
  source_type text NOT NULL DEFAULT 'agent',
  source_ref text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, lead_id, memory_key)
);
CREATE INDEX IF NOT EXISTS idx_account_memory_lead ON public.lead_account_memory(tenant_id, lead_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_account_memory_key ON public.lead_account_memory(tenant_id, memory_key, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.ai_command_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  command text NOT NULL,
  intent text NOT NULL,
  plan jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','queued','running','done','failed')),
  agent_run_id uuid,
  result jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ai_command_runs_tenant ON public.ai_command_runs(tenant_id, created_at DESC);

ALTER TABLE public.agent_runs ADD COLUMN IF NOT EXISTS goal_id uuid REFERENCES public.agent_goals(id) ON DELETE SET NULL;
ALTER TABLE public.agent_runs ADD COLUMN IF NOT EXISTS verification jsonb NOT NULL DEFAULT '{}';
ALTER TABLE public.agent_runs ADD COLUMN IF NOT EXISTS outcome jsonb NOT NULL DEFAULT '{}';
CREATE INDEX IF NOT EXISTS idx_agent_runs_goal ON public.agent_runs(goal_id, created_at DESC) WHERE goal_id IS NOT NULL;

ALTER TABLE public.agent_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_account_memory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_command_runs ENABLE ROW LEVEL SECURITY;
-- These tables are intentionally service-role only; API tenant authorization is enforced before access.

CREATE OR REPLACE FUNCTION public.leadx_touch_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_agent_goals_updated_at ON public.agent_goals;
CREATE TRIGGER trg_agent_goals_updated_at BEFORE UPDATE ON public.agent_goals FOR EACH ROW EXECUTE FUNCTION public.leadx_touch_updated_at();
DROP TRIGGER IF EXISTS trg_account_memory_updated_at ON public.lead_account_memory;
CREATE TRIGGER trg_account_memory_updated_at BEFORE UPDATE ON public.lead_account_memory FOR EACH ROW EXECUTE FUNCTION public.leadx_touch_updated_at();
DROP TRIGGER IF EXISTS trg_ai_command_runs_updated_at ON public.ai_command_runs;
CREATE TRIGGER trg_ai_command_runs_updated_at BEFORE UPDATE ON public.ai_command_runs FOR EACH ROW EXECUTE FUNCTION public.leadx_touch_updated_at();

-- ============================================================================
-- CANONICAL MIGRATION 05: 20260930000400_core_engine_2.sql
-- ============================================================================

-- LeadX Core Engine 2.0: provider intelligence, field provenance, coverage and outcomes.
CREATE TABLE IF NOT EXISTS public.core_provider_registry (
  provider text PRIMARY KEY,
  kind text NOT NULL,
  capabilities jsonb NOT NULL DEFAULT '[]'::jsonb,
  enabled boolean NOT NULL DEFAULT true,
  cost_estimate numeric(12,4) NOT NULL DEFAULT 0,
  priority numeric(8,4) NOT NULL DEFAULT 1,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.core_provider_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider text NOT NULL,
  operation text NOT NULL,
  field_name text,
  status text NOT NULL,
  latency_ms integer,
  cost numeric(12,4) DEFAULT 0,
  confidence numeric(6,5),
  verified boolean,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_core_provider_obs ON public.core_provider_observations(provider, operation, created_at DESC);

CREATE TABLE IF NOT EXISTS public.core_field_provenance (
  lead_id uuid NOT NULL,
  field_name text NOT NULL,
  value_hash text,
  provider text,
  confidence numeric(6,5) DEFAULT 0,
  verified boolean NOT NULL DEFAULT false,
  observed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  PRIMARY KEY (lead_id, field_name)
);
CREATE INDEX IF NOT EXISTS idx_core_field_freshness ON public.core_field_provenance(expires_at);

CREATE TABLE IF NOT EXISTS public.core_discovery_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  vertical text,
  locations jsonb NOT NULL DEFAULT '[]'::jsonb,
  objective text NOT NULL DEFAULT 'qualified_pipeline',
  source_telemetry jsonb NOT NULL DEFAULT '{}'::jsonb,
  raw_count bigint NOT NULL DEFAULT 0,
  resolved_count bigint NOT NULL DEFAULT 0,
  final_count bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_core_discovery_runs ON public.core_discovery_runs(tenant_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.core_lead_outcomes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  lead_id uuid,
  provider_sources jsonb NOT NULL DEFAULT '[]'::jsonb,
  opportunity_score numeric(8,3),
  outcome text NOT NULL,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_core_outcomes_lead ON public.core_lead_outcomes(tenant_id, lead_id, created_at DESC);

ALTER TABLE public.core_provider_registry ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.core_provider_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.core_field_provenance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.core_discovery_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.core_lead_outcomes ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- CANONICAL MIGRATION 06: 20260930000500_enrichment_intelligence_mesh.sql
-- ============================================================================

-- LeadX Core Engine 5.0: field-level enrichment provenance and provider telemetry.
CREATE TABLE IF NOT EXISTS enrichment_field_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  value_json jsonb,
  provider text NOT NULL,
  source_url text,
  confidence numeric(5,4),
  observed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  verified boolean NOT NULL DEFAULT false,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (lead_id, field_name, provider, observed_at)
);
CREATE INDEX IF NOT EXISTS idx_enrichment_obs_lead_field ON enrichment_field_observations(lead_id, field_name, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_enrichment_obs_provider ON enrichment_field_observations(provider, observed_at DESC);

CREATE TABLE IF NOT EXISTS enrichment_provider_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  field_name text NOT NULL,
  tenant_id uuid,
  calls integer NOT NULL DEFAULT 0,
  hits integer NOT NULL DEFAULT 0,
  verified_hits integer NOT NULL DEFAULT 0,
  conflicts integer NOT NULL DEFAULT 0,
  estimated_cost numeric(12,4) NOT NULL DEFAULT 0,
  latency_ms integer,
  observed_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_enrichment_provider_obs ON enrichment_provider_observations(provider, field_name, observed_at DESC);

ALTER TABLE enrichment_field_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrichment_provider_observations ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF to_regclass('public.lead_assignments') IS NOT NULL THEN
    CREATE POLICY enrichment_obs_select ON enrichment_field_observations FOR SELECT
      USING (EXISTS (SELECT 1 FROM lead_assignments la WHERE la.lead_id = enrichment_field_observations.lead_id AND la.tenant_id = auth.uid()));
  END IF;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============================================================================
-- CANONICAL MIGRATION 07: 20260930000600_lead_intelligence_6.sql
-- ============================================================================

-- LeadX 6.0: post-enrichment intelligence, verification, quality gating,
-- assignment, delivery and closed-loop learning.

ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS lead_state text NOT NULL DEFAULT 'DISCOVERED';
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS priority_score numeric(6,2);
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS data_quality_score numeric(6,2);
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS lead_value_score numeric(12,2);
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS risk_score numeric(6,2) DEFAULT 0;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS email_status text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS email_verified_at timestamptz;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_status text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS phone_verified_at timestamptz;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS freshness_score numeric(6,2);
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS gate_decision text;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS gate_reasons jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS negative_signals jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE leads_global ADD COLUMN IF NOT EXISTS next_reverify_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_leads_global_6_priority ON leads_global(priority_score DESC) WHERE lead_state NOT IN ('WON','LOST','SUPPRESSED','DUPLICATE');
CREATE INDEX IF NOT EXISTS idx_leads_global_6_state ON leads_global(lead_state, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_global_6_gate ON leads_global(gate_decision, priority_score DESC);

CREATE TABLE IF NOT EXISTS lead_score_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid, model_version text NOT NULL DEFAULT 'leadx-6.0', dimensions jsonb NOT NULL DEFAULT '{}'::jsonb,
  overall numeric(6,2) NOT NULL DEFAULT 0, priority text, reasons jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_scores_lead_time ON lead_score_snapshots(lead_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_scores_tenant_priority ON lead_score_snapshots(tenant_id, overall DESC, created_at DESC);

CREATE TABLE IF NOT EXISTS lead_field_truth (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  field_name text NOT NULL, canonical_value jsonb, confidence numeric(6,2) NOT NULL DEFAULT 0,
  conflict boolean NOT NULL DEFAULT false, alternatives jsonb NOT NULL DEFAULT '[]'::jsonb,
  evidence jsonb NOT NULL DEFAULT '[]'::jsonb, resolved_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(lead_id, field_name)
);
CREATE INDEX IF NOT EXISTS idx_lead_truth_field ON lead_field_truth(lead_id, field_name);

CREATE TABLE IF NOT EXISTS lead_quality_gates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid, decision text NOT NULL, reasons jsonb NOT NULL DEFAULT '[]'::jsonb,
  score numeric(6,2), evaluated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(lead_id, tenant_id)
);
CREATE INDEX IF NOT EXISTS idx_quality_gates_tenant_decision ON lead_quality_gates(tenant_id, decision, evaluated_at DESC);

CREATE TABLE IF NOT EXISTS lead_state_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid, from_state text, to_state text NOT NULL, event text NOT NULL, reason text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_state_history ON lead_state_history(lead_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_state_tenant ON lead_state_history(tenant_id, to_state, created_at DESC);

CREATE TABLE IF NOT EXISTS lead_routing_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL, rep_id uuid, score numeric(8,2), reason text, candidates jsonb NOT NULL DEFAULT '[]'::jsonb,
  assigned_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_routing_tenant ON lead_routing_decisions(tenant_id, assigned_at DESC);

CREATE TABLE IF NOT EXISTS lead_delivery_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL, action text NOT NULL, channel text, recipient_id uuid, reason text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb, delivered_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_lead_delivery_tenant ON lead_delivery_events(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_delivery_lead ON lead_delivery_events(lead_id, created_at DESC);

CREATE TABLE IF NOT EXISTS lead_verification_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid, contact_type text NOT NULL CHECK(contact_type IN ('email','phone')), contact_value text NOT NULL,
  provider text NOT NULL, status text, confidence numeric(6,2), metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  verified_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_lead_verification_contact ON lead_verification_observations(lead_id, contact_type, verified_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_verification_provider ON lead_verification_observations(provider, contact_type, verified_at DESC);

CREATE TABLE IF NOT EXISTS lead_provider_telemetry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid, provider text NOT NULL, field_name text NOT NULL,
  calls integer NOT NULL DEFAULT 0, hits integer NOT NULL DEFAULT 0, accepted integer NOT NULL DEFAULT 0,
  latency_ms integer, estimated_cost numeric(12,4) NOT NULL DEFAULT 0, observed_at timestamptz NOT NULL DEFAULT now(), metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_lead_provider_telemetry ON lead_provider_telemetry(provider, field_name, observed_at DESC);

CREATE TABLE IF NOT EXISTS lead_outcome_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL, outcome text NOT NULL, signal text, value numeric(12,2), positive boolean,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb, occurred_at timestamptz NOT NULL DEFAULT now(),
  assignment_id uuid, note text, recorded_at timestamptz NOT NULL DEFAULT now()
);
-- Reconcile the earlier CRM outcome-event shape (recorded_at/assignment_id/note)
-- with the intelligence shape (occurred_at/signal/value/positive/metadata).
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS assignment_id uuid;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS note text;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS recorded_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS signal text;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS value numeric(12,2);
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS positive boolean;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE IF EXISTS public.lead_outcome_events ADD COLUMN IF NOT EXISTS occurred_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_lead_outcomes_tenant_time ON lead_outcome_events(tenant_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_outcomes_lead ON lead_outcome_events(lead_id, occurred_at DESC);

CREATE TABLE IF NOT EXISTS tenant_icp_learning (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL, model_version text NOT NULL DEFAULT 'leadx-6.0',
  profile jsonb NOT NULL DEFAULT '{}'::jsonb, sample_size integer NOT NULL DEFAULT 0, positive_rate numeric(8,4) NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id, model_version)
);

CREATE TABLE IF NOT EXISTS lead_quality_credits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL, lead_id uuid NOT NULL REFERENCES leads_global(id) ON DELETE CASCADE,
  assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL, status text NOT NULL DEFAULT 'eligible',
  root_causes jsonb NOT NULL DEFAULT '[]'::jsonb, replacement_lead_id uuid REFERENCES leads_global(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_quality_credits_tenant ON lead_quality_credits(tenant_id, status, created_at DESC);

-- Tenant isolation. Service-role/server jobs bypass RLS; browser access is tenant scoped.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['lead_score_snapshots','lead_field_truth','lead_quality_gates','lead_state_history','lead_routing_decisions','lead_delivery_events','lead_verification_observations','lead_provider_telemetry','lead_outcome_events','tenant_icp_learning','lead_quality_credits'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

DO $$ BEGIN
  CREATE POLICY lead6_score_select ON lead_score_snapshots FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_gate_select ON lead_quality_gates FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_state_select ON lead_state_history FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_route_select ON lead_routing_decisions FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_delivery_select ON lead_delivery_events FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_verification_select ON lead_verification_observations FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_provider_select ON lead_provider_telemetry FOR SELECT USING (tenant_id = auth.uid() OR tenant_id IS NULL);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_outcome_select ON lead_outcome_events FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_icp_select ON tenant_icp_learning FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_credit_select ON lead_quality_credits FOR SELECT USING (tenant_id = auth.uid());
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE POLICY lead6_truth_select ON lead_field_truth FOR SELECT USING (EXISTS (SELECT 1 FROM lead_assignments la WHERE la.lead_id = lead_field_truth.lead_id AND la.tenant_id = auth.uid()));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============================================================================
-- CANONICAL MIGRATION 08: 20260930000700_leadx_7_runtime_wiring.sql
-- ============================================================================

-- LeadX 7.0: durable runtime wiring and schema reconciliation.
-- Safe to apply after 6.1. All statements are idempotent.

-- Outcome events are consumed by CRM sync and agency reporting. The baseline
-- schema already uses assignment_id + recorded_at; 7.0 only reconciles the
-- optional signal/metadata fields used by the runtime writers.
ALTER TABLE lead_outcome_events
  ADD COLUMN IF NOT EXISTS assignment_id uuid REFERENCES lead_assignments(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS signal text,
  ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS note text;

CREATE INDEX IF NOT EXISTS idx_lead_outcomes_assignment_time
  ON lead_outcome_events(assignment_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_outcomes_tenant_time_7
  ON lead_outcome_events(tenant_id, recorded_at DESC);

-- Runtime state history must be queryable by tenant and current state.
CREATE INDEX IF NOT EXISTS idx_lead_state_history_tenant_state_time_7
  ON lead_state_history(tenant_id, to_state, created_at DESC);

-- Assignment and delivery audit trails are operational data, not optional UI
-- decoration. These indexes make tenant timelines cheap at scale.
CREATE INDEX IF NOT EXISTS idx_lead_routing_tenant_lead_time_7
  ON lead_routing_decisions(tenant_id, lead_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_delivery_tenant_action_time_7
  ON lead_delivery_events(tenant_id, action, created_at DESC);

-- Keep the canonical lead row queryable without repeatedly joining snapshots.
CREATE INDEX IF NOT EXISTS idx_leads_global_7_delivery
  ON leads_global(lead_state, priority_score DESC, updated_at DESC)
  WHERE lead_state NOT IN ('WON','LOST','SUPPRESSED','DUPLICATE','REJECTED');

-- RLS write policies remain service-role controlled. Browser users can read
-- their tenant's state via the existing tenant-scoped SELECT policies.

-- ============================================================================
-- CANONICAL MIGRATION 09: 20260930000800_leadx_8_frontend_runtime.sql
-- ============================================================================

-- LeadX 8.0 frontend/runtime support.
-- Keeps operational logs tenant-scoped, append-only and cheap to page.
create table if not exists public.leadx_event_log (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  actor_id text,
  actor_type text not null default 'user',
  action text not null,
  resource_type text,
  resource_id text,
  summary text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_leadx_event_log_tenant_created
  on public.leadx_event_log (tenant_id, created_at desc, id desc);
create index if not exists idx_leadx_event_log_tenant_action
  on public.leadx_event_log (tenant_id, action, created_at desc);

alter table public.leadx_event_log enable row level security;

-- No client policies: the table is API/service-role only. The API enforces tenant membership.

-- Low-cost database-side operational trail. This avoids making every API request
-- perform a second synchronous logging request. Only state-changing CRM/lead
-- tables are captured; SELECT traffic is never logged.
create or replace function public.leadx_capture_event() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  row_data jsonb;
  tid uuid;
  rid text;
begin
  row_data := case when TG_OP = 'DELETE' then to_jsonb(OLD) else to_jsonb(NEW) end;
  begin tid := nullif(row_data->>'tenant_id','')::uuid; exception when others then tid := null; end;
  rid := coalesce(row_data->>'id', row_data->>'assignment_id');
  if TG_TABLE_NAME = 'notifications' and lower(coalesce(row_data->>'scope', 'tenant')) <> 'tenant' then
    tid := null;
  end if;
  if tid is not null then
    insert into public.leadx_event_log(tenant_id, actor_type, action, resource_type, resource_id, summary)
    values (tid, 'system', lower('db.' || TG_TABLE_NAME || '.' || TG_OP), TG_TABLE_NAME, rid,
            initcap(replace(lower(TG_TABLE_NAME), '_', ' ')) || ' ' || lower(TG_OP));
  end if;
  if TG_OP = 'DELETE' then return OLD; else return NEW; end if;
end;
$$;

create or replace function public.leadx_broadcast_event() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  begin
    perform realtime.send(
      jsonb_build_object(
        'table', coalesce(NEW.resource_type, 'workspace'),
        'event', case when position('.' in coalesce(NEW.action, '')) > 0 then split_part(NEW.action, '.', 3) else 'LOG' end
      ),
      'crm_change',
      'crm:' || NEW.tenant_id::text,
      true
    );
  exception when others then
    null;
  end;
  return NEW;
end;
$$;

drop trigger if exists leadx_event_broadcast on public.leadx_event_log;
create trigger leadx_event_broadcast
after insert on public.leadx_event_log
for each row execute function public.leadx_broadcast_event();

-- Browser roles cannot inspect or mutate the operational event trail.
revoke all on table public.leadx_event_log from public, anon, authenticated;
grant select, insert on table public.leadx_event_log to service_role;
revoke all on function public.leadx_capture_event() from public, anon, authenticated;
revoke all on function public.leadx_broadcast_event() from public, anon, authenticated;
grant execute on function public.leadx_capture_event() to service_role;
grant execute on function public.leadx_broadcast_event() to service_role;

do $$
declare
  t text;
  tables text[] := array[
    'pipeline_runs','discovery_requests','pipeline_stages',
    'lead_assignments','lead_state_history','lead_score_snapshots','lead_quality_gates',
    'lead_routing_decisions','lead_delivery_events','lead_verification_observations',
    'lead_outcome_events','lead_activities','lead_tasks',
    'companies','company_locations','contacts','contact_roles','deals','deal_stages',
    'activities','tasks','notes','agent_runs','jobs',
    'email_sequences','email_sequence_enrollments','email_sequence_sends','email_replies',
    'workflow_definitions','workflow_runs','automation_events',
    'tenant_members','tenant_invites','notifications','audit_log','crm_audit_log',
    'usage_log','provider_usage_daily','learning_snapshots','tenant_icp_learning',
    'tenant_icp_recommendations','support_conversations'
  ];
begin
  foreach t in array tables loop
    if to_regclass('public.' || t) is not null then
      execute format('drop trigger if exists leadx_event_capture on public.%I', t);
      execute format('create trigger leadx_event_capture after insert or update or delete on public.%I for each row execute function public.leadx_capture_event()', t);
      begin
        execute format('alter table public.%I replica identity full', t);
        execute format('alter publication supabase_realtime add table public.%I', t);
      exception when duplicate_object or undefined_table or undefined_object then null;
      end;
    end if;
  end loop;
end $$;

-- Keep operational logs bounded. Deploy a daily/weekly maintenance job to
-- delete rows older than the product retention window (default 180 days).
create index if not exists idx_leadx_event_log_retention
  on public.leadx_event_log (created_at);

-- Secure Broadcast authorization. A workspace user can receive only the
-- private topic for a tenant where they have an active membership.
drop policy if exists leadx_workspace_broadcast_read on realtime.messages;
create policy leadx_workspace_broadcast_read
  on realtime.messages
  for select to authenticated
  using (
    extension = 'broadcast'
    and realtime.topic() ~* '^crm:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
    and exists (
      select 1
      from public.tenant_members tm
      where tm.tenant_id = nullif(split_part(realtime.topic(), ':', 2), '')::uuid
        and tm.auth_user_id = auth.uid()
        and tm.status = 'active'
    )
  );

-- ============================================================================
-- CANONICAL MIGRATION 10: 20260930000900_leadx_9_automation_quota.sql
-- ============================================================================

-- LeadX 9.0: quota/run hard caps + event-driven automation + reply intelligence.
ALTER TABLE pipeline_runs
  ADD COLUMN IF NOT EXISTS requested_target integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS target_assigned integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS quota_limit_at_start integer,
  ADD COLUMN IF NOT EXISTS target_mode boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_tenant_started ON pipeline_runs(tenant_id, started_at DESC);

CREATE OR REPLACE FUNCTION public.claim_pipeline_run_slot(
  p_run_id uuid, p_tenant_id uuid, p_target integer
) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE cur int; target int;
BEGIN
  target := GREATEST(COALESCE(p_target,0),0);
  IF target <= 0 THEN RETURN true; END IF;
  SELECT target_assigned INTO cur FROM pipeline_runs WHERE id=p_run_id AND tenant_id=p_tenant_id FOR UPDATE;
  IF NOT FOUND THEN RETURN false; END IF;
  IF cur >= target THEN RETURN false; END IF;
  UPDATE pipeline_runs SET target_assigned=target_assigned+1, assigned=assigned+1 WHERE id=p_run_id;
  RETURN true;
END; $$;

CREATE OR REPLACE FUNCTION public.release_pipeline_run_slot(p_run_id uuid, p_tenant_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  UPDATE pipeline_runs
  SET target_assigned=GREATEST(target_assigned-1,0), assigned=GREATEST(assigned-1,0)
  WHERE id=p_run_id AND tenant_id=p_tenant_id;
END; $$;

-- Durable event queue: application code writes compact events; workers execute them asynchronously.
CREATE TABLE IF NOT EXISTS public.automation_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  subject_type text NOT NULL,
  subject_id text,
  payload jsonb NOT NULL DEFAULT '{}',
  idempotency_key text NOT NULL,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','processing','done','failed','ignored')),
  attempts integer NOT NULL DEFAULT 0,
  available_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  locked_by text,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  UNIQUE(tenant_id,idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_automation_events_due ON automation_events(status, available_at, created_at);
CREATE INDEX IF NOT EXISTS idx_automation_events_tenant ON automation_events(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_automation_events_subject ON automation_events(tenant_id, subject_type, subject_id, created_at DESC);

ALTER TABLE workflow_definitions
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS max_concurrency integer NOT NULL DEFAULT 10,
  ADD COLUMN IF NOT EXISTS cooldown_seconds integer NOT NULL DEFAULT 0;
ALTER TABLE workflow_runs
  ADD COLUMN IF NOT EXISTS event_id uuid REFERENCES automation_events(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS idempotency_key text;
CREATE UNIQUE INDEX IF NOT EXISTS uq_workflow_runs_idempotency ON workflow_runs(workflow_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_workflow_runs_tenant_created ON workflow_runs(tenant_id, created_at DESC);

ALTER TABLE email_replies
  ADD COLUMN IF NOT EXISTS intent text,
  ADD COLUMN IF NOT EXISTS sentiment text,
  ADD COLUMN IF NOT EXISTS reply_score integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS urgency text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS next_action text,
  ADD COLUMN IF NOT EXISTS escalated_at timestamptz;
CREATE INDEX IF NOT EXISTS idx_email_replies_score ON email_replies(tenant_id, reply_score DESC, received_at DESC);

-- Safe event insertion. Duplicate events collapse at the DB boundary.
CREATE OR REPLACE FUNCTION public.enqueue_automation_event(
  p_tenant_id uuid, p_event_type text, p_subject_type text, p_subject_id text,
  p_payload jsonb, p_idempotency_key text
) RETURNS uuid LANGUAGE plpgsql AS $$
DECLARE eid uuid;
BEGIN
  INSERT INTO automation_events(tenant_id,event_type,subject_type,subject_id,payload,idempotency_key)
  VALUES(p_tenant_id,p_event_type,p_subject_type,p_subject_id,COALESCE(p_payload,'{}'::jsonb),p_idempotency_key)
  ON CONFLICT(tenant_id,idempotency_key) DO UPDATE SET payload=EXCLUDED.payload
  RETURNING id INTO eid;
  RETURN eid;
END; $$;

-- Client RLS: workflow/event history is tenant-scoped; service worker can use service role.
ALTER TABLE workflow_definitions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS workflow_definitions_member_select ON workflow_definitions;
CREATE POLICY workflow_definitions_member_select ON workflow_definitions FOR SELECT USING (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=workflow_definitions.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);
ALTER TABLE workflow_runs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS workflow_runs_member_select ON workflow_runs;
CREATE POLICY workflow_runs_member_select ON workflow_runs FOR SELECT USING (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=workflow_runs.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);
ALTER TABLE automation_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS automation_events_member_select ON automation_events;
CREATE POLICY automation_events_member_select ON automation_events FOR SELECT USING (
  EXISTS (SELECT 1 FROM tenant_members tm WHERE tm.tenant_id=automation_events.tenant_id AND tm.auth_user_id=auth.uid() AND tm.status='active')
);

NOTIFY pgrst, 'reload schema';

-- Atomic per-domain daily send reservation. Prevents concurrent workers from
-- both seeing the same remaining capacity and overshooting a sender cap.
CREATE OR REPLACE FUNCTION public.reserve_email_domain_slot(
  p_tenant_id uuid, p_domain text, p_cap integer
) RETURNS boolean LANGUAGE plpgsql AS $$
DECLARE used integer;
BEGIN
  IF COALESCE(p_cap,0) <= 0 OR NULLIF(trim(p_domain),'') IS NULL THEN RETURN false; END IF;
  INSERT INTO email_domain_daily(day,tenant_id,domain,sent_count)
  VALUES(current_date,p_tenant_id,lower(trim(p_domain)),0)
  ON CONFLICT(day,tenant_id,domain) DO NOTHING;
  SELECT sent_count INTO used FROM email_domain_daily
  WHERE day=current_date AND tenant_id=p_tenant_id AND domain=lower(trim(p_domain)) FOR UPDATE;
  IF COALESCE(used,0) >= p_cap THEN RETURN false; END IF;
  UPDATE email_domain_daily SET sent_count=sent_count+1 WHERE day=current_date AND tenant_id=p_tenant_id AND domain=lower(trim(p_domain));
  RETURN true;
END; $$;

CREATE OR REPLACE FUNCTION public.release_email_domain_slot(p_tenant_id uuid, p_domain text)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  UPDATE email_domain_daily SET sent_count=GREATEST(sent_count-1,0)
  WHERE day=current_date AND tenant_id=p_tenant_id AND domain=lower(trim(p_domain));
END; $$;

-- ============================================================================
-- CANONICAL MIGRATION 11: 20260930001000_leadx_10_crm_scale.sql
-- ============================================================================

-- LeadX 10.0: CRM scale, keyset-friendly indexes, automation safety and tenant-scoped observability.
-- Inspired by documented Salesforce/HubSpot patterns: selective indexes, async bulk work,
-- tenant-aware access paths, associations, and audit trails.

CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_delivered_id
  ON lead_assignments (tenant_id, delivered_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_stage_status
  ON lead_assignments (tenant_id, stage_id, status, delivered_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_owner
  ON lead_assignments (tenant_id, assigned_to, delivered_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_lead
  ON lead_assignments (tenant_id, lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_activities_tenant_created_id
  ON lead_activities (tenant_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_lead_tasks_tenant_status_due
  ON lead_tasks (tenant_id, status, due_at, id);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_updated_id
  ON deals (tenant_id, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_deals_tenant_stage_status
  ON deals (tenant_id, stage_id, status, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_contacts_tenant_updated_id
  ON contacts (tenant_id, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_companies_tenant_updated_id
  ON companies (tenant_id, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_activities_tenant_occurred_id
  ON activities (tenant_id, occurred_at DESC, id DESC);

DO $$ BEGIN
  CREATE EXTENSION IF NOT EXISTS pg_trgm;
EXCEPTION WHEN insufficient_privilege THEN
  RAISE NOTICE 'pg_trgm unavailable; btree indexes remain active';
END $$;

DO $$ BEGIN
  CREATE INDEX IF NOT EXISTS idx_leads_global_name_trgm ON leads_global USING gin (name gin_trgm_ops);
EXCEPTION WHEN undefined_object OR undefined_column OR undefined_table OR insufficient_privilege THEN
  RAISE NOTICE 'trigram index on leads_global skipped';
END $$;

DO $$ BEGIN
  CREATE INDEX IF NOT EXISTS idx_companies_name_trgm ON companies USING gin (name gin_trgm_ops);
EXCEPTION WHEN undefined_object OR undefined_column OR undefined_table OR insufficient_privilege THEN
  RAISE NOTICE 'trigram index on companies skipped';
END $$;

DO $$ BEGIN
  CREATE INDEX IF NOT EXISTS idx_contacts_name_trgm ON contacts USING gin (full_name gin_trgm_ops);
EXCEPTION WHEN undefined_object OR undefined_column OR undefined_table OR insufficient_privilege THEN
  RAISE NOTICE 'trigram index on contacts skipped';
END $$;

-- Prevent workflow capacity counters from becoming unbounded.
CREATE INDEX IF NOT EXISTS idx_workflow_runs_active ON workflow_runs (workflow_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_workflow_runs_idem ON workflow_runs (workflow_id, idempotency_key);

-- Safe presentation log lookup at scale.
CREATE INDEX IF NOT EXISTS idx_leadx_event_log_tenant_created_id
  ON leadx_event_log (tenant_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_leadx_event_log_tenant_action_created
  ON leadx_event_log (tenant_id, action, created_at DESC);

-- Realtime payloads should remain small: this table is metadata/audit only.
COMMENT ON TABLE leadx_event_log IS 'Tenant-scoped presentation-safe audit events; no secrets/provider payloads.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 12: 20260930001050_leadx_15_3_runtime_foundation.sql
-- ============================================================================

-- LeadX 15.3 pre-11 runtime compatibility foundation.
-- These objects existed in legacy SQL and are required by later canonical migrations/runtime.
-- Kept here before 20260930001100 so clean installs never execute ALTER/DELETE against absent tables.

-- jobs queue (source: sql/005_jobs_queue.sql)
CREATE TABLE IF NOT EXISTS public.jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid, kind text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}', status text NOT NULL DEFAULT 'queued',
  priority int NOT NULL DEFAULT 0, attempts int NOT NULL DEFAULT 0, max_attempts int NOT NULL DEFAULT 3,
  run_after timestamptz NOT NULL DEFAULT now(), created_by text DEFAULT 'api', locked_by text,
  locked_at timestamptz, started_at timestamptz, finished_at timestamptz, result jsonb, error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS tenant_id uuid;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS payload jsonb NOT NULL DEFAULT '{}';
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'queued';
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS priority int NOT NULL DEFAULT 0;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS attempts int NOT NULL DEFAULT 0;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS max_attempts int NOT NULL DEFAULT 3;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS run_after timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS created_by text DEFAULT 'api';
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS locked_by text;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS locked_at timestamptz;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS started_at timestamptz;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS finished_at timestamptz;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS result jsonb;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS error text;
ALTER TABLE public.jobs ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS idx_jobs_claim ON public.jobs(priority DESC, created_at) WHERE status='queued';
CREATE INDEX IF NOT EXISTS idx_jobs_kind_status ON public.jobs(kind,status);
CREATE INDEX IF NOT EXISTS idx_jobs_stale ON public.jobs(locked_at) WHERE status='running';
CREATE INDEX IF NOT EXISTS idx_jobs_created ON public.jobs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_tenant ON public.jobs(tenant_id,created_at DESC);

-- business integrations / outbound delivery (source: sql/031_BUSINESS_INTEGRATIONS_AND_REVENUE_OPS.sql)
CREATE TABLE IF NOT EXISTS public.integration_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  provider text NOT NULL, status text NOT NULL DEFAULT 'connected', external_account_id text,
  secret_ref text, scopes text[] NOT NULL DEFAULT '{}', metadata jsonb NOT NULL DEFAULT '{}',
  last_sync_at timestamptz, last_error text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,provider,external_account_id)
);
CREATE INDEX IF NOT EXISTS idx_integrations_tenant ON public.integration_connections(tenant_id,status);
CREATE TABLE IF NOT EXISTS public.outbound_webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  name text NOT NULL, endpoint_url text NOT NULL, secret_ref text, events text[] NOT NULL DEFAULT '{}',
  active boolean NOT NULL DEFAULT true, retry_limit int NOT NULL DEFAULT 6, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_outbound_webhooks_tenant ON public.outbound_webhooks(tenant_id,active);
CREATE TABLE IF NOT EXISTS public.webhook_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), webhook_id uuid NOT NULL REFERENCES public.outbound_webhooks(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE, event_type text NOT NULL, event_id text,
  payload jsonb NOT NULL DEFAULT '{}', status text NOT NULL DEFAULT 'queued', attempts int NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(), response_status int, response_body text, last_error text,
  created_at timestamptz NOT NULL DEFAULT now(), delivered_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_webhook_delivery_due ON public.webhook_deliveries(status,next_attempt_at);
CREATE INDEX IF NOT EXISTS idx_webhook_delivery_tenant ON public.webhook_deliveries(tenant_id,created_at DESC);

-- CRM graph objects (source: sql/030_CRM_REVENUE_GRAPH.sql)
CREATE TABLE IF NOT EXISTS public.company_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE, name text, address text, city text, state text,
  country text, postal_code text, phone text, website text, latitude numeric(10,7), longitude numeric(10,7),
  is_primary boolean NOT NULL DEFAULT false, source text, source_key text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_company_locations_company ON public.company_locations(company_id);
CREATE INDEX IF NOT EXISTS idx_company_locations_geo ON public.company_locations(state,city);
CREATE TABLE IF NOT EXISTS public.contact_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  contact_id uuid NOT NULL REFERENCES public.contacts(id) ON DELETE CASCADE, role_type text NOT NULL,
  influence_score int CHECK (influence_score IS NULL OR influence_score BETWEEN 0 AND 100),
  buying_authority int CHECK (buying_authority IS NULL OR buying_authority BETWEEN 0 AND 100), verified_at timestamptz,
  evidence jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(tenant_id,contact_id,role_type)
);
CREATE INDEX IF NOT EXISTS idx_contact_roles_company ON public.contact_roles(tenant_id,role_type,influence_score DESC);
CREATE TABLE IF NOT EXISTS public.prospect_audits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES public.leads_global(id) ON DELETE SET NULL, company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  public_token text UNIQUE NOT NULL, status text NOT NULL DEFAULT 'draft', title text, summary text, sections jsonb NOT NULL DEFAULT '{}',
  expires_at timestamptz, created_by text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_prospect_audits_tenant ON public.prospect_audits(tenant_id,created_at DESC);

-- Support copilot (source: sql/032_SUPPORT_CHAT.sql)
CREATE TABLE IF NOT EXISTS public.support_faq (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), category text NOT NULL, question text NOT NULL, answer text NOT NULL,
  keywords text[] NOT NULL DEFAULT '{}', priority int NOT NULL DEFAULT 0, active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_faq_active ON public.support_faq(active,priority DESC);
CREATE TABLE IF NOT EXISTS public.support_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  user_id uuid, user_email text, subject text NOT NULL DEFAULT 'LeadX Support',
  status text NOT NULL DEFAULT 'open' CHECK(status IN ('open','bot','escalated','human','resolved','closed')),
  needs_human boolean NOT NULL DEFAULT false, assigned_admin text, last_message_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_conv_tenant ON public.support_conversations(tenant_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_support_conv_escalated ON public.support_conversations(needs_human,updated_at DESC);
CREATE TABLE IF NOT EXISTS public.support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), conversation_id uuid NOT NULL REFERENCES public.support_conversations(id) ON DELETE CASCADE,
  sender_type text NOT NULL CHECK(sender_type IN ('user','bot','admin','system')), sender_id text, body text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_messages_conv ON public.support_messages(conversation_id,created_at);
CREATE UNIQUE INDEX IF NOT EXISTS uq_support_faq_category_question ON public.support_faq(category,question);

-- Saved CRM views (source: sql/021_FIX_pipeline_notifications_jobs.sql)
CREATE TABLE IF NOT EXISTS public.saved_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  entity text NOT NULL DEFAULT 'leads',
  name text NOT NULL,
  filters jsonb NOT NULL DEFAULT '{}'::jsonb,
  user_id text,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_saved_views_tenant_entity ON public.saved_views(tenant_id,entity);
ALTER TABLE public.saved_views ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.saved_views FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_views TO service_role;

-- Runtime column contract required by the current application before later migrations run.
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS stripe_subscription_id text;
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS stripe_subscription_item_id text;
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS stripe_price_id text;
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS billing_status text NOT NULL DEFAULT 'active';
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS billing_interval text;
ALTER TABLE public.tenants ADD COLUMN IF NOT EXISTS billing_grace_until timestamptz;
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS health_score int CHECK (health_score IS NULL OR health_score BETWEEN 0 AND 100);
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS last_activity_at timestamptz;
ALTER TABLE public.deals ADD COLUMN IF NOT EXISTS next_action_at timestamptz;
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS last_replied_at timestamptz;
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS lifecycle_stage text NOT NULL DEFAULT 'new';
ALTER TABLE public.lead_assignments ADD COLUMN IF NOT EXISTS source_campaign_id uuid;
ALTER TABLE public.email_sends ADD COLUMN IF NOT EXISTS variant_key text;
ALTER TABLE public.email_sends ADD COLUMN IF NOT EXISTS variant_category text;
ALTER TABLE public.usage_log ADD COLUMN IF NOT EXISTS leads_credited int NOT NULL DEFAULT 0;
ALTER TABLE public.usage_log ADD COLUMN IF NOT EXISTS stripe_reported_qty int;
ALTER TABLE public.usage_log ADD COLUMN IF NOT EXISTS stripe_reported_at timestamptz;

-- Durable HTTP idempotency release primitive used when a claimed response cannot safely be cached.
CREATE OR REPLACE FUNCTION public.release_operation_idempotency(p_key text, p_operation text)
RETURNS void LANGUAGE sql AS $$
  DELETE FROM public.operation_idempotency WHERE idempotency_key=p_key AND operation=p_operation;
$$;
REVOKE ALL ON FUNCTION public.release_operation_idempotency(text,text) FROM public;
GRANT EXECUTE ON FUNCTION public.release_operation_idempotency(text,text) TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 13: 20260930001100_leadx_11_connectors.sql
-- ============================================================================

-- LeadX 11.0: connector platform, BYOK, multi-account connections and safe sync metadata.
ALTER TABLE public.integration_connections
  ADD COLUMN IF NOT EXISTS connection_name text,
  ADD COLUMN IF NOT EXISTS auth_mode text NOT NULL DEFAULT 'platform',
  ADD COLUMN IF NOT EXISTS owner_user_id uuid,
  ADD COLUMN IF NOT EXISTS capabilities jsonb NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS health_status text NOT NULL DEFAULT 'unknown',
  ADD COLUMN IF NOT EXISTS last_health_at timestamptz;

UPDATE public.integration_connections
SET connection_name = COALESCE(connection_name, provider),
    auth_mode = COALESCE(auth_mode, CASE WHEN secret_ref IS NULL THEN 'platform' ELSE 'byok' END)
WHERE connection_name IS NULL OR auth_mode IS NULL;

CREATE INDEX IF NOT EXISTS idx_integrations_tenant_provider_status
  ON public.integration_connections(tenant_id, provider, status, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_integrations_tenant_owner
  ON public.integration_connections(tenant_id, owner_user_id, status);
CREATE INDEX IF NOT EXISTS idx_integrations_external_account
  ON public.integration_connections(tenant_id, provider, external_account_id);

-- Keep the old unique constraint compatible while allowing multiple accounts per provider.
-- The canonical uniqueness remains tenant/provider/external_account_id. NULL external IDs are
-- intentionally allowed so named BYOK connections can coexist until an external ID is known.

CREATE TABLE IF NOT EXISTS public.connector_sync_cursors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  connection_id uuid NOT NULL REFERENCES public.integration_connections(id) ON DELETE CASCADE,
  resource text NOT NULL,
  cursor text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(connection_id, resource)
);
CREATE INDEX IF NOT EXISTS idx_connector_sync_cursors_tenant ON public.connector_sync_cursors(tenant_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.connector_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  connection_id uuid REFERENCES public.integration_connections(id) ON DELETE SET NULL,
  provider text NOT NULL,
  event_type text NOT NULL,
  external_event_id text,
  status text NOT NULL DEFAULT 'received',
  payload jsonb NOT NULL DEFAULT '{}',
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  error text,
  UNIQUE(tenant_id, provider, external_event_id)
);
CREATE INDEX IF NOT EXISTS idx_connector_events_tenant_time ON public.connector_events(tenant_id, received_at DESC);
CREATE INDEX IF NOT EXISTS idx_connector_events_connection_time ON public.connector_events(connection_id, received_at DESC);

ALTER TABLE public.connector_sync_cursors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.connector_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS connector_sync_cursors_member ON public.connector_sync_cursors;
CREATE POLICY connector_sync_cursors_member ON public.connector_sync_cursors FOR SELECT USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS connector_sync_cursors_admin_write ON public.connector_sync_cursors;
CREATE POLICY connector_sync_cursors_admin_write ON public.connector_sync_cursors FOR ALL USING (public.is_tenant_admin(tenant_id)) WITH CHECK (public.is_tenant_admin(tenant_id));
DROP POLICY IF EXISTS connector_events_member ON public.connector_events;
CREATE POLICY connector_events_member ON public.connector_events FOR SELECT USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS connector_events_admin_write ON public.connector_events;
CREATE POLICY connector_events_admin_write ON public.connector_events FOR ALL USING (public.is_tenant_admin(tenant_id)) WITH CHECK (public.is_tenant_admin(tenant_id));
REVOKE ALL ON public.connector_sync_cursors, public.connector_events FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.connector_sync_cursors, public.connector_events TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 14: 20260930001200_leadx_12_agent_governance.sql
-- ============================================================================

-- LeadX 12.0 agent governance, approval inbox, evidence and learning shadow mode.
CREATE TABLE IF NOT EXISTS public.tenant_agent_settings (
  tenant_id uuid PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  outreach_auto_approve boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.agent_approval_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  run_id uuid REFERENCES public.agent_runs(id) ON DELETE SET NULL, agent_id text NOT NULL, action_type text NOT NULL,
  status text NOT NULL DEFAULT 'needs_approval' CHECK (status IN ('needs_approval','approved','rejected','executed','failed')),
  lead_id uuid REFERENCES public.leads_global(id) ON DELETE SET NULL, assignment_id uuid REFERENCES public.lead_assignments(id) ON DELETE SET NULL,
  payload jsonb NOT NULL DEFAULT '{}', reviewed_by uuid, reviewed_at timestamptz, executed_at timestamptz, error text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_approval_tenant_status ON agent_approval_items(tenant_id,status,created_at DESC);
CREATE TABLE IF NOT EXISTS public.agent_run_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  run_id uuid REFERENCES public.agent_runs(id) ON DELETE CASCADE, agent_id text NOT NULL, event_type text NOT NULL, payload jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_run_evidence_run ON agent_run_evidence(tenant_id,run_id,created_at DESC);
CREATE TABLE IF NOT EXISTS public.vertical_score_shadow_weights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), vertical text NOT NULL, feature text NOT NULL, baseline_weight numeric NOT NULL DEFAULT 1, proposed_weight numeric NOT NULL DEFAULT 1, sample_size integer NOT NULL DEFAULT 0, mode text NOT NULL DEFAULT 'shadow', lift numeric, calculated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(vertical,feature)
);
CREATE INDEX IF NOT EXISTS idx_vertical_shadow ON vertical_score_shadow_weights(vertical,calculated_at DESC);
DO $$ BEGIN
  ALTER TABLE tenant_agent_settings ENABLE ROW LEVEL SECURITY;
  ALTER TABLE agent_approval_items ENABLE ROW LEVEL SECURITY;
  ALTER TABLE agent_run_evidence ENABLE ROW LEVEL SECURITY;
  ALTER TABLE vertical_score_shadow_weights ENABLE ROW LEVEL SECURITY;
EXCEPTION WHEN undefined_table THEN NULL; END $$;
DROP POLICY IF EXISTS tenant_agent_settings_member ON tenant_agent_settings; CREATE POLICY tenant_agent_settings_member ON tenant_agent_settings FOR ALL USING (public.is_tenant_member(tenant_id)) WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS agent_approval_member ON agent_approval_items; CREATE POLICY agent_approval_member ON agent_approval_items FOR ALL USING (public.is_tenant_member(tenant_id)) WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS agent_run_evidence_member ON agent_run_evidence; CREATE POLICY agent_run_evidence_member ON agent_run_evidence FOR ALL USING (public.is_tenant_member(tenant_id)) WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS vertical_shadow_member ON vertical_score_shadow_weights; CREATE POLICY vertical_shadow_member ON vertical_score_shadow_weights FOR SELECT USING (EXISTS (SELECT 1 FROM tenant_members tm JOIN icp_profiles i ON i.tenant_id=tm.tenant_id WHERE tm.auth_user_id=auth.uid() AND tm.status='active' AND lower(i.vertical)=lower(vertical)));
NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 15: 20261001000000_leadx_13_security_queue.sql
-- ============================================================================

-- LeadX 13.0 hardening: job leases, duplicate prevention, RLS audit helpers.
-- Apply after the existing timestamped chain.

alter table if exists public.jobs add column if not exists lease_renewed_at timestamptz;

create index if not exists jobs_running_lease_idx on public.jobs (locked_at) where status = 'running';
-- Normalize any pre-existing duplicate active cron rows before adding the constraint.
delete from public.jobs j using public.jobs older
where j.status in ('queued','running') and older.status in ('queued','running')
  and j.kind = older.kind and j.tenant_id is not distinct from older.tenant_id
  and j.created_at < older.created_at;

create unique index if not exists jobs_active_unique_kind_tenant_idx
  on public.jobs (kind, tenant_id) where status in ('queued','running');

create or replace function public.leadx_queue_stats()
returns table(status text, count bigint, oldest_created_at timestamptz)
language sql stable security definer set search_path = public
as $$
  select j.status, count(*)::bigint, min(j.created_at)
  from public.jobs j
  group by j.status;
$$;

revoke all on function public.leadx_queue_stats() from public;
grant execute on function public.leadx_queue_stats() to service_role;

-- CI-only audit helper: tenant-scoped tables should enable RLS.
create or replace function public.leadx_rls_coverage()
returns table(table_name text, rls_enabled boolean)
language sql stable security definer set search_path = public
as $$
  select c.relname::text, c.relrowsecurity
  from pg_class c join pg_namespace n on n.oid=c.relnamespace
  where n.nspname='public' and c.relkind='r'
    and exists (select 1 from information_schema.columns x where x.table_schema='public' and x.table_name=c.relname and x.column_name='tenant_id')
  order by c.relname;
$$;
revoke all on function public.leadx_rls_coverage() from public;
grant execute on function public.leadx_rls_coverage() to service_role;


-- Enable RLS on every canonical tenant-scoped table. Backend service_role access remains unaffected; anon/authenticated clients cannot bypass tenant policies by direct table access.


-- Explicit RLS coverage for tenant-scoped tables identified by the migration audit.
alter table if exists public.agent_feedback enable row level security;
alter table if exists public.agent_memory enable row level security;
alter table if exists public.agent_runs enable row level security;
alter table if exists public.ai_claims enable row level security;
alter table if exists public.audit_log enable row level security;
alter table if exists public.autonomous_campaigns enable row level security;
alter table if exists public.campaign_guardrails enable row level security;
alter table if exists public.campaign_schedules enable row level security;
alter table if exists public.company_change_events enable row level security;
alter table if exists public.compliance_events enable row level security;
alter table if exists public.contact_graph_edges enable row level security;
alter table if exists public.daily_briefs enable row level security;
alter table if exists public.data_lineage enable row level security;
alter table if exists public.data_subject_requests enable row level security;
alter table if exists public.delivery_outbox enable row level security;
alter table if exists public.discovery_coverage enable row level security;
alter table if exists public.doc_sends enable row level security;
alter table if exists public.doc_templates enable row level security;
alter table if exists public.domain_warmup enable row level security;
alter table if exists public.email_bounces enable row level security;
alter table if exists public.email_domain_daily enable row level security;
alter table if exists public.email_domain_health enable row level security;
alter table if exists public.email_optouts enable row level security;
alter table if exists public.email_replies enable row level security;
alter table if exists public.email_sends enable row level security;
alter table if exists public.email_sequence_enrollments enable row level security;
alter table if exists public.email_sequence_sends enable row level security;
alter table if exists public.email_sequences enable row level security;
alter table if exists public.export_audit enable row level security;
alter table if exists public.first_touch_log enable row level security;
alter table if exists public.integration_deliveries enable row level security;
alter table if exists public.integration_field_maps enable row level security;
alter table if exists public.intelligence_feedback enable row level security;
alter table if exists public.lead_ai_briefs enable row level security;
alter table if exists public.lead_delivery_events enable row level security;
alter table if exists public.lead_evidence enable row level security;
alter table if exists public.lead_feedback enable row level security;
alter table if exists public.lead_opportunities enable row level security;
alter table if exists public.lead_outcome_events enable row level security;
alter table if exists public.lead_provider_telemetry enable row level security;
alter table if exists public.lead_quality_credits enable row level security;
alter table if exists public.lead_quality_gates enable row level security;
alter table if exists public.lead_quality_reports enable row level security;
alter table if exists public.lead_replacement_events enable row level security;
alter table if exists public.lead_routing_decisions enable row level security;
alter table if exists public.lead_score_snapshots enable row level security;
alter table if exists public.lead_state_history enable row level security;
alter table if exists public.lead_touches enable row level security;
alter table if exists public.lead_verification_observations enable row level security;
alter table if exists public.learning_snapshots enable row level security;
alter table if exists public.next_best_actions enable row level security;
alter table if exists public.operation_idempotency enable row level security;
alter table if exists public.ops_metrics_daily enable row level security;
alter table if exists public.product_events enable row level security;
alter table if exists public.provider_usage_daily enable row level security;
alter table if exists public.revenue_attribution enable row level security;
alter table if exists public.revenue_funnel_events enable row level security;
alter table if exists public.sample_packs enable row level security;
alter table if exists public.saved_searches enable row level security;
alter table if exists public.security_events enable row level security;
alter table if exists public.template_variant_stats enable row level security;
alter table if exists public.tenant_email_settings enable row level security;
alter table if exists public.tenant_icp_learning enable row level security;
alter table if exists public.tenant_playbooks enable row level security;
alter table if exists public.tenant_seen_leads enable row level security;
alter table if exists public.territory_locks enable row level security;
alter table if exists public.unit_economics_snapshots enable row level security;
alter table if exists public.website_audits enable row level security;
alter table if exists public.workflow_rules enable row level security;
alter table if exists public.workspace_preferences enable row level security;

notify pgrst, 'reload schema';

create or replace function public.leadx_claim_next_job(p_worker_id text, p_kinds text[] default null)
returns setof public.jobs
language plpgsql security definer set search_path = public
as $$
declare r public.jobs%rowtype;
begin
  select * into r from public.jobs
   where status='queued' and run_after <= now()
     and (p_kinds is null or kind = any(p_kinds))
   order by priority desc, created_at
   for update skip locked limit 1;
  if r.id is null then return; end if;
  update public.jobs set status='running', locked_by=p_worker_id, locked_at=now(), started_at=now(), attempts=coalesce(attempts,0)+1
   where id=r.id and status='queued' returning * into r;
  return next r;
end $$;
revoke all on function public.leadx_claim_next_job(text,text[]) from public;
grant execute on function public.leadx_claim_next_job(text,text[]) to service_role;

-- ============================================================================
-- CANONICAL MIGRATION 16: 20261001000100_leadx_14_data_intelligence_fabric.sql
-- ============================================================================

-- LeadX 14.0 Data & Intelligence Fabric
-- Additive migration. No existing tables/columns are removed.

CREATE TABLE IF NOT EXISTS public.provider_intelligence_stats (
  id text PRIMARY KEY,
  snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.provider_execution_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  run_id uuid,
  provider text NOT NULL,
  field_name text NOT NULL,
  source_class text NOT NULL DEFAULT 'data_vendor',
  hit boolean NOT NULL DEFAULT false,
  verified boolean NOT NULL DEFAULT false,
  failed boolean NOT NULL DEFAULT false,
  latency_ms integer NOT NULL DEFAULT 0,
  cost numeric(12,5) NOT NULL DEFAULT 0,
  region text NOT NULL DEFAULT 'global',
  vertical text NOT NULL DEFAULT 'global',
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  observed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_provider_exec_tenant_time ON public.provider_execution_log(tenant_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_provider_exec_provider_field ON public.provider_execution_log(provider, field_name, observed_at DESC);

CREATE TABLE IF NOT EXISTS public.field_evidence_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES public.leads_global(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  value_hash text NOT NULL,
  value_preview text,
  source text NOT NULL,
  source_class text NOT NULL DEFAULT 'other',
  source_url text,
  confidence numeric(6,5) NOT NULL DEFAULT 0.5,
  evidence_strength numeric(6,5) NOT NULL DEFAULT 0.5,
  observed_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_field_evidence_lead_field ON public.field_evidence_observations(tenant_id, lead_id, field_name, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_field_evidence_hash ON public.field_evidence_observations(tenant_id, field_name, value_hash);

CREATE TABLE IF NOT EXISTS public.discovery_plan_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  run_id uuid,
  vertical text NOT NULL,
  locations jsonb NOT NULL DEFAULT '[]'::jsonb,
  queries jsonb NOT NULL DEFAULT '[]'::jsonb,
  surfaces jsonb NOT NULL DEFAULT '[]'::jsonb,
  round_number integer NOT NULL DEFAULT 0,
  raw_found integer NOT NULL DEFAULT 0,
  unique_new integer NOT NULL DEFAULT 0,
  duplicates integer NOT NULL DEFAULT 0,
  source_counts jsonb NOT NULL DEFAULT '{}'::jsonb,
  saturated boolean NOT NULL DEFAULT false,
  coverage jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_discovery_plan_runs_tenant ON public.discovery_plan_runs(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_discovery_plan_runs_run ON public.discovery_plan_runs(run_id, round_number);

CREATE TABLE IF NOT EXISTS public.agent_execution_policies (
  tenant_id uuid PRIMARY KEY REFERENCES public.tenants(id) ON DELETE CASCADE,
  daily_cost_limit numeric(12,4) NOT NULL DEFAULT 100,
  per_run_cost_limit numeric(12,4) NOT NULL DEFAULT 25,
  read_auto boolean NOT NULL DEFAULT true,
  low_write_auto boolean NOT NULL DEFAULT true,
  high_write_approval boolean NOT NULL DEFAULT true,
  external_send_approval boolean NOT NULL DEFAULT true,
  destructive_approval boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.provider_intelligence_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.provider_execution_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.field_evidence_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.discovery_plan_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_execution_policies ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.leadx14_touch_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_provider_intelligence_updated_at ON public.provider_intelligence_stats;
CREATE TRIGGER trg_provider_intelligence_updated_at BEFORE UPDATE ON public.provider_intelligence_stats FOR EACH ROW EXECUTE FUNCTION public.leadx14_touch_updated_at();
DROP TRIGGER IF EXISTS trg_agent_execution_policies_updated_at ON public.agent_execution_policies;
CREATE TRIGGER trg_agent_execution_policies_updated_at BEFORE UPDATE ON public.agent_execution_policies FOR EACH ROW EXECUTE FUNCTION public.leadx14_touch_updated_at();

COMMENT ON TABLE public.provider_intelligence_stats IS 'LeadX 14.0 adaptive provider performance snapshots; inventory is not treated as executable coverage.';
COMMENT ON TABLE public.provider_execution_log IS 'Field-level provider execution economics and outcome telemetry.';
COMMENT ON TABLE public.field_evidence_observations IS 'Independent field-level evidence observations used by confidence/provenance UX.';
COMMENT ON TABLE public.discovery_plan_runs IS 'Discovery planner rounds, saturation and coverage evidence.';
COMMENT ON TABLE public.agent_execution_policies IS 'Tenant-scoped Agent OS governance defaults for LeadX 14.0.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 17: 20261001000200_leadx_15_agent_missions.sql
-- ============================================================================

-- LeadX 15.0 durable agent-to-agent mission graph. Additive only.
create table if not exists public.agent_missions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  objective text not null,
  input_data jsonb not null default '{}'::jsonb,
  mode text not null default 'supervised' check (mode in ('manual','supervised','autonomous')),
  parent_agent_id text not null default 'gtm',
  graph_version text not null default 'gtm-v1',
  graph_count integer not null default 30 check (graph_count = 30),
  status text not null default 'queued' check (status in ('queued','running','completed','failed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.agent_mission_tasks (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid not null references public.agent_missions(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  agent_id text not null,
  objective text not null,
  task_id text not null,
  topological_order integer not null check (topological_order >= 0 and topological_order < 30),
  executor_key text not null,
  depends_on jsonb not null default '[]'::jsonb,
  input_data jsonb not null default '{}'::jsonb,
  output_data jsonb not null default '{}'::jsonb,
  status text not null default 'blocked' check (status in ('blocked','queued','running','done','failed','cancelled')),
  agent_run_id uuid references public.agent_runs(id) on delete set null,
  error text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.agent_mission_events (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid not null references public.agent_missions(id) on delete cascade,
  task_id uuid references public.agent_mission_tasks(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists agent_missions_tenant_created_idx on public.agent_missions(tenant_id, created_at desc);
create index if not exists agent_mission_tasks_mission_status_idx on public.agent_mission_tasks(tenant_id, mission_id, status);
create unique index if not exists agent_mission_tasks_task_key_idx on public.agent_mission_tasks(mission_id, task_id);
create unique index if not exists agent_mission_tasks_topological_order_idx on public.agent_mission_tasks(mission_id, topological_order);
create index if not exists agent_mission_tasks_run_idx on public.agent_mission_tasks(tenant_id, agent_run_id);
create index if not exists agent_mission_events_mission_idx on public.agent_mission_events(tenant_id, mission_id, created_at desc);

alter table public.agent_missions enable row level security;
alter table public.agent_mission_tasks enable row level security;
alter table public.agent_mission_events enable row level security;

create or replace function public.leadx15_touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists trg_agent_missions_updated_at on public.agent_missions;
create trigger trg_agent_missions_updated_at before update on public.agent_missions for each row execute function public.leadx15_touch_updated_at();
drop trigger if exists trg_agent_mission_tasks_updated_at on public.agent_mission_tasks;
create trigger trg_agent_mission_tasks_updated_at before update on public.agent_mission_tasks for each row execute function public.leadx15_touch_updated_at();

notify pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 18: 20261001000300_leadx_15_4_security_reliability.sql
-- ============================================================================

-- LeadX 15.4 security + reliability hardening.
-- Applies safely to existing 15.0/15.1/15.2/15.3 installations and is also
-- included in SUPABASE_FULL_MIGRATION.sql for clean installs.

-- ---------------------------------------------------------------------------
-- 1. Complete runtime column contract.
-- ---------------------------------------------------------------------------
ALTER TABLE IF EXISTS public.tenants
  ADD COLUMN IF NOT EXISTS stripe_subscription_id text,
  ADD COLUMN IF NOT EXISTS billing_status text NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS billing_interval text,
  ADD COLUMN IF NOT EXISTS billing_grace_until timestamptz;

ALTER TABLE IF EXISTS public.deals
  ADD COLUMN IF NOT EXISTS health_score int CHECK (health_score IS NULL OR health_score BETWEEN 0 AND 100),
  ADD COLUMN IF NOT EXISTS last_activity_at timestamptz,
  ADD COLUMN IF NOT EXISTS next_action_at timestamptz;

ALTER TABLE IF EXISTS public.lead_assignments
  ADD COLUMN IF NOT EXISTS last_replied_at timestamptz,
  ADD COLUMN IF NOT EXISTS lifecycle_stage text NOT NULL DEFAULT 'new',
  ADD COLUMN IF NOT EXISTS source_campaign_id uuid;

ALTER TABLE IF EXISTS public.email_sends
  ADD COLUMN IF NOT EXISTS variant_key text,
  ADD COLUMN IF NOT EXISTS variant_category text;

ALTER TABLE IF EXISTS public.usage_log
  ADD COLUMN IF NOT EXISTS leads_credited int NOT NULL DEFAULT 0;

-- ---------------------------------------------------------------------------
-- 2. Upgrade-safe plan constraint repair.
-- The 15.3 baseline is also corrected so fresh and historical migrations both
-- drop the legacy constraint before converting premium/enterprise rows.
-- ---------------------------------------------------------------------------
DO $$
DECLARE c record;
BEGIN
  IF to_regclass('public.tenants') IS NULL THEN RETURN; END IF;
  FOR c IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'public.tenants'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%plan%'
  LOOP
    EXECUTE format('ALTER TABLE public.tenants DROP CONSTRAINT IF EXISTS %I', c.conname);
  END LOOP;
END $$;
UPDATE public.tenants SET plan='agency' WHERE plan IN ('premium','enterprise');
UPDATE public.tenants SET plan='free' WHERE plan IS NULL OR plan='';
ALTER TABLE public.tenants
  ADD CONSTRAINT tenants_plan_check_15_4 CHECK (plan IN ('free','starter','growth','agency'));
ALTER TABLE public.tenants ALTER COLUMN plan SET DEFAULT 'free';

-- ---------------------------------------------------------------------------
-- 3. Durable HTTP idempotency: user/session + body binding, stale reclaim,
--    and retention cleanup. Existing rows remain readable.
-- ---------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.claim_operation_idempotency(text,text,uuid);
DROP FUNCTION IF EXISTS public.finish_operation_idempotency(text,text,jsonb,text);
DROP FUNCTION IF EXISTS public.release_operation_idempotency(text,text);
ALTER TABLE IF EXISTS public.operation_idempotency
  ADD COLUMN IF NOT EXISTS scope_hash text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS request_hash text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS processing_expires_at timestamptz;

DO $$
DECLARE c record;
BEGIN
  IF to_regclass('public.operation_idempotency') IS NULL THEN RETURN; END IF;
  FOR c IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid='public.operation_idempotency'::regclass
      AND contype='u'
      AND pg_get_constraintdef(oid) ILIKE '%idempotency_key%operation%'
  LOOP
    EXECUTE format('ALTER TABLE public.operation_idempotency DROP CONSTRAINT IF EXISTS %I', c.conname);
  END LOOP;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS uq_operation_idempotency_scope
  ON public.operation_idempotency(scope_hash,idempotency_key,operation);
CREATE INDEX IF NOT EXISTS idx_operation_idempotency_cleanup
  ON public.operation_idempotency(created_at);

CREATE OR REPLACE FUNCTION public.claim_operation_idempotency(
  p_key text,
  p_operation text,
  p_tenant_id uuid DEFAULT NULL,
  p_scope_hash text DEFAULT '',
  p_request_hash text DEFAULT ''
) RETURNS TABLE(acquired boolean, existing_response jsonb)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.operation_idempotency%ROWTYPE;
BEGIN
  SELECT * INTO r
  FROM public.operation_idempotency
  WHERE scope_hash=COALESCE(p_scope_hash,'')
    AND idempotency_key=p_key
    AND operation=p_operation
  FOR UPDATE;

  IF NOT FOUND THEN
    INSERT INTO public.operation_idempotency(
      idempotency_key,operation,tenant_id,scope_hash,request_hash,status,response,processing_expires_at
    ) VALUES (
      p_key,p_operation,p_tenant_id,COALESCE(p_scope_hash,''),COALESCE(p_request_hash,''),
      'processing','{}',now()+interval '10 minutes'
    );
    RETURN QUERY SELECT true, NULL::jsonb;
    RETURN;
  END IF;

  IF r.request_hash <> COALESCE(p_request_hash,'') THEN
    RETURN QUERY SELECT false, jsonb_build_object('idempotency_mismatch',true);
    RETURN;
  END IF;

  IF r.status='completed' THEN
    RETURN QUERY SELECT false, r.response;
    RETURN;
  END IF;

  IF r.status='processing' AND COALESCE(r.processing_expires_at, now()+interval '10 minutes') > now() THEN
    RETURN QUERY SELECT false, NULL::jsonb;
    RETURN;
  END IF;

  UPDATE public.operation_idempotency
  SET tenant_id=p_tenant_id,
      request_hash=COALESCE(p_request_hash,''),
      status='processing',
      response='{}',
      processing_expires_at=now()+interval '10 minutes',
      created_at=now()
  WHERE id=r.id;
  RETURN QUERY SELECT true, NULL::jsonb;
END; $$;

CREATE OR REPLACE FUNCTION public.finish_operation_idempotency(
  p_key text,
  p_operation text,
  p_response jsonb,
  p_status text DEFAULT 'completed',
  p_scope_hash text DEFAULT '',
  p_request_hash text DEFAULT ''
) RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path=public AS $$
  UPDATE public.operation_idempotency
  SET response=COALESCE(p_response,'{}'), status=p_status, processing_expires_at=NULL
  WHERE idempotency_key=p_key
    AND operation=p_operation
    AND scope_hash=COALESCE(p_scope_hash,'')
    AND request_hash=COALESCE(p_request_hash,'');
$$;

CREATE OR REPLACE FUNCTION public.release_operation_idempotency(p_key text,p_operation text,p_scope_hash text DEFAULT NULL)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path=public AS $$
  DELETE FROM public.operation_idempotency
   WHERE idempotency_key=p_key AND operation=p_operation
     AND (p_scope_hash IS NULL OR scope_hash=COALESCE(p_scope_hash,''));
$$;

CREATE OR REPLACE FUNCTION public.cleanup_operation_idempotency(p_retention_days integer DEFAULT 30)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE n integer;
BEGIN
  DELETE FROM public.operation_idempotency
   WHERE created_at < now() - make_interval(days => greatest(1,p_retention_days))
      OR (status='processing' AND processing_expires_at < now() - interval '1 hour');
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END; $$;

REVOKE ALL ON FUNCTION public.claim_operation_idempotency(text,text,uuid,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.finish_operation_idempotency(text,text,jsonb,text,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.release_operation_idempotency(text,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.cleanup_operation_idempotency(integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_operation_idempotency(text,text,uuid,text,text) TO service_role;
GRANT EXECUTE ON FUNCTION public.finish_operation_idempotency(text,text,jsonb,text,text,text) TO service_role;
GRANT EXECUTE ON FUNCTION public.release_operation_idempotency(text,text,text) TO service_role;
GRANT EXECUTE ON FUNCTION public.cleanup_operation_idempotency(integer) TO service_role;

-- ---------------------------------------------------------------------------
-- 4. Complete RLS hardening. LeadX's browser talks to FastAPI, not PostgREST;
--    therefore public tables are service-role owned. This closes every table,
--    including platform_admins, jobs, integrations, verification codes and
--    global suppression data. Future public tables inherit revoked privileges.
-- ---------------------------------------------------------------------------
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM anon, authenticated;

DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT c.relname
    FROM pg_class c
    JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE n.nspname='public' AND c.relkind='r'
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', r.relname);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', r.relname);
  END LOOP;
END $$;

-- Service role is the only database role used by the FastAPI backend.
-- It bypasses RLS in Supabase; no browser role receives table privileges.

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 19: 20261001000400_leadx_15_5_realtime_authz.sql
-- ============================================================================

-- LeadX 15.5 realtime authorization hardening.
-- RLS lockdown revokes authenticated table privileges; Broadcast authorization
-- therefore uses a narrowly-scoped SECURITY DEFINER membership helper.

CREATE OR REPLACE FUNCTION public.leadx_is_workspace_member(p_tenant uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.tenant_members tm
    WHERE tm.tenant_id = p_tenant
      AND tm.auth_user_id = auth.uid()
      AND tm.status = 'active'
  )
$$;

REVOKE ALL ON FUNCTION public.leadx_is_workspace_member(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.leadx_is_workspace_member(uuid) TO authenticated;

DROP POLICY IF EXISTS leadx_workspace_broadcast_read ON realtime.messages;
CREATE POLICY leadx_workspace_broadcast_read
  ON realtime.messages
  FOR SELECT TO authenticated
  USING (
    extension = 'broadcast'
    AND public.leadx_is_workspace_member(
      nullif(split_part(realtime.topic(), ':', 2), '')::uuid
    )
  );

-- ============================================================================
-- CANONICAL MIGRATION 20: 20261001000410_leadx_15_5_billing_consistency.sql
-- ============================================================================

-- LeadX 15.5 billing ordering, subscription lifecycle and refund/dispute state.
ALTER TABLE IF EXISTS public.tenants
  ADD COLUMN IF NOT EXISTS stripe_event_created bigint NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS stripe_current_period_start timestamptz,
  ADD COLUMN IF NOT EXISTS stripe_current_period_end timestamptz,
  ADD COLUMN IF NOT EXISTS pending_plan text,
  ADD COLUMN IF NOT EXISTS pending_leads_per_month_limit integer,
  ADD COLUMN IF NOT EXISTS pending_billing_interval text,
  ADD COLUMN IF NOT EXISTS billing_outbound_suspended boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS stripe_refund_at timestamptz,
  ADD COLUMN IF NOT EXISTS stripe_refund_amount_cents bigint,
  ADD COLUMN IF NOT EXISTS stripe_dispute_status text;

ALTER TABLE IF EXISTS public.webhook_events
  ADD COLUMN IF NOT EXISTS processed_at timestamptz,
  ADD COLUMN IF NOT EXISTS processing_expires_at timestamptz;
CREATE INDEX IF NOT EXISTS idx_webhook_events_processed_at ON public.webhook_events(processed_at);

ALTER TABLE IF EXISTS public.tenants
  DROP CONSTRAINT IF EXISTS tenants_pending_plan_check_15_5;
ALTER TABLE IF EXISTS public.tenants
  ADD CONSTRAINT tenants_pending_plan_check_15_5
  CHECK (pending_plan IS NULL OR pending_plan IN ('free','starter','growth','agency'));

-- ============================================================================
-- CANONICAL MIGRATION 21: 20261001000500_leadx_15_7_oauth_security.sql
-- ============================================================================

-- LeadX 15.7: single-use OAuth state bindings.
CREATE TABLE IF NOT EXISTS public.oauth_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL,
  user_id uuid NOT NULL,
  provider text NOT NULL,
  nonce_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_oauth_states_expiry ON public.oauth_states(expires_at);
CREATE INDEX IF NOT EXISTS idx_oauth_states_binding ON public.oauth_states(tenant_id,user_id,provider,expires_at);
ALTER TABLE public.oauth_states ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.oauth_states FROM anon, authenticated;
GRANT ALL ON TABLE public.oauth_states TO service_role;
DROP POLICY IF EXISTS "service_role_oauth_states" ON public.oauth_states;
CREATE POLICY "service_role_oauth_states" ON public.oauth_states FOR ALL TO service_role USING (true) WITH CHECK (true);

-- ============================================================================
-- CANONICAL MIGRATION 22: 20261001000600_leadx_15_8_security_hardening.sql
-- ============================================================================

-- LeadX 15.8: production security hardening.
-- Billing helper functions are machine-only. Never expose them to browser roles.
CREATE OR REPLACE FUNCTION public.credit_tenant_usage(
  p_tenant_id uuid,
  p_period date,
  p_amount int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF p_amount IS NULL OR p_amount < 0 OR p_amount > 100000 THEN
    RAISE EXCEPTION 'invalid credit amount';
  END IF;
  UPDATE public.usage_log
  SET leads_delivered = GREATEST(0, leads_delivered - p_amount),
      leads_credited = COALESCE(leads_credited, 0) + p_amount
  WHERE tenant_id = p_tenant_id AND period = p_period;
END;
$$;
REVOKE ALL ON FUNCTION public.credit_tenant_usage(uuid,date,int) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.credit_tenant_usage(uuid,date,int) TO service_role;

CREATE OR REPLACE FUNCTION public.bump_ops_metric(
  p_day date,
  p_tenant_id uuid,
  p_field text,
  p_delta int DEFAULT 1
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
  IF p_field NOT IN ('pipeline_runs','leads_discovered','leads_enriched_ok','leads_enriched_fail','leads_gated','leads_assigned','suppression_hits','opt_out_hits','credits_issued','serper_calls','firecrawl_calls','avg_enrich_ms') THEN
    RAISE EXCEPTION 'invalid ops metric field';
  END IF;
  IF p_delta IS NULL OR abs(p_delta) > 1000000 THEN
    RAISE EXCEPTION 'invalid metric delta';
  END IF;
  INSERT INTO public.ops_metrics_daily (day, tenant_id)
  VALUES (p_day, p_tenant_id)
  ON CONFLICT (day, tenant_id) DO NOTHING;
  EXECUTE format(
    'UPDATE public.ops_metrics_daily SET %I = COALESCE(%I, 0) + $1 WHERE day = $2 AND tenant_id IS NOT DISTINCT FROM $3',
    p_field, p_field
  ) USING p_delta, p_day, p_tenant_id;
END;
$$;
REVOKE ALL ON FUNCTION public.bump_ops_metric(date,uuid,text,int) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.bump_ops_metric(date,uuid,text,int) TO service_role;

-- Keep service-only tables/functions explicitly scoped even if an older policy
-- used USING(true). Browser roles receive no direct access.
REVOKE ALL ON TABLE public.oauth_states FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.oauth_states TO service_role;
DROP POLICY IF EXISTS "service_role_oauth_states" ON public.oauth_states;
CREATE POLICY "service_role_oauth_states" ON public.oauth_states
  FOR ALL TO service_role USING (true) WITH CHECK (true);

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 23: 20261001000700_leadx_15_8_pipeline_run_lifecycle.sql
-- ============================================================================

-- LeadX 15.8: durable pipeline-run lifecycle compatibility.
-- The API creates a run before enqueueing the worker, so `queued` must be a
-- valid pipeline_runs.status on both fresh and previously provisioned databases.
DO $$
DECLARE
  c record;
BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    FOR c IN
      SELECT conname
      FROM pg_constraint
      WHERE conrelid = 'public.pipeline_runs'::regclass
        AND contype = 'c'
        AND pg_get_constraintdef(oid) ILIKE '%status%'
        AND pg_get_constraintdef(oid) ILIKE '%running%'
        AND pg_get_constraintdef(oid) ILIKE '%completed%'
    LOOP
      EXECUTE format('ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS %I', c.conname);
    END LOOP;

    -- Existing installations may contain historical labels from before the
    -- durable lifecycle contract. Normalize them before adding the stricter
    -- constraint; preserve successful work and mark ambiguous terminal work
    -- as partial when it produced any output.
    UPDATE public.pipeline_runs
    SET status = CASE lower(trim(COALESCE(status, '')))
      WHEN 'queued' THEN 'queued'
      WHEN 'pending' THEN 'queued'
      WHEN 'created' THEN 'queued'
      WHEN 'waiting' THEN 'queued'
      WHEN 'running' THEN 'running'
      WHEN 'processing' THEN 'running'
      WHEN 'started' THEN 'running'
      WHEN 'in_progress' THEN 'running'
      WHEN 'in-progress' THEN 'running'
      WHEN 'completed' THEN 'completed'
      WHEN 'complete' THEN 'completed'
      WHEN 'done' THEN 'completed'
      WHEN 'success' THEN 'completed'
      WHEN 'succeeded' THEN 'completed'
      WHEN 'failed' THEN 'failed'
      WHEN 'error' THEN 'failed'
      WHEN 'errored' THEN 'failed'
      WHEN 'partial' THEN 'partial'
      WHEN 'partially_completed' THEN 'partial'
      WHEN 'partial_success' THEN 'partial'
      WHEN 'cancelled' THEN CASE
        WHEN COALESCE(assigned, 0) > 0 OR COALESCE(delivered, 0) > 0 THEN 'partial'
        ELSE 'failed'
      END
      WHEN 'canceled' THEN CASE
        WHEN COALESCE(assigned, 0) > 0 OR COALESCE(delivered, 0) > 0 THEN 'partial'
        ELSE 'failed'
      END
      ELSE CASE
        WHEN COALESCE(assigned, 0) > 0 OR COALESCE(delivered, 0) > 0 THEN 'partial'
        ELSE 'failed'
      END
    END
    WHERE lower(trim(COALESCE(status, ''))) NOT IN
      ('queued','running','completed','failed','partial');

    ALTER TABLE public.pipeline_runs
      ADD CONSTRAINT pipeline_runs_status_check
      CHECK (status IN ('queued','running','completed','failed','partial'));
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 24: 20261001000800_leadx_15_9_durable_job_accounting.sql
-- ============================================================================

-- LeadX 15.9: additive durable job identity and fail-closed accounting boundary.
--
-- This migration deliberately leaves public.jobs statuses, existing
-- operation_idempotency behavior, billing ledgers, and credit/refund functions
-- unchanged. New job-aware submissions use job_operations and the RPC below;
-- older application versions continue to read their existing tables normally.

-- The reservation column already exists in the canonical chain, but retaining
-- IF NOT EXISTS makes this migration safe for supported older installations.
ALTER TABLE IF EXISTS public.usage_log
  ADD COLUMN IF NOT EXISTS quota_reserved integer NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS public.usage_log
  ADD COLUMN IF NOT EXISTS rollover_credits integer NOT NULL DEFAULT 0;

-- One durable operation identity per normalized operation/idempotency key.
-- The unique operation/key constraint intentionally makes a scope or request
-- mismatch a conflict instead of allowing a second job for the same key.
CREATE TABLE IF NOT EXISTS public.job_operations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  operation_kind text NOT NULL,
  idempotency_key text NOT NULL,
  scope_hash text NOT NULL,
  request_hash text NOT NULL,
  job_id uuid UNIQUE REFERENCES public.jobs(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'processing'
    CHECK (status IN ('processing','completed','rejected','cancelled')),
  response jsonb NOT NULL DEFAULT '{}'::jsonb,
  accounting_status text NOT NULL DEFAULT 'none'
    CHECK (accounting_status IN ('none','reserved','consumed','released','rejected')),
  accounting_amount integer NOT NULL DEFAULT 0 CHECK (accounting_amount >= 0),
  accounting_period date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (operation_kind, idempotency_key)
);

-- Existing installations may have a pre-created compatible table. These
-- additive declarations keep the RPC's referenced columns available without
-- rewriting or deleting existing rows.
ALTER TABLE IF EXISTS public.job_operations
  ADD COLUMN IF NOT EXISTS id uuid,
  ADD COLUMN IF NOT EXISTS tenant_id uuid,
  ADD COLUMN IF NOT EXISTS operation_kind text,
  ADD COLUMN IF NOT EXISTS idempotency_key text,
  ADD COLUMN IF NOT EXISTS scope_hash text,
  ADD COLUMN IF NOT EXISTS request_hash text,
  ADD COLUMN IF NOT EXISTS job_id uuid,
  ADD COLUMN IF NOT EXISTS status text,
  ADD COLUMN IF NOT EXISTS response jsonb,
  ADD COLUMN IF NOT EXISTS accounting_status text,
  ADD COLUMN IF NOT EXISTS accounting_amount integer,
  ADD COLUMN IF NOT EXISTS accounting_period date,
  ADD COLUMN IF NOT EXISTS created_at timestamptz,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS uq_job_operations_operation_key
  ON public.job_operations(operation_kind, idempotency_key);
CREATE UNIQUE INDEX IF NOT EXISTS uq_job_operations_job
  ON public.job_operations(job_id) WHERE job_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_job_operations_tenant_created
  ON public.job_operations(tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_job_operations_accounting
  ON public.job_operations(accounting_status, updated_at DESC);

-- This ledger is backend-only. Explicit RLS/revocation protects deployments
-- where default privileges were established before this table was introduced.
ALTER TABLE IF EXISTS public.job_operations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.job_operations FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.job_operations TO service_role;

-- Atomically claim/replay one job identity and reserve monthly quota before a
-- provider-bound worker is allowed to begin. The caller supplies the result of
-- the existing authentication/authorization boundary in p_authorized; this
-- function never grants authorization based on a tenant id supplied by a
-- browser. It is executable only by the trusted backend service role.
CREATE OR REPLACE FUNCTION public.leadx_prepare_job(
  p_tenant_id uuid,
  p_operation_kind text,
  p_idempotency_key text,
  p_scope_hash text,
  p_request_hash text,
  p_job_kind text,
  p_payload jsonb DEFAULT '{}'::jsonb,
  p_requested_credits integer DEFAULT 0,
  p_authorized boolean DEFAULT true,
  p_priority integer DEFAULT 0,
  p_delay_seconds integer DEFAULT 0,
  p_max_attempts integer DEFAULT 3,
  p_created_by text DEFAULT 'api'
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_operation_kind text := lower(btrim(coalesce(p_operation_kind, '')));
  v_idempotency_key text := btrim(coalesce(p_idempotency_key, ''));
  v_scope_hash text := lower(btrim(coalesce(p_scope_hash, '')));
  v_request_hash text := lower(btrim(coalesce(p_request_hash, '')));
  v_job_kind text := btrim(coalesce(p_job_kind, ''));
  v_period date := date_trunc('month', now())::date;
  v_existing public.job_operations%ROWTYPE;
  v_tenant_id uuid;
  v_limit integer;
  v_used integer;
  v_reserved integer;
  v_rollover integer;
  v_available integer;
  v_job_id uuid;
  v_new boolean;
  v_response jsonb;
BEGIN
  -- Reject malformed identities before any durable side effect.
  IF p_tenant_id IS NULL OR v_operation_kind = '' OR v_idempotency_key = ''
     OR v_scope_hash = '' OR v_request_hash = '' OR v_job_kind = '' THEN
    RETURN jsonb_build_object(
      'ok', false, 'outcome', 'invalid_request',
      'reason', 'durable_job_identity_required'
    );
  END IF;
  IF length(v_idempotency_key) > 200 OR length(v_operation_kind) > 160
     OR length(v_scope_hash) > 256 OR length(v_request_hash) > 256
     OR length(v_job_kind) > 160 THEN
    RETURN jsonb_build_object(
      'ok', false, 'outcome', 'invalid_request', 'reason', 'durable_job_identity_too_large'
    );
  END IF;
  IF p_requested_credits IS NULL OR p_requested_credits < 0
     OR p_requested_credits > 100000
     OR p_max_attempts IS NULL OR p_max_attempts < 1 OR p_max_attempts > 100
     OR p_delay_seconds IS NULL OR p_delay_seconds < 0 OR p_delay_seconds > 31536000 THEN
    RETURN jsonb_build_object(
      'ok', false, 'outcome', 'invalid_request', 'reason', 'durable_job_parameters_invalid'
    );
  END IF;

  -- Serialize quota reservations for the tenant and prove that the tenant is
  -- still present before writing an operation row with its foreign key.
  SELECT t.id, COALESCE(t.leads_per_month_limit, 0)
    INTO v_tenant_id, v_limit
  FROM public.tenants t
  WHERE t.id = p_tenant_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'ok', false, 'outcome', 'rejected', 'reason', 'tenant_not_found'
    );
  END IF;

  -- The unique operation/key index plus the tenant lock make the insert/replay
  -- decision deterministic for concurrent requests from the same tenant.
  INSERT INTO public.job_operations(
    tenant_id, operation_kind, idempotency_key, scope_hash, request_hash,
    status, response, accounting_status, accounting_amount, created_at, updated_at
  ) VALUES (
    p_tenant_id, v_operation_kind, v_idempotency_key, v_scope_hash, v_request_hash,
    'processing', '{}'::jsonb, 'none', 0, now(), now()
  )
  ON CONFLICT (operation_kind, idempotency_key) DO NOTHING
  RETURNING * INTO v_existing;
  v_new := FOUND;

  IF NOT v_new THEN
    SELECT * INTO v_existing
    FROM public.job_operations
    WHERE operation_kind = v_operation_kind
      AND idempotency_key = v_idempotency_key
    FOR UPDATE;

    IF v_existing.tenant_id IS DISTINCT FROM p_tenant_id
       OR v_existing.scope_hash <> v_scope_hash
       OR v_existing.request_hash <> v_request_hash THEN
      RETURN jsonb_build_object(
        'ok', false, 'outcome', 'conflict', 'reason', 'idempotency_mismatch'
      );
    END IF;

    -- Never disclose an existing job or response to a caller that failed the
    -- existing API authorization boundary, even when the identity is known.
    IF NOT COALESCE(p_authorized, false) THEN
      RETURN jsonb_build_object(
        'ok', false, 'outcome', 'rejected', 'reason', 'unauthorized'
      );
    END IF;

    IF v_existing.status IN ('completed', 'rejected', 'cancelled') THEN
      RETURN COALESCE(v_existing.response, '{}'::jsonb) || jsonb_build_object(
        'ok', CASE WHEN v_existing.status = 'rejected' THEN false ELSE true END,
        'outcome', 'replay', 'replayed', true,
        'job_id', v_existing.job_id,
        'status', v_existing.status,
        'accounting_status', v_existing.accounting_status
      );
    END IF;

    RETURN jsonb_build_object(
      'ok', true, 'outcome', 'in_progress', 'replayed', false,
      'job_id', v_existing.job_id, 'status', v_existing.status,
      'accounting_status', v_existing.accounting_status
    );
  END IF;

  -- Authorization is decided by the existing API boundary. Persist a safe
  -- denial so a retry with the same identity cannot create provider work.
  IF NOT COALESCE(p_authorized, false) THEN
    v_response := jsonb_build_object(
      'ok', false, 'outcome', 'rejected', 'reason', 'unauthorized'
    );
    UPDATE public.job_operations
    SET status = 'rejected', response = v_response,
        accounting_status = 'rejected', updated_at = now()
    WHERE id = v_existing.id;
    RETURN v_response;
  END IF;

  -- Lock/create the monthly usage row and reserve before inserting the job.
  -- rollover_credits is included in the existing free-before-paid quota
  -- contract; this migration does not alter paid-credit or refund behavior.
  IF p_requested_credits > 0 THEN
    INSERT INTO public.usage_log(
      tenant_id, period, leads_delivered, quota_reserved, rollover_credits, updated_at
    ) VALUES (p_tenant_id, v_period, 0, 0, 0, now())
    ON CONFLICT (tenant_id, period) DO NOTHING;

    SELECT COALESCE(ul.leads_delivered, 0),
           COALESCE(ul.quota_reserved, 0),
           COALESCE(ul.rollover_credits, 0)
      INTO v_used, v_reserved, v_rollover
    FROM public.usage_log ul
    WHERE ul.tenant_id = p_tenant_id AND ul.period = v_period
    FOR UPDATE;

    v_available := GREATEST(v_limit + v_rollover - v_used - v_reserved, 0);
    IF v_available < p_requested_credits THEN
      v_response := jsonb_build_object(
        'ok', false, 'outcome', 'rejected', 'reason', 'insufficient_credits',
        'requested', p_requested_credits, 'available', v_available,
        'period', v_period
      );
      UPDATE public.job_operations
      SET status = 'rejected', response = v_response,
          accounting_status = 'rejected', accounting_period = v_period,
          accounting_amount = p_requested_credits, updated_at = now()
      WHERE id = v_existing.id;
      RETURN v_response;
    END IF;

    UPDATE public.usage_log
    SET quota_reserved = quota_reserved + p_requested_credits, updated_at = now()
    WHERE tenant_id = p_tenant_id AND period = v_period;
  END IF;

  v_job_id := gen_random_uuid();
  INSERT INTO public.jobs(
    id, tenant_id, kind, payload, status, priority, attempts, max_attempts,
    run_after, created_by
  ) VALUES (
    v_job_id, p_tenant_id, v_job_kind, COALESCE(p_payload, '{}'::jsonb), 'queued',
    COALESCE(p_priority, 0), 0, p_max_attempts,
    now() + make_interval(secs => p_delay_seconds),
    left(coalesce(p_created_by, 'api'), 160)
  );

  v_response := jsonb_build_object(
    'ok', true, 'outcome', 'accepted', 'replayed', false,
    'job_id', v_job_id, 'status', 'queued',
    'accounting_status', CASE WHEN p_requested_credits > 0 THEN 'reserved' ELSE 'none' END,
    'accounting_amount', p_requested_credits,
    'accounting_period', CASE WHEN p_requested_credits > 0 THEN v_period ELSE NULL END
  );
  UPDATE public.job_operations
  SET job_id = v_job_id, status = 'processing', response = v_response,
      accounting_status = CASE WHEN p_requested_credits > 0 THEN 'reserved' ELSE 'none' END,
      accounting_amount = p_requested_credits,
      accounting_period = CASE WHEN p_requested_credits > 0 THEN v_period ELSE NULL END,
      updated_at = now()
  WHERE id = v_existing.id;

  RETURN v_response;
END;
$$;

-- Finish the durable idempotency record without changing the existing HTTP
-- operation_idempotency RPCs. This is intentionally separate from worker job
-- state transitions; task 10 will call it only after durable job outcomes are
-- known.
CREATE OR REPLACE FUNCTION public.leadx_finish_job_operation(
  p_job_id uuid,
  p_status text,
  p_response jsonb DEFAULT '{}'::jsonb
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_status text := lower(btrim(coalesce(p_status, '')));
  v_row public.job_operations%ROWTYPE;
BEGIN
  IF p_job_id IS NULL OR v_status NOT IN ('completed', 'rejected', 'cancelled') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_job_operation_status');
  END IF;
  SELECT * INTO v_row
  FROM public.job_operations
  WHERE job_id = p_job_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'job_operation_not_found');
  END IF;
  IF v_row.status IN ('completed', 'rejected', 'cancelled') THEN
    RETURN COALESCE(v_row.response, '{}'::jsonb) || jsonb_build_object(
      'ok', v_row.status = 'completed', 'outcome', 'replay', 'replayed', true
    );
  END IF;
  UPDATE public.job_operations
  SET status = v_status, response = COALESCE(p_response, '{}'::jsonb), updated_at = now()
  WHERE id = v_row.id;
  RETURN jsonb_build_object(
    'ok', v_status = 'completed', 'outcome', v_status, 'job_id', p_job_id
  ) || COALESCE(p_response, '{}'::jsonb);
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_prepare_job(uuid,text,text,text,text,text,jsonb,integer,boolean,integer,integer,integer,text)
  FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.leadx_finish_job_operation(uuid,text,jsonb)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_prepare_job(uuid,text,text,text,text,text,jsonb,integer,boolean,integer,integer,integer,text)
  TO service_role;
GRANT EXECUTE ON FUNCTION public.leadx_finish_job_operation(uuid,text,jsonb)
  TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 25: 20261001000900_leadx_15_10_durable_handoff.sql
-- ============================================================================

-- LeadX 15.10: settle task-9 accounting reservations at one terminal outcome.
-- Additive replacement: queued/running jobs and existing operation rows remain
-- valid; retries leave a reservation in place until completion, cancellation,
-- or terminal failure is durably finalized.

CREATE OR REPLACE FUNCTION public.leadx_finish_job_operation(
  p_job_id uuid,
  p_status text,
  p_response jsonb DEFAULT '{}'::jsonb
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_status text := lower(btrim(coalesce(p_status, '')));
  v_row public.job_operations%ROWTYPE;
  v_accounting_status text;
BEGIN
  IF p_job_id IS NULL OR v_status NOT IN ('completed', 'rejected', 'cancelled') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_job_operation_status');
  END IF;

  SELECT * INTO v_row
  FROM public.job_operations
  WHERE job_id = p_job_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'job_operation_not_found');
  END IF;

  -- Completion callbacks and worker retries are safe replays. The first
  -- terminal transition owns accounting settlement; later callbacks return
  -- the original response without touching quota again.
  IF v_row.status IN ('completed', 'rejected', 'cancelled') THEN
    RETURN COALESCE(v_row.response, '{}'::jsonb) || jsonb_build_object(
      'ok', v_row.status = 'completed', 'outcome', 'replay', 'replayed', true
    );
  END IF;

  IF v_row.accounting_status = 'reserved'
     AND COALESCE(v_row.accounting_amount, 0) > 0
     AND v_row.accounting_period IS NOT NULL THEN
    UPDATE public.usage_log
    SET quota_reserved = GREATEST(COALESCE(quota_reserved, 0) - v_row.accounting_amount, 0),
        leads_delivered = CASE
          WHEN v_status = 'completed'
            THEN COALESCE(leads_delivered, 0) + v_row.accounting_amount
          ELSE COALESCE(leads_delivered, 0)
        END,
        updated_at = now()
    WHERE tenant_id = v_row.tenant_id
      AND period = v_row.accounting_period;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'durable accounting reservation row missing';
    END IF;
    v_accounting_status := CASE
      WHEN v_status = 'completed' THEN 'consumed'
      ELSE 'released'
    END;
  ELSE
    v_accounting_status := CASE
      WHEN v_status = 'completed' AND v_row.accounting_status = 'none' THEN 'none'
      ELSE v_row.accounting_status
    END;
  END IF;

  UPDATE public.job_operations
  SET status = v_status,
      response = COALESCE(p_response, '{}'::jsonb),
      accounting_status = v_accounting_status,
      updated_at = now()
  WHERE id = v_row.id;

  RETURN jsonb_build_object(
    'ok', v_status = 'completed',
    'outcome', v_status,
    'job_id', p_job_id,
    'accounting_status', v_accounting_status
  ) || COALESCE(p_response, '{}'::jsonb);
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_finish_job_operation(uuid,text,jsonb)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_finish_job_operation(uuid,text,jsonb)
  TO service_role;

NOTIFY pgrst, 'reload schema';

-- Reopen only an exhausted/cancelled operation for an explicit admin retry.
-- This re-reserves the original amount before the worker can run again.
CREATE OR REPLACE FUNCTION public.leadx_reopen_job_operation(
  p_job_id uuid
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.job_operations%ROWTYPE;
  v_limit integer;
  v_used integer;
  v_reserved integer;
  v_rollover integer;
  v_available integer;
BEGIN
  SELECT * INTO v_row
  FROM public.job_operations
  WHERE job_id = p_job_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', true, 'reason', 'job_operation_not_found');
  END IF;
  IF v_row.status = 'processing' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'job_operation_in_progress');
  END IF;
  IF v_row.status = 'completed' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'job_operation_completed');
  END IF;

  IF COALESCE(v_row.accounting_amount, 0) > 0
     AND v_row.accounting_period IS NOT NULL
     AND COALESCE(v_row.accounting_status, 'none') <> 'reserved' THEN
    SELECT COALESCE(t.leads_per_month_limit, 0) INTO v_limit
    FROM public.tenants t WHERE t.id = v_row.tenant_id FOR UPDATE;
    INSERT INTO public.usage_log(
      tenant_id, period, leads_delivered, quota_reserved, rollover_credits, updated_at
    ) VALUES (v_row.tenant_id, v_row.accounting_period, 0, 0, 0, now())
    ON CONFLICT (tenant_id, period) DO NOTHING;
    SELECT COALESCE(leads_delivered, 0), COALESCE(quota_reserved, 0),
           COALESCE(rollover_credits, 0)
      INTO v_used, v_reserved, v_rollover
    FROM public.usage_log
    WHERE tenant_id = v_row.tenant_id AND period = v_row.accounting_period
    FOR UPDATE;
    v_available := GREATEST(v_limit + v_rollover - v_used - v_reserved, 0);
    IF v_available < v_row.accounting_amount THEN
      RETURN jsonb_build_object(
        'ok', false, 'reason', 'insufficient_credits',
        'requested', v_row.accounting_amount, 'available', v_available
      );
    END IF;
    UPDATE public.usage_log
    SET quota_reserved = quota_reserved + v_row.accounting_amount, updated_at = now()
    WHERE tenant_id = v_row.tenant_id AND period = v_row.accounting_period;
  END IF;

  UPDATE public.job_operations
  SET status = 'processing', response = '{}'::jsonb,
      accounting_status = CASE WHEN COALESCE(accounting_amount, 0) > 0
        THEN 'reserved' ELSE accounting_status END,
      updated_at = now()
  WHERE id = v_row.id;
  RETURN jsonb_build_object('ok', true, 'outcome', 'reopened', 'job_id', p_job_id);
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_reopen_job_operation(uuid)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_reopen_job_operation(uuid)
  TO service_role;

-- ============================================================================
-- CANONICAL MIGRATION 26: 20261001000950_leadx_16_durable_task_recovery.sql
-- ============================================================================

-- LeadX 16.0: additive durable task recovery and accounting identity.
-- This migration preserves all existing status values, rows, RLS, and job
-- operation semantics.  New columns are nullable/defaulted for old rows.

ALTER TABLE IF EXISTS public.jobs ADD COLUMN IF NOT EXISTS lease_expires_at timestamptz;
ALTER TABLE IF EXISTS public.jobs ADD COLUMN IF NOT EXISTS retry_after timestamptz;
ALTER TABLE IF EXISTS public.jobs ADD COLUMN IF NOT EXISTS error_category text;
ALTER TABLE IF EXISTS public.jobs ADD COLUMN IF NOT EXISTS dependency_outcome text;
ALTER TABLE IF EXISTS public.jobs ADD COLUMN IF NOT EXISTS terminal_result jsonb;
ALTER TABLE IF EXISTS public.jobs ADD COLUMN IF NOT EXISTS accounting_reconciliation_status text DEFAULT 'not_required';
CREATE INDEX IF NOT EXISTS idx_jobs_due_lease ON public.jobs(status, run_after, lease_expires_at);
CREATE INDEX IF NOT EXISTS idx_jobs_retry_after ON public.jobs(retry_after) WHERE status = 'queued';

ALTER TABLE IF EXISTS public.job_operations ADD COLUMN IF NOT EXISTS principal_scope text NOT NULL DEFAULT '';
ALTER TABLE IF EXISTS public.job_operations ADD COLUMN IF NOT EXISTS terminal_result jsonb;
ALTER TABLE IF EXISTS public.job_operations ADD COLUMN IF NOT EXISTS settlement_key text;
CREATE INDEX IF NOT EXISTS idx_job_operations_principal ON public.job_operations(tenant_id, principal_scope, operation_kind, idempotency_key);

ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS progress_total integer NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS progress_completed integer NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS progress_failed integer NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS progress_skipped integer NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS progress_remaining integer NOT NULL DEFAULT 30;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS failure_summary jsonb;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS terminal_result jsonb;
ALTER TABLE IF EXISTS public.agent_missions ADD COLUMN IF NOT EXISTS completed_at timestamptz;

ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS attempts integer NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS max_attempts integer NOT NULL DEFAULT 3;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS run_after timestamptz NOT NULL DEFAULT now();
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS lease_owner text;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS lease_expires_at timestamptz;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS lease_renewed_at timestamptz;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS error_category text;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS dependency_outcome text;
ALTER TABLE IF EXISTS public.agent_mission_tasks ADD COLUMN IF NOT EXISTS terminal_result jsonb;
CREATE INDEX IF NOT EXISTS idx_mission_tasks_due_lease
  ON public.agent_mission_tasks(status, run_after, lease_expires_at);
CREATE INDEX IF NOT EXISTS idx_mission_tasks_owner
  ON public.agent_mission_tasks(tenant_id, lease_owner) WHERE status = 'running';

CREATE TABLE IF NOT EXISTS public.job_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  attempt integer NOT NULL CHECK (attempt > 0),
  owner text,
  claimed_at timestamptz NOT NULL DEFAULT now(),
  lease_expires_at timestamptz,
  finished_at timestamptz,
  outcome text,
  retryable boolean,
  error_category text,
  error text,
  result jsonb,
  UNIQUE(job_id, attempt)
);
CREATE INDEX IF NOT EXISTS idx_job_attempts_tenant_job ON public.job_attempts(tenant_id, job_id, attempt);
ALTER TABLE public.job_attempts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.job_attempts FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.job_attempts TO service_role;

CREATE TABLE IF NOT EXISTS public.agent_mission_task_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.agent_mission_tasks(id) ON DELETE CASCADE,
  mission_id uuid NOT NULL REFERENCES public.agent_missions(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  attempt integer NOT NULL CHECK (attempt > 0),
  owner text NOT NULL,
  claimed_at timestamptz NOT NULL DEFAULT now(),
  lease_expires_at timestamptz,
  finished_at timestamptz,
  outcome text,
  retryable boolean,
  error_category text,
  error text,
  result jsonb,
  UNIQUE(task_id, attempt)
);
CREATE INDEX IF NOT EXISTS idx_mission_task_attempts_task ON public.agent_mission_task_attempts(tenant_id, task_id, attempt);
ALTER TABLE public.agent_mission_task_attempts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.agent_mission_task_attempts FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.agent_mission_task_attempts TO service_role;

CREATE TABLE IF NOT EXISTS public.quota_reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  operation_id uuid REFERENCES public.job_operations(id) ON DELETE SET NULL,
  requested_quantity integer NOT NULL DEFAULT 0 CHECK (requested_quantity >= 0),
  reserved_quantity integer NOT NULL DEFAULT 0 CHECK (reserved_quantity >= 0),
  committed_quantity integer NOT NULL DEFAULT 0 CHECK (committed_quantity >= 0),
  released_quantity integer NOT NULL DEFAULT 0 CHECK (released_quantity >= 0),
  status text NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved','committed','released','rejected')),
  settlement_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, settlement_key)
);
CREATE INDEX IF NOT EXISTS idx_quota_reservations_job ON public.quota_reservations(tenant_id, job_id);
CREATE INDEX IF NOT EXISTS idx_quota_reservations_status ON public.quota_reservations(tenant_id, status, updated_at);
ALTER TABLE public.quota_reservations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.quota_reservations FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.quota_reservations TO service_role;

CREATE TABLE IF NOT EXISTS public.quota_settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reservation_id uuid NOT NULL REFERENCES public.quota_reservations(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  settlement_key text NOT NULL,
  outcome text NOT NULL CHECK (outcome IN ('committed','released','rejected')),
  quantity integer NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(reservation_id, settlement_key)
);
CREATE INDEX IF NOT EXISTS idx_quota_settlements_tenant ON public.quota_settlements(tenant_id, created_at DESC);
ALTER TABLE public.quota_settlements ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.quota_settlements FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.quota_settlements TO service_role;

ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS queue_capability boolean NOT NULL DEFAULT false;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS queue_checked_at timestamptz;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS reclaim_capability boolean NOT NULL DEFAULT false;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS reclaim_checked_at timestamptz;
ALTER TABLE IF EXISTS public.worker_heartbeats ADD COLUMN IF NOT EXISTS last_terminal_error_category text;
CREATE INDEX IF NOT EXISTS idx_worker_heartbeats_capability ON public.worker_heartbeats(status, queue_checked_at, reclaim_checked_at);

CREATE OR REPLACE FUNCTION public.leadx_claim_next_job(p_worker_id text, p_kinds text[] DEFAULT NULL)
RETURNS SETOF public.jobs LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.jobs%rowtype; v_lease_seconds integer := GREATEST(30, COALESCE(NULLIF(current_setting('app.job_lease_seconds', true), '')::integer, 2700));
BEGIN
  SELECT * INTO r FROM public.jobs
   WHERE status = 'queued' AND run_after <= now()
     AND (p_kinds IS NULL OR kind = ANY(p_kinds))
   ORDER BY priority DESC, created_at
   FOR UPDATE SKIP LOCKED LIMIT 1;
  IF r.id IS NULL THEN RETURN; END IF;
  UPDATE public.jobs SET status='running', locked_by=p_worker_id, locked_at=now(), lease_renewed_at=now(),
    lease_expires_at=now() + make_interval(secs => v_lease_seconds), started_at=COALESCE(started_at, now()),
    attempts=COALESCE(attempts,0)+1, error_category=NULL, dependency_outcome='claimed'
   WHERE id=r.id AND status='queued' RETURNING * INTO r;
  INSERT INTO public.job_attempts(job_id,tenant_id,attempt,owner,lease_expires_at)
    VALUES(r.id,r.tenant_id,r.attempts,p_worker_id,r.lease_expires_at)
    ON CONFLICT(job_id,attempt) DO NOTHING;
  RETURN NEXT r;
END $$;
REVOKE ALL ON FUNCTION public.leadx_claim_next_job(text,text[]) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_claim_next_job(text,text[]) TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_probe_queue_capability(p_worker_id text, p_checked_at timestamptz DEFAULT now())
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF p_worker_id IS NULL OR btrim(p_worker_id) = '' THEN
    RETURN jsonb_build_object('ok',false,'reclaim_capability',false,'reason','worker_id_required');
  END IF;
  RETURN jsonb_build_object('ok',true,'worker_id',p_worker_id,'checked_at',COALESCE(p_checked_at,now()),
    'queue_capability',true,'reclaim_capability',to_regprocedure('public.leadx_reap_stale_mission_tasks(integer)') IS NOT NULL);
END $$;
REVOKE ALL ON FUNCTION public.leadx_probe_queue_capability(text,timestamptz) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_probe_queue_capability(text,timestamptz) TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_claim_mission_task(
  p_task_id uuid, p_tenant_id uuid, p_owner text, p_lease_seconds integer DEFAULT 900
) RETURNS SETOF public.agent_mission_tasks LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.agent_mission_tasks%rowtype; v_attempt integer;
BEGIN
  SELECT * INTO r FROM public.agent_mission_tasks WHERE id=p_task_id AND tenant_id=p_tenant_id
    AND status='queued' AND run_after <= now() FOR UPDATE SKIP LOCKED;
  IF r.id IS NULL THEN RETURN; END IF;
  v_attempt := COALESCE(r.attempts,0)+1;
  UPDATE public.agent_mission_tasks SET status='running', attempts=v_attempt,
    lease_owner=p_owner, lease_renewed_at=now(), lease_expires_at=now()+make_interval(secs=>GREATEST(30,p_lease_seconds)),
    started_at=COALESCE(started_at,now()), error=NULL, error_category=NULL, dependency_outcome='claimed', updated_at=now()
    WHERE id=r.id AND tenant_id=p_tenant_id AND status='queued' RETURNING * INTO r;
  INSERT INTO public.agent_mission_task_attempts(task_id,mission_id,tenant_id,attempt,owner,lease_expires_at)
    VALUES(r.id,r.mission_id,r.tenant_id,r.attempts,r.lease_owner,r.lease_expires_at)
    ON CONFLICT(task_id,attempt) DO NOTHING;
  RETURN NEXT r;
END $$;
REVOKE ALL ON FUNCTION public.leadx_claim_mission_task(uuid,uuid,text,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_claim_mission_task(uuid,uuid,text,integer) TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_renew_mission_task(
  p_task_id uuid, p_tenant_id uuid, p_owner text, p_lease_seconds integer DEFAULT 900
) RETURNS SETOF public.agent_mission_tasks LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  RETURN QUERY UPDATE public.agent_mission_tasks SET lease_renewed_at=now(),
    lease_expires_at=now()+make_interval(secs=>GREATEST(30,p_lease_seconds)), updated_at=now()
   WHERE id=p_task_id AND tenant_id=p_tenant_id AND status='running' AND lease_owner=p_owner
     AND (lease_expires_at IS NULL OR lease_expires_at > now()) RETURNING *;
END $$;
REVOKE ALL ON FUNCTION public.leadx_renew_mission_task(uuid,uuid,text,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_renew_mission_task(uuid,uuid,text,integer) TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_reap_stale_mission_tasks(p_limit integer DEFAULT 500)
RETURNS SETOF public.agent_mission_tasks LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.agent_mission_tasks%rowtype; v_status text;
BEGIN
  FOR r IN SELECT * FROM public.agent_mission_tasks
    WHERE status='running' AND lease_expires_at IS NOT NULL AND lease_expires_at < now()
    ORDER BY lease_expires_at LIMIT GREATEST(1,LEAST(p_limit,500)) FOR UPDATE SKIP LOCKED LOOP
    v_status := CASE WHEN COALESCE(r.attempts,0) < COALESCE(r.max_attempts,3) THEN 'queued' ELSE 'failed' END;
    UPDATE public.agent_mission_tasks SET status=v_status, lease_owner=NULL, lease_expires_at=NULL,
      error='worker_lost_reaped', error_category='lease_expired', dependency_outcome=CASE WHEN v_status='queued' THEN 'recovered' ELSE 'terminal' END,
      run_after=CASE WHEN v_status='queued' THEN now()+make_interval(secs=>LEAST(3600,60*2^GREATEST(0,r.attempts-1))) ELSE now() END,
      finished_at=CASE WHEN v_status='failed' THEN now() ELSE NULL END,
      terminal_result=CASE WHEN v_status='failed' THEN jsonb_build_object('status','failed','error_category','lease_expired') ELSE NULL END,
      updated_at=now()
      WHERE id=r.id AND status='running' AND lease_expires_at < now() RETURNING * INTO r;
    UPDATE public.agent_mission_task_attempts SET finished_at=now(), outcome=v_status, retryable=(v_status='queued'), error_category='lease_expired'
      WHERE task_id=r.id AND attempt=r.attempts AND finished_at IS NULL;
    RETURN NEXT r;
  END LOOP;
END $$;
REVOKE ALL ON FUNCTION public.leadx_reap_stale_mission_tasks(integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_reap_stale_mission_tasks(integer) TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_record_quota_settlement(
  p_reservation_id uuid, p_tenant_id uuid, p_settlement_key text, p_outcome text, p_quantity integer DEFAULT 0
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.quota_reservations%rowtype; v_outcome text := lower(btrim(coalesce(p_outcome,'')));
BEGIN
  IF v_outcome NOT IN ('committed','released','rejected') OR p_quantity < 0 THEN
    RETURN jsonb_build_object('ok',false,'reason','invalid_settlement');
  END IF;
  SELECT * INTO r FROM public.quota_reservations WHERE id=p_reservation_id AND tenant_id=p_tenant_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','reservation_not_found'); END IF;
  INSERT INTO public.quota_settlements(reservation_id,tenant_id,settlement_key,outcome,quantity)
    VALUES(r.id,r.tenant_id,p_settlement_key,v_outcome,p_quantity)
    ON CONFLICT(reservation_id,settlement_key) DO NOTHING;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',true,'outcome','replay','settlement_key',p_settlement_key); END IF;
  IF r.status <> 'reserved' THEN RETURN jsonb_build_object('ok',true,'outcome','replay','status',r.status); END IF;
  UPDATE public.quota_reservations SET status=v_outcome,
    committed_quantity=CASE WHEN v_outcome='committed' THEN p_quantity ELSE committed_quantity END,
    released_quantity=CASE WHEN v_outcome IN ('released','rejected') THEN p_quantity ELSE released_quantity END,
    updated_at=now() WHERE id=r.id;
  RETURN jsonb_build_object('ok',true,'outcome',v_outcome,'settlement_key',p_settlement_key);
END $$;
REVOKE ALL ON FUNCTION public.leadx_record_quota_settlement(uuid,uuid,text,text,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_record_quota_settlement(uuid,uuid,text,text,integer) TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 27: 20261001001000_leadx_16_migration_preflight.sql
-- ============================================================================

-- LeadX 16.0: additive durable migration preflight.
-- This database-only preflight is intentionally callable by startup before any
-- provider-bound work. It reports missing durable objects without changing data.

CREATE OR REPLACE FUNCTION public.leadx_verify_durable_preflight()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_missing text[] := ARRAY[]::text[];
  v_rls boolean;
BEGIN
  IF to_regclass('public.job_operations') IS NULL THEN
    v_missing := v_missing || 'table:job_operations';
  END IF;
  IF to_regclass('public.job_attempts') IS NULL THEN
    v_missing := v_missing || 'table:job_attempts';
  END IF;
  IF to_regclass('public.agent_mission_task_attempts') IS NULL THEN
    v_missing := v_missing || 'table:agent_mission_task_attempts';
  END IF;
  IF to_regclass('public.quota_reservations') IS NULL THEN
    v_missing := v_missing || 'table:quota_reservations';
  END IF;
  IF to_regprocedure('public.leadx_reap_stale_mission_tasks(integer)') IS NULL THEN
    v_missing := v_missing || 'function:leadx_reap_stale_mission_tasks';
  END IF;
  IF to_regprocedure('public.leadx_probe_queue_capability(text,timestamptz)') IS NULL THEN
    v_missing := v_missing || 'function:leadx_probe_queue_capability';
  END IF;
  IF to_regclass('public.uq_job_operations_operation_key') IS NULL THEN
    v_missing := v_missing || 'index:uq_job_operations_operation_key';
  END IF;
  IF to_regclass('public.uq_job_operations_job') IS NULL THEN
    v_missing := v_missing || 'index:uq_job_operations_job';
  END IF;
  IF to_regclass('public.idx_job_operations_tenant_created') IS NULL THEN
    v_missing := v_missing || 'index:idx_job_operations_tenant_created';
  END IF;
  IF to_regprocedure('public.leadx_prepare_job(uuid,text,text,text,text,text,jsonb,integer,boolean,integer,integer,integer,text)') IS NULL THEN
    v_missing := v_missing || 'function:leadx_prepare_job';
  END IF;
  IF to_regprocedure('public.leadx_finish_job_operation(uuid,text,jsonb)') IS NULL THEN
    v_missing := v_missing || 'function:leadx_finish_job_operation';
  END IF;
  IF to_regprocedure('public.leadx_reopen_job_operation(uuid)') IS NULL THEN
    v_missing := v_missing || 'function:leadx_reopen_job_operation';
  END IF;

  SELECT c.relrowsecurity INTO v_rls
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' AND c.relname = 'job_operations';
  IF COALESCE(v_rls, false) IS NOT TRUE THEN
    v_missing := v_missing || 'rls:job_operations';
  END IF;
  IF to_regclass('public.job_operations') IS NOT NULL
     AND NOT has_table_privilege('service_role', 'public.job_operations', 'SELECT') THEN
    v_missing := v_missing || 'grant:service_role.job_operations';
  END IF;
  IF to_regprocedure('public.leadx_prepare_job(uuid,text,text,text,text,text,jsonb,integer,boolean,integer,integer,integer,text)') IS NOT NULL
     AND NOT has_function_privilege('service_role', 'public.leadx_prepare_job(uuid,text,text,text,text,text,jsonb,integer,boolean,integer,integer,integer,text)', 'EXECUTE') THEN
    v_missing := v_missing || 'grant:service_role.leadx_prepare_job';
  END IF;

  RETURN jsonb_build_object(
    'ok', cardinality(v_missing) = 0,
    'migration_chain', '20261001000800..20261001000950',
    'checked_at', clock_timestamp(),
    'missing', to_jsonb(v_missing),
    'safe_to_start_provider_work', cardinality(v_missing) = 0
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.leadx_require_durable_preflight()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_result jsonb;
BEGIN
  v_result := public.leadx_verify_durable_preflight();
  IF COALESCE((v_result ->> 'ok')::boolean, false) IS NOT TRUE THEN
    RAISE EXCEPTION 'durable migration preflight failed: %', v_result -> 'missing';
  END IF;
  RETURN v_result;
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_verify_durable_preflight() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.leadx_require_durable_preflight() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_verify_durable_preflight() TO service_role;
GRANT EXECUTE ON FUNCTION public.leadx_require_durable_preflight() TO service_role;

COMMENT ON FUNCTION public.leadx_verify_durable_preflight() IS
  'Reports required durable job/accounting objects; callers must fail closed before provider work.';
COMMENT ON FUNCTION public.leadx_require_durable_preflight() IS
  'Raises when the durable job/accounting boundary is incomplete.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 28: 20261001001100_leadx_16_canonical_data_plane.sql
-- ============================================================================

-- LeadX 16.0: additive canonical account/contact/evidence projections.
-- Existing companies, contacts, lead_contacts, lead_evidence, CRM views, and
-- their statuses remain untouched. These projections are service-role owned.

CREATE TABLE IF NOT EXISTS public.canonical_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  source_company_id uuid REFERENCES public.companies(id) ON DELETE SET NULL,
  source_lead_id uuid REFERENCES public.leads_global(id) ON DELETE SET NULL,
  canonical_key text NOT NULL,
  name text NOT NULL,
  normalized_domain text,
  website text,
  phone text,
  field_confidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  provenance jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, canonical_key)
);

CREATE TABLE IF NOT EXISTS public.canonical_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES public.canonical_accounts(id) ON DELETE CASCADE,
  location_key text NOT NULL,
  address_line1 text,
  address_line2 text,
  city text,
  state text,
  postal_code text,
  country text,
  latitude numeric(9,6),
  longitude numeric(9,6),
  is_primary boolean NOT NULL DEFAULT false,
  field_confidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  provenance jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, account_id, location_key)
);

CREATE TABLE IF NOT EXISTS public.canonical_people (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES public.canonical_accounts(id) ON DELETE CASCADE,
  source_contact_id uuid REFERENCES public.contacts(id) ON DELETE SET NULL,
  source_lead_contact_id uuid REFERENCES public.lead_contacts(id) ON DELETE SET NULL,
  canonical_key text NOT NULL,
  first_name text,
  last_name text,
  full_name text,
  field_confidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  provenance jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, canonical_key)
);

CREATE TABLE IF NOT EXISTS public.canonical_contact_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  person_id uuid NOT NULL REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  method_type text NOT NULL CHECK (method_type IN ('email','phone','mobile','linkedin','other')),
  normalized_value text NOT NULL,
  value_hash text NOT NULL,
  is_primary boolean NOT NULL DEFAULT false,
  field_confidence numeric(5,4) CHECK (field_confidence IS NULL OR field_confidence BETWEEN 0 AND 1),
  provenance jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, method_type, value_hash)
);

CREATE TABLE IF NOT EXISTS public.canonical_titles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  person_id uuid NOT NULL REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  title text NOT NULL,
  normalized_title text NOT NULL,
  is_current boolean NOT NULL DEFAULT true,
  confidence numeric(5,4) CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
  observed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, person_id, normalized_title)
);

CREATE TABLE IF NOT EXISTS public.canonical_buying_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES public.canonical_accounts(id) ON DELETE CASCADE,
  group_key text NOT NULL,
  name text NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, account_id, group_key)
);

CREATE TABLE IF NOT EXISTS public.canonical_buying_group_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  buying_group_id uuid NOT NULL REFERENCES public.canonical_buying_groups(id) ON DELETE CASCADE,
  person_id uuid NOT NULL REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  role_type text NOT NULL,
  influence_score numeric(5,4) CHECK (influence_score IS NULL OR influence_score BETWEEN 0 AND 1),
  buying_authority text,
  evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (tenant_id, buying_group_id, person_id, role_type)
);

CREATE TABLE IF NOT EXISTS public.canonical_field_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  account_id uuid REFERENCES public.canonical_accounts(id) ON DELETE CASCADE,
  person_id uuid REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  contact_method_id uuid REFERENCES public.canonical_contact_methods(id) ON DELETE CASCADE,
  field_name text NOT NULL,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  source_type text NOT NULL,
  source_ref text,
  source_url text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  confidence numeric(5,4) CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
  evidence_hash text NOT NULL,
  is_current boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (num_nonnulls(account_id, person_id, contact_method_id) = 1),
  UNIQUE (tenant_id, evidence_hash)
);

CREATE TABLE IF NOT EXISTS public.canonical_freshness (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  subject_type text NOT NULL CHECK (subject_type IN ('account','location','person','contact_method')),
  subject_id uuid NOT NULL,
  field_name text NOT NULL,
  observed_at timestamptz NOT NULL,
  expires_at timestamptz,
  freshness_score numeric(5,4) CHECK (freshness_score IS NULL OR freshness_score BETWEEN 0 AND 1),
  source_evidence_id uuid REFERENCES public.canonical_field_evidence(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, subject_type, subject_id, field_name)
);

CREATE TABLE IF NOT EXISTS public.canonical_consents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  person_id uuid REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  contact_method_id uuid REFERENCES public.canonical_contact_methods(id) ON DELETE CASCADE,
  purpose text NOT NULL,
  state text NOT NULL CHECK (state IN ('granted','denied','unknown','withdrawn','expired')),
  source text NOT NULL,
  captured_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  evidence_id uuid REFERENCES public.canonical_field_evidence(id) ON DELETE SET NULL,
  CHECK (num_nonnulls(person_id, contact_method_id) = 1)
);

CREATE TABLE IF NOT EXISTS public.canonical_suppressions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  person_id uuid REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  contact_method_id uuid REFERENCES public.canonical_contact_methods(id) ON DELETE CASCADE,
  channel text NOT NULL CHECK (channel IN ('email','phone','all')),
  reason text NOT NULL,
  source text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  suppressed_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  CHECK (num_nonnulls(person_id, contact_method_id) = 1)
);

CREATE INDEX IF NOT EXISTS idx_canonical_accounts_tenant_name
  ON public.canonical_accounts(tenant_id, lower(name));
CREATE INDEX IF NOT EXISTS idx_canonical_locations_account
  ON public.canonical_locations(tenant_id, account_id, is_primary DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_people_account
  ON public.canonical_people(tenant_id, account_id, lower(full_name));
CREATE INDEX IF NOT EXISTS idx_canonical_methods_person
  ON public.canonical_contact_methods(tenant_id, person_id, method_type);
CREATE INDEX IF NOT EXISTS idx_canonical_evidence_subject
  ON public.canonical_field_evidence(tenant_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_freshness_expiry
  ON public.canonical_freshness(tenant_id, expires_at);
CREATE INDEX IF NOT EXISTS idx_canonical_consent_active
  ON public.canonical_consents(tenant_id, state, expires_at);
CREATE INDEX IF NOT EXISTS idx_canonical_suppression_active
  ON public.canonical_suppressions(tenant_id, active, channel);

ALTER TABLE public.canonical_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_people ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_contact_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_titles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_buying_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_buying_group_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_field_evidence ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_freshness ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_consents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_suppressions ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.canonical_accounts, public.canonical_locations,
  public.canonical_people, public.canonical_contact_methods, public.canonical_titles,
  public.canonical_buying_groups, public.canonical_buying_group_roles,
  public.canonical_field_evidence, public.canonical_freshness,
  public.canonical_consents, public.canonical_suppressions
  FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.canonical_accounts,
  public.canonical_locations, public.canonical_people, public.canonical_contact_methods,
  public.canonical_titles, public.canonical_buying_groups,
  public.canonical_buying_group_roles, public.canonical_field_evidence,
  public.canonical_freshness, public.canonical_consents, public.canonical_suppressions
  TO service_role;

COMMENT ON TABLE public.canonical_people IS
  'Additive person projection; lead_contacts remains the scraped legacy projection.';
COMMENT ON TABLE public.canonical_field_evidence IS
  'Immutable-source-compatible evidence projection with field confidence and provenance.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 29: 20261001001150_leadx_task4_approval_scheduling.sql
-- ============================================================================

-- LeadX Task 4: approval CAS, durable automation executions, and sequence transitions.
-- Additive and safe for existing installs; all provider work remains behind jobs.

ALTER TABLE IF EXISTS public.discovery_requests
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS decision_actor text,
  ADD COLUMN IF NOT EXISTS decision_at timestamptz,
  ADD COLUMN IF NOT EXISTS transition_error text,
  ADD COLUMN IF NOT EXISTS approved_by text,
  ADD COLUMN IF NOT EXISTS approved_at timestamptz,
  ADD COLUMN IF NOT EXISTS approved_leads integer;

-- Existing deployments used several constraint names. Replace only the status
-- check so expiry is a first-class terminal, non-executable state.
DO $$
DECLARE c record;
BEGIN
  FOR c IN
    SELECT conname FROM pg_constraint
    WHERE conrelid = 'public.discovery_requests'::regclass
      AND contype = 'c' AND pg_get_constraintdef(oid) ILIKE '%status%'
  LOOP
    EXECUTE format('ALTER TABLE public.discovery_requests DROP CONSTRAINT IF EXISTS %I', c.conname);
  END LOOP;
EXCEPTION WHEN undefined_table THEN NULL;
END $$;
DO $$ BEGIN
  ALTER TABLE public.discovery_requests ADD CONSTRAINT discovery_requests_status_check
    CHECK (status IN ('pending_approval','approved','queued','running','completed','partially_completed','rejected','expired','cancelled','failed'));
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
CREATE INDEX IF NOT EXISTS idx_discovery_requests_expiry
  ON public.discovery_requests(status, expires_at) WHERE status = 'pending_approval';

-- One transaction owns the request CAS and, for terminal decisions, the
-- reservation settlement. Application fallbacks retain the same status CAS for
-- older schemas, but production installs should use this function.
CREATE OR REPLACE FUNCTION public.leadx_transition_discovery_request(
  p_request_id uuid, p_decision text, p_actor text, p_reason text DEFAULT '',
  p_approved_leads integer DEFAULT NULL, p_now timestamptz DEFAULT now()
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.discovery_requests%rowtype; v_status text; v_release integer := 0; v_settlement_key text;
BEGIN
  SELECT * INTO r FROM public.discovery_requests WHERE id=p_request_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','not_found'); END IF;
  IF r.status <> 'pending_approval' THEN
    RETURN jsonb_build_object('ok',false,'reason','already_decided','status',r.status,'request',row_to_json(r));
  END IF;
  IF p_decision NOT IN ('approve','reject','expire') THEN
    RETURN jsonb_build_object('ok',false,'reason','invalid_decision');
  END IF;
  IF p_decision='approve' THEN
    IF coalesce(p_approved_leads,0) < 1 OR p_approved_leads > coalesce(r.requested_leads,p_approved_leads) THEN
      RETURN jsonb_build_object('ok',false,'reason','invalid_approved_leads');
    END IF;
    v_status := 'approved';
  ELSIF p_decision='reject' THEN v_status := 'rejected';
  ELSE v_status := 'expired';
  END IF;
  UPDATE public.discovery_requests SET
    status=v_status, approved_leads=CASE WHEN p_decision='approve' THEN p_approved_leads ELSE approved_leads END,
    admin_reason=CASE WHEN p_decision='approve' THEN p_reason ELSE admin_reason END,
    rejection_reason=CASE WHEN p_decision<>'approve' THEN p_reason ELSE rejection_reason END,
    approved_by=CASE WHEN p_decision='approve' THEN nullif(btrim(p_actor),'') ELSE approved_by END,
    approved_at=CASE WHEN p_decision='approve' THEN p_now ELSE approved_at END,
    decision_actor=nullif(btrim(p_actor),''), decision_at=p_now, updated_at=p_now,
    transition_error=NULL
  WHERE id=p_request_id AND status='pending_approval';
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','already_decided'); END IF;
  IF p_decision <> 'approve' AND r.reservation_id IS NOT NULL THEN
    v_release := greatest(coalesce(r.requested_leads,0),0);
    v_settlement_key := coalesce(r.settlement_key, 'discovery:'||r.id::text||':'||v_status);
    INSERT INTO public.quota_settlements(reservation_id,tenant_id,settlement_key,outcome,quantity,released_quantity)
      VALUES(r.reservation_id,r.tenant_id,v_settlement_key,'released',v_release, v_release)
      ON CONFLICT(reservation_id,settlement_key) DO NOTHING;
    UPDATE public.quota_reservations SET status='released', released_quantity=v_release, updated_at=p_now
      WHERE id=r.reservation_id AND tenant_id=r.tenant_id AND status='reserved';
  END IF;
  SELECT * INTO r FROM public.discovery_requests WHERE id=p_request_id;
  RETURN jsonb_build_object('ok',true,'status',v_status,'released',v_release,'request',row_to_json(r));
END $$;
REVOKE ALL ON FUNCTION public.leadx_transition_discovery_request(uuid,text,text,text,integer,timestamptz) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_transition_discovery_request(uuid,text,text,text,integer,timestamptz) TO service_role;

CREATE TABLE IF NOT EXISTS public.automation_executions (
  execution_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  source_event_id uuid NOT NULL REFERENCES public.automation_events(id) ON DELETE CASCADE,
  workflow_id uuid REFERENCES public.workflow_definitions(id) ON DELETE CASCADE,
  due_at timestamptz NOT NULL DEFAULT now(),
  rule_version integer NOT NULL DEFAULT 1,
  action_version integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','processing','completed','retryable','failed','cancelled')),
  attempts integer NOT NULL DEFAULT 0,
  retry_at timestamptz,
  terminal_reason text,
  job_id uuid REFERENCES public.jobs(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(tenant_id,source_event_id,workflow_id)
);
CREATE INDEX IF NOT EXISTS idx_automation_executions_due ON public.automation_executions(status,due_at,retry_at);
CREATE INDEX IF NOT EXISTS idx_automation_executions_tenant ON public.automation_executions(tenant_id,created_at DESC);
ALTER TABLE public.automation_executions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.automation_executions FROM PUBLIC,anon,authenticated;
GRANT ALL ON TABLE public.automation_executions TO service_role;

ALTER TABLE IF EXISTS public.email_sequences
  ADD COLUMN IF NOT EXISTS last_transition_error text,
  ADD COLUMN IF NOT EXISTS transitioned_at timestamptz;
ALTER TABLE IF EXISTS public.email_sequence_enrollments
  ADD COLUMN IF NOT EXISTS paused_at timestamptz;
CREATE INDEX IF NOT EXISTS idx_email_sequence_enrollments_paused ON public.email_sequence_enrollments(sequence_id,status,next_send_at);

NOTIFY pgrst, 'reload schema';

ALTER TABLE IF EXISTS public.automation_events
  ADD COLUMN IF NOT EXISTS due_at timestamptz,
  ADD COLUMN IF NOT EXISTS rule_version integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS action_version integer NOT NULL DEFAULT 1;
CREATE INDEX IF NOT EXISTS idx_automation_events_tenant_source
  ON public.automation_events(tenant_id,id,available_at);

-- ============================================================================
-- CANONICAL MIGRATION 30: 20261001001200_leadx_16_verification_quality.sql
-- ============================================================================

-- LeadX 16.0: additive verification, quality, bounce, and replacement economics.
-- Existing lead/assignment/contact statuses and lead_quality_credits rows remain
-- readable. The canonical vocabulary is enforced only in these projections.

CREATE TABLE IF NOT EXISTS public.canonical_contact_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  person_id uuid REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  contact_method_id uuid REFERENCES public.canonical_contact_methods(id) ON DELETE CASCADE,
  state text NOT NULL CHECK (state IN ('unknown','probable','verified','risky','catch-all','invalid','unreachable','suppressed','expired')),
  state_reason text,
  verification_id uuid,
  verified_at timestamptz,
  freshness_expires_at timestamptz,
  replacement_eligible boolean NOT NULL DEFAULT false,
  credit_reason text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (num_nonnulls(person_id, contact_method_id) = 1),
  UNIQUE (tenant_id, person_id),
  UNIQUE (tenant_id, contact_method_id)
);

CREATE TABLE IF NOT EXISTS public.canonical_verification_observations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  person_id uuid REFERENCES public.canonical_people(id) ON DELETE CASCADE,
  contact_method_id uuid REFERENCES public.canonical_contact_methods(id) ON DELETE CASCADE,
  state text NOT NULL CHECK (state IN ('unknown','probable','verified','risky','catch-all','invalid','unreachable','suppressed','expired')),
  provider text NOT NULL,
  provider_operation_id text,
  confidence numeric(5,4) CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
  evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
  verified_at timestamptz NOT NULL DEFAULT now(),
  freshness_expires_at timestamptz,
  bounce_code text,
  bounce_feedback text,
  replacement_eligible boolean NOT NULL DEFAULT false,
  credit_reason text,
  observation_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (num_nonnulls(person_id, contact_method_id) = 1),
  UNIQUE (tenant_id, observation_key)
);

CREATE TABLE IF NOT EXISTS public.canonical_bounce_feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  contact_method_id uuid REFERENCES public.canonical_contact_methods(id) ON DELETE SET NULL,
  provider text NOT NULL,
  provider_event_id text,
  bounce_class text NOT NULL CHECK (bounce_class IN ('hard','soft','blocked','unknown')),
  code text,
  safe_message text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  feedback_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, feedback_key)
);

CREATE TABLE IF NOT EXISTS public.canonical_quality_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  lead_id uuid REFERENCES public.leads_global(id) ON DELETE SET NULL,
  assignment_id uuid REFERENCES public.lead_assignments(id) ON DELETE SET NULL,
  decision text NOT NULL CHECK (decision IN ('accepted','rejected','degraded')),
  quality_score numeric(8,4) CHECK (quality_score IS NULL OR quality_score BETWEEN 0 AND 100),
  reasons jsonb NOT NULL DEFAULT '[]'::jsonb,
  required_states jsonb NOT NULL DEFAULT '{}'::jsonb,
  guarantee_version text NOT NULL,
  decided_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, assignment_id, guarantee_version)
);

CREATE TABLE IF NOT EXISTS public.canonical_replacement_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  idempotency_key text NOT NULL,
  original_assignment_id uuid REFERENCES public.lead_assignments(id) ON DELETE SET NULL,
  original_lead_id uuid REFERENCES public.leads_global(id) ON DELETE SET NULL,
  reason text NOT NULL,
  credit_reason text NOT NULL,
  status text NOT NULL DEFAULT 'requested'
    CHECK (status IN ('requested','credited','fulfilled','rejected','cancelled')),
  credit_amount integer NOT NULL DEFAULT 1 CHECK (credit_amount >= 0),
  credit_result jsonb NOT NULL DEFAULT '{}'::jsonb,
  replacement_assignment_id uuid REFERENCES public.lead_assignments(id) ON DELETE SET NULL,
  requested_at timestamptz NOT NULL DEFAULT now(),
  credited_at timestamptz,
  fulfilled_at timestamptz,
  UNIQUE (tenant_id, idempotency_key)
);

CREATE INDEX IF NOT EXISTS idx_canonical_states_tenant_state
  ON public.canonical_contact_states(tenant_id, state, replacement_eligible);
CREATE INDEX IF NOT EXISTS idx_canonical_verification_subject
  ON public.canonical_verification_observations(tenant_id, contact_method_id, verified_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_verification_expiry
  ON public.canonical_verification_observations(tenant_id, freshness_expires_at);
CREATE INDEX IF NOT EXISTS idx_canonical_bounce_method
  ON public.canonical_bounce_feedback(tenant_id, contact_method_id, observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_quality_assignment
  ON public.canonical_quality_decisions(tenant_id, assignment_id, decided_at DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_replacement_status
  ON public.canonical_replacement_requests(tenant_id, status, requested_at DESC);

ALTER TABLE public.canonical_contact_states ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_verification_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_bounce_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_quality_decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.canonical_replacement_requests ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON TABLE public.canonical_contact_states,
  public.canonical_verification_observations, public.canonical_bounce_feedback,
  public.canonical_quality_decisions, public.canonical_replacement_requests
  FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.canonical_contact_states,
  public.canonical_verification_observations, public.canonical_bounce_feedback,
  public.canonical_quality_decisions, public.canonical_replacement_requests
  TO service_role;

COMMENT ON TABLE public.canonical_contact_states IS
  'Task-7 canonical state projection; legacy free-text statuses are not rewritten.';
COMMENT ON TABLE public.canonical_replacement_requests IS
  'Idempotent quality-credit request boundary; credit_result records the exact outcome.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 31: 20261001001300_leadx_16_delivery_outbox.sql
-- ============================================================================

-- LeadX 16.0: additive durable delivery and CRM outbox state.
-- Existing delivery_outbox.status values (pending/processing/delivered/failed)
-- remain unchanged. outbox_state is the canonical Task-8 vocabulary.

ALTER TABLE IF EXISTS public.delivery_outbox
  ADD COLUMN IF NOT EXISTS stable_event_id text,
  ADD COLUMN IF NOT EXISTS destination text NOT NULL DEFAULT 'portal',
  ADD COLUMN IF NOT EXISTS provider text,
  ADD COLUMN IF NOT EXISTS payload_hash text,
  ADD COLUMN IF NOT EXISTS outbox_state text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS next_attempt_at timestamptz,
  ADD COLUMN IF NOT EXISTS safe_error_code text,
  ADD COLUMN IF NOT EXISTS safe_error_detail text,
  ADD COLUMN IF NOT EXISTS replay_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS replay_of_id uuid,
  ADD COLUMN IF NOT EXISTS reconciled_at timestamptz,
  ADD COLUMN IF NOT EXISTS reconciliation_key text;

DO $$
BEGIN
  ALTER TABLE public.delivery_outbox
    ADD CONSTRAINT delivery_outbox_outbox_state_check
    CHECK (outbox_state IN ('pending','processing','delivered','retryable','dead-letter','cancelled'))
    NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END;
$$;

DO $$
BEGIN
  ALTER TABLE public.delivery_outbox
    ADD CONSTRAINT delivery_outbox_destination_check
    CHECK (destination IN ('email','webhook','salesforce','hubspot','pipedrive','close','gohighlevel','export','portal'))
    NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END;
$$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_delivery_outbox_stable_destination
  ON public.delivery_outbox(tenant_id, stable_event_id, destination)
  WHERE stable_event_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_delivery_outbox_canonical_ready
  ON public.delivery_outbox(outbox_state, next_attempt_at, created_at)
  WHERE outbox_state IN ('pending','retryable');
CREATE INDEX IF NOT EXISTS idx_delivery_outbox_reconcile
  ON public.delivery_outbox(tenant_id, reconciliation_key)
  WHERE reconciliation_key IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.delivery_outbox_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  outbox_id uuid NOT NULL REFERENCES public.delivery_outbox(id) ON DELETE CASCADE,
  attempt_number integer NOT NULL CHECK (attempt_number > 0),
  state text NOT NULL CHECK (state IN ('processing','delivered','retryable','dead-letter','cancelled')),
  provider_operation_id text,
  http_status integer,
  safe_error_code text,
  safe_error_detail text,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  UNIQUE (outbox_id, attempt_number)
);

CREATE TABLE IF NOT EXISTS public.delivery_reconciliations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  outbox_id uuid NOT NULL REFERENCES public.delivery_outbox(id) ON DELETE CASCADE,
  stable_event_id text NOT NULL,
  destination text NOT NULL,
  external_id text,
  state text NOT NULL CHECK (state IN ('unconfirmed','matched','mismatched','not-found')),
  safe_detail text,
  observed_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  UNIQUE (tenant_id, stable_event_id, destination)
);

CREATE INDEX IF NOT EXISTS idx_delivery_attempts_outbox
  ON public.delivery_outbox_attempts(tenant_id, outbox_id, attempt_number DESC);
CREATE INDEX IF NOT EXISTS idx_delivery_reconciliations_state
  ON public.delivery_reconciliations(tenant_id, state, observed_at DESC);

ALTER TABLE public.delivery_outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_outbox_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_reconciliations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.delivery_outbox, public.delivery_outbox_attempts,
  public.delivery_reconciliations FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.delivery_outbox TO service_role;
GRANT SELECT, INSERT ON TABLE public.delivery_outbox_attempts,
  public.delivery_reconciliations TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_replay_delivery_outbox(
  p_outbox_id uuid,
  p_reason text
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_row public.delivery_outbox%ROWTYPE;
BEGIN
  IF p_outbox_id IS NULL OR nullif(btrim(coalesce(p_reason, '')), '') IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'replay_reason_required');
  END IF;
  SELECT * INTO v_row FROM public.delivery_outbox WHERE id = p_outbox_id FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'outbox_not_found');
  END IF;
  IF v_row.outbox_state = 'delivered' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_delivered', 'outbox_id', p_outbox_id);
  END IF;
  IF v_row.outbox_state = 'cancelled' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'outbox_cancelled', 'outbox_id', p_outbox_id);
  END IF;
  UPDATE public.delivery_outbox
  SET outbox_state = 'pending',
      next_attempt_at = now(),
      replay_count = coalesce(replay_count, 0) + 1,
      safe_error_code = NULL,
      safe_error_detail = left(btrim(p_reason), 500)
  WHERE id = p_outbox_id;
  RETURN jsonb_build_object('ok', true, 'outcome', 'replayed', 'outbox_id', p_outbox_id,
    'stable_event_id', v_row.stable_event_id, 'destination', v_row.destination);
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_replay_delivery_outbox(uuid,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_replay_delivery_outbox(uuid,text) TO service_role;
COMMENT ON FUNCTION public.leadx_replay_delivery_outbox(uuid,text) IS
  'Requeues one durable event in place; it never creates a second assignment or email event.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 32: 20261001001400_leadx_16_economic_ledger.sql
-- ============================================================================

-- LeadX 16.0: immutable provider, usage, delivery, refund, replacement,
-- reservation, and Stripe-reporting ledger support.
-- Existing jobs, usage_log, lead_credits, provider tables, and billing functions
-- remain authoritative for compatibility; this is an append-only reconciliation
-- bridge with exact-once event keys.

CREATE TABLE IF NOT EXISTS public.economic_ledger_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  event_key text NOT NULL,
  event_type text NOT NULL CHECK (event_type IN (
    'requested','reserved','reservation_released','consumed','provider_usage',
    'delivery_outcome','refund','replacement_credit','stripe_report'
  )),
  direction text NOT NULL CHECK (direction IN ('debit','credit','informational')),
  quantity numeric(20,6) NOT NULL CHECK (quantity >= 0),
  unit text NOT NULL CHECK (unit IN ('lead','credit','provider_call','usd_cents','event')),
  source_type text NOT NULL,
  source_id text,
  job_operation_id uuid,
  provider text,
  period date,
  assignment_id uuid,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, event_key)
);

CREATE INDEX IF NOT EXISTS idx_economic_ledger_tenant_period
  ON public.economic_ledger_events(tenant_id, period, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_economic_ledger_source
  ON public.economic_ledger_events(tenant_id, source_type, source_id);
CREATE INDEX IF NOT EXISTS idx_economic_ledger_job
  ON public.economic_ledger_events(tenant_id, job_operation_id)
  WHERE job_operation_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_economic_ledger_event_type
  ON public.economic_ledger_events(tenant_id, event_type, occurred_at DESC);

CREATE OR REPLACE FUNCTION public.leadx_reject_economic_ledger_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'economic ledger events are immutable';
END;
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgrelid = 'public.economic_ledger_events'::regclass
      AND tgname = 'trg_economic_ledger_immutable'
      AND NOT tgisinternal
  ) THEN
    CREATE TRIGGER trg_economic_ledger_immutable
      BEFORE UPDATE OR DELETE ON public.economic_ledger_events
      FOR EACH ROW EXECUTE FUNCTION public.leadx_reject_economic_ledger_mutation();
  END IF;
END;
$$;

ALTER TABLE public.economic_ledger_events ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.economic_ledger_events FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT ON TABLE public.economic_ledger_events TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_append_economic_ledger_event(
  p_tenant_id uuid,
  p_event_key text,
  p_event_type text,
  p_direction text,
  p_quantity numeric,
  p_unit text,
  p_source_type text,
  p_source_id text DEFAULT NULL,
  p_job_operation_id uuid DEFAULT NULL,
  p_provider text DEFAULT NULL,
  p_period date DEFAULT NULL,
  p_assignment_id uuid DEFAULT NULL,
  p_metadata jsonb DEFAULT '{}'::jsonb,
  p_occurred_at timestamptz DEFAULT now()
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_id uuid;
  v_existing public.economic_ledger_events%ROWTYPE;
BEGIN
  IF p_tenant_id IS NULL OR nullif(btrim(coalesce(p_event_key, '')), '') IS NULL
     OR p_quantity IS NULL OR p_quantity < 0 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'ledger_event_invalid');
  END IF;
  INSERT INTO public.economic_ledger_events(
    tenant_id, event_key, event_type, direction, quantity, unit, source_type,
    source_id, job_operation_id, provider, period, assignment_id, metadata, occurred_at
  ) VALUES (
    p_tenant_id, btrim(p_event_key), p_event_type, p_direction, p_quantity, p_unit,
    btrim(p_source_type), p_source_id, p_job_operation_id, p_provider, p_period,
    p_assignment_id, coalesce(p_metadata, '{}'::jsonb), coalesce(p_occurred_at, now())
  )
  ON CONFLICT (tenant_id, event_key) DO NOTHING
  RETURNING id INTO v_id;
  IF v_id IS NULL THEN
    SELECT * INTO v_existing FROM public.economic_ledger_events
    WHERE tenant_id = p_tenant_id AND event_key = btrim(p_event_key);
    RETURN jsonb_build_object('ok', true, 'outcome', 'replay', 'replayed', true,
      'event_id', v_existing.id, 'event_key', v_existing.event_key,
      'event_type', v_existing.event_type, 'quantity', v_existing.quantity);
  END IF;
  RETURN jsonb_build_object('ok', true, 'outcome', 'accepted', 'replayed', false,
    'event_id', v_id, 'event_key', btrim(p_event_key));
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_reject_economic_ledger_mutation() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.leadx_append_economic_ledger_event(uuid,text,text,text,numeric,text,text,text,uuid,text,date,uuid,jsonb,timestamptz)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_append_economic_ledger_event(uuid,text,text,text,numeric,text,text,text,uuid,text,date,uuid,jsonb,timestamptz)
  TO service_role;

CREATE OR REPLACE VIEW public.economic_ledger_balances AS
SELECT tenant_id, period, unit,
  sum(CASE WHEN direction = 'debit' THEN quantity ELSE 0 END) AS debited,
  sum(CASE WHEN direction = 'credit' THEN quantity ELSE 0 END) AS credited,
  sum(CASE WHEN direction = 'debit' THEN quantity WHEN direction = 'credit' THEN -quantity ELSE 0 END) AS net,
  count(*) AS event_count
FROM public.economic_ledger_events
GROUP BY tenant_id, period, unit;

CREATE OR REPLACE VIEW public.economic_ledger_reconciliation AS
SELECT tenant_id, period,
  sum(quantity) FILTER (WHERE event_type = 'requested') AS requested_quantity,
  sum(quantity) FILTER (WHERE event_type = 'reserved') AS reserved_quantity,
  sum(quantity) FILTER (WHERE event_type = 'consumed') AS consumed_quantity,
  sum(quantity) FILTER (WHERE event_type IN ('refund','replacement_credit')) AS refunded_quantity,
  sum(quantity) FILTER (WHERE event_type = 'provider_usage') AS provider_quantity,
  sum(quantity) FILTER (WHERE event_type = 'stripe_report') AS stripe_quantity,
  count(*) AS ledger_event_count
FROM public.economic_ledger_events
GROUP BY tenant_id, period;

REVOKE ALL ON public.economic_ledger_balances, public.economic_ledger_reconciliation FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.economic_ledger_balances, public.economic_ledger_reconciliation TO service_role;

COMMENT ON TABLE public.economic_ledger_events IS
  'Append-only exact-once economic event bridge; existing usage/credit tables remain compatible sources.';
COMMENT ON VIEW public.economic_ledger_reconciliation IS
  'Admin reconciliation projection for requested, reserved, consumed, refunded, provider, and Stripe quantities.';

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 33: 20261020001500_leadx_exclusivity_learning_quota.sql
-- ============================================================================

-- LeadX exclusivity, quota truth, and approval-gated learning correction.
-- Safe to run after the existing 16.x migrations.

ALTER TABLE public.icp_profiles
  ALTER COLUMN exclusivity SET DEFAULT 'shared';
UPDATE public.icp_profiles SET exclusivity = 'shared'
WHERE exclusivity IS NULL OR lower(trim(exclusivity)) NOT IN ('exclusive', 'shared');
UPDATE public.icp_profiles
SET offer_category = NULL, exclusivity = 'shared'
WHERE NULLIF(trim(offer_category), '') IS NOT NULL
  AND lower(regexp_replace(trim(offer_category), '\s+', '_', 'g')) = lower(regexp_replace(trim(vertical), '\s+', '_', 'g'))
  AND NULLIF(trim(COALESCE(offer_label, '')), '') IS NULL;
UPDATE public.lead_assignments la
SET offer_category = NULL
FROM public.icp_profiles icp
WHERE la.icp_id = icp.id
  AND icp.offer_category IS NULL
  AND (la.offer_category IS NULL OR lower(regexp_replace(trim(la.offer_category), '\s+', '_', 'g')) = lower(regexp_replace(trim(icp.vertical), '\s+', '_', 'g')));

CREATE OR REPLACE FUNCTION public.check_exclusivity(
  p_lead_id uuid,
  p_tenant_id uuid,
  p_vertical text,
  p_geo text[],
  p_offer_category text DEFAULT NULL
) RETURNS boolean
LANGUAGE plpgsql STABLE AS $$
DECLARE conflict_exists boolean; v_offer text;
BEGIN
  v_offer := lower(regexp_replace(trim(COALESCE(p_offer_category, '')), '\s+', '_', 'g'));
  IF v_offer IS NULL OR v_offer = '' OR v_offer IN ('default','general','generic','unknown','any','all','shared','lead_gen_service','lead_generation','service') THEN
    RETURN false;
  END IF;
  SELECT EXISTS (
    SELECT 1
    FROM public.lead_assignments la
    LEFT JOIN public.icp_profiles icp ON icp.id = la.icp_id
    WHERE la.lead_id = p_lead_id
      AND la.tenant_id <> p_tenant_id
      AND la.status NOT IN ('rejected','expired')
      AND COALESCE(lower(trim(icp.exclusivity)), 'shared') = 'exclusive'
      AND lower(regexp_replace(trim(COALESCE(NULLIF(la.offer_category, ''), NULLIF(icp.offer_category, ''))), '\s+', '_', 'g')) = v_offer
      AND (
        icp.geo IS NULL OR icp.geo = '[]'::jsonb OR p_geo IS NULL OR cardinality(p_geo) = 0
        OR EXISTS (
          SELECT 1 FROM jsonb_array_elements_text(icp.geo) g
          WHERE lower(trim(g)) = ANY (SELECT lower(trim(x)) FROM unnest(p_geo) x)
        )
      )
  ) INTO conflict_exists;
  RETURN conflict_exists;
END;
$$;

CREATE OR REPLACE FUNCTION public.tenant_quota_remaining(p_tenant_id uuid)
RETURNS int LANGUAGE plpgsql STABLE AS $$
DECLARE lim int; used int; reserved int; rollover int; p date := date_trunc('month', now())::date;
BEGIN
  SELECT COALESCE(leads_per_month_limit, 0) INTO lim FROM public.tenants WHERE id = p_tenant_id;
  SELECT COALESCE(leads_delivered, 0), COALESCE(quota_reserved, 0), COALESCE(rollover_credits, 0)
    INTO used, reserved, rollover
  FROM public.usage_log WHERE tenant_id = p_tenant_id AND period = p;
  RETURN GREATEST(lim + rollover - used - reserved, 0);
END;
$$;

CREATE TABLE IF NOT EXISTS public.tenant_icp_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  icp_id uuid REFERENCES public.icp_profiles(id) ON DELETE SET NULL,
  recommendation_key text NOT NULL,
  recommendation_type text NOT NULL DEFAULT 'query_expansion',
  status text NOT NULL DEFAULT 'proposed' CHECK (status IN ('proposed','approved','rejected','applied')),
  recommendation jsonb NOT NULL DEFAULT '{}'::jsonb,
  rationale text,
  sample_size integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz,
  reviewed_by uuid,
  UNIQUE (tenant_id, recommendation_key)
);
ALTER TABLE IF EXISTS public.tenant_icp_recommendations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_icp_recommendations_select ON public.tenant_icp_recommendations;
CREATE POLICY tenant_icp_recommendations_select ON public.tenant_icp_recommendations FOR SELECT USING (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS tenant_icp_recommendations_insert ON public.tenant_icp_recommendations;
CREATE POLICY tenant_icp_recommendations_insert ON public.tenant_icp_recommendations FOR INSERT WITH CHECK (public.is_tenant_member(tenant_id));
DROP POLICY IF EXISTS tenant_icp_recommendations_update ON public.tenant_icp_recommendations;
CREATE POLICY tenant_icp_recommendations_update ON public.tenant_icp_recommendations FOR UPDATE USING (public.is_tenant_member(tenant_id)) WITH CHECK (public.is_tenant_member(tenant_id));
CREATE INDEX IF NOT EXISTS idx_tenant_icp_recommendations_status ON public.tenant_icp_recommendations(tenant_id, status, created_at DESC);

-- ============================================================================
-- CANONICAL MIGRATION 34: 20261020001600_leadx_21_realtime_capture.sql
-- ============================================================================

-- LeadX task 21: tenant-safe database change signals.
-- Broadcast is an invalidation hint; APIs remain authoritative. The lists below
-- contain only tables whose changed row has a tenant_id ownership boundary.
-- Rows with nullable tenant_id are intentionally skipped when it is NULL.

CREATE OR REPLACE FUNCTION public.leadx_capture_event() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  row_data jsonb;
  tid uuid;
  rid text;
BEGIN
  -- DELETE must read OLD so the event remains on the deleted row's tenant topic.
  row_data := CASE WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD) ELSE to_jsonb(NEW) END;
  BEGIN
    tid := NULLIF(row_data->>'tenant_id', '')::uuid;
  EXCEPTION WHEN others THEN
    tid := NULL;
  END;

  -- Platform/admin notifications are never emitted on a tenant topic.
  IF TG_TABLE_NAME = 'notifications'
     AND lower(COALESCE(row_data->>'scope', 'tenant')) <> 'tenant' THEN
    tid := NULL;
  END IF;

  rid := COALESCE(row_data->>'id', row_data->>'assignment_id');
  IF tid IS NOT NULL THEN
    INSERT INTO public.leadx_event_log(
      tenant_id, actor_type, action, resource_type, resource_id, summary
    )
    VALUES (
      tid,
      'system',
      lower('db.' || TG_TABLE_NAME || '.' || TG_OP),
      TG_TABLE_NAME,
      rid,
      initcap(replace(lower(TG_TABLE_NAME), '_', ' ')) || ' ' || lower(TG_OP)
    );
  END IF;

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.leadx_broadcast_event() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  BEGIN
    -- Keep Broadcast metadata-only: clients refetch authoritative API data.
    PERFORM realtime.send(
      jsonb_build_object(
        'table', COALESCE(NEW.resource_type, 'workspace'),
        'event', CASE
          WHEN position('.' IN COALESCE(NEW.action, '')) > 0
            THEN split_part(NEW.action, '.', 3)
          ELSE 'LOG'
        END
      ),
      'crm_change',
      'crm:' || NEW.tenant_id::text,
      true
    );
  EXCEPTION WHEN others THEN
    -- Realtime availability must not roll back the durable mutation.
    NULL;
  END;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS leadx_event_broadcast ON public.leadx_event_log;
CREATE TRIGGER leadx_event_broadcast
AFTER INSERT ON public.leadx_event_log
FOR EACH ROW EXECUTE FUNCTION public.leadx_broadcast_event();

-- The event log is append-only and API/service-role only. No browser role can
-- read, write, update, or delete the operational trail directly.
ALTER TABLE IF EXISTS public.leadx_event_log ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.leadx_event_log FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT ON TABLE public.leadx_event_log TO service_role;
REVOKE ALL ON FUNCTION public.leadx_capture_event() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.leadx_broadcast_event() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_capture_event() TO service_role;
GRANT EXECUTE ON FUNCTION public.leadx_broadcast_event() TO service_role;

-- One authoritative table list drives both capture triggers and realtime
-- publication/replica identity. It intentionally excludes global tables,
-- views, and child tables with no safe row-local tenant ownership:
-- leads_global, lead_crm_cards, email_sequence_steps, support_messages,
-- tenant_integrations, deal_activities, and integrations are not durable
-- tenant-owned event sources in this schema. Their portal consumers use the
-- authoritative API with a bounded fallback: visibility-aware polling.
DO $$
DECLARE
  t text;
  supported_tables text[] := ARRAY[
    'pipeline_runs', 'discovery_requests', 'pipeline_stages',
    'lead_assignments', 'lead_state_history', 'lead_score_snapshots',
    'lead_quality_gates', 'lead_routing_decisions', 'lead_delivery_events',
    'lead_verification_observations', 'lead_outcome_events',
    'lead_activities', 'lead_tasks',
    'companies', 'company_locations', 'contacts', 'contact_roles',
    'deals', 'deal_stages', 'activities', 'tasks', 'notes',
    'agent_runs', 'jobs',
    'email_sequences', 'email_sequence_enrollments', 'email_sequence_sends',
    'email_replies',
    'workflow_definitions', 'workflow_runs', 'automation_events',
    'tenant_members', 'tenant_invites', 'notifications', 'audit_log',
    'crm_audit_log',
    'usage_log', 'provider_usage_daily',
    'learning_snapshots', 'tenant_icp_learning', 'tenant_icp_recommendations',
    'support_conversations'
  ];
BEGIN
  FOREACH t IN ARRAY supported_tables LOOP
    IF to_regclass('public.' || t) IS NOT NULL THEN
      EXECUTE format('DROP TRIGGER IF EXISTS leadx_event_capture ON public.%I', t);
      EXECUTE format(
        'CREATE TRIGGER leadx_event_capture AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.leadx_capture_event()',
        t
      );

      BEGIN
        EXECUTE format('ALTER TABLE public.%I REPLICA IDENTITY FULL', t);
        EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
      EXCEPTION
        WHEN duplicate_object THEN NULL;
        WHEN undefined_table THEN NULL;
        WHEN undefined_object THEN NULL;
      END;
    END IF;
  END LOOP;
END
$$;

-- Private tenant Broadcast only. There is deliberately no admin aggregate
-- topic: platform-wide consumers must use bounded, authorized API polling.
DROP POLICY IF EXISTS leadx_workspace_broadcast_read ON realtime.messages;
CREATE POLICY leadx_workspace_broadcast_read
  ON realtime.messages
  FOR SELECT TO authenticated
  USING (
    extension = 'broadcast'
    AND realtime.topic() ~* '^crm:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
    AND public.leadx_is_workspace_member(
      nullif(split_part(realtime.topic(), ':', 2), '')::uuid
    )
  );

COMMENT ON TABLE public.leadx_event_log IS
  'Tenant-scoped append-only metadata events; browser roles have no table privileges.';

-- Task 3: local-first discovery identity, persisted progress, and quota settlement.
-- Additive and safe for existing discovery requests and Task 2 reservations.
ALTER TABLE IF EXISTS public.discovery_requests
  ADD COLUMN IF NOT EXISTS mission_id uuid,
  ADD COLUMN IF NOT EXISTS job_id uuid,
  ADD COLUMN IF NOT EXISTS reservation_id uuid,
  ADD COLUMN IF NOT EXISTS settlement_key text,
  ADD COLUMN IF NOT EXISTS mode text NOT NULL DEFAULT 'production',
  ADD COLUMN IF NOT EXISTS progress_total integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_completed integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_failed integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_skipped integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_remaining integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_qualifying integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_billable integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progress_shortfall integer NOT NULL DEFAULT 0;
CREATE UNIQUE INDEX IF NOT EXISTS uq_discovery_requests_settlement_key
  ON public.discovery_requests(tenant_id, settlement_key) WHERE settlement_key IS NOT NULL;
ALTER TABLE IF EXISTS public.quota_reservations
  ADD COLUMN IF NOT EXISTS request_id uuid;
ALTER TABLE IF EXISTS public.quota_settlements
  ADD COLUMN IF NOT EXISTS committed_quantity integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS released_quantity integer NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.discovery_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES public.discovery_requests(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  task_key text NOT NULL,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','completed','failed','skipped','cancelled')),
  provider text,
  started_at timestamptz,
  finished_at timestamptz,
  error_category text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(request_id, task_key)
);
CREATE INDEX IF NOT EXISTS idx_discovery_tasks_projection ON public.discovery_tasks(request_id, tenant_id, status);

CREATE TABLE IF NOT EXISTS public.discovery_provider_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES public.discovery_requests(id) ON DELETE CASCADE,
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  lead_id uuid,
  task_id uuid REFERENCES public.discovery_tasks(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'persisted' CHECK (status IN ('persisted','completed','qualified','failed','skipped')),
  persisted boolean NOT NULL DEFAULT true,
  qualifying boolean NOT NULL DEFAULT false,
  billable boolean NOT NULL DEFAULT false,
  source text,
  provenance jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(request_id, lead_id)
);
CREATE INDEX IF NOT EXISTS idx_discovery_results_projection ON public.discovery_provider_results(request_id, tenant_id, status);
ALTER TABLE public.discovery_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.discovery_provider_results ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.discovery_tasks, public.discovery_provider_results FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.discovery_tasks, public.discovery_provider_results TO service_role;

CREATE OR REPLACE FUNCTION public.leadx_reserve_discovery_quota(
  p_reservation_id uuid, p_tenant_id uuid, p_request_id uuid,
  p_requested integer, p_settlement_key text
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_period date := date_trunc('month', now())::date;
  v_limit integer; v_used integer; v_reserved integer; v_available integer;
  v_existing public.quota_reservations%ROWTYPE;
BEGIN
  IF p_reservation_id IS NULL OR p_tenant_id IS NULL OR p_request_id IS NULL
     OR p_requested IS NULL OR p_requested <= 0 OR nullif(btrim(coalesce(p_settlement_key,'')),'') IS NULL THEN
    RETURN jsonb_build_object('ok',false,'reason','invalid_reservation');
  END IF;
  SELECT leads_per_month_limit INTO v_limit FROM public.tenants WHERE id=p_tenant_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','tenant_not_found'); END IF;
  SELECT * INTO v_existing FROM public.quota_reservations WHERE tenant_id=p_tenant_id AND settlement_key=p_settlement_key FOR UPDATE;
  IF FOUND THEN RETURN jsonb_build_object('ok',true,'replayed',true,'reservation_id',v_existing.id,'granted',v_existing.reserved_quantity,'status',v_existing.status); END IF;
  INSERT INTO public.usage_log(tenant_id,period,leads_delivered,quota_reserved)
    VALUES(p_tenant_id,v_period,0,0) ON CONFLICT(tenant_id,period) DO NOTHING;
  SELECT coalesce(leads_delivered,0),coalesce(quota_reserved,0) INTO v_used,v_reserved
    FROM public.usage_log WHERE tenant_id=p_tenant_id AND period=v_period FOR UPDATE;
  v_available := greatest(coalesce(v_limit,0) - v_used - v_reserved, 0);
  IF v_available < p_requested THEN
    RETURN jsonb_build_object('ok',false,'reason','quota_exhausted','granted',v_available);
  END IF;
  INSERT INTO public.quota_reservations(id,tenant_id,request_id,requested_quantity,reserved_quantity,settlement_key)
    VALUES(p_reservation_id,p_tenant_id,p_request_id,p_requested,p_requested,p_settlement_key);
  UPDATE public.usage_log SET quota_reserved=quota_reserved+p_requested,updated_at=now()
    WHERE tenant_id=p_tenant_id AND period=v_period;
  RETURN jsonb_build_object('ok',true,'replayed',false,'reservation_id',p_reservation_id,'granted',p_requested);
END $$;

CREATE OR REPLACE FUNCTION public.leadx_settle_discovery_reservation(
  p_reservation_id uuid, p_tenant_id uuid, p_settlement_key text,
  p_committed integer DEFAULT 0, p_released integer DEFAULT 0
) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r public.quota_reservations%ROWTYPE; v_period date := date_trunc('month',now())::date;
BEGIN
  IF p_committed < 0 OR p_released < 0 OR nullif(btrim(coalesce(p_settlement_key,'')),'') IS NULL THEN
    RETURN jsonb_build_object('ok',false,'reason','invalid_settlement');
  END IF;
  SELECT * INTO r FROM public.quota_reservations WHERE id=p_reservation_id AND tenant_id=p_tenant_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','reservation_not_found'); END IF;
  IF r.status <> 'reserved' THEN
    RETURN jsonb_build_object('ok',true,'replayed',true,'status',r.status,'committed',r.committed_quantity,'released',r.released_quantity);
  END IF;
  IF p_committed + p_released > r.reserved_quantity THEN
    RETURN jsonb_build_object('ok',false,'reason','settlement_exceeds_reservation');
  END IF;
  INSERT INTO public.quota_settlements(reservation_id,tenant_id,settlement_key,outcome,quantity,committed_quantity,released_quantity)
    VALUES(r.id,r.tenant_id,p_settlement_key,CASE WHEN p_committed > 0 THEN 'committed' ELSE 'released' END,p_committed,p_committed,p_released)
    ON CONFLICT(reservation_id,settlement_key) DO NOTHING;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',true,'replayed',true,'status',r.status); END IF;
  UPDATE public.quota_reservations SET status=CASE WHEN p_committed > 0 THEN 'committed' ELSE 'released' END,
    committed_quantity=p_committed,released_quantity=p_released,updated_at=now() WHERE id=r.id;
  UPDATE public.usage_log SET quota_reserved=greatest(quota_reserved-p_committed-p_released,0),
    leads_delivered=leads_delivered+p_committed,updated_at=now()
    WHERE tenant_id=p_tenant_id AND period=v_period;
  RETURN jsonb_build_object('ok',true,'replayed',false,'status',CASE WHEN p_committed > 0 THEN 'committed' ELSE 'released' END,
    'committed',p_committed,'released',p_released,'settlement_key',p_settlement_key);
END $$;
REVOKE ALL ON FUNCTION public.leadx_reserve_discovery_quota(uuid,uuid,uuid,integer,text), public.leadx_settle_discovery_reservation(uuid,uuid,text,integer,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_reserve_discovery_quota(uuid,uuid,uuid,integer,text), public.leadx_settle_discovery_reservation(uuid,uuid,text,integer,integer) TO service_role;
NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 35: 20261020001700_leadx_5_tenant_scope_hardening.sql
-- ============================================================================

-- LeadX Task 5: additive tenant scope and security checks.
-- Browser roles remain denied; FastAPI/worker service-role calls must supply
-- verified membership/tenant scope before reaching these backend-only tables.

ALTER TABLE IF EXISTS public.job_operations
  ADD COLUMN IF NOT EXISTS principal_scope text NOT NULL DEFAULT '';

-- Bind every durable operation to the derived principal scope. The existing
-- global operation/key uniqueness is retained for compatibility; this scoped
-- index and lookup path prevent a replay/fallback from crossing tenants.
UPDATE public.job_operations
SET principal_scope = COALESCE(NULLIF(principal_scope, ''), NULLIF(scope_hash, ''), 'legacy')
WHERE principal_scope IS NULL OR principal_scope = '';
CREATE UNIQUE INDEX IF NOT EXISTS uq_job_operations_scoped_identity
  ON public.job_operations(tenant_id, principal_scope, operation_kind, idempotency_key);
CREATE INDEX IF NOT EXISTS idx_job_operations_tenant_principal
  ON public.job_operations(tenant_id, principal_scope, operation_kind, idempotency_key);

CREATE OR REPLACE FUNCTION public.leadx_set_job_operation_scope()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.principal_scope IS NULL OR btrim(NEW.principal_scope) = '' THEN
    NEW.principal_scope := COALESCE(NULLIF(btrim(NEW.scope_hash), ''), 'legacy');
  END IF;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS trg_job_operation_scope ON public.job_operations;
CREATE TRIGGER trg_job_operation_scope
BEFORE INSERT OR UPDATE OF scope_hash, principal_scope ON public.job_operations
FOR EACH ROW EXECUTE FUNCTION public.leadx_set_job_operation_scope();
REVOKE ALL ON FUNCTION public.leadx_set_job_operation_scope() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_set_job_operation_scope() TO service_role;

-- Explicitly keep all protected data-plane tables backend-only and RLS-gated,
-- including newer tables that were added after the original tenant policies.
DO $$
DECLARE table_name text;
BEGIN
  FOREACH table_name IN ARRAY ARRAY[
    'job_operations','jobs','job_attempts','agent_missions','agent_mission_tasks',
    'agent_mission_task_attempts','quota_reservations','quota_settlements',
    'operation_idempotency','audit_log','security_events','tenant_members',
    'companies','contacts','deals','activities','tasks','notes','sequences',
    'automations','automation_executions'
  ] LOOP
    IF to_regclass('public.' || table_name) IS NOT NULL THEN
      EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', table_name);
      EXECUTE format('REVOKE ALL ON public.%I FROM anon, authenticated', table_name);
    END IF;
  END LOOP;
END $$;

-- Reassert semantic policies for direct PostgREST deployments. FastAPI uses
-- service_role and performs the same checks in require_tenant/require_admin;
-- these policies are additive defense-in-depth for authenticated database use.
DO $$
BEGIN
  IF to_regclass('public.audit_log') IS NOT NULL THEN
    DROP POLICY IF EXISTS audit_log_tenant_select_task5 ON public.audit_log;
    CREATE POLICY audit_log_tenant_select_task5 ON public.audit_log FOR SELECT
      USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id));
  END IF;
  IF to_regclass('public.security_events') IS NOT NULL THEN
    DROP POLICY IF EXISTS security_events_tenant_select_task5 ON public.security_events;
    CREATE POLICY security_events_tenant_select_task5 ON public.security_events FOR SELECT
      USING (tenant_id IS NULL OR public.is_tenant_member(tenant_id));
  END IF;
END $$;

-- A service-role-only, non-disclosing preflight proves the expected security
-- boundary without returning rows, tenant names, membership, or credentials.
CREATE OR REPLACE FUNCTION public.leadx_verify_tenant_security()
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  table_name text;
  missing_rls text[] := ARRAY[]::text[];
BEGIN
  FOREACH table_name IN ARRAY ARRAY[
    'tenants','tenant_members','jobs','job_operations','operation_idempotency',
    'agent_missions','agent_mission_tasks','quota_reservations','audit_log','security_events',
    'companies','contacts','deals','activities','tasks','notes','sequences','automations'
  ] LOOP
    IF to_regclass('public.' || table_name) IS NOT NULL THEN
      IF NOT EXISTS (
        SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'public' AND c.relname = table_name AND c.relrowsecurity
      ) THEN
        missing_rls := missing_rls || ('rls:' || table_name);
      END IF;
    END IF;
  END LOOP;
  RETURN jsonb_build_object(
    'ok', cardinality(missing_rls) = 0,
    'missing', to_jsonb(missing_rls),
    'browser_roles', 'revoked',
    'checked_at', clock_timestamp()
  );
END;
$$;
REVOKE ALL ON FUNCTION public.leadx_verify_tenant_security() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_verify_tenant_security() TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 36: 20261025000100_leadx_scoped_work_transitions.sql
-- ============================================================================

-- LeadX additive scoped-work transition primitive.
-- This function only locks rows selected by one explicit run or tenant scope.
-- It does not delete data, create an operation ledger, or infer a global scope.

CREATE OR REPLACE FUNCTION public.leadx_transition_scoped_work(
  p_scope_kind text,
  p_run_id uuid DEFAULT NULL,
  p_tenant_id uuid DEFAULT NULL,
  p_cutoff timestamptz DEFAULT NULL,
  p_status_allowlist text[] DEFAULT ARRAY['queued','running','retrying']::text[],
  p_apply boolean DEFAULT false
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_scope text := lower(btrim(coalesce(p_scope_kind, '')));
  v_active text[] := ARRAY['queued','running','retrying']::text[];
  v_run_count integer := 0;
  v_job_count integer := 0;
  v_agent_run_count integer := 0;
  v_mission_count integer := 0;
  v_task_count integer := 0;
  v_reservation_count integer := 0;
  v_transitioned integer := 0;
  v_changed integer := 0;
  v_accounting_pending integer := 0;
  v_remaining integer := 0;
  v_remaining_active integer := 0;
  v_remaining_stale integer := 0;
  v_release integer;
  v_run_changed integer := 0;
  v_job_changed integer := 0;
  v_agent_run_changed integer := 0;
  v_task_changed integer := 0;
  v_mission_changed integer := 0;
  v_report_limit integer := 500;
  v_selected_by_status jsonb := '{}'::jsonb;
  v_transitioned_by_table jsonb := '{}'::jsonb;
  v_skipped_by_table jsonb := '{}'::jsonb;
  v_failed_reason_codes jsonb := '[]'::jsonb;
  v_skipped_reason_codes jsonb := '[]'::jsonb;
  v_result jsonb;
  v_job_id uuid;
  v_reservation_id uuid;
BEGIN
  IF v_scope NOT IN ('run','tenant_active','tenant_stale') THEN
    RETURN jsonb_build_object('ok',false,'reason','unsupported_scope');
  END IF;
  IF p_status_allowlist IS NULL OR cardinality(p_status_allowlist) = 0
     OR NOT (p_status_allowlist <@ v_active) THEN
    RETURN jsonb_build_object('ok',false,'reason','invalid_status_allowlist');
  END IF;
  IF v_scope = 'run' THEN
    IF p_run_id IS NULL OR p_tenant_id IS NOT NULL OR p_cutoff IS NOT NULL THEN
      RETURN jsonb_build_object('ok',false,'reason','invalid_run_scope');
    END IF;
  ELSIF p_tenant_id IS NULL OR p_run_id IS NOT NULL THEN
    RETURN jsonb_build_object('ok',false,'reason','invalid_tenant_scope');
  ELSIF v_scope = 'tenant_stale' AND p_cutoff IS NULL THEN
    RETURN jsonb_build_object('ok',false,'reason','cutoff_required');
  ELSIF v_scope = 'tenant_active' AND p_cutoff IS NOT NULL THEN
    RETURN jsonb_build_object('ok',false,'reason','cutoff_not_allowed');
  END IF;

  CREATE TEMP TABLE IF NOT EXISTS _leadx_reset_runs(id uuid PRIMARY KEY) ON COMMIT DROP;
  CREATE TEMP TABLE IF NOT EXISTS _leadx_reset_jobs(id uuid PRIMARY KEY) ON COMMIT DROP;
  CREATE TEMP TABLE IF NOT EXISTS _leadx_reset_agent_runs(id uuid PRIMARY KEY) ON COMMIT DROP;
  CREATE TEMP TABLE IF NOT EXISTS _leadx_reset_missions(id uuid PRIMARY KEY) ON COMMIT DROP;
  CREATE TEMP TABLE IF NOT EXISTS _leadx_reset_tasks(id uuid PRIMARY KEY) ON COMMIT DROP;
  CREATE TEMP TABLE IF NOT EXISTS _leadx_reset_reservations(id uuid PRIMARY KEY) ON COMMIT DROP;
  TRUNCATE _leadx_reset_runs, _leadx_reset_jobs, _leadx_reset_agent_runs,
    _leadx_reset_missions, _leadx_reset_tasks, _leadx_reset_reservations;

  -- Lock parent runs first. The scope predicate is repeated by every child
  -- selection, so a tenant or stale reset cannot widen through a join.
  INSERT INTO _leadx_reset_runs(id)
  SELECT pr.id
  FROM public.pipeline_runs pr
  WHERE pr.status = ANY(p_status_allowlist)
    AND ((v_scope = 'run' AND pr.id = p_run_id)
      OR (v_scope <> 'run' AND pr.tenant_id = p_tenant_id
          AND (v_scope = 'tenant_active'
            OR COALESCE(pr.updated_at, pr.started_at, pr.created_at) <= p_cutoff)))
  ORDER BY pr.id
  FOR UPDATE;
  SELECT count(*) INTO v_run_count FROM _leadx_reset_runs;

  INSERT INTO _leadx_reset_jobs(id)
  SELECT j.id
  FROM public.jobs j
  WHERE j.status = ANY(p_status_allowlist)
    AND ((v_scope = 'run' AND EXISTS (
            SELECT 1 FROM _leadx_reset_runs r
            WHERE j.id = r.id OR j.payload->>'run_id' = r.id::text))
      OR (v_scope <> 'run' AND j.tenant_id = p_tenant_id
          AND (v_scope = 'tenant_active'
            OR COALESCE(j.locked_at, j.created_at) <= p_cutoff)))
  ORDER BY j.id
  FOR UPDATE;
  SELECT count(*) INTO v_job_count FROM _leadx_reset_jobs;

  -- Agent runs are selected by the pipeline linkage carried in input_data or
  -- by a task already selected in this same transaction.
  INSERT INTO _leadx_reset_agent_runs(id)
  SELECT ar.id
  FROM public.agent_runs ar
  WHERE ar.status IN ('queued','running')
    AND ((v_scope = 'run' AND EXISTS (
            SELECT 1 FROM _leadx_reset_runs r
            WHERE ar.input_data->>'run_id' = r.id::text))
      OR (v_scope <> 'run' AND ar.tenant_id = p_tenant_id
          AND (v_scope = 'tenant_active'
            OR COALESCE(ar.updated_at, ar.created_at) <= p_cutoff)))
  ORDER BY ar.id
  FOR UPDATE;

  INSERT INTO _leadx_reset_tasks(id)
  SELECT t.id
  FROM public.agent_mission_tasks t
  WHERE t.tenant_id = CASE WHEN v_scope = 'run' THEN t.tenant_id ELSE p_tenant_id END
    AND (t.status = ANY(p_status_allowlist) OR t.status = 'blocked')
    AND ((v_scope = 'run' AND (
            t.input_data->>'run_id' = p_run_id::text
            OR t.agent_run_id IN (SELECT id FROM _leadx_reset_agent_runs)))
      OR (v_scope <> 'run' AND (
            t.tenant_id = p_tenant_id
            AND (v_scope = 'tenant_active'
              OR COALESCE(t.lease_expires_at, t.updated_at, t.created_at) <= p_cutoff))))
  ORDER BY t.id
  FOR UPDATE;

  INSERT INTO _leadx_reset_missions(id)
  SELECT DISTINCT t.mission_id
  FROM public.agent_mission_tasks t
  WHERE t.id IN (SELECT id FROM _leadx_reset_tasks)
  ON CONFLICT DO NOTHING;
  INSERT INTO _leadx_reset_missions(id)
  SELECT m.id
  FROM public.agent_missions m
  WHERE m.status IN ('queued','running')
    AND ((v_scope = 'run' AND m.input_data->>'run_id' = p_run_id::text)
      OR (v_scope <> 'run' AND m.tenant_id = p_tenant_id
          AND (v_scope = 'tenant_active'
            OR COALESCE(m.updated_at, m.created_at) <= p_cutoff)))
  ON CONFLICT DO NOTHING;

  -- A selected mission owns all of its non-terminal child tasks, including
  -- dependency-blocked children that otherwise could strand the parent.
  INSERT INTO _leadx_reset_tasks(id)
  SELECT t.id
  FROM public.agent_mission_tasks t
  WHERE t.mission_id IN (SELECT id FROM _leadx_reset_missions)
    AND (t.status = ANY(p_status_allowlist) OR t.status = 'blocked')
  ON CONFLICT DO NOTHING;
  SELECT count(*) INTO v_task_count FROM _leadx_reset_tasks;

  INSERT INTO _leadx_reset_agent_runs(id)
  SELECT t.agent_run_id
  FROM public.agent_mission_tasks t
  WHERE t.id IN (SELECT id FROM _leadx_reset_tasks)
    AND t.agent_run_id IS NOT NULL
  ON CONFLICT DO NOTHING;
  SELECT count(*) INTO v_agent_run_count FROM _leadx_reset_agent_runs;

  INSERT INTO _leadx_reset_reservations(id)
  SELECT qr.id
  FROM public.quota_reservations qr
  WHERE qr.status = 'reserved'
    AND (qr.job_id IN (SELECT id FROM _leadx_reset_jobs)
      OR qr.operation_id IN (
        SELECT jo.id FROM public.job_operations jo
        WHERE jo.job_id IN (SELECT id FROM _leadx_reset_jobs)))
  ORDER BY qr.id
  FOR UPDATE;
  SELECT count(*) INTO v_reservation_count FROM _leadx_reset_reservations;
  SELECT count(*) INTO v_mission_count
  FROM public.agent_missions m
  WHERE m.id IN (SELECT id FROM _leadx_reset_missions)
    AND m.status IN ('queued','running');

  -- Keep report detail bounded while retaining compatibility totals above.
  v_selected_by_status := jsonb_build_object(
    'pipeline_runs', COALESCE((SELECT jsonb_object_agg(status, LEAST(row_count, v_report_limit)) FROM (
      SELECT pr.status, count(*)::integer AS row_count FROM public.pipeline_runs pr
      WHERE pr.id IN (SELECT id FROM _leadx_reset_runs) GROUP BY pr.status) s), '{}'::jsonb),
    'jobs', COALESCE((SELECT jsonb_object_agg(status, LEAST(row_count, v_report_limit)) FROM (
      SELECT j.status, count(*)::integer AS row_count FROM public.jobs j
      WHERE j.id IN (SELECT id FROM _leadx_reset_jobs) GROUP BY j.status) s), '{}'::jsonb),
    'agent_runs', COALESCE((SELECT jsonb_object_agg(status, LEAST(row_count, v_report_limit)) FROM (
      SELECT ar.status, count(*)::integer AS row_count FROM public.agent_runs ar
      WHERE ar.id IN (SELECT id FROM _leadx_reset_agent_runs) GROUP BY ar.status) s), '{}'::jsonb),
    'missions', COALESCE((SELECT jsonb_object_agg(status, LEAST(row_count, v_report_limit)) FROM (
      SELECT m.status, count(*)::integer AS row_count FROM public.agent_missions m
      WHERE m.id IN (SELECT id FROM _leadx_reset_missions) GROUP BY m.status) s), '{}'::jsonb),
    'mission_tasks', COALESCE((SELECT jsonb_object_agg(status, LEAST(row_count, v_report_limit)) FROM (
      SELECT t.status, count(*)::integer AS row_count FROM public.agent_mission_tasks t
      WHERE t.id IN (SELECT id FROM _leadx_reset_tasks) GROUP BY t.status) s), '{}'::jsonb),
    'quota_reservations', COALESCE((SELECT jsonb_object_agg(status, LEAST(row_count, v_report_limit)) FROM (
      SELECT qr.status, count(*)::integer AS row_count FROM public.quota_reservations qr
      WHERE qr.id IN (SELECT id FROM _leadx_reset_reservations) GROUP BY qr.status) s), '{}'::jsonb)
  );

  IF NOT p_apply THEN
    v_skipped_by_table := jsonb_build_object(
      'pipeline_runs', LEAST(v_run_count, v_report_limit), 'jobs', LEAST(v_job_count, v_report_limit),
      'agent_runs', LEAST(v_agent_run_count, v_report_limit), 'missions', LEAST(v_mission_count, v_report_limit),
      'mission_tasks', LEAST(v_task_count, v_report_limit), 'quota_reservations', LEAST(v_reservation_count, v_report_limit));
    v_skipped_reason_codes := '["dry_run"]'::jsonb;
    RETURN jsonb_build_object(
      'ok', true, 'applied', false, 'scope_kind', v_scope,
      'selected', jsonb_build_object('pipeline_runs',LEAST(v_run_count,v_report_limit),'jobs',LEAST(v_job_count,v_report_limit),
        'agent_runs',LEAST(v_agent_run_count,v_report_limit),'missions',LEAST(v_mission_count,v_report_limit),
        'mission_tasks',LEAST(v_task_count,v_report_limit),'quota_reservations',LEAST(v_reservation_count,v_report_limit)),
      'counts', jsonb_build_object('selected_by_status', v_selected_by_status,
        'transitioned_by_table', jsonb_build_object('pipeline_runs',0,'jobs',0,'agent_runs',0,'missions',0,'mission_tasks',0,'quota_reservations',0),
        'skipped_by_table', v_skipped_by_table, 'remaining', jsonb_build_object('active',0,'stale',0)),
      'transitioned', 0, 'accounting_pending', 0,
      'pending_reconciliation', jsonb_build_object('status','not_required','count',0,'reason_codes',v_failed_reason_codes),
      'skipped_reason_codes', v_skipped_reason_codes, 'failed_reason_codes', v_failed_reason_codes,
      'remaining_active', 0, 'remaining_stale', 0, 'ready_for_fresh_run', false);
  END IF;

  UPDATE public.pipeline_runs pr
  SET status = 'failed',
      error_message = 'scoped_reset',
      finished_at = now(),
      meta = COALESCE(pr.meta, '{}'::jsonb) || jsonb_build_object(
        'stage','failed', 'message','Stopped by scoped reset',
        'recovery', jsonb_build_object(
          'reason','scoped_reset', 'outcome','cancelled',
          'source_run_id',pr.id::text, 'terminal',true
        )
      )
  WHERE pr.id IN (SELECT id FROM _leadx_reset_runs)
    AND pr.status = ANY(p_status_allowlist);
  GET DIAGNOSTICS v_run_changed = ROW_COUNT;
  v_transitioned := v_run_changed;

  UPDATE public.jobs j
  SET status = 'cancelled', error = 'scoped_reset', error_category = 'scoped_reset',
      dependency_outcome = 'terminal',
      terminal_result = jsonb_build_object(
        'status','cancelled', 'reason','scoped_reset',
        'recovery', jsonb_build_object('source_job_id',j.id::text, 'outcome','cancelled', 'terminal',true)
      ),
      finished_at = now(), locked_by = NULL, locked_at = NULL,
      lease_expires_at = NULL, lease_renewed_at = NULL, retry_after = NULL,
      accounting_reconciliation_status = CASE
        WHEN EXISTS (SELECT 1 FROM public.job_operations jo WHERE jo.job_id = j.id)
        THEN 'pending' ELSE COALESCE(j.accounting_reconciliation_status, 'not_required') END
  WHERE j.id IN (SELECT id FROM _leadx_reset_jobs)
    AND j.status = ANY(p_status_allowlist);
  GET DIAGNOSTICS v_job_changed = ROW_COUNT;
  v_changed := v_job_changed;
  v_transitioned := v_transitioned + v_changed;

  UPDATE public.agent_runs ar
  SET status = 'cancelled', error = 'scoped_reset', finished_at = now(), updated_at = now()
  WHERE ar.id IN (SELECT id FROM _leadx_reset_agent_runs)
    AND ar.status IN ('queued','running');
  GET DIAGNOSTICS v_agent_run_changed = ROW_COUNT;
  v_changed := v_agent_run_changed;
  v_transitioned := v_transitioned + v_changed;

  UPDATE public.agent_mission_tasks t
  SET status = 'cancelled', error = 'scoped_reset', error_category = 'scoped_reset',
      dependency_outcome = 'terminal', terminal_result = jsonb_build_object('status','cancelled','reason','scoped_reset'),
      lease_owner = NULL, lease_expires_at = NULL, lease_renewed_at = NULL,
      run_after = now(), finished_at = now(), updated_at = now()
  WHERE t.id IN (SELECT id FROM _leadx_reset_tasks)
    AND (t.status = ANY(p_status_allowlist) OR t.status = 'blocked');
  GET DIAGNOSTICS v_task_changed = ROW_COUNT;
  v_changed := v_task_changed;
  v_transitioned := v_transitioned + v_changed;

  UPDATE public.agent_missions m
  SET status = 'cancelled', completed_at = now(), updated_at = now(),
      failure_summary = jsonb_build_object('reason','scoped_reset'),
      terminal_result = jsonb_build_object('status','cancelled','reason','scoped_reset')
  WHERE m.id IN (SELECT id FROM _leadx_reset_missions)
    AND m.status IN ('queued','running');
  GET DIAGNOSTICS v_mission_changed = ROW_COUNT;
  v_changed := v_mission_changed;
  v_transitioned := v_transitioned + v_changed;

  -- Finish the current attempt rows without deleting their evidence. The
  -- owner/attempt identity remains available for diagnostics and late CAS
  -- completion cannot match the reset terminal status.
  UPDATE public.job_attempts ja
  SET finished_at = COALESCE(finished_at, now()), outcome = 'cancelled',
      retryable = false, error_category = 'scoped_reset', error = 'scoped_reset'
  WHERE ja.job_id IN (SELECT id FROM _leadx_reset_jobs) AND ja.finished_at IS NULL;
  UPDATE public.agent_mission_task_attempts ta
  SET finished_at = COALESCE(finished_at, now()), outcome = 'cancelled',
      retryable = false, error_category = 'scoped_reset', error = 'scoped_reset'
  WHERE ta.task_id IN (SELECT id FROM _leadx_reset_tasks) AND ta.finished_at IS NULL;

  -- Reuse the established job-operation settlement path. A missing operation
  -- is a legacy row, not an accounting failure; an unavailable dependency is
  -- reported pending rather than claimed as reconciled.
  FOR v_job_id IN SELECT id FROM _leadx_reset_jobs LOOP
    BEGIN
      v_result := public.leadx_finish_job_operation(
        v_job_id, 'cancelled', jsonb_build_object('status','cancelled','reason','scoped_reset'));
      IF (v_result ? 'reason') AND v_result->>'reason' = 'job_operation_not_found' THEN
        UPDATE public.jobs SET accounting_reconciliation_status = 'not_required'
        WHERE id = v_job_id AND status = 'cancelled';
      ELSIF COALESCE(v_result->>'accounting_status','') IN ('released','none')
         OR (v_result ? 'outcome') AND v_result->>'outcome' = 'replay' THEN
        UPDATE public.jobs SET accounting_reconciliation_status = 'reconciled'
        WHERE id = v_job_id AND status = 'cancelled';
      ELSE
        v_accounting_pending := v_accounting_pending + 1;
        IF NOT (v_failed_reason_codes ? 'job_accounting_pending') THEN
          v_failed_reason_codes := v_failed_reason_codes || '["job_accounting_pending"]'::jsonb;
        END IF;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      v_accounting_pending := v_accounting_pending + 1;
      IF NOT (v_failed_reason_codes ? 'accounting_dependency_unavailable') THEN
        v_failed_reason_codes := v_failed_reason_codes || '["accounting_dependency_unavailable"]'::jsonb;
      END IF;
    END;
  END LOOP;

  FOR v_reservation_id IN SELECT id FROM _leadx_reset_reservations LOOP
    BEGIN
      v_result := public.leadx_record_quota_settlement(
        v_reservation_id,
        (SELECT tenant_id FROM public.quota_reservations WHERE id = v_reservation_id),
        'scoped-reset:' || v_reservation_id::text,
        'released',
        (SELECT GREATEST(COALESCE(reserved_quantity,0) - COALESCE(committed_quantity,0),0)
         FROM public.quota_reservations WHERE id = v_reservation_id));
      IF NOT COALESCE((v_result->>'ok')::boolean, false) THEN
        v_accounting_pending := v_accounting_pending + 1;
        IF NOT (v_failed_reason_codes ? 'quota_settlement_pending') THEN
          v_failed_reason_codes := v_failed_reason_codes || '["quota_settlement_pending"]'::jsonb;
        END IF;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      v_accounting_pending := v_accounting_pending + 1;
      IF NOT (v_failed_reason_codes ? 'quota_accounting_unavailable') THEN
        v_failed_reason_codes := v_failed_reason_codes || '["quota_accounting_unavailable"]'::jsonb;
      END IF;
    END;
  END LOOP;

  SELECT count(*) INTO v_remaining_active FROM public.pipeline_runs pr
  WHERE pr.id IN (SELECT id FROM _leadx_reset_runs) AND pr.status = ANY(p_status_allowlist);
  SELECT v_remaining_active + count(*) INTO v_remaining_active FROM public.jobs j
  WHERE j.id IN (SELECT id FROM _leadx_reset_jobs) AND j.status = ANY(p_status_allowlist);
  SELECT v_remaining_active + count(*) INTO v_remaining_active FROM public.agent_runs ar
  WHERE ar.id IN (SELECT id FROM _leadx_reset_agent_runs) AND ar.status IN ('queued','running');
  SELECT v_remaining_active + count(*) INTO v_remaining_active FROM public.agent_mission_tasks t
  WHERE t.id IN (SELECT id FROM _leadx_reset_tasks) AND (t.status = ANY(p_status_allowlist) OR t.status = 'blocked');
  SELECT v_remaining_active + count(*) INTO v_remaining_active FROM public.agent_missions m
  WHERE m.id IN (SELECT id FROM _leadx_reset_missions) AND m.status IN ('queued','running');
  v_remaining := v_remaining_active;
  -- A stale scope has no separate hidden queue: every remaining active row is stale.
  v_remaining_stale := CASE WHEN v_scope = 'tenant_stale' THEN v_remaining_active ELSE 0 END;
  v_transitioned_by_table := jsonb_build_object(
    'pipeline_runs', LEAST(v_run_changed, v_report_limit), 'jobs', LEAST(v_job_changed, v_report_limit),
    'agent_runs', LEAST(v_agent_run_changed, v_report_limit), 'missions', LEAST(v_mission_changed, v_report_limit),
    'mission_tasks', LEAST(v_task_changed, v_report_limit), 'quota_reservations', 0);
  v_skipped_by_table := jsonb_build_object(
    'pipeline_runs', LEAST(GREATEST(v_run_count - v_run_changed, 0), v_report_limit),
    'jobs', LEAST(GREATEST(v_job_count - v_job_changed, 0), v_report_limit),
    'agent_runs', LEAST(GREATEST(v_agent_run_count - v_agent_run_changed, 0), v_report_limit),
    'missions', LEAST(GREATEST(v_mission_count - v_mission_changed, 0), v_report_limit),
    'mission_tasks', LEAST(GREATEST(v_task_count - v_task_changed, 0), v_report_limit),
    'quota_reservations', 0);
  IF v_skipped_by_table <> '{"pipeline_runs": 0, "jobs": 0, "agent_runs": 0, "missions": 0, "mission_tasks": 0, "quota_reservations": 0}'::jsonb
     AND NOT (v_skipped_reason_codes ? 'status_changed_before_transition') THEN
    v_skipped_reason_codes := v_skipped_reason_codes || '["status_changed_before_transition"]'::jsonb;
  END IF;

  RETURN jsonb_build_object(
    'ok', v_accounting_pending = 0, 'applied', true, 'scope_kind', v_scope,
    'selected', jsonb_build_object('pipeline_runs',LEAST(v_run_count,v_report_limit),'jobs',LEAST(v_job_count,v_report_limit),
      'agent_runs',LEAST(v_agent_run_count,v_report_limit),'missions',LEAST(v_mission_count,v_report_limit),
      'mission_tasks',LEAST(v_task_count,v_report_limit),'quota_reservations',LEAST(v_reservation_count,v_report_limit)),
    'counts', jsonb_build_object('selected_by_status', v_selected_by_status,
      'transitioned_by_table', v_transitioned_by_table, 'skipped_by_table', v_skipped_by_table,
      'remaining', jsonb_build_object('active',LEAST(v_remaining_active,v_report_limit),
        'stale',LEAST(v_remaining_stale,v_report_limit))),
    'transitioned', LEAST(v_transitioned, v_report_limit), 'accounting_pending', v_accounting_pending,
    'pending_reconciliation', jsonb_build_object(
      'status', CASE WHEN v_accounting_pending = 0 THEN 'reconciled' ELSE 'pending' END,
      'count', LEAST(v_accounting_pending, v_report_limit), 'reason_codes', v_failed_reason_codes),
    'skipped_reason_codes', v_skipped_reason_codes, 'failed_reason_codes', v_failed_reason_codes,
    'remaining_active', LEAST(v_remaining_active,v_report_limit),
    'remaining_stale', LEAST(v_remaining_stale,v_report_limit),
    'ready_for_fresh_run', v_remaining_active = 0 AND v_accounting_pending = 0);
END;
$$;

REVOKE ALL ON FUNCTION public.leadx_transition_scoped_work(text,uuid,uuid,timestamptz,text[],boolean)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_transition_scoped_work(text,uuid,uuid,timestamptz,text[],boolean)
  TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 37: 20261025000200_leadx_scoped_work_operation_ledger.sql
-- ============================================================================

-- LeadX additive scoped-reset operation ledger.
-- The operation key is global by design: reusing it with another request can
-- never create a second scoped mutation or disclose the original request.

CREATE TABLE IF NOT EXISTS public.scoped_work_reset_operations (
  operation_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  operation_key text NOT NULL UNIQUE,
  request_hash text NOT NULL,
  canonical_request jsonb NOT NULL DEFAULT '{}'::jsonb,
  scope_hash text NOT NULL,
  actor_hash text NOT NULL,
  status text NOT NULL DEFAULT 'processing'
    CHECK (status IN ('processing', 'completed')),
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS operation_id uuid;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS operation_key text;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS request_hash text;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS canonical_request jsonb;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS scope_hash text;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS actor_hash text;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS status text;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS result jsonb;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS created_at timestamptz;
ALTER TABLE IF EXISTS public.scoped_work_reset_operations
  ADD COLUMN IF NOT EXISTS completed_at timestamptz;

CREATE UNIQUE INDEX IF NOT EXISTS uq_scoped_reset_operation_key
  ON public.scoped_work_reset_operations(operation_key);
CREATE INDEX IF NOT EXISTS idx_scoped_reset_operations_scope
  ON public.scoped_work_reset_operations(scope_hash, created_at DESC);

CREATE OR REPLACE FUNCTION public.leadx_reset_scoped_work(
  p_operation_key text,
  p_actor text,
  p_scope_kind text,
  p_run_id uuid DEFAULT NULL,
  p_tenant_id uuid DEFAULT NULL,
  p_cutoff timestamptz DEFAULT NULL,
  p_status_allowlist text[] DEFAULT ARRAY['queued','running','retrying']::text[],
  p_apply boolean DEFAULT false,
  p_confirmation boolean DEFAULT false
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_operation_id uuid;
  v_existing public.scoped_work_reset_operations%ROWTYPE;
  v_canonical jsonb;
  v_statuses jsonb;
  v_request_hash text;
  v_scope_hash text;
  v_result jsonb;
  v_started_at timestamptz := clock_timestamp();
BEGIN
  -- The Python boundary validates these values too; keep the RPC fail-closed
  -- for direct service-role callers and never treat a missing scope as global.
  IF p_operation_key IS NULL OR btrim(p_operation_key) = ''
     OR p_actor IS NULL OR btrim(p_actor) = ''
     OR (coalesce(p_apply, false) AND NOT coalesce(p_confirmation, false)) THEN
    RETURN jsonb_build_object('ok', false, 'outcome', 'conflict',
      'reason', CASE WHEN coalesce(p_apply, false) THEN 'confirmation_required' ELSE 'invalid_reset_request' END);
  END IF;

  SELECT coalesce(jsonb_agg(value ORDER BY value), '[]'::jsonb)
    INTO v_statuses
  FROM unnest(coalesce(p_status_allowlist, ARRAY[]::text[])) AS statuses(value);

  v_canonical := jsonb_build_object(
    'actor_hash', md5(p_actor),
    'scope_kind', lower(btrim(coalesce(p_scope_kind, ''))),
    'run_id', p_run_id,
    'tenant_id', p_tenant_id,
    'cutoff', p_cutoff,
    'status_allowlist', v_statuses,
    'apply', coalesce(p_apply, false),
    'confirmation', coalesce(p_confirmation, false)
  );
  v_request_hash := md5(v_canonical::text);
  v_scope_hash := md5(jsonb_build_object(
    'scope_kind', lower(btrim(coalesce(p_scope_kind, ''))),
    'run_id', p_run_id,
    'tenant_id', p_tenant_id,
    'cutoff', p_cutoff,
    'status_allowlist', v_statuses
  )::text);

  INSERT INTO public.scoped_work_reset_operations(
    operation_key, request_hash, canonical_request, scope_hash, actor_hash
  ) VALUES (
    p_operation_key, v_request_hash, v_canonical, v_scope_hash, md5(p_actor)
  ) ON CONFLICT (operation_key) DO NOTHING
  RETURNING operation_id INTO v_operation_id;

  IF v_operation_id IS NULL THEN
    SELECT * INTO v_existing
    FROM public.scoped_work_reset_operations
    WHERE operation_key = p_operation_key
    FOR UPDATE;

    IF v_existing.request_hash <> v_request_hash THEN
      -- Do not return the original scope, actor, result, or operation id.
      RETURN jsonb_build_object('ok', false, 'outcome', 'conflict', 'reason', 'operation_key_conflict');
    END IF;
    IF v_existing.status = 'completed' THEN
      RETURN coalesce(v_existing.result, '{}'::jsonb) || jsonb_build_object('replayed', true);
    END IF;
    RETURN jsonb_build_object('ok', false, 'outcome', 'conflict', 'reason', 'operation_in_progress');
  END IF;

  -- The existing transition function remains the only lifecycle mutation.
  -- This wrapper adds identity, replay, and audit boundaries around it.
  v_result := public.leadx_transition_scoped_work(
    p_scope_kind, p_run_id, p_tenant_id, p_cutoff, p_status_allowlist, p_apply
  );
  IF p_apply THEN
    -- Attach only hashed actor identity and the safe operation id to rows that
    -- this transaction just terminalized. Never persist raw operator input.
    UPDATE public.pipeline_runs
    SET meta = COALESCE(meta, '{}'::jsonb) || jsonb_build_object(
      'recovery', COALESCE(meta->'recovery', '{}'::jsonb) || jsonb_build_object(
        'operation_id', v_operation_id, 'actor_hash', md5(p_actor), 'source_run_id', id::text))
    WHERE status = 'failed' AND error_message = 'scoped_reset'
      AND finished_at >= v_started_at
      AND ((lower(btrim(coalesce(p_scope_kind,''))) = 'run' AND id = p_run_id)
        OR (lower(btrim(coalesce(p_scope_kind,''))) <> 'run' AND tenant_id = p_tenant_id));
    UPDATE public.jobs
    SET terminal_result = COALESCE(terminal_result, '{}'::jsonb) || jsonb_build_object(
      'recovery', COALESCE(terminal_result->'recovery', '{}'::jsonb) || jsonb_build_object(
        'operation_id', v_operation_id, 'actor_hash', md5(p_actor), 'source_job_id', id::text))
    WHERE status = 'cancelled' AND error_category = 'scoped_reset'
      AND finished_at >= v_started_at
      AND ((lower(btrim(coalesce(p_scope_kind,''))) = 'run' AND (id = p_run_id OR payload->>'run_id' = p_run_id::text))
        OR (lower(btrim(coalesce(p_scope_kind,''))) <> 'run' AND tenant_id = p_tenant_id));
  END IF;
  v_result := coalesce(v_result, '{}'::jsonb) || jsonb_build_object(
    'operation_id', v_operation_id,
    'scope_hash', v_scope_hash,
    'outcome', CASE WHEN p_apply THEN 'applied' ELSE 'dry_run' END,
    'replayed', false,
    'event_recorded', true
  );

  UPDATE public.scoped_work_reset_operations
  SET status = 'completed', result = v_result, completed_at = now()
  WHERE operation_id = v_operation_id;

  -- Keep the event allow-listed and opaque. Raw actor/request payloads never
  -- enter audit_log; the existing audit readers expose only safe columns.
  INSERT INTO public.audit_log(
    tenant_id, actor_id, actor_type, action, resource_type, resource_id,
    after_state, reason
  ) VALUES (
    p_tenant_id,
    'principal_' || left(md5(p_actor), 24),
    'platform_admin',
    'admin.scoped_work_reset',
    'scoped_work_reset',
    v_operation_id::text,
    jsonb_build_object(
      'operation_id', v_operation_id,
      'scope_hash', v_scope_hash,
      'run_id', p_run_id,
      'selected', v_result->'selected',
      'outcome', v_result->>'outcome',
      'reason_code', coalesce(v_result->>'reason', 'scoped_reset')
    ),
    'scoped_reset'
  );

  RETURN v_result;
END;
$$;

ALTER TABLE IF EXISTS public.scoped_work_reset_operations ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.scoped_work_reset_operations FROM PUBLIC, anon, authenticated;
GRANT ALL ON TABLE public.scoped_work_reset_operations TO service_role;
REVOKE ALL ON FUNCTION public.leadx_reset_scoped_work(text,text,text,uuid,uuid,timestamptz,text[],boolean,boolean)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.leadx_reset_scoped_work(text,text,text,uuid,uuid,timestamptz,text[],boolean,boolean)
  TO service_role;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 38: 20261025000300_leadx_task8_stage_accounting.sql
-- ============================================================================

-- LeadX Task 8: durable ordered stage and assignment identities.
-- Additive only. Legacy board/status fields remain readable by existing clients.
ALTER TABLE IF EXISTS public.pipeline_run_leads
  ADD COLUMN IF NOT EXISTS stage_status text NOT NULL DEFAULT 'accepted',
  ADD COLUMN IF NOT EXISTS stage_reason text,
  ADD COLUMN IF NOT EXISTS stage_idempotency_key text,
  ADD COLUMN IF NOT EXISTS crm_assignment_id uuid;

DO $$
BEGIN
  ALTER TABLE public.pipeline_run_leads
    ADD CONSTRAINT pipeline_run_leads_stage_status_check
    CHECK (stage_status IN ('accepted','rejected','retryable','skipped','terminal'))
    NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_pipeline_run_leads_stage_operation
  ON public.pipeline_run_leads(run_id, lead_id, stage_idempotency_key)
  WHERE stage_idempotency_key IS NOT NULL;

ALTER TABLE IF EXISTS public.lead_assignments
  ADD COLUMN IF NOT EXISTS assignment_idempotency_key text,
  ADD COLUMN IF NOT EXISTS crm_status text,
  ADD COLUMN IF NOT EXISTS crm_company_id uuid,
  ADD COLUMN IF NOT EXISTS crm_contact_id uuid;

CREATE UNIQUE INDEX IF NOT EXISTS uq_lead_assignments_idempotency
  ON public.lead_assignments(tenant_id, assignment_idempotency_key)
  WHERE assignment_idempotency_key IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_lead_assignments_tenant_delivery
  ON public.lead_assignments(tenant_id, delivery_status, created_at DESC);

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 39: 20261028000400_leadx_delivery_timestamp_semantics.sql
-- ============================================================================

-- Keep delivered_at truthful: assignment creation is not delivery.
-- Pending/failed assignments have never reached a successful delivery state.
UPDATE public.lead_assignments
SET delivered_at = NULL
WHERE delivery_status IN ('pending', 'failed')
  AND delivered_at IS NOT NULL;

COMMENT ON COLUMN public.lead_assignments.delivered_at IS
  'Timestamp of successful delivery confirmation; NULL while assignment is pending or failed.';

-- ============================================================================
-- CANONICAL MIGRATION 40: 20261029000500_leadx_pipeline_run_cancelled_status.sql
-- ============================================================================

-- Allow durable operator/client cancellation as a terminal pipeline state.
DO $$
DECLARE constraint_name text;
BEGIN
  IF to_regclass('public.pipeline_runs') IS NOT NULL THEN
    FOR constraint_name IN
      SELECT conname
      FROM pg_constraint
      WHERE conrelid = 'public.pipeline_runs'::regclass
        AND contype = 'c'
        AND pg_get_constraintdef(oid) ILIKE '%status%'
        AND pg_get_constraintdef(oid) ILIKE '%completed%'
    LOOP
      EXECUTE format('ALTER TABLE public.pipeline_runs DROP CONSTRAINT IF EXISTS %I', constraint_name);
    END LOOP;
    ALTER TABLE public.pipeline_runs
      ADD CONSTRAINT pipeline_runs_status_check
      CHECK (status IN ('queued','running','completed','failed','partial','cancelled'));
  END IF;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 41: 20261030000600_leadx_product_state_authority.sql
-- ============================================================================

-- LeadX product-state authority: additive billing, support, target, and reconciliation fields.
-- Legacy columns/statuses remain readable by older API workers.
ALTER TABLE IF EXISTS public.tenants
  ADD COLUMN IF NOT EXISTS billing_catalog_version text,
  ADD COLUMN IF NOT EXISTS billing_plan_snapshot jsonb,
  ADD COLUMN IF NOT EXISTS payment_method_state text,
  ADD COLUMN IF NOT EXISTS stripe_payment_method_id text,
  ADD COLUMN IF NOT EXISTS billing_cancel_at_period_end boolean NOT NULL DEFAULT false;

DO $$
BEGIN
  ALTER TABLE public.tenants
    ADD CONSTRAINT tenants_payment_method_state_check
    CHECK (payment_method_state IS NULL OR payment_method_state IN ('present','absent','unknown','pending'))
    NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE IF EXISTS public.support_conversations
  ADD COLUMN IF NOT EXISTS ticket_status text NOT NULL DEFAULT 'open',
  ADD COLUMN IF NOT EXISTS ticket_owner text,
  ADD COLUMN IF NOT EXISTS ticket_version integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS resolved_at timestamptz,
  ADD COLUMN IF NOT EXISTS closed_at timestamptz,
  ADD COLUMN IF NOT EXISTS closure_reason text;

DO $$
BEGIN
  ALTER TABLE public.support_conversations
    ADD CONSTRAINT support_ticket_status_check
    CHECK (ticket_status IN ('open','triaged','in_progress','waiting','resolved','closed'))
    NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS public.support_ticket_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.support_conversations(id) ON DELETE CASCADE,
  from_status text NOT NULL,
  to_status text NOT NULL,
  owner text,
  closure_reason text,
  version integer NOT NULL CHECK (version > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_support_ticket_events_conversation
  ON public.support_ticket_events(conversation_id, version DESC);

ALTER TABLE IF EXISTS public.pipeline_runs
  ADD COLUMN IF NOT EXISTS target_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS target_metric text NOT NULL DEFAULT 'assigned',
  ADD COLUMN IF NOT EXISTS reconciliation_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS reconciliation_reason text;

DO $$
BEGIN
  ALTER TABLE public.pipeline_runs
    ADD CONSTRAINT pipeline_runs_target_metric_check
    CHECK (target_metric IN ('assigned','delivered'))
    NOT VALID;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_reconciliation
  ON public.pipeline_runs(tenant_id, reconciliation_status, started_at DESC);

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 42: 20261117000100_leadx_tenant_settings.sql
-- ============================================================================

-- Application code reads tenants.settings (feature flags, exclusive-lead entitlement, quality gate,
-- client discovery requests) but no earlier migration created the column, so those paths returned 500.
-- Additive and idempotent; no row rewrite beyond the default.
ALTER TABLE IF EXISTS public.tenants
  ADD COLUMN IF NOT EXISTS settings jsonb NOT NULL DEFAULT '{}'::jsonb;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 43: 20261117000200_leadx_jobs_singleton_kinds.sql
-- ============================================================================

-- jobs_active_unique_kind_tenant_idx made EVERY job kind single-flight per tenant. That is only intended for
-- cron/scheduler kinds and pipeline.run (two runs for one tenant would fight over the same quota). It also
-- rejected a second queued agent.run, csv.import, email.bulk, ... for the same tenant with a 23505 that surfaced
-- as "Durable job queue unavailable". Narrow the uniqueness to the intended singleton kinds.
-- Subset of the previous predicate: cannot fail on existing data. Rollback: recreate the old index (see MIGRATION_RECOVERY.json).
DROP INDEX IF EXISTS public.jobs_active_unique_kind_tenant_idx;
CREATE UNIQUE INDEX IF NOT EXISTS jobs_active_singleton_kind_tenant_idx
  ON public.jobs (kind, tenant_id)
  WHERE status IN ('queued','running')
    AND kind IN ('pipeline.run','sequences.process_due','automations.process_events','approvals.expire','alerts.run',
                 'schedules.tick','leads.reverify','autonomous.campaign_tick','autonomous.campaign_run',
                 'webhooks.deliver','agent.goals.tick','signals.refresh','searches.alerts');

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 44: 20261117000300_leadx_webhook_signing_secret.sql
-- ============================================================================

-- Per-webhook signing secret. Deliveries were signed only with one global WEBHOOK_SIGNING_SECRET, and were unsigned when it was unset.
-- Existing rows get NULL and keep the legacy behaviour until the webhook is re-created; new webhooks always receive a secret.
ALTER TABLE IF EXISTS public.outbound_webhooks ADD COLUMN IF NOT EXISTS signing_secret text;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 45: 20261117000400_leadx_workflow_runs_fk.sql
-- ============================================================================

-- workflow_runs.workflow_id referenced the legacy workflow_rules table, but runs are created for workflow_definitions rows
-- (the CRM Automations feature). Every custom automation therefore failed with a foreign-key error and never executed.
-- Re-point the key at workflow_definitions. NOT VALID keeps any pre-existing legacy run rows untouched; new rows are checked.
-- Rollback: drop workflow_runs_workflow_definition_fkey and re-add the old constraint referencing workflow_rules(id) NOT VALID.
DO $$
BEGIN
  IF to_regclass('public.workflow_runs') IS NOT NULL AND to_regclass('public.workflow_definitions') IS NOT NULL THEN
    ALTER TABLE public.workflow_runs DROP CONSTRAINT IF EXISTS workflow_runs_workflow_id_fkey;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'workflow_runs_workflow_definition_fkey') THEN
      ALTER TABLE public.workflow_runs
        ADD CONSTRAINT workflow_runs_workflow_definition_fkey
        FOREIGN KEY (workflow_id) REFERENCES public.workflow_definitions(id) ON DELETE CASCADE NOT VALID;
    END IF;
  END IF;
END $$;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 46: 20261117000500_leadx_agent_missions_graph_count.sql
-- ============================================================================

-- agent_missions.graph_count was constrained to exactly 30 (the legacy fixed graph). Task-first missions compile a profile-specific
-- graph of a different size, so creating ANY default GTM mission failed with a check violation. Allow 1..200.
-- Rollback: re-add CHECK (graph_count = 30) after deleting or rewriting task-first missions.
ALTER TABLE IF EXISTS public.agent_missions DROP CONSTRAINT IF EXISTS agent_missions_graph_count_check;
ALTER TABLE IF EXISTS public.agent_missions ADD CONSTRAINT agent_missions_graph_count_check CHECK (graph_count BETWEEN 1 AND 200);

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 47: 20261118000100_leadx_email_format_guard.sql
-- ============================================================================

-- Last line of defence for the "TikTok URL saved as an email" class of bug. The application validates before writing; this makes the
-- database refuse such values even if a future code path forgets to. NOT VALID: existing rows are not scanned or rejected, new writes are checked.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['enrichment', 'leads_global'] LOOP
    IF to_regclass('public.' || t) IS NOT NULL
       AND EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = t AND column_name = 'email')
       AND NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = t || '_email_format_chk') THEN
      EXECUTE format($f$ALTER TABLE public.%I ADD CONSTRAINT %I CHECK (
        email IS NULL OR (
          email ~* '^[a-z0-9._%%+\-]{1,64}@[a-z0-9\-]+(\.[a-z0-9\-]+)*\.[a-z]{2,24}$'
          AND email !~* '(tiktok|instagram|facebook|linkedin|twitter|youtube|pinterest)\.com'
          AND email !~* '@[0-9]x\.'
          AND email !~* '\.(png|jpe?g|gif|webp|svg|css|js)$'
        )) NOT VALID$f$, t, t || '_email_format_chk');
    END IF;
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';

-- ============================================================================
-- CANONICAL MIGRATION 48: 20261118000200_leadx_data_engine_ledgers.sql
-- ============================================================================

-- Data-engine ledgers: provider miss cache, enrichment spend ledger, rejected-lead review queue.
-- All three are written by the service role only (RLS enabled, no anon/authenticated policies);
-- tenants read them through the API, which scopes by tenant_id.

create table if not exists public.enrichment_negative_cache (
  lead_key text not null,
  provider text not null,
  field text not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  primary key (lead_key, provider, field)
);
create index if not exists enrichment_negative_cache_expires_idx on public.enrichment_negative_cache(expires_at);

create table if not exists public.enrichment_spend_ledger (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid references public.tenants(id) on delete cascade,
  run_id text,
  lead_key text,
  provider text not null,
  field text not null,
  credits numeric not null default 0 check (credits >= 0),
  hit boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists enrichment_spend_ledger_tenant_idx on public.enrichment_spend_ledger(tenant_id, created_at desc);
create index if not exists enrichment_spend_ledger_run_idx on public.enrichment_spend_ledger(run_id);

create table if not exists public.lead_review_queue (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  lead_id uuid not null,
  run_id text,
  reasons jsonb not null default '[]'::jsonb,
  score integer,
  snapshot jsonb not null default '{}'::jsonb,
  status text not null default 'pending' check (status in ('pending','approved','rejected','recovered')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by text
);
create unique index if not exists lead_review_queue_tenant_lead_pending_idx
  on public.lead_review_queue(tenant_id, lead_id) where status = 'pending';
create index if not exists lead_review_queue_tenant_status_idx on public.lead_review_queue(tenant_id, status, created_at desc);

alter table public.enrichment_negative_cache enable row level security;
alter table public.enrichment_spend_ledger enable row level security;
alter table public.lead_review_queue enable row level security;

COMMIT;
