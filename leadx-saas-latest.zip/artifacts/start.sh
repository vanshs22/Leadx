#!/usr/bin/env bash
# Start Lead Engine API + CRM frontend with a few commands.
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
API="$ROOT/lead-engine-v2"
WEB="$ROOT/lead-crm-portal/frontend"

echo "==> Checking env"
if [ ! -f "$API/.env" ]; then
  echo "Missing $API/.env — copying from .env.example"
  cp "$API/.env.example" "$API/.env"
  echo "Edit lead-engine-v2/.env (SUPABASE_URL, SUPABASE_SERVICE_KEY, LEAD_ENGINE_SERVICE_KEY) then re-run."
  exit 1
fi

echo "==> Starting API on :8000"
cd "$API"
if command -v docker >/dev/null 2>&1; then
  docker compose up -d api
else
  export PYTHONPATH=.
  pip install -q -r requirements-lead-v2.txt 2>/dev/null || true
  # background uvicorn if not already
  if ! curl -sf http://127.0.0.1:8000/health >/dev/null 2>&1; then
    nohup uvicorn backend.app_service:app --host 0.0.0.0 --port 8000 > /tmp/lead-api.log 2>&1 &
    echo $! > /tmp/lead-api.pid
    sleep 2
  fi
fi

echo "==> Starting frontend on :3000"
cd "$WEB"
if [ ! -f .env.local ]; then
  cat > .env.local << ENV
NEXT_PUBLIC_API_URL=http://localhost:8000
ENV
  echo "Wrote frontend/.env.local (API URL only — no tenant id needed)"
fi
npm install --silent
npm run dev
