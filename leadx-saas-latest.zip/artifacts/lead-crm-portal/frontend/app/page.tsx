import { redirect } from "next/navigation";

/** Root URL → CRM home */
export default function RootPage() {
  redirect("/dashboard");
}
