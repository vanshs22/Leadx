"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getTenantId, setTenant } from "@/lib/tenant";
import { admin, setAdminKey } from "@/lib/admin";

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export function WorkspacePicker({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [hasTenant, setHasTenant] = useState(false);
  const [tenants, setTenants] = useState<any[]>([]);
  const [serviceKey, setServiceKey] = useState("");
  const [newName, setNewName] = useState("My workspace");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [manualId, setManualId] = useState("");

  useEffect(() => {
    const id = getTenantId();
    setHasTenant(!!id);
    setReady(true);
    if (!id && typeof window !== "undefined" && sessionStorage.getItem("admin_service_key")) {
      loadTenants();
    }
  }, []);

  async function loadTenants() {
    try {
      const d = await admin.tenants();
      setTenants(d.tenants || []);
    } catch (e: any) {
      setMsg(e.message);
    }
  }

  async function unlock() {
    if (serviceKey.length < 8) {
      setMsg("Enter your LEAD_ENGINE_SERVICE_KEY");
      return;
    }
    setAdminKey(serviceKey);
    setBusy(true);
    try {
      await loadTenants();
      setMsg("Key saved for this browser session. Pick or create a workspace.");
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function createWorkspace() {
    setBusy(true);
    setMsg("");
    try {
      const r: any = await admin.createTenant({
        name: newName || "My workspace",
        delivery_channel: "portal",
        leads_per_month_limit: 500,
        status: "active",
      });
      const id = r.id || r.tenant?.id || r.tenant_id;
      if (!id) throw new Error("No tenant id returned");
      setTenant(id, newName);
      setHasTenant(true);
      router.refresh();
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  function pick(t: any) {
    setTenant(t.id, t.name || t.id);
    setHasTenant(true);
    router.refresh();
  }

  function useManual() {
    if (!manualId.trim()) return;
    setTenant(manualId.trim(), "Workspace");
    setHasTenant(true);
    router.refresh();
  }

  if (!ready) {
    return <div className="min-h-screen bg-surface p-8 text-ink-faint">Loading…</div>;
  }

  if (hasTenant) {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-surface p-6">
      <div className="card-pad w-full max-w-md space-y-4 shadow-lift">
        <div>
          <h1 className="text-xl font-semibold text-ink">Choose workspace</h1>
          <p className="mt-1 text-sm text-ink-muted">
            No tenant id in env needed. Pick or create a workspace once — saved in this browser.
          </p>
        </div>

        {msg && <p className="text-sm text-ink-muted">{msg}</p>}

        <div className="space-y-2 border-b border-line pb-4">
          <label className="block text-xs text-ink-faint">
            Operator service key (to list/create workspaces)
            <input
              className="input mt-1"
              type="password"
              value={serviceKey}
              onChange={(e) => setServiceKey(e.target.value)}
              placeholder="LEAD_ENGINE_SERVICE_KEY"
            />
          </label>
          <button type="button" className="btn-secondary w-full" disabled={busy} onClick={unlock}>
            Unlock
          </button>
        </div>

        {tenants.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase text-ink-faint">Existing</div>
            {tenants.map((t) => (
              <button
                key={t.id}
                type="button"
                className="btn-secondary w-full justify-start"
                onClick={() => pick(t)}
              >
                {t.name || t.id}
              </button>
            ))}
          </div>
        )}

        <div className="space-y-2 border-t border-line pt-4">
          <div className="text-xs font-semibold uppercase text-ink-faint">Create new</div>
          <input
            className="input"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Workspace name"
          />
          <button type="button" className="btn-primary w-full" disabled={busy} onClick={createWorkspace}>
            Create & open
          </button>
        </div>

        <div className="space-y-2 border-t border-line pt-4">
          <div className="text-xs font-semibold uppercase text-ink-faint">Or paste tenant UUID</div>
          <input
            className="input font-mono text-xs"
            value={manualId}
            onChange={(e) => setManualId(e.target.value)}
            placeholder="uuid…"
          />
          <button type="button" className="btn-ghost w-full" onClick={useManual}>
            Use this id
          </button>
        </div>
      </div>
    </div>
  );
}
