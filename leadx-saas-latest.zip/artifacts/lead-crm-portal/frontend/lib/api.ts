/**
 * CRM Portal API client — all calls scoped to tenant.
 * In production, attach JWT via middleware / fetch interceptor.
 */

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    cache: "no-store",
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err || res.statusText);
  }
  return res.json();
}

export const crm = {
  dashboard: (tenantId: string) =>
    api<DashboardResponse>(`/crm/${tenantId}/dashboard`),

  leads: (tenantId: string, params: Record<string, string | number | undefined> = {}) => {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== "") q.set(k, String(v));
    });
    return api<{ total: number; leads: LeadCard[] }>(`/crm/${tenantId}/leads?${q}`);
  },

  lead: (tenantId: string, assignmentId: string) =>
    api<LeadDetail>(`/crm/${tenantId}/leads/${assignmentId}`),

  updateLead: (tenantId: string, assignmentId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/leads/${assignmentId}`, {
      method: "PATCH",
      body: JSON.stringify(body),
    }),

  changeStage: (tenantId: string, assignmentId: string, stageId: string, note?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/stage`, {
      method: "POST",
      body: JSON.stringify({ stage_id: stageId, note }),
    }),

  bulkStage: (tenantId: string, assignmentIds: string[], stageId: string) =>
    api(`/crm/${tenantId}/leads/bulk-stage`, {
      method: "POST",
      body: JSON.stringify({ assignment_ids: assignmentIds, stage_id: stageId }),
    }),

  addActivity: (
    tenantId: string,
    assignmentId: string,
    body: { activity_type: string; title?: string; body?: string; meta?: object }
  ) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/activities`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  createTask: (
    tenantId: string,
    assignmentId: string,
    body: { title: string; due_at?: string; priority?: string; description?: string }
  ) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/tasks`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  completeTask: (tenantId: string, taskId: string) =>
    api(`/crm/${tenantId}/tasks/${taskId}/complete`, { method: "POST" }),

  pipeline: (tenantId: string) =>
    api<PipelineBoard>(`/crm/${tenantId}/pipeline`),

  stages: (tenantId: string) =>
    api<Stage[]>(`/crm/${tenantId}/stages`),

  setup: (tenantId: string) =>
    api(`/crm/${tenantId}/setup`, { method: "POST" }),

  reports: (tenantId: string) =>
    api<ReportsSummary>(`/crm/${tenantId}/reports/summary`),

  reportBadLead: (tenantId: string, assignmentId: string, reason: string, detail = "") =>
    api(`/crm/${tenantId}/leads/${assignmentId}/bad-lead`, {
      method: "POST",
      body: JSON.stringify({ reason, detail }),
    }),

  exportInstantlyUrl: (tenantId: string) =>
    `${BASE}/crm/${tenantId}/export/instantly`,

  getBranding: (tenantId: string) =>
    api<any>(`/crm/${tenantId}/branding`),

  updateBranding: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/branding`, { method: "PATCH", body: JSON.stringify(body) }),

  teamMembers: (tenantId: string) =>
    api<{ members: any[]; invites: any[] }>(`/crm/${tenantId}/team/members`),

  teamInvite: (tenantId: string, body: { email: string; role?: string; send_email?: boolean }) =>
    api(`/crm/${tenantId}/team/invite`, { method: "POST", body: JSON.stringify(body) }),

  docsTemplates: (tenantId: string, category?: string) => {
    const q = category ? `?category=${encodeURIComponent(category)}` : "";
    return api<{ templates: any[] }>(`/crm/${tenantId}/docs/templates${q}`);
  },

  docsSend: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/docs/send`, { method: "POST", body: JSON.stringify(body) }),

  updateIcpWeights: (tenantId: string, icpId: string, weights: Record<string, number>) =>
    api(`/crm/${tenantId}/icp/weights`, {
      method: "PATCH",
      body: JSON.stringify({ icp_id: icpId, weights }),
    }),

  searchRun: (tenantId: string, body: Record<string, unknown>) =>
    api(`/crm/${tenantId}/search-run`, { method: 'POST', body: JSON.stringify(body) }),

  sendEmail: (
    tenantId: string,
    assignmentId: string,
    body: { subject: string; body_html: string; body_text?: string; reply_to?: string }
  ) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/email`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  sendEmailBulk: (
    tenantId: string,
    body: {
      subject: string;
      body_html: string;
      body_text?: string;
      assignment_ids?: string[];
      tier?: string;
      stage?: string;
      limit?: number;
    }
  ) =>
    api(`/crm/${tenantId}/email/bulk`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  firstTouch: (tenantId: string, assignmentId: string, channel?: string) =>
    api(`/crm/${tenantId}/leads/${assignmentId}/first-touch`, {
      method: "POST",
      body: JSON.stringify({ channel: channel || "sms" }),
    }),

  exportCsv: (tenantId: string, params: { stage?: string; tier?: string } = {}) => {
    const q = new URLSearchParams(params as Record<string, string>);
    return api<{ filename: string; rows: Record<string, unknown>[] }>(
      `/crm/${tenantId}/export/csv?${q}`
    );
  },
};

// ─── Types ─────────────────────────────────────────────────────────────────

export type LeadCard = {
  assignment_id: string;
  lead_id: string;
  company_name: string;
  phone_e164?: string;
  phone_normalized?: string;
  email?: string;
  website?: string;
  city?: string;
  address?: string;
  tier?: string;
  total_score?: number;
  stage_id?: string;
  stage_name?: string;
  stage_slug?: string;
  stage_color?: string;
  priority?: string;
  tags?: string[];
  has_booking?: boolean;
  booking_platform?: string;
  services?: string[];
  owner_name?: string;
  google_rating?: number;
  review_count?: number;
  score_reasoning?: string;
  delivered_at?: string;
  next_action_at?: string;
  last_contacted_at?: string;
  assignment_status?: string;
  value_estimate?: number;
};

export type Stage = {
  id: string;
  name: string;
  slug: string;
  color: string;
  position: number;
  is_won?: boolean;
  is_lost?: boolean;
};

export type DashboardResponse = {
  tenant: { name: string; plan: string; leads_per_month_limit: number } | null;
  kpis: {
    total_leads: number;
    tier_a: number;
    tier_b: number;
    new: number;
    in_pipeline: number;
    won: number;
    lost: number;
    win_rate_pct: number;
  };
  funnel: { stage: string; slug: string; color: string; count: number }[];
  usage: { leads_delivered: number; tier_a_count: number } | null;
  quota_limit: number | null;
  tasks_due: { id: string; title: string; due_at?: string; priority: string }[];
  recent_activity: { id: string; activity_type: string; title?: string; created_at: string }[];
};

export type LeadDetail = {
  lead: LeadCard;
  activities: {
    id: string;
    activity_type: string;
    title?: string;
    body?: string;
    created_at: string;
    meta?: object;
  }[];
  tasks: {
    id: string;
    title: string;
    status: string;
    due_at?: string;
    priority: string;
  }[];
};

export type PipelineBoard = {
  stages: (Stage & { leads: LeadCard[] })[];
  unstaged: LeadCard[];
};

export type ReportsSummary = {
  total: number;
  with_email: number;
  with_email_pct: number;
  with_booking: number;
  by_tier: Record<string, number>;
  by_stage: Record<string, number>;
  avg_score: number;
};
