/**
 * Operator Admin API client — uses LEAD_ENGINE_SERVICE_KEY.
 * Set NEXT_PUBLIC_API_URL. Enter LEAD_ENGINE_SERVICE_KEY only via Admin Login (sessionStorage).
 * Do NOT put the service key in NEXT_PUBLIC_* env vars.
 */

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

function getKey(): string {
  // Operator key is entered at /admin/login into sessionStorage only.
  // NEVER use NEXT_PUBLIC_* for the service key — it would ship in the browser bundle.
  if (typeof window !== "undefined") {
    return sessionStorage.getItem("admin_service_key") || "";
  }
  return "";
}

export function setAdminKey(key: string) {
  if (typeof window !== "undefined") {
    sessionStorage.setItem("admin_service_key", key);
  }
}

export function getAdminKeyPresent(): boolean {
  if (typeof window === "undefined") return false;
  return !!sessionStorage.getItem("admin_service_key");
}

export function clearAdminKey() {
  if (typeof window !== "undefined") {
    sessionStorage.removeItem("admin_service_key");
  }
}

async function adminApi<T>(path: string, init?: RequestInit): Promise<T> {
  const key = getKey();
  if (!key) throw new Error("Service key required — open Admin Login");
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
      ...(init?.headers || {}),
    },
    cache: "no-store",
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err || res.statusText);
  }
  return res.json();
}

export const admin = {
  health: () => fetch(`${BASE}/health`).then((r) => r.json()),

  globalStats: () => adminApi<{ tenants_active: number; tenants_total: number; icps_active: number; leads_global: number; assignments: number; opt_outs: number }>("/leads/v2/admin/global-stats"),

  ops: (days = 14) => adminApi<any>(`/leads/v2/ops/dashboard?days=${days}`),

  tenants: (status?: string) =>
    adminApi<{ tenants: any[] }>(`/leads/v2/admin/tenants${status ? `?status=${status}` : ""}`),

  tenant: (id: string) => adminApi<{ tenant: any; icps: any[]; usage: any[] }>(`/leads/v2/admin/tenants/${id}`),

  createTenant: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/tenants", { method: "POST", body: JSON.stringify(body) }),

  updateTenant: (id: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/tenants/${id}`, { method: "PATCH", body: JSON.stringify(body) }),

  icps: (tenantId?: string) =>
    adminApi<{ icps: any[] }>(`/leads/v2/admin/icps${tenantId ? `?tenant_id=${tenantId}` : ""}`),

  createIcp: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/icps", { method: "POST", body: JSON.stringify(body) }),

  updateIcp: (id: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/icps/${id}`, { method: "PATCH", body: JSON.stringify(body) }),

  runs: (tenantId?: string) =>
    adminApi<{ runs: any[] }>(`/leads/v2/admin/runs${tenantId ? `?tenant_id=${tenantId}` : ""}`),

  runPipeline: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/pipeline/run", { method: "POST", body: JSON.stringify(body) }),

  runAllIcps: (body: Record<string, unknown> = {}) =>
    adminApi("/leads/v2/pipeline/run-all-icps", { method: "POST", body: JSON.stringify(body) }),

  keys: () => adminApi<{ keys: any[] }>("/leads/v2/admin/keys"),

  keysHealth: () => adminApi<any>("/leads/v2/keys/health"),

  addKey: (body: { provider: string; key_value: string; label?: string; credits_limit?: number }) =>
    adminApi("/leads/v2/keys/add", { method: "POST", body: JSON.stringify(body) }),

  usage: (period?: string) =>
    adminApi<{ period: string; usage: any[] }>(`/leads/v2/admin/usage${period ? `?period=${period}` : ""}`),

  billingLink: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/billing/link", { method: "POST", body: JSON.stringify(body) }),

  billingReport: (tenantId: string) =>
    adminApi(`/leads/v2/billing/report/${tenantId}`, { method: "POST" }),

  billingReportAll: () =>
    adminApi("/leads/v2/billing/report-all", { method: "POST" }),

  optOut: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/opt-out", { method: "POST", body: JSON.stringify(body) }),

  suppressionUpload: (tenantId: string, rows: any[]) =>
    adminApi("/leads/v2/suppression/upload", {
      method: "POST",
      body: JSON.stringify({ tenant_id: tenantId, rows }),
    }),

  credit: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/credits", { method: "POST", body: JSON.stringify(body) }),

  refreshPriors: (vertical: string) =>
    adminApi(`/leads/v2/priors/refresh/${vertical}`, { method: "POST" }),

  tenantStats: (tenantId: string) =>
    adminApi(`/leads/v2/${tenantId}/stats`),

  updateBranding: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/tenants/branding", { method: "PATCH", body: JSON.stringify(body) }),

  teamInvite: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/team/invite", { method: "POST", body: JSON.stringify(body) }),

  teamMembers: (tenantId: string) =>
    adminApi(`/leads/v2/team/${tenantId}/members`),

  samplePack: (body: { vertical: string; geo?: string; limit?: number; tenant_id?: string }) =>
    adminApi("/leads/v2/admin/sample-pack", { method: "POST", body: JSON.stringify(body) }),

  qaSubmit: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/qa", { method: "POST", body: JSON.stringify(body) }),

  qaStats: (tenantId?: string) =>
    adminApi(`/leads/v2/admin/qa/stats${tenantId ? `?tenant_id=${tenantId}` : ""}`),

  badLeads: () => adminApi<{ reports: any[] }>("/leads/v2/admin/bad-leads"),

  resolveBadLead: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/bad-leads/resolve", { method: "POST", body: JSON.stringify(body) }),

  territories: () => adminApi<{ territories: any[] }>("/leads/v2/admin/territories"),

  createTerritory: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/territories", { method: "POST", body: JSON.stringify(body) }),
};
