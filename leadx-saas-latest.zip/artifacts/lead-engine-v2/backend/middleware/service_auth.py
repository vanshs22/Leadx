"""
Service-key auth for internal / n8n / cron callers of leads_api.
Separate from JWT tenant auth — this protects operator endpoints.

Set LEAD_ENGINE_SERVICE_KEY in env. Requests must send:
  Authorization: Bearer <service_key>
  or X-Service-Key: <service_key>
"""
from __future__ import annotations

import hmac
import os
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

_bearer = HTTPBearer(auto_error=False)

SERVICE_KEY = os.getenv("LEAD_ENGINE_SERVICE_KEY", "")


def _configured() -> bool:
    return bool(SERVICE_KEY and len(SERVICE_KEY) >= 16)


async def require_service_key(
    request: Request,
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> None:
    if not _configured():
        # Fail closed in production-ish environments
        if os.getenv("ENVIRONMENT", "").lower() in ("production", "prod", "staging"):
            raise HTTPException(
                status.HTTP_503_SERVICE_UNAVAILABLE,
                "Service key not configured",
            )
        # Dev: allow if explicitly opted in
        if os.getenv("LEAD_ENGINE_DEV_AUTH_BYPASS", "").lower() in ("1", "true", "yes"):
            return
        raise HTTPException(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "Set LEAD_ENGINE_SERVICE_KEY (min 16 chars) or LEAD_ENGINE_DEV_AUTH_BYPASS for local dev",
        )

    provided = None
    if creds and creds.credentials:
        provided = creds.credentials
    if not provided:
        provided = request.headers.get("X-Service-Key")

    if not provided or not hmac.compare_digest(provided, SERVICE_KEY):
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Invalid or missing service key",
            headers={"WWW-Authenticate": "Bearer"},
        )
