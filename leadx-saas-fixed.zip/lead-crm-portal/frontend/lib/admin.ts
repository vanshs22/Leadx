import { getApiBase } from "./config";

const STORAGE_KEY = "lead_admin_service_key"; // sessionStorage — cleared when the tab closes

export function setAdminKey(k: string) {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(STORAGE_KEY, k);
}

export function clearAdminKey() {
  if (typeof window === "undefined") return;
  sessionStorage.removeItem(STORAGE_KEY);
}

export function getAdminKey(): string {
  if (typeof window === "undefined") return "";
  return sessionStorage.getItem(STORAGE_KEY) || "";
}

export function hasAdminKey(): boolean {
  return getAdminKey().length >= 8;
}

async function adminApi(path: string, init?: RequestInit) {
  const base = getApiBase();
  const url = `${base}${path.startsWith("/") ? path : `/${path}`}`;
  const key = getAdminKey();
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(key ? { Authorization: `Bearer ${key}` } : {}),
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch (e: any) {
    throw new Error(`Cannot reach API at ${base}: ${e?.message || "network error"}`);
  }
  if (res.status === 401 || res.status === 403) {
    clearAdminKey();
    if (typeof window !== "undefined") window.location.href = "/admin/login";
    throw new Error("Session expired — please log in again");
  }
  if (!res.ok) {
    const t = await res.text();
    let d = t;
    try {
      d = JSON.parse(t).detail || t;
    } catch {
      /* keep text */
    }
    throw new Error(typeof d === "string" ? d : JSON.stringify(d));
  }
  if (res.status === 204) return undefined;
  return res.json();
}

export const admin = {
  // Tenants
  tenants: () => adminApi("/leads/v2/admin/tenants"),
  tenant: (id: string) => adminApi(`/leads/v2/admin/tenants/${id}`),
  updateTenant: (id: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/tenants/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
  createTenant: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/tenants", { method: "POST", body: JSON.stringify(body) }),

  // ICPs
  icps: (tenantId?: string) =>
    adminApi(`/leads/v2/admin/icps${tenantId ? `?tenant_id=${tenantId}` : ""}`),
  createIcp: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/icps", { method: "POST", body: JSON.stringify(body) }),
  updateIcp: (id: string, body: Record<string, unknown>) =>
    adminApi(`/leads/v2/admin/icps/${id}`, { method: "PATCH", body: JSON.stringify(body) }),

  // Pipeline
  runPipeline: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/pipeline/run", { method: "POST", body: JSON.stringify(body) }),
  runAllIcps: () => adminApi("/leads/v2/pipeline/run-all-icps", { method: "POST" }),

  // Keys
  keys: () => adminApi("/leads/v2/admin/keys"),
  addKey: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/keys/add", { method: "POST", body: JSON.stringify(body) }),
  keysHealth: () => adminApi("/leads/v2/keys/health"),

  // Ops / usage / stats
  usage: (params = "") => adminApi(`/leads/v2/admin/usage${params}`),
  globalStats: () => adminApi("/leads/v2/admin/global-stats"),
  ops: (days = 14) => adminApi(`/leads/v2/ops/dashboard?days=${days}`),
  health: () => adminApi("/health"),

  // Sample pack / QA / bad leads
  samplePack: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/sample-pack", { method: "POST", body: JSON.stringify(body) }),
  qaSubmit: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/qa", { method: "POST", body: JSON.stringify(body) }),
  qaStats: () => adminApi("/leads/v2/admin/qa/stats"),
  badLeads: () => adminApi("/leads/v2/admin/bad-leads"),
  resolveBadLead: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/bad-leads/resolve", { method: "POST", body: JSON.stringify(body) }),

  // Territories
  territories: () => adminApi("/leads/v2/admin/territories"),
  createTerritory: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/admin/territories", { method: "POST", body: JSON.stringify(body) }),

  // Billing
  billingLink: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/billing/link", { method: "POST", body: JSON.stringify(body) }),
  billingReport: (tenantId: string) =>
    adminApi(`/leads/v2/billing/report/${tenantId}`, { method: "POST" }),
  billingReportAll: () => adminApi("/leads/v2/billing/report-all", { method: "POST" }),

  // Suppression / opt-out
  suppressionUpload: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/suppression/upload", { method: "POST", body: JSON.stringify(body) }),
  optOut: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/opt-out", { method: "POST", body: JSON.stringify(body) }),

  // Priors / team
  refreshPriors: (vertical: string) =>
    adminApi(`/leads/v2/priors/refresh/${vertical}`, { method: "POST" }),
  teamInvite: (body: Record<string, unknown>) =>
    adminApi("/leads/v2/team/invite", { method: "POST", body: JSON.stringify(body) }),
};
