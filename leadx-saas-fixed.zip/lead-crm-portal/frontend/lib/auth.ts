import { getSupabase } from "./supabaseClient";

export async function getAccessToken(): Promise<string | null> {
  const { data } = await getSupabase().auth.getSession();
  return data.session?.access_token || null;
}

export async function signInWithPassword(email: string, password: string) {
  const { error } = await getSupabase().auth.signInWithPassword({ email, password });
  if (error) throw new Error(error.message);
}

export async function signUpWithPassword(email: string, password: string) {
  const { error } = await getSupabase().auth.signUp({ email, password });
  if (error) throw new Error(error.message);
}

export async function signOut() {
  await getSupabase().auth.signOut();
}

export async function isLoggedIn(): Promise<boolean> {
  return !!(await getAccessToken());
}
