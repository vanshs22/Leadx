"use client";

/**
 * Replaces the old WorkspacePicker, which let any visitor list every
 * tenant in the system and open (or paste in) any tenant's UUID with no
 * login at all. This gate requires a real Supabase session, then asks
 * the backend (/crm/me) which tenant the logged-in user actually belongs
 * to — the browser never enumerates or chooses tenants itself.
 */
import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { getSupabase } from "@/lib/supabaseClient";
import { crm } from "@/lib/api";
import { setTenant, getTenantId } from "@/lib/tenant";

export function SessionGate({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function resolve() {
      const { data } = await getSupabase().auth.getSession();
      if (!data.session) {
        router.replace(`/login?next=${encodeURIComponent(pathname || "/")}`);
        return;
      }
      // Already resolved this session
      if (getTenantId()) {
        if (!cancelled) setReady(true);
        return;
      }
      try {
        const me = await crm.me();
        setTenant(me.tenant_id);
        if (!cancelled) setReady(true);
      } catch (e: any) {
        if (!cancelled) setError(e.message || "Could not resolve your workspace");
      }
    }

    resolve();
    return () => {
      cancelled = true;
    };
  }, [pathname, router]);

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas p-4 text-sm text-red-400">
        {error}
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-canvas text-ink-muted text-sm">
        Loading…
      </div>
    );
  }

  return <>{children}</>;
}
