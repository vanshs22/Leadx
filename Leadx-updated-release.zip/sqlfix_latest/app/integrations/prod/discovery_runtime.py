"""Task 3 discovery runtime contracts.

This module is deliberately small and dependency-light.  It owns the boundaries
that must remain true even when the legacy discovery pipeline is retried:
local validation isolation, persisted progress projection, and idempotent quota
settlement.  Provider adapters use these helpers before doing any remote work.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import logging
import os
from typing import Any, Iterable
from uuid import uuid4
from collections import deque


class ProviderIsolationError(RuntimeError):
    """Raised when a prohibited provider or lead-generation call is reached."""


_PROVIDER_ISOLATION_AUDIT: deque[dict[str, str]] = deque(maxlen=256)


def provider_isolation_events() -> list[dict[str, str]]:
    """Return sanitized local deny events for validation evidence."""

    return list(_PROVIDER_ISOLATION_AUDIT)


def clear_provider_isolation_events() -> None:
    _PROVIDER_ISOLATION_AUDIT.clear()


def local_validation_mode(environ: dict[str, str] | None = None) -> bool:
    env = os.environ if environ is None else environ
    return str(env.get("LOCAL_VALIDATION_MODE", "0")).strip().lower() in {"1", "true", "yes", "on"}


def assert_provider_allowed(provider: str, *, local_mode: bool | None = None) -> None:
    """Fail closed before a provider/network boundary in local mode."""
    isolated = local_validation_mode() if local_mode is None else local_mode
    if isolated:
        safe_provider = str(provider or "unknown")[:80]
        _PROVIDER_ISOLATION_AUDIT.append({"provider": safe_provider, "outcome": "denied"})
        raise ProviderIsolationError(f"provider_isolated:{safe_provider}")


def synthetic_discovery(
    industry: str,
    locations: Iterable[str] | None,
    *,
    limit_per_location: int = 10,
) -> list[dict[str, Any]]:
    """Return deterministic, non-billable local fixtures without I/O."""
    rows: list[dict[str, Any]] = []
    locations = list(locations or ["Local"])
    count = max(0, min(int(limit_per_location or 0), 500))
    for location in locations:
        for index in range(count):
            key = f"{industry.strip().lower()}|{location.strip().lower()}|{index}"
            digest = sha256(key.encode("utf-8")).hexdigest()[:12]
            name = f"Local {industry.strip().title() or 'Business'} {index + 1}"
            rows.append({
                "id": f"local-{digest}",
                "name": name,
                "company_name": name,
                "website": f"https://local.invalid/{digest}",
                "website_domain": f"local-{digest}.invalid",
                "location": location,
                "industry": industry,
                "source": "local_fixture",
                "source_mode": "local",
                "source_provenance": {"source": "local_fixture", "billable": False},
                "billable": False,
                "fingerprint": f"local:{digest}",
                "enrichment_ok": True,
            })
    return rows


def initial_progress(requested: int) -> dict[str, int]:
    requested = max(0, int(requested or 0))
    return {
        "total": requested, "completed": 0, "failed": 0, "skipped": 0,
        "remaining": requested, "qualifying": 0, "billable": 0, "shortfall": requested,
    }


def project_progress(
    task_rows: Iterable[dict[str, Any]] | None,
    result_rows: Iterable[dict[str, Any]] | None,
    requested: int,
) -> dict[str, int]:
    """Project progress only from durable task/result rows.

    A provider task with no durable result remains incomplete.  A result is
    billable only when it explicitly says so and has persisted terminal state.
    """
    tasks = list(task_rows or [])
    results = list(result_rows or [])
    if not tasks:
        tasks = [{"id": str(r.get("task_id") or r.get("lead_id") or r.get("id") or index), "status": r.get("status")}
                 for index, r in enumerate(results)]
    terminal = {"completed", "complete", "done", "persisted", "qualified"}
    failed_states = {"failed", "error"}
    skipped_states = {"skipped", "cancelled", "canceled"}
    result_by_task: dict[str, dict[str, Any]] = {}
    for result in results:
        for key in (result.get("task_id"), result.get("lead_id"), result.get("id")):
            if key is not None:
                result_by_task[str(key)] = result
    completed = failed = skipped = qualifying = billable = 0
    for task in tasks:
        task_id = str(task.get("id") or task.get("task_id") or "")
        result = result_by_task.get(task_id)
        state = str((result or {}).get("status") or task.get("status") or "").lower()
        durable = bool(result and (result.get("persisted", True) is not False))
        if durable and state in terminal:
            completed += 1
            qualifying += int(bool(result.get("qualifying", result.get("qualified", False))))
            billable += int(bool(result.get("billable", False)))
        elif state in failed_states:
            failed += 1
        elif state in skipped_states:
            skipped += 1
    total = max(0, int(requested or 0))
    completed = min(completed, total) if total else completed
    remaining = max(total - completed - failed - skipped, 0)
    return {
        "total": total, "completed": completed, "failed": failed, "skipped": skipped,
        "remaining": remaining, "qualifying": qualifying, "billable": billable,
        "shortfall": max(total - qualifying, 0),
    }


@dataclass(frozen=True)
class SettlementResult:
    ok: bool
    outcome: str
    committed: int = 0
    released: int = 0
    replayed: bool = False
    recoverable: bool = False
    reason: str | None = None


def _reservation_rows(sb, reservation_id: str, tenant_id: str) -> list[dict[str, Any]]:
    return (sb.table("quota_reservations").select("*").eq("id", reservation_id)
            .eq("tenant_id", tenant_id).limit(1).execute().data or [])


def settle_reservation(
    sb,
    *,
    reservation_id: str,
    tenant_id: str,
    settlement_key: str,
    billable: int,
    reserved: int,
) -> SettlementResult:
    """Commit persisted billable work and release the unused reservation once."""
    billable = max(0, int(billable or 0))
    reserved = max(0, int(reserved or 0))
    release = max(reserved - billable, 0)
    if not settlement_key.strip():
        return SettlementResult(False, "failed", reason="settlement_key_required", recoverable=True)
    try:
        rpc = sb.rpc("leadx_settle_discovery_reservation", {
            "p_reservation_id": reservation_id, "p_tenant_id": tenant_id,
            "p_settlement_key": settlement_key, "p_committed": billable,
            "p_released": release,
        }).execute()
        data = getattr(rpc, "data", None)
        if isinstance(data, dict) and data.get("ok"):
            return SettlementResult(True, str(data.get("status") or "committed"), billable, release, bool(data.get("replayed")))
    except Exception as exc:
        # Compatibility fallback below is safe for older installs and fake stores.
        last_error = exc
    else:
        last_error = RuntimeError("settlement_rpc_unavailable")

    try:
        rows = _reservation_rows(sb, reservation_id, tenant_id)
        legacy_quota_schema = False
    except Exception:
        rows = []
        legacy_quota_schema = True
    if legacy_quota_schema:
        # Legacy deployments store monthly reservation only in usage_log.
        period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
        try:
            usage = (sb.table("usage_log").select("id,leads_delivered,quota_reserved")
                     .eq("tenant_id", tenant_id).eq("period", period).limit(1).execute().data or [])
            if not usage:
                return SettlementResult(False, "failed", reason="usage_row_not_found", recoverable=True)
            row = usage[0]
            current_reserved = int(row.get("quota_reserved") or 0)
            current_used = int(row.get("leads_delivered") or 0)
            sb.table("usage_log").update({
                "quota_reserved": max(0, current_reserved - reserved),
                "leads_delivered": current_used + billable,
            }).eq("id", row["id"]).execute()
            return SettlementResult(True, "committed" if billable else "released", billable, release)
        except Exception as exc:
            return SettlementResult(False, "failed", reason=type(exc).__name__, recoverable=True)
    if not rows:
        return SettlementResult(False, "failed", reason="reservation_not_found", recoverable=False)
    reservation = rows[0]
    if str(reservation.get("status") or "reserved") != "reserved":
        return SettlementResult(True, str(reservation.get("status")), int(reservation.get("committed_quantity") or 0), int(reservation.get("released_quantity") or 0), replayed=True)
    existing = (sb.table("quota_settlements").select("id").eq("reservation_id", reservation_id)
                .eq("settlement_key", settlement_key).limit(1).execute().data or [])
    if existing:
        return SettlementResult(True, "replay", billable, release, replayed=True)
    try:
        sb.table("quota_settlements").insert({
            "reservation_id": reservation_id, "tenant_id": tenant_id,
            "settlement_key": settlement_key, "outcome": "committed" if billable else "released",
            "quantity": billable, "committed_quantity": billable, "released_quantity": release,
        }).execute()
        sb.table("quota_reservations").update({
            "status": "committed" if billable else "released",
            "committed_quantity": billable, "released_quantity": release,
        }).eq("id", reservation_id).eq("tenant_id", tenant_id).eq("status", "reserved").execute()
        return SettlementResult(True, "committed" if billable else "released", billable, release)
    except Exception as exc:
        return SettlementResult(False, "failed", reason=type(exc).__name__, recoverable=True)


def settlement_key(request_id: str, job_id: str | None = None) -> str:
    return f"discovery:{request_id}:{job_id or request_id}"


def durable_identity(*, request_id: str | None = None, requested: int = 0, mode: str | None = None) -> dict[str, Any]:
    request_id = request_id or str(uuid4())
    mission_id = str(uuid4())
    job_id = str(uuid4())
    return {
        "request_id": request_id, "mission_id": mission_id, "job_id": job_id,
        "requested_leads": max(0, int(requested or 0)),
        "mode": mode or ("local" if local_validation_mode() else "production"),
        "progress": initial_progress(requested),
        "settlement_key": settlement_key(request_id, job_id),
    }


def reserve_request_quota(sb, *, reservation_id: str, tenant_id: str, request_id: str, amount: int, settlement_key: str) -> dict[str, Any]:
    """Reserve quota before provider work; compatible with Task 2 installs."""
    amount = max(0, int(amount or 0))
    try:
        response = sb.rpc("leadx_reserve_discovery_quota", {
            "p_reservation_id": reservation_id, "p_tenant_id": tenant_id,
            "p_request_id": request_id, "p_requested": amount,
            "p_settlement_key": settlement_key,
        }).execute()
        data = getattr(response, "data", None)
        if isinstance(data, dict) and data.get("ok"):
            return data
    except Exception as exc:
        # Compatibility fallback is intentional, but never silently swallow a
        # failed RPC; keep diagnostics type-only and secret-free.
        logging.getLogger("lead_engine.discovery_runtime").warning(
            "quota reservation RPC unavailable error=%s", type(exc).__name__
        )
    # Legacy installs may not have quota_reservations at all. Keep the
    # reservation durable in usage_log so client requests can still be approved
    # and settled without pretending the additive ledger exists.
    try:
        rows = (sb.table("quota_reservations").select("id,status,reserved_quantity")
                .eq("id", reservation_id).eq("tenant_id", tenant_id).limit(1).execute().data or [])
    except Exception:
        rows = []
    if rows:
        return {"ok": True, "reservation_id": reservation_id, "granted": int(rows[0].get("reserved_quantity") or amount)}
    try:
        inserted = sb.table("quota_reservations").insert({
            "id": reservation_id, "tenant_id": tenant_id, "requested_quantity": amount,
            "reserved_quantity": amount, "committed_quantity": 0, "released_quantity": 0,
            "status": "reserved", "settlement_key": settlement_key,
            "request_id": request_id,
        }).execute().data or []
        if inserted:
            return {"ok": True, "reservation_id": reservation_id, "granted": amount, "compatibility_fallback": True}
    except Exception:
        period = datetime.now(timezone.utc).replace(day=1).date().isoformat()
        try:
            usage = (sb.table("usage_log").select("id,leads_delivered,quota_reserved")
                     .eq("tenant_id", tenant_id).eq("period", period).limit(1).execute().data or [])
            if usage:
                current = usage[0]
                sb.table("usage_log").update({
                    "quota_reserved": int(current.get("quota_reserved") or 0) + amount,
                }).eq("id", current["id"]).execute()
            else:
                sb.table("usage_log").insert({
                    "tenant_id": tenant_id, "period": period,
                    "leads_delivered": 0, "quota_reserved": amount,
                }).execute()
            return {"ok": True, "reservation_id": reservation_id, "granted": amount, "legacy_usage_fallback": True}
        except Exception as exc:
            return {"ok": False, "reason": type(exc).__name__}
    return {"ok": False, "reason": "reservation_unavailable"}
