"""Shared smart lead-selection policy for pipeline and GTM missions.

The planner does not discover, enrich, assign, or send. It produces one bounded,
JSON-safe decision consumed by those existing engines. Tier A is a preferred
mix, never a relaxation of quality gates; Tier B can fill only when policy
allows it and eligible Tier A supply is exhausted.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import math
from typing import Any, Iterable

SCHEMA_VERSION = "lead-selection-v1"
LANES = ("osm", "maps", "web", "yelp", "facebook", "linkedin", "instagram")


@dataclass(frozen=True)
class TierMix:
    target: int
    tier_a_percent: int
    tier_b_percent: int
    tier_c_percent: int
    tier_a_target: int
    tier_b_target: int
    tier_c_target: int
    allow_tier_b: bool
    allow_tier_c: bool


def tier_mix_for_target(target: int, *, allow_tier_b: bool = True, allow_tier_c: bool = True) -> TierMix:
    """Return target-aware A/B/C delivery mix; every delivered C needs contact."""
    value = max(0, int(target or 0))
    if value <= 100:
        a_pct, b_pct = 40, 35
    elif value <= 500:
        a_pct, b_pct = 35, 35
    elif value <= 2000:
        a_pct, b_pct = 30, 35
    elif value <= 5000:
        a_pct, b_pct = 25, 35
    else:
        a_pct, b_pct = 20, 35
    c_pct = max(0, 100 - a_pct - b_pct)
    if not allow_tier_b:
        b_pct, c_pct = 0, max(0, 100 - a_pct)
    if not allow_tier_c:
        c_pct, b_pct = 0, max(0, 100 - a_pct)
    return TierMix(
        value, a_pct, b_pct, c_pct,
        int(math.ceil(value * a_pct / 100)),
        int(math.ceil(value * b_pct / 100)),
        max(0, value - int(math.ceil(value * a_pct / 100)) - int(math.ceil(value * b_pct / 100))),
        bool(allow_tier_b), bool(allow_tier_c),
    )


def _rotation_offset(key: str, lane_count: int) -> int:
    if lane_count <= 0:
        return 0
    return int.from_bytes(sha256(str(key or "default").encode()).digest()[:8], "big") % lane_count


def _lane_budgets(target: int, enabled: dict[str, bool]) -> dict[str, int]:
    """Allocate a target across free/local and social/web families."""
    target = max(1, int(target or 1))
    weights = {"osm": .20, "maps": .28, "web": .16, "yelp": .10, "facebook": .08, "linkedin": .10, "instagram": .08}
    active = [lane for lane in LANES if enabled.get(lane, True)] or ["osm"]
    total = sum(weights[lane] for lane in active)
    budgets = {lane: max(1, round(target * weights[lane] / total)) for lane in active}
    # Keep the sum close to target while preserving at least one slot per lane.
    while sum(budgets.values()) > target and len(budgets) > 1:
        lane = max(budgets, key=lambda item: budgets[item])
        if budgets[lane] > 1:
            budgets[lane] -= 1
        else:
            break
    while sum(budgets.values()) < target:
        lane = max(active, key=lambda item: weights[item])
        budgets[lane] += 1
    return {lane: budgets.get(lane, 0) for lane in LANES}


def build_selection_decision(
    *,
    target: int,
    allow_tier_b: bool = True,
    allow_tier_c: bool = True,
    rotation_key: str,
    enabled_sources: dict[str, bool] | None = None,
    lane_plan: dict[str, Any] | None = None,
    icp_id: str | None = None,
    tenant_id: str | None = None,
    run_id: str | None = None,
    mission_id: str | None = None,
) -> dict[str, Any]:
    target = max(0, int(target or 0))
    enabled = {lane: True for lane in LANES}
    for key, value in (enabled_sources or {}).items():
        if key in enabled:
            enabled[key] = bool(value)
    mix = tier_mix_for_target(target, allow_tier_b=allow_tier_b, allow_tier_c=allow_tier_c)
    order = list(LANES)
    offset = _rotation_offset(rotation_key, len(order))
    order = order[offset:] + order[:offset]
    planned = int((lane_plan or {}).get("tranche_size") or 0)
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_id": sha256(f"{tenant_id}|{run_id}|{mission_id}|{rotation_key}|{target}".encode()).hexdigest()[:24],
        "tenant_id": tenant_id,
        "icp_id": icp_id,
        "run_id": run_id,
        "mission_id": mission_id,
        "target": target,
        "tier_policy": {
            "tier_a_percent": mix.tier_a_percent,
            "tier_b_percent": mix.tier_b_percent,
            "tier_c_percent": mix.tier_c_percent,
            "tier_a_target": mix.tier_a_target,
            "tier_b_target": mix.tier_b_target,
            "tier_c_target": mix.tier_c_target,
            "tier_a_shortfall_reason": "tier_a_supply_exhausted",
            "allow_tier_b_fallback": mix.allow_tier_b,
            "allow_tier_c_fallback": mix.allow_tier_c,
            "tier_c_contact_required": True,
            "tier_c_allowed": mix.allow_tier_c,
        },
        "lane_policy": {
            "enabled": enabled,
            "order": order,
            "rotation_key": rotation_key,
            "rotation_offset": offset,
            "budgets": _lane_budgets(target, enabled),
            "catalog_planned_lanes": planned,
            "free_first": ["osm", "maps", "web"],
            "social_lanes": ["linkedin", "instagram", "facebook"],
        },
        "selection_order": ["eligible_tier_a", "eligible_tier_b", "multi_source", "composite_quality", "contactability", "score"],
        "rationale": "Prefer verified Tier A coverage, rotate enabled lanes deterministically, then use eligible Tier B only for target shortfall.",
    }


def _quality_key(lead: dict[str, Any]) -> tuple:
    return (
        len(lead.get("sources_hit") or []),
        int(lead.get("composite_quality") or 0),
        int(lead.get("contactability") or 0),
        int(lead.get("score") or lead.get("total_score") or 0),
    )


def select_candidates(candidates: Iterable[dict[str, Any]], decision: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Select A first, then B fallback, without ever promoting B to A."""
    rows = [row for row in candidates if isinstance(row, dict)]
    target = max(0, int(decision.get("target") or 0))
    policy = decision.get("tier_policy") or {}
    a_target = min(target, max(0, int(policy.get("tier_a_target") or 0)))
    b_target = max(0, int(policy.get("tier_b_target") or 0))
    c_target = max(0, int(policy.get("tier_c_target") or 0))
    allow_b = bool(policy.get("allow_tier_b_fallback"))
    allow_c = bool(policy.get("allow_tier_c_fallback"))
    eligible_a = sorted([row for row in rows if str(row.get("tier") or "C").upper() == "A"], key=_quality_key, reverse=True)
    eligible_b = sorted([row for row in rows if str(row.get("tier") or "C").upper() == "B"], key=_quality_key, reverse=True)
    def has_contact(row: dict[str, Any]) -> bool:
        return bool(row.get("phone_verified") is True or str(row.get("phone_status") or "").lower() in {"valid", "deliverable"} or row.get("email_valid") is True or str(row.get("email_status") or "").lower() in {"valid", "deliverable"} or row.get("email"))
    eligible_c = sorted([row for row in rows if str(row.get("tier") or "C").upper() == "C" and has_contact(row)], key=_quality_key, reverse=True)
    selected = eligible_a[:a_target]
    if allow_b:
        selected.extend(eligible_b[:max(0, min(b_target, target - len(selected)))])
    if allow_c:
        selected.extend(eligible_c[:max(0, min(c_target, target - len(selected)))])
    # Fill any remaining target from the best allowed lower tier after preferred quotas.
    if len(selected) < target and allow_b:
        selected.extend([row for row in eligible_b[b_target:] if row not in selected][:target-len(selected)])
    if len(selected) < target and allow_c:
        selected.extend([row for row in eligible_c[c_target:] if row not in selected][:target-len(selected)])
    summary = {
        "tier_a_available": len(eligible_a),
        "tier_a_selected": sum(1 for row in selected if str(row.get("tier") or "").upper() == "A"),
        "tier_b_selected": sum(1 for row in selected if str(row.get("tier") or "").upper() == "B"),
        "tier_c_selected": sum(1 for row in selected if str(row.get("tier") or "").upper() == "C"),
        "tier_c_contactable_selected": sum(1 for row in selected if str(row.get("tier") or "").upper() == "C" and (row.get("email") or row.get("phone_verified") or str(row.get("phone_status") or "").lower() in {"valid", "deliverable"})),
        "tier_a_shortfall": max(0, a_target - len([row for row in selected if str(row.get("tier") or "").upper() == "A"])),
        "selected": len(selected),
    }
    return selected, summary


def validate_selection_decision(decision: dict[str, Any]) -> bool:
    policy = decision.get("tier_policy") or {}
    lane = decision.get("lane_policy") or {}
    pct = int(policy.get("tier_a_percent") or 0)
    return (
        decision.get("schema_version") == SCHEMA_VERSION
        and 20 <= pct <= 50
        and int(policy.get("tier_b_percent") or 0) >= 0
        and int(policy.get("tier_a_target") or 0) >= 0
        and int(policy.get("tier_b_target") or 0) >= 0
        and int(policy.get("tier_c_target") or 0) >= 0
        and bool(lane.get("order"))
        and set(lane.get("order") or []).issubset(set(LANES))
    )
