"""Structured, truthful release evidence for local validation.

The schema is intentionally dependency-free so the gate can run before the
application is installed.  Local records and unavailable remote records are
kept in separate sections and are validated before they are written.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "leadx.local-validation.v1"
LOCAL_MODES = {"local_static", "local_unit", "local_build", "local_browser", "local_synthetic"}
REMOTE_MODES = {"remote"}
RESULTS = {"PASS", "FAIL", "NOT_RUN", "UNVERIFIED"}
REQUIRED_FIELDS = ("environment_mode", "test_name", "result", "diagnosis", "artifacts")


@dataclass(frozen=True)
class EvidenceRecord:
    environment_mode: str
    test_name: str
    result: str
    diagnosis: str
    artifacts: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_record(record: EvidenceRecord) -> None:
    """Reject incomplete or misleading evidence before serialization."""
    values = record.as_dict()
    missing = [key for key in REQUIRED_FIELDS if key not in values]
    if missing:
        raise ValueError(f"evidence_missing_fields:{','.join(missing)}")
    if record.environment_mode not in LOCAL_MODES | REMOTE_MODES:
        raise ValueError(f"evidence_unknown_environment_mode:{record.environment_mode}")
    if record.result not in RESULTS:
        raise ValueError(f"evidence_unknown_result:{record.result}")
    if not record.test_name.strip() or not record.diagnosis.strip():
        raise ValueError("evidence_test_name_and_diagnosis_required")
    if not isinstance(record.artifacts, list) or not all(isinstance(item, str) and item.strip() for item in record.artifacts):
        raise ValueError("evidence_artifacts_must_be_nonempty_strings")
    lowered = record.test_name.lower()
    if record.environment_mode in LOCAL_MODES and any(token in lowered for token in ("remote evidence", "deployed success")):
        raise ValueError("local_evidence_mislabeled_as_remote_or_deployed")
    if record.environment_mode == "remote" and record.result not in {"UNVERIFIED", "NOT_RUN"}:
        raise ValueError("remote_evidence_requires_unverified_or_not_run")


@dataclass
class EvidenceReport:
    """Release report with explicit local sections and a remote boundary."""

    sections: dict[str, list[EvidenceRecord]] = field(default_factory=lambda: {
        "local_build": [],
        "local_unit_property": [],
        "local_browser": [],
        "local_synthetic": [],
    })
    remote_evidence: list[EvidenceRecord] = field(default_factory=list)

    def add(self, section: str, record: EvidenceRecord) -> EvidenceRecord:
        validate_record(record)
        if section == "remote_evidence":
            if record.environment_mode != "remote":
                raise ValueError("remote_section_requires_remote_mode")
            self.remote_evidence.append(record)
        else:
            if section not in self.sections:
                raise ValueError(f"evidence_unknown_section:{section}")
            if record.environment_mode == "remote":
                raise ValueError("local_section_cannot_contain_remote_mode")
            self.sections[section].append(record)
        return record

    def records(self) -> list[EvidenceRecord]:
        return [record for records in self.sections.values() for record in records] + list(self.remote_evidence)

    def validate(self) -> None:
        for record in self.records():
            validate_record(record)
        if not self.remote_evidence:
            raise ValueError("remote_evidence_section_required")
        if any(record.environment_mode == "remote" and record.result not in {"UNVERIFIED", "NOT_RUN"} for record in self.remote_evidence):
            raise ValueError("remote_evidence_must_remain_unverified")

    def as_dict(self) -> dict[str, Any]:
        self.validate()
        all_records = self.records()
        counts = {result: sum(record.result == result for record in all_records) for result in sorted(RESULTS)}
        return {
            "schema_version": SCHEMA_VERSION,
            "sections": {
                name: [record.as_dict() for record in records]
                for name, records in self.sections.items()
            },
            "remote_evidence": [record.as_dict() for record in self.remote_evidence],
            "summary": {"records": len(all_records), "counts": counts},
        }

    def write(self, output_dir: Path) -> tuple[Path, Path]:
        payload = self.as_dict()
        output_dir.mkdir(parents=True, exist_ok=True)
        json_path = output_dir / "evidence.json"
        markdown_path = output_dir / "evidence.md"
        json_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        lines = ["# LeadX local validation evidence", "", f"Schema: `{SCHEMA_VERSION}`", ""]
        for section, records in (*self.sections.items(), ("remote_evidence", self.remote_evidence)):
            lines.extend([f"## {section}", "", "| environment_mode | test_name | result | diagnosis | artifacts |", "|---|---|---|---|---|"])
            for record in records:
                artifacts = "<br>".join(record.artifacts) or "(none)"
                diagnosis = record.diagnosis.replace("|", "\\|")
                escaped_artifacts = artifacts.replace("|", "\\|")
                lines.append(f"| `{record.environment_mode}` | `{record.test_name}` | **{record.result}** | {diagnosis} | {escaped_artifacts} |")
            lines.append("")
        markdown_path.write_text("\n".join(lines), encoding="utf-8")
        return json_path, markdown_path
