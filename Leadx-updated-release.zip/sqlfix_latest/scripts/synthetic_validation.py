"""Run the complete Task 11 local synthetic lifecycle without network I/O."""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


async def _run() -> dict[str, Any]:
    from app.integrations.prod import agent_missions, discovery, discovery_runtime
    from app.integrations.prod.contact_verification_mesh import verify_email, verify_phone
    from app.integrations.prod.discovery_runtime import ProviderIsolationError
    from tests.conftest import FakeSupabase

    required_env = {
        "LOCAL_VALIDATION_MODE": "true",
        "LOCAL_AUTHENTICATION_FLAG": "true",
        "PAID_PROVIDER_ISOLATION": "true",
    }
    if any(os.environ.get(key, "").lower() not in {"1", "true", "yes", "on"} for key in required_env):
        raise RuntimeError("local synthetic flags are not all enabled")

    discovery_runtime.clear_provider_isolation_events()
    tenant_id = "local-tenant"
    request_id = "synthetic-request-001"
    reservation_id = "synthetic-reservation-001"
    job_id = "synthetic-job-001"
    state: dict[str, Any] = {
        "request": {"id": request_id, "tenant_id": tenant_id, "status": "authenticated"},
        "quota": {"id": reservation_id, "tenant_id": tenant_id, "status": "reserved", "reserved": 3},
        "crm": [],
        "events": [],
    }

    # Authenticated request -> durable reservation -> approval is represented by
    # the same state transitions used by the local contract tests.
    if state["request"]["tenant_id"] != tenant_id:
        raise AssertionError("synthetic tenant authorization failed")
    state["request"]["status"] = "pending_approval"
    state["request"]["status"] = "approved"

    compiled = agent_missions.compile_mission()
    registry_count = len(agent_missions.FULL_AGENT_REGISTRY)
    task_count = len(compiled["tasks"])
    if registry_count != 31 or task_count != 30:
        raise AssertionError(f"mission contract mismatch registry={registry_count} tasks={task_count}")
    state["mission"] = {"id": "synthetic-mission-001", "status": "running", "tasks": task_count}

    rows = await discovery.discover_leads("dental", ["Synthetic City"], limit_per_location=3)
    email = await verify_email("fixture@example.test")
    phone = await verify_phone("+1 908 642 3187")
    if len(rows) != 3 or any(row.get("source") != "local_fixture" or row.get("billable") for row in rows):
        raise AssertionError("discovery did not remain local and non-billable")
    if email.get("observations", [{}])[0].get("provider") != "local_fixture":
        raise AssertionError("email verification was not local")
    if phone.get("observations", [{}])[0].get("provider") != "local_fixture":
        raise AssertionError("phone verification was not local")

    results = []
    for index, row in enumerate(rows):
        lead = {**row, "id": row["id"], "tenant_id": tenant_id, "status": "persisted", "qualifying": True, "billable": False}
        state["crm"].append(lead)
        results.append({"task_id": f"task-{index}", "status": "persisted", "persisted": True, "qualifying": True, "billable": False})
    progress = discovery_runtime.project_progress(
        [{"id": f"task-{index}", "status": "running"} for index in range(len(rows))], results, len(rows)
    )
    if progress["completed"] != 3 or progress["remaining"] != 0 or progress["billable"] != 0:
        raise AssertionError(f"persisted progress mismatch: {progress}")

    fake = FakeSupabase({"quota_reservations": [{
        "id": reservation_id, "tenant_id": tenant_id, "status": "reserved",
        "reserved_quantity": 3, "committed_quantity": 0, "released_quantity": 0,
    }]})
    settlement = discovery_runtime.settle_reservation(
        fake, reservation_id=reservation_id, tenant_id=tenant_id,
        settlement_key=discovery_runtime.settlement_key(request_id, job_id), billable=0, reserved=3,
    )
    replay = discovery_runtime.settle_reservation(
        fake, reservation_id=reservation_id, tenant_id=tenant_id,
        settlement_key=discovery_runtime.settlement_key(request_id, job_id), billable=0, reserved=3,
    )
    if not settlement.ok or not replay.ok or not replay.replayed:
        raise AssertionError("quota release was not exactly once")
    state["quota"].update({"status": "released", "released": 3})

    # Private invalidation carries metadata only; the authoritative refetch
    # reads the CRM projection and establishes the terminal state.
    state["events"].append({"tenant_id": tenant_id, "table": "leads", "event": "UPDATE"})
    authoritative = {"tenant_id": tenant_id, "leads": list(state["crm"]), "status": "completed"}
    state["request"]["status"] = "completed"
    state["mission"]["status"] = "completed"
    if authoritative["tenant_id"] != tenant_id or len(authoritative["leads"]) != 3:
        raise AssertionError("authoritative refetch crossed tenant or lost CRM state")

    denied_categories = ("serper", "paid_enrichment", "email_send", "stripe", "lead_generation", "remote_supabase", "provider_credit")
    denied = 0
    for category in denied_categories:
        try:
            discovery_runtime.assert_provider_allowed(category)
        except ProviderIsolationError:
            denied += 1
    audit = discovery_runtime.provider_isolation_events()
    if denied != len(denied_categories) or len(audit) != len(denied_categories) or any(item.get("outcome") != "denied" for item in audit):
        raise AssertionError(f"provider isolation audit mismatch: {audit}")

    return {
        "environment_mode": "local_synthetic",
        "result": "PASS",
        "request_status": state["request"]["status"],
        "mission_status": state["mission"]["status"],
        "registry_count": registry_count,
        "downstream_task_count": task_count,
        "discovered": len(rows),
        "crm_persisted": len(state["crm"]),
        "quota_status": state["quota"]["status"],
        "private_invalidation_events": len(state["events"]),
        "authoritative_refetch": authoritative,
        "provider_isolation_audit": audit,
    }


def main() -> int:
    result = asyncio.run(_run())
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
