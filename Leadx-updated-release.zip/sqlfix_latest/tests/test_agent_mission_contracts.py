"""Task 1 contract-closure tests; local/static only, with no provider calls."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest

from app.integrations.prod import agent_missions as missions
from app.integrations.prod.agent_registry import (
    FULL_AGENT_REGISTRY,
    RegistryContractError,
    validate_registry,
)


def _graph():
    return missions.graph_template()


def test_authoritative_registry_has_explicit_contract_closure():
    catalog = validate_registry()
    assert len(catalog) == 31
    assert len(set(catalog)) == 31
    for agent_id, contract in catalog.items():
        assert contract["agent_id"] == agent_id
        assert contract["enabled"] is True
        assert contract["input_contract"]["type"] == "object"
        assert contract["output_contract"]["type"] == "object"
        assert contract["capabilities"]
        assert contract["executor_key"]
        assert contract["approval_policy"] in {"none", "required"}
        assert contract["max_cost"] >= 0
        assert contract["max_duration"] > 0


def test_compiler_returns_exact_deterministic_contract_closed_dag():
    first = missions.compile_mission()
    second = missions.compile_mission()
    assert first == second
    assert first["parent_agent_id"] == "gtm"
    assert first["graph_count"] == 30
    assert len(first["tasks"]) == 30
    assert len({task["task_id"] for task in first["tasks"]}) == 30
    assert [task["topological_order"] for task in first["tasks"]] == list(range(30))
    assert all(task["executor_key"] for task in first["tasks"])
    assert first["tasks"][0]["status"] == "queued"
    assert all(task["status"] == "blocked" for task in first["tasks"][1:])

    by_id = {task["agent_id"]: task for task in first["tasks"]}
    for task in first["tasks"]:
        assert all(dep == "gtm" or by_id[dep]["topological_order"] < task["topological_order"] for dep in task["depends_on"])


def test_create_mission_rejects_invalid_input_before_persistence(monkeypatch):
    calls = []

    def forbidden_supabase():
        calls.append("supabase")
        raise AssertionError("invalid input reached persistence")

    monkeypatch.setattr(missions, "_sb", forbidden_supabase)
    with pytest.raises(ValueError, match="agent_input_must_be_object"):
        missions.create_mission("tenant", "A valid objective", input_data=[])
    assert calls == []


def test_create_mission_rejects_invalid_graph_before_persistence(monkeypatch):
    graph = _graph()
    graph[0]["depends_on"] = ["source_router"]
    calls = []

    def forbidden_supabase():
        calls.append("supabase")
        raise AssertionError("invalid graph reached persistence")

    monkeypatch.setattr(missions, "DEFAULT_GRAPH", [(item["agent_id"], item["depends_on"], item["objective"]) for item in graph])
    monkeypatch.setattr(missions, "_sb", forbidden_supabase)
    with pytest.raises(missions.MissionGraphError, match="mission_graph_contains_cycle"):
        missions.create_mission("tenant", "A valid objective", input_data={})
    assert calls == []


def test_invalid_binding_is_rejected_without_compilation_side_effects():
    catalog = deepcopy(FULL_AGENT_REGISTRY)
    catalog["prospecting"]["executor_key"] = "dedicated:not_real"
    with pytest.raises(RegistryContractError, match="invalid_executor_binding:prospecting"):
        validate_registry(catalog)


@pytest.mark.parametrize("case", ["unknown", "missing", "self", "cycle", "duplicate"] * 20)
def test_mission_contract_closure_rejects_generated_invalid_graphs_before_side_effects(monkeypatch, case):
    graph = _graph()
    if case == "unknown":
        graph[0]["agent_id"] = "not_registered"
    elif case == "missing":
        graph[0]["depends_on"] = ["not_a_task"]
    elif case == "self":
        graph[0]["depends_on"] = [graph[0]["agent_id"]]
    elif case == "cycle":
        graph[0]["depends_on"] = ["source_router"]
    elif case == "duplicate":
        graph[1]["agent_id"] = graph[0]["agent_id"]

    def forbidden_supabase():
        raise AssertionError("invalid graph reached persistence")

    monkeypatch.setattr(missions, "_sb", forbidden_supabase)
    with pytest.raises((missions.MissionGraphError, RegistryContractError)):
        missions.compile_mission(graph=graph)


def test_registry_rejects_duplicate_pair_entries_before_binding_resolution():
    entries = list(FULL_AGENT_REGISTRY.items())
    entries[-1] = entries[0]
    with pytest.raises(RegistryContractError, match="unique_entries"):
        validate_registry(entries)


def test_registry_keeps_disabled_entries_counted_and_diagnosable():
    catalog = deepcopy(FULL_AGENT_REGISTRY)
    catalog["prospecting"]["enabled"] = False
    catalog["prospecting"]["disabled_reason"] = "local_validation_fixture_disabled"
    validated = validate_registry(catalog)
    assert len(validated) == 31
    with pytest.raises(ValueError, match="agent_disabled"):
        from app.integrations.prod.agent_registry import resolve_executor_key
        resolve_executor_key("prospecting", registry=validated)


def test_registry_rejects_binding_for_a_different_agent():
    catalog = deepcopy(FULL_AGENT_REGISTRY)
    catalog["prospecting"]["executor_key"] = "dedicated:enrichment"
    with pytest.raises(RegistryContractError, match="invalid_executor_binding:prospecting"):
        validate_registry(catalog)


def test_disconnected_task_is_rejected_before_any_durable_side_effect(monkeypatch):
    graph = _graph()
    graph[0]["depends_on"] = []
    calls = []

    def forbidden_supabase():
        calls.append("supabase")
        raise AssertionError("invalid graph reached persistence")

    monkeypatch.setattr(missions, "DEFAULT_GRAPH", [(item["agent_id"], item["depends_on"], item["objective"]) for item in graph])
    monkeypatch.setattr(missions, "_sb", forbidden_supabase)
    with pytest.raises(missions.MissionGraphError, match="missing_dependency"):
        missions.create_mission("tenant", "A valid objective", input_data={})
    assert calls == []


def test_create_mission_persists_compiled_task_contract(fake_supabase):
    mission = missions.create_mission("tenant", "A valid objective", input_data={"vertical": "synthetic"})
    assert mission["parent_agent_id"] == "gtm"
    assert mission["graph_version"] == missions.MISSION_GRAPH_VERSION
    assert mission["graph_count"] == 30
    tasks = fake_supabase.rows("agent_mission_tasks")
    assert len(tasks) == 30
    assert len({task["task_id"] for task in tasks}) == 30
    assert [task["topological_order"] for task in tasks] == list(range(30))
    assert all(task["executor_key"] for task in tasks)
    assert tasks[0]["status"] == "queued"
    assert all(task["status"] == "blocked" for task in tasks[1:])


def test_task_schema_declares_compiler_metadata():
    migration = Path(missions.__file__).resolve().parents[3] / "supabase" / "migrations" / "20261001000200_leadx_15_agent_missions.sql"
    text = migration.read_text(encoding="utf-8")
    for field in ("graph_version", "graph_count", "task_id", "topological_order", "executor_key"):
        assert field in text
