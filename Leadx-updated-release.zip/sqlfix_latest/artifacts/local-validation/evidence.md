# LeadX local validation evidence

Schema: `leadx.local-validation.v1`

## local_build

| environment_mode | test_name | result | diagnosis | artifacts |
|---|---|---|---|---|
| `local_build` | `portal_typecheck` | **PASS** | passed | artifacts\local-validation\portal_typecheck.log |
| `local_build` | `portal_next_build` | **PASS** | passed | artifacts\local-validation\portal_next_build.log |
| `local_build` | `compose_config` | **PASS** | passed | artifacts\local-validation\compose_config.log |
| `local_build` | `compose_build` | **PASS** | passed | artifacts\local-validation\compose_build.log |
| `local_build` | `compose_start` | **PASS** | passed | artifacts\local-validation\compose_start.log |
| `local_build` | `Compose health convergence within 120 seconds` | **PASS** | all core services healthy | artifacts\local-validation\compose_health.log |

## local_unit_property

| environment_mode | test_name | result | diagnosis | artifacts |
|---|---|---|---|---|
| `local_static` | `full_system_static_contracts` | **PASS** | passed | artifacts\local-validation\full_system_static_contracts.log |
| `local_static` | `migrations` | **PASS** | passed | artifacts\local-validation\migrations.log |
| `local_static` | `rls_coverage` | **PASS** | passed | artifacts\local-validation\rls_coverage.log |
| `local_static` | `security_release_gate` | **PASS** | passed | artifacts\local-validation\security_release_gate.log |
| `local_static` | `runtime_schema` | **PASS** | passed | artifacts\local-validation\runtime_schema.log |
| `local_static` | `plan_contract` | **PASS** | passed | artifacts\local-validation\plan_contract.log |
| `local_static` | `frontend_accessibility` | **PASS** | passed | artifacts\local-validation\frontend_accessibility.log |
| `local_static` | `frontend_performance_contract` | **PASS** | passed | artifacts\local-validation\frontend_performance_contract.log |
| `local_static` | `release_audit` | **PASS** | passed | artifacts\local-validation\release_audit.log |
| `local_unit` | `python_unit_and_property_tests` | **PASS** | passed | artifacts\local-validation\python_unit_and_property_tests.log |

## local_browser

| environment_mode | test_name | result | diagnosis | artifacts |
|---|---|---|---|---|
| `local_browser` | `portal_static_browser_contracts` | **PASS** | passed | artifacts\local-validation\portal_static_browser_contracts.log |

## local_synthetic

| environment_mode | test_name | result | diagnosis | artifacts |
|---|---|---|---|---|
| `local_synthetic` | `local_durable_adapter_smoke` | **PASS** | passed | artifacts\local-validation\local_durable_adapter_smoke.log |
| `local_synthetic` | `complete_synthetic_discovery_to_terminal_flow` | **PASS** | passed | artifacts\local-validation\complete_synthetic_discovery_to_terminal_flow.log |
| `local_synthetic` | `restart_reclaim_and_dependency_recovery` | **PASS** | passed | artifacts\local-validation\restart_reclaim_and_dependency_recovery.log |

## remote_evidence

| environment_mode | test_name | result | diagnosis | artifacts |
|---|---|---|---|---|
| `remote` | `Remote Evidence: remote Supabase` | **UNVERIFIED** | not run by the local-only gate; no remote credentials, provider calls, credits, or deployment are used | (none) |
| `remote` | `Remote Evidence: external providers and Serper` | **UNVERIFIED** | not run by the local-only gate; no remote credentials, provider calls, credits, or deployment are used | (none) |
| `remote` | `Remote Evidence: paid enrichment and provider credits` | **UNVERIFIED** | not run by the local-only gate; no remote credentials, provider calls, credits, or deployment are used | (none) |
| `remote` | `Remote Evidence: email delivery` | **UNVERIFIED** | not run by the local-only gate; no remote credentials, provider calls, credits, or deployment are used | (none) |
| `remote` | `Remote Evidence: Stripe billing` | **UNVERIFIED** | not run by the local-only gate; no remote credentials, provider calls, credits, or deployment are used | (none) |
| `remote` | `Remote Evidence: staging/production deployment` | **UNVERIFIED** | not run by the local-only gate; no remote credentials, provider calls, credits, or deployment are used | (none) |
