"use client";

import { useEffect, useState } from "react";
import { admin } from "@/lib/admin";
import { ErrorState } from "@/components/ui/States";

export default function SecurityPage(){
  const [a,setA]=useState<any[]>([]),[s,setS]=useState<any[]>([]),[e,setE]=useState<unknown>(null),[loading,setLoading]=useState(true);
  const load = () => {
    setLoading(true); setE(null);
    Promise.all([admin.auditLog(100), admin.securityEvents(100)])
      .then(([x,y])=>{setA(x.events||[]);setS(y.events||[]);})
      .catch(setE)
      .finally(()=>setLoading(false));
  };
  useEffect(()=>{load();},[]);
  if (loading) return <div className="page text-ink-faint" aria-busy="true">Loading security events…</div>;
  if (e) return <div className="page"><ErrorState error={e} onRetry={load} /></div>;
  return <div className="page space-y-5"><header><div className="section-kicker">Security & governance</div><h1 className="page-title">Audit center</h1><p className="page-sub">Administrative actions, security signals and compliance evidence.</p></header><section className="data-card p-5"><div className="section-kicker">Security events</div><div className="mt-3 space-y-2">{s.map(x=><div key={x.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface-2 p-3 text-sm"><div><strong>{x.event_type}</strong><div className="text-xs text-ink-faint">{x.created_at}</div></div><span className="pill bg-surface-3">{x.severity}</span></div>)}{!s.length&&<p className="text-sm text-ink-faint">No security events recorded.</p>}</div></section><section className="data-card p-5"><div className="section-kicker">Audit trail</div><div className="mt-3 space-y-2">{a.slice(0,25).map(x=><div key={x.id} className="rounded-xl border border-line bg-surface-2 p-3"><div className="flex justify-between gap-3 text-sm"><strong>{x.action}</strong><span className="text-xs text-ink-faint">{x.created_at}</span></div><div className="mt-1 text-xs text-ink-muted">{x.actor_type} · {x.resource_type||'system'} {x.resource_id||''}</div>{x.reason&&<div className="mt-1 text-xs text-ink-faint">Reason: {x.reason}</div>}</div>)}{!a.length&&<p className="text-sm text-ink-faint">No audit entries recorded.</p>}</div></section></div>
}
