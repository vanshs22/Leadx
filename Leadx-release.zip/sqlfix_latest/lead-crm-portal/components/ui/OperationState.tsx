import Link from "next/link";
import { PollingDeadlineState } from "./States";

export type OperationState = {
  runId?: string;
  jobId?: string;
  status: string;
  stage?: string;
  lastProgressAt?: string;
  queueAgeSeconds?: number;
  retries?: number;
  workerStatus?: string;
  reasonCode?: string;
  requestId?: string;
  deadlineReached?: boolean;
};

type RecordLike = Record<string, unknown>;

function record(value: unknown): RecordLike {
  return value && typeof value === "object" ? value as RecordLike : {};
}

function text(value: unknown): string | undefined {
  return value == null || value === "" ? undefined : String(value);
}

function number(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function first(...values: unknown[]) {
  return values.find((value) => value != null && value !== "");
}

/** Normalize request, run, and job payloads into the same visible operation contract. */
export function toOperationState(value: unknown, fallback: Partial<OperationState> = {}): OperationState {
  const source = record(value);
  const run = record(first(source.run, source.operation, source.progress));
  const job = record(first(source.job, source.job_state));
  const meta = record(source.meta);
  const status = text(first(source.status, run.status, job.status, fallback.status)) || "queued";
  return {
    runId: text(first(source.run_id, source.runId, run.id, run.run_id, fallback.runId)),
    jobId: text(first(source.job_id, source.jobId, job.id, job.job_id, run.job_id, fallback.jobId)),
    status,
    stage: text(first(source.stage, source.current_stage, run.stage, run.current_stage, job.stage, fallback.stage)),
    lastProgressAt: text(first(source.last_progress_at, source.lastProgressAt, run.last_progress_at, job.last_progress_at, fallback.lastProgressAt)),
    queueAgeSeconds: number(first(source.queue_age_seconds, source.queueAgeSeconds, run.queue_age_seconds, job.queue_age_seconds, fallback.queueAgeSeconds)),
    retries: number(first(source.retries, source.retry_count, run.retries, job.attempts, fallback.retries)),
    workerStatus: text(first(source.worker_status, source.workerStatus, run.worker_status, job.worker_status, fallback.workerStatus)),
    reasonCode: text(first(source.reason_code, source.reasonCode, run.reason_code, job.reason_code, meta.reason_code, fallback.reasonCode)),
    requestId: text(first(source.request_id, source.requestId, fallback.requestId)),
    deadlineReached: fallback.deadlineReached,
  };
}

function age(seconds?: number) {
  if (seconds == null) return "—";
  if (seconds < 60) return `${Math.round(seconds)}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
  return `${(seconds / 3600).toFixed(1)}h`;
}

function label(value?: string) {
  return value ? value.replace(/[_-]+/g, " ") : "—";
}

export function OperationStateCard({
  operation,
  title = "Operation progress",
  onRefresh,
  jobsHref,
}: {
  operation: OperationState;
  title?: string;
  onRefresh?: () => void;
  jobsHref?: string;
}) {
  const status = label(operation.status);
  return (
    <section className="rounded-2xl border border-line bg-surface-2/50 p-4" role="status" aria-label={title} aria-live="polite">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-ink">{title}</h2>
          <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 font-mono text-[11px] text-ink-faint">
            {operation.runId ? <span>Run {operation.runId}</span> : null}
            {operation.jobId ? <span>Job {operation.jobId}</span> : null}
          </div>
        </div>
        <span className="pill bg-brand-500/15 text-brand-700 dark:text-brand-300">{status}</span>
      </div>
      <dl className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
        <div><dt className="text-ink-faint">Stage</dt><dd className="mt-1 font-medium text-ink">{label(operation.stage)}</dd></div>
        <div><dt className="text-ink-faint">Queue age</dt><dd className="mt-1 font-medium text-ink">{age(operation.queueAgeSeconds)}</dd></div>
        <div><dt className="text-ink-faint">Retries</dt><dd className="mt-1 font-medium text-ink">{operation.retries ?? 0}</dd></div>
        <div><dt className="text-ink-faint">Worker</dt><dd className="mt-1 font-medium text-ink">{label(operation.workerStatus)}</dd></div>
      </dl>
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-muted">
        <span>Last progress: {operation.lastProgressAt ? new Date(operation.lastProgressAt).toLocaleString() : "not reported"}</span>
        {operation.reasonCode ? <span>Reason: <code>{operation.reasonCode}</code></span> : null}
        {operation.requestId ? <span>Request ID: <code>{operation.requestId}</code></span> : null}
      </div>
      {operation.deadlineReached && onRefresh ? <div className="mt-3"><PollingDeadlineState onRefresh={onRefresh} /></div> : null}
      {jobsHref ? <Link className="mt-3 inline-flex rounded-md border border-line px-2.5 py-1 text-xs font-medium text-ink hover:bg-surface-2" href={jobsHref}>Open jobs monitor</Link> : null}
    </section>
  );
}
